/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
// hc1xComm.cpp
#include "contain.h"
#include "hc1xcomm.h"
#include "schedule.h"
#include "../hc2xio/include/hc2xio_exports.h"

extern DbContainer g_dbContainer;

QueryResponse  *  Hc1xComm_pQueryResponse = 0;
Hc1xComm	   *  Hc1xComm_pHc1xComm = 0;

DIN			*digitalInDb;
DOUT		*digitalOutDb;
ANALOGIN 	*analogInDb;
ANALOGOUT   *analogOutDb;
AlarmQueue	*alarmQueueDb;						// a 16550 must be present, retries > 3 for a single query

void QueryResponse_init(QueryResponse* pQueryResponse, char* szName)
{
	pQueryResponse->name[0] = '\0';
	strcpy( pQueryResponse->rBuffer, "Response Buffer" );
	pQueryResponse->queryMessLength	  = 0;
	pQueryResponse->respMessLength	  = 0;
	pQueryResponse->charOffset		  = 0;
	pQueryResponse->messageOk		  = FALSE;
	pQueryResponse->dataReady		  = FALSE;

	memset( pQueryResponse->queryMessage, 0, sizeof( pQueryResponse->queryMessage) );
	memset( pQueryResponse->responseMessage, 0, sizeof( pQueryResponse->responseMessage) );
}

//*****************************************************************************
// QueryResponse::messageValid( )
//
// Abstract:
// All of the modbus commands used in this projec 0x01,0x02,0x03,0x04,0x0f,0x10 
// have responses that are related to the request.
// Writing of a single coil 0x05 and single register 0x06 are not implemented
// This is just one of another checks to make sure the messge is valid. If it 
// has already been deemed in valid then do nothing. 
//
// Programmer: Steven Young
// Date: 05/01/1998
//
//*****************************************************************************
BOOL QueryResponse_isMessageValid(QueryResponse* pQueryResponse)
{
	pQueryResponse->exceptionAllowed = FALSE;
	if ( pQueryResponse->messageOk == TRUE )
	{	
		switch ( pQueryResponse->responseMessage[01] )
		{
			case READ_COILS_FUNCTION:		//	0x01
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 2 ); 
					break;
			case READ_DIGITAL_IN_FUNCTION:	//  0x02
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 2 );
					break;
			case READ_ANALOG_OUT_FUNCTION:	//  0x03
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 2 );
					break;
			case READ_ANALOG_IN_FUNCTION:	//	0x04
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 2 );
					break;
			case WRITE_DIGITAL_OUT_FUNCTION://	0x0f
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 6 );
					break;
			case WRITE_ANALOG_OUT_FUNCTION:	//	0X10
					pQueryResponse->messageOk = QueryResponse_headerCompare( pQueryResponse, 0, 6 );
					break;
			case 0x90:	// an exception message when writing TPO's
					if ( pQueryResponse->responseMessage[0] != 0x01 )
						pQueryResponse->messageOk = FALSE;
					if ( pQueryResponse->responseMessage[1] != 0x90 )
						pQueryResponse->messageOk = FALSE;
					if ( pQueryResponse->responseMessage[2] != 0x05 )	
						pQueryResponse->messageOk = FALSE;
					if ( pQueryResponse->responseMessage[3] != 0x8C )	
						pQueryResponse->messageOk = FALSE;
					if ( pQueryResponse->responseMessage[4] != 0x03 )	
						pQueryResponse->messageOk = FALSE;
					if ( pQueryResponse->messageOk == TRUE )
					{
						pQueryResponse->exceptionAllowed = TRUE;
					}
					break;
			default:
					pQueryResponse->messageOk = FALSE;
		}
	}
	return pQueryResponse->messageOk;
}

//*****************************************************************************
// BOOL QueryResponse::headerCompare( UINT startPos, UINT byteCounter )
//
// Abstract:
// Compare a range of bytes that are known to be the same under the modbus 
// protocol. If the compare fails then the message is not valid.
//
// Programmer: Steven Young
// Date: 05/01/1998
//
//*****************************************************************************
BOOL QueryResponse_headerCompare(QueryResponse* pQueryResponse, UINT startPos, UINT byteCount )
{
	PUCHAR pQuery = pQueryResponse->queryMessage + startPos;
	PUCHAR pResponse = pQueryResponse->responseMessage + startPos;
	BOOL status = TRUE;
	int lcv;

	for ( lcv = 0; lcv < byteCount; lcv++ )
	{
		if (  pResponse[lcv] != pQuery[lcv] )
		{
			status = FALSE;
		}	
	}

	return status;
}

//******************************************************************************
// class Hc1xComm_Hc1xComm
//
// Abstract:
// constructor for communications module to HC1X module.
//
// Programmer: Steven Young
// Date: 04/23/1998
//
//******************************************************************************

void Hc1xComm_init( Hc1xComm* pHc1xComm, const char *szName)
{
	int lcv;

	strcpy(pHc1xComm->name, szName);
	pHc1xComm->messagesSent	= 0;
	pHc1xComm->goodReplies		= 0;
	pHc1xComm->messageErrorCount = 0;
	pHc1xComm->m_sendInProgress = FALSE;
	
	for (  lcv = 0; lcv < MaxQueryMessages; lcv++ )
	{
		switch ( lcv )
		{
			case READ_COILS_MESSAGE:	
				strcpy(pHc1xComm->qr[lcv].name, "READ COILS" );
				break;
			case READ_DIGITAL_IN_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "READ DIGITAL IN");
				break;
			case READ_ANALOG_OUT_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "READ ANALOG OUT" );
				break;
			case READ_ANALOG_IN_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "READ ANALOG IN" );
				break;
			case READ_ENCODERS_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "READ ENCODERS" );
				break;
			case WRITE_DIGITAL_OUT_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "WRITE DIGITAL OUT" );
				break;
			case WRITE_ANALOG_OUT_MESSAGE:
				strcpy(pHc1xComm->qr[lcv].name, "WRITE ANALOG OUT" );
				break;
			default:
				strcpy(pHc1xComm->qr[lcv].name, "MESSAGE BUFFER" );
				break;
		}
	}

	alarmQueueDb = &( g_dbContainer.alarmQueueDb	);
	digitalInDb = &( g_dbContainer.digitalInDb	);
	digitalOutDb = &( g_dbContainer.digitalOutDb	);
	analogInDb = &( g_dbContainer.analogInDb	);
	analogOutDb = &( g_dbContainer.analogOutDb	);
}

//******************************************************************************
//******************************************************************************
BOOL Hc1xComm_addMessage(Hc1xComm* pHc1xComm, UCHAR messageNo, UCHAR slaveAddress, DWORD startAddress, DWORD noOfPoints )
{
	PUCHAR pMessage;
	BOOL status = TRUE;
	UCHAR crcOffset;
	UINT byteOffset;
	UINT lcv;
	UCHAR *pDigitalOutBits;
	UCHAR sizeOfDigitalOutBitsArray;

//printk("hc2xctl: Hc1xComm_addMessage() messageNo = %d\n", messageNo);
	switch ( messageNo )
	{
		// all read messages use the same basic format.
		case READ_COILS_MESSAGE			: 	// function 01
				pMessage = pHc1xComm->qr[messageNo].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = READ_COILS_FUNCTION;
				pMessage[2] = (UCHAR)((startAddress >> 8 	&	0xff));
				pMessage[3] = (UCHAR)(startAddress         	&	0xff);
				pMessage[4] = (UCHAR)((noOfPoints >> 8)    	&	0xff);
				pMessage[5] = (UCHAR)(noOfPoints   	 		&	0xff);
				crcOffset = 6;
				pHc1xComm->qr[messageNo].queryMessLength = crcOffset + 2;
				break;
		case READ_DIGITAL_IN_MESSAGE	: 	// function 02
				pMessage = pHc1xComm->qr[messageNo].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = READ_DIGITAL_IN_FUNCTION;
				pMessage[2] = (UCHAR)((startAddress >> 8)	&	0xff);
				pMessage[3] = (UCHAR)(startAddress         	&	0xff);
				pMessage[4] = (UCHAR)((noOfPoints >> 8 )   	&	0xff);
				pMessage[5] = (UCHAR)(noOfPoints   	 		&	0xff);
				crcOffset = 6;
				pHc1xComm->qr[messageNo].queryMessLength = crcOffset + 2;
				break;
		case READ_ANALOG_OUT_MESSAGE	:   // function 03
				pMessage = pHc1xComm->qr[messageNo].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = READ_ANALOG_OUT_FUNCTION;
				pMessage[2] = (UCHAR)((startAddress >> 8)	&	0xff);
				pMessage[3] = (UCHAR)(startAddress         	&	0xff);
				pMessage[4] = (UCHAR)((noOfPoints >> 8 )   	&	0xff);
				pMessage[5] = (UCHAR)(noOfPoints   	 		&	0xff);
				crcOffset = 6;
				pHc1xComm->qr[messageNo].queryMessLength = crcOffset + 2;
				break;
		case READ_ANALOG_IN_MESSAGE		:   // function 04
				pMessage = pHc1xComm->qr[messageNo].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = READ_ANALOG_IN_FUNCTION;
				pMessage[2] = (UCHAR)((startAddress >> 8)	&	0xff);
				pMessage[3] = (UCHAR)(startAddress         	&	0xff);
				pMessage[4] = (UCHAR)((noOfPoints >> 8 )   	&	0xff);
				pMessage[5] = (UCHAR)(noOfPoints   	 		&	0xff);
				pHc1xComm->qr[messageNo].queryMessLength = 8;
				crcOffset = 6;
				break;
		case WRITE_DIGITAL_OUT_MESSAGE:
				DOUT_getOutputArray(digitalOutDb,  &pDigitalOutBits, &sizeOfDigitalOutBitsArray );
				pMessage = pHc1xComm->qr[WRITE_DIGITAL_OUT_MESSAGE].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = WRITE_DIGITAL_OUT_FUNCTION;
				pMessage[2] = 0;   	// since we are writing the full array always start at 0
				pMessage[3] = 0;    // Due to high overhead it is not logical to offer partial array writes.
				pMessage[4] = sizeOfDigitalOutBitsArray >> 5 & 0xff; 	// the equivalane of multiplying by 8 and dividing by 256
				pMessage[5] = sizeOfDigitalOutBitsArray << 3 & 0xff; 	// multiply bytes by 8 to get bits thus << 3
				pMessage[6] = sizeOfDigitalOutBitsArray 		&	0xff;
				byteOffset = 7;
				for ( lcv = 0; lcv < sizeOfDigitalOutBitsArray; lcv++ )
				{
					pMessage[ lcv + byteOffset ] = pDigitalOutBits[lcv];
				}
				
				crcOffset = byteOffset + sizeOfDigitalOutBitsArray;
				pHc1xComm->qr[messageNo].queryMessLength = crcOffset + 2;
				break;
		case WRITE_ANALOG_OUT_MESSAGE:
				pMessage = pHc1xComm->qr[WRITE_ANALOG_OUT_MESSAGE].queryMessage;
				pMessage[0] = slaveAddress;
				pMessage[1] = WRITE_ANALOG_OUT_FUNCTION;
				pMessage[2] = (UCHAR)((startAddress >> 8)   &	0xff);
				pMessage[3] = (UCHAR)(startAddress          &	0xff);
				pMessage[4] = 0;				// number of points cannot be greater than 122
				pMessage[5] = (UCHAR)(noOfPoints      	   &	0xff);
				pMessage[6] = (UCHAR)(noOfPoints << 1);	// the number of bytes.
				for ( lcv = 0; lcv < noOfPoints; lcv++ )
				{
					pHc1xComm->qr[WRITE_ANALOG_OUT_MESSAGE].queryMessage[7+(lcv<<1)] = (ANALOGOUT_get(analogOutDb, startAddress+lcv)>>8)/*(*(analogOutDb))[startAddress+lcv]*/& 0xff;
					pHc1xComm->qr[WRITE_ANALOG_OUT_MESSAGE].queryMessage[8+(lcv<<1)] = ANALOGOUT_get(analogOutDb, startAddress+lcv)/*(*(analogOutDb))[startAddress+lcv]*/& 0xff;
				}
				
				crcOffset = 7+(noOfPoints<<1);		
				pHc1xComm->qr[messageNo].queryMessLength = crcOffset+2;
				break;
		default:
			crcOffset = 0;
			status = FALSE;
	}

	if ( status == TRUE  )
	{
		ModbCRC_calcCRC( pMessage, crcOffset, pMessage+crcOffset, pMessage+crcOffset+1);
	}

	return status;
}

//******************************************************************************
// void Hc1xComm_sendMessage( UCHAR messageNo, BOOL * pProcessState )
//
// Abstract:
// The messages for creating the requests for reading the Digital and Analog 
// Inputs and the Writing of the Digital and Analog Outputs. A Miscellaneous 
// message needs to be included in order for the setting of the default parameters
// of the HC1X. Since this message will only be needed to be sent intermittently 
// it will be implemented through DeviceIOControl.
//
// Programmer: Steven Young
// Date: 05/01/1998
//
//******************************************************************************
void Hc1xComm_sendMessage(Hc1xComm* pHc1xComm, UCHAR messageNo, BOOL * pProcessState)
{
	int noOfCharsToSend;
	int status = 0;
	int i;
#if 0
	printk("hc2xctl: send msg: ");
	for ( i = 0; i < pHc1xComm->qr[messageNo].queryMessLength; i++)
	{
		printk("[%x]", pHc1xComm->qr[messageNo].queryMessage[i]);
	}
	printk("\n");
#endif

	//printk("hc2xctl: Entered Hc1xComm_sendMessage() messageNo = %d    noOfCharsToSend = %d\n", messageNo, pHc1xComm->qr[messageNo].queryMessLength);
	if(!pHc1xComm->m_sendInProgress)
	{
	//	printk("hc2xctl: !m_sendInProgress\n");
		noOfCharsToSend = pHc1xComm->qr[messageNo].queryMessLength;
		pHc1xComm->m_sendInProgress = TRUE;
		pHc1xComm->pInProcess = pProcessState;

		pHc1xComm->pQueryResponse = pHc1xComm->qr + messageNo;
		pHc1xComm->qr[messageNo].respMessLength = 0;
		pHc1xComm->pQueryResponse->messageOk = TRUE;	// need to assume the best so that any error will reset to false.
		pHc1xComm->pQueryResponse->dataReady = FALSE;	// when true this data can be moved into the arrays.


		status = sendMessage(noOfCharsToSend, pHc1xComm->qr[messageNo].queryMessage, pHc1xComm->qr[messageNo].responseMessage, &(pHc1xComm->qr[messageNo].respMessLength));
 
		if (status == 1)
		{
			pHc1xComm->messagesSent++;
			pHc1xComm->m_sendInProgress = FALSE;
		}
	}
}


//*****************************************************************************
// void Hc1xComm_resetCommStats( )
//
// Abstract:
// When debugging or starting up the machinery there may be a benefit to finding
// out if the problems encountered could be caused by comm errors.
// The statistics on the number of messages sent of which valid replies were 
// received and how many errors occurred. 
// messagesSent = goodReplies + messageErrorCount withing a count of 1.
// 
//*****************************************************************************
void Hc1xComm_resetCommStats(Hc1xComm* pHc1xComm )
{
	pHc1xComm->messagesSent =	0;
	pHc1xComm->goodReplies = 0;
	pHc1xComm->messageErrorCount = 0;
}


QueryResponse * Hc1xComm_getQueryResponseBuffer(Hc1xComm* pHc1xComm, UINT messageId )
{
	QueryResponse *pBuffer = NULL;

	if ( messageId < NO_OF_QUERY_MESSAGES )
	{
		pBuffer = &(pHc1xComm->qr[messageId]);
	}
	return pBuffer;
}

//******************************************************************************
// void Hc1xComm_commIrqHandler( )
//
// Abstract:
// The interrupt handler for the comm port. As the data is received it will need 
// be checked for validity and the CRC verified. 
// Currently checking for the following Errors:
//
//	Overrun Error
//  Parity Error
//	Framing Error
//	Break Interrupt 
//	Error in Receiver FIFO
//  Correct message response - slave and function at minimum
//	CRC
//
// Programmer: Steven Young
// Date: 05/01/1998
//		
//******************************************************************************
BOOL Hc1xComm_commIrqHandler( Hc1xComm* pHc1xComm )
{
	QueryResponse* pQueryResponse = NULL;

	PARAM_CHECK_RETURN( pHc1xComm, "Hc1xComm_commIrqHandler", 0);
	if ( pHc1xComm->pQueryResponse == NULL )
		return FALSE;

	pQueryResponse = pHc1xComm->pQueryResponse;

//printk("Hc1xComm_commIrqHandler() g_bReceived = %d\n", g_bReceived);
	if ( !g_bReceived )
		return FALSE;

	QueryResponse_isMessageValid(pQueryResponse); 
//printk("Hc1xComm_commIrqHandler() pQueryResponse->messageOk = %d\n", pQueryResponse->messageOk); 
	if ( pQueryResponse->messageOk == TRUE )
	{
//printk("Hc1xComm_commIrqHandler() pQueryResponse->exceptionAllowed = %d\n", pQueryResponse->exceptionAllowed);
		if ( pQueryResponse->exceptionAllowed != TRUE )
		{

//printk("Hc1xComm_commIrqHandler(): respMessLegth = %d\n", pQueryResponse->respMessLength);
			// only calculate CRC if message is Ok.
			if ( ModbCRC_checkCRC( pQueryResponse->responseMessage, pQueryResponse->respMessLength) == TRUE )
			{
				pQueryResponse->dataReady = TRUE;
				pHc1xComm->goodReplies++;

//printk("Hc1xComm_commIrqHandler(): crc = TRUE, *(pHc1xComm->pInProcess) = FALSE\n");
				*(pHc1xComm->pInProcess) = FALSE;
			}
			else
			{
//printk("Hc1xComm_commIrqHandler(): crc = FALSE\n");
				pQueryResponse->dataReady = FALSE;
				Hc1xComm_errorCountInc(pHc1xComm);
			}
		}
		else
		{
			pQueryResponse->dataReady = TRUE;
			pHc1xComm->goodReplies++;
//printk("Hc1xComm_commIrqHandler(): *(pHc1xComm->pInProcess) = FALSE\n");
			*(pHc1xComm->pInProcess) = FALSE;
		}
	}
	else
	{
		pQueryResponse->dataReady = FALSE;	
		Hc1xComm_errorCountInc(pHc1xComm);
	}

	return TRUE;
}

void Hc1xComm_errorCountInc( Hc1xComm* pHc1xComm ) 
{
	pHc1xComm->messageErrorCount++; 
}
