/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __OVEN_H__
#define __OVEN_H__

#include "typedefdefine.h"


// Board Drop Config Options
//		LANE1	LANE2	
// 0.	NONE	NONE	4.	TIMED	NONE	8.	BEAM	NONE	12.	BOTH	NONE
// 1.   NONE	TIMED	5.	TIMED	TIMED	9.	BEAM	TIMED	13. BOTH	TIMED
// 2.	NONE	BEAM	6.	TIMED	BEAM	10.	BEAM	BEAM	14.	BOTH	BEAM	
// 3.	NONE	BOTH	7.	TIMED	BOTH	11.	BEAM	BOTH	15.	BOTH	BOTH
// 
// Boards Processed Options
//		LANE1	LANE2
// 0.     0		  0
// 1.	  1       0
// 2.	  0       1
// 3.     1       1
//
// Boards In Oven Options:
//		LANE1	LANE2
// 0.	  0		  0
// 1.	  1		  0
// 2.	  0	      1
// 3.     1       1		
// 
// SMEMA Interface Types			// OR THESE TOGETHER FOR THE TYPE
//		LANE 1		LANE 2
// 0.	NONE		16.  NONE
// 1.	SMEMAII		32.  SMEMAII
// 2.	TDK			64.	 TDK
// 4.	FUJI		128. FUJI
// 8.	SEAGATE		256. SEAGATE
// 
// Animation
//		LANE 1		LANE 2
// 0.	0			0
// 1.   1			0
// 2.	0			1
// 3.	1			1

enum { COOLDOWN = 0 };		// cooldown is always job 0.
enum { NONE=0, BEAM=1, TIMED=2, TIMEDBEAM=3};

typedef struct _Oven_
{
//private:
	char	name[MaxNameLength+1];
	char recipeName[MAX_RECIPE_NAME_LENGTH];
	DWORD					scanPeriod;
	DWORD					scanCounts;
	DWORD					tempJobNo;		        // the new job before jobloadcomplete is set.
	DWORD					jobNo;			        // default to 0 cooldown
	DWORD					noBelts;   		        // 1 or 2 - default 1
	DWORD					noHeatZones;	        // depending on the model the zones can range from 4 to 24
	DWORD					noRails;  		        // 0 to 3 rails may be used. Per IO table if 3 rails only 2 belts.
	DWORD					cdAmbientTemp;          // in degrees c - must be > than MinTemp and < MaxTemp
	DWORD					startPowFailTime;
	DWORD					startPowCooldownFailTime;
    DWORD					currentPowFailTime;
    DWORD					currentPowFailCooldownTime;
	DWORD					startLowExhaustTime;
	DWORD					startBlowerFailTime;
	DWORD					startOverTempTime;
	DWORD					startHighWaterTempTime;
	DWORD					boardDropConfig;		    // see above		
	DWORD					boardsProcessedConfig;	    // see above 
	DWORD					boardsInOvenConfig;			// see above
	DWORD					smemaConfig;				// see above
	DWORD					animationConfig;			// see above
	DWORD					modelNo;					// 1088=0,1500,1700,1800,1800z,1900,788
	DWORD					FiveSecondStartTime;        // the start time for the job loading output
	DWORD					FiveSecondCurrentTime;      // the current time for the job loading output
	DWORD					FiveSecondPreviousTime;     // the current time for the job loading output
	DWORD					m_dwrdCooldownStartTime;

	BOOL					jobStartupComplete;  		// default to TRUE to turn off contactor
	BOOL					jobLoadInProgress;			// the user interface is loading a new job, when done it sets this to false.
	BOOL					coolDown;                   // coolDown enabled!!
	BOOL					eStopSet;
	BOOL					lowExhaustWarningSent;
	BOOL					COOLDOWNachievedFlag;
	BOOL					wantResume;
	BOOL					startUpWithJob;
	BOOL					leftToRight;
	BOOL					redundantOverTempOptionEnabled;
	BOOL					lto;
	BOOL					demoMode;
	BOOL					blowerFailureCheckEnabled;
	BOOL					autoCleanFluxMode;
	BOOL					lane3Enabled;
	BOOL					lane4Enabled;
	BOOL					FiveSecondTimerIsRunning;
	BOOL					m_bCooldownCountOn;
	BOOL					m_bAudibleBlowFail;		// fjn -- needed for alarm.c
	BOOL					m_bCurrentDelayedCooldown;	// fjn -- needed for oven.c

	//WDT 1.31.1 added to allow dynamic timing for low exhaust warnings and alarms
	int					m_iLowExhWarning;
	int					m_iLowExhAlarm;
	DWORD					m_dwrdDelayedCooldownTime;

	//WDT 3.20.01 added to disable high h2o alarm for board type a
	BOOL					m_bTypeA;

	//WDT 4.27.01 added to indicate if the power failure information message has already been sent
	BOOL					m_bFailureNotified;

	//WDT 07.30.01
	BOOL					m_bIsPowerOKForWarningTime;
	
	BOOL					m_bExhaustWarningsEnabled;
	BOOL					m_bExhaustAlarmsEnabled;

	BOOL					m_bSelfAcknowledgeDisabled;
	BOOL					m_bDisableDevAlarmInStartup;
	DWORD					m_StartupCompletePlusDelayTime;
	UINT					m_iPowerfailureTime;

	BOOL					m_bFiveSecondDisabled;
	BOOL					m_bDelayedCooldown;
	BOOL					m_bCurrentMonitorDelayedCooldown;
	BOOL					m_bHeaterFailureDelayedCooldown;
	BOOL					m_bRequestCooldown;
	BOOL					m_bStarted;
	BOOL 					m_bSysParamsSet;
	DWORD					m_dwrCurrentGroup;
	DWORD					m_dwrdLoadTime;
	BOOL					m_bPendingCooldown;
	BOOL					mbAlarmScanner;
	int						miAlarmOutput;
	BOOL					mbAlarmState;
} Oven;


void	Oven_checkE_Stop(Oven* pOven);
void	Oven_checkForPowerFail(Oven* pOven);
void	Oven_checkForLowExhaust(Oven* pOven);
void	Oven_checkJobLoad(Oven* pOven);
void	Oven_checkForHighWaterTemp(Oven* pOven);
void	Oven_checkForOverTemp(Oven* pOven);
void	Oven_checkBlowerFailure(Oven* pOven);
void	Oven_SetJobNewJobLoadedOutput(Oven* pOven);
void Oven_SetSys(Oven* pOven, int iStarted);
void Oven_init(Oven* pOven);

//added to test if the oven is in powerfailure prior to new recipe load
BOOL Oven_ExternalCheckForPowerFailure(Oven* pOven);	
BOOL Oven_isEStopSet(Oven* pOven);
UINT Oven_getNoBelts(Oven* pOven);

void Oven_SetDemoMode(Oven* pOven, BOOL demoModeState);
BOOL Oven_getDemoMode(Oven* pOven);
const char* const Oven_getName(Oven* pOven);

UINT Oven_getJob(Oven* pOven);
void Oven_setJob(Oven* pOven, UINT nJobNo );

BOOL Oven_isJobStartupComplete(Oven* pOven);
void Oven_setJobStartupComplete(Oven* pOven, BOOL jobStartupState /*= TRUE*/ );
void Oven_pause(Oven* pOven);		
void Oven_resume(Oven* pOven);		
BOOL Oven_isJobLoadInProgress(Oven* pOven);
void Oven_setCOOLDOWNachieved (Oven* pOven, BOOL atCoolDown );
BOOL Oven_isCOOLDOWNcomplete(Oven* pOven);
DWORD Oven_getScanTime(Oven* pOven);
BOOL Oven_getStartUpWithJob(Oven* pOven);
void Oven_setStartWithJob(Oven* pOven, BOOL jobState /*= FALSE*/ );

BOOL Oven_setModelNo(Oven* pOven, DWORD model_no );
DWORD Oven_getModelNo(Oven* pOven);
void Oven_setDirection(Oven* pOven, BOOL standardDirection );
BOOL Oven_getDirection(Oven* pOven);

void Oven_setRedundantOverTempOption(Oven* pOven, BOOL option /*= TRUE*/ );
void Oven_setLTOption(Oven* pOven, BOOL option /*= TRUE*/ );
BOOL Oven_getLTOption(Oven* pOven);
void Oven_setBlowerFailureOption(Oven* pOven, BOOL option /*= TRUE*/);
BOOL Oven_getBlowerFailureOption(Oven* pOven);
void Oven_setAutoCleanFlux(Oven* pOven, BOOL autoCleanMode /*= TRUE*/);
BOOL Oven_getAutoCleanFlux(Oven* pOven);

BOOL Oven_getLane3EnabledState(Oven* pOven);
BOOL Oven_getLane4EnabledState(Oven* pOven);
void Oven_process(Oven* pOven);

void Oven_setAsBoardTypeA(Oven* pOven, BOOL bType);
BOOL Oven_getIsBoardTypeA(Oven* pOven);

void Oven_disableAutoAcknowledge(Oven* pOven, BOOL bEntered);
BOOL Oven_getIsAutoAcknowledgedDisabled(Oven* pOven);
BOOL Oven_getIsDevAlarmInStartupDisabled(Oven* pOven);
void Oven_setStartupCompletePlusDelay(Oven* pOven, int iTimeInSec);
DWORD Oven_getStartupCompletePlusDelayTime(Oven* pOven);
void Oven_setFiveSecondDisable(Oven* pOven, BOOL bDisabled);
BOOL Oven_getFiveSecondDisable(Oven* pOven);
DWORD Oven_getTempJobNo(Oven* pOven);
void Oven_initiateCooldownCountdown(Oven* pOven, BOOL bInit);
void Oven_setDelayedCooldown(Oven* pOven, BOOL cooldownDelayed);
BOOL Oven_getDelayedCooldown(Oven* pOven);
void Oven_setCurrentMonitorDelayedCooldown(Oven* pOven, BOOL currentMonitorCooldownDelayed);
BOOL Oven_getCurrentMonitorDelayedCooldown(Oven* pOven);
void Oven_setHeaterFailureDelayedCooldown(Oven* pOven, BOOL heaterFailureCooldownDelayed);
BOOL Oven_getHeaterFailureDelayedCooldown(Oven* pOven);
void Oven_setDelayedCooldownTime(Oven* pOven, int iTime);
BOOL Oven_getAppCoolFlag(Oven* pOven);
void Oven_setAppFlag(Oven* pOven, BOOL bWeNeedCooldown);
BOOL Oven_cooldownModePending(Oven* pOven);

DWORD Oven_getStartupGroup(Oven* pOven);
BOOL Oven_LaunchCooldown(Oven* pOven);
void Oven_requestCooldown(Oven* pOven);

#endif

