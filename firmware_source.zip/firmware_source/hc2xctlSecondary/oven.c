//*****************************************************************************
// Copyright (c) 1999-2014 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2014 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: oven.c
//
// Description: oven logic processing
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Implement Oven_setCurrentDelayedCooldown and Oven_getcurrentDelayedCooldown
// 21-Feb-17  TP   Implement Oven_setBeltStopWhenRailMoving(), Oven_getBeltStopWhenRailMoving(), ver8.0.0.18
//*****************************************************************************
#include "contain.h"
#include "oven.h"
#include "hellerenumerations.h"
#include "typedefdefine.h"
#include "digitio.h"
#include "alarm.h"
#include "timer.h"

#include "../hc2xio/include/hc2xio_exports.h"
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"


extern DbContainer g_dbContainer;

//******************************************************************************
// class Oven_oven 	Constructor
//
// Abstract:
// The oven system parameters and state of operation.
//
// Programmer: Steven Young
// Date: 03/30/1998
//******************************************************************************
void Oven_init(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_init");

	pOven->scanPeriod	= 0;
	pOven->jobNo		= COOLDOWN;
	pOven->noHeatZones	= 0;
	pOven->coolDown	= FALSE;
	pOven->noBelts		= 1;
	pOven->noRails		= 0;
	pOven->eStopSet	= FALSE;
	pOven->jobLoadInProgress	=	FALSE;
	pOven->jobStartupComplete	= FALSE;
	pOven->lowExhaustWarningSent	=	FALSE;
	pOven->demoMode	= FALSE;
	pOven->startLowExhaustTime	= 0;
	pOven->startHighWaterTempTime  = 0;
	pOven->wantResume  = TRUE;
	pOven->scanCounts	= 0;
	pOven->leftToRight	= TRUE;
	pOven->modelNo		= 0;
	pOven->startOverTempTime   = 0;
	pOven->startBlowerFailTime	= 0;
	pOven->redundantOverTempOptionEnabled	= FALSE;
	pOven->blowerFailureCheckEnabled   = FALSE;
	pOven->autoCleanFluxMode	= FALSE;
	pOven->FiveSecondTimerIsRunning = FALSE;
	pOven->startUpWithJob	= FALSE;
	pOven->m_bFailureNotified = FALSE;
	pOven->startPowCooldownFailTime = 0;
	pOven->m_bExhaustWarningsEnabled = TRUE;
	pOven->m_bExhaustAlarmsEnabled = TRUE;
	pOven->m_bSelfAcknowledgeDisabled = FALSE;
	pOven->m_bDisableDevAlarmInStartup = FALSE;
	pOven->m_StartupCompletePlusDelayTime = 0;
	pOven->m_iPowerfailureTime = POWER_FAIL_TIME_10THS;
	pOven->m_bDelayedCooldown = FALSE;
	pOven->m_bCurrentMonitorDelayedCooldown = FALSE;
	pOven->m_bHeaterFailureDelayedCooldown = FALSE;
	pOven->m_dwrdDelayedCooldownTime = 0;
	pOven->m_bCooldownCountOn = FALSE;
	pOven->m_bRequestCooldown = FALSE;
	pOven->m_bStarted = FALSE;
	pOven->m_bSysParamsSet = FALSE;
	pOven->recipeName[0] = '\0';
	pOven->m_dwrCurrentGroup = 1;
	pOven->m_bPendingCooldown = FALSE;

	pOven->lto = FALSE;
	pOven->mbAlarmScanner=FALSE;
	pOven->miAlarmOutput=ODO_NULL;
	pOven->mbAlarmState=TRUE;
}

//******************************************************************************
// Oven_setJob
//
// Abstract:
// A new job can be loaded when:
//		1. the new job no is not the same as the current job no.
//		2. As long as threre are no unacknoledged alarms.
//		3. COOLDOWN can be loaded at any time.


// Programmer: Steven Young
// Date: 4/1/1998
//******************************************************************************
void Oven_setJob(Oven* pOven, unsigned int nJobNo)
{
	PARAM_CHECK( pOven, "Oven_setJob");
		
	if ( nJobNo != pOven->jobNo )	// when these are not equal the job has changed.
	{


		pOven->m_bRequestCooldown = FALSE;
		pOven->jobStartupComplete	= FALSE; 
		Oven_initiateCooldownCountdown(pOven, FALSE); //Clear any impending cooldown launch
		if(nJobNo)//if not loading cooldown, clear warnings
		{
			AlarmQueue_clearAllWarnings(&(g_dbContainer.alarmQueueDb));
		}
		if ( nJobNo != COOLDOWN && AlarmQueue_alarmsPresent(&(g_dbContainer.alarmQueueDb)) == FALSE )
		{
			pOven->tempJobNo = nJobNo;
			pOven->m_bFailureNotified = FALSE;
		}	

		if (  nJobNo == COOLDOWN )
		{
			pOven->jobNo = pOven->tempJobNo = nJobNo;
		}
	}
}





//******************************************************************************
// Oven_SetJobNewJobLoadedOutput
//
// Abstract:
// 	This member function to sets an output for  a period of five seconds on the 
//  occurence of a new job being loaded. This out put can be found at
//  the define ODO_NEW_JOB_FIVESEC
//
// Programmer: Joe Fortier
// Date: 01/25/01
//
//******************************************************************************
void Oven_SetJobNewJobLoadedOutput(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_SetJobNewJobLoadedOutput");
	
	if (Oven_isJobLoadInProgress(pOven) && !pOven->FiveSecondTimerIsRunning)  //
	{
		pOven->FiveSecondStartTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
		pOven->FiveSecondTimerIsRunning = TRUE;	
	}
	else
	{
		if(pOven->FiveSecondTimerIsRunning)
		{
			if(pOven->jobNo != COOLDOWN)
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = TRUE;
			pOven->FiveSecondCurrentTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
			if ((pOven->FiveSecondCurrentTime - pOven->FiveSecondStartTime) >= FIVE_SECOND_DELAY)
			{
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = FALSE;
				pOven->FiveSecondTimerIsRunning = FALSE;
			}
		}
	}
}

//******************************************************************************
// Oven_process
//
// Abstract:
// 	The function to call all functions related to the oven process.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Oven_process(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_process");
	if(pOven->wantResume == FALSE) //job load has not completed, timeout?
	{
	   if((Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer))-pOven->m_dwrdLoadTime) > 150)
		{
	      Oven_setJob(pOven, COOLDOWN);
		}
				
	}
	// PROCESS E-STOP
//slave has no digital inputs, should not alarm
	Oven_checkJobLoad(pOven);
	if( !pOven->m_bFiveSecondDisabled)//need output for second audible alarm in some ovens
	{
		Oven_SetJobNewJobLoadedOutput(pOven); // added 1/25/01 jwf
	}
	pOven->scanCounts++;
	if(pOven->jobNo == COOLDOWN)
	{
		pOven->m_bPendingCooldown=FALSE;
	}
	if(pOven->jobNo != COOLDOWN)
	{
		if(pOven->m_bPendingCooldown==TRUE)
		{
			if(Oven_LaunchCooldown(pOven)==TRUE)
			{
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_CLEARED_COOLDOWN, 0);
				pOven->m_bPendingCooldown = FALSE;				
				pOven->m_bRequestCooldown = TRUE;
			}
		}
		if(pOven->m_bCooldownCountOn == TRUE)
		{
			if((pOven->m_dwrdCooldownStartTime + (pOven->m_dwrdDelayedCooldownTime * 600)) < Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)))
			{
				pOven->m_bCooldownCountOn = FALSE;
				Oven_setJob(pOven, COOLDOWN);
				pOven->m_bRequestCooldown = TRUE;
			}
		}
	}

	if ( pOven->jobNo != COOLDOWN && pOven->jobLoadInProgress == FALSE )
	{
		*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_CONVEYOR_BLOWER) = TRUE;

	}
	else 
	{
		if(pOven->jobNo == COOLDOWN)
		{
			pOven->m_bPendingCooldown = FALSE;
		}
		if ( Oven_isCOOLDOWNcomplete(pOven) == TRUE )
		{
			*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_CONVEYOR_BLOWER) = FALSE;
			*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
			*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = FALSE;
		}
	}


}




void Oven_pause(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_pause");
	pOven->m_dwrdLoadTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	pOven->jobLoadInProgress = TRUE;
	pOven->wantResume = FALSE;
	pOven->scanCounts = 0;

}

void Oven_resume(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_resume");
	pOven->wantResume = TRUE;
	Oven_setStartWithJob(pOven, TRUE );
	pOven->m_bStarted = TRUE;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Oven_checkJobLoad


	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void Oven_checkJobLoad(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkJobLoad");
	if ( pOven->wantResume == TRUE && pOven->scanCounts >= 2 )
	{
		//This will tell the alarmqueue not to register the TIMER_LOSS
		//alarm once external timer tick is stable.
		if(!AlarmQueue_getProcessLoopStarted(&(g_dbContainer.alarmQueueDb)))
		{
			AlarmQueue_setProcessLoopStarted(&(g_dbContainer.alarmQueueDb), TRUE);
		}

		pOven->jobNo = pOven->tempJobNo;
		pOven->jobLoadInProgress = FALSE;
	}
}



/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	Oven_setModelNo

				sets the oven model

	GLOBALS:
	RETURNS:	bool.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL Oven_setModelNo(Oven* pOven, DWORD model_no )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setModelNo", 0);

	if ( model_no < eADD_ABOVE_OVENMODEL )
	{
		pOven->modelNo = model_no;
		status = TRUE;
	}
	else
	{
		printk("error in secondary setModelNo, value %d out of range %d\n", model_no, eADD_ABOVE_OVENMODEL);
	}

	return status;
}

DWORD Oven_getModelNo(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getModelNo", 0);
	return pOven->modelNo;
}


void Oven_setDirection(Oven* pOven, BOOL standardDirection )
{
	// TRUE = left to right - the standard direction.
	// FALSE = right to left - the non-standard direction.

	//printk( "Oven_setDirection( %d )\n", standardDirection );

	PARAM_CHECK( pOven, "Oven_setDirection");
	pOven->leftToRight = standardDirection;
#if 0 // fjn -- not relevant to secondary HC-2
	if ( pOven->modelNo == e2060_OVENMODELS )
	{
		DbContainer_configureIO( &g_dbContainer );
	}
#endif
}

BOOL Oven_getDirection(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDirection", 0);
	return pOven->leftToRight;
}

BOOL Oven_ExternalCheckForPowerFailure(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_ExternalCheckForPowerFailure", 0);
	return 	 pOven->m_bIsPowerOKForWarningTime;
}

//////////////////////////////////////////////////////////////
//
//void Oven_initiateCooldownCountdown(bInit)
//
//
//////////////////////////////////////////////////////////////
void Oven_initiateCooldownCountdown(Oven* pOven, BOOL bInit)
{
	PARAM_CHECK( pOven, "Oven_initiateCooldownCountdown");
	if(bInit) //start countdown
	{
		if(!pOven->m_dwrdDelayedCooldownTime)
		{
			//printk("line 1078 oven\n");
			Oven_setJob(pOven, COOLDOWN);
		}
		else
		{
			//printk("cooldown count on line 1018 %d\n", pOven->m_bCooldownCountOn);
			if(!pOven->m_bCooldownCountOn)
			{
				pOven->m_bRequestCooldown = FALSE;
				pOven->m_dwrdCooldownStartTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
				pOven->m_bCooldownCountOn = TRUE;
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, COOLDOWN_COUNTDOWN_STARTED, 0);
			}
		}
	}
	else //terminate countdown
	{
//		printk("cooldown count on line 1030 %d\n", pOven->m_bCooldownCountOn);
		if(pOven->m_bCooldownCountOn)
			AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, COOLDOWN_COUNTDOWN_ABORTED, 0);
		pOven->m_bCooldownCountOn = FALSE;
	}

}

void Oven_setDelayedCooldown(Oven* pOven, BOOL cooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setDelayedCooldown");
	pOven->m_bDelayedCooldown = cooldownDelayed;
}
		
BOOL Oven_getDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDelayedCooldown", 0);
	return pOven->m_bDelayedCooldown;
}

void Oven_setCurrentMonitorDelayedCooldown(Oven* pOven, BOOL currentMonitorCooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setCurrentMonitorDelayedCooldown");
	pOven->m_bCurrentMonitorDelayedCooldown = currentMonitorCooldownDelayed;
}
		
BOOL Oven_getCurrentMonitorDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getCurrentMonitorDelayedCooldown", 0);
	return pOven->m_bCurrentDelayedCooldown;
}

void Oven_setHeaterFailureDelayedCooldown(Oven* pOven, BOOL heaterFailureCooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setHeaterFailureDelayedCooldown");
	pOven->m_bHeaterFailureDelayedCooldown = heaterFailureCooldownDelayed;
}
		
BOOL Oven_getHeaterFailureDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getHeaterFailureDelayedCooldown", 0);
	return pOven->m_bHeaterFailureDelayedCooldown;
}

void Oven_setDelayedCooldownTime(Oven* pOven, int iTime)
{
	PARAM_CHECK( pOven, "Nitrogen_setCoolRunTime");
	pOven->m_dwrdDelayedCooldownTime = (DWORD)iTime;
}

BOOL Oven_getAppCoolFlag(Oven* pOven)
{
	BOOL bReturnFlag = pOven->m_bRequestCooldown;
	
	if(pOven->jobLoadInProgress)//dont trigger cooldown when a load is in process
		bReturnFlag=FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setDelayedCooldownTime", 0);
//	printk("app flag %d\n", bReturnFlag);
//	pOven->m_bRequestCooldown = FALSE;
	return bReturnFlag;
}
void OVEN_ClearCN(Oven* pOven)
{
//	printk("ClearCN\n");
	pOven->m_bRequestCooldown =FALSE;
}

BOOL Oven_isEStopSet(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_isEStopSet", 0);
	return pOven->eStopSet; 
}

UINT Oven_getNoBelts(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getNoBelts", 0);
	return pOven->noBelts; 
}

void Oven_SetDemoMode(Oven* pOven, BOOL demoModeState) 
{
	PARAM_CHECK( pOven, "Oven_SetDemoMode");
	pOven->demoMode = demoModeState; 

}

BOOL Oven_getDemoMode(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDemoMode", 0);
	return pOven->demoMode; 
}

const char* const Oven_getName(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getName", 0);
	return pOven->name; 
}

UINT Oven_getJob(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getJob", 0);
	return pOven->jobNo; 
}		

BOOL Oven_isJobStartupComplete(Oven* pOven)		
{
	PARAM_CHECK_RETURN( pOven, "Oven_isJobStartupComplete", 0);
	return pOven->jobStartupComplete; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setJobStartupComplete
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setJobStartupComplete(Oven* pOven, BOOL jobStartupState /*= TRUE*/ )	
{
	PARAM_CHECK( pOven, "Oven_setJobStartupComplete");
	pOven->jobStartupComplete = jobStartupState; 
}

BOOL Oven_isJobLoadInProgress(Oven* pOven)	
{
	PARAM_CHECK_RETURN( pOven, "Oven_isJobLoadInProgress", 0);
	return pOven->jobLoadInProgress; 
}

void Oven_setCOOLDOWNachieved (Oven* pOven, BOOL atCoolDown )
{ 
	PARAM_CHECK( pOven, "Oven_setCOOLDOWNachieved");
	pOven->COOLDOWNachievedFlag = atCoolDown;

} 		

BOOL Oven_isCOOLDOWNcomplete(Oven* pOven)	
{
	PARAM_CHECK_RETURN( pOven, "Oven_isCOOLDOWNcomplete", 0);
	return  pOven->COOLDOWNachievedFlag; 
}

BOOL Oven_getStartUpWithJob(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getStartUpWithJob", 0);
	return pOven->startUpWithJob; 
}

void Oven_setStartWithJob(Oven* pOven, BOOL jobState /*= FALSE*/ )
{
	PARAM_CHECK( pOven, "Oven_setStartWithJob");
	pOven->startUpWithJob = jobState; 

}

void Oven_setRedundantOverTempOption(Oven* pOven, BOOL option /*= TRUE*/ )
{
	PARAM_CHECK( pOven, "Oven_setRedundantOverTempOption");
	pOven->redundantOverTempOptionEnabled = option; 
}

void Oven_setLTOption(Oven* pOven, BOOL option /*= TRUE*/ ) 
{
	PARAM_CHECK( pOven, "Oven_setLTOption");
	pOven->lto = option; 
}

BOOL Oven_getLTOption(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getLTOption", 0);
	return pOven->lto; 
}

void Oven_setBlowerFailureOption(Oven* pOven, BOOL option /*= TRUE*/)
{
	PARAM_CHECK( pOven, "Oven_setBlowerFailureOption");
	pOven->blowerFailureCheckEnabled = option; 
}

BOOL Oven_getBlowerFailureOption(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getBlowerFailureOption", 0);
	return pOven->blowerFailureCheckEnabled;
}

void Oven_setAutoCleanFlux(Oven* pOven, BOOL autoCleanMode /*= TRUE*/) 
{
	PARAM_CHECK( pOven, "Oven_setAutoCleanFlux");
	pOven->autoCleanFluxMode = autoCleanMode; 
}

BOOL Oven_getAutoCleanFlux(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getAutoCleanFlux", 0);
	return pOven->autoCleanFluxMode; 
}



void Oven_setAsBoardTypeA(Oven* pOven, BOOL bType)
{
	PARAM_CHECK( pOven, "Oven_setAsBoardTypeA");
	pOven->m_bTypeA = bType;
	

}

BOOL Oven_getIsBoardTypeA(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsBoardTypeA", 0);
	return pOven->m_bTypeA;
}


void Oven_disableAutoAcknowledge(Oven* pOven, BOOL bEntered)
{
	PARAM_CHECK( pOven, "Oven_disableAutoAcknowledge");
	pOven->m_bSelfAcknowledgeDisabled = bEntered;
}

BOOL Oven_getIsAutoAcknowledgedDisabled(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsAutoAcknowledgedDisabled", 0);
	return pOven->m_bSelfAcknowledgeDisabled;
}

void Oven_disableDevAlarmInStartup(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_disableDevAlarmInStartup");
	pOven->m_bDisableDevAlarmInStartup = bDisabled;
}

BOOL Oven_getIsDevAlarmInStartupDisabled(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsDevAlarmInStartupDisabled", 0);
	return pOven->m_bDisableDevAlarmInStartup;
}

void Oven_setStartupCompletePlusDelay(Oven* pOven, int iTimeInSec)
{
	PARAM_CHECK( pOven, "Oven_setStartupCompletePlusDelay");
	pOven->m_StartupCompletePlusDelayTime = (DWORD)(iTimeInSec * 10);  //Time in 10th of seconds
}

DWORD Oven_getStartupCompletePlusDelayTime(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getStartupCompletePlusDelayTime", 0);
	return pOven->m_StartupCompletePlusDelayTime;
}

void Oven_setFiveSecondDisable(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_setFiveSecondDisable");
	pOven->m_bFiveSecondDisabled = bDisabled;
}

BOOL Oven_getFiveSecondDisable(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getFiveSecondDisable", 0);
	return pOven->m_bFiveSecondDisabled;
}

DWORD Oven_getTempJobNo(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getTempJobNo", 0);

	
	return pOven->tempJobNo;
}

void Oven_setAppFlag(Oven* pOven, BOOL bWeNeedCooldown)
{
	PARAM_CHECK( pOven, "Oven_setAppFlag");
	pOven->m_bRequestCooldown = bWeNeedCooldown;
}

BOOL Oven_cooldownModePending(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_cooldownModePending", 0);
	return pOven->m_bCooldownCountOn;
}

BOOL Oven_returnOvenProgrammed(Oven * pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_returnOvenProgrammed", 0);
	return pOven->m_bStarted;
}


void Oven_SetSys(Oven * pOven, int iStarted)
{
	pOven->m_bSysParamsSet = iStarted;
}

DWORD Oven_getStartupGroup(Oven* pOven)
{
	return pOven->m_dwrCurrentGroup;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_LaunchCooldown
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_LaunchCooldown(Oven* pOven)
{
	Oven_setJob(pOven, COOLDOWN);
	AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_CLEARED_COOLDOWN, 0);

	return TRUE;
}

void Oven_requestCooldown(Oven* pOven)
{
	BOOL bCooldownAlreadyPending = pOven->m_bPendingCooldown;
		
	pOven->m_bPendingCooldown = !Oven_LaunchCooldown(pOven);
	if((pOven->m_bPendingCooldown == TRUE) && (bCooldownAlreadyPending!=TRUE))//no need to inform gui if cooldown already pending
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_COOLDOWN_WAIT, 0);
	}
	else if(pOven->m_bPendingCooldown ==FALSE)//TO INFORM GUI OF COOLDOWN
	{
		pOven->m_bRequestCooldown=TRUE;
	}
}




