/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/
#include <stdio.h>
#include "contain.h"

DbContainer g_dbContainer;

int main()
{
	DbContainer_init(&g_dbContainer, NULL);
	return 0;
}

