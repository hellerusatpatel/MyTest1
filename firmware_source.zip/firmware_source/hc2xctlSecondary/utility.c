/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#include "utility.h"

DWORD differenceWithRollover( DWORD  newValue, DWORD prevValue )
{
   DWORD  absDiff;
                                                                                
   if ( (DWORD)newValue < (DWORD)prevValue )
   {
      absDiff = newValue + ~prevValue+1;
   }
   else
   {
      absDiff = newValue - prevValue;
   }
                                                                                
   return absDiff;
}

