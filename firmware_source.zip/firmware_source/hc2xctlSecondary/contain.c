/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// contain.cpp

#include "contain.h"
#include "xpdriverdevice.h"

//**********************************************************************
// Class DbContain::DbContain
//
// Constructor
//
// Abstract:
// To hold all the databases in one object that can be passed to the GUI
//
//
// Programmer: Steven Young
// Date: 03/09/98
//
// Revision History:
//	03/09/98 Created					SDY
//**********************************************************************
void DbContainer_init(DbContainer* pDbContainer)
{
	Timer_init(&(pDbContainer->elapseTimer));
	DIN_init(&(pDbContainer->digitalInDb));
	DOUT_init(&(pDbContainer->digitalOutDb));
	ANALOGIN_init(&(pDbContainer->analogInDb));
	ANALOGOUT_init(&(pDbContainer->analogOutDb));	

	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_COILS_MESSAGE, 1, 0, 56);
	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_DIGITAL_IN_MESSAGE, 1, 0, 64);
	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_ANALOG_OUT_MESSAGE, 1, 0, 32);
	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_ANALOG_IN_MESSAGE, 1, 0, 60);
	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), WRITE_DIGITAL_OUT_MESSAGE, 1, 0, 56);
	Hc1xComm_addMessage(&(pDbContainer->hc1xComm), WRITE_ANALOG_OUT_MESSAGE, 1, 0, 32);
}
