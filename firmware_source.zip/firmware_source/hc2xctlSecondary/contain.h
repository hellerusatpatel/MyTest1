/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// contain.h
#ifndef __DBCONTAINER_H__
#define __DBCONTAINER_H__

#include "hc1xcomm.h"
#include "digitio.h"
#include "error.h"
#include "timer.h"

//#include "blackBox.h"
//**********************************************************************
// Programmer : Steven Young
//	Date: 02/03/1998
//
// Abstract:
//	The DbContain, database container, is a class to contain all of the database
// objects and to allow for a method to pass an address of this class to the
// windows server application. This removes any requirements of having to know
// how the information is put in memory by the application.
//**********************************************************************

typedef struct _DbContainer_
{
	Timer				elapseTimer;
	Hc1xComm			hc1xComm;
	DIN 				digitalInDb;
	DOUT 				digitalOutDb;
	ANALOGIN 	    		analogInDb;
	ANALOGOUT 			analogOutDb;

	unsigned   long			m_jiffies;

} DbContainer;

void DbContainer_init(DbContainer* pDbc );

#endif

