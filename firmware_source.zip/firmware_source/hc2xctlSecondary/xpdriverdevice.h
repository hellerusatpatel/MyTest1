//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: xpdriverdevice.h
//
// Description: source code for interface object
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 14-Jan-15  FJN  Declare IOCTL_GATHER_TDM_EEPROM_Handler, IOCTL_SET_TDM_EEPROM_Handler and IOCTL_PROGRAM_TDM_HANDLER
//*****************************************************************************
#ifndef __XpDriverDevice_h__
#define __XpDriverDevice_h__

#include "contain.h"
#include "schedule.h"
#include "typedefdefine.h"	// Added by ClassView

//10 ms timeout for backup schedule production, note that the dpc will not be this granular on some systems
#define EMERGENCY_TIME -100000
//1 second timeout value in 100 NANO second units (1 second = 1,000,000,000 nanoSeconds
#define COMM_TIMEOUT -10000000/*-30000000/*/

#define IRP_MJ_SHUTDOWN		0x10

/////////////////////////////////////////////////////////////
//
// KIrp
//
/////////////////////////////////////////////////////////////

typedef struct _KIrp_
{
	unsigned int m_ioctlCode;

	int m_inputBufferSize;
	int m_outputBufferSize;
	unsigned int m_information;

	char m_ioctlBuffer[KIRP_IOCTL_BUFFER_SIZE];
} KIrp;

/////////////////////////////////////////////////////////////
//
// XpDriverDevice
//
/////////////////////////////////////////////////////////////

typedef struct _XpDriverDevice_
{
	BOOL m_bTimerFailWarningSent;
	BOOL m_bMonitorMode;
	DWORD m_alarm_id;
	ULONG				m_Unit;
	BOOL				m_bOvenIsPaused;
	BOOL	m_bOvenStarted;

	DbContainer			m_Container;
	Scheduler			m_Scheduler;
	int m_bOvenControlled;

} XpDriverDevice;

void XpDriverDevice_init(XpDriverDevice* pXpDriverDevice, ULONG Unit/*=0*/);
NTSTATUS TRANSFER_TABLE_PROCESS_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS XpDriverDevice_DeviceControl(XpDriverDevice* pXpDriverDevice, KIrp* I);

NTSTATUS XPDRIVER_IOCTL_800_Handler(KIrp* I);
NTSTATUS XPDRIVER_IOCTL_801_Handler(KIrp* I);

NTSTATUS ANALOGIN_getValue_Handler(KIrp* I);
NTSTATUS ANALOGIN_readProfileOffset_Handler(KIrp* I);
NTSTATUS ANALOGIN_GetAnalogInVal_Handler(KIrp* I);
NTSTATUS ANALOGIN_GetStoredOffset_Handler(KIrp* I);
NTSTATUS ANALOGIN_SetOffsetValue_Handler(KIrp* I);			
NTSTATUS ANALOGIN_GetInputStyle_Handler(KIrp* I);
NTSTATUS ANALOGIN_SetInputStyle_Handler(KIrp* I);	

NTSTATUS ANALOGOUT_getValue_Handler(KIrp* I);
NTSTATUS ANALOGOUT_setValue_Handler(KIrp* I);

NTSTATUS DIGITALIN_getValue_Handler(KIrp* I);
NTSTATUS DIGITALIN_getHistBufferIndex_Handler(KIrp* I);
NTSTATUS DIGITALIN_getHistBuffer_Handler(KIrp* I);

NTSTATUS DIGITALOUT_getValue_Handler(KIrp* I);
NTSTATUS DIGITALOUT_setValue_Handler(KIrp* I);

NTSTATUS IOCTL_getTimerLoss_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_SetMonitorMode_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_GET_TICK_FREQUENCY_HANDLER(KIrp* I);
NTSTATUS IOCTL_CONTROL_HAULTED_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_REQUEST_MONITOR_MODE_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_CONTROL_STARTED_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_TEST_WATCHDOG_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_ACTIVATE_MODBUS_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_GATHER_TDM_EEPROM_Handler(KIrp* I);
NTSTATUS IOCTL_SET_TDM_EEPROM_Handler(KIrp* I);
NTSTATUS IOCTL_PROGRAM_TDM_Handler(KIrp* I);

#endif		// __XpDriverDevice_h__
