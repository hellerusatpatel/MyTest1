//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: digitio.c
//
// Description: digital IO processing
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 20-Jan-15  FJN  Modify ANALOGIN_process to detect TDM failures
// 05-Feb-15  FJN  Modify ANALOGIN_process to detect slave timeout
// 05-Feb-15  FJN  Remove vestigial iNoSlaveDataCount from ANALOGIN_init
//*****************************************************************************
#include <memory.h>
#include "contain.h"
#include "hc1xcomm.h"
#include "digitio.h"

#include "io_digitio.h"
#include "hc2xio_exports.h"

extern DbContainer g_dbContainer;
int iLevel2PathTest;

int TDM_versionError(int which);
int TDM_crcError(int which);

//******************************************************************************
// class DIN::DIN
//
// Abstract:
// The actual values of the Digital Inputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 02/24/1998
//******************************************************************************
void DIN_init(DIN* pDin)
{
	PARAM_CHECK( pDin, "DIN_init");
	pDin->dummy = FALSE;
	memset(pDin->dinputs,0,sizeof(pDin->dinputs));
	pDin->iBuffPoint = 0;
	iLevel2PathTest = 0;
}

//******************************************************************************
// DIN::operator[]
//
// Abstract:
//	Return the reference to the DIN object for access to READING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
BOOL* DIN_GetAt(DIN* p, UINT index)
{
	IODIN* pDin = getIODIN();	
	PARAM_CHECK_RETURN( pDin, "DIN_GetAt", NULL);

	BOOL* pReturn = NULL;

	if ( index < MaxDin )
	{
		pReturn = &(pDin->dinputs[index]);
	}
	else
	{
		pDin->dummy = FALSE;
		pReturn = &(pDin->dummy);
	}

	return pReturn;
}

//******************************************************************************
// DIN::process
//
// Abstract:
// The function to call all functions that the DIN object needs in order to
// perform its' expected task. Getting Digital IO.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
// Rev History: Set for 7 bytes of data to be received from HC1X.
//
//******************************************************************************
void DIN_process(DIN* pDin)
{
}

//******************************************************************************
// class DOUT::DOUT
//
// Abstract:
// The actual values of the Digital Outputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 02/24/1998
//******************************************************************************
void DOUT_init(DOUT* pDout)
{
	PARAM_CHECK( pDout, "DOUT_int");
	pDout->dummy = FALSE;
	memset( pDout->doutputs,0,sizeof(pDout->doutputs));
}

//******************************************************************************
// DOUT::operator[]
//
// Abstract:
//	Return the reference to the DOUT object for access to WRITING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
BOOL* DOUT_GetAt(DOUT* p, UINT index)
{
	IODOUT* pDout = getIODOUT();
	PARAM_CHECK_RETURN( pDout, "DOUT_GetAt", NULL);

	BOOL* pReturn = NULL;

	if ( index < MaxDout )
	{
		pReturn = &(pDout->doutputs[index]);
	}
	else
	{
		pDout->dummy = FALSE;
		pReturn =  &(pDout->dummy);
	}

	return pReturn;
}

//******************************************************************************
// DOUT::process
//
// Abstract:
// The function to call all functions that the DOUT object needs in order to
// perform its' expected task. Writing Digital IO to the Analogic Device.
// Refer to the Analogic Software Specifications Heller HC1-x 91g00574 Rev A2
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void DOUT_process(DOUT* p)
{
	UINT lcv = 0;
	UINT byteNo = 0;
	IODOUT* pDout = getIODOUT();
	PARAM_CHECK( pDout, "DOUT_process");

	memset( pDout->dOutBits, 0, sizeof( pDout->dOutBits ));

	for ( lcv = 0; lcv < MaxDout; lcv++ )
	{
		switch ( lcv )
		{  
			case  ODO_RED_LIGHT_TOWER	  :	
			case  ODO_AMBER_LIGHT_TOWER	  : 
			case  ODO_GREEN_LIGHT_TOWER	  :	
			case  ODO_AUDIBLE_ALARM		  : 
			case  ODO_CONVEYOR_BLOWER	  :	
			case  ODO_HEATER_CONTACT	  :	
			case  ODO_1088_DIGITAL_FAN_FLUX_FILTER:
			case  ODO_SMEMA1_ENTRANCE     :
			case  ODO_SMEMA1_EXIT	      :	
			case  ODO_RAIL1_ENABLE		  :	
			case  ODO_RAIL1_DIRECTION	  :	
			case  ODO_RAIL2_ENABLE		  :	
			case  ODO_RAIL2_DIRECTION	  :	
			case  ODO_AUTOLUBE_SOLENOID_1 :	
			case  ODO_NITROGEN_ON		  :	
			case  ODO_SMEMA2_ENTRANCE	  :
			case  ODO_SMEMA2_EXIT		  :	
			case  ODO_RAIL3_ENABLE		  :	
			case  ODO_RAIL3_DIRECTION	  :	
			case  ODO_RAIL4_ENABLE		  :	
			case  ODO_RAIL4_DIRECTION	  :	
			case  ODO_CBS_UP			  :	
			case  ODO_NITROGEN_HIGH_FLOW  :	
			case  ODO_NITROGEN_NORMAL_FLOW:
			case  ODO_NITROGEN_LOW_FLOW	  :	
            case  ODO_SMEMA3_ENTRANCE     :  
            case  ODO_SMEMA3_EXIT         :   
            case  ODO_AUTOLUBE_SOLENOID_2 :
			case  ODO_NEW_JOB_FIVESEC	  :	
			case  ODO_CBS_UP2			  :	
			case  ODO_SMEMA4_ENTRANCE	  :
			case  ODO_SMEMA4_EXIT		  :
				byteNo = lcv/8;
				pDout->dOutBits[byteNo] |= (pDout->doutputs[lcv]&0x01)<<(lcv%8);
				break;
		}
	}
	pDout->bUpdated = 1;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DOUT_getOutputArray
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void DOUT_getOutputArray(DOUT* p, UCHAR** ppDigitalOut, UCHAR* pSize)
{
	IODOUT* pDout = getIODOUT();
	PARAM_CHECK( pDout, "DOUT_getOutputArray");

	DOUT_process( p );

	if ( pDout )
	{
		*ppDigitalOut = pDout->dOutBits;
		*pSize = sizeof( pDout->dOutBits);
	}
}


//******************************************************************************
// class ANALOGIN::ANALOGIN
//
// Abstract:
// The actual values of the Analog Inputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 03/02/1998
//******************************************************************************
void ANALOGIN_init(ANALOGIN* pANALOGIN)
{
	PARAM_CHECK( pANALOGIN, "ANALOGIN_init");

	pANALOGIN->profileOffset = 0;
	pANALOGIN->dummy = 0;
	pANALOGIN->startOffsetProgramming =0;

	pANALOGIN->recordOffsets = 0;
	pANALOGIN->iSlaveDataTimeout = 0;
	pANALOGIN->m_bAlarmed =0;
	pANALOGIN->miAlarmScanner=0;

	memset(pANALOGIN->offsets, 10, sizeof(pANALOGIN->offsets));
	memset(pANALOGIN->inputStyles, 0, sizeof(pANALOGIN->inputStyles));
	memset(pANALOGIN->recordInputStyles, 0, sizeof(pANALOGIN->recordInputStyles));
	memset(pANALOGIN->analogInputs, 0, sizeof(pANALOGIN->analogInputs));
	memset(pANALOGIN->secondaryAnalogInput, 0, sizeof(pANALOGIN->secondaryAnalogInput));
}

//******************************************************************************
// ANALOGIN::operator[]
//
// Abstract:
//	Return the reference to the ANALOGIN object for access to READING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
WORD* ANALOGIN_GetAt(ANALOGIN* p, UINT index)
{
	IOANALOGIN* pANALOGIN = getIOANALOGIN();
	PARAM_CHECK_RETURN( pANALOGIN, "ANALOGIN_GetAt", NULL);

	WORD* pReturn = NULL;
	
	if ( index < (MaxAnalogIn*2) )
	{
		pReturn = &(pANALOGIN->analogInputs[index]);
	}
	else
	{
		pANALOGIN->dummy = 0;
		pReturn = &(pANALOGIN->dummy);
	}

	return pReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetAtHigh
			
 GLOBALS:
 RETURNS:   WORD*
 SEE ALSO:
------------------------------------------------------------------------*/
WORD* ANALOGIN_GetAtHigh(ANALOGIN* p, UINT index)
{
	IOANALOGIN* pANALOGIN = getIOANALOGIN();
	PARAM_CHECK_RETURN( pANALOGIN, "ANALOGIN_GetAtHigh", NULL);

	WORD* pReturn = NULL;

	if ( (index >= MaxAnalogIn)&&(index<(MaxAnalogIn*2)) )
	{
		pReturn = &(pANALOGIN->analogInputs[index]);
	}
	else if(index < (MaxAnalogIn * 4)) //secondary slave AIs first 60 regular AI, next 60 modbus
	{
		pReturn = &(p->secondaryAnalogInput[index-(MaxAnalogIn*2)]);
	}
	else
	{
		pANALOGIN->dummy = 0;
		pReturn = &(pANALOGIN->dummy);
	}

	return pReturn;
}
//******************************************************************************
// ANALOGIN::process
//
// Abstract:
// The function to call all functions that the ANALOGIN object needs in order to
// perform its' expected task. Reading analog IO from the Analogic Device.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void ANALOGIN_process(ANALOGIN* pANALOGIN)
{
	IOANALOGIN* pIOANALOGIN = getIOANALOGIN();
	pIOANALOGIN->analogInputs[TDM_0_GND0] = 0;
	if (TDM_versionError(0))
		pIOANALOGIN->analogInputs[TDM_0_GND0] |= TDM0_VERSION_ERROR;
	if (TDM_crcError(0))
		pIOANALOGIN->analogInputs[TDM_0_GND0] |= TDM0_CRC_ERROR;
	if (TDM_versionError(1))
		pIOANALOGIN->analogInputs[TDM_0_GND0] |= TDM1_VERSION_ERROR;
	if (TDM_crcError(1))
		pIOANALOGIN->analogInputs[TDM_0_GND0] |= TDM1_CRC_ERROR;
	if (pANALOGIN->iSlaveDataTimeout > 0 &&
		pIOANALOGIN->iNoSlaveDataCount >= pANALOGIN->iSlaveDataTimeout)
		pIOANALOGIN->analogInputs[TDM_0_GND0] |= HC2_MONITOR_ERROR;
#if 0
	pANALOGIN->analogInputs[TDM_0_GND0] = 0;
	if (TDM_versionError(0))
		pANALOGIN->analogInputs[TDM_0_GND0] |= 1;
	if (TDM_crcError(0))
		pANALOGIN->analogInputs[TDM_0_GND0] |= 2;
	if (TDM_versionError(1))
		pANALOGIN->analogInputs[TDM_0_GND0] |= 4;
	if (TDM_crcError(1))
		pANALOGIN->analogInputs[TDM_0_GND0] |= 8;

	pANALOGIN->secondaryAnalogInput[TDM_0_GND0] = 0;
	if (TDM_versionError(0))
		pANALOGIN->secondaryAnalogInput[TDM_0_GND0] |= 1;
	if (TDM_crcError(0))
		pANALOGIN->secondaryAnalogInput[TDM_0_GND0] |= 2;
	if (TDM_versionError(1))
		pANALOGIN->secondaryAnalogInput[TDM_0_GND0] |= 4;
	if (TDM_crcError(1))
		pANALOGIN->secondaryAnalogInput[TDM_0_GND0] |= 8;

	printk("ANALOGIN_process TDM_0_GND0 %u\n", pANALOGIN->analogInputs[TDM_0_GND0]);
#endif
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_setProfileOffset
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void ANALOGIN_setProfileOffset(ANALOGIN* p, WORD newProfileOffset) 
{
	IOANALOGIN* pIn = getIOANALOGIN();
	PARAM_CHECK( pIn, "ANALOGIN_setProfileOffset");
	pIn->profileOffset = newProfileOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_ReadProfileOffset
			
 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD ANALOGIN_ReadProfileOffset(ANALOGIN* p)
{
	IOANALOGIN* pIn = getIOANALOGIN();
	PARAM_CHECK_RETURN( pIn, "ANALOGIN_ReadProfileOffset", 0);
	return pIn->profileOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetOffsetAt
			
 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD ANALOGIN_GetOffsetAt(ANALOGIN* pIn, UINT index)
{
	IOANALOGIN* pInL = getIOANALOGIN();
	return pInL->offsets[index];
}

///////////////////////////////////////////////////////////////////////////////////////////
//
//ANALOGIN_SetOff\nsetAt
//
//Returns the internal flag that is read by the io driver to indicate that we should record.
//This will be set when the last viable offset is sent (AI_FREE_L2SR) to minimize eeprom access
//
///////////////////////////////////////////////////////////////////////////////////////////
BOOL ANALOGIN_SetOffsetAt(ANALOGIN* pIn, UINT index, WORD offsetValue)
{
	IOANALOGIN* pInL = getIOANALOGIN();

	BOOL bReturn = FALSE;

	pInL->startOffsetProgramming =1;
	if ( index < MaxAnalogIn )
	{
		pInL->offsets[index] = offsetValue;
		if(index == AI_FREE_L2SR)
		{
			pInL->recordOffsets = 1;
			bReturn = TRUE;
		}
	}

	return bReturn;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetInputStyleAt
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD ANALOGIN_GetInputStyleAt(ANALOGIN* pIn, UINT index)
{
	IOANALOGIN* pInL = getIOANALOGIN();

	DWORD dwReturn = 0;

	if(index < MaxAnalogIn)
	{
		dwReturn = pInL->inputStyles[index];
	}
	else
	{
		dwReturn = 0;
	}

	return dwReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_SetInputStyleAt
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL ANALOGIN_SetInputStyleAt(ANALOGIN* pIn, UINT index, UINT iType)
{
	IOANALOGIN* pInL = getIOANALOGIN();

	BOOL bReturn = FALSE;

	if ( index < MaxAnalogIn )
	{
		pInL->inputStyles[index] = iType;
		pInL->recordInputStyles[index] = TRUE;
		bReturn = TRUE;
	}
	return bReturn;
}

//******************************************************************************
// class ANALOGOUT::ANALOGOUT
//
// Abstract:
// The actual values of the Analog Outputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 03/02/1998
//******************************************************************************
void ANALOGOUT_init(ANALOGOUT* pOut)
{
	PARAM_CHECK( pOut, "ANALOGOUT_init");

	pOut->dummy = 0;

	memset(pOut->analogOutputs, 0, sizeof(pOut->analogOutputs));
}

//******************************************************************************
// ANALOGOUT:operator[]
//
// Abstract:
//	Return the reference to the ANALOGOUT object for access to WRITING the IO.
//  Will fail when exclusively locked for use(by fluxheater for now)
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
WORD* ANALOGOUT_GetAt(ANALOGOUT* p, UINT index)
{
	IOANALOGOUT* pOut = getIOANALOGOUT();
	PARAM_CHECK_RETURN( pOut, "ANALOGOUT_GetAt", NULL);

	WORD* pReturn = NULL;

	if ( index < MaxAnalogOut )
	{
		if(!iLevel2PathTest)
		{
			TPO_AddSafeSegment(index, 0x02); 
		}
		pReturn = &(pOut->analogOutputs[index]);
	}
	else
	{
		pOut->dummy = 0;
		pReturn = 	&(pOut->dummy);
	}

	return pReturn;
}

//******************************************************************************
// ANALOGIN::process
//
// Abstract:
// The function to call all functions that the ANALOGIN object needs in order to
// perform its' expected task. Reading analog IO from the Analogic Device.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void ANALOGOUT_process(ANALOGOUT* pOut)
{
	PARAM_CHECK( pOut, "ANALOGOUT_process");
}

//******************************************************************************
// ANALOGOUT::set
//
// Abstract:
// A function to set the output value when the output is locked by the owner, note
// as implemented nothing stops a non-owner from calling this function, which will cause
// havoc
//
// Programmer: Wallace Tree
// Date: 04/12/2004
//
//******************************************************************************
void ANALOGOUT_set(ANALOGOUT* p, UINT index, WORD wValue)
{
	IOANALOGOUT* pOut = getIOANALOGOUT();
	PARAM_CHECK( pOut, "ANALOGOUT_set");

	if(index < MaxAnalogOut)
	{
		pOut->analogOutputs[index] = wValue;
		if(!iLevel2PathTest)
		{
			TPO_AddSafeSegment(index, 0x02);
		}
	}
}

//******************************************************************************
// ANALOGOUT::get
//
// Abstract:
// Will return the value regardless of ownership
//
// Programmer: Wallace Tree
// Date: 04/12/2004
//
//******************************************************************************

WORD ANALOGOUT_get(ANALOGOUT* p, UINT index)
{
	IOANALOGOUT* pOut = getIOANALOGOUT();
	PARAM_CHECK_RETURN( pOut, "ANALOGOUT_get", 0);

	WORD wReturn = 0;

	if ( index < MaxAnalogOut)
	{
		if(!iLevel2PathTest)
		{
			TPO_AddSafeSegment(index, 0x02);
		}
		wReturn = pOut->analogOutputs[index];
	}
	else
	{
		wReturn = 	0;
	}

	return wReturn;
}

void ANALOGOUT_testMPath(UINT iPath, int iTest)
{
	switch(iPath)
	{
	case 1:
		iLevel2PathTest = iTest;
		break;

	default:
		break;
	}
}
