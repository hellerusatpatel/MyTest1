/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "schedule.h"
#include "contain.h"
#include "hc2xwd.h"
#include "../hc2xio/include/hc2xio_exports.h"
#include "xpdriverdevice.h"
#include <linux/poll.h>
#include "transferTable.h"

extern DbContainer g_dbContainer;

//static UCHAR tempbuff[MAX_MESSAGE_LENGTH+1];

void Scheduler_init(Scheduler* pScheduler)
{
	pScheduler->iScheduleLoopCount = 0;
	pScheduler->sequenceNo   =  0;
	pScheduler->timerCount   =  0;	
	pScheduler->scanPeriod   =  100;	// in ms
	pScheduler->goodCOMM     =  0;
	pScheduler->consecutiveNoReadScans = 0;
	pScheduler->elapsedTempZoneTime = 0;
	pScheduler->inProcess	   =  FALSE;   
	pScheduler->commError	   =  0;
	pScheduler->lossOfComm   =  0;
	pScheduler->upDateTPOs   =  FALSE;
	pScheduler->m_bTimerFired = FALSE;
	pScheduler->lSchedulerEx = 0;
	pScheduler->HighPartTime = 0;
	pScheduler->LowPartTime = 0;
	pScheduler->elapsed100Nanos = 0;
	pScheduler->bProcess = 0;
	pScheduler->testDog = 0;
	pScheduler->m_commTime = jiffies;

}

//******************************************************************************
// Scheduler_sequencer
//
// Abstract:
//	The sequencer is triggered on each 1ms interrupt and a counter is incremented
// 	to maintain a sequence position. When the counter reaches the scanPeriod time
// 	it is reset to start processing the loop again.
// 	Interrupts need to be turned off when setting the inProcess flag. Should not
//	need to worry about when setting to FALSE because no other process should
// 	be able to run process functions if inProcess is TRUE.
//  In the event of an overrun, it is assumed that if the HC1X IO Controller does
//	not respond by the following sequence step it will not.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Scheduler_sequencer(Scheduler* pScheduler)
{
	if(!pScheduler->testDog)
	{
		hc2xwd_TickleDog(CTL_DOG);
	}
		
	if(pScheduler->bProcess)
	{
		Timer_add10thSecond(&(g_dbContainer.elapseTimer));

		pScheduler->inProcess = TRUE;
		DIN_process(&(g_dbContainer.digitalInDb));		// put the data in an array for processing.
		DOUT_process(&(g_dbContainer.digitalOutDb));		// put the data in an array for processing.
		ANALOGIN_process(&(g_dbContainer.analogInDb));
		if((jiffies - pScheduler->m_commTime) > TIMEOUT_FOR_SECONDARY_COMM)
		{
			pScheduler->lossOfComm   =  1;
			Scheduler_zeroOutputs();
		}
	}
}




void Scheduler_reset( Scheduler* pScheduler )
{ 
	pScheduler->sequenceNo = 0;	
	pScheduler->inProcess = FALSE; 
	pScheduler->m_bTimerFired = FALSE; 
	pScheduler->LowPartTime = 0; 
	pScheduler->HighPartTime = 0;
	pScheduler->lSchedulerEx = 0;
}

DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler)
{
	return pScheduler->scanPeriod; 
}

void Scheduler_start( Scheduler *pScheduler )
{
	pScheduler->bProcess = 1;	
}

void Scheduler_stop( Scheduler *pScheduler )
{
	pScheduler->bProcess = 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//void Scheduler_switchLoops( Scheduler *pScheduler , int bValue)
//
//This function will set a boolean to be used in the sequence routine.  When true the 
//normal oven controller will be bypassed for direct io control
////////////////////////////////////////////////////////////////////////////////////////////////////
void Scheduler_switchLoops( Scheduler *pScheduler , int bValue)
{
}

////////////////////////////////////////////////////////////////////////////
//Scheduler_testDog
//
//This function will cause the reset of the watchdog to skip, thus the board
//should watchdog due to the scheduler test
////////////////////////////////////////////////////////////////////////////
void Scheduler_testDog(Scheduler *pScheduler)
{
	pScheduler->testDog = 1;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_zeroOutputs

			zeros the write values on comm loss
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_zeroOutputs()
{
	int i = 0;
	for(i = 0; i < MAX_ANALOG_OUTPUTS; i++)
	{
		ANALOGOUT_set(&(g_dbContainer.analogOutDb), i, 0);
	}
	for(i = 0; i < MAX_DIGITAL_OUTPUTS; i++)
	{
		*DOUT_GetAt(&(g_dbContainer.digitalOutDb), i) = FALSE;
	}
}
