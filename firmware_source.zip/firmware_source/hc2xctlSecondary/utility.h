/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

#ifndef UTILITY_H
#define UTILITY_H

#include "typedefdefine.h"

DWORD differenceWithRollover( DWORD  newValue, DWORD prevValue );

#endif
