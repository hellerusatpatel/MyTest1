//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: xpdriverdevice.c
//
// Description: code for interface object
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 14-Jan-15  FJN  Implement IOCTL_GATHER_TDM_EEPROM, IOCTL_SET_TDM_EEPROM and IOCTL_PROGRAM_TDM
//*****************************************************************************
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"
#include "msglog.h"
#include <string.h>
#include <linux/poll.h>

#include "io_digitio.h"
#include "hc2xio_exports.h"
#include "transferTable.h"
#include "typedefdefine.h"


#define _BLOCK_TRACE

DWORD IOANALOGIN_GetMem(IOANALOGIN* pIn, UINT index, UINT tdm);
void IOANALOGIN_ProgramTDM(IOANALOGIN* pIn, UINT index);
void Tdm_writeEEPromBuffer(unsigned int value, unsigned int location);
void testIOWatchDogs(UINT iWhichOne);
BOOL Scheduler_getModbus(void);

extern IOANALOGIN analogInDb;

DbContainer g_dbContainer;

////////////////////////////////////////////////////////////////////////////////
//  XpDriverDevice
//
//	Routine Description:
//		The device constructor is typically responsible for allocating
//		any physical resources that are associated with the device.
//
//	Parameters:
//		Unit - Unit number. This is a number to append to the device's
//			base device name to distinguish multiple units of this
//			device type.
//
//	Return Value:
//		None
//
//	Comments:
//		The device constructor often reads the registry to setup
//		various configurable parameters.

void XpDriverDevice_init(XpDriverDevice* pXpDriverDevice, ULONG Unit)
{
	pXpDriverDevice->m_alarm_id = 0;
	pXpDriverDevice->m_bMonitorMode = FALSE;
	pXpDriverDevice->m_Unit = Unit;
	pXpDriverDevice->m_bOvenIsPaused = FALSE;
	pXpDriverDevice->m_bTimerFailWarningSent = FALSE;
	pXpDriverDevice->m_bOvenStarted = FALSE;
	pXpDriverDevice->m_bOvenControlled = 0;
	DbContainer_init(&g_dbContainer);
	Scheduler_init(&(pXpDriverDevice->m_Scheduler));
	g_dbContainer.m_jiffies = jiffies;
}

////////////////////////////////////////////////////////////////////////
//  XpDriverDevice_DeviceControl
//
//	Routine Description:
//		Handler for IRP_MJ_DEVICE_CONTROL
//
//	Parameters:
//		I - Current IRP
// 
//	Return Value:
//		NTSTATUS - Result code
//
//	Comments:
//		This routine is the first handler for Device Control requests.
//
//		Some function codes may be handled immediately, 
//		while others may be serialized.
//		

NTSTATUS XpDriverDevice_DeviceControl(XpDriverDevice* pXpDriverDevice, KIrp* I) 
{
	NTSTATUS status = STATUS_SUCCESS;

	g_dbContainer.m_jiffies = jiffies;
	
	switch (I->m_ioctlCode)
	{
		case TRANSFER_TABLE_PROCESS:
			status = TRANSFER_TABLE_PROCESS_Handler(pXpDriverDevice, I);
			break;

		case ANALOGIN_getValue:
			status = ANALOGIN_getValue_Handler(I);
			break;

		case ANALOGIN_readProfileOffset:
			status = ANALOGIN_readProfileOffset_Handler(I);
			break;
			
		case ANALOGIN_GetAnalogInVal:
			ANALOGIN_GetAnalogInVal_Handler(I);
			break;
			
		case ANALOGIN_GetStoredOffset:
			ANALOGIN_GetStoredOffset_Handler(I);
			break;
			
		case ANALOGIN_SetOffsetValue:		
			ANALOGIN_SetOffsetValue_Handler(I);			
			break;

		case ANALOGIN_GetInputStyle:
			ANALOGIN_GetInputStyle_Handler(I);
			break;

		case ANALOGIN_SetInputStyle:	
			ANALOGIN_SetInputStyle_Handler(I);	
			break;

		case ANALOGOUT_getValue:
			status = ANALOGOUT_getValue_Handler(I);
			break;

		case ANALOGOUT_setValue:
			status = ANALOGOUT_setValue_Handler(I);
			break;

		case DIGITALIN_getValue:
			status = DIGITALIN_getValue_Handler(I);
			break;	
			
		case DIGITALIN_getHistBufferIndex:
			status = DIGITALIN_getHistBufferIndex_Handler(I);
			break;
			
		case DIGITALIN_getHistBuffer:
			status = DIGITALIN_getHistBuffer_Handler(I);
			break;			
			
		case DIGITALOUT_getValue:
			status = DIGITALOUT_getValue_Handler(I);
			break;

		case DIGITALOUT_setValue:
			status = DIGITALOUT_setValue_Handler(I);
			break;


		case IOCTL_getTimerLoss:
			status = IOCTL_getTimerLoss_Handler(pXpDriverDevice, I);
			break;

		case IOCTL_GET_TICK_FREQUENCY:
			status = IOCTL_GET_TICK_FREQUENCY_HANDLER(I);
			break;
		
		case IOCTL_SetMonitorMode:
			status  = IOCTL_SetMonitorMode_Handler(pXpDriverDevice, I);
			break;

		case IOCTL_TEST_WATCHDOG:
			status = IOCTL_TEST_WATCHDOG_Handler(pXpDriverDevice, I);
			break;

		case IOCTL_ACTIVATE_MODBUS:
			status = IOCTL_ACTIVATE_MODBUS_Handler(pXpDriverDevice,I);
			break;			

		case IOCTL_CONTROL_HAULTED:
			status = IOCTL_CONTROL_HAULTED_Handler(pXpDriverDevice, I);
			break;

		case IOCTL_REQUEST_MONITOR_MODE:
			status = IOCTL_REQUEST_MONITOR_MODE_Handler(pXpDriverDevice, I);
			break;
	
		case IOCTL_CONTROL_STARTED:
			status = IOCTL_CONTROL_STARTED_Handler(pXpDriverDevice, I);
			break;
			
		case IOCTL_GATHER_TDM_EEPROM:
			status = IOCTL_GATHER_TDM_EEPROM_Handler(I);
			break;

		case IOCTL_SET_TDM_EEPROM:
			status = IOCTL_SET_TDM_EEPROM_Handler(I);
			break;

		case IOCTL_PROGRAM_TDM:
			status = IOCTL_PROGRAM_TDM_Handler(I);
			break;

		default:
			// Unrecognized IOCTL request
			printk("bad DeviceControl: m_ioctlCode = %d\n", I->m_ioctlCode);
			printk("%x\n", I->m_ioctlCode);	
			status = STATUS_INVALID_PARAMETER;
			break;
	}

	return status;
}




/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_GET_TICK_FREQUENCY_HANDLER
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_GET_TICK_FREQUENCY_HANDLER(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	I->m_information = sizeof(ULONG);

	return status;
}


////////////////////////////////////////////////////////////////////////
//  ANALOGIN_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected Analogin
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//
//		Output buffer contains:
//			WORD - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGIN_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char* buff = NULL;
	UINT index = 0;
	UINT buffSize = sizeof(UINT);
	WORD retVal = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);

		if(index < (MAX_ANALOG_INPUTS * 2))	
		{
			retVal = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);
		}

		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGIN_readProfileOffset_Handler
//
//	Routine Description:
//		Retreives the profileOffset of the Analogin(s)
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			WORD - profileOffset
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGIN_readProfileOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	char *buff = (char *)I->m_ioctlBuffer;

	WORD retVal = ANALOGIN_ReadProfileOffset(&(g_dbContainer.analogInDb));
	*((WORD *)buff) = retVal;
	I->m_information = sizeof(WORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALIN_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//
//		Output buffer contains:
//			BOOL - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALIN_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		BOOL retVal = *DIN_GetAt(&(g_dbContainer.digitalInDb), index);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALOUT_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into digitalOutDb array.
//
//		Output buffer contains:
//			BOOL - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALOUT_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		BOOL retVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), index);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  IOCTL_getTimerLoss_Handler
//
//	Routine Description:
//		returns TimerLoss from driver.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - Timer Loss
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS IOCTL_getTimerLoss_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

	BOOL bTimerLoss = FALSE;

	bTimerLoss = pXp->m_bTimerFailWarningSent;

	*((BOOL *)buff) = bTimerLoss;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGOUT_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected Analogout
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//
//		Output buffer contains:
//			WORD - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGOUT_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	WORD retVal;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		retVal = ANALOGOUT_get(&(g_dbContainer.analogOutDb), index);
		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALOUT_setValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into digitalOutDb array.
//			BOOL - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALOUT_setValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL bValue = *((BOOL *)(buff+sizeof(UINT)));

		*DOUT_GetAt(&(g_dbContainer.digitalOutDb), index) = bValue;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = 0;
	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  IOCTL_SetMonitorMode_Handler
//
//	Routine Description:
//		Puts the driver into Monitor Mode for ioMonitor input.
//
//Note I have modified the behavior of this function so that it will no longer
//set monitor mode.  Old versions of the ioMonitor will not work by design.  Thi
//function will now return a value indicating if the mode switch is possible
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS IOCTL_SetMonitorMode_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bValue = *((BOOL *)buff);
		
		//if the oven has started we are not allowing monitor mode so outputs will not be set manually by the monitor
		bValue = pXp->m_bOvenStarted;
		*((BOOL*)buff) = bValue;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = sizeof(BOOL);
	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGOUT_setValue_Handler
//
//	Routine Description:
//		Sets the value of the selected Analogout
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//			WORD - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGOUT_setValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(WORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		WORD wValue =*((WORD *)(buff + sizeof(UINT)));

		*ANALOGOUT_GetAt(&(g_dbContainer.analogOutDb), index) = wValue;
		ANALOGOUT_set(&(g_dbContainer.analogOutDb), index, wValue);
		buffSize = 0;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetAnalogInVal_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_GetAnalogInVal_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		WORD retVal = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);
		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetStoredOffset_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_GetStoredOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD retVal;

		if(index<60)
		{
			retVal = ANALOGIN_GetOffsetAt(&(g_dbContainer.analogInDb), index);
		}

		*((DWORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_SetOffsetValue_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_SetOffsetValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT offsetValue= *((UINT *)(buff + sizeof(UINT)));

		BOOL retVal = ANALOGIN_SetOffsetAt(&(g_dbContainer.analogInDb), index, offsetValue);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetInputStyle_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_GetInputStyle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		DWORD retVal = ANALOGIN_GetInputStyleAt(&(g_dbContainer.analogInDb), index);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_SetInputStyle_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_SetInputStyle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT iType= *((UINT *)(buff + sizeof(UINT)));

		BOOL retVal = ANALOGIN_SetInputStyleAt(&(g_dbContainer.analogInDb), index, iType);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DIGITALIN_getHistBufferIndex_Handler
			
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS DIGITALIN_getHistBufferIndex_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UCHAR *buff = (UCHAR *)I->m_ioctlBuffer;

	UINT retVal = 0;
	
	IODIN* pDin = getIODIN();	
	if ( pDin )
	{
		retVal = IODIN_GetBuffPoint(pDin);
	}
	
	*((UINT *)buff) = retVal;

	I->m_information = sizeof(UINT);

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DIGITALIN_getHistBuffer_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS DIGITALIN_getHistBuffer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_BUFFER_TOO_SMALL;
	UINT buffSize = 0;
	UINT i = 0;
	UCHAR *buff = (UCHAR *)I->m_ioctlBuffer;

	if(I->m_inputBufferSize >= 401)
	{
		for( i=0; i<400; i++)
		{
			UCHAR retVal = 2;//DIN_BufferGet(&(g_dbContainer.digitalInDb), i);
			*((UCHAR *)buff) = retVal;
			buff++;
		}
		*buff=' ';

		buffSize = 401;

		status = STATUS_SUCCESS;
	}

	I->m_information = buffSize;

	return status;	
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_CONTROL_HAULTED_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_CONTROL_HAULTED_Handler(XpDriverDevice * xpDriver, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	xpDriver->m_bOvenStarted = 0;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_REQUEST_MONITOR_MODE_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_REQUEST_MONITOR_MODE_Handler(XpDriverDevice *pXp, KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	WORD retVal = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char*)I->m_ioctlBuffer;
		UINT iMonitor = *((UINT* )buff);

		if(pXp->m_bOvenStarted != 0)//oven is running, cannot switch to monitor control
		{
			if(!iMonitor)//we can deactivate monitor mode, although the case should not happen
			{
				Scheduler_switchLoops(&(pXp->m_Scheduler), iMonitor);
			}
			retVal = 0;
			*((WORD*)buff)= retVal;
		}
		else
		{
			Scheduler_switchLoops(&(pXp->m_Scheduler), iMonitor);
			retVal = 1;
			*((WORD*)buff) = retVal;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_CONTROL_STARTED_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_CONTROL_STARTED_Handler(XpDriverDevice * xpDriver, KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
	xpDriver->m_bOvenStarted =1;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_TEST_WATCHDOG_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_TEST_WATCHDOG_Handler(XpDriverDevice* xpDriver, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char*) I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		
		UINT action = *((UINT*)(buff + sizeof(DWORD)));
//the index indicates which watchdog we are testing
		switch(index)
		{
		//The scheduler watchdog
			case 0:
				break;
		
			//io dog	
			case 1:
			//tdm dog
			case 2:
			//tpo dog
			case 3:
				testIOWatchDogs(index);
				break;

			//application dog
			case 4:
				break;

			//control write
			case 6:
				ANALOGOUT_testMPath(1, action);	
			break;
			//memory request
			case 7:
				ANALOGOUT_testMPath(2, action);
				break;
			//buffer copy 
			case 8:
				TPO_testPath(1, action);
				break;

			//output level set
			case 9:
				TPO_testPath(2, action);
				break;
			
			default:
				break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_ACTIVATE_MODBUS_Handler
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_ACTIVATE_MODBUS_Handler(XpDriverDevice* xpDriver, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT bufferSize = sizeof(BOOL);
	if(I->m_inputBufferSize >= bufferSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		BOOL bOn = *((BOOL*)buff);

		Scheduler_setModbus(bOn);
		if(bOn==TRUE)
		{
			g_dbContainer.analogInDb.iSlaveDataTimeout = 150;
		}
		else
		{
			g_dbContainer.analogInDb.iSlaveDataTimeout = 0;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TRANSFER_TABLE_PROCESS_Handler

			processes all the control messages from the primary, builds
			table to report values from secondary.  resets timeout for safestate 
			action
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TRANSFER_TABLE_PROCESS_Handler(XpDriverDevice* pXp, KIrp* I)
{
	PARAM_CHECK_RETURN( pXp, "TRANSFER_TABLE_PROCESS_Handler", STATUS_BUFFER_TOO_SMALL);
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(struct TRANSFER_TABLE);
	BOOL bModbusMaster = FALSE;
	int i = 0;
	WORD* pWord = NULL;
	BOOL bModbusIsOn = FALSE;

	struct SECONDARY_TABLE returnTable;
	memset( &returnTable, 0, sizeof(struct SECONDARY_TABLE) );

	I->m_information = 0;

	if( I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char*) I->m_ioctlBuffer;
		struct TRANSFER_TABLE table = *((struct TRANSFER_TABLE*)buff);

		//
		// configuration tasks
		//

		if( table.configuration.byte1 & CONFIGURATION_BYTE1_SHUTDOWN )
		{
			Scheduler_stop(&(pXp->m_Scheduler));
		}
		else
		{
			if(!pXp->m_Scheduler.bProcess)
			{
				Scheduler_start(&(pXp->m_Scheduler));
			}
		}

		if(table.configuration.byte1 & CONFIGURATION_BYTE1_MODBUS_MASTER)
		{
			bModbusMaster = TRUE;
		}

		bModbusIsOn = Scheduler_getModbus();
		if(bModbusIsOn != bModbusMaster)
		{
			Scheduler_setModbus(bModbusMaster);
			if(bModbusMaster == TRUE)
			{
				g_dbContainer.analogInDb.iSlaveDataTimeout = 150;
			}
			else
			{
				g_dbContainer.analogInDb.iSlaveDataTimeout = 0;
			}
		}

		//
		// value assignment
		//
		for(i = 0; i < MAX_ANALOG_OUTPUTS; i++)
		{
			TPO_AddSafeSegment( i, 0x01);
			ANALOGOUT_set(&(g_dbContainer.analogOutDb), i, table.tablePrimary.tpo[i]);
		}

		for(i = 0; i < MAX_DIGITAL_OUTPUTS; i++)
		{
			*DOUT_GetAt(&(g_dbContainer.digitalOutDb), i) = table.tablePrimary.digOut[i];
		}

		//
		// value read
		//
		returnTable.statusFlags = StatusFlagConfigured;//default to configured

		for(i = 0; i < COUNT_ANALOG_INPUTS; i++)
		{
			pWord = ANALOGIN_GetAt(&(g_dbContainer.analogInDb), i);

			returnTable.analogIn[i] = *pWord;
		}

		if(table.configuration.byte1 & CONFIGURATION_BYTE1_GETTDM)
		{
			for(i = 0; i < MAX_ANALOG_INPUTS; i++)
			{
				returnTable.tdmOffset[i] = ANALOGIN_GetOffsetAt(&(g_dbContainer.analogInDb), i);
			}
			returnTable.statusFlags |= StatusFlagOffsets;
		}

		for(i = 0; i < MAX_DIGITAL_INPUTS; i++)
		{
			returnTable.digIn[i] = *DIN_GetAt(&(g_dbContainer.digitalInDb), i);
		}
		
		pXp->m_Scheduler.m_commTime = jiffies;
		
		if(pXp->m_Scheduler.lossOfComm == 1)
		{
			returnTable.statusFlags |= StatusFlagCommTimeout;
			pXp->m_Scheduler.lossOfComm = 0;
		}

		*((struct SECONDARY_TABLE *)(buff)) = returnTable;

		I->m_information = sizeof(struct SECONDARY_TABLE);
	}
	else
	{
		printk( "TRANSFER_TABLE_PROCESS_Handler: STATUS_BUFFER_TOO_SMALL\n" );
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;
}

NTSTATUS IOCTL_GATHER_TDM_EEPROM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
	UINT index = 0;
	UINT inBuffSize =(sizeof(DWORD)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
		DWORD tdm = *((DWORD *)(buff));
		for(index=0; index<EEPROM_SIZE; index++)
		{
			if(tdm<2)	
			{
				retVal[index] = IOANALOGIN_GetMem(&analogInDb, index, tdm);
		//		printk("index %d, tdm %d, value %x\n", index, tdm, retVal[index]);
			}

			*((DWORD *)(buff+buffSize)) = retVal[index];
			buffSize += sizeof(DWORD);
		}
	}
	I->m_information = buffSize;

	return status;
}

NTSTATUS IOCTL_SET_TDM_EEPROM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
//	UINT buffSize = 0;
//	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
//	UINT index = 0;
	UINT inBuffSize =((sizeof(DWORD)*2)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
//		printk("in xpdriver device loc %d, val %x\n");
		DWORD loc = *((DWORD *)(buff));
		DWORD val = *((DWORD *)(buff + sizeof(DWORD)));
		Tdm_writeEEPromBuffer(val, loc);
	}
	I->m_information = 0;

	return status;
}

NTSTATUS IOCTL_PROGRAM_TDM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
//	UINT buffSize = 0;
//	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
//	UINT index = 0;
	UINT inBuffSize =(sizeof(DWORD)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
		DWORD tdm = *((DWORD *)(buff));
		IOANALOGIN_ProgramTDM((IOANALOGIN*)tdm, 0); // fjn -- v5.5.0.18 source does not show second argument, total mismatch with prototype
//		TDM_commitMapToEEPROM(tdm);
	}
	I->m_information = 0;
	//ANALOGIN_SetOffsetAt(&(g_dbContainer.analogInDb), AI_FREE_L2SR, 0);

	return status;
}
