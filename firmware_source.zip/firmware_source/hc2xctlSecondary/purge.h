/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			purge.h

	Description:	purge custom alarm code

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __PURGE_H__
#define __PURGE_H__

#include "typedefdefine.h"

extern signed char cClearCustomWarning[MAX_CALARMS_BOTH_TYPES];
extern signed char cSetSoundOff[MAX_CALARMS_BOTH_TYPES];
#define NULL_OUTPUT 99
#define NULL_INPUT 98
//******************************************************************************
// class Purge
//
// Abstract:
// Heller needs the ability to trigger a nitrogen flush after the fluxcondensation cycle
//independant of the existing nitrogen settings.  Also the digitial output is variable.
//rather than implementing special case handling within the disabled/enabled nitrogen and 
//special handling for the 14 or so possible digital outputs I have added this class.  By
// calling its process loop after all of the other classes in the scheduler it should have
//effective ownership of the digital output.
//
// Programmer: Wallace Tree
// Date: 06/20/2003
//******************************************************************************

#define SPRAY_CNT  5

typedef struct _Purge_
{
	//private:
	DWORD 				purgeTimeDuration10ths;			// from user interface	
	DWORD				startPurgeTime10ths;
	BOOL 				enabled;					// option is set in set up screen.
	int					m_iDigitalOutput;
	BOOL				m_bCooldownShouldEnableInput;
	BOOL				m_bCycleCommenced;
	UINT				m_iJobNo;
	BOOL				m_bForced;
	BOOL				m_bStateChanged;
	BOOL				m_bOutputOn;
	//autoclean recipe variables
	int				m_shrtLightTowerFilter[MAX_CALARMS];
	int				m_iDigitalRecipeOutput;
	BOOL				m_bSetRecipeOutput;
	BOOL				m_bCondensationGo;
	BOOL				m_bRecipeOptionTrue;
	DWORD 			m_dwrdLastOffTime[MAX_CALARMS];
	DWORD				selfAckAlarmNo[MAX_CALARMS];
	UINT				m_messageIndex[MAX_CALARMS];
	BOOL 				m_bInState[MAX_CALARMS];
	int				m_shrtAlarmType[MAX_CALARMS];
	int				m_shrtDI[MAX_CALARMS];
	int				m_shrtDO[MAX_CALARMS];
	BOOL 				m_bTurnSoundOff;
	BOOL 				m_bAllowAddition[MAX_CALARMS];
	BOOL 				m_bCustomAlarm[MAX_CALARMS];
	DWORD				m_dwrdDetectOnDelay[MAX_CALARMS];
	BOOL				m_bActiveHigh[MAX_CALARMS];
//	BOOL				m_bTurnOffSound;
	BOOL				m_bAudible[MAX_CALARMS];
	BOOL				m_bTwoMotorActive;									
	UINT				m_iTwoMotorOutput;			
	BOOL				m_bTwoMotorValue;		
	BOOL				m_bSprayOn[SPRAY_CNT];
	int				m_shrSprayOutput;
	BOOL				m_bCA3Enabled;
	BOOL				m_bCA3Warning;
	BOOL				m_bCA3Alarm;
	BOOL				m_bCA3Audible;
	BOOL				m_bCA3Dist;
	BOOL				m_bCA3High;
	BOOL				m_bCA3WarningOutputs;
	BOOL				m_bCA3AlarmOutput;
	DWORD				m_dwrdCA3Input;
	DWORD				m_dwrdCA3Output;
	DWORD				m_dwrdCA3WarningTime;
	DWORD				m_dwrdCA3AlarmTime;
	DWORD				mDwrdAlarmStart;
	DWORD				mDwrdWarningStart;
	BOOL				m_dwrdBoardWarningOutput[MAX_SMEMA_LANES];
	DWORD				mbBoardCountOption;
	DWORD				mbBoardCountCount;
	DWORD				mbBoardCountOutput[MAX_SMEMA_LANES];
	DWORD				mbBoardCountAction;
} Purge;
//2 BELT MOTOR VARIABLES
void		Purge_initialization(Purge* pPurge);
void		Purge_resetCAs(Purge* pPurge);
void		Purge_CA3Processing(Purge* pPurge);	
void 		Purge_setSprayOutput(Purge* pPurge, UINT iOutput);
void		Purge_setSprayOn(Purge* pPurge, BOOL bIsSpraying, UINT lane);
void 		Purge_processSpray(Purge* pPurge);
void		Purge_setTwoMotorOutputValue(Purge* pPurge,BOOL bValue);
void		Purge_setTwoMotorOutput(Purge* pPurge,UINT iOutput);
void		Purge_setTwoMotorActive(Purge* pPurge,BOOL bActivate);
void		Purge_init(Purge* pPurge);
void		Purge_process	(Purge* pPurge);
const char*	Purge_getName	(Purge* pPurge);
void		Purge_setActive	(Purge* pPurge, BOOL state );
void		Purge_setPurgeTime10ths	(Purge* pPurge, DWORD purgeTime10thsOfSeconds );
void		Purge_setDigitialOutput	(Purge* pPurge, int iWhichOutput);
DWORD		Purge_getPurgeTime10ths	(Purge* pPurge);
void		Purge_setOutputOnForCooldown(Purge* pPurge, BOOL bOn);
void		Purge_forceOn(Purge* pPurge);

//Autoclean recipe functions
void		Purge_setRecipeOutput(Purge* pPurge, int iWhichOutput);
void		Purge_enableRecipeOutput(Purge* pPurge, BOOL bEnable);
void		Purge_isFluxCondensationEnabled(Purge* pPurge, BOOL bEnabled);
void		Purge_isFluxCondensationRecipeEnabled(Purge* pPurge, BOOL bEnabled);

//custom message function
void Purge_process_custom(Purge* pPurge, int iWhich);
void Purge_clearWarning(signed char which);
void Purge_enableCustomAlarm(Purge* pPurge, BOOL bAlarmOn, UINT iIndex);
void Purge_SetLineState(Purge* pPurge, BOOL bActiveHigh, UINT iIndex);
void Purge_setAudibleWarning(Purge* pPurge, BOOL bAudible, UINT iIndex);
void Purge_setMessageDelay(Purge* pPurge, DWORD dwrdDelay, UINT iIndex);
void Purge_setMessageType(Purge* pPurge, int shrtMsgType, UINT iIndex);
void Purge_setInput(Purge* pPurge, int shrtInput, UINT iIndex);
void Purge_setOutput(Purge* pPurge, int shrtOutput, UINT iIndex);
void Purge_setLightTowerAction(Purge* pPurge, int shrtAffect, UINT iIndex);
BOOL Purge_LightTowerShouldBeRed(Purge* pPurge);
BOOL Purge_LightTowerShouldBeYellow(Purge* pPurge);
BOOL Purge_inAudibleCondition(Purge* pPurge);
void Purge_suppressAudibleEvent();
BOOL Purge_lightTowerShouldBeRed(Purge* pPurge);
BOOL Purge_lightTowerShouldBeYellow(Purge* pPurge);

#endif

