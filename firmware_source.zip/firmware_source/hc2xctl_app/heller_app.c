/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
/*
** heller_app.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <sys/stat.h>
#include <signal.h>
#include "../hc2xio/include/hc2xio.h"
#include "xpdriverioctl.h"
#include "typedefdefine.h"
#include "BoardEventCmds.h"
#include "LotProcessingCmds.h"
#include "hc2xmstr.h"
#include "hc2xmstr_exports.h"
#include "hellermaster.h"

#include "safeSocket.h"
#include "transferTable.h"

#include <signal.h>

#define LRG_BUF_SIZE 50000 //7000	
#define XLRG_BUF_SIZE 50000 //7000	
unsigned char g_lrg_buffer[LRG_BUF_SIZE] = {0};
unsigned char g_ret_buffer[XLRG_BUF_SIZE] = {0};

unsigned char g_lotProcMsg[MAX_BOARDEVENT_MSG_SIZE] = { 0 };

#define IOCTL_ENABLE_WD _IOR('t', 0x97, int)
#define IOCTL_TICKLE_DOG _IOR('t', 0x98, int)
#define IOCTL_DISABLE_WD _IOR('t', 0x99, int)
#define WRITE_DEBUG_MESSAGES 0
#define SM_BUF_SIZE	512

#define DATA_SIZE_OFFSET	4
#define DATA_START_OFFSET	6
#define FIELD_SIZE			4 
#define OPCODE_SIZE			2

#define SLAVE_FILE	"/mnt/jffs/slave.txt"
#define MAC_FILE	"/mnt/jffs/mac"

#ifdef UDP_DEBUG
#define MAX_UDP_BUF1_SIZE	256
#define MAX_UDP_BUF2_SIZE	512
#endif

unsigned char g_sm_buffer[SM_BUF_SIZE] = {0};

unsigned char g_slave_ip[4] = {192, 168, 10, 251};

char g_deviceFile[SM_BUF_SIZE] = "";
char g_ioFile[] = "/dev/hc2xio";
char g_wdFile[] = "/dev/hc2xwd";

int g_driver_fd;
int g_io_fd = 0;
int g_wd_fd = 0;
int g_driverDBG_fd;

SafeSocket g_pvtSafeSocket;
SafeSocket g_pvtMasterSocket;

struct TRANSFER_TABLE g_recvTable;

int bTestWatchDog; 
int Handler_ClientCommunication();
int Process_BoardData_Command(unsigned int opCode, unsigned char* cmdBuf);
int ProcessTransferTable( unsigned int opCode, unsigned int bufferSize, unsigned char* cmdBuf );
int Process_PVT_Command(unsigned int pvt_command, unsigned char* cmdBuf, const int cmdBuf_size);
unsigned int Pack_PVT_Response(unsigned char *retBuff, unsigned char *smBuff);
int ChangeIPAddress(unsigned char* ipAddr);
int Process_UnknownCommand(void);
int Process_LotCommand(unsigned char* pkt, int pktSize);
int Process_CarrierLotCommand(unsigned char* pkt, int pktSize);

//////////////////////////////////
//
//	Global function varialbes to avoid stepping on memory.
//
//////////////////////////////////
fd_set master;   // master file descriptor list
fd_set read_fds; // temp file descriptor list for select()

struct sockaddr_in remoteaddr; // client address
int fdmax;        // maximum file descriptor number

unsigned int socket_cnt = 0;

int nbytes;
unsigned int* pInt;
unsigned short* pShort;
unsigned int functionField;
unsigned short sizeField;
int ret_offset = 0;

int total = 0, n;

int cmdSize;
char ch;

unsigned int nRetVal = 0;
unsigned short nSize = 0;

int iMasterFailure = 0;

#ifdef UDP_DEBUG
int udpSd = 0;
struct sockaddr_in remoteUdpAddr;
#endif // #ifdef UDP_DEBUG

unsigned short getShort(char *p)
{
	// Due to a compiler issue with pulling shorts out of unsigned
	// char pointers (they come out backwards), this function corrects that.
	unsigned int nRetVal;

	nRetVal = (((unsigned short)(p[1]) << 8) & 0xFF00) |
			((unsigned short)(p[0]) & 0x00FF);

	return nRetVal;
}


unsigned int getInt(unsigned char *p)
{
   unsigned int nRetVal;

   nRetVal = (((unsigned int)(p[3]) << 24) & 0xFF000000) |
             (((unsigned int)(p[2]) << 16) & 0x00FF0000) |
             (((unsigned int)(p[1]) << 8) & 0x0000FF00) |
             ((unsigned int)(p[0]) & 0x000000FF);

   return nRetVal;
}

#ifdef UDP_DEBUG
int g_sigPiped;

void udpOpen(void)
{
	struct sockaddr_in udpAddr;
	in_addr_t ip;
	int bindRes;
	int sendRes;
	int bCastOpt;
	int sockOptRes;
	char udpMsg[402];
	int tmpRes;

	udpSd = socket(AF_INET, SOCK_DGRAM, 0);
	if (udpSd <= 0)
	{
		perror("udp: socket");
	}

	tmpRes = fcntl(udpSd, F_SETFL, O_NONBLOCK);

	if (0 != tmpRes)
	{
		fprintf(stderr, "Error nonblocking socket (ret=%d): \n", tmpRes);
		perror("Nonblock UDP");
	}

	memset(&udpAddr, 0, sizeof(udpAddr));
	udpAddr.sin_family  = AF_INET;
	ip = INADDR_ANY;
	memcpy(&udpAddr.sin_addr.s_addr, &ip, 4);
	udpAddr.sin_port = htons(1111);

	memset(&remoteUdpAddr, 0, sizeof(remoteUdpAddr));
	remoteUdpAddr.sin_family  = AF_INET;
	ip = inet_addr("192.168.10.255");
	memcpy(&remoteUdpAddr.sin_addr.s_addr, &ip, 4);
	remoteUdpAddr.sin_port = htons(1111);

	bCastOpt = 1;
	sockOptRes = setsockopt(udpSd, SOL_SOCKET, SO_BROADCAST, &bCastOpt, sizeof(bCastOpt));
	if (0 != sockOptRes)
	{
		perror("udp setsockopt(SO_BROADCAST)");
	}

	bindRes = bind(udpSd, (struct sockaddr*)&udpAddr, sizeof(udpAddr));
	if (0 != bindRes)
	{
		perror("udp bind");
	}

	memset(udpMsg, 0, 256);
	snprintf(udpMsg, 256, "UDP debug socket open");
	sendRes = sendto(udpSd, udpMsg, 256, 0, (struct sockaddr*)&remoteUdpAddr, sizeof(remoteUdpAddr));

	return;
}

void udpDebugMsg(char* msg)
{
	char udpMsg[256];
	int sz = 256;
	int sendRes;
	int sockOptRes;
	int sockErrVal;
	socklen_t sockErrSz;

	memset(udpMsg, 0, 256);
	if (strlen(msg) < 256)
	{
		sz = strlen(msg);
	}
	memcpy(udpMsg, msg, sz);

	sockOptRes = getsockopt(udpSd, SOL_SOCKET, SO_ERROR, &sockErrVal, &sockErrSz);

	if ((-1 == sockOptRes) || (0 !=  sockErrVal))
	{
		fprintf(stderr, "udp getsockopt: res=%d, errVal=%d\n", sockOptRes, sockErrVal);
		perror("udp getsockopt(SO_ERROR)");
		close(udpSd);
		udpOpen();
	}

	sendRes = sendto(udpSd, udpMsg, 256, 0, (struct sockaddr*)&remoteUdpAddr, sizeof(remoteUdpAddr));

	if (sendRes != 256)
	{
		perror("udpDebugMsgP: send");
	}

	return;
}

void udpDebugMsgEx(char* msg, int size)
{
	int sendRes;
	int sockOptRes;
	int sockErrVal;
	socklen_t sockErrSz;

	sockOptRes = getsockopt(udpSd, SOL_SOCKET, SO_ERROR, &sockErrVal, &sockErrSz);

	if ((-1 == sockOptRes) || (0 !=  sockErrVal))
	{
		fprintf(stderr, "udp getsockopt(Ex): res=%d, errVal=%d\n", sockOptRes, sockErrVal);
		perror("udp getsockopt(SO_ERROR)");
		close(udpSd);
		udpOpen();
	}

	sendRes = sendto(udpSd, msg, size, 0, (struct sockaddr*)&remoteUdpAddr, sizeof(remoteUdpAddr));

	if (sendRes != size)
	{
		perror("udpDebugMsgEx: send");
	}

	return;
}

#endif // #ifdef UDP_DEBUG

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  sigPipeHandler

 			Handle the SIGPIPE signal so its default handler does not
			kill the application.

 GLOBALS:
 RETURNS:   none
 SEE ALSO:
------------------------------------------------------------------------*/
void sigPipeHandler(int sig)
{
#ifdef UDP_DEBUG
	g_sigPiped = 1;
	fprintf(stderr, "sigPipeHandler()\n");
#endif // #ifdef UDP_DEBUG
	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  main

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int main(int argc, char* argv[])
{
	unsigned char ping_str[30] = { 0 };

	int status = 0;
	int i = 0;
	int retries=0;
	int iReturn = 0;
	struct timeval timeout;
	BOOL bAbort = FALSE;
	int newfd = 0;
	int savedMask = 0;

#ifdef UDP_DEBUG
	char udpMsg[402];
	udpOpen();

	g_sigPiped = 0;

	signal(SIGPIPE, sigPipeHandler);
#endif // #ifdef UDP_DEBUG

	// Mask ALL signals (savedMask will contain current mask list)
	savedMask = sigsetmask(0xffffffff);

#ifdef UDP_DEBUG
	fprintf(stderr, "\tregistered sigPipeHandler()\n");
#endif // #ifdef UDP_DEBUG


	socket_cnt = 0;
	int slave_fd = -1;
	bTestWatchDog = 0;
	int bMaster	 = 0;

	SafeSocket_Constructor( &g_pvtSafeSocket );
	g_pvtSafeSocket.port = PORT;
	g_pvtSafeSocket.retries = 3;

	SafeSocket_Constructor( &g_pvtMasterSocket );
	g_pvtMasterSocket.port = PORT;
	g_pvtMasterSocket.retries = 3;

	if (argc != 2 )
	{
		if(WRITE_DEBUG_MESSAGES)
		{
			printf("usage: %s dev_name\n", argv[0]);
		}
		iReturn = 1;
	}
	else
	{
		strcpy(g_deviceFile, argv[1]);

		// TODO: request IP address from firmware
		//			if not initialize use a default address

		if ( g_io_fd <= 0 )
		{
			g_io_fd = open(g_ioFile, O_RDWR);
			if ( g_io_fd <= 0 )
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					printf("ERROR: main(): Can't open file: %s\n", g_ioFile);
				}
				iReturn = 1;
				bAbort = TRUE;
			}
		}

		if(!bAbort)
		{
			ioctl(g_io_fd, HC2XCTLAPP_INIT_TDM, g_lrg_buffer);
			status = ioctl(g_io_fd, HC2XCTLAPP_GetIPAddress, g_lrg_buffer);
			if(WRITE_DEBUG_MESSAGES)
			{
				printf("g_wd_fd prevalue %d\n", g_wd_fd);	
			}
			if(g_wd_fd <= 0)
			{
				g_wd_fd = open(g_wdFile, O_RDWR);
				if(g_wd_fd <= 0)
				{
					if(WRITE_DEBUG_MESSAGES)
					{
						printf("ERROR: main(): Can't open file: %s\n", g_wdFile);
					}
					iReturn = 1;
					bAbort = TRUE;
				}
				else
				{
					if(WRITE_DEBUG_MESSAGES)
					{
						printf("g_wd_fd succeded\n");
					}
				}
			}

			if(!bAbort)
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					printf("main(): HC2XCTLAPP_GetIPAddress %d.%d.%d.%d\n", 
						g_lrg_buffer[0], g_lrg_buffer[1],g_lrg_buffer[2],g_lrg_buffer[3]);
				}
				//
				// see if the SLAVE_FILE exists and set ip accordingly
				//
				slave_fd = open( SLAVE_FILE, O_RDONLY );
				if ( slave_fd > 0 )
				{
					close( slave_fd );
			
					printf("main(): This board is a slave.\n");
					g_lrg_buffer[0] = g_slave_ip[0];
					g_lrg_buffer[1] = g_slave_ip[1];
					g_lrg_buffer[2] = g_slave_ip[2];
					g_lrg_buffer[3] = g_slave_ip[3];
				}
				else
				{
					printf("main(): This board is a master.\n");
					
					bMaster = 1;
				}

				if ( status != 0 )
				{
					if(WRITE_DEBUG_MESSAGES)
					{
						printf("ERROR: main(): Unable to obtain ip address\n");
					}
					iReturn = 1;
					bAbort = TRUE;
				}
				else if ( (g_lrg_buffer[0] == 0) && (g_lrg_buffer[1] == 0) &&
							(g_lrg_buffer[2] == 0) && (g_lrg_buffer[3] == 0) )
				{
					g_lrg_buffer[0] = 192;
					g_lrg_buffer[1] = 168;
					g_lrg_buffer[2] = 10;
					g_lrg_buffer[3] = 250;
				
					status = ioctl(g_io_fd, HC2XCTLAPP_SetIPAddress, g_lrg_buffer);
					if ( status != 0 )
					{
						if(WRITE_DEBUG_MESSAGES)
						{
							printf("ERROR: main(): Unable to set ip address\n");
						}
						iReturn = 1;
						bAbort = TRUE;
					}
				}
			}
		}

		if(!bAbort)
		{
			ChangeIPAddress(g_lrg_buffer);

			FD_ZERO(&master);    // clear the master and temp sets
			FD_ZERO(&read_fds);
			status = -1;
			retries = 0;

			while((status == -1) && (retries < 5))
			{
				status = SafeSocket_Init(&g_pvtSafeSocket);
				retries++;
			}

			if ( status == -1 )
			{
				iReturn = 1;
			}
			else
			{
				// add the listener to the master set
				FD_SET( g_pvtSafeSocket.listenSd, &master);

				// keep track of the biggest file descriptor
				fdmax = g_pvtSafeSocket.listenSd; // so far, it's this one

				status = open(g_deviceFile, O_RDWR);
				if ( status == -1 )
				{
					if(WRITE_DEBUG_MESSAGES)
					{
					  system("load_hc2xctl");
					  printf("Can't open file: %s\n", g_deviceFile);
					}
					iReturn = 1;
				}
				else
				{
					g_driver_fd = status;

					// main loop
					ioctl(g_wd_fd, IOCTL_ENABLE_WD, 0);
					while (1)
					{

#ifdef UDP_DEBUG
						if (g_sigPiped)
						{
							char udpMsgPipe[320];

							g_sigPiped = 0;
							memset(udpMsgPipe, 0, 320);
							snprintf(udpMsgPipe, 320, "pipe signal received");
							udpDebugMsgEx(udpMsgPipe, 320);
						}
#endif // #ifdef UDP_DEBUG

						if(!bTestWatchDog)
						{
#ifdef UDP_DEBUG
					udpDebugMsg("tickling dog in while(1)");
#endif // #ifdef UDP_DEBUG
							int ioctrlReturned = ioctl(g_wd_fd, IOCTL_TICKLE_DOG, 0);
#ifdef UDP_DEBUG
					snprintf(udpMsg, 402, "driver tickle dog stamped %d", ioctrlReturned);
					udpDebugMsgEx(udpMsg, 402);
#endif // #ifdef UDP_DEBUG
						}

						if ( bMaster )
						{
							iMasterFailure = ExecuteMasterCommunication(iMasterFailure);
						}

						read_fds = master; // copy it
						timeout.tv_sec = 0;
						timeout.tv_usec = 0;

						status = select(fdmax+1, &read_fds, NULL, NULL, &timeout);
						if ( status == -1 )
						{
							if(WRITE_DEBUG_MESSAGES)
							{
								perror("main select");
							}
							//printf( "main: select() returned -1.  Calling SafeSocket_Init()\n" );

							FD_ZERO(&master);
							fdmax = 0;

							SafeSocket_CloseClient( &g_pvtSafeSocket );
							close( g_pvtSafeSocket.listenSd );
							g_pvtSafeSocket.listenSd = -1;

							status = SafeSocket_Init(&g_pvtSafeSocket);
							if ( status != -1 )
							{
								// add the listener to the master set
								FD_SET( g_pvtSafeSocket.listenSd, &master);

								// keep track of the biggest file descriptor
								fdmax = g_pvtSafeSocket.listenSd; // so far, it's this one
							}
						}
						else
						{
							// run through the existing connections looking for data to read
							for(i = 0; i <= fdmax; i++)
							{

								if(!bTestWatchDog)
								{
#ifdef UDP_DEBUG
					udpDebugMsg("tickling dog in socket service fdmax");
#endif // #ifdef UDP_DEBUG
									int ifdMaxIo = ioctl(g_wd_fd, IOCTL_TICKLE_DOG, 0);
#ifdef UDP_DEBUG
					snprintf(udpMsg, 402, "driver tickle dog stamped fdmax %d", ifdMaxIo);
					udpDebugMsgEx(udpMsg, 402);
#endif // #ifdef UDP_DEBUG
								}

								if (FD_ISSET(i, &read_fds))
								{ 
									// we got one!!
									if (i == g_pvtSafeSocket.listenSd)
									{
										// handle new connections
										newfd = SafeSocket_AcceptClient( &g_pvtSafeSocket );

										if ( newfd == -1 )
										{
											if(WRITE_DEBUG_MESSAGES)
											{
												perror("safe socket accept");
											}
										} 
										else
										{
#ifdef UDP_DEBUG
					udpDebugMsg("accepted client");
#endif // #ifdef UDP_DEBUG
											FD_SET( newfd, &master ); // add to master set
											if ( newfd > fdmax )
											{
												// keep track of the maximum
												fdmax = newfd;
											}

											socket_cnt++; //remove if re-adding g_ioFile
										}
									}
									else if( i > g_pvtSafeSocket.listenSd)
									{
										g_pvtSafeSocket.clientSd = i;
										status = Handler_ClientCommunication();

										if ( status <= 0 )
										{
#ifdef UDP_DEBUG
					udpDebugMsg("closing socket due to Handler_clientCommunication return value");
#endif // #ifdef UDP_DEBUG
											SafeSocket_CloseClient( &g_pvtSafeSocket ); // bye!

											FD_CLR(i, &master); // remove from master set
											socket_cnt--;
										}
									}
									else
									{
										if(WRITE_DEBUG_MESSAGES)
										{
											printf("socket id: %d, g_listener: %d\n",i, g_pvtSafeSocket.listenSd);
										}
									}
								}
							}
						}
					}
					close(g_driver_fd);
					iReturn = 0;
				}
			}
		}
	}

	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Handler_ClientCommunication()

				Manages all Client Communications to and from the HC2x.

	RETURNS:   int
------------------------------------------------------------------------*/
int Handler_ClientCommunication()
{
	int iReturn = 0;
	BOOL bAbort = FALSE;

	int dataSize = 0;
	unsigned int opCode = 0;
	unsigned int payloadSize = 0;
	unsigned char* payload = NULL;

	SSErr ssRetVal = SSErrNone;
	unsigned char g_hold_buffer[SM_BUF_SIZE] = {0};
	size_t curMsgSize = 0;

#ifdef UDP_DEBUG
	char udpMsg1[MAX_UDP_BUF2_SIZE];
	int sz = MAX_UDP_BUF2_SIZE;
#endif

	memset(g_lrg_buffer, 0, LRG_BUF_SIZE);

	// All messages are atleast 512 bytes.  Only one message is greater,
	// and that is the PVT_COMMAND.  Read 512 bytes off the ethernet 
	// and then determine what type of message it is and if we need to read more.
	
#ifdef UDP_DEBUG
		udpDebugMsg("before read client data");
#endif // #ifdef UDP_DEBUG

	ssRetVal = SafeSocket_ReadClientData( &g_pvtSafeSocket, &dataSize );

#ifdef UDP_DEBUG
	sz = MAX_UDP_BUF1_SIZE;
	snprintf(udpMsg1, sz, "after read client data (ssRetVal=%d, data size %d)", ssRetVal, dataSize);
	udpDebugMsgEx(udpMsg1, sz);
#endif // #ifdef UDP_DEBUG

	if ( ssRetVal == SSErrNone )
	{
		SafeSocket_GetClientMsg( &opCode, &payloadSize, &payload );
		nbytes = payloadSize;

		// Copy the data the SafeSocket read into the g_lrg_buffer.
		memcpy( g_lrg_buffer, payload, payloadSize );

		functionField = getInt(g_lrg_buffer);
		if ( (functionField == GET_PV_COMMAND) || (functionField == GET_PVT_COMMAND) || 
			(functionField == SET_PVT_COMMAND) || (functionField == SET_RECIPE_COMMAND) ||
			(functionField == MASS_COLLECT_AI_PV_TPO_SA) )
		{
			// Read the size field to determine how big the message 
			// will be.
			sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);
#ifdef UDP_DEBUG
			udpDebugMsg("before process pvt");
#endif // #ifdef UDP_DEBUG

			iReturn = Process_PVT_Command(functionField, g_lrg_buffer + DATA_START_OFFSET, sizeField);
#ifdef UDP_DEBUG
			udpDebugMsg("after process pvt");
#endif // #ifdef UDP_DEBUG

		}
		else if ( functionField == TRANSFER_TABLE_PROCESS )
		{
			iReturn = ProcessTransferTable( TRANSFER_TABLE_PROCESS, payloadSize, g_lrg_buffer );
		}
		else if( functionField == BOARDQUEUE_getBoardData)
		{
			iReturn = Process_BoardData_Command(opCode, g_lrg_buffer);
		}
		else if( functionField == BOARDEVENT_COMMAND)
		{
			// pass the major opcode in as well
			sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);
			// process the rest of the command, skipping the first op code and size
#ifdef UDP_DEBUG
					udpDebugMsg("before process lot");
#endif // #ifdef UDP_DEBUG

			iReturn = Process_LotCommand(g_lrg_buffer + DATA_START_OFFSET, sizeField);
#ifdef UDP_DEBUG
			udpDebugMsg("after process lot");
#endif // #ifdef UDP_DEBUG

		}
		else if ( functionField == LOTPROC_COMMAND )
		{
			// pass the major opcode in as well
			sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);

			// process the rest of the command, skipping the first op code and size
			iReturn = Process_CarrierLotCommand(g_lrg_buffer + DATA_START_OFFSET, sizeField);
		}
		else if ( functionField == HC2XCTLAPP_SetIPAddress )
		{
#ifdef UDP_DEBUG
			udpDebugMsg("setting ip");
#endif // #ifdef UDP_DEBUG

			if(WRITE_DEBUG_MESSAGES)
			{
				printf("hc2xctl_app: receive SetIPAddress\n");
			}
			sizeField = getShort(g_lrg_buffer+4);

			// echo the message back to the client as an ack


			ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, g_lrg_buffer, nbytes );

			if ( ssRetVal != SSErrNone )
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					perror("send");
				}
				iReturn = nbytes;
				bAbort = TRUE;
			}
			else
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					printf("hc2xctl_app: about to ChangeIPAddress()\n");
				}

				iReturn = ChangeIPAddress(g_lrg_buffer + DATA_START_OFFSET); 
				if ( iReturn == -1 )
				{
					bAbort = TRUE;
				}
				else
				{
					iReturn = SafeSocket_Init(&g_pvtSafeSocket);

					if ( g_io_fd <= 0 )
					{
						g_io_fd = open(g_ioFile, O_RDWR);
					}
					iReturn = ioctl(g_io_fd, functionField, g_lrg_buffer + DATA_START_OFFSET);
				}
			}
		}
		else if ( functionField == HC2XCTLAPP_SetMACAddress )
		{
#ifdef UDP_DEBUG
					udpDebugMsg("setting mac");
#endif // #ifdef UDP_DEBUG

			sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);

			// echo the message back to the client as an ack
			ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, g_lrg_buffer, nbytes );
			if ( ssRetVal != SSErrNone )
			{
				iReturn = nbytes;
				bAbort = TRUE;
			}

			if(!bAbort)
			{
				if ( g_io_fd <= 0 )
				{
					g_io_fd = open(g_ioFile, O_RDWR);
				}

				iReturn = ioctl(g_io_fd, functionField, g_lrg_buffer+6);
			}
		}
		else if(functionField == HC2XAPP_TEST_WATCHDOG)
		{
#ifdef UDP_DEBUG
					udpDebugMsg("testing wd");
#endif // #ifdef UDP_DEBUG

			bTestWatchDog = 1;
		}
		else
		{
			sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);
			curMsgSize = sizeField + FIELD_SIZE + OPCODE_SIZE; // size of data, size field, and opcode

			// make sure we do not exceed our buffer
			if (curMsgSize > SM_BUF_SIZE)
			{
				SafeSocket_SendErrorResp( &g_pvtSafeSocket, opCode, SSErrPayloadSize);
				iReturn = -1;
			}
			else
			{
				memcpy(g_hold_buffer, g_lrg_buffer, curMsgSize);
		
				iReturn = write(g_driver_fd, g_lrg_buffer, SM_BUF_SIZE);
#ifdef UDP_DEBUG
				if (0 == iReturn)
				{
					sz = MAX_UDP_BUF2_SIZE;

					snprintf(udpMsg1, sz, "Invalid IOCTL op code (1), packet to follow, followed by prewrite buffer");
					udpDebugMsgEx(udpMsg1, sz);
					udpDebugMsgEx(g_lrg_buffer, SM_BUF_SIZE);
					udpDebugMsgEx(g_hold_buffer, SM_BUF_SIZE);
				}
#endif // #ifdef UDP_DEBUG
				if ( iReturn != SM_BUF_SIZE )
				{
					bAbort = TRUE;
#ifdef UDP_DEBUG
						udpDebugMsg("abort true handler client line 737");
#endif // #ifdef UDP_DEBUG
				}
			}

			if(!bAbort)
			{
				iReturn = read(g_driver_fd, g_lrg_buffer, SM_BUF_SIZE);
				curMsgSize = SM_BUF_SIZE;
				if ( iReturn != SM_BUF_SIZE )
				{
					bAbort = TRUE;
#ifdef UDP_DEBUG
					udpDebugMsg("abort true handler client line 752");
#endif // #ifdef UDP_DEBUG
				}
				else
				{
					sizeField = getShort(g_lrg_buffer + DATA_SIZE_OFFSET);
					// size of data, size field, and opcode
					curMsgSize = sizeField + FIELD_SIZE + OPCODE_SIZE;
				}
			}

			if(!bAbort)
			{
				// send data to the client
				ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, g_lrg_buffer, curMsgSize);
				if ( ssRetVal == SSErrNone )
				{
					iReturn = SM_BUF_SIZE;
				}
				else
				{
					iReturn = -1;
				}
			}
		}
	}
	else if ( ssRetVal != SSNoData )
	{

		// An error occured.  Send back an error message.
		SafeSocket_GetClientMsg( &opCode, &payloadSize, &payload );
		SafeSocket_SendErrorResp( &g_pvtSafeSocket, opCode, ssRetVal );
	}
#ifdef UDP_DEBUG
	if(iReturn == -1)
	{
		udpDebugMsg("client communications failed");

	}
#endif // #ifdef UDP_DEBUG
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ProcessTransferTable

			Copies the TRANSFER_TABLE object to the driver.

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int ProcessTransferTable( unsigned int opCode, unsigned int bufferSize, unsigned char* cmdBuf )
{
	int iReturn = -1;
	int i = 0;
	int index = 0;
	int status = 0;
	SSErr ssErr = SSErrNone;


	const int headerBytes = 6; // 4 byte function field + 2 byte size field
	const int sizeSecondaryTable = sizeof( struct SECONDARY_TABLE );
	const int sizeReadback = sizeSecondaryTable + headerBytes;

	unsigned char* pDataBuffer = NULL;
	unsigned int dataSize = 0;

	//
	// The cmdBuf is the entire message sent from the primary.
	// Strip off the header and get to the actual data.
	//
	pDataBuffer = cmdBuf + headerBytes;
	dataSize = bufferSize - headerBytes;


	const int expectedSize = sizeof( struct TRANSFER_TABLE );

	if ( cmdBuf )
	{
		if ( dataSize == expectedSize )
		{
			TransferTable_Init( &g_recvTable );

			for ( i = 0; i < expectedSize; i++ )
			{
				((unsigned char*) &g_recvTable)[i] = pDataBuffer[i];
			}

			//
			// Copy the new table into the driver.
			//
			status = write(g_driver_fd, cmdBuf, bufferSize);
			if ( status != bufferSize )
			{
				iReturn = -1;
			}
			else
			{
				status = read(g_driver_fd, g_lrg_buffer, sizeReadback);
				if ( status != sizeReadback )
				{
					iReturn = -1;
				}
				else
				{
					ssErr = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, g_lrg_buffer, sizeReadback);
					if ( ssErr == SSErrNone )
					{
						iReturn = sizeReadback;
					}
					else
					{
						iReturn = -1;
					}

				}
			}
		}
		else
		{
			iReturn = -1;
		}
	}

	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Process_BoardData_Command

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int Process_BoardData_Command(unsigned int opCode, unsigned char* cmdBuf)
{
	sizeField = getShort(cmdBuf+4);
	unsigned short headerSize = sizeof(unsigned int) + sizeof(unsigned short);
	unsigned short dataSize = sizeof(unsigned int) + sizeof(unsigned short); //represents the size of a board and the distance traveled 2 bytes + 4bytes
	size_t curMsgSize = 0;
	int iReturn = 0;
	BOOL bAbort = FALSE;
	SSErr ssRetVal = SSErrNone;

	curMsgSize = sizeField + headerSize; // size of data, size field, and opcode
	int dataCount = getInt(cmdBuf + headerSize);
	if (curMsgSize > SM_BUF_SIZE)
	{

		SafeSocket_SendErrorResp( &g_pvtSafeSocket, opCode, SSErrPayloadSize);
		iReturn = -1;
	}
	else
	{

		iReturn = write(g_driver_fd, g_lrg_buffer, SM_BUF_SIZE);

		if ( iReturn != SM_BUF_SIZE )
		{
			if(WRITE_DEBUG_MESSAGES)
			{
				perror("write");
			}
			bAbort = TRUE;
		}
	}
	if(!bAbort)
	{
		dataCount = (dataCount * dataSize);
		if(dataCount > (LRG_BUF_SIZE-headerSize) )//request size is too large redesign
		{
			bAbort = TRUE;
		}
		else
		{
			iReturn = read(g_driver_fd, g_lrg_buffer, dataCount);
		}
	}

	if(!bAbort)
	{
		pInt = (unsigned int*) g_ret_buffer;
		*pInt = BOARDQUEUE_getBoardData;
		pShort = (unsigned short*) (g_ret_buffer + sizeof(unsigned int));
		*pShort = (iReturn + headerSize);
		unsigned char* ptrResponse = g_ret_buffer;
		ptrResponse += headerSize;
		iReturn += headerSize;
		memcpy(ptrResponse,(g_lrg_buffer + headerSize), iReturn);

		if(iReturn > LRG_BUF_SIZE)
		{
			bAbort = TRUE;
		}
		if(!bAbort)
		{
			ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, BOARDQUEUE_getBoardData, g_ret_buffer, iReturn );
			// send data to the client
			if ( ssRetVal == SSErrNone )
			{
				iReturn = SM_BUF_SIZE;
			}
			else
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					perror("send");
				}
				iReturn = -1;
			}
		}
	}
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Process_PVT_Command

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int Process_PVT_Command(unsigned int pvt_command, unsigned char* cmdBuf, const int cmdBuf_size)
{
	// The data portion of the PVT message consists of a series of
	// 4 byte function codes, 2 byte size field, and sizeField bytes of data.
	// Each one of these commands needs to be passed to the driver 
	// individually as if the client program asked each one in succession.

	int nReturn = 1;
	int packStatus = 0;
	int offset = 0;
	int i = 0;
	BOOL bContinue = TRUE;

	SSErr ssRetVal = SSErrNone;

	ret_offset = sizeof(unsigned int) + sizeof(unsigned short);

	while ( (offset < cmdBuf_size) && (bContinue == TRUE) )
	{
		// grab the function code and bytefield of the next message.
		functionField = getInt(cmdBuf + offset); 
		sizeField = getShort(cmdBuf + offset + sizeof(unsigned int));
		if(WRITE_DEBUG_MESSAGES)
		{
			printf("ff: %x, size %d, pos %d\n", functionField, sizeField, offset);
		}
		// copy the current command into a buffer to pass to the driver
		cmdSize = sizeof(unsigned int) + sizeof(unsigned short) + sizeField;
		if(cmdSize > 512)
		{
			if(WRITE_DEBUG_MESSAGES)
			{
				printf("Process_PVT_Command(): cmdSize = %d, function = %lx\nThrowing out communication\n"
				, cmdSize, functionField );
			}

			bContinue = FALSE;
			nReturn = 0;
		}
		else
		{
			memcpy(g_sm_buffer, cmdBuf+offset, cmdSize);
			offset += cmdSize;

			//
			// Pass the cmd to the driver
			//
			nReturn = write(g_driver_fd, g_sm_buffer, SM_BUF_SIZE);
#ifdef UDP_DEBUG
			if (0 == nReturn)
			{
				char udpMsg1[512];
				int sz = 512;

				snprintf(udpMsg1, sz, "Invalid IOCTL op code (2), packet to follow");
				udpDebugMsgEx(udpMsg1, sz);
				udpDebugMsgEx(g_sm_buffer, SM_BUF_SIZE);
			}
#endif // #ifdef UDP_DEBUG
			if ( nReturn != SM_BUF_SIZE )
			{
				if(WRITE_DEBUG_MESSAGES)
				{
					perror("write(pvt)");
				}
				bContinue = FALSE;
			}
			
			if ( bContinue )
			{
				nReturn = read(g_driver_fd, g_sm_buffer, SM_BUF_SIZE);
				if ( nReturn != SM_BUF_SIZE )
				{
					if(WRITE_DEBUG_MESSAGES)
					{
						perror("read(pvt)");
					}
					bContinue = FALSE;
				}
			}

			if ( bContinue )
			{
				if ( (pvt_command == GET_PVT_COMMAND) || (pvt_command == GET_PV_COMMAND) ||
					(pvt_command == SET_RECIPE_COMMAND)) 
				{
					// 
					// Package up the command to send back to the client.
					//
					packStatus = Pack_PVT_Response(&(g_ret_buffer[ret_offset]),
															g_sm_buffer);
					if(!packStatus)
					{
						if(WRITE_DEBUG_MESSAGES)
						{
							fprintf(stderr, "Error: Pack_PVT_Response\n");
						}
					}

					ret_offset += packStatus;
				}
			}
		}
	}

	if ( bContinue )
	{
		// set the outgoing func and size fields.
		pInt = (unsigned int*) g_ret_buffer;
		*pInt = pvt_command;
		pShort = (unsigned short*) (g_ret_buffer + sizeof(unsigned int));
		*pShort = ret_offset - sizeof(unsigned int) - sizeof(unsigned short);

		// send data to the client
		ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, pvt_command, g_ret_buffer, ret_offset );
		if ( ssRetVal == SSErrNone )
		{
			nReturn = nbytes;
		}
		else
		{
			nReturn = 0;
		}
	}
	
	return nReturn;
}

unsigned int Pack_PVT_Response(unsigned char *retBuff, unsigned char *smBuff)
{
	nRetVal = 0; //added when nRetVal became global

	if(retBuff != NULL && smBuff != NULL)
	{
		nRetVal += (sizeof(unsigned int) + sizeof(unsigned short));

		memcpy(retBuff, smBuff, nRetVal);
		
		nSize = getShort(&(smBuff[sizeof(unsigned int)]));

		memcpy(&(retBuff[nRetVal]), &(smBuff[nRetVal]), nSize);

		nRetVal += nSize;
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION: ChangeIPAddress
 GLOBALS:
 DESCRIPTION: Modifies the ethernet card to use the new IP address
 PARAMETERS: an array of 4 unsigned characters representing the dotted IP address.
 RETURNS: return 0 on Success, -1 on failure
 SEE ALSO:
------------------------------------------------------------------------*/
int ChangeIPAddress(unsigned char* ipAddr)
{
	int status, skfd;
	struct ifreq ifr = {0};
	struct sockaddr_in* in;
	char dotted_ipAddress[16] = "";
	int nsRetries = 0;
	// Convert the unsigned char array
	// to dotted format.
	sprintf(dotted_ipAddress, "%d.%d.%d.%d",
		ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
		
	if(WRITE_DEBUG_MESSAGES)
		printf(" New IP address is %d.%d.%d.%d\n",ipAddr[0],ipAddr[1],ipAddr[2],ipAddr[3]);

	// Create a socket that is the interace to the eth0 device.
	skfd = -1;
	while((skfd == -1) && nsRetries <5)
	{
		skfd = socket(AF_INET, SOCK_DGRAM, 0);
		nsRetries++;
	};
	if ( skfd == -1 )
	{
		if(WRITE_DEBUG_MESSAGES)
			perror("ChangeIPAddress socket");
		return -1;
	}

	strcpy(ifr.ifr_name, "eth0");

	in = (struct sockaddr_in*)&ifr.ifr_addr;
	in->sin_family = AF_INET;
	in->sin_port = 0;
	inet_aton( dotted_ipAddress, &(in->sin_addr) );

	status = ioctl(skfd, SIOCSIFADDR, &ifr);
	if ( status == -1 )
	{
		if(WRITE_DEBUG_MESSAGES)
			perror("ChangeIPAddress ioctl");
		return -1;
	}

	close(skfd);
	return 0;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION: Process_LotCommand

 			This function processes a lot processing command received 
			from the GUI.  It passes the command to the driver and 
			propagates the response back to the GUI (without the extra
			2 layers of opCode,size)
 			
 GLOBALS:
 RETURNS:   none
 SEE ALSO:  
------------------------------------------------------------------------*/
int Process_LotCommand(unsigned char* pkt, int pktSize)
{
	int retval = -1;
	ssize_t writeRes = 0;
	ssize_t readRes = 0;
	ssize_t bytesSent = 0;
	ssize_t sendRes = 0;
	ssize_t respSize = 0;

	SSErr ssRetVal = SSErrNone;

	unsigned char* respPkt = NULL;
	BoardEventHdr* pHdr = NULL;

	// driver expects a size of 512 every time...should be
	//		what we have if we got this far
	writeRes = write(g_driver_fd, pkt, pktSize);
#ifdef UDP_DEBUG
	if (0 == writeRes)
	{
		char udpMsg1[512];
		int sz = pktSize;

		memset(udpMsg1, 0, 512);
		if (pktSize < sz)
		{
			sz = pktSize;
		}
		snprintf(udpMsg1, sz, "Invalid IOCTL op code (LotCommand), <=512 bytes of packet to follow (len=%d)", pktSize);
		udpDebugMsgEx(udpMsg1, sz);
		udpDebugMsgEx(pkt, sz);
	}
#endif // #ifdef UDP_DEBUG

	if (pktSize == (int)writeRes)
	{
		// responses from the LOTPROC_OPCODE can be larger than 512 bytes
		readRes = read(g_driver_fd, g_lotProcMsg, MAX_BOARDEVENT_MSG_SIZE);
		respPkt = (g_lotProcMsg + 6);
		pHdr = (BoardEventHdr*)(respPkt);
		respSize = pHdr->msgSize;

		ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, respPkt, respSize );
		if ( ssRetVal == SSErrNone )
		{
			retval = readRes;
		}
		else
		{
			// pass up error
			retval = -1;
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION: Process_LotCommand

 			This function processes a lot processing command received 
			from the GUI.  It passes the command to the driver and 
			propagates the response back to the GUI (without the extra
			2 layers of opCode,size)
 			
 RETURNS:   none
------------------------------------------------------------------------*/
int Process_CarrierLotCommand(unsigned char* pkt, int pktSize)
{
	int retval = -1;
	ssize_t writeRes = 0;
	ssize_t readRes = 0;
	ssize_t bytesSent = 0;
	ssize_t sendRes = 0;
	ssize_t respSize = 0;

	SSErr ssRetVal = SSErrNone;

	unsigned char* respPkt = NULL;
	LotProcHdr* pHdr = NULL;

	// driver expects a size of 512 every time...should be
	//		what we have if we got this far
	writeRes = write(g_driver_fd, pkt, pktSize);
#ifdef UDP_DEBUG
	if (0 == writeRes)
	{
		char udpMsg1[512];
		int sz = pktSize;

		memset(udpMsg1, 0, 512);
		if (pktSize < sz)
		{
			sz = pktSize;
		}
		snprintf(udpMsg1, sz, "Invalid IOCTL op code (LotCommand), <=512 bytes of packet to follow (len=%d)", pktSize);
		udpDebugMsgEx(udpMsg1, sz);
		udpDebugMsgEx(pkt, sz);
	}
#endif // #ifdef UDP_DEBUG

	if (pktSize == (int)writeRes)
	{
		// responses from the LOTPROC_OPCODE can be larger than 512 bytes
		readRes = read(g_driver_fd, g_lotProcMsg, MAX_BOARDEVENT_MSG_SIZE);
		respPkt = (g_lotProcMsg + DATA_START_OFFSET);
		pHdr = (LotProcHdr*)(respPkt);
		respSize = pHdr->msgSize;
		
		ssRetVal = SafeSocket_SendResp( &g_pvtSafeSocket, functionField, respPkt, respSize );
		if ( ssRetVal == SSErrNone )
		{
			retval = readRes;
		}
		else
		{
			// pass up error
			retval = -1;
		}
	}

	return retval;
}

