/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/if_ether.h>

#include "hc2xmstr.h"
#include "hellermaster.h"

#include "xpdriverioctl.h"
#include "typedefdefine.h"

#include "safeSocket.h"
#include "transferTable.h"

#include "hc2xio.h"

#define RETRY_COUNT 3
#define NO_RETRY 1

#define FAILURE_CODE -1
#define DATA_BUF_SIZE (sizeof(struct TRANSFER_TABLE) + 6) // 4 bytes for function, 2 bytes for size

#define MESSAGE_POLLING			100	// milliseconds
#define POLLING_TIME_INCOMMLOSS	2000 //milliseconds, when previous attempt failed
#define TIMEOUT_CONNECTION_LOST	10000	// milliseconds

#define SLEEP_TIMEOUT			3		// seconds

//////////////////////////////////
//
//  Global function variables to avoid stepping on memory.
//
//////////////////////////////////

unsigned char g_send_buffer[DATA_BUF_SIZE] = {0};
unsigned char g_recv_buffer[DATA_BUF_SIZE] = {0};

// Time of last known successful communication
// between the primary and secondary.
unsigned int g_lastKnownGoodConnection = 0;

unsigned long g_lastRunTime = 0;

struct TRANSFER_TABLE g_sendTable;
struct TRANSFER_TABLE g_recvTable;

struct SECONDARY_TABLE g_tableSecondary;

BOOL g_bDataStatus = TRUE;		// Assume good data - used by SetSecondaryDataStatus()

//////////////////////////////////
//
//  Function declarations.
//
//////////////////////////////////

SSErr initialize_masterSocket();

unsigned short ParseUShortFromBuffer(char* p);
unsigned int ParseUIntFromBuffer(unsigned char* p);

int BuildTableCommand();
unsigned short VerifyTableResponse();

int SendRecvTableCommand( unsigned int opCode, int sendSize, int retries );

void HandleError(enum HC2XMSTR_ERROR error);

void SetSecondaryDataStatus( BOOL bDataStatus );

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ExecuteMasterCommunication

			Main entry point for sending/receiving data to/from the secondary.

 GLOBALS:
 RETURNS:   int 0 success, -1 failure
 SEE ALSO:
------------------------------------------------------------------------*/
int ExecuteMasterCommunication(int lastFailed)
{
	SSErr ssErr = SSErrNone;

	int iReturn = 0;

	int bEnable = 0;
	int status = 0;
	int savedMask = 0;
	int nBytes = 0;

	BOOL bSecondaryBoardActive = FALSE;

	unsigned long currentTime = 0;
	unsigned long pollFreq = MESSAGE_POLLING;
	int retries = RETRY_COUNT;
	//if the last communication failed we need to allow time for the pc and primary hc2 to communicate
	//slowing the poll rate to every two seconds and not retrying once the system is in error.  by
	//nature once the error clears we will go back to n retries and 100 ms
	if(lastFailed != 0)
	{
		retries = NO_RETRY;
		pollFreq = POLLING_TIME_INCOMMLOSS;
	}
	else
	{
		retries = RETRY_COUNT;
		pollFreq = MESSAGE_POLLING;
	}

	if ( g_io_fd != 0 )
	{
		status = ioctl( g_io_fd, IOCTL_GET_SECONDARY_ACTIVE, (int)(&bSecondaryBoardActive) );
		if ( status == 0 )
		{
			if ( bSecondaryBoardActive )
			{
				//
				// The current recipe uses the secondary board.
				// Query the secondary for its data.
				//

				ssErr = initialize_masterSocket();
				if ( ssErr == SSErrNone )
				{
					ioctl( g_io_fd, IOCTL_GET_JIFFIES, &currentTime);

					if ((currentTime - g_lastRunTime) >= pollFreq)
					{
						g_lastRunTime = currentTime;

						nBytes = BuildTableCommand();
						if ( nBytes < 0 )
						{
							iReturn = FAILURE_CODE;
						}
						else
						{
							//
							// Send the Table add await the response back which is new table.
							//
							status = SendRecvTableCommand( TRANSFER_TABLE_PROCESS, nBytes, retries );
							if ( status >= 0 )
							{
								//
								// Copy the repsonse into the driver.
								//
								status = VerifyTableResponse();
								if ( status == 0 )
								{
									iReturn = FAILURE_CODE;
								}
								else
								{
									//Successful communication.
									ioctl( g_io_fd, IOCTL_GET_JIFFIES, &currentTime );
									g_lastKnownGoodConnection = currentTime;

									SetSecondaryDataStatus( TRUE );
								}
							}
							else
							{
								iReturn = FAILURE_CODE;
							}
						}
					}
					else //preserve the error state if set
					{
						if(lastFailed)
						{
							iReturn = FAILURE_CODE;
						}

					}

				}
				else
				{
					iReturn = FAILURE_CODE;
				}
			}
		}
		else
		{
				iReturn = FAILURE_CODE;
		}
	}
	else
	{
		iReturn = FAILURE_CODE;
	}

	if(iReturn == FAILURE_CODE)
	{
		SetSecondaryDataStatus( FALSE );		
	}

	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  initialize_masterSocket

            reopens the SafeSocket connection and informs the 
			driver about the status of the conenction.

 GLOBALS:
 RETURNS:   unsigned short
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr initialize_masterSocket()
{
	SSErr ssErr = SSErrConn;

	BOOL bConnect = FALSE;

	if ( g_pvtMasterSocket.clientSd == -1 )
	{
		bConnect = TRUE;
	}
	else
	{
		ssErr = SafeSocket_CheckSocket( &g_pvtMasterSocket );
		if ( ssErr != SSErrNone )
		{
			bConnect = TRUE;
		}
	}

	if ( bConnect )
	{
		HandleError(HC2XMSTR_NO_CONNECTION);

		ssErr = SafeSocket_Connect( &g_pvtMasterSocket, g_slave_ip );
		if  ( ssErr == SSErrNone )
		{
			HandleError( HC2XMSTR_NO_ERROR );
		}
	}

	return ssErr;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ParseUShortFromBuffer

            Pull an unsigned short from the buffer.

 GLOBALS:
 RETURNS:   unsigned short
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned short ParseUShortFromBuffer(char* p)
{
	// Due to a compiler issue with pulling shorts out of unsigned
	// char pointers (they come out backwards), this function corrects that.
	unsigned int nRetVal = 0;

	nRetVal = (((unsigned short)(p[1]) << 8) & 0xFF00) |
	          ((unsigned short)(p[0]) & 0x00FF);

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ParseUIntFromBuffer

            Pull an unsigned short from the buffer.

 GLOBALS:
 RETURNS:   unsigned int
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned int ParseUIntFromBuffer(unsigned char* p)
{
	unsigned int nRetVal = 0;

	nRetVal = (((unsigned int)(p[3]) << 24) & 0xFF000000) |
	          (((unsigned int)(p[2]) << 16) & 0x00FF0000) |
	          (((unsigned int)(p[1]) << 8) & 0x0000FF00) |
	          ((unsigned int)(p[0]) & 0x000000FF);

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BuildTableCommand

			Queries the master driver for the table, 
			builds the command in the g_send_buffer, 
			and returns the size of the message to send.

			Returns -1 on failure.

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int BuildTableCommand()
{
	const unsigned int function = TRANSFER_TABLE_PROCESS;
	const int size = sizeof( struct TRANSFER_TABLE);

	unsigned short nRetval = -1;

	int offset = 0;
	int status = 0;
	int i = 0;

	TransferTable_Init( &g_sendTable );

	status = ioctl( g_io_fd, IOCTL_GET_TRANSFER_TABLE, &g_sendTable );
	if ( status )
	{
		nRetval = -1;
	}
	else
	{
		memset( g_send_buffer, 0, DATA_BUF_SIZE );

		g_send_buffer[offset++] = (function & 0x000000FF);
		g_send_buffer[offset++] = (function & 0x0000FF00) >> 8;
		g_send_buffer[offset++] = (function & 0x00FF0000) >> 16;
		g_send_buffer[offset++] = (function & 0xFF000000) >> 24;

		g_send_buffer[offset++] = (size & 0x000000FF);
		g_send_buffer[offset++] = (size & 0x0000FF00) >> 8;

		for ( i = 0; i < size; i++ )
		{
			g_send_buffer[offset++] = ((unsigned char*) &g_sendTable)[i];
		}

		nRetval = offset;
	}

	return nRetval;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  VerifyTableResponse

			Verifies the response from the client and copies the data
			into the hc2xmstr driver.

 GLOBALS:
 RETURNS:   unsigned short - 0 on failure, 1 on success
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned short VerifyTableResponse()
{
	unsigned short bRetVal = 0;
	unsigned int function = 0;
	unsigned short size = 0;

	BOOL bSecondaryActive = TRUE;

	const int dataSize = sizeof( struct SECONDARY_TABLE);

	int offset = 0;
	int status = 0;
	int i = 0;

	function = ParseUIntFromBuffer( g_recv_buffer );

	// Skip over the function code to get to the size field.
	offset += sizeof(unsigned int);

	size = ParseUShortFromBuffer( (g_recv_buffer + offset) );

	// Skip over the size to get to the start of the data.
	offset += sizeof(unsigned short);

	if ( TRANSFER_TABLE_PROCESS == function )
	{
		if ( dataSize == size )
		{
			//
			// Copy the data into the table from the message.
			// 
			TransferTable_Init( &g_recvTable );
			memset( &g_tableSecondary, 0, sizeof(g_tableSecondary) );

			for ( i = 0; i < size; i++ )
			{
				((unsigned char*) &g_tableSecondary)[i] = g_recv_buffer[offset++];
			}

			g_recvTable = g_sendTable;
			g_recvTable.tableSecondary = g_tableSecondary;

			// Copy the table into the driver.
			status = ioctl( g_io_fd, IOCTL_SET_TRANSFER_TABLE, &g_recvTable );
			if ( !status )
			{
				// Success.
				bRetVal = 1;

				// If the primary driver has told the secondary driver to shut down,
				// turn off the hc2xmaster_app's polling loop.
				if ( g_sendTable.configuration.byte1 & CONFIGURATION_BYTE1_SHUTDOWN )
				{
					bSecondaryActive = FALSE;
					status = ioctl( g_io_fd, IOCTL_SET_SECONDARY_ACTIVE, (int)(&bSecondaryActive) );
				}
			}
		}

	}

	return bRetVal;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SendRecvTableCommand

			Sends the command and awaits a response.
			Returns the amount of bytes read back or -1 on failure.

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int SendRecvTableCommand( unsigned int opCode, int sendSize, int retries )
{
	SSErr ssErr = SSErrNone;

	int nRetVal = -1; //Assume failure
	int status = 0;
	fd_set socks;
	struct timeval tv = {0};
	int i = 0;

	int dataSize = 0;
	unsigned int payloadSize = 0;
	unsigned char* payload = NULL;

	for ( i = 0; (i < retries) && (nRetVal < 0); i++ )
	{
		ssErr = SafeSocket_SendResp( &g_pvtMasterSocket, opCode, g_send_buffer, sendSize );
		if ( ssErr != SSErrNone )
		{
			if ( errno == EPIPE )
			{
				nRetVal = -1;
			}
			else
			{
				perror("SendMessage(): send");
			}
		}
		else
		{
			FD_ZERO(&socks);
			FD_SET( g_pvtMasterSocket.clientSd, &socks);
			tv.tv_sec = 1; //set timeout to 1 sec.
			tv.tv_usec = 0;

			status = select( g_pvtMasterSocket.clientSd + 1, &socks, NULL, NULL, &tv);

			if (status == -1)
			{
				perror("select() -1");
				nRetVal = -1;
			}
			else if (status == 0)
			{
				// Time out occured.
				nRetVal = -1;
			}
			else
			{
				ssErr = SafeSocket_ReadClientData( &g_pvtMasterSocket, &dataSize );
				if ( ssErr == SSErrNone )
				{
					ssErr = SafeSocket_GetClientMsg( &opCode, &payloadSize, &payload );
					if ( ssErr == SSErrNone )
					{
						memcpy( g_recv_buffer, payload, payloadSize );
						nRetVal = payloadSize;
					}
				}
			}
		}
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HandleError


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HandleError(enum HC2XMSTR_ERROR error)
{
	ioctl(g_io_fd, IOCTL_SET_SOCKET_ERROR, &error);

	printf( "HandleError( %d )\n", error );
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SetSecondaryDataStatus

			Informs the other driver if we have lost data communication
			or if the communciation has come back alive.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void SetSecondaryDataStatus( BOOL bDataStatus )
{
	int status = bDataStatus;

	if ( g_bDataStatus != bDataStatus )
	{
		g_bDataStatus = bDataStatus;

		if ( bDataStatus )
		{
			ioctl(g_io_fd, IOCTL_CLEAR_NO_DATA, &status);
		}
		else
		{
			ioctl(g_io_fd, IOCTL_SET_NO_DATA, &status);
		}
	}
}
