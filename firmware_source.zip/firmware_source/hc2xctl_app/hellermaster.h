/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 

#ifndef HELLERMASTER_H
#define HELLERMASTER_H

#include "safeSocket.h"
#include "transferTable.h"

int ExecuteMasterCommunication(int lastFailed);

extern int g_io_fd;
extern SafeSocket g_pvtMasterSocket;
extern unsigned char g_slave_ip[4];

#endif
