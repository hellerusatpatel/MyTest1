/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2001, All Rights Reserved
                    Company Confidential

	File:			BoardEventCmds.h

	Description:	Lot Processing Command definitions

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
 
#ifndef __BOARDEVENTCMDS_H__
#define __BOARDEVENTCMDS_H__

#define BOARDEVENT_COMMAND				2000000	// Op Code read by Linux App

#define BOARDEVENT_EVENT_REQ			1		// Event Request - check for and retrieve pending events from HC2X
#define BOARDEVENT_EVENT_RESP			2		// Event Response - contains event information (see BoardEvent)
#define BOARDEVENT_EVENT_CLEAR			3		// Event Clear - clear retrieved/validated events from the HC2X
#define BOARDEVENT_EVENT_CLEAR_ACK		4		// Event Clear Acknowlege - confirm a clear of events (mirror of command)
#define BOARDEVENT_ERROR				9		// Event Error Response - detected an issue with the previous command

#define BOARDEVENT_SEQUENCE_RESET			1		//assigned to the reset bit for the first message or after reset message from UI.  UI will set its count to 0 when the bit is set

#define BOARDEVENT_ERR_NOERROR			0		// No error error code
#define BOARDEVENT_ERR_GENERR			1		// General error (CRC, size, check bytes, etc.)
#define BOARDEVENT_ERR_UNKNOWNEVENT		4		// Event referenced in command is not defined

#define	MAX_EVENTS_PER_PACKET		50		// Maximum number of events that will fit in a packet

#define MAX_BOARDEVENT_MSG_SIZE		1556	// This is more than the largest size a lot message

#define BOARDEVENT_CHECKBYTES			0xA5A5

#pragma pack(1)
typedef struct HC2XHdr_s
{
	DWORD		opCode;			// main op code read and extracted by the Linux App
	WORD		msgSize1;		// size of the message to follow
	DWORD		ioctlOpCode;	// op code read by the driver_write in the hc2xctl()
	WORD		msgSize2;		// size of the message to follow
} HC2XHdr;

// NOTE: BoardEventHdr should be preceeded by HC2XHdr
typedef struct BoardEventHdr_s
{
	WORD		subOpCode;		// sub op code for lot processing specific command
	WORD		msgSize;		// includes this message size
	WORD		checkBytes;		// checkbytes to prevent issues with all zeros/ones
	WORD		crc;			// CRC for data verification
} BoardEventHdr;

typedef struct BoardEvent_s
{
	DWORD		highTime;		// MSB portion of __tim364_t representation of the event's timestamp
	DWORD		lowTime;		// LSB portion of __tim364_t representation of the event's timestamp
	DWORD		milliseconds;	// milliseconds portion of the event's timestamp
	WORD		eventSeqNum;	// sequence number of the event

	CHAR		inUse;			// carrier/event is valid or not (0 or 1 resepectively)
	CHAR		lane;			// lane identification
	CHAR		cooldown;		// non-zero if the event was generated while in cooldown
	CHAR		reset;			// resets the sequence count

	WORD		reserved;		// reserved for padding

} BoardEvent;

typedef struct BoardEventReq_s
{
	BoardEventHdr		hdr;
	CHAR			reserved[492];					// reserved for padding
} BoardEventReq;

typedef struct BoardEventResp_s
{
	BoardEventHdr		hdr;
	CHAR				numValidEvents;					// number of valid events in the packet
	CHAR				reserved[3];					// reserved for padding
	BoardEvent			events[MAX_EVENTS_PER_PACKET];	// the events
} BoardEventResp;

typedef struct BoardEventAck_s
{
	BoardEventHdr	hdr;
	CHAR			numEvents;							// number of valid event sequence numbers
	CHAR			reserved[3];						// padding for alignment
	WORD			eventSeqs[MAX_EVENTS_PER_PACKET];	// sequence numbers of events to be cleared
	CHAR			reserved2[388];						// pad the packet to ensure it meets the min size of 512
} BoardEventAck;

typedef struct BoardEventError_s
{
	BoardEventHdr	hdr;
	WORD			subOpCode;			// subOpCode the error is in response to
	WORD			errorCode;			// error code denoting the error
	CHAR			reserved[488];		// pad the packet to ensure it meets the min size of 512
} BoardEventError;


#pragma pack()		// return to Zp setting in windows app.

#endif // #ifndef __BOARDEVENTCMDS_H__

