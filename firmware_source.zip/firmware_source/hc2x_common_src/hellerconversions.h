/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//
//
//	Heller Industries
//
//
//
//	Filename:							HellerConversions.h
//
//	Defintion Author:					Jessica Kowalcyzk
//
//	Implementation Author:				Jessica Kowalczyk
//
//	Creation Date:						4/8/98
//
//

#ifndef HellerConversions
#define HellerConversions

//TEMPERATURE VALUE CONVERSION FACTORS
#define	COUNTS_PER_DEGREE_C						10.0f//temperature values 
#define	COUNTS_PER_SECOND						10.0f//time value
#define COUNTS_PER_CENTIMETER					10.0f//distance value
#define COUNTS_PER_FLOAT_PARAM					10.0f//other float value
#define COUNTS_PER_PERCENT						1.0f//percentage value 
#define PERCENTCOUNTS_PER_PERCENT				2.56f//tpo value

#define DEFAULT_ALARM_BAND 10 * COUNTS_PER_DEGREE_C
#define DEFAULT_WARN_BAND 8 * COUNTS_PER_DEGREE_C
#define DEFAULT_DEAD_BAND 5 * COUNTS_PER_DEGREE_C

#endif










