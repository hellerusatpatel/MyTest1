/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2013, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 

#ifndef _TRANSFER_TABLE_H_
#define _TRANSFER_TABLE_H_

#include "typedefdefine.h"

#define COUNT_ANALOG_INPUTS	(MAX_ANALOG_INPUTS * 2)	// need to also account for the modbus points 

//statusFlags bit values for the SECONDARY_TABLE
#define StatusFlagConfigured	0x01	// sent configuration from the primary has been recieved by the secondary board
#define StatusFlagOffsets		0x02	// primary board has recieved a valid offset table
#define StatusFlagCommTimeout	0x04	// a timeout has occurred - (primary can log a warning)
#define StatusFlagNoData		0x08	// set by the master application if there is no communication between the boards.

#define CONFIGURATION_BYTE1_MODBUS_MASTER		0x01
#define CONFIGURATION_BYTE1_GETTDM				0x02
#define CONFIGURATION_BYTE1_MODBUS_SLAVE_ACTIVE 0x04
#define CONFIGURATION_BYTE1_SHUTDOWN			0x08	// tell the secondary to stop its schedule loop

//----------------------------------------------------
//
//	struct PRIMARY_TABLE - data to send to the secondary controller
//
//----------------------------------------------------
struct PRIMARY_TABLE
{
	DWORD	tpo[MAX_ANALOG_OUTPUTS];
	BOOL	digOut[MAX_DIGITAL_OUTPUTS];
};

//----------------------------------------------------
//
//	struct SECONDARY_TABLE - data returned from the secondary controller
//
//----------------------------------------------------
struct SECONDARY_TABLE
{
	WORD	analogIn[COUNT_ANALOG_INPUTS];
	WORD	tdmOffset[MAX_ANALOG_INPUTS];
	BOOL	digIn[MAX_DIGITAL_INPUTS];

	DWORD	statusFlags;
};

//----------------------------------------------------
//
//	struct CONFIGURATION - configuration parameters to send to the secondary controller
//
//----------------------------------------------------
struct CONFIGURATION
{
	BYTE	byte1; //bit lsb to msb, 0 master, 1 get tdm, 2 slave active
};

//----------------------------------------------------
//
//	struct TRANSFER_TABLE - table that is send to/from primary/secondary
//
//----------------------------------------------------
struct TRANSFER_TABLE
{
	struct CONFIGURATION	configuration;
	struct PRIMARY_TABLE	tablePrimary;
	struct SECONDARY_TABLE	tableSecondary;
};

//----------------------------------------------------
//
//	struct TRANSFER_TABLE - methods
//
//----------------------------------------------------

void TransferTable_Init( struct TRANSFER_TABLE* pTable );

WORD TransferTable_SecondaryGetAI( struct TRANSFER_TABLE* pTable, int index );
BOOL TransferTable_SecondaryGetDigitalIn( struct TRANSFER_TABLE* pTable, int index );
WORD TransferTable_SecondaryGetTdmOffset( struct TRANSFER_TABLE* pTable, int index );
DWORD TransferTable_SecondaryGetFlags( struct TRANSFER_TABLE* pTable );

BOOL TransferTable_PrimarySetTPO( struct TRANSFER_TABLE* pTable, int index, DWORD dwValue );
BOOL TransferTable_PrimarySetDigitalOut( struct TRANSFER_TABLE* pTable, int index, BOOL bValue );

BOOL TransferTable_Compare( struct TRANSFER_TABLE* pTable1, struct TRANSFER_TABLE* pTable2 );
void TransferTable_DebugFill( struct TRANSFER_TABLE* pTable );

#endif
