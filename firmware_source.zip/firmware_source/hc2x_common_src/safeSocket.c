/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

#include "safeSocket.h"

#include "crc.h"

// #define UDP_DEBUG

unsigned char g_pRecvBuff[SS_MAX_SEG_SIZE];
unsigned char g_pSendBuff[SS_MAX_SEG_SIZE];

void udpDebugMsg(char* msg);

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_Constructor

			Constructor-like function that initializes the structure.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void SafeSocket_Constructor(SafeSocket* pSS)
{
	if ( pSS )
	{
		pSS->listenSd = -1;
		pSS->clientSd = -1;
		pSS->seqNum = 0;
		pSS->port = 0;
		pSS->retries = 3;

		memset( &(pSS->lastCommTime), 0, sizeof(struct timeval) );

		pSS->bUseNonBlocking = 1;

		memset( &(pSS->clientAddr), 0, sizeof(struct sockaddr_in) );
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_Init

			Creates, binds, and listens to a socket.
			For listing to clients.

 GLOBALS:
 RETURNS:   unsigned short
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned short SafeSocket_Init(SafeSocket* pSS)
{
	unsigned short retval = 0;
	struct sockaddr_in localAddr = {0};
	int tmpRes = 0;
	int sockOpt = 0;
#ifdef UDP_DEBUG
	char udpMsg[256];
#endif // #ifdef UDP_DEBUG

	if ( pSS &&
		pSS->port )
	{
		memset(&localAddr, 0, sizeof(localAddr));
		localAddr.sin_addr.s_addr = htonl(INADDR_ANY);	
		localAddr.sin_port = htons(pSS->port);

		pSS->listenSd = socket(PF_INET, SOCK_STREAM, 0);
		if (-1 != pSS->listenSd)
		{
			// try to bind on the selected port
			tmpRes = bind(pSS->listenSd, (struct sockaddr*)&localAddr, sizeof(localAddr));
			
			if (0 == tmpRes)
			{
				sockOpt = 1;
				// try to allow access again without waiting if app is rerun etc
				tmpRes = setsockopt(pSS->listenSd, SOL_SOCKET, SO_REUSEADDR, &sockOpt, sizeof(sockOpt));
#ifdef ALLOW_DEBUG_STATEMENTS
				if (0 != tmpRes)
				{
					fprintf(stderr, "Error reusing address: %s\n", strerror(errno));
				}
#endif
				// O_NONBLOCK 
				if ( pSS->bUseNonBlocking )
				{
					tmpRes = fcntl(pSS->listenSd, F_SETFL, O_NONBLOCK);
#ifdef ALLOW_DEBUG_STATEMENTS
					if (0 != tmpRes)
					{
						fprintf(stderr, "Error nonblocking socket: %s\n", strerror(errno));
					}
#endif
#ifdef UDP_DEBUG
					snprintf(udpMsg, 256, "Blocking socket result: %d", tmpRes);
					udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
				}
#ifdef UDP_DEBUG
				else
				{
					udpDebugMsg("Not setting non-blocking socket!");
				}
#endif // #ifdef UDP_DEBUG

				tmpRes = listen( pSS->listenSd, SS_LISTEN_BACKLOG );

				if (0 == tmpRes)
				{
#ifdef ALLOW_DEBUG_STATEMENTS
					fprintf(stderr, "safeSocket listening on port %d\n", pSS->port);
#endif
					// finally, success
					retval = 1;
					// no client yet
					pSS->clientSd = -1;
				}
#ifdef ALLOW_DEBUG_STATEMENTS

				else
				{
					fprintf(stderr, "Error listening on socket: %s\n", strerror(errno));
				}
#endif
			}
#ifdef ALLOW_DEBUG_STATEMENTS

			else
			{
				fprintf(stderr, "Error binding socket: %s\n", strerror(errno));
			}
#endif
		}
#ifdef ALLOW_DEBUG_STATEMENTS
		else
		{
			fprintf(stderr, "Error opening socket: %s\n", strerror(errno));
		}
#endif
	}
#ifdef ALLOW_DEBUG_STATEMENTS
	else
	{
		fprintf(stderr, "Error: invalid port: %d\n", pSS->port);
	}
#endif
	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_AcceptClient

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int SafeSocket_AcceptClient(SafeSocket* pSS)
{
	int newSocket = 0;
	int fcntlRes = 0;
	socklen_t addrSz = 0;
	int wouldBlockErr = 0;
	struct sockaddr_in remoteAddr = {0};
#ifdef UDP_DEBUG
	char udpMsg[256];
#endif // #ifdef UDP_DEBUG

	if ( pSS )
	{
		addrSz = sizeof(remoteAddr);

		newSocket = accept(pSS->listenSd, (struct sockaddr*)&remoteAddr, &addrSz);
#ifdef UDP_DEBUG
		snprintf(udpMsg, 256, "New socket: %d", newSocket);
		udpDebugMsgEx(udpMsg, 128);
#endif // #ifdef UDP_DEBUG

		wouldBlockErr = ((errno == EAGAIN) || (errno == EWOULDBLOCK));

		if ((-1 == newSocket) && !wouldBlockErr)
		{
#ifdef ALLOW_DEBUG_STATEMENTS
			fprintf(stderr, "Error selecting listen: %s\n", strerror(errno));
#endif
			SafeSocket_CloseClient(pSS);
			SafeSocket_Init(pSS);
		}
		else
		{
			// O_NONBLOCK 
			if ( pSS->bUseNonBlocking )
			{
				fcntlRes = fcntl(newSocket, F_SETFL, O_NONBLOCK);
#ifdef ALLOW_DEBUG_STATEMENTS
				if (0 != fcntlRes)
				{
					fprintf(stderr, "Error nonblocking socket: %s\n", strerror(errno));
				}
#endif
#ifdef UDP_DEBUG
				snprintf(udpMsg, 256, "Blocking socket result: %d", fcntlRes);
				udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
			}
#ifdef UDP_DEBUG
			else
			{
				udpDebugMsg("Not setting non-blocking socket!");
			}
#endif // #ifdef UDP_DEBUG
		}
	}

	return newSocket;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_RecvTotal

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_RecvTotal(SafeSocket* pSS, unsigned char* buff, int* pSize)
{
	SSErr retval = SSErrNone;

	ssize_t recvRes = 0;
	ssize_t getSz = 0;
	ssize_t recvd = 0;
	ssize_t bytesLeft = 0;

	struct timeval timeStart = { 0 };
	struct timeval now = { 0 };

	suseconds_t timeTestUSec = 0;
	time_t timeTestMSec = 0;

	double dTmp = 0;
	time_t timeRecvTimeout = 0;

	unsigned int wiggle = 250;	// ms

	const double timeoutPerCharacter = 0.08; // 8 * 10(^-8) for every character in nano-seconds
	const unsigned int dwWindowsBaselineTimeout = 400000; // 400 nano-seconds
	const unsigned int dwTcpHeadersOverhead = 64; // 64 characters

	int wouldBlockErr = 0;
	SSErr checkSockErr = SSErrNone;

	if ( pSS 
		&& buff 
		&& pSize )
	{
		recvd = 0;
		getSz = *pSize;
		bytesLeft = getSz;

		dTmp = (getSz + dwTcpHeadersOverhead) * timeoutPerCharacter; // nano-seconds
		dTmp += dwWindowsBaselineTimeout;

		timeRecvTimeout = (time_t) (dTmp / 1000.0);	// nano to milli
		timeRecvTimeout += wiggle;

		gettimeofday(&timeStart, NULL);

		while ((recvd < getSz) && (SSErrNone == retval))
		{
			// check the health of the socket prior to sending
			checkSockErr = SafeSocket_CheckSocket(pSS);

			if (SSErrNone != checkSockErr)
			{
				retval = checkSockErr;
			}
			else
			{
				recvRes = recv(pSS->clientSd, (buff+recvd), bytesLeft, 0);

				wouldBlockErr = ((errno == EAGAIN) || (errno == EWOULDBLOCK));

				// if the socket just timed out and didn't close, we will get EAGAIN
				if ((-1 == recvRes) && !wouldBlockErr)
				{
					retval = SSErrConn;
				}
				else if (-1 != recvRes)
				{
					recvd += recvRes;
					bytesLeft -= recvRes;

					// update timer
					if (bytesLeft)
					{
						// check for a timeout
						gettimeofday(&now, NULL);

						timeTestMSec = now.tv_sec - timeStart.tv_sec;
						timeTestMSec *= 1000;
						timeTestUSec = (now.tv_usec - timeStart.tv_usec);
						timeTestMSec += (timeTestUSec / 1000);

						if (timeTestMSec > timeRecvTimeout)
						{
#ifdef ALLOW_DEBUG_STATEMENTS
							fprintf(stderr, "  Socket timeout: %d msec expired\n", timeTestMSec);
#endif
							retval = SSErrTimeout;
						}
					}
				}
			}
		} // while ((recvd < getSz) && (SSErrNone == retval))
	}
	else
	{
		retval = SSNullPtr;
	}

	return retval;
} // SafeSocket_RecvTotal()

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_ReadClientData

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_ReadClientData(SafeSocket* pSS, int* pSize)
{
	SSErr retval = SSErrNone;
	int crcFieldSize = 0;
	int size = 0;
	unsigned char* secondReadBuff = NULL;
	SSHdr* pHdr = (SSHdr*)g_pRecvBuff;
	int i = 0;
#ifdef UDP_DEBUG
	char udpMsg[256];
#endif // #ifdef UDP_DEBUG
	unsigned int crc = 0;
	SSErr checkSockErr = SSErrNone;

	if ( pSS && pSize )
	{
		// Zero out the recv buffer before every read.
		for ( i = 0; i < SS_MAX_SEG_SIZE; i++ )
		{
			g_pRecvBuff[i] = 0;
		}

		// check the health of the socket prior to sending
		checkSockErr = SafeSocket_CheckSocket(pSS);

		if (SSErrNone != checkSockErr)
		{
			retval = checkSockErr;
#ifdef ALLOW_DEBUG_STATEMENTS
			printf("checksocket failed\n");
#endif
		}
		else
		{
			// just try to read the header to see if data is present
			size = sizeof(SSHdr);
			retval = SafeSocket_RecvTotal(pSS, g_pRecvBuff, &size);

			// got data? if there was an error or we didn't get the whole thing, retval
			//		would not be SSErrNone
			if (SSErrNone == retval)
			{
				// Verify the check-bytes before verifying the CRCs.
				if (SS_CHECK_BYTES == pHdr->checkBytes)
				{
					crcFieldSize = (SS_NUMBER_CRCS_TOTAL * sizeof(unsigned int));
					size = sizeof(SSHdr) - crcFieldSize;

					// Check the integrity of the header.
					// Skip over the first 3 CRC objects in the header and
					// calculate our own CRC for checking.
					crc = Calc32BitCRC( size, (g_pRecvBuff + crcFieldSize) );
					if ( crc == pHdr->crcHeader )
					{
						// Header checks out. 
						// Read the rest of the payload.
						secondReadBuff = g_pRecvBuff + sizeof(SSHdr);
						size = pHdr->len;

						retval = SafeSocket_RecvTotal(pSS, secondReadBuff, &size);
						if (SSErrNone == retval)
						{
							// if got it ok: verify check bytes, CRC, opCode, length, sequence num
							*pSize = pHdr->len;
							retval = SafeSocket_VerifyClientData(pSS);

							if ( retval == SSErrNone )
							{
								// TODO: Verify sequence number.
							}
						}
						else
						{
#ifdef ALLOW_DEBUG_STATEMENTS
							printf( "SafeSocket_ReadClientData(): socket %d: SafeSocket_RecvTotal() return %x\n", pSS->clientSd, retval );
#endif
#ifdef UDP_DEBUG
							snprintf(udpMsg, 256, "SafeSocket_ReadClientData: socket %d: SafeSocket_RecvTotal() return %x", pSS->clientSd, retval);
							udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
						}
					}
					else
					{
						retval = SSErrCRCHeader;
#ifdef ALLOW_DEBUG_STATEMENTS
						fprintf(stderr, "SafeSocket_ReadClientData(): socket %d: opCode(%d), mismatched header crc [%X]\n", pSS->clientSd, pHdr->opCode, crc);
#endif
#ifdef UDP_DEBUG
						snprintf(udpMsg, 256, "SafeSocket_ReadClientData: socket %d: opCode(%d), mismatched header crc [%X]", pSS->clientSd, pHdr->opCode, crc);
						udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
					}
				}
				else
				{
					retval = SSErrCheckBytes;
#ifdef ALLOW_DEBUG_STATEMENTS
					fprintf(stderr, "SafeSocket_ReadClientData(): mismatched checkbytes [%X]\n", pHdr->checkBytes );
#endif
#ifdef UDP_DEBUG
					snprintf(udpMsg, 256, "SafeSocket_ReadClientData: SSErrCheckBytes %X", pHdr->checkBytes);
					udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
				}
			}
		}
	} // if ( pSS && pSize )
	else
	{
		retval = SSNullPtr;
	}

	return retval;
} // SafeSocket_ReadClientData()

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_VerifyClientData

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_VerifyClientData(SafeSocket* pSS)
{
	SSErr retval = SSErrNone;
	unsigned char* crcBuff = NULL;
	int i = 0;

	int crcLen = 0;
	int bytesLeft = 0;

	unsigned int crcCalculated[SS_NUMBER_CRCS_PAYLOAD] = { 0 };

	SSHdr* pHdr = (SSHdr*)g_pRecvBuff;
	bytesLeft = pHdr->len;
	
	// Skip over the header to get to the payload.
	crcBuff = g_pRecvBuff + sizeof(SSHdr);

	// For each SS_MAX_CRC_SIZE of the payload, verify the crc.
	if ( retval == SSErrNone )
	{
		for ( i = 0; 
			(i < SS_NUMBER_CRCS_PAYLOAD) && (bytesLeft > 0 ) && (retval == SSErrNone);
			i++ )
		{
			if ( bytesLeft > SS_MAX_CRC_SIZE )
			{
				crcLen = SS_MAX_CRC_SIZE;
			}
			else
			{
				crcLen = bytesLeft;
			}

			crcCalculated[i] = Calc32BitCRC( crcLen, crcBuff );
			if ( crcCalculated[i] == pHdr->crcMsg[i] )
			{
				// CRC passed.
				// Gets the next chunk of data.
				crcBuff += crcLen;
				bytesLeft -= crcLen;
			}
			else
			{
				// CRC failed.
				retval = SSErrCRCMsg;
#ifdef ALLOW_DEBUG_STATEMENTS
				fprintf(stderr, "socket %d: MsgCRC[%d] failed: calculated (0x%X) for length (%d) \n", 
					pSS->clientSd, i, crcCalculated[i], crcLen );
#endif
				SafeSocket_PrintHeader( pHdr );
			}
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_PrintHeader

			Print the header for debugging purposes.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void SafeSocket_PrintHeader( SSHdr* pHdr )
{
#ifdef ALLOW_DEBUG_STATEMENTS

	int i = 0;

	if ( pHdr )
	{
		printf( "SSHdr:\n" );
		printf( "    crcHeader: %X\n", pHdr->crcHeader );

		for ( i = 0; i < SS_NUMBER_CRCS_PAYLOAD; i++ )
		{
			printf( "    crcMsg[%d]: %X\n", i, pHdr->crcMsg[i] );
		}

		printf( "    checkBytes: %X\n", pHdr->checkBytes );
		printf( "    seqNum (dec): %d\n", pHdr->seqNum );
		printf( "    len (dec): %d\n", pHdr->len );
		printf( "    opCode (hex): %X\n", pHdr->opCode );
		printf( "    flags (hex): %X\n", pHdr->flags );
	}
#endif
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_CloseClient

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void SafeSocket_CloseClient(SafeSocket* pSS)
{
	if (-1 != pSS->clientSd)
	{
#ifdef ALLOW_DEBUG_STATEMENTS
		fprintf(stderr, "Closing safe socket connection %d\n", pSS->port);
#endif 
		close(pSS->clientSd);
		pSS->clientSd = -1;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_GetClientMsg

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_GetClientMsg(unsigned int* pOpCode, unsigned int* pPayloadLen, unsigned char** pPayload)
{
	SSErr retval = SSNullPtr;
	SSHdr* pHdr = (SSHdr*)g_pRecvBuff;

	if ( pOpCode 
		&& pPayloadLen
		&& pPayload )
	{
		retval = SSErrNone;

		*pOpCode = pHdr->opCode;
		*pPayloadLen = pHdr->len;
		*pPayload = (g_pRecvBuff + sizeof(SSHdr));
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_SendResp

			Attach the payload to the SafeSocket header, calculate the
			crcs, and send the message.

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_SendResp(SafeSocket* pSS, unsigned int opCode, unsigned char* payload, int size)
{
	SSErr retval = SSErrNone;
	SSHdr* pHdr = NULL;
	int i = 0;
	int crcHdrSz = 0;
	unsigned char* crcBuff = NULL;
	unsigned char* sendPayload = NULL;
	int wholeMsgSize = 0;
	int sendRes = 0;
	int crcFieldSize = 0;

	int crcLen = 0;
	int bytesLeft = 0;

	wholeMsgSize = sizeof(SSHdr) + size;

	if ( wholeMsgSize < SS_MAX_SEG_SIZE )
	{
		// Zero out the send buffer before every send.
		// Don't need to zero out the entire buffer just what we are sending.
		for ( i = 0; i < wholeMsgSize; i++ )
		{
			g_pSendBuff[i] = 0;
		}

		pHdr = (SSHdr*) g_pSendBuff;

		sendPayload = g_pSendBuff + sizeof(SSHdr);
		for (i = 0; (i < size); ++i)
		{
			sendPayload[i] = payload[i];
		}

		// don't include CRCs field in calc
		crcFieldSize = (SS_NUMBER_CRCS_TOTAL * sizeof(unsigned int));

		crcBuff = g_pSendBuff + crcFieldSize;
		crcHdrSz = sizeof(SSHdr) - crcFieldSize;

		pHdr->checkBytes = SS_CHECK_BYTES;
		pHdr->seqNum = pSS->seqNum;
		pHdr->len = size;
		pHdr->opCode = opCode;
		pHdr->flags = SS_FLAGS_ACK; // any response is an implicit ACK

		pHdr->crcHeader = Calc32BitCRC( crcHdrSz, crcBuff);

		//
		// calculate crc of each segment
		//
		bytesLeft = size;
		crcBuff = payload;

		for ( i = 0; 
			(i < SS_NUMBER_CRCS_PAYLOAD) && (bytesLeft > 0 ) && (retval == SSErrNone);
			i++ )
		{
			if ( bytesLeft > SS_MAX_CRC_SIZE )
			{
				crcLen = SS_MAX_CRC_SIZE;
			}
			else
			{
				crcLen = bytesLeft;
			}

			pHdr->crcMsg[i] = Calc32BitCRC( crcLen, crcBuff );

			// Gets the next chunk of data.
			crcBuff += crcLen;
			bytesLeft -= crcLen;
		}

		//printf( "SafeSocket_SendResp: crcHeader[%x], crcMsg[%X, %X, %X], pyldSize[%d], msgSize[%d]\n",
		//	pHdr->crcHeader, pHdr->crcMsg[0], pHdr->crcMsg[0], pHdr->crcMsg[0], size, wholeMsgSize );

		// message is prepared, send it out
		retval = SafeSocket_SendTotal(pSS, wholeMsgSize);

		// next message we get from client should have an incremented sequence num
		++pSS->seqNum;

		if (SSErrNone != retval)
		{
			SafeSocket_CloseClient(pSS);
		}
	}
	else
	{
		retval = SSErrLen;
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_CheckSocket

			Check if the socket is valid or not (via getsockopt()).

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_CheckSocket(SafeSocket* pSS)
{
	SSErr retval = SSErrNone;
	int sockOptRes = 0;
	int sockErrVal = 0;
	socklen_t sockErrSz = 0;

	sockOptRes = getsockopt(pSS->clientSd, SOL_SOCKET, SO_ERROR, &sockErrVal, &sockErrSz);

	if (-1 == sockOptRes || 0 !=  sockErrVal)
	{
		retval = SSErrConn;
		SafeSocket_CloseClient(pSS);
	}

#ifdef UDP_DEBUG
	{
		char udpMsg[512];
		char* errorStr;

		errorStr = strerror(errno);
		snprintf(udpMsg, 300, "getsockopt: sock=%d, res=%d, val=%d, errno=%s",
					pSS->clientSd, sockOptRes, sockErrVal, errorStr);
		udpDebugMsgEx(udpMsg, 300);
		errno = 0;
	}
#endif // #ifdef UDP_DEBUG

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_SendTotal

			Spool out the entire message in the g_pSendBuff.

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_SendTotal(SafeSocket* pSS, int size)
{
	SSErr retval = SSErrNone;
	int bytesLeft = 0;
	unsigned char* buff = NULL;
	int send_count = 0;
	ssize_t sendSz = size;

	struct timeval timeStart = { 0 };
	struct timeval now = { 0 };

	suseconds_t timeTestUSec = 0;
	time_t timeTestMSec = 0;

	int wouldBlockErr;
	SSErr checkSockErr;

#ifdef UDP_DEBUG
	char udpMsg[256];
#endif // #ifdef UDP_DEBUG


	if ( size < SS_MAX_SEG_SIZE )
	{
		bytesLeft = size;
		buff = g_pSendBuff;

#ifdef UDP_DEBUG
		snprintf(udpMsg, 256, "sendTotal timeout: %d, sd=%d", SS_SEND_TIMEOUT_MS, pSS->clientSd);
		udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG

		gettimeofday(&timeStart, NULL);

		while ( (bytesLeft > 0 ) && (SSErrNone == retval) )
		{
#ifdef UDP_DEBUG
			snprintf(udpMsg, 256, "sending: %d (sd=%d)", bytesLeft, pSS->clientSd);
			udpDebugMsg(udpMsg);
			errno = 0;
#endif // #ifdef UDP_DEBUG

			// check the health of the socket prior to sending
			checkSockErr = SafeSocket_CheckSocket(pSS);

			if (SSErrNone != checkSockErr)
			{
				retval = checkSockErr;
			}
			else
			{
				// socket is supposedly ok, try to send
				send_count = send(pSS->clientSd, buff, bytesLeft, 0);
				if ( send_count > 0 )
				{
					bytesLeft -= send_count;
					buff += send_count;
				}
				else
				{
					wouldBlockErr = ((errno == EAGAIN) || (errno == EWOULDBLOCK));

					// an actual socket failure will not have a blocking error code
					if ((-1 == send_count) && !wouldBlockErr)
					{
#ifdef ALLOW_DEBUG_STATEMENTS
						fprintf(stderr, "Error sending response: %s\n", strerror(errno));
#endif
#ifdef UDP_DEBUG
						snprintf(udpMsg, 256, "closing socket[sd=%d]: %s", pSS->clientSd, strerror(errno));
						udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
						SafeSocket_CloseClient(pSS);
						retval = SSErrConn;
					}
				}
			}

#ifdef UDP_DEBUG
			{
				char* errorStr;

				errorStr = strerror(errno);
				snprintf(udpMsg, 256, "send returned: %d, errno=%s[%d], sd=%d", send_count, errorStr, errno, pSS->clientSd);
				udpDebugMsg(udpMsg);
			}
#endif // #ifdef UDP_DEBUG

			// update timer
			if (bytesLeft)
			{
				// check for a timeout
				gettimeofday(&now, NULL);

				timeTestMSec = now.tv_sec - timeStart.tv_sec;
				timeTestMSec *= 1000;
				timeTestUSec = (now.tv_usec - timeStart.tv_usec);
				timeTestMSec += (timeTestUSec / 1000);

#ifdef UDP_DEBUG
				if (timeTestMSec >= 50)
				{
					snprintf(udpMsg, 256, "timeout exceeded 50: elapsed=%d (timeout=%d)", timeTestMSec, SS_SEND_TIMEOUT_MS);
					udpDebugMsgEx(udpMsg, 200);
				}
				snprintf(udpMsg, 256, "send checking timeout: elapsed=%d (timeout=%d)", timeTestMSec, SS_SEND_TIMEOUT_MS);
				udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
				if (timeTestMSec > SS_SEND_TIMEOUT_MS)
				{
#ifdef ALLOW_DEBUG_STATEMENTS
					fprintf(stderr, "Socket timeout: %d msec expired (sd=%d)\n", timeTestMSec, pSS->clientSd);
#endif
#ifdef UDP_DEBUG
					snprintf(udpMsg, 256, "sending response timed out, closing socket: sd=%d", pSS->clientSd);
					udpDebugMsg(udpMsg);
#endif // #ifdef UDP_DEBUG
					SafeSocket_CloseClient(pSS);
					retval = SSErrTimeout;
				}
			}
		} // while ( ... )
	}
	else
	{
		retval = SSErrLen;
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_SendErrorResp

			Send the client back just a header as an error response.

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_SendErrorResp(SafeSocket* pSS, unsigned int opCode, SSErr ssError)
{
	SSErr retval = SSErrNone;
	SSHdr* pHdr = NULL;
	int i = 0;
	int crcHdrSz = 0;
	int crcFieldSize = 0;
	int wholeMsgSize = 0;
	unsigned char* crcBuff = NULL;
	unsigned int errorFlag = 0;

	//
	// Get the error bit that corresponds with the error.
	//
	switch ( ssError )
	{
		case SSErrCRCHeader:
			errorFlag = SS_FLAGS_HDRCRC;
			break;

		case SSErrCRCMsg:
			errorFlag = SS_FLAGS_MSGCRC;
			break;

		case SSErrCheckBytes:
			errorFlag = SS_FLAGS_CHKBYTES;
			break;

		case SSErrTimeout:
			errorFlag = SS_FLAGS_TIMEOUT;
			break;

		case SSErrSeqNum:
			errorFlag = SS_FLAGS_SEQNUM;
			break;
		default:
			break;
	}

	//
	// Create the error message.
	//
	for ( i = 0; i < SS_MAX_SEG_SIZE; i++ )
	{
		g_pSendBuff[i] = 0;
	}

	pHdr = (SSHdr*) g_pSendBuff;

	pHdr->checkBytes = SS_CHECK_BYTES;
	pHdr->seqNum = pSS->seqNum;
	pHdr->len = 0;
	pHdr->opCode = opCode;
	pHdr->flags = SS_FLAGS_ERR | errorFlag;

	// don't include CRCs field in calc
	crcFieldSize = (SS_NUMBER_CRCS_TOTAL * sizeof(unsigned int));

	crcBuff = g_pSendBuff + crcFieldSize;
	crcHdrSz = sizeof(SSHdr) - crcFieldSize;

	pHdr->crcHeader = Calc32BitCRC( crcHdrSz, crcBuff);

	// message is prepared, send it out
	wholeMsgSize = sizeof(SSHdr);

	retval = SafeSocket_SendTotal(pSS, wholeMsgSize);

	// next message we get from client should have an incremented sequence num
	++pSS->seqNum;
#ifdef ALLOW_DEBUG_STATEMENTS
	printf( "SafeSocket_SendErrorResp: opCode[%X], flags[%X]\n", pHdr->opCode, pHdr->flags );
#endif
	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SafeSocket_Connect

			Connect to a remote ip.

 GLOBALS:
 RETURNS:   SSErr
 SEE ALSO:
------------------------------------------------------------------------*/
SSErr SafeSocket_Connect(SafeSocket* pSS, char* ip)
{
	SSErr ssErr = SSNullPtr;

	int reuse_addr = 1;		// for setsockopt() SO_REUSEADDR
	struct sockaddr_in myaddr = {0};

	char ipbuffer[16] = {0};
	int status = 0;

	if ( pSS && ip )
	{
		if ( pSS->clientSd > 0 )
		{
			SafeSocket_CloseClient( pSS );
		}
		
		// get the listener
		pSS->clientSd = socket(PF_INET, SOCK_STREAM, 0);
		if ( pSS->clientSd == -1 )
		{
			perror("socket");
			ssErr = SSErrConn;
		}
		else
		{
			// lose the pesky "address already in use" error message
			status = setsockopt( pSS->clientSd, SOL_SOCKET, SO_REUSEADDR, 
				&reuse_addr, sizeof(int));
			if ( status == -1 )
			{
				perror("setsockopt");
				ssErr = SSErrConn;
			}
			else
			{
				sprintf(ipbuffer, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
								
				// bind
				myaddr.sin_family = AF_INET;
				myaddr.sin_addr.s_addr = inet_addr(ipbuffer); //SLAVE_IP needs to be replaced.
				myaddr.sin_port = htons(pSS->port);
				memset(&(myaddr.sin_zero), '\0', 8);
					
				status = connect( pSS->clientSd, (struct sockaddr *)&myaddr, sizeof(myaddr) );
				if ( status == -1 )
				{
					ssErr = SSErrConn;
				}
				else
				{
					fcntl( pSS->clientSd, F_SETFL, O_NONBLOCK );
					ssErr = SSErrNone;
				}
			}
		}
	}

	return ssErr;
}
