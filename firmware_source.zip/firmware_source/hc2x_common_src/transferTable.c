/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2013, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 

#include "transferTable.h"

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_Init

			Zero out the tables.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TransferTable_Init( struct TRANSFER_TABLE* pTable )
{
	if ( pTable )
	{
		memset( &(pTable->configuration), 0, sizeof(struct CONFIGURATION) );
		memset( &(pTable->tablePrimary), 0, sizeof(struct PRIMARY_TABLE) );
		memset( &(pTable->tableSecondary), 0, sizeof(struct SECONDARY_TABLE) );
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_SecondaryGetAI

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD TransferTable_SecondaryGetAI( struct TRANSFER_TABLE* pTable, int index )
{
	WORD wReturn = 0;

	if ( pTable )
	{
		if ( index < COUNT_ANALOG_INPUTS )
		{
			wReturn = pTable->tableSecondary.analogIn[ index ];
		}
	}

	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_SecondaryGetDigitalIn

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TransferTable_SecondaryGetDigitalIn( struct TRANSFER_TABLE* pTable, int index )
{
	BOOL bReturn = 0;

	if ( pTable )
	{
		if ( index < MAX_DIGITAL_INPUTS )
		{
			bReturn = pTable->tableSecondary.digIn[ index ];
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_SecondaryGetTdmOffset

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD TransferTable_SecondaryGetTdmOffset( struct TRANSFER_TABLE* pTable, int index )
{
	WORD wReturn = 0;

	if ( pTable )
	{
		if ( index < MAX_ANALOG_INPUTS )
		{
			wReturn = pTable->tableSecondary.tdmOffset[ index ];
		}
	}

	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_SecondaryGetFlags

			Returns the status flags.

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD TransferTable_SecondaryGetFlags( struct TRANSFER_TABLE* pTable )
{
	DWORD wReturn = 0;

	if ( pTable )
	{
		wReturn = pTable->tableSecondary.statusFlags;
	}

	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_PrimarySetTPO

			Sets the value at the given index.
			Returns TRUE if successful.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TransferTable_PrimarySetTPO( struct TRANSFER_TABLE* pTable, int index, DWORD dwValue )
{
	BOOL bReturn = FALSE;

	if ( pTable )
	{
		if ( index < MAX_ANALOG_OUTPUTS )
		{
			pTable->tablePrimary.tpo[ index ] = dwValue;
			bReturn = TRUE;
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_PrimarySetDigitalOut

			Sets the value at the given index.
			Returns TRUE if successful.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TransferTable_PrimarySetDigitalOut( struct TRANSFER_TABLE* pTable, int index, BOOL bValue )
{
	BOOL bReturn = FALSE;

	if ( pTable )
	{
		if ( index < MAX_DIGITAL_OUTPUTS )
		{
			pTable->tablePrimary.digOut[ index ] = bValue;
			bReturn = TRUE;
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_Compare

			Returns TRUE if all the data items match.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TransferTable_Compare( struct TRANSFER_TABLE* pTable1, struct TRANSFER_TABLE* pTable2 )
{
	BOOL bReturn = FALSE;
	int i = 0;

	if ( pTable1 && pTable2 )
	{
		// Assume success.
		bReturn = TRUE;

		//
		// Primary Table
		//
		for ( i = 0; (i < MAX_ANALOG_OUTPUTS) && bReturn; i++ )
		{
			if ( pTable1->tablePrimary.tpo[i] != pTable2->tablePrimary.tpo[i] )
			{
				//printf( "TransferTable_Compare: tables differ at tablePrimary.tpo[%d]: (%.2x)(%.2x)\n",
				//	i, pTable1->tablePrimary.tpo[i], pTable2->tablePrimary.tpo[i] );
				bReturn = FALSE;
			}
		}

		for ( i = 0; (i < MAX_DIGITAL_OUTPUTS) && bReturn; i++ )
		{
			if ( pTable1->tablePrimary.digOut[i] != pTable2->tablePrimary.digOut[i] )
			{
				//printf( "TransferTable_Compare: tables differ at tablePrimary.digOut[%d]: (%.2x)(%.2x)\n",
				//	i, pTable1->tablePrimary.digOut[i], pTable2->tablePrimary.digOut[i] );
				bReturn = FALSE;
			}
		}

		//
		// Secondary Table
		//
		for ( i = 0; (i < COUNT_ANALOG_INPUTS) && bReturn; i++ )
		{
			if ( pTable1->tableSecondary.analogIn[i] != pTable2->tableSecondary.analogIn[i] )
			{
				//printf( "TransferTable_Compare: tables differ at tableSecondary.analogIn[%d]: (%.2x)(%.2x)\n",
				//	i, pTable1->tableSecondary.analogIn[i], pTable2->tableSecondary.analogIn[i] );
				bReturn = FALSE;
			}
		}

		for ( i = 0; (i < MAX_ANALOG_INPUTS) && bReturn; i++ )
		{
			if ( pTable1->tableSecondary.tdmOffset[i] != pTable2->tableSecondary.tdmOffset[i] )
			{
				//printf( "TransferTable_Compare: tables differ at tableSecondary.tdmOffset[%d]: (%.2x)(%.2x)\n",
				//	i, pTable1->tableSecondary.tdmOffset[i], pTable2->tableSecondary.tdmOffset[i] );
				bReturn = FALSE;
			}
		}

		for ( i = 0; (i < MAX_DIGITAL_INPUTS) && bReturn; i++ )
		{
			if ( pTable1->tableSecondary.digIn[i] != pTable2->tableSecondary.digIn[i] )
			{
				//printf( "TransferTable_Compare: tables differ at tableSecondary.digIn[%d]: (%.2x)(%.2x)\n",
				//	i, pTable1->tableSecondary.digIn[i], pTable2->tableSecondary.digIn[i] );
				bReturn = FALSE;
			}
		}

		if ( pTable1->tableSecondary.statusFlags != pTable2->tableSecondary.statusFlags )
		{
			//printf( "TransferTable_Compare: tables differ at tableSecondary.statusFlags: (%.2x)(%.2x)\n",
			//	pTable1->tableSecondary.statusFlags, pTable2->tableSecondary.statusFlags );
			bReturn = FALSE;
		}

		//
		// Configuration Table
		//
		if ( pTable1->configuration.byte1 != pTable2->configuration.byte1 )
		{
			//printf( "TransferTable_Compare: tables differ at configuration.byte1: (%.2x)(%.2x)\n",
			//	pTable1->configuration.byte1, pTable2->configuration.byte1 );
			bReturn = FALSE;
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TransferTable_DebugFill

			Fills the table with dummy data.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TransferTable_DebugFill( struct TRANSFER_TABLE* pTable )
{
	int i = 0;

	if ( pTable )
	{
		//
		// Primary Table
		//
		for ( i = 0; i < MAX_ANALOG_OUTPUTS; i++ )
		{
			pTable->tablePrimary.tpo[i] = i;
		}

		for ( i = 0; i < MAX_DIGITAL_OUTPUTS; i++ )
		{
			pTable->tablePrimary.digOut[i] = 0;
			if ( (i % 2) == 0 )
			{
				pTable->tablePrimary.digOut[i] = 1;
			}
		}

		//
		// Secondary Table
		//
		for ( i = 0; i < COUNT_ANALOG_INPUTS; i++ )
		{
			pTable->tableSecondary.analogIn[i] = i;
		}

		for ( i = 0; i < MAX_ANALOG_INPUTS; i++ )
		{
			pTable->tableSecondary.tdmOffset[i] = i;
		}

		for ( i = 0; i < MAX_DIGITAL_INPUTS; i++ )
		{
			pTable->tableSecondary.digIn[i] = 0;
			if ( (i % 2) == 0 )
			{
				pTable->tableSecondary.digIn[i] = 1;
			}
		}

		pTable->tableSecondary.statusFlags = 0xAA55;

		//
		// Configuration Table
		//
		pTable->configuration.byte1 = 0xA5;
	}
}
