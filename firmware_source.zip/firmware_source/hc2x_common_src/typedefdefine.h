/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999 - 2014, All Rights Reserved
                    Company Confidential

	File:			typedefdefine.h

	Description:	main define file 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __TYPE_HELLER_H__
#define __TYPE_HELLER_H__

#include <linux/module.h>
#include <linux/kernel.h>

#include <stddef.h>
#include "hellerconversions.h"

#define WARNING_TYPE_AUDILE_OFFSET 6 //Added to return to indicate the audible output should be on
#define WARNING_TYPE_ALL_AUDIBLE 13 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_SECSGEM_BOTH_RED_AUDIBLE 12 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_SECSGEM_BOTH_YELLOW_AUDIBLE 11 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_SECSGEM_BOTH_AUDIBLE 10 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_SECSGEM_RED_AUDIBLE 9 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_SECSGEM_YELLOW_AUDIBLE 8 //WARNING_TYPE_ALL + WARNING_TYPE_AUDILE_OFFSET
#define WARNING_TYPE_ALL 7
#define WARNING_TYPE_SECSGEM_BOTH_RED 6
#define WARNING_TYPE_SECSGEM_BOTH_YELLOW 5
#define WARNING_TYPE_SECSGEM_BOTH 4
#define WARNING_TYPE_SECSGEM_RED 3
#define WARNING_TYPE_SECSGEM_YELLOW 2
#define WARNING_TYPE_STANDARD 1

#define BIT_CONVEYOR_BLOWER 0x1
#define BIT_SMEMA1_OUT 0x2
#define BIT_SMEMA2_OUT 0x4
#define BIT_SMEMA3_OUT 0x8
#define BIT_SMEMA4_OUT 0x10
#define BIT_SECSGEML1 0x100
#define BIT_SECSGEML2 0x200
#define BIT_SECSGEML3 0x400
#define BIT_SECSGEML4 0x800
#define SECSGEM_WARN_RLT1 0x4000
#define SECSGEM_WARN_RLT2 0x8000

//defines for system add parameters boolean VIII
#define	SECSGEM_WARN_RLT3 0x0001
#define	SECSGEM_WARN_RLT4 0x0002
#define	SECSGEM_AUDIBLE1 0x0004
#define	SECSGEM_AUDIBLE2 0x0008
#define	SECSGEM_AUDIBLE3 0x0010
#define	SECSGEM_AUDIBLE4 0x0020

#define SECSGEM_LANE_RED 1 

#define MES_INDEX 0
#define APCO_INDEX 1
#define NUM_FILE_CONTROLLED_SMEMA 2
#define NEW_RECIPE_TIME_S2 50
#define BOARD_LOAD_DEFAULT 10
#define	DEFAULT_DELAYPERIOD10TH 300
#define	DEFAULT_RISERATE_PERIOD 200
#define	DEFAULT_RISE_DEGREES 50
#define DEFAULT_DRAW_WARNING 5
#define DEFAULT_STARTUP_POWER_COUNTS 204
#define DEFAULT_RESEQUENCE 3
#define SM_MACHINE_STATUS_READY 0
#define SM_MACHINE_STATUS_WAIT 1
#define SM_MACHINE_STATUS_INITHIGH 2
#define SM_MACHINE_STATUS_LOW 3
#define SM_MACHINE_STATUS_COMPLETE 4
#define STARTUP_GROUPS 32
#define STARTUP_GROUPS_PLUSONE 33
#define MINIMUM_READ_DELAY 3
#define MAX_SMEMA_HOLD_SECONDS (3*60)
#define RISE_RATE_MARGIN 100

#define COMM_LOSS_JIFFIES 5000
#define KIRP_IOCTL_BUFFER_SIZE 13000
#define PORT 1101   // port we're listening on
#define TIMEOUT_FOR_SECONDARY_COMM 10000 //1 jiffie per millisecond, 10 seconds, 10000
#define NUMBER_POSSIBLE_CONTROL_BOARDS 2

#define BCIO_DETECT_TIME 20
#define DEFAULT_ALLOW_TIME_BARCODE 100

#define TENTHS_IN_A_SECOND 10
#define FREQUENCY100MS 10
#define GET_PV_COMMAND				3000000
#define GET_PVT_COMMAND				4000000
#define SET_PVT_COMMAND				5000000
#define MASS_COLLECT_AI_PV_TPO_SA	7000000
#define SET_RECIPE_COMMAND			8000000

#define DEFAULT_NITRO_PURGE_PERIOD 6000
#define DEFAULT_NITRO_NORMAL_PERIOD 3000

#define L1_NONE_L2_NONE 0
#define L1_NONE_L2_TIMED 1
#define L1_NONE_L2_BEAM 2
#define L1_NONE_L2_BOTH 3
#define L1_TIMED_L2_NONE 4
#define L1_TIMED_L2_TIMED 5
#define L1_TIMED_L2_BEAM 6
#define L1_TIMED_L2_BOTH 7
#define L1_BEAM_L2_NONE 8
#define L1_BEAM_L2_TIMED 9
#define L1_BEAM_L2_BEAM 10
#define L1_BEAM_L2_BOTH 11
#define L1_BOTH_L2_NONE 12
#define L1_BOTH_L2_TIMED 13
#define L1_BOTH_L2_BEAM 14
#define L1_BOTH_L2_BOTH 15

#define MASS_A								0x01
#define MASS_B								0x02
#define MASS_C								0x04
#define MASS_D								0x08
#define MASS_E								0x10
#define MASS_UINT_A							0x20	
#define MASS_UINT_B							0x40
#define MASS_UINT_C							0x80
#define MASS_UINT_D							0x100
#define MASS_UINT_E							0x200
#define MaxNameLength			20

#define TENTHS_IN7_SECONDS 70
#define OUTPUT_INVALID_INDEX 100
#define SAFE_SEGMENT_CONTROL 0x01
#define SAFE_SEGMENT_BUFFER 0x02

#define DEFAULT_HIGH_PROCESS 2000
#define DEFAULT_GLOBAL_HIGH_PROCESS 4500
#define SOUND_NOT_DEFINED 2

#define BLOWER_FAIL_ALARM_DEFAULT 300
#define BLOWER_FAIL_WARNING_DEFAULT 150
#define STANDBY_MODE1_DEFAULT 100

// masks for secondary HC-2 IOANALOGIN TDM_0_GND0
#define	TDM0_VERSION_ERROR	1
#define	TDM0_CRC_ERROR		2
#define	TDM1_VERSION_ERROR	4
#define	TDM1_CRC_ERROR		8
#define	HC2_MONITOR_ERROR	0x10

#define TRUE		1
#define FALSE		0
typedef unsigned long		DWORD;
typedef unsigned short	WORD;
typedef int							BOOL;
typedef unsigned char		UCHAR, *PUCHAR;
typedef char				CHAR,  *PCHAR;
typedef unsigned int		UINT;
typedef unsigned char       BYTE;
typedef long LONG;
typedef unsigned short USHORT;
typedef short SHORT;
typedef unsigned long	ULONG;

typedef long NTSTATUS;
typedef void VOID;

#define STATUS_SUCCESS	0

#define MONITOR_SEQUENCE 0x01
#define CONTROL_SEQUENCE 0x06 //sum of  bProcess 0x2 and startup with job 0x04
#define BPROCESS 0x02
#define STARTUP_WITHJOB 0x04
#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0)

//
// Generic test for information on any status value.
//
//
#define NT_INFORMATION(Status) ((ULONG)(Status) >> 30 == 1)

//
// Generic test for warning on any status value.
//
#define NT_WARNING(Status) ((ULONG)(Status) >> 30 == 2)

//
// Generic test for error on any status value.
//
#define NT_ERROR(Status) ((ULONG)(Status) >> 30 == 3)

#define STATUS_PENDING                   ((NTSTATUS)0x00000103L)
#define STATUS_INVALID_PARAMETER         ((NTSTATUS)0xC000000DL)
#define STATUS_BUFFER_TOO_SMALL          ((NTSTATUS)0xC0000023L)
#define STATUS_DRIVER_INTERNAL_ERROR     ((NTSTATUS)0xC0000182L)
#define STATUS_DATA_ERROR                ((NTSTATUS)0xC000003EL)


#define L1_INCLUDE 1
#define L2_INCLUDE 0
#define L3_INCLUDE 0

#define FILTER_COUNT_FOR_BOARD_INPUT 2
#define RECIPE_LOAD_TIMEOUT 1200 //time in tenths of seconds 2 minutes * 60 * 10
#define SECONDS_INA_MINUTE 60

#define DS_FLOW0 0
#define DS_FLOW_NORMAL 1
#define DS_FLOW_STANDBY 2

#define BOARD_COUNT_PURGE 15

#define ROUND_FACTOR_TPO 50
#define MAX_TPOS 32
#define MAX_LOT_COUNT				3  //Note if this is changed LotProcessing_lotRemoveByIndex defrag will need adjustment
//also define in hellercommctl.h will need to match
#define MAX_CARRIER_EVENT_COUNT		512
#define MAX_BELT 2

#define TH_STARTUPGROUP 100

//boolean VII for system add paramters
#define	BLOWER_DISPLAY_ONMAIN_WINDOW		0x01
#define	DISABLE_AUDIBLE_SILENCE_BUTTON		0x02
#define ECLIGHT_TOWER						0x04
#define APCO_OPTION							0x08
#define OPTIONAL_PEGATRON_HEADER			0x10
#define APCO_RUNTIME_SETTING				0x20
#define AUTOCLEAN_ON_COOLDOWN				0x40
#define CONTROL_OUTPUT_RELAY_ENABLE			0x80
#define SECSGEM_ENTRY_CONTROL				0x0100

//boolean IV for system add paramters
#define ENERGY_STANDBY 0x01
#define ENERGY_COOLDOWN 0x02
#define CA3_WARNING_PARAM 0x04
#define CA3_ALARM_PARAM 0x08
#define CA3_AUDIBLE 0x10
#define CA3_DIST 0x20
#define CA3_CHECKED 0x40
#define CA3_ACTIVE_HIGH 0x80
#define CA3_OUTPUT_WARN 0x100
#define CA3_OUTPUT_ALARM 0x200
#define LT_MINUTE 0x400
#define LT_HOURS 0x800
#define LT_ACTIVE_HIGH 0x1000
#define LT_L1 0x2000
#define LT_L2 0x4000
#define LT_L3 0x8000

//boolean V for system add paramters
#define LT_L4								0x1
#define LT_SPECIAL_ENABLE					0x2
#define LT_ALL_LAMPS_OFF					0x4
#define LT_LAMP_MODE_AUTO					0x8
#define LT_LAMP_SOLID						0x10
#define PER_LANE_AUDIBLE					0x20
#define OUTPUT_COOLING_PID					0x40
#define COOLING_PID_INCOOLDOWN				0x80
#define COOLING_SEQUENCED					0x100
#define DO_ON_BOARDCOUNT					0x200
#define DO_BOARDCOUNT_ACTION				0x400
#define BLOWERS_H100_AT_STARTUP				0x800
#define	ENERGY_GLOBAL_INTELEXHAUST			0x1000
#define	ENERGY_STDBY_MODE1					0x2000
#define	ENERGY_N2_LOW						0x4000
#define	ENERGY_N2_OFF						0x8000

//defines for system add parameters boolean VI
#define	ENERGY_STDBY_MODE1_CONVEYOR			0x1
#define	ENERGY_STDBY_MODE1_START			0x2
#define	ENERGY_STDBY_MODE1_STOP				0x4
#define	ENERGY_STDBY_LOAD_RECIPE			0x8
#define NO_COOLDOWN_ON_RISE_RATE			0x800

#define CLASSIC_BLOWERS 1
#define STANDBY_BLOWERS 2
#define INTELLIGENT_EXHAUST 3

#define RUN_LEVEL_LOW 0
#define RUN_LEVEL_MEDIUM 1
#define RUN_LEVEL_HIGH 2
#define RUN_LEVEL_NORMAL 3
#define MAX_TPO_COUNTS						256
#define TWO_INCHES_AT_788_PULSES_PER_CM		4003
#define THREE_MINUTE_DELAY				1800	// a three minute delay is 1800 tenths of seconds.
#define FIVE_SECOND_DELAY			50        // a five minute delay is 3000 counts
#define STALLED_MOTOR_DELAY_TIME	50		// if the motor has not moved in this time consider it stalled.
#define RAIL_SEQUENCE_DELAY_10THS	20		// the delay before starting the next rail in motion.
#define RAILS_JOG_FAIL_TIME_10THS   9000
#define OVERTEMP_DELAY_TIME				50		// wait 5 seconds before sending overtemp alarm.
#define DIOC_GETDBCONTAIN_ADDRESS 0x3000
#define DIOC_SCAN_ENABLE					0X3001
#define MAX_RECIPE_NAME_LENGTH		256

#define COEFFDENOM					65535
#define ACOEFF						6553
#define ONEMINUSACOEFF				58982


#define LIGHTTOWERONDELAY 50            // these defines are for the on delay function in the lightower
#define LIGHTTOWERONDELAY_RESET 0

#define ALARMCONDITION_NONE 0
#define ALARMCONDITION_NORMAL 1
#define ALARMCONDITION_SPECIAL 2

//Color definitions
#define CONDITION_TRANSITION 0 //white
#define CONDITION_GREEN 1
#define CONDITION_YELLOW 2
#define CONDITION_SUSPENDED 9
//end color definitions

//struct SECONDARY_TABLE is 500 bytes, if it exceeds 512 driver read will need to modify the read
//routine in the hc2xctl.o secondary, the below defines affect the size
#define MAX_DIGITAL_INPUTS		64		// just so happens they're all the same
#define MAX_DIGITAL_OUTPUTS		56  	// this could change at any time though.
#define MAX_ANALOG_INPUTS		60
#define MAX_ANALOG_OUTPUTS		40
//see above note
 
//******************************************************************************
// Alarm Codes
//******************************************************************************
#define RAIL_HOME_TIME_ELAPSED	1
#define STALLED_MOTOR			2

#define MaxBelts 	2
#define MaxRails	4
#define NUM_QUEUES	4

#define MAXZONES 				24					// 12 upper and 12 lower
#define MAXGROUPS				12 					// two zones to a group
#define POSSIBLE_FLUXHEATERS	3
#define SCANTIME				100					// in milliseconds

#define MAX_CALARMS				2					// meaning only 1 and 2
#define MAX_CALARMS_BOTH_TYPES	5					// meaning 1 through 5

#define CUSTOM_ALARM1			0
#define CUSTOM_ALARM2			1
#define CUSTOM_ALARM3			2
#define CUSTOM_ALARM4			3
#define CUSTOM_ALARM5			4

#define MAX_SMEMA_LANES			4
#define MAX_FLUXHEATERS			5
#define MAX_BLOWERS_INCLUDING_FANS 5
#define GLOBAL_BLOWER_INDEX 5
#define ANALOG_FAN_INDEX 4
#define MAXIMUM_PERCENTAGE 100
#define DEFAULT_FLUXHEATERDELAY 24000
#define DEFAULT_COOLING_PERIOD 64
#define FLUX0 0
#define FLUX1 1
#define FLUX2 2
#define FLUX3 3
#define FLUX4 4
//******************************************************************************
// Alarm Codes
//******************************************************************************
// Tempzone Errors
#define TZ_HI_PROCESS_ALARM						1000
#define TZ_LO_PROCESS_ALARM						1001	
#define TZ_HI_DEVIATION_ALARM					1002
#define TZ_LO_DEVIATION_ALARM					1003
#define TZ_HI_DEVIATION_WARNING					1004
#define TZ_LO_DEVIATION_WARNING					1005
#define TZ_RISERATE_ALARM						1006

//New tempzone defines for secondary board
#define TZ_HI_PROCESS_ALARM_SEC					1014							
#define TZ_LO_PROCESS_ALARM_SEC					1015			
#define TZ_HI_DEVIATION_ALARM_SEC				1016		
#define TZ_LO_DEVIATION_ALARM_SEC				1017	
#define TZ_HI_DEVIATION_WARNING_SEC				1018	
#define TZ_LO_DEVIATION_WARNING_SEC				1019		
#define TZ_RISERATE_ALARM_SEC					1020
#define SECONDARY_BOARD_OUT						1021

//still more tempzone errors
#define TZ_DRAW_WARNING_WARNING					1028
#define TZ_STARTUP_GROUP_CALLED					1029
#define TZ_OPEN_THERMO							1030
#define TZ_OPEN_THERMO_SEC						1031
#define TZ_HI_PROC_INFO_EVENT					1032
#define TZ_HI_PROC_INFO_EVENT_SEC				1033
#define TZ_GLB_OVERTEMP							1034

#define TZ_SLAVE_COMM_FAILURE					1035
#define TZ_BLOWER_OFF							1036

#define FLUXHEATER_HI_PROCESS_ALARM				1007
#define FLUXHEATER_LO_PROCESS_ALARM				1008	
#define FLUXHEATER_HI_DEVIATION_ALARM			1009
#define FLUXHEATER_LO_DEVIATION_ALARM			1010
#define FLUXHEATER_HI_DEVIATION_WARNING			1011
#define FLUXHEATER_LO_DEVIATION_WARNING			1012
#define FLUXHEATER_RISERATE_ALARM				1013

//New fluxheater alarms for secondary board
#define FLUXHEATER_HI_PROCESS_ALARM_SEC			1022
#define FLUXHEATER_LO_PROCESS_ALARM_SEC			1023	
#define FLUXHEATER_HI_DEVIATION_ALARM_SEC		1024
#define FLUXHEATER_LO_DEVIATION_ALARM_SEC		1025
#define FLUXHEATER_HI_DEVIATION_WARNING_SEC		1026
#define FLUXHEATER_LO_DEVIATION_WARNING_SEC		1027

#define	HEATER_TEMP_ZONE_CURRENT_LOW			1037
#define	HEATER_TEMP_ZONE_FAILURE				1038
#define	HEATER_FLUX_ZONE_CURRENT_LOW			1039
#define	HEATER_FLUX_ZONE_FAILURE				1040
#define	MODBUSCURRENT_COMM_FAILURE				1041
#define	HEATER_TEMP_ZONE_CURRENT_HIGH			1042
#define	HEATER_FLUX_ZONE_CURRENT_HIGH			1043
#define	COOLPIPE_BLOCKAGE						1044

#define RAIL_STALLED_MOTOR						2000
#define RAIL_3MIN_TIMEOUT_WARNING				2001
#define RAIL_BOARD_IN_OVEN						2002
#define RAILS_COUNT_WRONG_DIRECTION				2003
#define RAIL_1MIN_NOTATPRESET_WARNING			2004
#define RAIL_FAILED_PRESET						2005
#define RAILS_JOG_INIT							2006
#define RAILS_JOG_COMPLETE						2007
#define RAILS_JOG_CBS_SWITCH					2008
#define RAILS_JOG_FAILED						2009

#define SECSGEM_WARN1							2055
#define SECSGEM_WARN2							2056
#define SECSGEM_WARN3							2057
#define SECSGEM_WARN4							2058

#define COMM_LOSS_OF_COMM_ALARM					3000
#define COMM_OVERRUN_WARNING					3001
#define COMM_TIMER_LOSS_ALARM					3002

#define	HIGH_H2O_TEMP_ALARM						4000		// jwf 2/21/01
#define NITROGEN_LO_PRESSURE_ALARM				4001
#define NITROGEN_FULL_PURGE_WARNING				4002
#define NITROGEN_LO_PRESSURE_WARNING			4003
#define	HIGH_H2O_TEMP_WARNING					4004

#define BOARD_DROP_WARNING						5000
#define BOARD_BACKUP_WARNING					5001
#define BOARD_DROP_WARNING_2					5002
#define BOARD_BACKUP_WARNING_2					5003
#define BOARD_DROP_WARNING_3					5004
#define BOARD_BACKUP_WARNING_3					5005
#define BOARD_DROP_WARNING_4					5006
#define BOARD_BACKUP_WARNING_4					5007
#define BOARD_BACKUP_CLEARED					5008
#define BOARD_BACKUP_CLEARED2					5009
#define BOARD_BACKUP_CLEARED3					5010
#define BOARD_BACKUP_CLEARED4					5011
#define BOARD_ADDED								5012
#define BOARD_EXITED							5013
#define BOARD_ADDED2							5014
#define BOARD_EXITED2							5015
#define BOARD_ADDED3							5016
#define BOARD_EXITED3							5017
#define BOARD_ADDED4							5018
#define BOARD_EXITED4							5019
#define SMEMA_EXIT_ERR							5020
#define SMEMA_EXIT_ERR1							5021
#define SMEMA_EXIT_ERR2							5022
#define SMEMA_EXIT_ERR3							5023
#define BOARD_ENTRANCE_JAM1						5024
#define BOARD_ENTRANCE_JAM2						5025
#define BOARD_ENTRANCE_JAM3						5026
#define BOARD_ENTRANCE_JAM4						5027
#define BOARD_DROP_INFO							5028

#define PROCESS_OVERRUN_WARNING					6000

#define BELT_HI_PROCESS_ALARM					7001
#define BELT_LO_PROCESS_ALARM					7002
#define BELT_HI_DEVIATION_ALARM					7003
#define BELT_LO_DEVIATION_ALARM					7004
#define BELT_HI_DEVIATION_WARNING				7005
#define BELT_LO_DEVIATION_WARNING				7006
#define BELT_HI_ACTIVE_OUTPUT					7007
#define BELT_LO_ACTIVE_INPUT					7008
#define	BELT_DIGITAL_STOP_ON					7009
#define	BELT_DIGITAL_STOP_OFF					7010
#define	BELT_DIGITAL_STOP_WARNING				7011

#define BARCODE_HOLD_SMEMA						8001 
#define BARCODE_RECORD_HOLD						8002
#define BARCODE_SMEMA_FREED						8003
#define BARCODE_ERROR_MISMATCH					8004
#define BARCODE_READ_ERROR						8005 
#define BARCODE_STATUS_ERROR					8006 
#define BARCODE_APP_TERMINATED 					8007
#define BARCODE_APP_INIT						8008
#define BARCODE_TIMEOUT							8009 
#define E_STOP_ALARM								9000
#define POWER_FAILURE_ALARM							9001
#define LOW_EXHAUST_ALARM							9002
#define FLUX_FILTER_CLEANING_REQUIRED				9003
#define FLUX_FILTER_DOOR_OPEN						9004
#define OVEN_MAINTENANCE_REQUIRED					9005
#define OVERTEMP_ALARM								9006
#define OVER_CURRENTDRAW							9007
#define FLUXCONDENSOR_CYCLE_START					9008
#define FLUXCONDENSOR_CYCLE_COMPLETE				9009
#define FLUXCONDENSOR_CYCLE_TERMINATED_BY_OPERATOR  9010 
#define FLUXCONDENSOR_CYCLE_TERMINATED				9011
#define FLUXCONDENSOR_AUTO_CYCLE_START				9012
#define FLUXCONDENSOR_MANUAL_CYCLE_START			9013
#define FLUXCONDENSOR_CYCLE_INTERRUPTED				9014 
#define LOW_EXHAUST_WARNING							9015
#define AUTOLUBE_CYCLE_ACTIVATED					9016
#define HEAT_FAN_FAULT_ALARM_CODE					9017
#define PPM_EXCEEDS_ALARM1_WARNING					9018
#define PPM_EXCEEDS_ALARM2_WARNING					9019
#define DANSENSOR_CONNECTION_BROKEN					9020
#define POWER_FAILURE_EVENT							9021
#define FLUXCONDENSOR_CYCLE_ABORTED					9022
#define FLUXCONDENSOR_TIMERS_STARTED				9023
#define FLUX_BLOWER_OFF								9024
#define AUTOLUBE_CYCLE_ACTIVATED_2					9025
#define FLUXCONDENSOR_RECIPE_ERROR					9026
#define PURGE_STATED								9027 
#define PURGE_TERMINATED							9028
#define COOLDOWN_DELAY_ELAPSED						9029
#define COOLDOWN_COUNTDOWN_STARTED					9030
#define COOLDOWN_COUNTDOWN_ABORTED					9031
#define DANSENSOR_NOT_CONNECTIONED					9032 //yellow lighttower when dansensor has not yet connected
#define DANSENSOR_STOPPED							9033
#define FLUXCON_PHASE1								9034
#define FLUXCON_PHASE2								9035
#define MAIN_TIMER_ACTIVE							9036
#define NITRO_LOW									9037
#define NITRO_MEDIUM								9038
#define NITRO_HIGH									9039
#define NITRO_OFF									9040
#define MANUAL_RAIL_MODE_STARTED					9041
#define MANUAL_RAIL_MODE_EXITED						9042
#define CUSTOM_MESSAGE_INITED						9043
#define ALARM2_EXCEEDS_PPM_WARNING				9044
#define DS_PRIMARY_PPM_SET							9045
#define DS_STANDBY_PPM_SET							9046
#define DS_PPM_SET_FAILED							9047
#define DS_ALARM1_SET_FAILED						9048
#define DS_PRIMARY_ALARM1_SET						9049
#define DS_STANDBY_ALARM1_SET						9050
#define BELT_MOTOR_SWITCH							9051
#define BELT_MOTOR_SWITCHB							9052
#define INPUT_LOW									9053
#define TM_OUTPUT_ON								9054
#define TM_OUTPUT_OFF								9055
#define FILE_IO_ERROR								9056
#define SPRAY_ON									9057
#define SPRAY_TERMINATED						9058
#define COOLDOWN_MODE_LOAD					9059 //Code not added, define is for future addition
#define CUSTOM_MESSAGE_INITED2				9060
#define RECIPE_SAVE_FAILED						9061
#define DTO_INPUT									9062
#define DTO_FINISHED								9063
#define DTO_STARTED								9064
#define FLUX_FILTER_DOOR_CLOSED				9065
#define SCHEDULED_EVENT_ABORT				9066
#define BOARD_CLEARED_COOLDOWN				9067
#define BOARD_COOLDOWN_WAIT				9068
#define DS_ALARM1_ACK					9069
#define DS_CONNECT_ACK					9070
#define DS_ALARM2_ACK					9071
#define HEAT_FAN_FAULT_WARN_CODE			9072
#define HEAT_FAN_FAULT_WARN_CODE_NONAUDIBLE		9073
#define TZ_CJC_LOW					9074
#define SLAVE_COMM_LOSS_TIMEOUT				9082
#define TZ_RISERATE_WARN				9083
#//define SECONDARY_BOARD_COMM_LOSS			9084
#define MODBUSCURRENT_PORT_IN_USE			9084
#define MODBUSCURRENT_CLIENT_NO_RESPONSE  		9085
#define MODBUSCURRENT_INVALID_RESPONSE 			9086
#define MODBUSCURRENT_SUCCESSFUL_CONNECTION		9087
#define BOARD_LOG_RECORD1				9088
#define BOARD_LOG_RECORD2				9089
#define BOARD_LOG_RECORD3				9090
#define BOARD_LOG_RECORD4				9091

/* The following alarm definitions are identical
   to those defined in 5.5.0.x.  Some are not 
   currently used in 6.2.0.x, but will be implemented
   sometime in the future.
*/
#define MODBUSBLOWER_COMM_ERR_S1					9092
#define MODBUSBLOWER_COMM_ERR_S2					9093

#define NO_TDM_VERSION0			9100
#define NO_TDM_VERSION1			9101
#define NO_TDM_VERSION0SEC		9102
#define NO_TDM_VERSION1SEC		9103
#define CHECKSUM_ERROR0			9104
#define CHECKSUM_ERROR1			9105
#define CHECKSUM_ERROR0SEC		9106
#define CHECKSUM_ERROR1SEC		9107

#define LT_YELLOW_TO_GREEN							9108
#define LT_GREEN_TO_YELLOW							9109
/* End of 5.5.0.x compatible alarms
*/
#define LT2_YELLOW_TO_GREEN				9110
#define LT2_GREEN_TO_YELLOW				9111


#define TEMPZONE_SEQ_COMPLETE			9112
#define TEMPZONE_SEQ_COMPLETE_TIMER		9113 // a hardcoded 2min timeout expired after the seq completed.
#define	BLOWER_RPM_ALARM				9114
#define	BLOWER_GENERAL_ERROR			9115
#define IE_HIGH_LEVEL					9116
#define IE_MED_LEVEL					9117
#define IE_LOW_LEVEL					9118
#define IN_STANDBY						9119
#define OUT_STANDBY						9120
#define	ENTERING_ENERGY_MODE			9121
#define EXIT_ENERGY_MODE				9122
#define ENTERING_ENERGY_COOLDOWN		9123
#define CA3_WARNING						9124
#define CA3_ALARM						9125
#define IN_SEC_YELLOW					9126
#define OUT_SEC_YELLOW					9127
#define RECIPE_PARAM_FAILED				9128

#define DUALBC_RECMISMATCH_LANE1		9129
#define DUALBC_RECMISMATCH_LANE2		9130
#define DUALBC_RECMISMATCH_LANE3		9131
#define DUALBC_RECMISMATCH_LANE4		9132

#define DUALBC_BELTSPEEDMISMATCH_LANE1	9133
#define DUALBC_BELTSPEEDMISMATCH_LANE2	9134
#define DUALBC_BELTSPEEDMISMATCH_LANE3	9135
#define DUALBC_BELTSPEEDMISMATCH_LANE4	9136

#define DUALBC_RAILWIDTHMISMATCH_LANE1	9137
#define DUALBC_RAILWIDTHMISMATCH_LANE2	9138
#define DUALBC_RAILWIDTHMISMATCH_LANE3	9139
#define DUALBC_RAILWIDTHMISMATCH_LANE4	9140

#define DUALBC_COMPORTFAIL_LANE1		9141
#define DUALBC_COMPORTFAIL_LANE2		9142
#define DUALBC_COMPORTFAIL_LANE3		9143
#define DUALBC_COMPORTFAIL_LANE4		9144

#define DUALBC_SCAN_LANE1				9145
#define DUALBC_SCAN_LANE2				9146

#define DUALBC_BADBARCODE_LANE1			9147
#define DUALBC_BADBARCODE_LANE2			9148
#define DUALBC_BADBARCODE_LANE3			9149
#define DUALBC_BADBARCODE_LANE4			9150

#define OUT_FLUSH2						9151

#define DUALBC_HOLD_SMEMA_LANE1			9152
#define DUALBC_HOLD_SMEMA_LANE2			9153
#define DUALBC_HOLD_SMEMA_LANE3			9154
#define DUALBC_HOLD_SMEMA_LANE4			9155

#define BARCODE_SMEMA_FREED_LANE		9156
#define MULTIPLE_MES_FILES				9157
#define MES_WRONG_JOB					9158
#define MES_ERROR_CODE					9159
#define MES_VALID_SCAN					9160
#define MES_FILE_ERROR					9161
#define MES_FILE_READONLY				9162
#define FLUXHEATER_RISERATE_WARN		9163
#define RECIPE_START_FAILED				9164
#define IN_FLUSH2						9165
#define BCIO_SCANNED					9166
#define BARCODE_LOGGED					9167
#define BARCODE_FAILED_SCAN				9168
#define SLAVE_COMM_DEFAULT				9169
#define BLOWER_OUTPUT_OUTOFRANGE_HI		9170
#define BLOWER_OUTPUT_OUTOFRANGE_LO		9171

#define EXHAUSTSPEED_OUTOFRANGE			9172
#define MODESPEED_OUTOFRANGE			9173
#define IESPEED_OUTOFRANGE				9174

#define FLUX_BLOWER_FAILURE				9175
#define PPM_BAD_CHANNEL_GOOD			9176
#define DS_BADPPM_ACK					9177
#define DS_PPM_OFF_ACK					9178

#define APCO_NO_JOB_IN_LIST				9179
#define APCO_RECIPE_NOT_FOUND			9180
#define APCO_LOAD_DUE_MISMATCH			9181
#define LOT_MISMATCH					9182
#define APCO_SMEMA_ALLOWED				9183
#define APCO_SMEMA_DISALLOWED			9184
#define APCO_PLF_NOT_FOUND				9185
#define APCO_CF_NOT_FOUND				9186

#define AUTOCLEAN_ON_COOLDOWN_WARNING	9187
#define STARTUP_CONTROL_OUTPUT			9188

#define	LT_GREEN_TO_RED					9189
#define	LT_YELLOW_TO_RED				9190
#define	LT_OFF_TO_YELLOW				9191
#define	LT2_GREEN_TO_RED				9192
#define	LT2_YELLOW_TO_RED				9193
#define	LT2_OFF_TO_YELLOW				9194

#define CA4_WARNING						9195
#define CA4_ALARM						9196
#define CA5_WARNING						9197
#define CA5_ALARM						9198

#define COMM_OVERRUN_DIGITAL_IN		1
#define COMM_OVERRUN_DIGITAL_OUT	2
#define COMM_OVERRUN_ANALOG_IN		3
#define COMM_OVERRUN_ANALOG_OUT		4

#define PROCESS_OVERRUN_INPUT_PROCESSING	1
#define PROCESS_OVERRUN_SYSTEM_PROCESSING	2
#define PROCESS_OVERRUN_TEMPZONE_PROCESSING	3


#define COOLDOWN_SETPOINT							950			// converted to tenths of degrees

#define TEMP_ZONE_UPDATE_PERIOD_MS		1250   	// 1250ms = 1.25 seconds
#define LOW_NITROGEN_PRESSURE_TIMEOUT	150			// 15 seconds in tenths = 150 
#define POWER_FAIL_WARNING_TIME_10THS			30		//3 second warning timer for power failure
#define POWER_FAIL_TIME_10THS					150			// wait 15 seconds for power fluctuations
#define BOARD_EXIT_DETECTION_TIME_10THS	50		// wait 5 seconds for detecting a board to prevent false detections.
#define BOARD_DROP_TIME_OUT_10THS			5				// wait .5 seconds to verify board drop				
#define FLUX_FILTER_DOOR_OPEN_TIME		50			// wait 5 seconds before indicating flux filter is clean.
#define ONE_HOUR_10THS								36000		// the number of miliseconds in an hour.
#define TWENTY_MINUTES_TENTHS_SECONDS	12000		// wait 20 minutes before sending again.


#define Z1_UPPER  			0
#define Z1_LOWER           	1
#define Z2_UPPER           	2
#define Z2_LOWER           	3
#define Z3_UPPER           	4
#define Z3_LOWER           	5
#define Z4_UPPER           	6
#define Z4_LOWER           	7
#define Z5_UPPER           	8
#define Z5_LOWER           	9 
#define Z6_UPPER           	10
#define Z6_LOWER           	11
#define Z7_UPPER           	12
#define Z7_LOWER           	13
#define Z8_UPPER           	14
#define Z8_LOWER           	15
#define Z9_UPPER           	16
#define Z9_LOWER           	17
#define Z10_UPPER          	18
#define Z10_LOWER          	19 
#define Z11_UPPER          	20
#define Z11_LOWER          	21
#define Z12_UPPER          	22 
#define Z12_LOWER          	23


//******************************************************************************
// AnalogIO  - 16 Bit Values -32767 to 32768
// Reference Analogic Software Requirement Specification
// Document No. 91G-00574		RevA
//******************************************************************************
#define AI_TCPORT1 							    0
#define AI_TCPORT2	 						    1
#define AI_TCPORT3 							    2
#define AI_EXHAUST_FLUX_HEATER	                3
#define AI_UPZ1 								4
#define AI_LOWZ1						    	5
#define AI_UPZ2  								6
#define AI_LOWZ2   							    7
#define AI_UPZ3  								8
#define AI_LOWZ3   							    9
#define AI_UPZ4  								10
#define AI_LOWZ4   							    11
#define AI_UPZ5  								12
#define AI_LOWZ5   						        13
#define AI_UPZ6  						  	    14
#define AI_LOWZ6   						        15
#define TDM_0_GND0							    16
#define TDM_0_VSUPPLY_2					        17
#define	TDM_0_GJC0							    18
#define	TDM_0_GJC1							    19
#define TDM_0_GND1							    20
#define TDM_0_GND2							    21
#define TDM_0_GND3							    22
#define TDM_0_GND4							    23	
#define AI_TCPORT4						        24
#define AI_TCPORT5						        25
#define AI_UPZ7  						  	    26
#define AI_LOWZ7   						        27
#define AI_UPZ8  						  	    28
#define AI_LOWZ8   						        29
#define AI_UPZ9  						  	    30
#define AI_LOWZ9   						        31
#define AI_UPZ10 						  	    32
#define AI_LOWZ10  						        33
#define AI_UPZ11 						  	    34
#define AI_LOWZ11  						        35
#define AI_UPZ12 						  	    36
#define AI_LOWZ12  						        37
#define AI_FREE_L1SR 				  	        38  
#define AI_FREE_L2SR 				  	        39
#define TDM_1_GND0							    40
#define TDM_1_VSUPPLY_2					        41
#define	TDM_1_GJC0							    42
#define	TDM_1_GJC1							    43
#define TDM_1_GND1							    44
#define TDM_1_GND2							    45
#define TDM_1_GND3							    46
#define TDM_1_GND4							    47	
#define PULSE_COUNTER_1_MSW			            48
#define PULSE_COUNTER_1_LSW			            49
#define PULSE_COUNTER_1_SPEED		            50
#define PULSE_COUNTER_2_MSW                     51
#define PULSE_COUNTER_2_LSW                     52
#define PULSE_COUNTER_2_SPEED		            53
#define PULSE_COUNTER_3_MSW                     54
#define PULSE_COUNTER_3_LSW                     55
#define PULSE_COUNTER_3_SPEED		            56
#define PULSE_COUNTER_4_MSW                     57
#define PULSE_COUNTER_4_LSW                     58
#define PULSE_COUNTER_4_SPEED		            59

#define TPO_CONVBELT1	 					    0
#define TPO_GLOBAL_BLOWER_CONTROL			    1
#define TPO_ANALOG_FAN					        2
#define TPO_EXHAUST_FLUX_HEATER	                3
#define TPO_UPZ1								4
#define TPO_LOWZ1   		   			        5
#define TPO_UPZ2   							    6
#define TPO_LOWZ2   						    7
#define TPO_UPZ3   							    8
#define TPO_LOWZ3   						    9
#define TPO_UPZ4   							    10
#define TPO_LOWZ4   						    11
#define TPO_UPZ5  							    12
#define TPO_LOWZ5   						    13
#define TPO_UPZ6   							    14
#define TPO_LOWZ6   						    15
#define TPO_CONVBELT2						    16
#define TPO_AVAILABLE						    17
#define TPO_UPZ7								18
#define TPO_LOWZ7   						    19
#define TPO_UPZ8   							    20
#define TPO_LOWZ8   					        21
#define TPO_UPZ9   							    22
#define TPO_LOWZ9   					        23
#define TPO_UPZ10  							    24
#define TPO_LOWZ10  					        25
#define TPO_UPZ11  				 			    26
#define TPO_LOWZ11  					        27
#define TPO_UPZ12  				 			    28
#define TPO_LOWZ12  					        29
#define TPO_FREECL1 				 	        30
#define TPO_FREECL2 				 	        31

#define AO_AOUT0									32
#define AO_AOUT1									33
#define AO_AOUT2									34
#define AO_AOUT3									35
#define AO_AOUT4									36
#define AO_AOUT5									37
#define AO_AOUT6									38
#define AO_AOUT7									39


//******************************************************************************
// Digital IO - On/Off - TTL and 24v
// Reference Analogic Software Requirement Specification
// Document No. 91G-00574		RevA
//******************************************************************************
// Digital Inputs Array Mapping
// The digital inputs can be read and put into the array directly, since outputs 
// can be part of the array also read them as well. 
// I - Input Array
// D - Digital
// I - Input type OR O - Output Type

#define	IDI_RAIL2_HOME_SWITCH							0         		  
#define	IDI_RAIL3_HOME_SWITCH							1         		  
#define	IDI_RAIL4_HOME_SWITCH							2          		  
#define	IDI_SMEMA2_BOARD_ENTERING_OVEN		            3         		  
#define	IDI_SMEMA2_BOARD_LEAVING_OVEN			        4 
#define	IDI_SMEMA2_BOARD_BACKUP						    5 
#define IDI_LOW_N2_PRESSURE				 	            6
#define	IDI_FLUX_FILTER_DOOR_CLOSED				        7          		  

#define	ODO_RAIL1_ENABLE                                8
#define	ODO_RAIL1_DIRECTION                             9
#define	ODO_RAIL2_ENABLE                                10
#define	ODO_RAIL2_DIRECTION	            	            11
#define	ODO_AUTOLUBE_SOLENOID_1                         12
#define	ODO_NITROGEN_ON                                 13
#define ODO_SMEMA2_ENTRANCE								14
#define ODO_SMEMA2_EXIT									15
 
#define	IDI_BEAM_BOARD_DROP_LANE1 				        16         		  
#define	IDI_BEAM_BOARD_DROP_LANE2  				        17
#define IDI_REDUNDANT_OVERTEMP						    18
#define	IDI_HI_H2O_TEMP                    		        19     	
#define	IDI_CBS_UPDOWN_FB                    			20 
#define	IDI_AV4             						    21          		  
#define	IDI_AV5					 						22         		  
#define	IDI_AV6			         						23         		  

#define	ODO_RAIL3_ENABLE                                24
#define	ODO_RAIL3_DIRECTION  	         		        25
#define	ODO_RAIL4_ENABLE                                26
#define	ODO_RAIL4_DIRECTION                             27
#define	ODO_CBS_UP                                      28
#define	ODO_NITROGEN_HIGH_FLOW                          29
#define	ODO_NITROGEN_NORMAL_FLOW					    30
#define	ODO_NITROGEN_LOW_FLOW          		            31


#define IDI_SMEMA4_BOARD_ENTERING_OVEN					32
#define IDI_SMEMA4_BOARD_LEAVING_OVEN				    33
#define IDI_CBS_UPDOWN_FB2			                    34                
#define IDI_SMEMA3_BOARD_ENTERING_OVEN  		        35                
#define IDI_SMEMA3_BOARD_LEAVING_OVEN	    	        36                
#define IDI_SMEMA3_BOARD_BACKUP    				        37                
#define IDI_SMEMA4_BOARD_BACKUP    				        38               
#define	IDI_AV14                					    39                

#define	ODO_1088_DIGITAL_FAN_FLUX_FILTER                40
#define	ODO_NEW_JOB_FIVESEC	                            41
#define ODO_CBS_UP2										42
#define	ODO_SMEMA4_ENTRANCE                             43
#define	ODO_AUTOLUBE_SOLENOID_2	                        44
#define	ODO_SMEMA4_EXIT                                 45
#define ODO_SMEMA3_ENTRANCE         					46
#define ODO_SMEMA3_EXIT									47

#define	ODO_RED_LIGHT_TOWER              	            48 				  
#define	ODO_AMBER_LIGHT_TOWER            	            49                
#define	ODO_GREEN_LIGHT_TOWER            	            50                
#define	ODO_AUDIBLE_ALARM                	            51                
#define	ODO_CONVEYOR_BLOWER	            	            52                 
#define	ODO_HEATER_CONTACT                              53                 
#define ODO_SMEMA1_ENTRANCE								54
#define ODO_SMEMA1_EXIT									55

#define	IDI_ESTOP										56 // -- MARKS THE BEGINNING OF 24 VOLT INPUTS
#define	IDI_OVEN_POWER_NORMAL		   				    57 	          
#define	IDI_SMEMA1_BOARD_ENTERING_OVEN		            58              
#define	IDI_SMEMA1_BOARD_LEAVING_OVEN			        59	 
#define IDI_SMEMA1_BOARD_BACKUP         	            60
#define IDI_BLOWER_FAILURE								61
#define IDI_LOW_EXHAUST									62
#define	IDI_RAIL1_HOME_SWITCH							63 // -- MARKS THE END OF 24 VOLT INPUTS        		  

#define IDI_NULL 98
#define ODO_NULL 99

#define SMEMA_MAXBOARDS_DEFAULT		5

#define MAX_TEMP_ZONES_SLAVE			32
#define MAX_TEMP_ZONES_MASTER			28
#define XTRA_TEMP_ZONES_MASTER_2060		4	// these are zones 29 and 30

#define MaxTempZones  (MAX_TEMP_ZONES_MASTER + MAX_TEMP_ZONES_SLAVE + XTRA_TEMP_ZONES_MASTER_2060) 

// Slave zones begin at the end of the first set of master zones, continue through to 
// the end of the slave zone count, and then are followed by the extra master zones.
#define SLAVE_ZONE_START			MAX_TEMP_ZONES_MASTER
#define SLAVE_ZONE_END				(MAX_TEMP_ZONES_MASTER + MAX_TEMP_ZONES_SLAVE)


// Digital Outputs Array Mapping
// The digital outputs are shared with the inputs must be careful when writing.
// The 24V digital outputs are not shared so this block can be written from 
// Address 25 to 56. 
// can be part of the array also read them as well. 
// O - Output Array
// D - Digital
// I - Input type OR O - Output Type
// #include <stdio.h>
//#define printk printf
#define PARAM_CHECK(void_ptr, function_name) \
   { \
		if ( void_ptr == NULL ) \
		{ \
			printk("ERROR: %s() has null pointer %s\n", \
					function_name, (char*)void_ptr); \
			return; \
		} \
	 }
                                                                                
#define PARAM_CHECK_RETURN(void_ptr, function_name, return_val) \
   { \
		if ( void_ptr == NULL ) \
		{ \
			printk("ERROR: %s() has null pointer %s\n", \
				function_name, (char*)void_ptr); \
			return return_val; \
		}  \
	}

#define X_CA4_WARNING			0x0001
#define X_CA4_ALARM				0x0002
#define X_CA4_AUDIBLE_WARN		0x0004
#define X_CA4_DISTANCE_BASED	0x0008
#define X_CA4_CHECKED			0x0010
#define X_CA4_ACTIVE_HIGH		0x0020
#define X_CA4_OUTPUT_WARN		0x0040
#define X_CA4_OUTPUT_ALARM		0x0080
#define X_CA5_WARNING			0x0100
#define X_CA5_ALARM				0x0200
#define X_CA5_AUDIBLE_WARN		0x0400
#define X_CA5_DISTANCE_BASED	0x0800
#define X_CA5_CHECKED			0x1000
#define X_CA5_ACTIVE_HIGH		0x2000
#define X_CA5_OUTPUT_WARN		0x4000
#define X_CA5_OUTPUT_ALARM		0x8000

#endif
