//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: xpdriverioctl.h
//
// Description: define control codes for XpDriver driver
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Declare OVEN_currentDelayCooldown
// 11-Feb-15  FJN  Declare OVEN_currentMonitorCommFailure
// 13-Mar-15  FJN  Declare OVEN_currentMonitorHeatZoneFailureHigh and OVEN_currentMonitorFluxZoneFailureHigh
// 24-Jun-16  FJN  Declare SMEMA_setLaneHold
// 14-Sep-16  TP   Declare OVEN_disableDevAlarmInStartup	0x2241C9
// 26-Sep-16  TP   Declare Oven_setStartupCompletePlusDelay		0x2241CA
// 21-Feb-17  TP   Declare OVEN_setBeltStopWhenRailMoving	0x2241CB
//*****************************************************************************
#ifndef __xpDriverioctl__h_
#define __xpDriverioctl__h_

#define CTL_CODE(DeviceType, Function, Method, Access ) (((DeviceType) << 16) | ((Access) << 14) | ((Function) << 2) | (Method))

#define FILE_DEVICE_UNKNOWN             0x00000022

#define METHOD_BUFFERED                 0
#define METHOD_IN_DIRECT                1
#define METHOD_OUT_DIRECT               2
#define METHOD_NEITHER                  3

#define FILE_ANY_ACCESS                 0
#define	FILE_READ_ACCESS		1
#define	FILE_WRITE_ACCESS		2
#define	FILE_NO_ACCESS			3	// fjn -- peculiar to iMagic declarations

//Additional defines shared between comm and sys
#define SECONDARY_PV_REQUEST 1;
#define SECONDARY_OP_REQUEST 2;

#define XPDRIVER_IOCTL_800						0x222000 
#define XPDRIVER_IOCTL_801						0x222004
#define HC2XAPP_TEST_WATCHDOG					0x222008 
#define ALARMQUEUE_getStatusEvents				0x222040 
#define ALARMQUEUE_setCooldownPreference		0x222044 
#define ALARMQUEUE_setAudibleBeltWarningsEnabled	0x222048 
#define ALARMQUEUE_setAudibleLowExhaustEnabled	0x22204C 
#define ALARMQUEUE_getAlarmCount				0x222050 
#define ALARMQUEUE_alarmQueueAcknowledge		0x222054 
#define ALARMQUEUE_clearReadFlagAll				0x222068 
#define ALARMQUEUE_alarmsPresent				0x22206C 
#define ALARMQUEUE_warningsPresent				0x222070 
#define ALARMQUEUE_resetAudibleSounding			0x222074 
#define ALARMQUEUE_returnInAudibleCondition		0x222078 
#define ALARMQUEUE_getAlarmMessage				0x22207C 
#define ALARMQUEUE_addAlarm						0x222080 
#define ALARMQUEUE_resetAlarms					0x222084 
#define ALARMQUEUE_setAudibleDansensorWarningEnabled	0x222088 
#define ALARMQUEUE_audibleWarnings				0x22208C   
#define ALARMQUEUE_enableAudibleBoardWarnings	0x222090 
#define ALARMQUEUE_audibleBCWarnings			0x222094
#define ALARMQUEUE_renotify						0x222098
#define ALARMQUEUE_audible_DB					0x22209C
#define ALARMQUEUE_vipMode						0x2220A0
#define ALARMQUEUE_ackType						0x2220A4
#define ALARMQUEUE_warningOutput					0x2220A8

#define ANALOGIN_getValue						0x222100 
#define ANALOGIN_readProfileOffset			0x222104 
#define ANALOGIN_GetAnalogInVal				0x222108 
#define ANALOGIN_GetStoredOffset				0x22210C 
#define ANALOGIN_SetOffsetValue				0x222110 
#define ANALOGIN_GetInputStyle				0x222114 
#define ANALOGIN_SetInputStyle				0x222118 
#define ANALOGOUT_getValue						0x222180 
#define ANALOGOUT_setValue						0x222184 

#define ANALOGFAN_setOutputPercent			0x2221C0 
#define ANALOGFAN_getOutputPercent			0x2221C4 
#define ANALOGFAN_setEnableState				0x2221C8 
#define ANALOGFAN_0_100					0x2221CC
#define ANALOGFAN_LOW					0x2221D0
#define ANALOGFAN_MED					0x2221D4
#define ANALOGFAN_HIGH					0x2221D8
#define ANALOGFAN_MINIMUM				0x2221DC


#define BELTS_doFastPidControl					0x222240 
#define BELTS_enableHiDevAlarm					0x222244 
#define BELTS_enableHiDevWarn					0x222248 
#define BELTS_enableHiProcAlarm				0x22224C 
#define BELTS_enableLoDevAlarm				0x222250 
#define BELTS_enableLoProcAlarm				0x222254 
#define BELTS_enterSlowPidValue				0x222258 
#define BELTS_get4BElapsedPositionCountTics	0x22225C 
#define BELTS_getAutoMode					0x222260 
#define BELTS_getBeltActive				0x222264 
#define BELTS_getCountMethod				0x222268 
#define BELTS_getCurrentState				0x22226C 
#define BELTS_getHiPercentLimit			0x222270
#define BELTS_getHiSpeedRange				0x222274
#define BELTS_getInputRangeHighValue	0x222278
#define BELTS_getInputRangeLowValue		0x22227C
#define BELTS_getLoPercentLimit			0x222280
#define BELTS_getLowSpeedLimit			0x222284
#define BELTS_getMaxFreq					0x222288
#define BELTS_getPulsesPerCmCount		0x22228C
#define BELTS_getSetPoint					0x222290
#define BELTS_getSpeedCounts				0x222294
#define BELTS_getSpeedInCMsPerMin		0x222298
#define BELTS_getSummOfSpeeds				0x22229C
#define BELTS_IsBeltInWarning				0x2222A0
#define BELTS_IsOpenLoop					0x2222A4
#define BELTS_setAutoMode					0x2222A8
#define BELTS_setBeltActive				0x2222AC
#define BELTS_setElapsedPositionCounts	0x2222B0
#define BELTS_setHiDeadBandOffsetCounts 0x2222B4
#define BELTS_setHiDeviationCounts		0x2222B8
#define BELTS_setHiPercentLimit			0x2222BC
#define BELTS_setHiProcessCounts			0x2222C0
#define BELTS_setHiSpeedLimit				0x2222C4
#define BELTS_setHiWarningCounts			0x2222C8
#define BELTS_setInputRangeHighValue	0x2222CC
#define BELTS_setLoDeadBandOffsetCounts 0x2222D0
#define BELTS_setLoDeviationCounts		0x2222D4
#define BELTS_setLoPercentLimit			0x2222D8
#define BELTS_setLoProcessCounts			0x2222DC
#define BELTS_setLoWarningCounts			0x2222E0
#define BELTS_setLowSpeedLimit			0x2222E4
#define BELTS_setManualTPOcounts			0x222300
#define BELTS_setMaxFreq					0x222304
#define BELTS_setOpenLoop					0x222308
#define BELTS_setPb							0x22230C
#define BELTS_setPulsesPerCmCount		0x222310
#define BELTS_setSpeedInCMsPerMin		0x222314
#define BELTS_setSpeedCounts				0x222318
#define BELTS_setTd							0x22231C
#define BELTS_setTi							0x222320
#define BELTS_enableLoDevWarn				0x222324
#define BELTS_getTPOoutputCounts			0x222328
#define BELTS_enableSequencing			0x22232C
#define BELTS_setSequenceGroup			0x222330
#define BELTS_activateAllBelts			0x222734
#define BELTS_deactivateAllBelts			0x222738 
#define BELTS_setWarningTimeVariable	0x22273C 
#define BELTS_setDeadbandDeviationTime	0x222740 
#define BELTS_setMotors						0x222744 
#define BELTS_setDigOutput					0x222748 
#define BELTS_setOutputBehavior			0x22274C 
#define BELTS_setMultipleVariables		0x222750
#define BELTS_MotorFailureCounts			0x222754
#define BELTS_InputDeviationCounts		0x222758
#define BELTS_DiffMTime						0x222760
#define BELTS_getConfigParam				0x222764
#define BELTS_autoRange					0x222768
#define BELTS_autoRangeOutput				0x22276C
#define BLACKBOX_GatherData			0x222770
#define BELTS_autoRangeSwitch		0x222774
#define BELTS_SmemaOffRange		0x222778
#define BELTS_setOpenLoopStandbyCounts	0x222779
#define BELTS_setInputRangeLoValue		0x22277A
#define	BELTS_setDigitalStopSensor		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x9DF, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define BOARDQUEUE_getNotifyBoard			0x222380
#define BOARDQUEUE_setNotifyBoard			0x222384
#define BOARDQUEUE_getNotifyBoardOut		0x222388
#define BOARDQUEUE_setNotifyBoardOut		0x22238C
#define BOARDQUEUE_getBoardsInOvenCount	0x222390
#define BOARDQUEUE_getBoardsProcessed		0x222394
#define BOARDQUEUE_clearBoardsInOven		0x222398
#define BOARDQUEUE_clearBoardsProcessed	0x22239C
#define BOARDQUEUE_getBoardAnimationData	0x2223A0
#define BOARDQUEUE_getBoardData				0x2223A4
#define BOARDQUEUE_setBoardDeadBandDistance 0x2223A8
#define BOARDQUEUE_setSensorDistance			0x2223AC
#define BOARDQUEUE_setExitBoardDeadbandCounts 0x2223B0
#define BOARDQUEUE_setBoardDropTolerance		0x2223B4
#define BOARDQUEUE_setBoardDropTimeTolerance	0x2223B8
#define BOARDQUEUE_setBoardDropToleranceNeg	0x2223BC
#define BOARDQUEUE_enableSprayOption			0x2223C0
#define BOARDQUEUE_setSprayDist					0x2223C4
#define BOARDQUEUE_setSprayDistTime			0x2223C8
#define BOARDQUEUE_setSprayOutput			0x2223CC
#define BOARDQUEUE_SetFCDelayDist			0x2223D0
#define BOARDQUEUE_getBoardsInOvenFluxcon		0x2223D4
#define BOARDQUEUE_setHeatMidPoint			0X2223D8
#define BOARDQUEUE_ignoreBoardLength		0x2223DC
#define BOARDQUEUE_enablePredefinedBoardLength	0x2223E0
#define BOARDQUEUE_predefinedBoardLength		0x2223E4
#define BOARDQUEUE_entranceJamWarning			0x2223E8
#define BOARDQUEUE_setTime					0x2223EC
#define BOARDQUEUE_setWarningDout			0x222405

#define CBS_setFeedbackTypeFlag				0x222440
#define CBS_setState							0x222444
#define CBS_getState							0x222448
#define CBS_getSecondState						0x22244C
#define CBS_enable							0x22244D

#define DS_enable							0x222450
#define DS_Input							0x222454
#define DS_Output							0x222458

#define DIGITALIN_getValue						0x2224C0
#define DIGITALIN_getHistBufferIndex		0x2224C4
#define DIGITALIN_getHistBuffer				0x2224C8

#define DIGITALOUT_getValue					0x222500
#define DIGITALOUT_setValue					0x222504

#define FLUXCONDENSOR_setElapsedTime10ths	0x222540
#define FLUXCONDENSOR_recipeStarted			0x222544
#define FLUXCONDENSOR_getElapsedTime10ths	0x222548
#define FLUXCONDENSOR_enableOption			0x22254C
#define FLUXCONDENSOR_recipeOption			0x222550
#define FLUXCONDENSOR_setIntervalTime		0x222554
#define FLUXCONDENSOR_setDurationTime		0x222558
#define FLUXCONDENSOR_setT3Timer				0x22255C
#define FLUXCONDENSOR_setToggle				0x222560
#define FLUXCONDENSOR_setDelayTimer			0x222564
#define	FLUXCONDENSOR_setCycleEndNitro	0x222568
#define FLUXCONDENSOR_setJobAtEnd			0x22256C
#define FLUXCONDENSOR_recipePreStart		0x222570
#define FLUXCONDENSOR_gen9Option				0x222574
#define FLUXCONDENSOR_genPhase1Time			0x222578
#define FLUXCONDENSOR_genPhase2Time			0x22257C

#define FLUXFILTER_setElapsedTime10ths		0x2225C0
#define FLUXFILTER_fluxFilterEnable			0x2225C4
#define FLUXFILTER_setFluxFilterCleaningInterval10ths	0x2225C8
#define FLUXFILTER_getElapsedTime10ths		0x2225CC
#define FLUXFILTER_setDOAvailibility		0x2225D0

#define FLUXHEATER_getTPOoutput			0x222640
#define FLUXHEATER_getSetPoint			0x222644
#define FLUXHEATER_setActive				0x222648
#define FLUXHEATER_setSetPoint				0x22264C
#define FLUXHEATER_PIDsetPb					0x222650
#define FLUXHEATER_PIDsetTi					0x222654
#define FLUXHEATER_PIDsetTd					0x222658
#define FLUXHEATER_setSequenceGroup			0x22265C
#define FLUXHEATER_setZoneAuto				0x222660
#define FLUXHEATER_setPIDenable				0x222664
#define FLUXHEATER_setTPOoutput				0x222668
#define FLUXHEATER_PIDsetAction				0x22266C
#define FLUXHEATER_setDeadBandHiTempOffset 0x222670
#define FLUXHEATER_SetDeadBandLoTempOffset 0x222674
#define FLUXHEATER_enableHiProcAlarm		0x222678
#define FLUXHEATER_enableHiDeviationAlarm	0x22267C
#define FLUXHEATER_enableHiDeviationWarn	0x222680
#define FLUXHEATER_enableLoDeviationWarn	0x222684
#define FLUXHEATER_enableLoDeviationAlarm	0x222688
#define FLUXHEATER_enableLoProcAlarm		0x22268C
#define FLUXHEATER_setHiProcTemp			0x222690
#define FLUXHEATER_setAlarmHiTempOffset	0x222694
#define FLUXHEATER_setWarnHiTempOffset		0x222698
#define FLUXHEATER_setWarnLoTempOffset		0x22269C
#define FLUXHEATER_setAlarmLoTempOffset	0x2226A0
#define FLUXHEATER_setLoProcTemp			0x2226A4
#define FLUXHEATER_PIDsetPIDMode			0x2226A8
#define FLUXHEATER_isInDeviationAlarmZone	0x2226AC
#define FLUXHEATER_DeActivateZones			0x2226B0
#define FLUXHEATER_initializePowerUpSequencing	0x2226B4
#define FLUXHEATER_setMinRiseDegreeCounts	0x2226BC
#define FLUXHEATER_setRiseRatePeriod		0x2226C0
#define FLUXHEATER_ActivateZones				0x2226C4
#define FLUXHEATER_checkWarningState		0x2226C8
#define FLUXHEATER_InDeadBandOrIsNotEnabled	0x2226CC
#define FLUXHEATER_IsZoneInWarning			0x2226D0
#define FLUXHEATER_getProcVar					0x2226D8
#define FLUXHEATER_startSequencingRequiresTimer	0x2226DC
#define FLUXHEATER_isFluxHeaterEnabled		0x2226E0
#define FLUXHEATER_setFluxheaterDelayTime	0x2226E4
#define FLUXHEATER_setFluxHeaterEnable		0x2226E8
#define FLUXHEATER_initScInput				0x2226EC
#define FLUXHEATER_initTcInput				0x2226F0
#define FLUXHEATER_initTPOoutput				0x2226F4
#define FLUXHEATER_initScTPOOutput			0x2226F8
#define FLUXHEATER_setHiProcessDelayTime	0x2226FC
#define FLUXHEATER_getConfigParam			0x222704
#define FLUXHEATER_getInputReference			0x222708
#define FLUXHEATER_PIDsetPbCool			0x222709
#define FLUXHEATER_PIDsetTiCool			0x22270A
#define FLUXHEATER_PIDsetTdCool			0x22270B
#define FLUXHEATER_SetCoolOutput			0x22270C
#define FLUXHEATER_GetCoolingPercentage	0x22270D
#define FLUXHEATER_SetCoolOffset			0x22270E
#define FLUXHEATER_SetCoolOnOff			0x22270F

#define GLOBALBLOWER_setOutputPercent		0x222780
#define GLOBALBLOWER_getOutputPercent		0x222784
#define GLOBALBLOWER_setEnableState			0x222788
#define GLOBALBLOWER_setOnTime				0x22278C
#define GLOBALBLOWER_0_100					0x222790
#define GLOBALBLOWER_LOW					0x222794
#define GLOBALBLOWER_MED					0x222798
#define GLOBALBLOWER_HIGH					0x22279C
#define GLOBALBLOWER_MINIMUM				0x2227A0

#define HEATZONEBLOWER_setEnable			0x2227C0
#define HEATZONEBLOWER_setLowSetting		0x2227C4
#define HEATZONEBLOWER_setMediumSetting	0x2227C8
#define HEATZONEBLOWER_setHighSetting		0x2227CC
#define HEATZONEBLOWER_getIfHZBlowerIsEnabled	0x2227D0
#define HEATZONEBLOWER_getOutputPercent	0x2227D4
#define HEATZONEBLOWER_getLowSetting		0x2227D8
#define HEATZONEBLOWER_getMediumSetting	0x2227DC
#define HEATZONEBLOWER_getHighSetting		0x2227E0
#define HEATZONEBLOWER_setOutputPercent	0x2227E4
#define HEATZONEBLOWER_controlMap	0x2227E8
#define HEATZONEBLOWER_StandbyTime	0x2227EC
#define HEATZONEBLOWER_IEBoardLoad	0x2227F0
#define HEATZONEBLOWER_0_100A		0x2227F4
#define HEATZONEBLOWER_0_100B		0x2227F8
#define HEATZONEBLOWER_0_100C		0x2227FC
#define HEATZONEBLOWER_MINIMUM		0x222800
#define HEATZONEBLOWER_IE_LEVEL		0x22280C
#define HEATZONEBLOWER_100H			0x22280D

#define IOCTL_STOP_HELLER_DRIVER			0x224880
#define IOCTL_getTimerLoss					0x224884
#define IOCTL_START_HELLER_DRIVER		0x224888
#define IOCTL_SetMonitorMode				0x22488C
#define IOCTL_SET_TIMER_DONGLE_DEBUGGING 0x224890
#define IOCTL_GET_TICK_FREQUENCY			0x224894
#define IOCTL_GET_DONGLE_FAILED			0x224898
#define IOCTL_SLAVE_MODE					0x22489C
#define IOCTL_CONTROL_HAULTED				0x2248A0
#define IOCTL_REQUEST_MONITOR_MODE		0x2248A4
#define IOCTL_CONTROL_STARTED				0x2248A8
#define IOCTL_TEST_WATCHDOG				0x2248C4
#define IOCTL_ACTIVATE_MODBUS				0x2248C8

#define LIGHTTOWER_Enable					0x224900
#define LIGHTTOWER_getStatus				0x224904
#define LIGHTTOWER_setSonyGreenLightOption	0x224908
#define LIGHTTOWER_Disable					0x22490C
#define LIGHTTOWER_setDOAvailibility	0x224910
#define LIGHTTOWER_setBoardDropBehavior 0x224914
#define LIGHTTOWER_setCLBehavior	0x224918
#define LIGHTTOWER_SpecialInput		0x224919
#define LIGHTTOWER_TimeValue		0x22491A
#define LUBE_setElapsedTime10ths			0x224980
#define LUBE_getElapsedTime10ths			0x224984
#define LUBE_optionEnable					0x224988
#define LUBE_setLubeIntervalTime			0x22498C
#define LUBE_setLubeDurationTime			0x224990

#define NITROGEN_setNitrogenEnable		0x224A00
#define NITROGEN_getNitrogenEnable		0x224A01
#define NITROGEN_setAutoPurgeEnable		0x224A04
#define NITROGEN_setPurgeTime10ths		0x224A08
#define NITROGEN_setNormalTime10ths		0x224A0C
#define NITROGEN_setActive				0x224A10
#define NITROGEN_getActive				0x224A11
#define NITROGEN_setCoolRunTime			0x224A14
#define NITROGEN_isNitroOnInCooldown	0x224A18
#define NITROGEN_dsClosedLoop			0x224A1C
#define NITROGEN_makeOutputsUnavailable 0x224A20
#define NITROGEN_pollPpmState			0x224A24
#define NITROGEN_setRedundInput			0x224A40
#define NITROGEN_enableWarning			0x224A44
#define NITROGEN_enableAlarm			0x224A48
#define NITROGEN_setAlarmTime			0x224A4C
#define NITROGEN_setWarningTime			0x224A50

#define OVEN_Pause						0x224100
#define OVEN_setJob						0x224104
#define OVEN_setJobStartupComplete		0x224108
#define OVEN_resume						0x22410C
#define OVEN_setBelts					0x224110
#define OVEN_setBoardsProcessedConfig	0x224114
#define OVEN_setBoardAnimationConfig	0x224118
#define OVEN_setBoardsInOvenConfig		0x22411C
#define OVEN_setBoardDropConfig			0x224120
#define OVEN_setSMEMAConfig				0x224124
#define OVEN_setModelNo					0x224128
#define OVEN_setDirection				0x22412C
#define OVEN_setRedundantOverTempOption 0x224130
#define OVEN_setLTOption				0x224134
#define OVEN_setBlowerFailureOption		0x224138
#define OVEN_setThirdLaneEnabled		0x22413C
#define OVEN_setLowExhaustWarningTime	0x224140
#define OVEN_setLowExhaustAlarmTime		0x224144
#define OVEN_setAsBoardTypeA				0x224148
#define OVEN_SetDemoMode					0x22414C
#define OVEN_setRecipeName					0x224150
#define OVEN_getRecipeName					0x224154
#define OVEN_getDirection					0x224158
#define OVEN_getJob							0x22415C
#define OVEN_ExternalCheckForPowerFailure	0x224160
#define OVEN_getModelNo						0x224164
#define OVEN_setStartWithJob				0x224168
#define OVEN_setFourthLaneEnabled		0x22416C
#define OVEN_setExhaustWarningEnable	0x224170
#define OVEN_setExhaustAlarmEnable		0x224174
#define OVEN_disableAutoAcknowledge		0x224178
#define OVEN_setPowerFailureTime		0x22417C
#define OVEN_setFiveSecondDisable		0x224180
#define OVEN_getFiveSecondDisable		0x224184
#define OVEN_delayCooldown				0x224188
#define OVEN_delayCooldownTime			0x22418C
#define OVEN_inCooldown					0x224190
#define OVEN_SetBoardStop				0x224194
#define OVEN_System_Configured			0x224198
#define OVEN_Request_Cooldown			0x22419C
#define OVEN_FanFault_Alarm				0x2241A0
#define OVEN_BFAud						0x2241A4
#define OVEN_BFTimeAlarm				0x2241A8
#define OVEN_BFTimeWarn					0x2241AC
#define OVEN_BFWARN						0x2241B0
#define OVEN_ClearCooldownNotify		0x2241B4
#define OVEN_AllowSmemaAgain			0x2241BA
#define OVEN_variousSettings			0x2241BB
#define OVEN_standbyRTime				0x2241BC
#define OVEN_standbyCoolTime			0x2241BD
#define OVEN_standbyInput				0x2241BE
#define OVEN_energyRecipe				0x2241BF
#define OVEN_variousSettingsII			0x2241C1
#define OVEN_AlarmScannerOption			0x2241C2
#define OVEN_AlarmScannerOutput			0x2241C3
#define OVEN_AlarmScannerState			0x2241C5
#define OVEN_AlarmScannerHold			0x2241C6
#define OVEN_BarcodeReset				0x2241C7
#define OVEN_disableDevAlarmInStartup	0x2241C9
#define OVEN_setStartupCompletePlusDelay		0x2241CA
#define OVEN_setBeltStopWhenRailMoving	0x2241CB	//ver8.0.0.18

#define PURGE_setMessageDelay		0x2241C0
#define PURGE_setMessageType		0x2241C4
#define PURGE_setInput				0x2241C8
#define PURGE_setOutput				0x2241CC
#define PURGE_setLightTowerAction	0x2241D0
#define PURGE_CA3Input				0x2241D1
#define PURGE_CA3Output				0x2241D2
#define PURGE_CA3WarningTime		0x2241D3
#define PURGE_CA3AlarmTime			0x2241D4
#define PURGE_DOBCOption			0x2241D5
#define PURGE_DOBCAction			0x2241D6
#define PURGE_DOBCOutput			0x2241D7
#define PURGE_DOBCCount				0x2241D8
#define PURGE_CA4Input				0x2241D9
#define PURGE_CA4Output				0x2241DA
#define PURGE_CA4WarningTime		0x2241DB
#define PURGE_CA4AlarmTime			0x2241DC
#define PURGE_CA5Input				0x2241DD
#define PURGE_CA5Output				0x2241DE
#define PURGE_CA5WarningTime		0x2241DF
#define PURGE_CA5AlarmTime			0x2241E0

#define OXYGEN_setEnabled					0x224200
#define OXYGEN_getOxygenVolts				0x224204

#define PURGE_setActive						0x224220
#define PURGE_setPurgeTime10ths			0x224224
#define PURGE_setDigitialOutput			0x224228
#define PURGE_forceOn						0x22422C
#define PURGE_setRecipeOutput				0x224230
#define PURGE_enableCustomAlarm			0x224234
#define PURGE_setLineState					0x224238
#define PURGE_setAudibleWarning			0x22423C
//NEEDED MORE DEFINES, BELOW OVEN ENTRIES

#define RAIL_resetIncDec					0x224240
#define RAIL_increment						0x224244
#define RAIL_isPresetStable				0x224248
#define RAIL_setHomeDirection				0x22424C
#define RAIL_setHomeDistanceCounts		0x224250
#define RAIL_setControlType				0x224254
#define RAIL_setFalsePositionCounts		0x224258
#define RAIL_setOutputEnableFlag			0x22425C
#define RAIL_decrement						0x224260
#define RAIL_isInFinalPosition			0x224264
#define RAIL_EnterInitialCorrectionFactor 0x224268
#define RAIL_setHuntPreference			0x22426C
#define RAIL_EnterMaximumHunts			0x224270
#define RAIL_EnterNegativeTolerance		0x224274
#define RAIL_EnterPositiveTolerance		0x224278
#define RAIL_enterBackupDistance			0x22427C
#define RAIL_PREPROCESS					0x224280
#define RAIL_getSetpoint					0x224284
#define RAILS_setConfiguration			0x2242C0
#define RAILS_IntializeEdgeholdBools	0x2242C4
#define RAILS_getPositionCounts			0x2242C8
#define RAILS_setPosition					0x2242CC
#define RAILS_EnableTest					0x2242D0
#define RAILS_DisableTest					0x2242D4
#define RAILS_setRailStateToPresetForJobLoad	0x2242D8
#define RAILS_setOpFromCoolRailMovement	0x2242DC
#define RAILS_queueSetPosition				0x2242E0
#define RAILS_arrayInitialization			0x2242E4
#define RAILS_bypassHomeAndPresetRoutines	0x2242E8
#define RAILS_getValue							0x2242EC
#define RAILS_masterSetpoint				0x2242ED

// fjn -- must guess at available function value thanks to horrendous use of numeric literals above
#define OVEN_currentMonitorDelayCooldown		CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1100, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_currentMonitorTempZoneFailureLow	CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1101, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_currentMonitorFluxZoneFailureLow	CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1102, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_heaterFailureDelayCooldown			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1103, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_heaterTempZoneFailure				CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1104, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_heaterFluxZoneFailure				CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1105, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_currentMonitorCommFailure			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1106, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_currentMonitorTempZoneFailureHigh	CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1107, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define OVEN_currentMonitorFluxZoneFailureHigh	CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1108, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	OVEN_waterTempHighEnable				CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1109, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	OVEN_waterTempHighAlarmTime				CTL_CODE(FILE_DEVICE_UNKNOWN, 0x110A, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	OVEN_waterTempHighWarningTime			CTL_CODE(FILE_DEVICE_UNKNOWN, 0x110B, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define COOLPIPE_enable							CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1300, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define COOLPIPE_analogInputTC1					CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1301, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define COOLPIPE_analogInputTC2					CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1302, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define COOLPIPE_tempTC1						CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1303, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define COOLPIPE_tempDelta						CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1304, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define COOLPIPE_delay							CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1305, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define	IOCTL_GATHER_TDM_EEPROM					CTL_CODE(FILE_DEVICE_UNKNOWN, 0x232, METHOD_IN_DIRECT, FILE_READ_ACCESS)
#define	IOCTL_SET_TDM_EEPROM					CTL_CODE(FILE_DEVICE_UNKNOWN, 0x232, METHOD_IN_DIRECT, FILE_WRITE_ACCESS)
#define	IOCTL_PROGRAM_TDM						CTL_CODE(FILE_DEVICE_UNKNOWN, 0x232, METHOD_IN_DIRECT, FILE_NO_ACCESS)

//defines for RAILS_getValue
#define RAIL_ACTUALPOSITION			1
#define RAIL_PRESETPOSITION			2
#define RAIL_STOPFACTOR				3
#define RAIL_PRESETACHIEVED			4
#define RAIL_BACKUPFORFIRSTRUN		5
#define RAIL_BACKINGUP				6
#define RAIL_LASTRAILSTATE			7
#define RAIL_DIRECTIONALFLAG		8
#define RAIL_TOLERANCEATTEMPTS		9
#define RAIL_GETHOMEHUNTUSED		10
#define RAIL_NTOLERANCE				11
#define RAIL_PTOLERANCE				12
#define RAIL_BACKDISTANCE			13
#define RAIL_MAXHUNT				14
#define RAIL_DONTALLOWNEWSTOPFACTOR	15
//end RAILS_getValue

#define RAILS_setHardwareOption			0x2242F0	
#define RAILS_readHardwareFlag			0x2242F4	
#define RAILS_sendRailsHome				0x2242F8	
#define RAILS_readHasHomedFlag			0x2242FC	
#define RAILS_setHardwareInput			0x224300	
#define RAILS_exercisePossible			0x224304
#define RAILS_setCBS2Rail					0x224308
#define RAILS_executeJog					0x22430C
#define RAILS_sequenceRails				0x224310
#define RAILS_setPulseCounts				0x224314
#define RAILS_monitorm_bJogOn				0x224318
#define RAILS_monitorcurrentRail			0x22431C
#define RAILS_monitorm_bUDPhaseMonitor 0x22431F
#define RAILS_monitorm_uintJogPhase		0x224320
#define RAILS_monitorm_uintUpdownPhase 0x224324
#define RAILS_monitorudPhaseTimer		0x224328
#define RAILS_HardwarePause			0x224329
#define RAILS_HardwareResume			0x22432A
#define RAILS_railsInHardwareMode		0x22432B

#define RECIPETRIGGER_IncrementInstance	0x224380
#define RECIPETRIGGER_getNumberComms		0x224384
#define RECIPETRIGGER_DecrementInstance	0x224388
#define RECIPETRIGGER_setFireRecipeNotification	0x22438C
#define RECIPETRIGGER_getNotify				0x224390
#define RECIPETRIGGER_getControlComm		0x224394
#define RECIPETRIGGER_setNotify				0x224398
#define RECIPETRIGGER_getFireRecipeNotification	0x22439C
#define RECIPETRIGGER_getbSaveRecipePath	0x2243A0
#define RECIPETRIGGER_setbSaveRecipePath	0x2243A4
#define RECIPETRIGGER_getrecipeSaveTransferPath	0x2243A8
#define RECIPETRIGGER_getactionControl		0x2243AC
#define RECIPETRIGGER_setactionControl		0x2243B0
#define RECIPETRIGGER_getrecipeTransferPath	0x2243B4
#define RECIPETRIGGER_getrecipePath			0x2243B8
#define RECIPETRIGGER_setrecipeTransferPath	0x2243BC
#define RECIPETRIGGER_ExecuteLoad			0x2243C0
#define RECIPETRIGGER_setrecipePath			0x2243C4
#define RECIPETRIGGER_setControlComm		0x2243C8
#define RECIPETRIGGER_setrecipeSaveTransferPath	0x2243CC
#define RECIPETRIGGER_setHellerExitedFlag		0x2243D0
#define RECIPETRIGGER_getHellerExitedFlag		0x2243D4
#define RECIPETRIGGER_getHellerUp				0x2243D8
#define RECIPETRIGGER_setHellerUp				0x2243DC
#define RECIPETRIGGER_setReadControl			0x2243E0
#define RECIPETRIGGER_getReadControl			0x2243E4

#define SETPOINTS_getMaxNumberChannels		0x224500
#define SETPOINTS_getRecordChange			0x22450C

#define SMEMA_setSMEMAdeadBandCounts		0x2245C0
#define SMEMA_setSMEMAtype						0x2245C4
#define SMEMA_clearBarcodeTimeout			0x2245C8
#define SMEMA_HoldWarning				0x2245CC
#define SMEMA_HoldLot					0x2245D0
#define SMEMA_ClearLot					0x2245D4
#define SMEMA_CureApp					0x2245D8
#define SMEMA_EntrHold					0x2245DC
#define SMEMA_Count						0x2245E0
#define	SMEMA_setLaneHold				0x2245E1

#define TEMPZONE_getProcVar					0x224600
#define TEMPZONE_setActive						0x224604
#define TEMPZONE_setSetPoint					0x224608
#define TEMPZONE_setSequenceGroup			0x22460C
#define TEMPZONE_setZoneAuto					0x224610
#define TEMPZONE_setPIDenable					0x224614
#define TEMPZONE_setTPOoutput					0x224618
#define TEMPZONE_setDeadBandHiTempOffset	0x22461C
#define TEMPZONE_SetDeadBandLoTempOffset	0x224620
#define TEMPZONE_enableHiProcAlarm			0x224624
#define TEMPZONE_enableHiDeviationAlarm	0x224628
#define TEMPZONE_enableHiDeviationWarn		0x22462C
#define TEMPZONE_enableLoDeviationWarn		0x224630
#define TEMPZONE_enableLoDeviationAlarm	0x224634
#define TEMPZONE_enableLoProcAlarm			0x224638
#define TEMPZONE_setHiProcTemp				0x22463C
#define TEMPZONE_setAlarmHiTempOffset		0x224640
#define TEMPZONE_setWarnHiTempOffset		0x224644
#define TEMPZONE_setWarnLoTempOffset		0x224648
#define TEMPZONE_setAlarmLoTempOffset		0x22464C
#define TEMPZONE_setLoProcTemp				0x224650
#define TEMPZONE_getTPOoutput					0x224654
#define TEMPZONE_getSetPoint					0x224658
#define TEMPZONE_getCurrentState				0x22465C
#define TEMPZONE_isActive						0x224660
#define TEMPZONE_IsZoneInWarning				0x224664
#define TEMPZONE_PIDsetPb						0x224668
#define TEMPZONE_PIDsetTi						0x22466C
#define TEMPZONE_PIDsetTd						0x224670
#define TEMPZONE_PIDsetAction					0x224674
#define TEMPZONE_PIDsetPIDMode				0x224678
#define TEMPZONE_isInDeviationAlarmZone	0x22467C
#define TEMPZONE_getConfigParam				0x224484
#define TEMPZONE_setGlobalHighProcess		0x224488
#define TEMPZONE_initTcInput			0x22448C
#define TEMPZONE_initTPOoutput			0x224490
#define TEMPZONE_getInputReference		0x224494
#define TEMPZONE_PIDsetPbCool			0x224499
#define TEMPZONE_PIDsetTiCool			0x22449A
#define TEMPZONE_PIDsetTdCool			0x22449B
#define TEMPZONE_SetCoolOutput			0x22449C
#define TEMPZONE_GetCoolingPercentage	0x22449D
#define TEMPZONE_SetCoolOffset			0x22449E
#define TEMPZONE_SetCoolOnOff			0x22449F

#define TEMPZONES_DeActivateZones			0x224700
#define TEMPZONES_ActivateZones				0x224704
#define TEMPZONES_setStartUpPowerPercent	0x224708
#define TEMPZONES_setDelayStartPeriod		0x22470C
#define TEMPZONES_setMinRiseDegreeCounts	0x224710
#define TEMPZONES_setRiseRatePeriod			0x224714
#define TEMPZONES_initializePowerUpSequencing	0x224718
#define TEMPZONES_enableDrawWarning			0x22471C
#define TEMPZONES_setTCWarnPercentage		0x224724
#define TEMPZONES_configureIO					0x224728
#define TEMPZONES_setNumberDrawWarningZones	0x22472C
#define TEMPZONES_setHiProcessDelayTime	0x224730
#define TEMPZONES_setCooldownSP 0x224734
#define TEMPZONES_setRiseRateWarning		0x224738
#define TEMPZONES_setCoolCycle				0x224739
#define TEMPZONES_CooldownCooling			0x22473A
#define TEMPZONES_CooldownSequenced			0x22473B

#define INTERCOMMTRANSFER_getActiveRailCount		0x224800
#define INTERCOMMTRANSFER_getActiveRailSetChannel	0x224804
#define INTERCOMMTRANSFER_getActiveBeltCount	0x224808
#define INTERCOMMTRANSFER_getActiveHeatCount	0x22480C
#define INTERCOMMTRANSFER_getActiveHeatChannel	0x224810
#define INTERCOMMTRANSFER_getActiveBeltsChannel	0x224814
#define INTERCOMMTRANSFER_EnterChannel				0x224818
#define INTERCOMMTRANSFER_getActiveProfileCount		0x22481C
#define INTERCOMMTRANSFER_getActiveProfileChannel	0x224820
#define INTERCOMMTRANSFER_getMaxNumberChannels		0x224824
#define INTERCOMMTRANSFER_getChannelArrayType		0x224828
#define INTERCOMMTRANSFER_getChannelArrayEnabled	0x22482C
#define INTERCOMMTRANSFER_setDanState			0x224830
#define INTERCOMMTRANSFER_getDanState			0x224834
#define HC2XCTL_recipeLoaded			0x224848

#define PIDCONTROLLER_setActive					0x226000
#define PIDCONTROLLER_setZoneMode				0x226001
#define PIDCONTROLLER_setStartState				0x226002
#define PIDCONTROLLER_setTpo						0x226003
#define PIDCONTROLLER_writeTpo					0x226005
#define PIDCONTROLLER_writeTpoSecondary		0x226006
#define PIDCONTROLLER_getTPO						0x226007
#define PIDCONTROLLER_setPreviousJob			0x226008
#define PIDCONTROLLER_setPidEnable				0x226009
#define PIDCONTROLLER_setGroupNo					0x22600A
#define PIDCONTROLLER_setSP						0x22600B
#define PIDCONTROLLER_setPV						0x22600C
#define PIDCONTROLLER_getPV						0x22600D
#define PIDCONTROLLER_setPVSecondary			0x22600E
#define PIDCONTROLLER_setAction					0x22600F
#define PIDCONTROLLER_AddSafeSegment			0x226010
#define PIDCONTROLLER_writeCalculatedTpo		0x226011
#define PIDCONTROLLER_setSuspend				0x226012

#define RECIPE_PARAMS_IN_ERROR					0x226013
#define GET_RECIPE_PARAM_ERRORS					0x226014

#define PIDCONTROLLER_PIDsetPb					0x226015
#define PIDCONTROLLER_PIDsetTi					0x226016
#define PIDCONTROLLER_PIDsetTd					0x226017
#define PIDCONTROLLER_PIDsetAction				0x226018
#define PIDCONTROLLER_PIDsetPIDMode				0x226019
#define PIDCONTROLLER_enableHiDeviationAlarm	0x226020
#define PIDCONTROLLER_enableLoDeviationAlarm	0x226021
#define PIDCONTROLLER_enableHiDeviationWarn		0x226022
#define PIDCONTROLLER_enableLoDeviationWarn		0x226023

#define PIDCONTROLLER_setDeadBandState			0x226024
#define PIDCONTROLLER_setAlarmsEnabled			0x226025
#define PIDCONTROLLER_setRiseRateCheck			0x226026
#define PIDCONTROLLER_setRiseDelayPeriodElapsed 0x226027
#define PIDCONTROLLER_setPowerUpComplete		0x226028

#define PIDCONTROLLER_setHiProcTemp				0x226029
#define PIDCONTROLLER_setLoProcTemp				0x226030
#define	PIDCONTROLLER_enableHiProcAlarm			0x226031
#define PIDCONTROLLER_enableLoProcAlarm			0x226032
#define PIDCONTROLLER_setAlarmHiTempOffset		0x226033
#define PIDCONTROLLER_setAlarmLoTempOffset		0x226034
#define PIDCONTROLLER_setWarnHiTempOffset		0x226035
#define PIDCONTROLLER_setWarnLoTempOffset		0x226036
#define PIDCONTROLLER_setDeadBandHiTempOffset	0x226037
#define PIDCONTROLLER_setDeadBandLoTempOffset	0x226038
#define PIDCONTROLLER_getSelfAckAlarmNo			0x226039
#define PIDCONTROLLER_setHiProcCountdownOn		0x22603A
#define PIDCONTROLLER_setInternalTestForDrawWarning 0x22603B
#define PIDCONTROLLER_enableDeadBandRangeCheck	0x22603C

#define MASS_COLLECT_AI							0x22603D
#define MASS_COLLECT_PV							0x22603E
#define MASS_COLLECT_TPO						0x22603F
#define MASS_COLLECT_SA							0x226040
#define MASS_COLLECT_OFFSETS					0x226048

#define PIDCONTROLLER_riseRateSetPointChange	0x226047
#define PIDCONTROLLER_setIO						0x226049
#define PIDCONTROLLER_PIDsetPbCool 				0x22604A
#define PIDCONTROLLER_PIDsetTiCool 				0x22604B
#define PIDCONTROLLER_PIDsetTdCool 				0x22604C
#define PIDCONTROLLER_setCoolOutput 			0x22604D
#define PIDCONTROLLER_setCoolTime 				0x22604E
#define PIDCONTROLLER_setCoolSPOffset			0x22604F

#define SMEMA_MaxBoardsPerLaneEnable			0x226048
#define SMEMA_MaxBoardsPerLaneCount				0x226049
#define SMEMA_NoBoardAnimation					0x226050
#define SMEMA_BoardInOut						0x226052

#define LIGHTTOWER_LT2_Enable					0x226051
#define LIGHTTOWER_LT2_DO_Red					0x226052
#define LIGHTTOWER_LT2_DO_Yellow				0x226053
#define LIGHTTOWER_LT2_DO_Green					0x226054
#define LIGHTTOWER_LT2_getStatus				0x226055

#define RAIL_SetLaneIndex						0x226056
#define RAILS_getCountPerCM						0x226057
#define RAILS_getHomeDistanceCounts				0x226058

#define OVEN_variousSettingsIII					0x226060

#define ENERGYSAVING_IntelExhaust_Speed			0x226061
#define ENERGYSAVING_StandbyMode1_ExhaustSpeed	0x226062
#define ENERGYSAVING_StandbyMode1_ZoneSpeed		0x226063
#define ENERGYSAVING_StandbyMode1_ConveyorSpeed	0x226064

#define LIGHTTOWER_SPChange						0x226065
#define LIGHTTOWER_Ready						0x226066
#define LIGHTTOWER_Warning						0x226067
#define LIGHTTOWER_Alarm_Cooldown				0x226068
#define LIGHTTOWER_EStop_Cooldown				0x226069
#define LIGHTTOWER_ReadyBoards					0x22606A

#define SMEMA_MesActive							0x22606B
#define SMEMA_MesEnabled						0x22606C
#define	SMEMA_LaneBoardSpacing					0x22606D
#define	SMEMA_LaneBoardLength					0x22606E

#define LOTPROC_DEVDRVCMD						0x226100

#define RECIPETRIGGER_releaseControlComm		0x226101
#define MASSANALOG_setOnTime					0x226102
#define MASSCONTROLLER_CONFIG					0x226103
#define TEMPZONE_shutdownBlowers				0x226104
#define BCIO_setInput						0x226105
#define BCIO_setOutput						0x226106
#define BCIO_setOutputR						0x226107
#define BCIO_setOutputY						0x226108
#define BCIO_setOutputG						0x226109
#define BCIO_boardScanned					0x22610A
#define BCIO_setModeR						0x22610B
#define BCIO_setModeY						0x22610C
#define BCIO_setModeG						0x22610D
#define BCIO_setTime						0x22610E
#define BCIO_setEnable						0x22610F
#define BCIO_setECEnable					0x226110
#define MASS_PARAM_BEGIN					0x226111
#define HEATZONEBLOWER_setOnTime			0x226112
#define HEATZONEBLOWER_100H_STARTUP			0x226113
#define	OVEN_setCOOLDOWNachieved			0x226114

#define TRANSFER_TABLE_PROCESS				0x226115
#define HEATZONEBLOWER_MAXIMUM				0x22280E
#define BLOWER_GlobalHighLimit				0x226116
#define BLOWER_GlobalLowLimit				0x226117
#define FLUXHEATER_shutdownBlowers			0x226118
#define BOARDQUEUE_panalIdEnable			0x226119
#define BOARDQUEUE_lotProcessingEnable		0x22611A

#define NEWLOTPROC_DEVDRVCMD				0x22611B

#define BOARDQUEUE_clearCarrierVariables	0x22611C
#define BLOWER_GlobalLowStandbyLimit		0x22611D
#define BLOWER_GlobalHighStandbyLimit		0x22611E
#define OVEN_variousSettingsVII				0x226120
#define APCO_ValidScan						0x226121
#define OVEN_APCORuntimeEnable				0x226122
#define APCO_InvalidateScan					0x226123

#define TEMPZONES_setStartupGrpControlDO	0x226124
#define TEMPZONES_setStartupGrpControlGRP	0x226125
#define SMEMA_SecsGemControl				0x226126
#define GetBitPackedData					0x226127
#define OVEN_variousSettingsVIII			0x226128
#define SECSGEM_Entry_option				0x226129
#define OVEN_variousSettingsX				0x22612A
#define	OVEN_recipeLoadBoardEntryWait		0x22612B
#endif
