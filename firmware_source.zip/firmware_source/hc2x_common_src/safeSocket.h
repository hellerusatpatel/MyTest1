/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

#ifndef _SAFESOCKET_H_
#define _SAFESOCKET_H_

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

//#define ALLOW_DEBUG_STATEMENTS 1
#define SS_MAX_CRC_SIZE		10000
#define SS_MAX_SEG_SIZE		40000 //should match C:\projects\heller\source\heller_comm_control\safeSocket.h(14):#define SS_MAX_SEG_SIZE

#define SS_CHECK_BYTES		0xA5A5

#define SS_NUMBER_CRCS_PAYLOAD	3
#define SS_NUMBER_CRCS_HDR		1
#define SS_NUMBER_CRCS_TOTAL	(SS_NUMBER_CRCS_PAYLOAD + SS_NUMBER_CRCS_HDR)

// These are the flags for the SSHdr.
#define SS_FLAGS_NONE		0x000000000
#define SS_FLAGS_ACK		0x000000001
#define SS_FLAGS_ERR		0x000000002
#define SS_FLAGS_HDRCRC		0x000000004
#define SS_FLAGS_MSGCRC		0x000000008
#define SS_FLAGS_SEQNUM		0x000000010
#define SS_FLAGS_CHKBYTES	0x000000020
#define SS_FLAGS_TIMEOUT	0x000000040

#define SS_LISTEN_BACKLOG	10

#define SS_SEND_TIMEOUT_MS	650		// Timeout send operations (in milliseconds)

typedef struct SafeSocket_s {
	int listenSd;
	int clientSd;
	unsigned short seqNum;	// next expected sequence number
	unsigned short port;	// port to receive clients on
	unsigned short retries; // number of times to retry on failure (send only)
	time_t timeout; // timeout in millisecs (no comm, close)
	struct timeval lastCommTime;

	int bUseNonBlocking;	// set to non-zero to initialize a O_NONBLOCK socket

	struct sockaddr_in clientAddr;
} SafeSocket;

typedef struct SSHdr_s {
	unsigned int crcHeader;		// crc of header excluding this field, and crcMsg[]
	unsigned int crcMsg[SS_NUMBER_CRCS_PAYLOAD];		// crc of payload

	unsigned int checkBytes;	// known pattern
	unsigned int seqNum;		// ever increasing by one sequence
	unsigned int len;			// length of following payload
	unsigned int opCode;		// op code describing format of payload
	unsigned int flags;			// flags for the message
} SSHdr;

typedef enum SSOpCodes_e {
	SSOpGetPVT = 0,
	SSOpCarrier = 0,
	NumSSOpCodes
} SSOpCodes;

// These are the flags for the SafeSocket_() methods.
typedef enum SSErr_e {
	SSErrNone = 0,
	SSErrCRCHeader,
	SSErrCRCMsg,
	SSErrCheckBytes,
	SSErrTimeout,		// 4
	SSErrOpCode,
	SSErrLen,			// Didn't rec'v the requested amount of data
	SSErrSeqNum,		// 7
	SSErrConn,
	SSNullPtr,
	SSNoData,			// recv'd no data
	SSErrAck,
	SSUnknown,
	SSErrPayloadSize,
} SSErr;

void SafeSocket_Constructor(SafeSocket* pSS);

// Must set port and retries of the SS prior to calling
// For listing to clients.
unsigned short SafeSocket_Init(SafeSocket* pSS);

// Must set port and retries of the SS prior to calling
// For connecting to server.
SSErr SafeSocket_Connect(SafeSocket* pSS, char* ip);

// Check for client connection and/or message
int SafeSocket_AcceptClient(SafeSocket* pSS);
void SafeSocket_CloseClient(SafeSocket* pSS);

SSErr SafeSocket_CheckSocket(SafeSocket* pSS);
SSErr SafeSocket_ReadClientData(SafeSocket* pSS, int* pSize);
SSErr SafeSocket_VerifyClientData(SafeSocket* pSS);
SSErr SafeSocket_GetClientMsg(unsigned int* pOpCode, unsigned int* pPayloadLen, unsigned char** pPayload);

SSErr SafeSocket_SendResp(SafeSocket* pSS, unsigned int opCode, unsigned char* payload, int size);
SSErr SafeSocket_SendTotal(SafeSocket* pSS, int size);

SSErr SafeSocket_SendErrorResp(SafeSocket* pSS, unsigned int opCode, SSErr ssError);

void SafeSocket_PrintHeader( SSHdr* pHdr );

#endif // #ifndef _SAFESOCKET_H_
