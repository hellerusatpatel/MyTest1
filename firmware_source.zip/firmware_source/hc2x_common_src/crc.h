/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

#ifndef _CRC_H_
#define _CRC_H_

// 32-bit CRC table (used to generate CRC)
extern unsigned long CRC32BitTable[256];

unsigned int Calc32BitCRC(unsigned int count, unsigned char* buffer);

#endif // #ifndef _CRC_H_
