/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2001, All Rights Reserved
                    Company Confidential

	File:			LotProcessingCmds.h

	Description:	Lot Processing Command definitions

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
 
#ifndef __LOTPROCESSINGCMDS_H__
#define __LOTPROCESSINGCMDS_H__

//*****************************************************************************
// Class Board
//
// Abstract:
//	Each board in the oven will have known positions or times.
//	If counters are used then the position of the belt in centimeters can be used.
//	If a frequency to analog converter is used then the summation of the speeds 
//	divided by the number of counts to get average speed which will be as close
//	as we can get to the distance the board has traveled with the best possible
//  resolution.
//
//	Programmer: Steven Young
//	Date: 05/14/1998
//
//*****************************************************************************

#define LOTPROC_COMMAND				2000001	// Op Code read by Linux App

#define LOTPROC_EVENT_REQ			1		// Event Request - check for and retrieve pending events from HC2X
#define LOTPROC_EVENT_RESP			2		// Event Response - contains event information (see LotProcEvent)
#define LOTPROC_EVENT_CLEAR			3		// Event Clear - clear retrieved/validated events from the HC2X
#define LOTPROC_EVENT_CLEAR_ACK			4		// Event Clear Acknowlege - confirm a clear of events (mirror of command)
#define LOTPROC_LOTDEF				5		// Lot Definition - definition for the next lot
#define LOTPROC_LOTDEF_ACK			6		// Lot Definition Acknowledge - confirm a lot definition command (mirror of command)
#define LOTPROC_ABORT				7		// Lot Abort - abort a specific lot
#define LOTPROC_ABORT_ACK			8		// Lot Abort Acknowledge - confirm a lot abort command (mirror of command)
#define LOTPROC_ERROR				9		// Event Error Response - detected an issue with the previous command
#define LOTPROC_STATUS_REQ			10		// Status Request - retreive all MAX_USER_LOTS of LotProcLotStatus from HC2X
#define LOTPROC_STATUS_RESP			11		// Status Response - contains MAX_USER_LOTS count of LotProcLotStatus
#define LOTPROC_SMEMA_REQ			12		// request to set log flag for smema
#define LOTPROC_SMEMA_RESP			13		// response to set log flag for smema contains smema information

#define LOTPROC_INVALID_LOT			0		// Invalid/Undefined Lot ID

#define LOTPROC_ERR_NOERROR			0		// No error error code
#define LOTPROC_ERR_GENERR			1		// General error (CRC, size, check bytes, etc.)
#define LOTPROC_ERR_MAXLOTS			2		// Maximum number of lots in use
#define LOTPROC_ERR_UNKNOWNLOT		3		// Lot referenced in command is not defined
#define LOTPROC_ERR_UNKNOWNEVENT	4		// Event referenced in command is not defined

#define	MAX_USER_LOTS				3		// Maximum number of lots that can live in the driver at any one time

#define	MAX_EVENTS_PER_PACKET		50		// Maximum number of events that will fit in a packet

#define MAX_LOTPROC_MSG_SIZE		1556	// This is more than the largest size a lot message

#define LOTPROC_CHECKBYTES			0xA5A5

#define LOTPROC_BOARD_ENTRANCE		0
#define LOTPROC_BOARD_EXIT			1

#define LOTPROC_POS_LEADING			0
#define LOTPROC_POS_TRAILING		1
#define LOTPROC_POS_DROPPED			2
#define LOTPROC_POS_ENTR_STOP		3
#define LOTPROC_POS_EXIT_STOP		4
#define LOTPROC_POS_DROPPED_LEAD	5

#pragma pack(1)

// NOTE: LotProcHdr should be preceeded by HC2XHdr
typedef struct LotProcHdr_s {
	WORD		subOpCode;		// sub op code for lot processing specific command
	WORD		msgSize;		// includes this message size
	WORD		checkBytes;		// checkbytes to prevent issues with all zeros/ones
	WORD		crc;			// CRC for data verification
} LotProcHdr;

typedef struct LotProcEvent_s {
	DWORD		highTime;		// MSB portion of __tim364_t representation of the event's timestamp
	DWORD		lowTime;		// LSB portion of __tim364_t representation of the event's timestamp
	DWORD		milliseconds;	// milliseconds portion of the event's timestamp
	WORD		eventSeqNum;	// sequence number of the event
	WORD		lotID;			// ID of the Lot
	WORD		carrierIndex;	// carrier's position in the lot
	CHAR		inUse;			// carrier/event is valid or not (0 or 1 resepectively)
	CHAR		lane;			// lane identification
	CHAR		entryExit;		// 0 is entry, 1 is exit
	CHAR		position;		// 0: Leading, 1: Trailing, 2: Dropped, 3: EntryStopped, 4: ExitStopped
	CHAR		lotStart;		// non-zero if start of lot
	CHAR		lotEnd;			// non-zero if end of lot
	CHAR		lastEnter;		// non-zero if this is the last board of the lot to enter
	CHAR		firstExit;		// non-zero if this is the first board of the lot to exit
	CHAR		cooldown;		// non-zero if the event was generated while in cooldown
	CHAR		reserved;		// reserved for padding
} LotProcEvent;

typedef struct LotProcEventReq_s {
	LotProcHdr		hdr;
	CHAR			reserved[492];					// reserved for padding
} LotProcEventReq;

typedef struct LotProcEventResp_s {
	LotProcHdr		hdr;
	CHAR			numValidEvents;					// number of valid events in the packet
	CHAR			reserved[3];					// reserved for padding
	LotProcEvent	events[MAX_EVENTS_PER_PACKET];	// the events
} LotProcEventResp;

typedef struct LotProcEventAck_s {
	LotProcHdr	hdr;
	CHAR		numEvents;							// number of valid event sequence numbers
	CHAR		reserved[3];						// padding for alignment
	WORD		eventSeqs[MAX_EVENTS_PER_PACKET];	// sequence numbers of events to be cleared
	CHAR		reserved2[388];						// pad the packet to ensure it meets the min size of 512
} LotProcEventAck;

typedef struct LotProcLotDef_s {
	LotProcHdr	hdr;
	WORD		lotId;				// unique identifier for the lot
	WORD		carrierCount;		// expected count of carriers in the lot
	CHAR		reserved[488];		// pad the packet to ensure it meets the min size of 512
} LotProcLotDef;

typedef struct LotProcLotAbort_s {
	LotProcHdr	hdr;
	WORD		lotId;
	CHAR		reserved[490];
} LotProcLotAbort;

typedef struct LotProcError_s {
	LotProcHdr	hdr;
	WORD		subOpCode;			// subOpCode the error is in response to
	WORD		errorCode;			// error code denoting the error
	CHAR		reserved[488];		// pad the packet to ensure it meets the min size of 512
} LotProcError;

typedef struct LotProcSMEMA_s {
	LotProcHdr	hdr;
	CHAR		uilotflagstatus;		// status of the lot boolean for smema processing
	DWORD		smemaStatus;			//bit pack of current smema variables		
	CHAR		reserved[487];		// pad the packet to ensure it meets the min size of 512
} LotProcSmema;
typedef struct LotProcLotStatus_s {
	WORD		lotId;
	WORD		inOvenCount;
	WORD		processedCount;
	WORD		expectedCount;
	CHAR		bAborted;
	CHAR		bInUse;
	CHAR		reserved[2];
} LotProcLotStatus;

typedef struct LotProcLotStatusReq_s {
	LotProcHdr	hdr;
	CHAR		reserved[492];
} LotProcLotStatusReq;

typedef struct LotProcLotStatusResp_s {
	LotProcHdr			hdr;
	LotProcLotStatus	lots[MAX_USER_LOTS];
	CHAR				reserved[456];
} LotProcLotStatusResp;

#pragma pack()		// return to Zp setting in windows app.

#endif // #ifndef __LOTPROCESSINGCMDS_H__

