/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

/*
** updater.c
*/

#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <linux/if_ether.h>

#include "crc.h"
#include "../hc2xwd/hc2xwd.h"

#define MILLION 1000000
#define PORT 1105   // port we're listening on
#define GET_CONFIG 1001
#define SEND_SEGMENT 2001
#define FILE_CRC 2002
#define CREATE_FILE 2003
#define SEND_CONFIG 3001
#define UPDATE_CONFIG 3002
#define REBOOT_HC2X 4001
#define READ_HC2_MODULES 4002
#define FALSE 0
#define TRUE 1
#define RES_SUCCESS 0
#define RES_FAILURE -1

#define DIR_TEMP		"/usr" //this directory will hold temporary files so we will only write the jffs when a commit config is recieved
#define DIR_FIRMWARE	"/mnt/jffs"
#define UPDATER_LOG		"/mnt/jffs/updater.log"
#define FILE_VERSION 	"hc2_version"

#define SM_BUF_SIZE	1016
#define SIZE_HEADER	14
#define SIZE_MAXDATA	1000

#define CHECK_BYTE_LENGTH 2
#define FILE_CREATED 1
//
// Handler_ClientCommunication() error returns
//
#define CLIENTCOMM_SUCCESS		1
#define CLIENTCOMM_FAILURE		-1
#define CLIENTCOMM_REBOOT		-2


unsigned char g_buffer[SM_BUF_SIZE] = {0};

unsigned char g_buffer_temp1[SM_BUF_SIZE] = {0};

unsigned char g_buffer_err[SM_BUF_SIZE] = {0};

unsigned char g_firmware_filename[SM_BUF_SIZE] = {0};
unsigned int g_bufferField_function;
unsigned int g_bufferField_sequenceNum;
unsigned int g_bufferField_dataCount;

int g_firmware_next_nextSequenceNum = 0;
int g_firmware_fd = -1;

char g_deviceFile[SM_BUF_SIZE] = "";
int g_client_fd;

char g_wdFile[] = "/dev/hc2xwd";
int g_wd_fd = 0;

void initFirmwareFile();
void writeFileSegment();
int createValidatedTemporaryFile();

int readVersions(int iSequenceNumber);
int writeVersions();
void updateConfiguration();
void unmountJffs();

int Handler_ClientCommunication();
int send_all(int sockfd, unsigned char* buff, int* len);
int initialize_socket(int* skt);

//////////////////////////////////
//
//	Global function variables to avoid stepping on memory.
//
//////////////////////////////////
fd_set master;   // master file descriptor list
fd_set read_fds; // temp file descriptor list for select()
struct sockaddr_in myaddr;     // server address
struct sockaddr_in remoteaddr; // client address
int fdmax = 0;        // maximum file descriptor number
int g_listener = 0;     // listening socket descriptor
int newfd;        // newly accept()ed socket descriptor
int reuse_addr = 1;        // for setsockopt() SO_REUSEADDR, below
socklen_t addrlen;
int i = 0;
int status = 0;
unsigned int socket_cnt = 0;

int nbytes = 0;
unsigned int* pInt = NULL;
unsigned short* pShortt = NULL;
unsigned short sizeField = 0;
int offset = 0;
int ret_offset = 0;

int total = 0;
int n = 0;
int bytes_left = 0;

int cmdSize = 0;
char ch;

struct timeval tpstart;
struct timeval tpend;
long timediff = 0;

unsigned int nRetVal = 0;
unsigned short nSize = 0;


unsigned short getShort(char *p)
{
	// Due to a compiler issue with pulling shorts out of unsigned
	// char pointers (they come out backwards), this function corrects that.
	unsigned int nRetVal;

	nRetVal = (((unsigned short)(p[1]) << 8) & 0xFF00) |
			((unsigned short)(p[0]) & 0x00FF);

	return nRetVal;
}


unsigned int getInt(unsigned char *p)
{
   unsigned int nRetVal;

   nRetVal = (((unsigned int)(p[3]) << 24) & 0xFF000000) |
             (((unsigned int)(p[2]) << 16) & 0x00FF0000) |
             (((unsigned int)(p[1]) << 8) & 0x0000FF00) |
             ((unsigned int)(p[0]) & 0x000000FF);

   return nRetVal;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  writeInt
		
			changes byte order
	
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void writeInt(unsigned char* p, unsigned int val)
{
	int i = 0;
	unsigned int* ptrVal = &val;
	unsigned char* ptrChar = NULL;
	ptrChar = (unsigned char*)ptrVal;
	for( i = 0; i < sizeof(unsigned int); i++)
	{
		*(p+i) = *ptrChar;
		ptrChar++;
	}
	return;
}

int initialize_socket(int* skt)
{
	if ( *skt > 0 )
	{
		close(*skt);
	}

	// get the listener
	*skt = socket(AF_INET, SOCK_STREAM, 0);
	if ( *skt == -1 )
	{
		perror("socket");
		return -1;
	}

	// lose the pesky "address already in use" error message
	status = setsockopt(*skt, SOL_SOCKET, SO_REUSEADDR, 
		&reuse_addr, sizeof(int));
	if ( status == -1 )
	{
		perror("setsockopt");
		return -1;
	}

	// bind
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = INADDR_ANY;
	myaddr.sin_port = htons(PORT);
	memset(&(myaddr.sin_zero), '\0', 8);
		
	status = bind(*skt, (struct sockaddr *)&myaddr, sizeof(myaddr));
	if ( status == -1 )
	{
		perror("bind");
		return -1;
	}

	// listen
	status = listen(*skt, 10);
	if ( status == -1 )
	{
		perror("listen");
		return -1;
	}

	return 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  main

 RETURNS:   int - 1
 SEE ALSO:
------------------------------------------------------------------------*/
int main()
{
	unsigned char bRunProgram = 1;
	struct timeval toSelect = { 0 };

	unsigned char ping_str[30];

	int nReturn = 0; // 0 on success

	socket_cnt = 0;
	reuse_addr = 1;

	g_wd_fd = open(g_wdFile, O_RDWR);


	FD_ZERO(&master);    // clear the master and temp sets
	FD_ZERO(&read_fds);

	fprintf(stderr, "Updater with CRC verification.\n");

	status = initialize_socket(&g_listener);
	if ( status == -1 )
	{
		nReturn = 1;
	}
	else
	{
		// add the listener to the master set
		FD_SET(g_listener, &master);

		// keep track of the biggest file descriptor
		fdmax = g_listener; // so far, it's this one

		// main loop
		while ( bRunProgram )
		{

			// Don't block on the select() call.  
			toSelect.tv_sec = 0;
			toSelect.tv_usec = 0;

			read_fds = master; // copy it
			status = select(fdmax+1, &read_fds, NULL, NULL, &toSelect );
			if ( status == -1 )
			{
				perror("select");
				bRunProgram = 0;
				nReturn = 1;
			}
			else
			{
				// run through the existing connections looking for data to read
				for(i = 0; (i <= fdmax) && bRunProgram; i++)
				{
					if (FD_ISSET(i, &read_fds))
					{ 
						// we got one!!
						if (i == g_listener)
						 {
							// handle new connections
							addrlen = sizeof(remoteaddr);
							newfd = accept(g_listener, (struct sockaddr *)&remoteaddr, &addrlen);
							if ( newfd == -1 )
							{
								perror("accept");
							} 
							else
							{
								FD_SET(newfd, &master); // add to master set
								if (newfd > fdmax)
								{    // keep track of the maximum
									fdmax = newfd;
								}

								socket_cnt++; //remove if re-adding g_ioFile

							}
						}
						else if( i > g_listener)
						{

							g_client_fd = i;
							status = Handler_ClientCommunication();
							if ( status <= 0 )
							{
								close(i); // bye!
								FD_CLR(i, &master); // remove from master set
								socket_cnt--;

								if ( status == CLIENTCOMM_REBOOT )
								{
									// turn off loops and exit program
									bRunProgram = 0;
								}
							}
						}
					}
				}
			}
		}
	}

	return nReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Handler_ClientCommunication


 RETURNS:   int, 1 success other length, negative error
 SEE ALSO:
------------------------------------------------------------------------*/
int Handler_ClientCommunication()
{
	int bPassedCRC = FALSE;
	int nReturn = CLIENTCOMM_SUCCESS;

	memset(g_buffer, 0, SM_BUF_SIZE);

	// All messages are  1016 (SM_BUF_SIZE) bytes.
	// Read SM_BUF_SIZE bytes off the ethernet 
	// and then determine what type of message it is and if we need to read more.
	nbytes = recv(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
	if ( nbytes < SM_BUF_SIZE )
	{
		// got error or connection closed by client
		if (nbytes == 0)
		{
			// connection closed
			printf("heller_app: socket %d hung up\n", g_client_fd);
		}
		else if( nbytes < 0)
		{
			perror("recv(function)");
		}
		
		nReturn = nbytes;
	}
	else
	{
		bPassedCRC = Verify16BitCRC(g_buffer, SM_BUF_SIZE);
		if( bPassedCRC == 0 )
		{
			nReturn = CLIENTCOMM_FAILURE;
		}
		else
		{
			g_bufferField_function = getInt(g_buffer);

			offset = 0;
			offset += sizeof(unsigned int);

			g_bufferField_sequenceNum = getInt(g_buffer+offset);

			offset += sizeof(unsigned int);
			offset += CHECK_BYTE_LENGTH; // skip over check bytes
		 
			g_bufferField_dataCount = getInt(g_buffer+offset);

			//
			//processing code
			//
			switch( g_bufferField_function )
			{
				case GET_CONFIG: 
					readVersions(g_bufferField_sequenceNum);
					break;
					
				case SEND_SEGMENT: 
					writeFileSegment();
					break;
				
				case FILE_CRC:
					status = createValidatedTemporaryFile();
					break;
					
				case SEND_CONFIG: 
					writeVersions();
					break;
					
				case UPDATE_CONFIG:
					updateConfiguration();
					break;
					
				case REBOOT_HC2X: 
					if(g_client_fd!=-1)
					{
						close(g_client_fd); // force the send
					}
					if(g_wd_fd!=-1)
					{
						ioctl(g_wd_fd, IOCTL_ENABLE_WD, UPDATER_DOG);//enable the watchdog to cycle the hc2
						close(g_wd_fd);
					}
					nReturn = CLIENTCOMM_REBOOT;
					break;
					
				case READ_HC2_MODULES:
					break;
					
				case CREATE_FILE:
					initFirmwareFile();
					break;

				default:
					break; 	
			}
		}
	}

	return nReturn;
}

int send_all(int sockfd, unsigned char* buff, int* len)
{
	n = 0;
	bytes_left = *len;
	total = 0;
	
	while ( total < *len )
	{
		n = send(sockfd, buff+total, bytes_left, 0);
		if ( n == -1 )
			break;
		total += n;
		bytes_left -= n;
	}
	
	*len = total;	// number actually sent
	return (n == -1)? -1 : 0;	// return -1 on failure or 0 on success
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  unmountJffs

			unmounts the JFFS, power cycles the hc2.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void unmountJffs()
{
	// echo message back to client
	send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);

	// unmount the jffs directory
	snprintf(g_buffer_temp1, SM_BUF_SIZE, "umount /mnt/jffs/" );
	system(g_buffer_temp1);

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  writeVersions
		
			creates a version file in the temporary directory
	
 RETURNS:   int 0
 SEE ALSO:
------------------------------------------------------------------------*/
int writeVersions()
{
	int fd = 0;
	int bytes_written = 0;
	int bContinue = 1;

	snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", 
		DIR_TEMP, FILE_VERSION );
	unlink(g_buffer_temp1);
	fd = open(g_buffer_temp1, O_CREAT | O_TRUNC | O_RDWR );
	if ( fd == -1 )
	{
		perror(g_buffer_temp1);
	}
	else
	{
		bytes_written = write(fd, g_buffer+SIZE_HEADER, 
			g_bufferField_dataCount);
		if ( bytes_written == -1 )
		{
			perror("writeVersion");
			bContinue = 0;	
		}
		
		close(fd);
		if(bContinue)
		{
			// echo message back to client
			send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
		}
	}
	return 0;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  readVersions


	RETURNS:	int true if file existed, false if it failed to open
	SEE ALSO:
--------------------------------------------------------------------*/
int readVersions(int iSequenceNumber)
{
	int iFileDesc = 0;
	int iReadCount = 0;
	int nbytes = 0;
	int iReturn = TRUE;
	unsigned char cSendBuffer[SM_BUF_SIZE];
	const int SIZE_HEADER_FOOTER = 16;
	const int VERSION_SIZE = SM_BUF_SIZE - SIZE_HEADER_FOOTER;
	unsigned char versionInfo[VERSION_SIZE];
	int index = 0;
	unsigned char hi = 0;
	unsigned char lo = 0;
	unsigned int iReturnFunction = GET_CONFIG;

	snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s", DIR_FIRMWARE, FILE_VERSION);
	iFileDesc = open(g_buffer_temp1, O_RDONLY);

	index = 0;

	writeInt(cSendBuffer+index, iReturnFunction);
	index += 4;

	writeInt(cSendBuffer+index, iSequenceNumber);
	index += 4;

	cSendBuffer[index++] = 0xAA;
	cSendBuffer[index++] = 0x55;
	if( iFileDesc <= 0 )
	{	
		perror(g_buffer_temp1);
		iReturn = FALSE;
		writeInt(cSendBuffer + index, iReadCount);
		index += 4;

	}
	else
	{
		iReadCount = read(iFileDesc, versionInfo, VERSION_SIZE); 
		close(iFileDesc);

		writeInt(cSendBuffer + index, iReadCount);
		index += 4;

		memcpy(cSendBuffer + index, versionInfo, VERSION_SIZE); 
	}
	index += VERSION_SIZE;
	Calc16BitCRC(cSendBuffer, index, &hi, &lo);
	cSendBuffer[index++] = hi;
	cSendBuffer[index++] = lo;

	nbytes = send(g_client_fd, cSendBuffer, index, 0);
	
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  updateConfiguration
		
			copies files into /mnt/jffs, verifies crc against source
			reports error if any
	
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void updateConfiguration()
{
	char* p = NULL;
	char tokens[] = "\n\t ";
	char dataBuffer[SIZE_MAXDATA] = {0};	 
	int res = RES_FAILURE;
	int source_fd = -1;
	int dest_fd = -1;
	int successes = 0;
	int i = 0;
	FILE* lastUpdateLog = 0;
	char* errStr = 0;
	int errStrSz = 0;
	long sz = 0;
	unsigned char hi = 0;
	unsigned char lo = 0;
	int iStringLength = 0;
	unsigned char buffer_source[SM_BUF_SIZE] = {0};
	unsigned char buffer_dest[SM_BUF_SIZE] = {0};
	unsigned long source_crc = 0;
	unsigned long dest_crc = 0;
	int iUpdated = 0;
	for(i = 0; i < SIZE_MAXDATA; i++)
	{
		dataBuffer[i] = 0;
	}

	for( i = 0; i < g_bufferField_dataCount; i++)
	{
		dataBuffer[i] = g_buffer[ (SIZE_HEADER + i) ];
	}

	lastUpdateLog = fopen(UPDATER_LOG, "w");

	// setup a return error string...
	g_buffer_err[0] = '\0';
	errStr = g_buffer_err;
	errStrSz  = SM_BUF_SIZE;

	//
	// For each of the updated files in the data buffer, delete the 
	// old component file and copy the updated version to the correct name.
	//
	p = strtok(dataBuffer, tokens);
	res = RES_SUCCESS;

	while ( p && (RES_SUCCESS == res) )
	{
		iStringLength = strlen(p);
		iUpdated = 1;



		if (iStringLength)
		{
			// save previous version
			snprintf(g_buffer_temp1, SM_BUF_SIZE, "mv %s/%s %s/%s.prev",
				DIR_FIRMWARE, p, DIR_FIRMWARE, p);
			res = system(g_buffer_temp1);

			if (RES_SUCCESS != res)
			{
				fprintf(lastUpdateLog, "command failed: %s\n", g_buffer_temp1);
				// continue...maybe it's a new file?
				res = RES_SUCCESS;
			}
			//crc validation part 1
			snprintf(buffer_source, SM_BUF_SIZE, "%s/%s.update", 
			DIR_TEMP, p );
			source_fd = open(buffer_source, O_RDWR );
			if(source_fd == -1 )
			{
				res = RES_FAILURE;
			}
			else
			{
				source_crc = CalculateFile32BitCRC(source_fd);
				close(source_fd);
			}
			if(RES_SUCCESS == res)
			{
				//put file in jffs
				snprintf(g_buffer_temp1, SM_BUF_SIZE, "mv %s/%s.update %s/%s",
					DIR_TEMP, p, DIR_FIRMWARE, p);
				res = system(g_buffer_temp1);
				
				//crc validation part 2
				//snprintf(buffer_source, SM_BUF_SIZE, "%s/%s.update", 
				//DIR_TEMP, p );
				snprintf(buffer_dest, SM_BUF_SIZE, "%s/%s", 
				DIR_FIRMWARE, p );

				dest_fd = open(buffer_dest, O_RDWR );

				if(dest_fd == -1)
				{
					res = RES_FAILURE;
				}
				else
				{
					dest_crc = CalculateFile32BitCRC(dest_fd);
					close(dest_fd);
				}

				if( RES_SUCCESS == res)
				{
					if(dest_crc != source_crc)
					{
						res = RES_FAILURE;
						fprintf(lastUpdateLog, "crc failed: %s\n", g_firmware_filename);
						fprintf(stderr, "Failed updating %s:\n\t'%s'",
							p, g_firmware_filename);
						snprintf(errStr, errStrSz, "Failed updating %s:\n\t'%s'",
							p, g_firmware_filename);
					}
				}
				if (RES_SUCCESS != res)
				{
					// report where we failed
					fprintf(lastUpdateLog, "command failed: %s\n", g_buffer_temp1);
					fprintf(stderr, "Failed updating %s:\n\t'%s'",
						p, g_buffer_temp1);
					snprintf(errStr, errStrSz, "Failed updating %s:\n\t'%s'",
						p, g_buffer_temp1);
				}
				else
				{
					snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s", DIR_FIRMWARE, p);
					chmod(g_buffer_temp1, S_IRUSR | S_IWUSR | S_IXUSR);
					fprintf(lastUpdateLog, "%s updated successfully.\n", p);
					++successes;
				}
			
			}
			else//source file failed open
			{
				fprintf(lastUpdateLog, "file failed to open: %s\n", g_firmware_filename);
				fprintf(stderr, "Failed updating %s:\n\t'%s'",
					p, g_firmware_filename);
				snprintf(errStr, errStrSz, "Failed updating %s:\n\t'%s'",
					p, g_firmware_filename);
			}
		}
		else
		{
			// empty file name...
			sz = strlen(errStr);
			snprintf(errStr + sz, errStrSz - sz, "Failed updating due to empty filename.",
				p, g_buffer_temp1);
			res = 1;
		}

		p = strtok(NULL, tokens);
	}
	// something failed, attemtp to put things back where they were before we started,
	//	then return an error to the host
	if (RES_SUCCESS != res)
	{
		// start at the begining and restore those files we successfully replaced
		memcpy(dataBuffer, g_buffer+SIZE_HEADER, g_bufferField_dataCount);
		p = strtok(dataBuffer, tokens);
		for (i = 0; p && i < (successes + 1); ++i)
		{
			// try to restore previous version
			snprintf(g_buffer_temp1, SM_BUF_SIZE, "mv %s/%s.prev %s/%s",
				DIR_FIRMWARE, p, DIR_FIRMWARE, p);
			res = system(g_buffer_temp1);
			if (RES_SUCCESS == res)
			{
				snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s", DIR_FIRMWARE, p);
				chmod(g_buffer_temp1, S_IRUSR | S_IWUSR | S_IXUSR);

				fprintf(lastUpdateLog, "%s restored successfully.\n", p);
			}
			else
			{
				fprintf(lastUpdateLog, "ERROR: %s failed restore.\n", p);
				sz = strlen(errStr);
				snprintf(errStr + sz, errStrSz - sz, "\nERROR: %s failed restore!", p);
			}

			p = strtok(NULL, tokens);
		}
		res = RES_FAILURE; // make sure it stays failed.
	}

	fclose(lastUpdateLog);

	// remove .prev files and .update (only will be there if there was a failure)
	memcpy(dataBuffer, g_buffer+SIZE_HEADER, g_bufferField_dataCount);
	p = strtok(dataBuffer, tokens);
	while (p)
	{
		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.prev", DIR_FIRMWARE, p);
		unlink(g_buffer_temp1);
		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", DIR_FIRMWARE, p);
		unlink(g_buffer_temp1);
		p = strtok(NULL, tokens);
	}
	if(!iUpdated)
	{
		res = RES_FAILURE;
	}


	if (RES_SUCCESS != res)
	{
		// send an error string back and update the CRC
		strncpy(g_buffer + SIZE_HEADER, errStr, SM_BUF_SIZE - 2 - SIZE_HEADER);
		sz = strlen(errStr);
		// NOTE: not sent in network byte order, sent little endian //sz = htonl(sz);
		memcpy(g_buffer + 10, &sz, sizeof(long));
		hi = 0xFF;
		lo = 0xFF;
		Calc16BitCRC(g_buffer, SM_BUF_SIZE - 2, &hi, &lo);
		g_buffer[SM_BUF_SIZE - 1] = lo;
		g_buffer[SM_BUF_SIZE - 2] = hi;
	}
	else
	{
		unmountJffs(); 
	}

	// echo message back to client
	send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  initFirmwareFile
			

 RETURNS:   creates a temporary target file.  each file segment will be added to this
 SEE ALSO:
------------------------------------------------------------------------*/
void initFirmwareFile()
{
	unsigned char hi = 0;
	unsigned char lo = 0;
	long sz = 0;
	int i = 0;
	unsigned char* ptrChar = g_firmware_filename;
	int iStringLength = 0;
	int bContinue = 1;

	for(i = 0; i < SM_BUF_SIZE; i++)
	{
		*(ptrChar + i) = 0;
	}
	ptrChar = g_firmware_filename;
	for( i = 0; i < g_bufferField_dataCount; i++)
	{
		*ptrChar = *( g_buffer+SIZE_HEADER + i );
		ptrChar++;
	}

	iStringLength = strlen(g_firmware_filename);
	if (iStringLength)
	{
		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.prev", 
			DIR_TEMP, g_firmware_filename );
		unlink(g_buffer_temp1);

		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", 
			DIR_TEMP, g_firmware_filename );
		unlink(g_buffer_temp1);

		g_firmware_next_nextSequenceNum = 0;

		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", DIR_TEMP, g_firmware_filename);
		g_firmware_fd = open(g_buffer_temp1, O_CREAT | O_TRUNC | O_RDWR );
		if ( g_firmware_fd == -1 )
		{
			perror(g_firmware_filename);
			bContinue = 0;
		}
		if(bContinue)
		{
			// echo message back to client
			send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
		}
	}
	else
	{
		// error back to client (not mirroring their message is an error)
		snprintf(g_buffer + SIZE_HEADER, SM_BUF_SIZE - 2 - SIZE_HEADER, "Empty filename!");
		sz = strlen(g_buffer + SIZE_HEADER);
		// NOTE: not sent in network byte order, sent little endian //sz = htonl(sz);
		memcpy(g_buffer + 10, &sz, sizeof(long));
		// recalculate CRC
		hi = 0xFF;
		lo = 0xFF;
		Calc16BitCRC(g_buffer, SM_BUF_SIZE - 2, &hi, &lo);
		g_buffer[SM_BUF_SIZE - 1] = lo;
		g_buffer[SM_BUF_SIZE - 2] = hi;
		send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
	}

	return;
}

void writeFileSegment()
{
	ssize_t bytes_written;

	if ( g_firmware_fd == -1 )
	{
		printf("ERROR: writeFileSegment: g_firmware_fd is invalid\n");
		return;
	}

	if ( g_bufferField_sequenceNum  != g_firmware_next_nextSequenceNum )
	{
		printf("ERROR: writeFileSegment: file transfer is out of sequence!\n");
		return;
	}
	
	bytes_written = write(g_firmware_fd, g_buffer+SIZE_HEADER, 
		g_bufferField_dataCount);
	if ( bytes_written == -1 )
	{
		perror("writeFileSegment");
		return;	
	}

	g_firmware_next_nextSequenceNum++;

	// echo message back to client
	send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  createValidatedTemporaryFile
		
			crc the file after uploading
	
 RETURNS:   int -1 ERROR
 SEE ALSO:
------------------------------------------------------------------------*/
int createValidatedTemporaryFile()
{
	unsigned long file_crc = 0;
	unsigned long calculated_file_crc = 0;
	char bDone = FALSE;
	int retval = 0;
	unsigned char hi = 0xFF;
	unsigned char lo = 0xFF;

	ssize_t bytes_read = 0;
	ssize_t bytes_written = 0;
	
	file_crc = getInt(g_buffer+SIZE_HEADER);

	close(g_firmware_fd);
	g_firmware_fd = -1;
	retval = -1;
	
	//
	// CRC the entire file and check it against the known crc.
	//
	snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", DIR_TEMP, g_firmware_filename);
	g_firmware_fd = open(g_buffer_temp1, O_RDWR );
	printf(g_buffer_temp1);
	if ( g_firmware_fd == -1 )
	{
		perror(g_firmware_filename);
	}
	else
	{
		calculated_file_crc = CalculateFile32BitCRC(g_firmware_fd);
	
		if ( calculated_file_crc == file_crc ) 
		{
			send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);
			retval = 1; // greater than 0 implies success
		}
		close(g_firmware_fd);
		g_firmware_fd = -1;
	}

	if (1 != retval)
	{

		// send back a message with empty data to signify error
		memset(g_buffer + SIZE_HEADER, 0, SM_BUF_SIZE - SIZE_HEADER);
		Calc16BitCRC(g_buffer, SM_BUF_SIZE - 2, &hi, &lo);
		g_buffer[SM_BUF_SIZE - 1] = lo;
		g_buffer[SM_BUF_SIZE - 2] = hi;
		send(g_client_fd, g_buffer, SM_BUF_SIZE, 0);

		// delete the update file to make sure it doesn't get used
		snprintf(g_buffer_temp1, SM_BUF_SIZE, "%s/%s.update", DIR_TEMP, g_firmware_filename);
		unlink(g_buffer_temp1);
	}

	return retval;
}

