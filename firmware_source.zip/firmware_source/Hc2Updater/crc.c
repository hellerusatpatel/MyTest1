/**************************************************************************

   imagic, Inc.    Copyright (C) 2005, All Rights Reserved
                   Company Confidential    
 
	File:	        alarm.c

	Description:	CPU Control Card CRC Module
					
	Modifications :	Version		Author	Date		Description
						A		jmr		03/03/05	Initial pre-release
	                						 
	This is a trade secret of imagic, inc. and is protected by copyright. 
	All unauthorized uses prohibited.
***************************************************************************/

#include "crc.h"
#include "crctable.h"

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  Calc16BitCRC 
 			calculates two crc verification bytes based on message
 			buffer and length.
 GLOBALS:
 RETURNS:   none
 SEE ALSO:  
------------------------------------------------------------------------*/
void Calc16BitCRC(unsigned char *Msg, unsigned int Len, 
		unsigned char *retCRChi, unsigned char *retCRClo)
{
	unsigned CRChi = 0xFF;
	unsigned CRClo = 0xFF; 
	unsigned int index;
	
	while (Len--)
	{ 
		index = CRChi ^ *Msg++;
		CRChi = CRClo ^ aCRChi[index];
		CRClo = aCRClo[index];
	} 
	*retCRChi = CRChi;
	*retCRClo = CRClo;
} 

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  Verify16BitCRC 
 
 			calculates the crc of the given buffer, and compares it to
 			the values that are travelling with the buffer.
 GLOBALS:
 RETURNS:   1 if calculated CRC matches, 0 otherwise.
 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int Verify16BitCRC(unsigned char *buffer, unsigned int count)
{
	unsigned char CRChi = 0xFF;
	unsigned char CRClo = 0xFF;
	unsigned int index;

	while (count--)
	{
		index = CRChi ^ *buffer++;
		CRChi = CRClo ^ aCRChi[index];
		CRClo = aCRClo[index];
	}

	if ((!CRChi) && (!CRClo))
	   return 1; 	/* crc ok */
	else
	   return 0;	/* crc faulty */
}


/*
 * This routine is responsible for actually performing the
 * calculation of the 32 bit CRC for the entire file.  We
 * precondition the CRC value with all 1's, then invert every bit
 * after the entire file has been done.  This gives us a CRC value
 * that corresponds with the values calculated by PKZIP and ARJ.
 * The actual calculation consists of reading in blocks from the
 * file, then updating the CRC with the value for that block.  The
 * CRC work is done by another the CalculateBufferCRC routine.
 */

unsigned long CalculateFile32BitCRC(int fd)
{
    unsigned long crc;
    int count;
    unsigned char buffer[ 512 ];
    int i;

    crc = 0xFFFFFFFFL;
    i = 0;
    for ( ; ; ) {
		count = read(fd, buffer, 512);
        if ( count == 0 )
            break;
        crc = CalculateBuffer32BitCRC( count, crc, buffer );
    }
    return( crc ^= 0xFFFFFFFFL );
}

/*
 * This routine calculates the CRC for a block of data using the
 * table lookup method. It accepts an original value for the crc,
 * and returns the updated value.
 */

unsigned long CalculateBuffer32BitCRC( unsigned int count, unsigned long crc, void *buffer )
{
    unsigned char *p;
    unsigned long temp1;
    unsigned long temp2;

    p = (unsigned char*) buffer;
    while ( count-- != 0 ) {
        temp1 = ( crc >> 8 ) & 0x00FFFFFFL;
        temp2 = CRC32BitTable[ ( (int) crc ^ *p++ ) & 0xff ];
        crc = temp1 ^ temp2;
    }
    return( crc );
}

