/**************************************************************************

   imagic, Inc.    Copyright (C) 2005, All Rights Reserved
                   Company Confidential    
 
	File:	        crc.h

	Description:	Header file for CRC Table
					
	Modifications :	Version		Author	Date		Description
						A		jmr		03/03/05	Initial pre-release
	                						 
	This is a trade secret of imagic, inc. and is protected by copyright. 
	All unauthorized uses prohibited.
***************************************************************************/
#ifndef __CRC_H__
#define __CRC_H__

unsigned int Verify16BitCRC(unsigned char *buffer, unsigned int count);
void Calc16BitCRC(unsigned char *Msg, unsigned int Len, 
		unsigned char *retCRChi, unsigned char *retCRClo);

unsigned long CalculateFile32BitCRC(int fd);
unsigned long CalculateBuffer32BitCRC( unsigned int count, unsigned long crc, 
		void *buffer );

#endif
