/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __KERNEL__
	#define __KERNEL
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>

#include "encoder.h"
#include "tpo.h"
#include "hc2xio_exports.h"
#include "hc2xio.h"
#include "system.h"
#include "hc2xmem.h"
#include "SPIdef.h"

//******************************************************************************
// SystemInit
//
// Abstract:
//		Initializes CPU registers for operation.  This function is a global
//		collect-all to avoid overwriting settings, when writing configurations
//		for different aspects of the IO driver.
//
// Programmer: Joe Rogers
// Date: 11/10/2004
//
//******************************************************************************
void SystemInit( void )
{
	unsigned long mask;
	// reset the wait state on the control register
	unsigned long regVal = inl(0x80080004);
	regVal &= 0x0000FFFF;
	regVal |= (0x1f << 5);
	outl(regVal, 0x80080004);
#if 1
 	//setup the frequency io pin for the TPO's
	mask = inl(GPIO_PHDDR);	
	mask &= ~TPO_FREQ_SELECT_BIT;	//deselect the appropriate bit
	outl(mask, GPIO_PHDDR);
#endif

////////////////////////////////////////////////////////////////////////////////////////
//map physical memory for io use
	unsigned char *base;
	int i;

	printk("mapping memory\n");

	ptrDOW24V = ptrDIOR1 = ioremap(0x10000006, 1);
	ptrDIOW2/* = ptrDIOR2 */= ioremap(0x10000001, 1);
	/*ptrDIOW3 = */ptrDIOR3 = ioremap(0x10000002, 1);
	ptrDIOW4 = /*ptrDIOR4 =*/ ioremap(0x10000003, 1);
	/*ptrDIOW5 =*/ ptrDIOR5 = ioremap(0x10000004, 1);
	ptrDIOW6 /*= ptrDIOR6 */= ioremap(0x10000005, 1);
//	ptrDOR24V = ioremap(0x10000006, 1);
	/*ptrDIOW1 =*/ptrDIR24V = ioremap(0x10000007, 1);
	ptrTPO1 = ioremap(0x10000008, 1);
	ptrTPO2 = ioremap(0x10000009, 1);
	ptrTPO3 = ioremap(0x1000000A, 1);
	ptrTPO4 = ioremap(0x1000000B, 1);
	ptrSPICS = ioremap(0x1000000C, 1);
	printk("finished mapping\n");

	//Clear all chip selects
	SPIWriteCS(SPICS_CLEAR);
#if 1
	//setup the encoder pins
//	mask = ENCODER0_Z | ENCODER1_Z | ENCODER2_Z | ENCODER3_Z;
	mask = ENCODER0_B | ENCODER1_B;
   outl(0x00, GPIO_PADDR);     	/* Set All Bits to Input */
   outl(mask, GPIO_AINTTYPE1); 	/* Set Level Type Interrupt */
   outl(mask, GPIO_AINTTYPE2); 	/* Set the Level on Bit 2 to High */
   outl(0x00, GPIO_ADB);				/* Disable Debounce */
   outl(mask, GPIO_AEOI);      	/* Clear the interrupt */
   outl(mask, GPIO_AINTEN);    	/* Enable Interrupt(s) on PortA */

	mask = ENCODER2_B | ENCODER3_B;
	//TEMPORARY OUTPUT PIN USAGE WILL SET SOME TO OUTPUT
	//outl(0x40, GPIO_PBDDR);
 //  outl(0xC0, GPIO_PBDDR); //allows output on GPIO_PBDR bits 6,7 0x40 and 0x80 write
   outl(0x00, GPIO_PBDDR);     	/* Set All Bits to Input */
   outl(mask, GPIO_BINTTYPE1); 	/* Set Level Type Interrupt */
   outl(mask, GPIO_BINTTYPE2); 	/* Set the Level on Bit 2 to High */
   outl(0x00, GPIO_BDB);       	/* Disable Debounce */
   outl(mask, GPIO_BEOI);      	/* Clear the interrupt */
   outl(mask, GPIO_BINTEN);    	/* Enable Interrupt(s) on PortB */
	
	//setup SPICS select port pin
	mask = 0x0002; //pin 1, port F
	outl(mask, GPIO_PFDDR);
#endif
}

