/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

#include "schedule_local.h"
#include "hc1xcomm_local.h"
#include "tpo.h"
#include "hc2xio_exports.h"

#ifndef __KERNEL__
   #define __KERNEL
#endif
                                                                                
#ifndef MODULE
   #define MODULE
#endif
                                                                                
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/arch/hardware.h>

#include "hc2xutils.h"
#include "dio.h"
#include "hc2xwd.h"
#include "hc2xmem.h"
#include "hc2xio.h"
#include "D2Adrv.h"

void initialize_seq_timer( void );
void initialize_A2Dseq_timer( void );
void Scheduler_A2Dsequencer(Scheduler* pScheduler);
                                                                                
Scheduler scheduler;

static unsigned short bInTDMStore = 0;
static unsigned short bFirstTimer = 1;
static unsigned short bFirstA2DTimer = 1;
static struct timer_list sched_timer;
static struct timer_list pre_timer;
static struct timer_list A2D_timer;

static UCHAR tempbuff[MAX_MESSAGE_LENGTH+1];

extern int g_useTimer;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  timer_handler

 callback function from initialize_seq_timer currently set to 20 ms execution
                                                                                
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void timer_handler(unsigned long arg)
{
	if(bFirstTimer)
	{
		bFirstTimer = 0;
		bSkipIOTickle = 0;
		bSkipTDMTickle = 0;
		hc2xwd_EnableDog(IO_DOG, 1);
	}

	if(!bSkipIOTickle)
	{
		hc2xwd_TickleDog(IO_DOG);
	}
	Scheduler_sequencer(&scheduler);
		initialize_seq_timer();
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  A2Dtimer_handler

 callback function from initialize_A2Dseq_timer currently set to 70 ms execution

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void A2Dtimer_handler(unsigned long arg)
{

	if(bInTDMStore==0)
	{
		Scheduler * pSchedulerNull;
		pSchedulerNull = NULL;
		static short cnt = 0;
		if(bFirstA2DTimer)
		{
			bFirstA2DTimer = 0;
			hc2xwd_EnableDog(TDM_DOG, 1);
		}
	
	
	
	
	
		if(!bSkipTDMTickle)
		{
				hc2xwd_TickleDog(TDM_DOG);
		}
		bAccessingSPI = 1;
		if(!bAccessingEEPROM)
		{
			cnt++;
			if(cnt >= 30)
			{
	
				cnt = 0;
			}
			Scheduler_A2Dsequencer(&scheduler);
			D2A_update();
		}
		bAccessingSPI = 0;
		initialize_A2Dseq_timer();
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  sch_suspendTimer

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void sch_suspendTimer(unsigned short sEnable)
{
	if(sEnable)
	{
		printk("enabling A2D\n");
		bInTDMStore = 0;
		bFirstA2DTimer= TRUE;
	}
	else
	{
		bInTDMStore = 1;
		hc2xwd_EnableDog(TDM_DOG, 0);
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  initialize_seq_timer


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void initialize_seq_timer( void )
{
   static unsigned char mask = 0;
                                                                                
   init_timer(&sched_timer);
   sched_timer.function = timer_handler;
   sched_timer.data = 0;
   sched_timer.expires = jiffies + 20; // 20  mSecs. (min is 1 mSecs.)	
   add_timer(&sched_timer);
	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
   if(mask)
   {
      mask = 0x0;
   }
   else
   {
      mask = 0xff;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  initialize_A2Dseq_timer


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void initialize_A2Dseq_timer( void )
{
	unsigned long mask;
                                                                                
   init_timer(&A2D_timer);
   A2D_timer.function = A2Dtimer_handler;
   A2D_timer.data = 0;
   A2D_timer.expires = jiffies + 70; // 70 mSecs.
   add_timer(&A2D_timer);
	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
   if(mask & 0x2)
   {
      mask &= ~(0x2);
   }
   else
   {
      mask |= 0x2;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_init


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_init(Scheduler* pScheduler)
{
	bModbusMaster=FALSE;
	pScheduler->sequenceNo   =  0;
	pScheduler->timerCount   =  0;	
	pScheduler->scanPeriod   =  5;	// in ms
	pScheduler->goodCOMM     =  0;
	pScheduler->consecutiveNoReadScans = 0;
	pScheduler->elapsedTempZoneTime = 0;
	pScheduler->inProcess	   =  FALSE;   
	pScheduler->commError	   =  0;
	pScheduler->lossOfComm   =  0;
	pScheduler->upDateTPOs   =  FALSE;
	pScheduler->m_bTimerFired = FALSE;
	pScheduler->lSchedulerEx = 0;
	pScheduler->HighPartTime = 0;
	pScheduler->LowPartTime = 0;
	pScheduler->elapsedMillisecs = 0;
	pScheduler->AnalogInTicks = 0;

	initialize_seq_timer();
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_resetCommError


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_resetCommError(Scheduler* pScheduler)
{
   pScheduler->commError = 0;
}


//******************************************************************************
// Scheduler::sequencer
//
// Abstract:
//	The sequencer is triggered on each 1ms interrupt and a counter is incremented
// 	to maintain a sequence position. When the counter reaches the scanPeriod time
// 	it is reset to start processing the loop again.
// 	Interrupts need to be turned off when setting the inProcess flag. Should not
//	need to worry about when setting to FALSE because no other process should
// 	be able to run process functions if inProcess is TRUE.
//  In the event of an overrun, it is assumed that if the HC1X IO Controller does
//	not respond by the following sequence step it will not.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Scheduler_sequencer(Scheduler* pScheduler)
{
	pScheduler->lSchedulerEx++;
	pScheduler->elapsedMillisecs += 20; //This can be changed to as fast as 1mSec.
	
	IODIN_process_nonModbus(&(digitalInDb));

	if(pScheduler->elapsedMillisecs == 40 ) //between 20 and 40 ms
	{
		IODOUT_process_nonModbus(&digitalOutDb);
		DIO_Write_Outputs();
	}		

	if(pScheduler->elapsedMillisecs == 80 )
	{
		//Here is where we check the Analog outs for new values.
		IOANALOGOUT_WRITE_OUT(&analogOutDb);
		TPO_CheckInput();
	}
	
	if(pScheduler->elapsedMillisecs == 100 ) //between 20 and 40 ms
	{
		if(bModbusMaster==TRUE)
		{
			///alright this is incorrect but rather than handling the 3.5 character timeout I am just using the mcr
			IOANALOGIN_process(&(analogInDb));
		}
		IOANALOGIN_process_nonModbus(&(analogInDb));

		if(bModbusMaster==TRUE)
		{
			Hc1xComm_addMessage(&(hc1xComm), READ_ANALOG_IN_MESSAGE, 1, 0, 60);
			Hc1xComm_sendMessage(&(hc1xComm), READ_ANALOG_IN_MESSAGE,&(pScheduler->inProcess));
		}
		pScheduler->elapsedMillisecs = 0;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_A2Dsequencer

67 ms timer to acquire a2d conversions, based on a 15 hz conversion setting	
15 hz = 66 2/3 ms	

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_A2Dsequencer(Scheduler* pScheduler)
{
	Tdm_beginAcquisition();
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_getCommLoss

			returns TRUE if we've detected comm loss.
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Scheduler_getCommLoss(Scheduler* pScheduler)
{
	BOOL bRetVal = FALSE;
	if(pScheduler->goodCOMM == 0 && pScheduler->consecutiveNoReadScans > 40 )
	{
		bRetVal = TRUE;
	}
	return bRetVal;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_reset


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_reset( Scheduler* pScheduler )
{ 
	pScheduler->sequenceNo = 0;	
	pScheduler->inProcess = FALSE; 
	pScheduler->m_bTimerFired = FALSE; 
	pScheduler->LowPartTime = 0; 
	pScheduler->HighPartTime = 0;
	pScheduler->lSchedulerEx = 0;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_getScanPeriodMs


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler)
{
	return pScheduler->scanPeriod; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_setModbus

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Scheduler_setModbus(BOOL bOn)
{
	bModbusMaster = bOn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_getModbus

			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Scheduler_getModbus()
{
	return bModbusMaster;
}
