/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
// digitio.c

#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>
#include "dio.h"
#include "hc2xmem.h"

unsigned char dio_buffer[SIZE] = {0};
int randomTestVariable = 0;
void DIO_Initialize()
{
	int i;
	for(i = 0; i < SIZE; i++)
		dio_buffer[i] = 0x00;

	DIO_Write_Outputs();
}

//
// function: DIO_SET
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Set(unsigned int index, unsigned int value)
{
	int sub_index;
	int bit_shift;

	// make sure index is in range
	if ( (index < 0) || (index > 63) )
	{
		return 0xFFFF;
	}

	sub_index = (int)(index / 8);
	bit_shift = (int)(index % 8);

	//DIO_Read(sub_index | CS0_MEM_BASE);

	// limit value to either 1 or 0
	if ( value >= 1 )
	{
		value = 0x0001 << bit_shift;
		dio_buffer[sub_index] |= value;
	}
	else
	{
		value = ~(0x0001 << bit_shift);
		dio_buffer[sub_index] &= value;
	}

//	DIO_Write(sub_index/*| CS0_MEM_BASE*/);

	return 1;
}

//
// function: DIO_Get
// return: bit value at index either 0 or 1, or 0xFFFF if failure
//
unsigned int DIO_Get(unsigned int index)
{
	int sub_index;
	unsigned char mask = 0x0001;
	unsigned char value;
	int bit_shift;

	// make sure index is in range
	if ( (index < 0) || (index > 63) )
	{
		return 0xFFFF;
	}

	sub_index = (int)(index / 8);
	DIO_Read(sub_index);
	value = dio_buffer[sub_index];

	bit_shift = (int)(index % 8);
	value = value >> bit_shift;
	value &= mask;

	return value;
}

//
// function: DIO_Write
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Write(unsigned buffer_index)
{
unsigned char local_char;
	int index = buffer_index & 0x000000FF;

	if ( index >= SIZE )
		return 0xFFFF;
	local_char = dio_buffer[index];
	switch (buffer_index)
	{
/*	case DIOW1:
	writeb(dio_buffer[index], ptrDIOW1);
	printk("DIOW1 written %d\n", dio_buffer[index]);
	break;*/
	
	case DOW2:
	writeb(local_char, ptrDIOW2);
//	printk("DOW2 %d\n", local_char);
	break;

	case DOW4:
	writeb(local_char, ptrDIOW4);
	//printk("DOW4 %d\n", local_char);
	break;

	case DOW6:
	writeb(local_char, ptrDIOW6);
//	printk("DOW6 %d\n", local_char);
	break;

	case DOW24V:
	writeb(local_char, ptrDOW24V);
//	printk("DOW24V %d\n", local_char);
	break;

	default:
	printk("dio write failed\n");
	return 0;
	break;
	}
	//outl( dio_buffer[index], buffer_index );
//	printk("\n");

	return 1;
}

//
// function: DIO_READ
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Read(unsigned buffer_index)
{
	int junkBuffer = 0;
	int index = buffer_index & 0x000000FF;
	if ( index >= SIZE )
		return 0xFFFF;
	//dio_buffer[index] = (unsigned char)inl(buffer_index);
	
//inputs are active low, need to flip read for boolean logic
	switch (index)
	{
	case DIR1:
		dio_buffer[index] = readb( ptrDIOR1);
//		printk("DIOR1: %d\n", dio_buffer[index]);	
	break;


	case DIR3:
		dio_buffer[index] = readb(ptrDIOR3);
//	printk("DIOR3: %d\n", dio_buffer[index]);
	break;



	case DIR5:
		dio_buffer[index] = readb(ptrDIOR5);
//	printk("DIOR5: %d\n", dio_buffer[index]);
	break;

	case DIR24V:
		dio_buffer[index] = ~(readb( ptrDIR24V));
//	printk("DIR24V: %d\n", dio_buffer[index]);
	break;

	default:
//	printk("dio read failed\n");

		return 0;
	break;
	}


	return 1;
}

void DIO_ReadAll()
{
/*	int i;
	for ( i = 0; i < SIZE; i++ )
		DIO_Read(i | CS0_MEM_BASE);*/
}

void DIO_Write_Outputs()
{
	if(randomTestVariable >=21)
	{
		//printk("in DIO_Write_Outputs\n");
		randomTestVariable = 0;
	}
	randomTestVariable++;
	DIO_Write(DOW2);
	DIO_Write(DOW4);
	DIO_Write(DOW6);
	DIO_Write(DOW24V);
}
