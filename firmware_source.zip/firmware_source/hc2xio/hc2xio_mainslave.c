#ifndef __KERNEL__
	#define __KERNEL
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <asm/uaccess.h>

#include "encoder.h"
#include "hc2xio.h"
#include "hc2xio_exports.h"
#include "hc1xcomm_local.h"
#include "schedule_local.h"
#include "hc2xspi.h"
#include "tpo.h"
#include "dio.h"
#include "hc2xtdm.h"
#include "hc2xwd.h"
#include "system.h"
#include "eeprom.h"
#include "hc2xmem.h"

int driver_major  = 0;
struct fasync_struct *async_queue;

int g_useTimer = 0;
int g_encoderCount = 0;
unsigned char out = 0xff;

int block2 = 0;
//int mask = 0;

unsigned long last_jiffies;
unsigned short bAccessingSPI;
unsigned short bAccessingEEPROM;
unsigned short bWritingTDMEEMemory;
int driver_fasync(int fd, struct file *filp, int mode)
{
	printk("hc2xio: driver_fasync\n");
	return fasync_helper(fd, filp, mode, &async_queue);
}

int driver_release(struct inode *inode, struct file *filp)
{
//	MOD_DEC_USE_COUNT;
//	g_useTimer--;
/*WDT 06_30_06
Do not disable watchdogs in driver release!  The drivers should never unload during normal operations, unloading watchdogs can potentially cause runaway conditions on heat controllers*/
	return 0;
}

int driver_open(struct inode* i, struct file* f)
{
	printk("hc2xio: driver_open\n");
	MOD_INC_USE_COUNT;

	return 0;
}

ssize_t driver_write(struct file* f, const char* buf, size_t len, loff_t* thing)
{	
	return len;
}

int driver_ioctl(struct inode* inode, struct file* f, 
	unsigned int cmd, unsigned long arg)
{
	int status;
//	printk("hc2xio: driver_ioctl  cmd = %d\n", cmd);
	int i;
	int nRetVal;
//	int iTempor;
	switch ( cmd )
	{
	case HC2XCTLAPP_INIT_TDM:
		Tdm_processHc2xEEProm();
/*	hc2xwd_TriggerTimer(1);
	bAccessingEEPROM = 1;
		for(i = 0; i <90; i++)
		printk("reading byte %d", i);
		iTempor = readb(i+0x60FC0000);
		printk(" %s\n", iTempor);
		bAccessingEEPROM = 0;
	hc2xwd_TriggerTimer(0);*/
	break;
	case HC2XCTLAPP_SetIPAddress:
		bAccessingEEPROM = 1;
		for(i = 0; i < 10000 && bAccessingSPI; i++);
		if ( bAccessingSPI )
		{
			printk("hc2xio: driver_ioctl() SPI busy\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}
		status = access_ok(VERIFY_READ, (void*) arg, 4);
		if ( status == 0 )
		{
			printk("hc2xio: driver_ioctl() access_ok failed\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}

		__get_user( hc2xip_addr.a, (char*) arg );
		__get_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
		__get_user( hc2xip_addr.c, ((char*) arg) + 2 );
		__get_user( hc2xip_addr.d, ((char*) arg) + 3 );
		
#if 1
		printk("hc2xio: Setting IP: %d.%d.%d.%d\n", hc2xip_addr.a, hc2xip_addr.b,
																	hc2xip_addr.c, hc2xip_addr.d);
		StoreConfig();
		bAccessingEEPROM = 0;
#endif
		break;
	
	case HC2XCTLAPP_GetIPAddress:
		bAccessingEEPROM = 1;
		for(i = 0; i < 10000 && bAccessingSPI; i++);
		if ( bAccessingSPI )
		{
			printk("hc2xio: driver_ioctl() SPI busy\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}
		status = access_ok(VERIFY_WRITE, (void*) arg, 4);

#if 1
		if(QueryEEPromX100())
		{
			__put_user( hc2xip_addr.a, (char*) arg );
			__put_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
			__put_user( hc2xip_addr.c, ((char*) arg) + 2 );
			__put_user( hc2xip_addr.d, ((char*) arg) + 3 );
		}
//			printk("hc2xio: Returning IP: %d.%d.%d.%d\n", hc2xip_addr.a, hc2xip_addr.b,
//																		hc2xip_addr.c, hc2xip_addr.d);
		

/*		if(GetConfig())
		{
			__put_user( hc2xip_addr.a, (char*) arg );
			__put_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
			__put_user( hc2xip_addr.c, ((char*) arg) + 2 );
			__put_user( hc2xip_addr.d, ((char*) arg) + 3 );
			printk("hc2xio: Returning IP: %d.%d.%d.%d\n", hc2xip_addr.a, hc2xip_addr.b,
																		hc2xip_addr.c, hc2xip_addr.d);
		}*/
		bAccessingEEPROM = 0;
#endif
		break;
	case HC2XCTLAPP_SetMACAddress:
		bAccessingEEPROM = 1;
		for(i = 0; i < 10000 && bAccessingSPI; i++);
		if ( bAccessingSPI )
		{
			printk("hc2xio: driver_ioctl() SPI busy\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}
		status = access_ok(VERIFY_READ, (void*) arg, 4);
		if ( status == 0 )
		{
			printk("hc2xio: driver_ioctl() access_ok failed\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}

		__get_user( hc2xip_addr.mac[0], (char*) arg );
		__get_user( hc2xip_addr.mac[1], ((char*) arg) + 1 ); 
		__get_user( hc2xip_addr.mac[2], ((char*) arg) + 2 );
		__get_user( hc2xip_addr.mac[3], ((char*) arg) + 3 );
		__get_user( hc2xip_addr.mac[4], ((char*) arg) + 4 );
		__get_user( hc2xip_addr.mac[5], ((char*) arg) + 5 );
		
#if 1
		printk("hc2xio: Setting MAC: %d.%d.%d.%d.%d.%d\n", hc2xip_addr.mac[0], 
					hc2xip_addr.mac[1], hc2xip_addr.mac[2], hc2xip_addr.mac[3],
					hc2xip_addr.mac[4], hc2xip_addr.mac[5]);
		StoreConfig();
		bAccessingEEPROM = 0;
#endif
		break;
	case HC2XCTLAPP_GetMACAddress:
		bAccessingEEPROM = 1;
		for(i = 0; i < 10000 && bAccessingSPI; i++);
		if ( bAccessingSPI )
		{
			printk("hc2xio: driver_ioctl() SPI busy\n");
			bAccessingEEPROM = 0;
			return -EFAULT; 
		}
		status = access_ok(VERIFY_WRITE, (void*) arg, 4);

		if(QueryEEPromX100())
		{
			__put_user( hc2xip_addr.a, (char*) arg );
			__put_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
			__put_user( hc2xip_addr.c, ((char*) arg) + 2 );
			__put_user( hc2xip_addr.d, ((char*) arg) + 3 );
		}
		
		bAccessingEEPROM = 0;
	default:
		return -EINVAL;
	}

	printk(KERN_WARNING "hc2xio: driver_ioctl return 0\n");
	return 0;
}

struct file_operations driver_fops =
{
	open:		driver_open,
	fasync:     driver_fasync,
	release:    driver_release,
	write:		driver_write,
	ioctl:	driver_ioctl,
};

int init_module()
{
	int status = 0;
	unsigned int i;
	unsigned int readData;

//	printk("hc2xio: entering init_module %d, %ld\n", HZ, jiffies);
	driver_fops.owner = THIS_MODULE;

//	printk("hc2xio: register_chrdev...\n");
	/*
	* Register your major, and accept a dynamic number. This is the
	* first thing to do, in order to avoid releasing other module's
	* fops in scull_cleanup_module()
	*/
	status = register_chrdev(driver_major, "hc2xio", &driver_fops);
	if (status < 0)
	{
		printk(KERN_WARNING "hc2xio: can't get major %d\n", driver_major);
		return status;
	}
	if (driver_major == 0)
		driver_major = status; /* dynamic */
//	printk("hc2xio: register_chrdev... succeeded\n");

	printk("hc2xio: init_module() loaded\n");

	if(!g_useTimer)
	{

///////////////////////////////////////////////////////////////////////////////////////////////
//system must initialized before other objects so pointers to physical memory are valid
		bAccessingSPI = 0;
		bAccessingEEPROM = 0;
		bWritingTDMEEMemory = 0;
		SystemInit();

		InitEEPROMImage();
		initialize_tpos();
		initialize_encoder();
		DIO_Initialize();
		D2A_init();
		Scheduler_init(&scheduler);
		Tdm_init(0);
#if 0
		hc2xwd_EnableDog(IO_DOG, TRUE);
		hc2xwd_EnableDog(TDM_DOG, TRUE);
#endif
		initialize_uart();
		Hc1xComm_init(&hc1xComm, "Hc1xComm");
#if 0
		Hc1xComm_init(&hc1xComm, "Hc1xComm");
		hc2xwd_EnableDog(IO_DOG, TRUE);
		hc2xwd_EnableDog(TDM_DOG, TRUE);
#endif
	}
	g_useTimer++; 

//	Scheduler_init(&scheduler);
	return 0;
}

void cleanup_module()
{
	iounmap(ptrDIOW1);
	iounmap(ptrDIOW2);
	iounmap(ptrDIOW3);
	iounmap(ptrDIOW4);
	iounmap(ptrDIOW5);
	iounmap(ptrDIOW6);
	iounmap(ptrDOW24V);
	iounmap(ptrDIR24V);
	iounmap(ptrTPO1);
	iounmap(ptrTPO2);
	iounmap(ptrTPO3);
	iounmap(ptrTPO4);
	iounmap(ptrSPICS);

	unregister_chrdev(driver_major, "hc2xio");
}
