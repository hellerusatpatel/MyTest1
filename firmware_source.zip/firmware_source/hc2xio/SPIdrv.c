/**************************************************************************
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
    Heller Industries         Company Confidential    
                    

	File:	        SPIdrv.c

	Description:	
					This file contains EP9301 routines to initialize, read and write 
					the SPI interfaces as used by the A2D, D2A and EEPROMS
					device driver. 
					
	Modifications :	Version	Author	Date		Description
	`				A		jwf		10/24/04	Initial pre-release
	
			         
    This is a trade secret of imagic, inc. and Heller Industries   
    and is protected by copyright. All unauthorized uses prohibited.
********************************************************************/
 
/*===========================================================================
 *
 * INCLUDE FILES:
 *
/*==========================================================================*/ 
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>

#include "hc2xmem.h"
#include "SPIdef.h"
#include "confcal.h"
#include "A2DCdefs.h"
#include "hc2xutils.h"


/*========================================================================
 *
 * EXTERNAL REFERENCES:
 *
 * Global Data and Function declarations (not defined in include files).
/*=======================================================================*/


/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  InitSPI

    This function initializes the SPI control registers, and 
	baud rate register 

 GLOBALS:

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void InitSPI(char NoBits, unsigned short clkMask)
{
	unsigned short status, result;
	unsigned long statusL;
	/* Synchronous serial port control register one SSPCR1
	*				function. 		description		
	* Bit.15 - 8		RSVD		reserved / not used    				
	* Bit.7				RSVD		reserved / not used
	* Bit.6				SOD			slave output disable		
	* Bit.5				MS			master / slave select m = 1	
	* Bit.4				SSE			synchronous serial port enable		
	* Bit.3				LBM			loop back mode = 0/normal		
	* Bit.2				ROIRE		return overrun interrupt enable = 0		
	* Bit.1				TIE			transmit interrupt fifo enable
	* Bit.0				RIE			recieve fifo interrupt enable
	*				
	*/  

	statusL=inl(SYSCON_CHIPID);
//	printk("clock mask %h\n", clkMask);
//	printk("chip id %x\n", statusL);
	statusL &=0xF0000000;
	switch(statusL)
	{
		case 0x30000000:
		case 0x40000000:
		case 0x50000000:
		case 0x60000000:
		break;
		default:
		clkMask=clkMask+0x100; //setting clock divisor to 2 for SPI speed revision
		break;
	}
//	printk("chip id %x\n", statusL);

//	printk("clock mask %h\n", clkMask);

	outl(0x0010, SSPCR1);

	//Set Clock divider to 8
	outl(0x08, SSPCPSR);

	/* Synchronous serial port control register zero SSPCR0
	*				function. 		description		
	* Bit.15 - 8		SCR			Serial comm rate    				
	* Bit.7				SPH			phase 		
	* Bit.6				SPO			polarity		
	* Bit.5 - 4			FRF			frame format motorola = 00	
	* Bit.3				DSS.3		number of bits		
	* Bit.2				DSS.2		number of bits		
	* Bit.1				DSS.1		number of bits		
	* Bit.0				DSS.0		number of bits
	*				
	*/
	outl(clkMask | (NoBits - 1), SSPCR0);  

	//Now disable SSP per documentation
	outl(0x0000, SSPCR1);

	//Renable SSP
	outl(0x0010, SSPCR1);

	status = inl(SSPSR);
	status &=0x0004;
	while(status)
	{
		result = inl(SSPDR);
		status = inl(SSPSR);
		status &= 0x0004;
	}
}
	

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  WriteSPI

    		This function writes a value to the SPI transmit buffer
    		and waits for the write to complete

 GLOBALS:

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void WriteSPI(unsigned short txbuffer)
{   

	unsigned short i, temp, status; 
    char rxbuffer;

	outl(txbuffer, SSPDR);

	/* Synchronous serial port status register SSPSR
	*				function. 		description		
	* Bit.15 - 5		RSVD		reserved / not used  				
	* Bit.4				BSY			0 = idle, 1= busy tx'ing or rx'ing		
	* Bit.3				RFF			rx fifo full = 1 not full = 0		
	* Bit.2				RNE			rx fifo not empty		
	* Bit.1				TNF			tx fifo not full		
	* Bit.0				TFE			tx fifo empty
	*				
	*/ 
#if 0
	status = inl(SSPSR);
	while((status & 0x0010) || !(status & 0x0001))
	{
		status = inl(SSPSR);
	}
#endif
} 

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  ReadSPI

    		This function reads from the SPI read buffer

 GLOBALS:

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned short ReadSPI(void)
{   

	unsigned short status,result;

	/* Synchronous serial port status register SSPSR
	*				function. 		description		
	* Bit.15 - 5		RSVD		reserved / not used  				
	* Bit.4				BSY			0 = idle, 1= busy tx'ing or rx'ing		
	* Bit.3				RFF			rx fifo full = 1 not full = 0		
	* Bit.2				RNE			rx fifo not empty		
	* Bit.1				TNF			tx fifo not full		
	* Bit.0				TFE			tx fifo empty
	*				
	*/ 
	status = inl(SSPSR);
//	12_09_05 per JF we should not continue until the memory is ready WDT
	while((status & 0x0010) )
	{
		status = inl(SSPSR);
	}
	status &=0x0004;
	if(status)
	{
		result = inl(SSPDR);
	}
	else
		result = -1;

	return(result);

}

void SPIWaitTxBusy( void )
{
	unsigned short status; 
	
	
	/* Synchronous serial port status register SSPSR
	*				function. 		description		
	* Bit.15 - 5		RSVD		reserved / not used  				
	* Bit.4				BSY			0 = idle, 1= busy tx'ing or rx'ing		
	* Bit.3				RFF			rx fifo full = 1 not full = 0		
	* Bit.2				RNE			rx fifo not empty		
	* Bit.1				TNF			tx fifo not full		
	* Bit.0				TFE			tx fifo empty
	*				
	*/ 
	status = inl(SSPSR);
	while((status & 0x0010) || !(status & 0x0001))
	{
		status = inl(SSPSR);
	}
} 

void SPIWaitTxNotFull( void )
{
	unsigned short status; 
	
	
	/* Synchronous serial port status register SSPSR
	*				function. 		description		
	* Bit.15 - 5		RSVD		reserved / not used  				
	* Bit.4				BSY			0 = idle, 1= busy tx'ing or rx'ing		
	* Bit.3				RFF			rx fifo full = 1 not full = 0		
	* Bit.2				RNE			rx fifo not empty		
	* Bit.1				TNF			tx fifo not full		
	* Bit.0				TFE			tx fifo empty
	*				
	*/ 
	status = inl(SSPSR);
	while(!(status & 0x0002))
	{
		status = inl(SSPSR);
	}
} 
void EmptyRXFIFO( void )
{
	unsigned int status, result;

	status = inl(SSPSR);
	status &=0x0004;
	while(status)
	{
		result = inl(SSPDR);
		status = inl(SSPSR);
		status &= 0x0004;
	}
}

void SPIWriteCS(unsigned int cs_value)
{
	unsigned int mask;
	mask = cs_value | nDiagLine;
	writeb(mask, ptrSPICS);
//	printk("hc2xio: SPIWriteSC( 0x%x )\n", mask);
}
