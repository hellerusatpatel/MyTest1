/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//digitio.cpp

#include "hc1xcomm_local.h"
#include "io_digitio.h"
#include "encoder.h"
#include "confcal.h"
#include "globals.h"
#include "hc2xtdm.h"
#include "D2Adrv.h"
#include "dio.h"
#include "schedule_local.h"
#include "tpo.h"
#include "hc2xio_exports.h"

int iTest4Path;
int iTest2Path;

int randomTestVariable2 = 0;

//******************************************************************************
// class IODIN::IODIN
//
// Abstract:
// The actual values of the Digital Inputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 02/24/1998
//******************************************************************************
void IODIN_init(IODIN* pDin, const char *szDbName )
{
	PARAM_CHECK( pDin, "DIN_init");
	if ( szDbName )
	{
		strcpy(pDin->name, szDbName);
	}
	pDin->dummy = FALSE;
	pDin->iTest = 1;
	iTest4Path = 0;
	iTest2Path = 0;
	memset(pDin->dinputs,0,sizeof(pDin->dinputs));
};

//******************************************************************************
// IODIN::operator[]
//
// Abstract:
//	Return the reference to the IODIN object for access to READING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
BOOL* IODIN_GetAt(IODIN* pDin, UINT index)
{
	PARAM_CHECK_RETURN( pDin, "DIN_GetAt", NULL);

	BOOL* pReturn = &(pDin->dummy);

	if ( index < MaxDin )
	{
		pReturn = &(pDin->dinputs[index]);
	}
	else
	{
		pDin->dummy = FALSE;
		pReturn =  &(pDin->dummy);
	}

	return pReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODIN_BufferGet

	GLOBALS:
	RETURNS:   UCHAR
	SEE ALSO:  
------------------------------------------------------------------------*/
UCHAR IODIN_BufferGet(IODIN* pDin, UINT index)
{
	UCHAR uReturn = 0;

	if ( index < IOHISTLENGTH )
	{
		uReturn = pDin->inBuffer[index];
	}
	else
	{
		uReturn = pDin->inBuffer[0];
	}

	return uReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODIN_GetBuffPoint

	GLOBALS:
	RETURNS:   UINT
	SEE ALSO:  
------------------------------------------------------------------------*/
UINT IODIN_GetBuffPoint(IODIN* pDin)
{
	pDin->iTest = 0;
	return pDin->iBuffPoint;
}

//******************************************************************************
// IODIN::process
//
// Abstract:
// The function to call all functions that the IODIN object needs in order to
// perform its' expected task. Getting Digital IO.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
// Rev History: Set for 7 bytes of data to be received from HC1X.
//
//******************************************************************************
void IODIN_process(IODIN* pDin)
{
	QueryResponse *pQueryResponseBuffer = NULL;
	PUCHAR pResponseMessage = NULL;
	UINT index = 0;
	unsigned int byteNo = 0, bitNo = 0;
	PARAM_CHECK( pDin, "DIN_process");

 	pQueryResponseBuffer = Hc1xComm_getQueryResponseBuffer(&(hc1xComm), READ_DIGITAL_IN_MESSAGE);
	
	if ( pQueryResponseBuffer )
	{
		if ( pQueryResponseBuffer->dataReady == 1 )
		{
   			pResponseMessage = pQueryResponseBuffer->responseMessage + 3;	// offset to beginning of bytes of data

   			for ( byteNo = 0; byteNo < 8; byteNo++ ) 			// 56 bits of data in 7 bytes
			{
				for ( bitNo = 0; bitNo <= 7; bitNo++ )
				{
					if ( *pResponseMessage & (1 << bitNo))
					{
						pDin->dinputs[index]	= TRUE;
					}
					else
					{
 						pDin->dinputs[index]	= FALSE;
					}
					index++;
				}
				pResponseMessage++;
			}
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODIN_process_nonModbus

	GLOBALS:
	RETURNS:   VOID
	SEE ALSO:  
------------------------------------------------------------------------*/
void IODIN_process_nonModbus(IODIN* pDin)
{
	int i = 0;
	int iBitNo = 0;
	int iByteNo = 0;

	for(i = 0; i <= IDI_RAIL1_HOME_SWITCH; i++)
	{
		if(DIO_Get(i)==1)
		{
			pDin->dinputs[i] = 1;
		}
		else
		{
			pDin->dinputs[i] = 0;
		}

		//shift current value by bit count, add existing value and assign to buffer element
		pDin->inBuffer[((8 * pDin->iBuffPoint) + iByteNo)] = (pDin->dinputs[i]<<iBitNo) + pDin->inBuffer[((8 * pDin->iBuffPoint) + iByteNo)];

		iBitNo++;
		if(iBitNo >7)
		{
			iBitNo = 0;		
			iByteNo++;
		}
	}

	if(pDin->iBuffPoint < 49)
	{
		pDin->iBuffPoint++;
	}
	else
	{
		pDin->iBuffPoint=0;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODIN_getName

	GLOBALS:
	RETURNS:   const char*
	SEE ALSO:  
------------------------------------------------------------------------*/
const char* IODIN_getName(IODIN* pDin)
{
	PARAM_CHECK_RETURN( pDin, "DIN_getName", NULL);
	return pDin->name;
}

//******************************************************************************
// class IODOUT::IODOUT
//
// Abstract:
// The actual values of the Digital Outputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 02/24/1998
//******************************************************************************
void IODOUT_init(IODOUT* pDout, const char *szDbName )
{
	PARAM_CHECK( pDout, "DOUT_int");
	if ( szDbName )
	{
		strcpy(	pDout->name, szDbName);
	}
	pDout->dummy = FALSE;
	pDout->bUpdated = 0;
	memset( pDout->doutputs,0,sizeof(pDout->doutputs));
}

//******************************************************************************
// IODOUT::operator[]
//
// Abstract:
//	Return the reference to the IODOUT object for access to WRITING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
BOOL* IODOUT_GetAt(IODOUT* pDout, UINT index)
{
	BOOL* pReturn = NULL;

	PARAM_CHECK_RETURN( pDout, "DOUT_GetAt", NULL);
	if ( index < MaxDout )
	{
		pReturn = &(pDout->doutputs[index]);
	}
	else
	{
		pDout->dummy = FALSE;
		pReturn = &(pDout->dummy);
	}

	return pReturn;
}

//******************************************************************************
// IODOUT::process
//
// Abstract:
// The function to call all functions that the IODOUT object needs in order to
// perform its' expected task. Writing Digital IO to the Analogic Device.
// Refer to the Analogic Software Specifications Heller HC1-x 91g00574 Rev A2
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void IODOUT_process(IODOUT* pDout)
{
	UINT lcv = 0;
	UINT byteNo = 0;
	PARAM_CHECK( pDout, "DOUT_process");

	memset( pDout->dOutBits, 0, sizeof( pDout->dOutBits ));

	for ( lcv = 0; lcv < MaxDout; lcv++ )
	{
		switch ( lcv )
		{  
			case  ODO_RED_LIGHT_TOWER	  :	
			case  ODO_AMBER_LIGHT_TOWER	  : 
			case  ODO_GREEN_LIGHT_TOWER	  :	
			case  ODO_AUDIBLE_ALARM		  : 
			case  ODO_CONVEYOR_BLOWER	  :	
			case  ODO_HEATER_CONTACT	  :	
			case  ODO_1088_DIGITAL_FAN_FLUX_FILTER:
			case  ODO_SMEMA1_ENTRANCE     :
			case  ODO_SMEMA1_EXIT	      :	
			case  ODO_RAIL1_ENABLE		  :	
			case  ODO_RAIL1_DIRECTION	  :	
			case  ODO_RAIL2_ENABLE		  :	
			case  ODO_RAIL2_DIRECTION	  :	
			case  ODO_AUTOLUBE_SOLENOID_1 :	
			case  ODO_NITROGEN_ON		  :	
			case  ODO_SMEMA2_ENTRANCE	  :
			case  ODO_SMEMA2_EXIT		  :	
			case  ODO_RAIL3_ENABLE		  :	
			case  ODO_RAIL3_DIRECTION	  :	
			case  ODO_RAIL4_ENABLE		  :	
			case  ODO_RAIL4_DIRECTION	  :	
			case  ODO_CBS_UP			  :	
			case  ODO_NITROGEN_HIGH_FLOW  :	
			case  ODO_NITROGEN_NORMAL_FLOW:
			case  ODO_NITROGEN_LOW_FLOW	  :	
            case  ODO_SMEMA3_ENTRANCE     :  
            case  ODO_SMEMA3_EXIT         :   
            case  ODO_AUTOLUBE_SOLENOID_2 :
			case  ODO_NEW_JOB_FIVESEC	  :	
			case  ODO_CBS_UP2			  :	
			case  ODO_SMEMA4_ENTRANCE	  :
			case  ODO_SMEMA4_EXIT		  :
				byteNo = lcv/8;
				pDout->dOutBits[byteNo] |= (pDout->doutputs[lcv]&0x01)<<(lcv%8);
				break;
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODOUT_process_nonModbus

	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void IODOUT_process_nonModbus(IODOUT* pDout)
{
	unsigned int lcv = 0;
	unsigned int byteNo = 0;

	for ( lcv = 0; lcv < MaxDout; lcv++ )
	{
		switch ( lcv )
		{  
			case  ODO_RED_LIGHT_TOWER	  :	
			case  ODO_AMBER_LIGHT_TOWER	  : 
			case  ODO_GREEN_LIGHT_TOWER	  :	
			case  ODO_AUDIBLE_ALARM		  : 
			case  ODO_CONVEYOR_BLOWER	  :	
			case  ODO_HEATER_CONTACT	  :	
			case  ODO_1088_DIGITAL_FAN_FLUX_FILTER:
			case  ODO_SMEMA1_ENTRANCE     :
			case  ODO_SMEMA1_EXIT	      :	
			case  ODO_RAIL1_ENABLE		  :	
			case  ODO_RAIL1_DIRECTION	  :	
			case  ODO_RAIL2_ENABLE		  :	
			case  ODO_RAIL2_DIRECTION	  :	
			case  ODO_AUTOLUBE_SOLENOID_1 :	
			case  ODO_NITROGEN_ON		  :	
			case  ODO_SMEMA2_ENTRANCE	  :
			case  ODO_SMEMA2_EXIT		  :	
			case  ODO_RAIL3_ENABLE		  :	
			case  ODO_RAIL3_DIRECTION	  :	
			case  ODO_RAIL4_ENABLE		  :	
			case  ODO_RAIL4_DIRECTION	  :	
			case  ODO_CBS_UP			  :	
			case  ODO_NITROGEN_HIGH_FLOW  :	
			case  ODO_NITROGEN_NORMAL_FLOW:
			case  ODO_NITROGEN_LOW_FLOW	  :	
            case  ODO_SMEMA3_ENTRANCE     :  
            case  ODO_SMEMA3_EXIT         :   
            case  ODO_AUTOLUBE_SOLENOID_2 :
			case  ODO_NEW_JOB_FIVESEC	  :	
			case  ODO_CBS_UP2			  :	
			case  ODO_SMEMA4_ENTRANCE	  :
			case  ODO_SMEMA4_EXIT		  :
				byteNo = lcv/8;
				if((pDout->doutputs[lcv]))
				{
					dio_buffer[byteNo] |= 0x01<<(lcv%8);
				}
				else
				{
					dio_buffer[byteNo] &= ~(0x01<<(lcv%8));
				}
				break;
		}
	}
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODOUT_getOutputArray

	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void IODOUT_getOutputArray(IODOUT* pDout, UCHAR** ppDigitalOut, UCHAR* pSize)
{
	PARAM_CHECK( pDout, "DOUT_getOutputArray");
	IODOUT_process(pDout);
	*ppDigitalOut = pDout->dOutBits;
	*pSize = sizeof( pDout->dOutBits);
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IODOUT_getName

	GLOBALS:
	RETURNS:   const char*
	SEE ALSO:  
------------------------------------------------------------------------*/
const char* IODOUT_getName(IODOUT* pDout)
{
	PARAM_CHECK_RETURN( pDout, "DOUT_getName", NULL);
	return pDout->name;
}

//******************************************************************************
// class IOANALOGIN::IOANALOGIN
//
// Abstract:
// The actual values of the Analog Inputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 03/02/1998
//******************************************************************************
void IOANALOGIN_init(IOANALOGIN* pANALOGIN,	const char * szDbName )
{
	PARAM_CHECK( pANALOGIN, "ANALOGIN_init");

	if ( szDbName )
	{
		strcpy(pANALOGIN->name, szDbName);
	}

	pANALOGIN->profileOffset = 0;
	pANALOGIN->dummy = 0;

	pANALOGIN->recordOffsets = 0;
	pANALOGIN->iNoSlaveDataCount = 0;
	pANALOGIN->iSlaveDataTimeout = 0;
	pANALOGIN->m_bAlarmed=0;

	memset(pANALOGIN->offsets, 0, sizeof(pANALOGIN->offsets));
	memset(pANALOGIN->inputStyles, 0, sizeof(pANALOGIN->inputStyles));
	memset(pANALOGIN->recordInputStyles, 0, sizeof(pANALOGIN->recordInputStyles));
	memset(pANALOGIN->analogInputs, 0, sizeof(pANALOGIN->analogInputs));
}

//******************************************************************************
// IOANALOGIN::operator[]
//
// Abstract:
//	Return the reference to the IOANALOGIN object for access to READING the IO.
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
WORD* IOANALOGIN_GetAt(IOANALOGIN* pANALOGIN, UINT index)
{
	WORD* pReturn = NULL;

	PARAM_CHECK_RETURN( pANALOGIN, "ANALOGIN_GetAt", NULL);
	if ( index < MaxAnalogIn )
	{
		pReturn = &(pANALOGIN->analogInputs[index]);
	}
	else
	{
		pANALOGIN->dummy = 0;
		pReturn = &(pANALOGIN->dummy);
	}

	return pReturn;
}


//******************************************************************************
// IOANALOGIN::process
//
// Abstract:
// The function to call all functions that the IOANALOGIN object needs in order to
// perform its' expected task. Reading analog IO from the Analogic Device.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void IOANALOGIN_process(IOANALOGIN* pANALOGIN)
{
	QueryResponse *pQueryResponseBuffer = NULL;
	PUCHAR pResponseMessage = NULL;
	UINT index = 0;
	unsigned int wordNo = 0;
	int noOfBytes = 0;
	PARAM_CHECK( pANALOGIN, "ANALOGIN_process");

	pQueryResponseBuffer = Hc1xComm_getQueryResponseBuffer(&(hc1xComm), READ_ANALOG_IN_MESSAGE);
	if ( pQueryResponseBuffer ) 
	{
		if ( pQueryResponseBuffer->dataReady == 1 )
		{
			pANALOGIN->m_bAlarmed=0;
			pANALOGIN->iNoSlaveDataCount=0;
			noOfBytes = pQueryResponseBuffer->responseMessage[2];
   			pResponseMessage = (PUCHAR)(pQueryResponseBuffer->responseMessage + 3);	// offset to beginning of bytes of data
   		
			for ( wordNo = 0; wordNo < (noOfBytes/sizeof(WORD)); wordNo++ ) 	// 64 bytes for 32 words of analog inputs
			{
				if ( wordNo < MaxAnalogIn )
				{
					index = wordNo+MaxAnalogIn;
					pANALOGIN->analogInputs[index] = pResponseMessage[1]  | pResponseMessage[0]<<8;
				}
				pResponseMessage += sizeof(*(pANALOGIN->analogInputs));
			}
		}
		else
		{
			pANALOGIN->iNoSlaveDataCount++;				
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGIN_processMaster

	GLOBALS:
	RETURNS:   VOID
	SEE ALSO:  
------------------------------------------------------------------------*/
void IOANALOGIN_processMaster(IOANALOGIN* pIn, QueryResponse * qrP)
{
	QueryResponse *pQueryResponseBuffer = NULL;
	PUCHAR pResponseMessage = NULL;
	UINT index = 0;
	unsigned int wordNo = 0;
	int noOfBytes = 0;
	PARAM_CHECK( pIn, "ANALOGIN_processMaster");

	if ( qrP->dataReady == 1 )
	{
		noOfBytes = qrP->responseMessage[2];

		pResponseMessage = (PUCHAR)(qrP->responseMessage + 3);	// offset to beginning of bytes of data
   		
		for ( wordNo = 0; wordNo < (noOfBytes/sizeof(WORD)); wordNo++ ) 	// 64 bytes for 32 words of analog inputs
		{
			if ( wordNo < MaxAnalogIn )
			{
				pIn->analogInputs[wordNo+MaxAnalogIn] = pResponseMessage[1]  | pResponseMessage[0]<<8;
			}
			pResponseMessage += sizeof(*(pIn->analogInputs));
		}
	}
}

//******************************************************************************
// ANALOGIN_process_nonModbus
//
// Abstract:
// This function will populate the analog inputs if the controller not gathering 
//data through the modbus routines
//
// Programmer: Wallace Tree
// Date: 10/27/2004
//
//******************************************************************************
void IOANALOGIN_process_nonModbus(IOANALOGIN* pANALOGIN)
{
	int i = 0;
	int j = 0;
	static short n100msecCnts = 0;

	for(i = 0; i < MaxAnalogIn; i++)
	{
		if(pANALOGIN->recordInputStyles[i]==1)
		{
			TDM_setInputType(i, pANALOGIN->inputStyles[i]);
			pANALOGIN->recordInputStyles[i] = 0;
		}
	}

	if(pANALOGIN->recordOffsets)//if this flag is set we will record offsets to flash and update the tdm settings
	{
		disable_rxt_int();
		disable_tx_int();
		for(i = 0; i < 16; i++)
		{
			TDM_setOffsets(0, i, pANALOGIN->offsets[i]);
			TDM_setOffsets(1, i, pANALOGIN->offsets[i+24]);
		}	
		pANALOGIN->recordOffsets = 0;
		TDM_commitOffsetsToEEPROM();
	}
	
	if((n100msecCnts==8||TDM_fresh_memory())&&(pANALOGIN->startOffsetProgramming!=1)) //EEprom read, need to pass to analogs
	{
		for(i = 0; i < 16; i++)
		{
			pANALOGIN->offsets[i] = TDM_getOffsets(i);
			pANALOGIN->offsets[i+24] = TDM_getOffsets(i + 16);
			pANALOGIN->inputStyles[i] = TDM_getInputType(i);
			pANALOGIN->inputStyles[i+24] = TDM_getInputType(i+24);
		}
		for(j = 0; j < 2; j++)
		{
			for(i = 0; i < 128; i++)
			{
				pANALOGIN->EEpromMap[i][j] = TDM_getMem(i,j);
				//printk("read i: %d, j %d: %d\n",i,j,pANALOGIN->EEpromMap[i][j]);
			}
		}
	}
	//analogin 0-15 are tdm 0 channels, 24-39 tdm 1
	//others are not utilized by the control driver

	for ( i = 0; i < 16; i++)
	{
		pANALOGIN->analogInputs[i] = TDM_returnData(0, i);
		pANALOGIN->analogInputs[i+24] = TDM_returnData(1, i);
	}

	n100msecCnts++;

	if(n100msecCnts >= 10)
	{
		n100msecCnts = 0;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGIN_setProfileOffset

	GLOBALS:
	RETURNS:   VOID
	SEE ALSO:  
------------------------------------------------------------------------*/
void IOANALOGIN_setProfileOffset(IOANALOGIN* pIn, WORD newProfileOffset) 
{
	PARAM_CHECK( pIn, "ANALOGIN_setProfileOffset");
	pIn->profileOffset = newProfileOffset;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGIN_ReadProfileOffset

	GLOBALS:
	RETURNS:   VOID
	SEE ALSO:  
------------------------------------------------------------------------*/
WORD IOANALOGIN_ReadProfileOffset(IOANALOGIN* pIn)
{
	PARAM_CHECK_RETURN( pIn, "ANALOGIN_ReadProfileOffset", 0);
	return pIn->profileOffset;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGIN_getName

	GLOBALS:
	RETURNS:   const char*
	SEE ALSO:  
------------------------------------------------------------------------*/
const char* IOANALOGIN_getName(IOANALOGIN* pIn) 
{
	PARAM_CHECK_RETURN( pIn, "ANALOGIN_getName", NULL);
	return pIn->name; 
}

//******************************************************************************
// class IOANALOGOUT::IOANALOGOUT
//
// Abstract:
// The actual values of the Analog Outputs stored in an array. The address of
// this object is what the windows apps the PLC, PID and LOGIC processes shall
// use.
//
// Programmer: Steven Young
// Date: 03/02/1998
//******************************************************************************
void IOANALOGOUT_init(IOANALOGOUT* pOut, const char *szDbName )
{
	PARAM_CHECK( pOut, "ANALOGOUT_init");

	pOut->dummy = 0;
	pOut->bUpdated = 0;

	memset(pOut->analogOutputs, 0, sizeof(pOut->analogOutputs));
	memset(pOut->m_bOwned, 0, sizeof(pOut->m_bOwned));
}

//******************************************************************************
// IOANALOGOUT:operator[]
//
// Abstract:
//	Return the reference to the IOANALOGOUT object for access to WRITING the IO.
//  Will fail when exclusively locked for use(by fluxheater for now)
//
// Programmer: Steven Young
// Date: 02/24/1998
//
//******************************************************************************
WORD* IOANALOGOUT_GetAt(IOANALOGOUT* pOut, UINT index)
{
	WORD* pReturn = NULL;

	PARAM_CHECK_RETURN( pOut, "ANALOGOUT_GetAt", NULL);
	if ( index < MaxAnalogOut && !pOut->m_bOwned[index])
	{
		pReturn = &(pOut->analogOutputs[index]);
	}
	else
	{
		pOut->dummy = 0;
		pReturn = 	&(pOut->dummy);
	}

	return pReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGOUT_WRITE_OUT

	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void IOANALOGOUT_WRITE_OUT(IOANALOGOUT* pOut)
{
	int i = 0;

	for(i = 0; i <= TPO_FREECL2; i++)//this will need to change to reference values beyond 31
	{
		TPO_setChannel(i, (unsigned int)pOut->analogOutputs[i]);
		TPO_AddSafeSegment(i, 0x04);
		switch(i)
		{ //currently AO channel 3 is unsupported; no corresponding TPO
			case 0:
				D2A_SetChannel(0, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 1:
				D2A_SetChannel(1, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 2:
				D2A_SetChannel(2, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 16:
				D2A_SetChannel(4, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 17:
				D2A_SetChannel(5, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 30:
				D2A_SetChannel(6, (unsigned int)pOut->analogOutputs[i]);
				break;
			case 31:
				D2A_SetChannel(7, (unsigned int)pOut->analogOutputs[i]);
				break;
		}
	}
}
//******************************************************************************
// IOANALOGIN::process
//
// Abstract:
// The function to call all functions that the IOANALOGIN object needs in order to
// perform its' expected task. Reading analog IO from the Analogic Device.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void IOANALOGOUT_process(IOANALOGOUT* pOut)
{
	PARAM_CHECK( pOut, "ANALOGOUT_process");
}

//******************************************************************************
// IOANALOGOUT::set
//
// Abstract:
// A function to set the output value when the output is locked by the owner, note
// as implemented nothing stops a non-owner from calling this function, which will cause
// havoc
//
// Programmer: Wallace Tree
// Date: 04/12/2004
//
//******************************************************************************
void IOANALOGOUT_set(IOANALOGOUT* pOut, UINT index, WORD wValue)
{
	PARAM_CHECK( pOut, "ANALOGOUT_set");
	if(index < MaxAnalogOut && pOut->m_bOwned[index])
	{
		pOut->analogOutputs[index] = wValue;
		if(!iTest2Path)
		{
			TPO_AddSafeSegment(index, 0x02);
		}
	}
}

//******************************************************************************
// IOANALOGOUT::get
//
// Abstract:
// Will return the value regardless of ownership
//
// Programmer: Wallace Tree
// Date: 04/12/2004
//
//******************************************************************************
WORD IOANALOGOUT_get(IOANALOGOUT* pOut, UINT index)
{
	PARAM_CHECK_RETURN( pOut, "ANALOGOUT_get", 0);

	WORD wReturn = 0;

	if ( index < MaxAnalogOut)
	{
		wReturn = pOut->analogOutputs[index];
	}
	else
	{
		wReturn = 0;
	}

	return wReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	IOANALOGOUT_getName

	GLOBALS:
	RETURNS:   const char*
	SEE ALSO:  
------------------------------------------------------------------------*/
const char* IOANALOGOUT_getName(IOANALOGOUT* pAout )
{
	PARAM_CHECK_RETURN( pAout, "ANALOGOUT_getName", NULL);
	return pAout->name; 
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	testIOWatchDogs

	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void testIOWatchDogs(UINT iWhichOne)
{
	switch (iWhichOne)
	{
		case 1:
			bSkipIOTickle = 1;
			break;
			
		case 2:
			bSkipTDMTickle = 1;
			break;
	
		case 3:
			bSkipTPOTickle = 1;
			break;

		default:
			break;
	}
}

/////////////////////////////////////////////////////////////////////
//
//void deactivateIO(IODOUT pDigOut, IOANALOGOUT pAnOut)
//
//
//function called from stop driver to turn off outputs
/////////////////////////////////////////////////////////////////////
void deactivateIO(IODOUT* pDigOut, IOANALOGOUT* pAnOut)
{
	int index = 0;

	for(index = 0; index < MAX_DIGITAL_OUTPUTS; index++)
	{
		digitalOutDb.doutputs[index] = 0;
	} 
	for(index = 0;  index < MaxAnalogOut; index++)
	{
		analogOutDb.analogOutputs[index] = 0;
 	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_encoderReader

analogin 48-59 are encoders
there are four sets of encoders.  Encoders are incremented/decremented by interrupt
they are placed into accumulators (for speed).  This routine will read them out
and zero the accumulators

there is a conditional ifdef for a closed loop simulation of encoders for belt 0 only
another matching ifdef in the schedule loop of the hc2xctl must be defined
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void IOANALOGIN_encoderReader(IOANALOGIN* pANALOGIN)
{
	int i = 0;
	static short n100msecCntsER = 0;
	for(i = 0; i < ENCODER_CNT; i++)
	{
		pANALOGIN->analogInputs[PULSE_COUNTER_1_MSW + (3 * i)] = (nEncoderPosn[i] >> 16) & 0xffff;
		pANALOGIN->analogInputs[PULSE_COUNTER_1_LSW + (3 * i)] = nEncoderPosn[i]  & 0xffff;
	}

	n100msecCntsER++;

	if(n100msecCntsER >= 10)
	{
		n100msecCntsER = 0;	
		for(i = 0; i < ENCODER_CNT; i++)
		{
			pANALOGIN->analogInputs[PULSE_COUNTER_1_SPEED + (3 * i)] = speed[i];
			speed[i] = 0;
		}
	}	
}

DWORD IOANALOGIN_GetMem(IOANALOGIN* pIn, UINT index, UINT tdm)
{
#if 0 // fjn v5.5.0.18 implementation
	ANALOGIN* pInL = getANALOGIN();
#else
	IOANALOGIN* pInL = &analogInDb;
#endif
	PARAM_CHECK_RETURN( pInL, "IOANALOGIN_GetMem", 0);

	if(index < 128 && tdm < 2)
	{
		return pInL->EEpromMap[index][tdm];
	}
	else
	{
		return 0;
	}
}
void IOANALOGIN_ProgramTDM(IOANALOGIN* pIn, UINT index)
{
#if 0 // fjn v5.5.0.18 implementation
	ANALOGIN* pInL = getANALOGIN();
#else
	IOANALOGIN* pInL = &analogInDb;
#endif
	PARAM_CHECK( pInL, "IOANALOGIN_SetOffsetAt");
	if(index==0)
	{
		pInL->recordMem0 = 1;
	}
	else
	{
		pInL->recordMem1 = 1;	
	}	
}
