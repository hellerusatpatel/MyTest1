/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __KERNEL__
	#define __KERNEL__
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <asm/semaphore.h>
#include <asm/segment.h>
#include <asm/uaccess.h>

#include "hc2xmstr.h"
#include "hc2xmstr_exports.h"
#include "transferTable.h"

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_SecondaryGetAI

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD HC2XMSTR_SecondaryGetAI( int index )
{
	WORD wReturn = TransferTable_SecondaryGetAI( &g_transferTable, index );
	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_SecondaryGetDigitalIn

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL HC2XMSTR_SecondaryGetDigitalIn( int index )
{
	BOOL bReturn = TransferTable_SecondaryGetDigitalIn( &g_transferTable, index );
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_SecondaryGetTdmOffset

			Returns the value at the given index.

 GLOBALS:
 RETURNS:   WORD
 SEE ALSO:
------------------------------------------------------------------------*/
WORD HC2XMSTR_SecondaryGetTdmOffset( int index )
{
	WORD wReturn = TransferTable_SecondaryGetTdmOffset( &g_transferTable, index );
	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_SecondaryGetFlags

			Returns the status flags.

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD HC2XMSTR_SecondaryGetFlags()
{
	DWORD wReturn = TransferTable_SecondaryGetFlags( &g_transferTable );
	return wReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_PrimarySetTPO

			Sets the value at the given index.
			Returns TRUE if successful.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL HC2XMSTR_PrimarySetTPO( int index, DWORD dwValue )
{
	BOOL bReturn = TransferTable_PrimarySetTPO( &g_transferTable, index, dwValue );
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_PrimarySetDigitalOut

			Sets the value at the given index.
			Returns TRUE if successful.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL HC2XMSTR_PrimarySetDigitalOut( int index, BOOL bValue )
{
	BOOL bReturn = TransferTable_PrimarySetDigitalOut( &g_transferTable, index, bValue );
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_PrimarySetConfiguration

			Sets the configuration to the secondary hc2x.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL HC2XMSTR_PrimarySetConfiguration(  struct CONFIGURATION* pConfiguration )
{
	BOOL bReturn = FALSE;

	if ( pConfiguration )
	{
		g_transferTable.configuration = *pConfiguration;
		bReturn = TRUE;
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HC2XMSTR_PrimarySetConfiguration

			Sets the configuration to the secondary hc2x.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HC2XMSTR_SetSecondaryActiveFlag( BOOL bActive )
{
	if ( g_bBlock == 0 )
	{
		g_bBlock = 1;
		
		g_bSecondaryBoardActive = bActive;

		g_bBlock = 0;
	}
}
