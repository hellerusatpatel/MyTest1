/************************************************************
 *
 *   thermlin.c
 *
 *   Thermocouple linearization code.
 *
 ***********************************************************/
/*
#include "globals.h"
#include "prototyp.h"

const double CJCtable[CJCENTRIES] = {
	1752,
	1876,
	2011,
	2157,
	2316,
	2487,
	2674,
	2877,
	3098,
	3339,
	3601,
	3887,
	4200,
	4542,
	4915,
	5325,
	5773,
	6266,
	6806,
	7401,
	8055,
	8776,
	9571,
	10449,
	11419,
	12492,
	13681,
	14999,
	16463,
	18091,
	19902,
	21920,
	24172,
	26687,
	29501,
	32652,
	36186,
	40155,
	44619,
	49646,
	55315,
	61718,
	68961,
	77165,
	86474,
	97051,
	109090,
	122815,
	138486,
	156412,
	176950,
	200524,
	227629,
	258851,
	294884,
	336545
};
extern	double	vgrnd;
*/


/******************************************************************************
FUNCTION:  calc_cjc_temp ()

COMMENTS:     This routine, given a value of R=cjc counts/fullscale_counts
           calculates the cold junction temperature using the Steinhart-Hart
           equation for thermistors.  It calculates cold junction
           temperature in degrees C, returning an overflow flag.
****************************************************************************/
/*
int calc_cjc_temp(uchar tdm, uchar channel)
{
	register int index;
	double	dtemp;
	
/* calculate the resitance of the thermister (Rt) by the following formula:
 * Rt = (((VRef - Vgnd) * Rd) - ((Vo - Vgnd) * Rd)) / (Vo - Vgnd)
 * where:	Vref = supply voltage to thermister & Rd (+2.50V)
 *			Vgnd = voltage at ground
 * 			Rd = value of voltage divider resister with the thermister
 *			Vo = thermister number from A/D
 **/
 /*/	if (TDM[tdm].chanl[channel].raw_val.NIBBLE.BYTE0.LO_NIBBLE)
		return(CONVERT_ERR);
	vgrnd = volts(tdm, VGND);
	dbl_val = (VRef - vgrnd) * Rd;
	dtemp = volts(tdm, channel);
	dbl_val -= (dtemp - vgrnd) * Rd;
	dbl_val /= dtemp - vgrnd;
	
	/* get the index from the resistance value table */
/*	index = searchtbl(CJCtable, CJCENTRIES, &dbl_val);

	/* now, check for overflow & underflow */
 /*   if (index < 0) return UNDERVAL;
    if (index == OVERVAL) return OVERVAL;

	dbl_val -= CJCtable[index];
	dbl_val /= CJCtable[index + 1] - CJCtable[index];
	dbl_val += (double)index;
	/* dbl_val is now an index into the table, with a fractional as well as
	 * an integer part.	*/
	 
 	/* now calc and store the temperature in degree C units	*/
 /*   TDM[tdm].thrmstr[channel - THERMISTRS].temp =
		CJCTEMPMAX + (dbl_val * (double)CJCDELTAT);
 	/* now calc and store the temperature in 0.1 degree C units	*/
/*	input_reg[(tdm * TDM_A2D_INPUTS) + channel].UINT =
		(uint)(TDM[tdm].thrmstr[channel-THERMISTRS].temp * (double)10);

	return TRUE;
}

/*----------------------------------------------------------------------------
int searchtbl(*dbltble, int #entries, double *value)
Michael Strauch
Search an ascending table of doubles for the last entry that is less
than "value".  If the first entry in the table is greater than "value",
the underflow return is 'UNDERVAL'.  If the last entry in the table is less
than "value", the overflow return is 'OVERVAL'.  Otherwise, the index of the
last entry smaller than "value" is returned.
----------------------------------------------------------------------------*/
/*
int searchtbl( double * tbl, uint entries, double * v)
{
  register int min_entry;
  
  if (tbl[0] > *v) return UNDERVAL;	/* check for underflow */
/*  if (tbl[entries - 1] <= *v) return OVERVAL; /* check for overflow */
  /* after this, a valid return value is possible */

/*  min_entry = 0;

  while (entries - min_entry > 1 )
  {
    if (tbl[(min_entry + entries) >> 1] > *v)
    	entries =  (min_entry + entries) >> 1;
    else
    	min_entry = (min_entry + entries) >> 1;
  }
  return min_entry;
}

double	volts(uchar tdm, uchar channel)
{
	dbl = (double)(TDM[tdm].Channel[channel].raw / SCALE);
	/* multiply by the voltage input range	*/
/*	dbl *= (double)range[gain_val[channel][TDM[tdm].channels[channel].calData.nGain]];
	dbl /= (double)FULLSCALE;
	return (dbl);
}*/

