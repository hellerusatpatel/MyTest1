/**************************************************************************
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
    Heller Industries         Company Confidential    
                    

	File:	        EEProm.c

	Description:	
					This file contains EP9301 routines to initialize, read and write 
					the onboard and TDM EEPROM's
					
	Modifications :	Version	Author	Date		Description
	`				A		jwf		10/24/04	Initial pre-release
	
			         
    This is a trade secret of imagic, inc. and Heller Industries   
    and is protected by copyright. All unauthorized uses prohibited.
********************************************************************/
 
/*===========================================================================
 *
 * INCLUDE FILES:
 *
/*==========================================================================*/  
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>

#include "system.h"
#include "hc2xmem.h"
#include "hc2xio_exports.h"
#include "eeprom.h"
#include "SPIdef.h"

/*========================================================================
 *
 * EXTERNAL REFERENCES:
 *
 * Global Data and Function declarations (not defined in include files).
/*=======================================================================*/
struct HC2X_IP hc2xip_addr;

unsigned int EEPROMImage[CONFIG_SIZE];


unsigned int aCRChi[] = 
{
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, /* 000 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, /* 010 */
           0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, /* 020 */
           0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, /* 030 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, /* 040 */
           0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, /* 050 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, /* 060 */
           0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, /* 070 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, /* 080 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, /* 090 */
           0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, /* 100 */
           0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, /* 110 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, /* 120 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, /* 130 */
           0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, /* 140 */
           0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, /* 150 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, /* 160 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, /* 170 */
           0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, /* 180 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, /* 190 */
           0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, /* 200 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, /* 210 */
           0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, /* 220 */
           0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, /* 230 */
           0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, /* 240 */
           0x80, 0x41, 0x00, 0xC1, 0x81, 0x40                          /* 250 */
};

unsigned int aCRClo[] =
{
           0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, /* 000 */
           0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD, /* 010 */
           0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, /* 020 */
           0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, /* 030 */
           0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4, /* 040 */
           0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, /* 050 */
           0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, /* 060 */
           0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, /* 070 */
           0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, /* 080 */
           0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, /* 090 */
           0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, /* 100 */
           0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, /* 110 */
           0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, /* 120 */
           0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, /* 130 */
           0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, /* 140 */
           0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, /* 150 */
           0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, /* 160 */
           0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5, /* 170 */
           0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, /* 180 */
           0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, /* 190 */
           0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C, /* 200 */
           0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, /* 210 */
           0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, /* 220 */
           0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C, /* 230 */
           0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, /* 240 */
           0x43, 0x83, 0x41, 0x81, 0x80, 0x40                          /* 250 */    
};


void SelectEESPI( void )
{
	SPIWriteCS(SPICS_CLEAR);
	outl(EE_SELECT_CS, GPIO_PFDR);
}

void DeSelectEESPI( void )
{
	outl(EE_DESELECT_CS, GPIO_PFDR);
	SPIWriteCS(SPICS_CLEAR);
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  WriteEE

    This function writes a byte value to the EEPROM

 GLOBALS:

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void WriteEnableEE( void )
{	

	unsigned int Opcode,i;   
	unsigned int WriteData; 
	unsigned int ReadData;
	/*
	char *CS_Ptr;
	GPIO write to select proper cs bank
	CS_Ptr = (unsigned int*)JOESPOINTER;
	InitSPI(8);
	*/
	/*****************************************************************************
	*
	*		Write Enable the EEPROM
	*
	*****************************************************************************/ 
 	SelectEESPI();
	InitSPI(16, SPICLK_11);
	
	/* write enable the EEPROM */
	WriteSPI(EEWREN);
	
	WriteSPI(EEWRSR | 0x02);

	WriteSPI(EERDSR);
	ReadData = ReadSPI();

	DeSelectEESPI();
	
}
	
/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  WriteEE

    This function writes a byte value to the EEPROM

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void WriteEE(unsigned int addr, unsigned int data)
{

	unsigned int Opcode,i, count;   
	unsigned int WriteData;
	unsigned int ReadData;
	unsigned int AddressHi, AddressLo; 
	unsigned int Data;
	unsigned int WriteStat;
	
	/*****************************************************************************
	*
	*  			Write the EEPROM
	*
	*****************************************************************************/ 
	/* Assert the EEPROM chip select */ 

	SelectEESPI();
	WriteSPI(EEWREN);
	SPIWaitTxBusy();
	DeSelectEESPI();
	ReadSPI();

	Data = data & 0x00FF;   	  
		
	Opcode =  EEWRITE;	
		
	AddressHi = (addr >> 8) & 0x00FF;
	AddressLo = addr & 0x00FF;      
	
	SelectEESPI();
	
	WriteSPI(Opcode);
	WriteSPI(AddressHi); 	
	WriteSPI(AddressLo);
	WriteSPI(Data);   
	SPIWaitTxBusy();
	DeSelectEESPI();
	ReadSPI();
	ReadSPI();
	ReadSPI();
	ReadSPI();
		
	/*****************************************************************************
	*
	*	Check for Read Status Register
	*
	*****************************************************************************/ 

	
	SelectEESPI();
	WriteSPI(EERDSR);
	WriteSPI(0x0000);
	SPIWaitTxBusy();
	/* De-assert the EEPROM chip select */ 
	DeSelectEESPI();
	ReadSPI();
	WriteStat = ReadSPI(); 
	
	      		
	while(WriteStat)
	{ 
//The f0 compare is incompete, we should compare with FF 12_09_05
//		WriteStat = WriteStat & 0x00F0; 
		WriteStat = WriteStat & 0x00FF; 
		if (WriteStat)
		{ 		
			SelectEESPI();
			WriteSPI(EERDSR);
			WriteSPI(0x0000);
			SPIWaitTxBusy();
			/* De-assert the EEPROM chip select */ 
			DeSelectEESPI();
			ReadSPI();
			WriteStat = ReadSPI(); 
			
			count++;
		}
		     
	}  
	
} 

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  ReadEE

    This function reads a byte value from the EEPROM

 GLOBALS: 

 RETURNS:   returns the byte read from the address supplied

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int ReadEE(unsigned int addr)
{	
    
    unsigned int Opcode,i, count;   
	unsigned int ReadData, WriteStat;
	unsigned int AddressHi, AddressLo;    
	
	/* Assert the EEPROM chip select */ 
	SelectEESPI();
	WriteSPI(EERDSR);
	WriteSPI(0);
	SPIWaitTxBusy();
	/* De-assert the EEPROM chip select */ 
	DeSelectEESPI();	

	WriteStat = ReadSPI(); 
	WriteStat = ReadSPI(); 
	
	
	while(WriteStat)
	{ 
		WriteStat = WriteStat & 0x00F0; 
		if (WriteStat)
		{ 		
			/* Assert the EEPROM chip select */ 
			SelectEESPI();
			WriteSPI(EERDSR);
			WriteSPI(0);
			SPIWaitTxBusy();
			/* De-assert the EEPROM chip select */ 
			DeSelectEESPI();	
	
			WriteStat = ReadSPI(); 
			WriteStat = ReadSPI(); 
			
			count++;
		}
		     
	}      

	/*****************************************************************************
	*
	*  			Read the EEPROM
	*
	*****************************************************************************/ 

	/* Assert the EEPROM chip select */ 
	SelectEESPI();
	
	Opcode =  EEREAD;	
		
	AddressHi = (addr>>8) & 0x00FF;
	AddressLo = addr & 0x00FF;	
		
	WriteSPI(Opcode); 
	WriteSPI(AddressHi); 
	WriteSPI(AddressLo); 
	WriteSPI(0x0000); 	

	SPIWaitTxBusy();

	/* De-assert the EEPROM chip select */ 
	DeSelectEESPI();

	ReadData = ReadSPI();     
	ReadData = ReadSPI();     
	ReadData = ReadSPI();     
	ReadData = ReadSPI();     

	return(ReadData);
}     

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  CalcCRC 
 			calculates two crc verification bytes based on message
 			buffer and length.
 GLOBALS:
 RETURNS:   none
 SEE ALSO:  
------------------------------------------------------------------------*/
void EECalcCRC(unsigned int *Msg, unsigned Len, unsigned *retCRChi, unsigned *retCRClo)
{
	extern unsigned int aCRChi[], aCRClo[];
	unsigned CRChi = 0xFF;
	unsigned CRClo = 0xFF; 
	unsigned int Index; 
	
	while (Len--)
	{ 
		Index = CRChi ^ *Msg++;
		CRChi = CRClo ^ aCRChi[Index];
		CRClo = aCRClo[Index];
	} 
	*retCRChi = CRChi;
	*retCRClo = CRClo;
} 

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  WriteEnableTDMEE

    This function Performs either a WriteEnable or Disable to the TDM
	EEPROM.

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void WriteEnableTDMEE( unsigned short val, unsigned int tdmNo)
{
	unsigned int csMask;

	if(tdmNo > 1)
		return;
	/* Assert the EEPROM chip select */ 
	if(!tdmNo)
		csMask = SPICS_EECS0;
	else
		csMask = SPICS_EECS1;

	SPIWriteCS(csMask);
	
	if(val)
	{ //enable TDM
		WriteSPI(TDMEEWEN);
	}
	else
	{//disable TDM
		WriteSPI(TDMEEWDS);
	}
	SPIWaitTxBusy();
	/* De-assert the EEPROM chip select */ 
	SPIWriteCS(SPICS_CLEAR);
	ReadSPI();
} 

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  WriteTDMEE

    This function writes a byte value to the EEPROM

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void WriteTDMEE(unsigned int addr, unsigned int data, unsigned int tdmNo)
{

	unsigned int Opcode,i, count;   
	unsigned int WriteData;
	unsigned int ReadData;
	unsigned int AddressHi, AddressLo; 
	unsigned int Data;
	unsigned int WriteStat;
	unsigned int csMask;

	if(tdmNo > 1)
		return;
	
	/* Assert the EEPROM chip select */ 
	if(!tdmNo)
		csMask = SPICS_EECS0;
	else
		csMask = SPICS_EECS1;

	Data = data & 0x0000FFFF;   	  
		
	Opcode =  TDMEEWRITE | (addr & 0x00FF);	
		
	SPIWriteCS(csMask);
	WriteSPI(Opcode);
	WriteSPI(Data);
	SPIWaitTxBusy();
	/* De-assert the EEPROM chip select */ 
	ReadSPI();
	ReadSPI();
	
	//Now we read D0 until it goes high signifying byte has
	//been written
	WriteStat = 0;
	while(!WriteStat)
	{
		WriteSPI(0);
		SPIWaitTxBusy();
		WriteStat = ReadSPI();
	}
	SPIWriteCS(SPICS_CLEAR);
} 

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  ReadTDMEE

    This function reads a byte value from the EEPROM

 GLOBALS: 

 RETURNS:   returns the byte read from the address supplied

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int ReadTDMEE(unsigned int addr, unsigned int tdmNo)
{	
    
   unsigned int Opcode,i, count;   
	unsigned int ReadData, ReadData1, ReadData2;
	unsigned int startaddr, Opcode2;    
	unsigned int csMask;
	
	/* Assert the EEPROM chip select */ 
	if(!tdmNo)
		csMask = SPICS_EECS0;
	else
		csMask = SPICS_EECS1;
	
	Opcode = (TDMEEREAD | (addr & 0xFFFF)) << 1;

	SPIWriteCS(csMask);
	WriteSPI(Opcode);
	WriteSPI(0x0000);
	SPIWaitTxBusy();
	/* De-assert the EEPROM chip select */ 
	SPIWriteCS(SPICS_CLEAR);
	
	ReadSPI();
	ReadData = ReadSPI();
	
	return(ReadData);
}

void InitEEPROMImage( void )
{
	unsigned int i;
	
	for(i = 0; i < CONFIG_SIZE; i++)
		EEPROMImage[i] = 0;
}
/*--(LOCAL FUNCTION)----------------------------------------------------------------
 FUNCTION:  QueryEEPromX100()
 
 Executes a GetConfig call, will return the getconfig success flag when a read is successful
 Up to 100 retries on a bad read
RETURNS:   none
------------------------------------------------------------------------------------*/
unsigned int QueryEEPromX100()
{
	unsigned int i = 0;
	unsigned int j;
//	unsigned int iErrorOccurred = 0;
	for(i=0; i<100; i++)
	{
		j = GetConfig(); 
		if(j==1)
		{
/*			if(iErrorOccurred)
				printk("read succedded\n");*/
			return 1; //good read
		}
/*		printk("attempted to read eeProm\n");
		printk("eeprom read error code = %x", j);
		printk("\n");
		iErrorOccurred = 1;*/
	}
	return 0; //bad read
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GetConfig()
 
 			This function retrieves the cupler configuration from the EEPROM 
 			and sets up the coupler and puts it in the appropriate CouplerMode 
 			
 GLOBALS:   EEPROMImage[]

 RETURNS:   none
 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int GetConfig( void )
{   

	unsigned int nRetVal = 0;
	unsigned int i,j;   
	unsigned int CRChi = 0xFF;
	unsigned int CRClo = 0xFF; 
	unsigned int index, Len, CurrentChannel; 
	unsigned int temp1, temp2, temp3, temp4; 
	unsigned int Opcode, Address, ReadData;
	long	     ltemp1, ltemp2, ltemp3, ltemp4;		 
	unsigned int *Msg;
	unsigned int *ptr;
	
	printk( "hc2xio: GetConfig() being called\n" );

	InitSPI(8, SPICLK_11);

	for(i=0;i<CONFIG_SIZE;i++)
	{
		EEPROMImage[i]  = ReadEE(i);	
	}
/*
	for(i=0;i<CONFIG_SIZE;i++)
	{
		printk(" index = %x, ", i);
		printk(" ");
		printk(" %x", EEPROMImage[i]);
		//		EEPROMImage[CRCLBYTE]);
	}
*/		
	//This code resets the SPI to work properly
	//with the TDM A2D Converters.  Without it
	//the SPI on TDM0 has unrecoverable clocking
	//problems
	InitSPI(8, SPICLK_00);
	
	SPIWriteCS(SPICS_CLEAR);
	WriteSPI(0x0000);
	SPIWaitTxBusy();
	ReadSPI();

#if 0
	printk("hc2xio: EEPROMImage[CRCHBYTE] = %x\n"  
		"EEPROMImage[CRCLBYTE] = %x\n"  	
		"EEPROMImage[TESTBYTE2] = %x\n"
		"EEPROMImage[TESTBYTE1]= %x\n",
		EEPROMImage[CRCHBYTE],  
		EEPROMImage[CRCLBYTE],  	
		EEPROMImage[TESTBYTE2],
		EEPROMImage[TESTBYTE1]);  
#endif

	if(EEPROMImage[TESTBYTE2]== 0x00aa && EEPROMImage[TESTBYTE1]== 0x0055)
	{ 	
		//printk("hc2xio: GetConfig passed byte check\n");
	
	   	Len = CONFIG_SIZE-2; 
		Msg = EEPROMImage;
			
		while (Len--)
		{   
			index = CRChi ^ *Msg++;
			CRChi = CRClo ^ aCRChi[index];
			CRClo = aCRClo[index]; 
		} 
		//printk("CRChi = %x, CRClo = %x\n", CRChi, CRClo);
		//printk("EEPROM[HI] = %x, EEPROM[LO] = %x\n", EEPROMImage[CRCHBYTE],
		//		EEPROMImage[CRCLBYTE]);
		if ((CRChi == EEPROMImage[CRCHBYTE]) && (CRClo == EEPROMImage[CRCLBYTE]))               
		{ 		
			index = 0x0000;
		 	hc2xip_addr.a = (unsigned char)EEPROMImage[index++];
		 	hc2xip_addr.b = (unsigned char)EEPROMImage[index++];
		 	hc2xip_addr.c = (unsigned char)EEPROMImage[index++];
		 	hc2xip_addr.d = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[0] = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[1] = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[2] = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[3] = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[4] = (unsigned char)EEPROMImage[index++];
			hc2xip_addr.mac[5] = (unsigned char)EEPROMImage[index++];
			nRetVal = 1;
		}
		else 
		{
/*			printk("crc failure, whoops!\n");
			printk("CRChi = %x, CRClo = %x\n", CRChi, CRClo);
			printk("EEPROM[HI] = %x, EEPROM[LO] = %x\n", EEPROMImage[CRCHBYTE],
				EEPROMImage[CRCLBYTE]);		
			for(i=0;i<CONFIG_SIZE;i++)
			{
				printk(" index = %x, ", i);
				printk(" ");
				printk(" %x", EEPROMImage[i]);
			}*/
			nRetVal = 2;
		}
	}
	else
	{
/*		for(i=0;i<CONFIG_SIZE;i++)
		{
			printk(" index = %x, ", i);
			printk(" ");
			printk(" %x", EEPROMImage[i]);
		}	*/
		nRetVal = 3;

//			printk("check byte error\n");
//			printk("EEPROM[cb1] = %x, EEPROM[cb2] = %x\n", EEPROMImage[TESTBYTE1], EEPROMImage[TESTBYTE2]);
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  StoreConfig()
 
 			This function writes the eeprom currently it records data for ip, tdm input style
 			and offset values for tdm channels.
 GLOBALS:   
 RETURNS:   none
 SEE ALSO:  
------------------------------------------------------------------------*/

void StoreConfig(void)
{ 

	unsigned int 	i, index = 0;
	unsigned int 	Index, Len;
	unsigned int 	*Msg;
	unsigned int 	CRChi = 0xFF;
	unsigned int 	CRClo = 0xFF; 
	
	printk( "hc2xio: StoreConfig() being called\n" );

 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.a;
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.b;
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.c;
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.d;
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[0];
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[1];
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[2];
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[3];
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[4];
 	EEPROMImage[index++] = (unsigned int)hc2xip_addr.mac[5];
	
	EEPROMImage[TESTBYTE2] = 0x00aa;
	EEPROMImage[TESTBYTE1] = 0x0055;	

	/* run everything through except the last 2 */
   	Len = CONFIG_SIZE-2;	
	Msg = EEPROMImage; 
	
	while (Len--)
	{ 
		Index = CRChi ^ *Msg++;
		CRChi = CRClo ^ aCRChi[Index];
		CRClo = aCRClo[Index];
	}	
	
	EEPROMImage[CRCHBYTE] = CRChi;  
	EEPROMImage[CRCLBYTE] = CRClo;  	

	InitSPI(8, SPICLK_11);  
	
	/* write the eeprom */
	for(i=0;i< CONFIG_SIZE;i++)
	{  
//		printk("EEPROMImage at %d", i);
//		printk(" %d\n", EEPROMImage[i]); 
	 	WriteEE(i, EEPROMImage[i]);	
	}    
//	printk("exited for loop\n");
	//This code resets the SPI to work properly
	//with the TDM A2D Converters.  Without it
	//the SPI on TDM0 has unrecoverable clocking
	//problems
	InitSPI(8, SPICLK_00);
	
	SPIWriteCS(SPICS_CLEAR);
	WriteSPI(0x0000);
	SPIWaitTxBusy();
	ReadSPI();

}    

int AssignEEPromMemory(int iLocation, char chaValue)
{
	if(iLocation < TESTBYTE1)
	{
		EEPROMImage[iLocation] = chaValue;
		return 1;
	}
	else
		return 0;	
}

char GetEEPromMemory(int iLocation)
{
	if(iLocation < CONFIG_SIZE)
		return EEPROMImage[iLocation];
	else 
	return 0;
}
