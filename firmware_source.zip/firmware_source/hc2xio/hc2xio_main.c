/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.

// Version history
// 23-Dec-16  TP   Update version printk 8.0.0.16 20161223 to match PC program version only
// 01-Feb-17  TP   Update version printk 8.0.0.17 20170201 to match PC program version
// 03-Apr-17  TP   Update version printk 8.0.0.18 20170403
// 16-Apr-17  TP   Update version printk 8.0.0.19 20170416
// 25-Apr-17  TP   Update version printk 8.0.0.20 20170425
***************************************************************************/ 

#ifndef __KERNEL__
	#define __KERNEL
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <asm/uaccess.h>
#include <asm/semaphore.h>
#include <asm/segment.h>

#include "encoder.h"
#include "hc2xio.h"
#include "hc2xio_exports.h"
#include "hc1xcomm_local.h"
#include "schedule_local.h"
#include "hc2xspi.h"
#include "tpo.h"
#include "dio.h"
#include "hc2xtdm.h"
#include "hc2xwd.h"
#include "system.h"
#include "eeprom.h"
#include "hc2xmem.h"

#include "hc2xmstr.h"
#include "hc2xmstr_exports.h"
#include "transferTable.h"

typedef struct hc2xmstrFile
{
	struct semaphore sem;
} masterFile;

masterFile g_MasterFile;
enum HC2XMSTR_ERROR g_bMstrError = HC2XMSTR_NO_ERROR;

struct TRANSFER_TABLE g_transferTable;
int g_bBlock = 0;
BOOL g_bSecondaryBoardActive = FALSE;

int driver_major  = 0;
struct fasync_struct *async_queue;

int g_useTimer = 0;
int g_encoderCount = 0;

unsigned short bAccessingSPI = 0;
unsigned short bAccessingEEPROM = 0;
unsigned short bWritingTDMEEMemory = 0;

int driver_fasync(int fd, struct file *filp, int mode)
{
	printk("hc2xio: driver_fasync\n");
	return fasync_helper(fd, filp, mode, &async_queue);
}

int driver_release(struct inode *inode, struct file *filp)
{
//	MOD_DEC_USE_COUNT;
//	g_useTimer--;
/*WDT 06_30_06
Do not disable watchdogs in driver release!  The drivers should never unload during normal operations, unloading watchdogs can potentially cause runaway conditions on heat controllers*/
	return 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  driver_open

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int driver_open(struct inode* i, struct file* f)
{
	printk("hc2xio: driver_open\n");
	MOD_INC_USE_COUNT;

	f->private_data = &g_MasterFile;

	return 0;
}

ssize_t driver_write(struct file* f, const char* buf, size_t len, loff_t* thing)
{	
	return len;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  driver_ioctl

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int driver_ioctl(struct inode* inode, struct file* f, 
	unsigned int cmd, unsigned long arg)
{
	int status = 0;
	int i = 0;
	int err = 0;
	char* local_slave = 0;
	int nRetVal = 0;

	masterFile *data = (masterFile *)f->private_data;

	if( _IOC_DIR(cmd) & _IOC_READ )
	{
		err = !access_ok(VERIFY_WRITE, (void *)arg, _IOC_SIZE(cmd));
	}
	else if( _IOC_DIR(cmd) & _IOC_WRITE )
	{
		err = !access_ok(VERIFY_READ, (void *)arg, _IOC_SIZE(cmd));
	}

	if(err)
	{
		printk( "driver_ioctl: return EFAULT\n" );
		nRetVal = -EFAULT;
	}
	else
	{
		switch ( cmd )
		{
		case HC2XCTLAPP_INIT_TDM:
			Tdm_processHc2xEEProm();
			break;

		case HC2XCTLAPP_SetIPAddress:
			bAccessingEEPROM = 1;
			for(i = 0; i < 10000 && bAccessingSPI; i++)
			{
				/*empty*/;	
			}

			if ( bAccessingSPI )
			{
				printk("hc2xio: driver_ioctl() SPI busy\n");
				bAccessingEEPROM = 0;
				nRetVal = -EFAULT; 
			}
			else
			{
				status = access_ok(VERIFY_READ, (void*) arg, 4);
				if ( status == 0 )
				{
					printk("hc2xio: driver_ioctl() access_ok failed\n");
					bAccessingEEPROM = 0;
					nRetVal = -EFAULT; 
				}
				else
				{
					__get_user( hc2xip_addr.a, (char*) arg );
					__get_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
					__get_user( hc2xip_addr.c, ((char*) arg) + 2 );
					__get_user( hc2xip_addr.d, ((char*) arg) + 3 );
					
					printk("hc2xio: Setting IP: %d.%d.%d.%d\n", hc2xip_addr.a, hc2xip_addr.b,
																				hc2xip_addr.c, hc2xip_addr.d);
					StoreConfig();
					bAccessingEEPROM = 0;
				}
			}
			break;
		
		case HC2XCTLAPP_GetIPAddress:
			bAccessingEEPROM = 1;
			for(i = 0; i < 10000 && bAccessingSPI; i++)
			{
				/*empty*/;	
			}

			if ( bAccessingSPI )
			{
				printk("hc2xio: driver_ioctl() SPI busy\n");
				bAccessingEEPROM = 0;
				nRetVal = -EFAULT; 
			}
			else
			{
				status = access_ok(VERIFY_WRITE, (void*) arg, 4);

				if(QueryEEPromX100())
				{
					__put_user( hc2xip_addr.a, (char*) arg );
					__put_user( hc2xip_addr.b, ((char*) arg) + 1 ); 
					__put_user( hc2xip_addr.c, ((char*) arg) + 2 );
					__put_user( hc2xip_addr.d, ((char*) arg) + 3 );
				}
				bAccessingEEPROM = 0;
			}
			break;

		case HC2XCTLAPP_SetMACAddress:
			bAccessingEEPROM = 1;
			for(i = 0; i < 10000 && bAccessingSPI; i++)
			{
				/*empty*/;	
			}

			if ( bAccessingSPI )
			{
				printk("hc2xio: driver_ioctl() SPI busy\n");
				bAccessingEEPROM = 0;
				nRetVal = -EFAULT; 
			}
			else
			{
				status = access_ok(VERIFY_READ, (void*) arg, 4);
				if ( status == 0 )
				{
					printk("hc2xio: driver_ioctl() access_ok failed\n");
					bAccessingEEPROM = 0;
					nRetVal = -EFAULT; 
				}
				else
				{
					__get_user( hc2xip_addr.mac[0], (unsigned char*) arg );
					__get_user( hc2xip_addr.mac[1], ((unsigned char*) arg) + 1 ); 
					__get_user( hc2xip_addr.mac[2], ((unsigned char*) arg) + 2 );
					__get_user( hc2xip_addr.mac[3], ((unsigned char*) arg) + 3 );
					__get_user( hc2xip_addr.mac[4], ((unsigned char*) arg) + 4 );
					__get_user( hc2xip_addr.mac[5], ((unsigned char*) arg) + 5 );
					
					printk("hc2xio: Setting MAC: %d.%d.%d.%d.%d.%d\n", hc2xip_addr.mac[0], 
								hc2xip_addr.mac[1], hc2xip_addr.mac[2], hc2xip_addr.mac[3],
								hc2xip_addr.mac[4], hc2xip_addr.mac[5]);
					StoreConfig();
					bAccessingEEPROM = 0;
				}
			}
			break;

		case HC2XCTLAPP_GetMACAddress:
			bAccessingEEPROM = 1;
			for(i = 0; i < 10000 && bAccessingSPI; i++)
			{
				/*empty*/;	
			}

			if ( bAccessingSPI )
			{
				printk("hc2xio: driver_ioctl() SPI busy\n");
				bAccessingEEPROM = 0;
				nRetVal = -EFAULT; 
			}
			else
			{
				status = access_ok(VERIFY_WRITE, (void*) arg, 6);

				if(QueryEEPromX100())
				{
					for(i = 0; i < 6; i++)
					{
						__put_user( hc2xip_addr.mac[i], (unsigned char*) arg+i );
					}
				}
				
				bAccessingEEPROM = 0;
			}
			break;

		case IOCTL_GET_JIFFIES:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if(g_bBlock)	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;
					copy_to_user((unsigned long *)arg, (unsigned long *)(&jiffies), 
								sizeof(unsigned long));

					g_bBlock = 0;
				}
				up(&(data->sem));
			}
			break;

		case IOCTL_SET_SOCKET_ERROR:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if(g_bBlock)	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					copy_from_user((enum HC2XMSTR_ERROR *)(&g_bMstrError), 
						(enum HC2XMSTR_ERROR *)(arg), sizeof(enum HC2XMSTR_ERROR));

					g_bBlock = 0;
				}
				up(&(data->sem));
			}
			break;

		case IOCTL_GET_SOCKET_ERROR:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if(g_bBlock)	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					copy_from_user((enum HC2XMSTR_ERROR *)arg, 
						(enum HC2XMSTR_ERROR *)(&g_bMstrError), sizeof(enum HC2XMSTR_ERROR));

					g_bBlock = 0;
				}
				up(&(data->sem));
			}
			break;

		case IOCTL_SET_NO_DATA:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Set the flag.
					//
					g_transferTable.tableSecondary.statusFlags |= StatusFlagNoData;
					nRetVal = 0;

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		case IOCTL_CLEAR_NO_DATA:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Clear the flag.
					//
					g_transferTable.tableSecondary.statusFlags &= ~StatusFlagNoData;
					nRetVal = 0;

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		case IOCTL_GET_TRANSFER_TABLE:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Copy transfer table to user.
					//
					status = copy_to_user(
						(struct TRANSFER_TABLE *) arg, 
						&g_transferTable, 
						sizeof(struct TRANSFER_TABLE));
					if ( status )
					{
						nRetVal = -EACCES;
					}
					else
					{
						nRetVal = 0;
					}

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		case IOCTL_SET_TRANSFER_TABLE:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Copy transfer table to user.
					//
					status = copy_from_user(
						&g_transferTable, 
						(struct TRANSFER_TABLE *) arg, 						
						sizeof(struct TRANSFER_TABLE));
					if ( status )
					{
						nRetVal = -EACCES;
					}
					else
					{
						nRetVal = 0;
					}

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		case IOCTL_GET_SECONDARY_ACTIVE:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Copy flag to user.
					//

					status = copy_to_user(
						(BOOL *) arg, 
						&g_bSecondaryBoardActive, 
						sizeof(BOOL) );

					if ( status )
					{
						nRetVal = -EACCES;
					}
					else
					{
						nRetVal = 0;
					}

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		case IOCTL_SET_SECONDARY_ACTIVE:
			status = down_interruptible(&(data->sem));
			if ( status )	
			{
				nRetVal = -ERESTARTSYS;
			}
			else
			{
				if( g_bBlock )	
				{
					nRetVal = -ERESTARTSYS;
				}
				else
				{
					g_bBlock = 1;

					//
					// Copy flag to user.
					//

					status = copy_from_user(
						&g_bSecondaryBoardActive, 
						(BOOL *) arg, 
						sizeof(BOOL) );

					if ( status )
					{
						nRetVal = -EACCES;
					}
					else
					{
						nRetVal = 0;
					}

					g_bBlock = 0;
				}

				up(&(data->sem));
			}
			break;

		default:
			return -EINVAL;
		}
	}

	return nRetVal;
}

struct file_operations driver_fops =
{
	open:		driver_open,
	fasync:     driver_fasync,
	release:    driver_release,
	write:		driver_write,
	ioctl:	driver_ioctl,
};

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  init_module

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int init_module()
{
	int status = 0;

	driver_fops.owner = THIS_MODULE;

	/*
	* Register your major, and accept a dynamic number. This is the
	* first thing to do, in order to avoid releasing other module's
	* fops in scull_cleanup_module()
	*/
	status = register_chrdev(driver_major, "hc2xio", &driver_fops);
	if (status < 0)
	{
		printk(KERN_WARNING "hc2xio: can't get major %d\n", driver_major);
	}
	else
	{
		if (driver_major == 0)
		{
			driver_major = status; /* dynamic */
		}
		
		sema_init(&(g_MasterFile.sem), 1);

		TransferTable_Init( &g_transferTable );
		g_bSecondaryBoardActive = FALSE;

		if(!g_useTimer)
		{
			//system must initialized before other objects so pointers to physical memory are valid
			bAccessingSPI = 0;
			bAccessingEEPROM = 0;
			bWritingTDMEEMemory = 0;
			SystemInit();

			InitEEPROMImage();
			initialize_tpos();
			initialize_encoder();
			DIO_Initialize();
			D2A_init();
			Scheduler_init(&scheduler);
			Tdm_init(0);

			initialize_uart();
		}
		g_useTimer++; 

		status = 0;

		printk("hc2xio::init_module() loaded version 8.0.0.28 20180208\n");
	}

	return status;
}

void cleanup_module()
{
	iounmap(ptrDIOW1);
	iounmap(ptrDIOW2);
	iounmap(ptrDIOW3);
	iounmap(ptrDIOW4);
	iounmap(ptrDIOW5);
	iounmap(ptrDIOW6);
	iounmap(ptrDOW24V);
	iounmap(ptrDIR24V);
	iounmap(ptrTPO1);
	iounmap(ptrTPO2);
	iounmap(ptrTPO3);
	iounmap(ptrTPO4);
	iounmap(ptrSPICS);

	unregister_chrdev(driver_major, "hc2xio");
}
