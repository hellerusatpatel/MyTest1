/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 

#include "schedule_local.h"
#include "hc1xcomm_local.h"
#include "tpo.h"

#ifndef __KERNEL__
   #define __KERNEL
#endif
                                                                                
#ifndef MODULE
   #define MODULE
#endif
                                                                                
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/arch/hardware.h>

#include "hc2xutils.h"
#include "dio.h"
#include "hc2xwd.h"
#include "hc2xmem.h"
#include "hc2xio.h"
#include "D2Adrv.h"
#define COLLECTION_TEST 1
void initialize_seq_timer( void );
void initialize_A2Dseq_timer( void );
//void initialize_pre_timer( void );
void Scheduler_A2Dsequencer(Scheduler* pScheduler);
                                                                                
Scheduler scheduler;

static unsigned short bInTDMStore = 0;
static unsigned short bFirstTimer = 1;
static unsigned short bFirstA2DTimer = 1;
static struct timer_list sched_timer;
static struct timer_list pre_timer;
static struct timer_list A2D_timer;
//UINT randomTestVariable3 = 0;

static UCHAR tempbuff[MAX_MESSAGE_LENGTH+1];

extern int g_useTimer;
/*
void pre_timer_handler(unsigned long arg)
{
	Scheduler_preSequencer(&scheduler);
	initialize_pre_timer();
}

void initialize_pre_timer( void )
{
   static unsigned char mask = 0;// = inl(GPIO_PBDR);
                                                                                
   init_timer(&pre_timer);
   pre_timer.function = pre_timer_handler;
   pre_timer.data = 0;
   pre_timer.expires = jiffies + 20; // 20  mSecs. (min is 1 mSecs.)	
	//printk("jiffies = %x\nexpires = %x\n", jiffies, sched_timer.expires);
	//printk("Frequency = 0x%x\n",HZ);
   add_timer(&pre_timer);
	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
   if(mask)// & 0x1)
      mask = 0x0;
   else
      mask = 0xff;
//	writeb(mask, ptrTPO1);
#if 0
   outl(mask, GPIO_PBDR);
#endif
}
*/
void timer_handler(unsigned long arg)
{
	if(bFirstTimer)
	{
//		randomTestVariable3 = 0;
		bFirstTimer = 0;
		bSkipIOTickle = 0;
		bSkipTDMTickle = 0;
		hc2xwd_EnableDog(IO_DOG, 1);
	}
/*	if(randomTestVariable3 >=2000)
		Scheduler_sequencer(pBadSequencer);
	randomTestVariable3++;*/
//	printk("crash counter %d\n", randomTestVariable3);
	if(!bSkipIOTickle)
		hc2xwd_TickleDog(IO_DOG);
	Scheduler_sequencer(&scheduler);

		initialize_seq_timer();
}

void A2Dtimer_handler(unsigned long arg)
{
//testtesttest
	if(bInTDMStore)
		return;
	Scheduler * pSchedulerNull;
	pSchedulerNull = NULL;
	static short cnt = 0;
	if(bFirstA2DTimer)
	{
		bFirstA2DTimer = 0;
		hc2xwd_EnableDog(TDM_DOG, 1);
	}
/*	if(randomTestVariable3 >= 600)
	{
		Scheduler_sequencer(pSchedulerNull);
	}
	randomTestVariable3++;*/
	if(!bSkipTDMTickle)
		hc2xwd_TickleDog(TDM_DOG);
	bAccessingSPI = 1;
	if(!bAccessingEEPROM)
	{
		cnt++;
		if(cnt >= 30)
		{
//			printk("Executing A2D/D2A\n");
			cnt = 0;
		}
		Scheduler_A2Dsequencer(&scheduler);
		D2A_update();
	}
	bAccessingSPI = 0;
	initialize_A2Dseq_timer();
}

void sch_suspendTimer(unsigned short sEnable)
{
	if(sEnable)
	{
		printk("enabling A2D\n");
		bInTDMStore = 0;
		bFirstA2DTimer= TRUE;
//		initialize_A2Dseq_timer();
//		hc2xwd_EnableDog(TDM_DOG, 1);
	}
	else
	{
      printk("disabling A2D\n");
		bInTDMStore = 1;
		hc2xwd_EnableDog(TDM_DOG, 0);
//		kill_timer(&A2D_timer);
	}
}

void initialize_seq_timer( void )
{
   static unsigned char mask = 0;// = inl(GPIO_PBDR);
                                                                                
   init_timer(&sched_timer);
   sched_timer.function = timer_handler;
   sched_timer.data = 0;
   sched_timer.expires = jiffies + 20; // 20  mSecs. (min is 1 mSecs.)	
	//printk("jiffies = %x\nexpires = %x\n", jiffies, sched_timer.expires);
	//printk("Frequency = 0x%x\n",HZ);
   add_timer(&sched_timer);
	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
   if(mask)// & 0x1)
      mask = 0x0;
   else
      mask = 0xff;
//	writeb(mask, ptrTPO1);
#if 0
   outl(mask, GPIO_PBDR);
#endif
}

void initialize_A2Dseq_timer( void )
{
//testtesttest
//	return;
	 unsigned long mask;// = inl(GPIO_PBDR);
                                                                                
   init_timer(&A2D_timer);
   A2D_timer.function = A2Dtimer_handler;
   A2D_timer.data = 0;
   A2D_timer.expires = jiffies + 70; // 70 mSecs.
	//printk("jiffies = %x\nexpires = %x\n", jiffies, sched_timer.expires);
	//printk("Frequency = 0x%x\n",HZ);
   add_timer(&A2D_timer);
	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
   if(mask & 0x2)
      mask &= ~(0x2);
   else
      mask |= 0x2;
#if 0
   outl(mask, GPIO_PBDR);
#endif
}

void Scheduler_init(Scheduler* pScheduler)
{
	bModbusMaster=FALSE;
	pScheduler->sequenceNo   =  0;
	pScheduler->timerCount   =  0;	
	pScheduler->scanPeriod   =  5;	// in ms
	pScheduler->goodCOMM     =  0;
	pScheduler->consecutiveNoReadScans = 0;
	pScheduler->elapsedTempZoneTime = 0;
	pScheduler->inProcess	   =  FALSE;   
	pScheduler->commError	   =  0;
	pScheduler->lossOfComm   =  0;
	pScheduler->upDateTPOs   =  FALSE;
	pScheduler->m_bTimerFired = FALSE;
	pScheduler->lSchedulerEx = 0;
	pScheduler->HighPartTime = 0;
	pScheduler->LowPartTime = 0;
	pScheduler->elapsedMillisecs = 0;
	pScheduler->AnalogInTicks = 0;

	initialize_seq_timer();
}


void Scheduler_resetCommError(Scheduler* pScheduler)
{
   pScheduler->commError = 0;
}

//******************************************************************************
// Scheduler_setContainerAddress
//
// 	Abstract:
//  The scheduler needs the address of the container in order to call the
// 	processing functions. Once it is set then we can set interrupts to happen.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Scheduler_setContainerAddress(Scheduler* pScheduler)
{
	  // this is the closest thing to a constructor withouth having to make it
	  // part of the DbContainer class. 
//	  Oven_setScanPeriod(&(g_dbContainer.ovenDb), pScheduler->scanPeriod);
}

//******************************************************************************
// Scheduler::sequencer
//
// Abstract:
//	The sequencer is triggered on each 1ms interrupt and a counter is incremented
// 	to maintain a sequence position. When the counter reaches the scanPeriod time
// 	it is reset to start processing the loop again.
// 	Interrupts need to be turned off when setting the inProcess flag. Should not
//	need to worry about when setting to FALSE because no other process should
// 	be able to run process functions if inProcess is TRUE.
//  In the event of an overrun, it is assumed that if the HC1X IO Controller does
//	not respond by the following sequence step it will not.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Scheduler_sequencer(Scheduler* pScheduler)
{

	DWORD commCount = 0;
	int i = 0;
	
	pScheduler->lSchedulerEx++;
	pScheduler->elapsedMillisecs += 20; //This can be changed to as fast as 1mSec.

#ifdef HC1X_DATA_COLLECTION
	
#else
	IODIN_process_nonModbus(&(digitalInDb));
#endif

	if(pScheduler->elapsedMillisecs == 60 ) //between 20 and 40 ms
	{
#ifdef HC1X_DATA_COLLECTION
		Hc1xComm_addMessage(&(hc1xComm), WRITE_DIGITAL_OUT_MESSAGE,1,0,0);
#else

		IODOUT_process_nonModbus(&digitalOutDb);
		DIO_Write_Outputs();
#endif
	}		

	if(pScheduler->elapsedMillisecs == 80 )
	{
#ifdef HC1X_DATA_COLLECTION
		Hc1xComm_addMessage(&(hc1xComm), WRITE_ANALOG_OUT_MESSAGE,1,0,0x20);
#else
		//Here is where we check the Analog outs for new values.
		IOANALOGOUT_WRITE_OUT(&analogOutDb);
		TPO_CheckInput();
#endif
	}
	
	if(pScheduler->elapsedMillisecs == 100 ) //between 20 and 40 ms
	{
#ifdef HC1X_DATA_COLLECTION
		IODIN_process(&(digitalInDb));		// put the data in an array for processing.
		IOANALOGIN_process(&(analogInDb));
#else
		if(bModbusMaster==TRUE)
		{
			IOANALOGIN_process(&(analogInDb));
		}
		IOANALOGIN_process_nonModbus(&(analogInDb));

		if(bModbusMaster==TRUE)
		{
			Hc1xComm_addMessage(&(hc1xComm), READ_ANALOG_IN_MESSAGE, 1, 0, 60);
			Hc1xComm_sendMessage(&(hc1xComm), READ_ANALOG_IN_MESSAGE,&(pScheduler->inProcess));
		}
#endif
		pScheduler->elapsedMillisecs = 0;
	}
}
/////////////////////////////////////////////////////////////////////////////
//
//67 ms timer to acquire a2d conversions, based on a 15 hz conversion setting
// 15 hz = 66 2/3 ms
//
//
/////////////////////////////////////////////////////////////////////////////
void Scheduler_A2Dsequencer(Scheduler* pScheduler)
{
	Tdm_beginAcquisition();
}
//returns TRUE if we've detected comm loss.
BOOL Scheduler_getCommLoss(Scheduler* pScheduler)
{
	BOOL bRetVal = FALSE;
	if(pScheduler->goodCOMM == 0 && pScheduler->consecutiveNoReadScans > 40 )
		bRetVal = TRUE;
	return bRetVal;
}

void Scheduler_reset( Scheduler* pScheduler )
{ 
	pScheduler->sequenceNo = 0;	
	pScheduler->inProcess = FALSE; 
	pScheduler->m_bTimerFired = FALSE; 
	pScheduler->LowPartTime = 0; 
	pScheduler->HighPartTime = 0;
	pScheduler->lSchedulerEx = 0;
}

DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler)
{
	return pScheduler->scanPeriod; 
}
void Scheduler_setModbus(BOOL bOn)
{
	bModbusMaster = bOn;
}
