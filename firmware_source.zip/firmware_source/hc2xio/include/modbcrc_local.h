/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
#ifndef __MODBCRC_LOCAL_H__
#define __MODBCRC_LOCAL_H__

#include "typedefdefine.h"

BOOL ModbCRC_checkCRC(PUCHAR pMsg, UINT msgLen);
void ModbCRC_calcCRC(PUCHAR pMsg, UINT msgLen, PUCHAR retCRChi, PUCHAR retCRClo);


#endif
