/* ad5526.inc
 *
 * symbol definitions for A/D converter CS5526	*/

/* command register	*/
#define	CB				0x80		/* command bit	*/
#define	SC				0x40		/* single conversion	*/
#define	CC				0x20		/* continuous conversion	*/
#define	RW				0x10		/* 1 = read, 0 = write to/from selected reg	*/
#define	REG_MASK		0x0e		/* register select bits mask	*/
#define	PSR				0x01		/* 1 = power save, 0 = run	*/

/* register select bits defined (even #'s from 0 to 0e)	*/
#define	OFFSET			0
#define	GAIN			2
#define	CONFIG			4
#define	CONVDR			6		/* conversion data register (read only)	*/
#define	SETUP			8		/* set-up reg's (offset, gan, config)	*/

/* configuration register	*/
#define	LOGICBITMASK	0xf00000l	/* mask for D3-0 output pins	*/
#define	LOGCBIT3		0x800000	/* D3 output pin	*/
#define	LOGCBIT2		0x400000	/* D2 output pin	*/
#define	LOGCBIT1		0x200000	/* D1 output pin	*/
#define	LOGCBIT0		0x100000	/* D0 output pin	*/
#define	LOGCBITS2_0		(LOGCBIT2 | LOGCBIT1 | LOGCBIT0)
#define	WORD_MSK		0x0e000
#define	WR_15HZ			0x00		/* 15.02Hz conversion rate - default	*/
#define	WR_30HZ			0x2000	/* 30.06Hz	*/
#define	WR_60HZ			0x4000	/* 60.01Hz	*/
#define	WR_123HZ		0x6000	/* 123.18Hz	*/
#define	WR_169HZ		0x8000	/* 168.9Hz	*/
#define	WR_202HZ		0x0b000	/* 202.27Hz	*/
#define	WR_4HZ			0x0c000	/* 3.76Hz	*/
#define	WR_7_5HZ		0x0e000	/* 7.51Hz	*/
#define	U_B				0x1000	/* 1 = unipolar, 0 = bipolar	*/
#define	UNIPOLAR		U_B		/* unipolar signal input range	*/
#define	BIPOLAR			0		/* bipolar signal input range	*/
#define	GAIN_MASK		0x0e00	/* mask for gain bits	*/
#define	GAIN2_5V		0x0a00	/* internal gain calibration	*/
#define	GAIN5V			0x800	/* gain = 5V	*/
#define	GAIN1V			0x600	/* gain = 1V	*/
#define	GAIN25mV		0x400	/* gain = 25mV	*/
#define	GAIN55mV		0x200	/* gain = 55mV	*/
#define	GAIN100mV		0		/* gain = 100mV	*/
#define	PD				0x100	/* 1 = charge pump disabled, 0 = enabled	*/
#define	RS				0x80	/* 1 = reset, 0 = normal operation	*/
#define	RV				0x40	/* 1 = valid reset occured, 0 = no reset or bit was cleared	*/
#define	PF				0x20	/* 1 = Port Flag mode, 0 = mode inactive	*/
#define	DF				0x8		/* 1 = cal or conv complete, 0 = flag bit cleared	*/
#define	CC_MASK			7		/* cal control bits mask	*/
#define	CC_GAIN_SYS		6		/* Gain - system calibration	*/
#define	CC_OFFST_SYS	5		/* Offset - system calibration	*/
#define	CC_OSCG			3		/* offset sel-cal then gain self-cal (GAINCAL must be set)	*/
#define	CC_GAIN_SELF	2		/* gain - self cal (GAIN2_5V must be set)	*/
#define	CC_OFFS_SEELF	1		/* offset - self cal	*/
#define	CC_NORML		0		/* normal opertion	*/

#define	TDMPORT			P9DR	/* tell which port it is	*/
#define	TDMSCK			5		/* SCK is bit 5 of Port 9	*/
#define	TDMSDO			2		/* Serial Data Out (from uC)	*/
#define	TDMSDI			8		/* Serial Data In (to uC)	*/

#define	CNVRT_FAIL		4		/* the converter did not complete	*/

#define	CONFIG_INIT		(ulong)(WR_15HZ | BIPOLAR | GAIN100mV | PF)
