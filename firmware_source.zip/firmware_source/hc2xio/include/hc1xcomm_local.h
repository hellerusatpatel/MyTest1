/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
// hc1xcomm.h
#ifndef __HC1XCOMM_LOCAL_H__
#define __HC1XCOMM_LOCAL_H__
#ifndef __HC1XCOMM_H__
#define __HC1XCOMM_H__

#include "typedefdefine.h"
#include "modbcrc.h"
#include "io_digitio.h"

//#define HC1X_DATA_COLLECTION 1

#define READ_COILS_FUNCTION			0x01
#define READ_DIGITAL_IN_FUNCTION    0x02
#define READ_ANALOG_OUT_FUNCTION	0x03
#define READ_ANALOG_IN_FUNCTION		0x04
#define WRITE_DIGITAL_OUT_FUNCTION	0x0f
#define WRITE_ANALOG_OUT_FUNCTION	0X10

#define RBR 0		// receive buffer
#define THR 0		// transmit hold register
#define DLL 0		// divisor latch least significant byte
#define DLM 1		// divisor latch most significant byte
#define IER 1		// interrupt enable register
#define FCR 2		// FIFO control register
#define IIR 2		// interrupt id register
#define LCR 3		// line control register
#define MCR 4		// modem control register
#define LSR 5		// line status register
#define MSR 6		// modem status register
#define SCR 7		// scratch pad register

#define MAX_MESSAGE_LENGTH			256

//******************************************************************************
// 	class QueryRespose
//
// 	Abstract:
//  For holding the query message and its' corresponding response. As an
//	abstraction of this class a query message can also include the setting
// 	of registers and coils. This is consistent with the modbus protocol which
//	results in the generation of dynamic messages.
//
// 	Programmer:	Steven Young
//	Date: 04/20/1998
//
//******************************************************************************
typedef struct _QueryResponse_
{
	char	name[MaxNameLength+1];
	UCHAR 	queryMessage[MAX_MESSAGE_LENGTH];
	char	rBuffer[MaxNameLength+1];
	UCHAR 	responseMessage[MAX_MESSAGE_LENGTH];
	DWORD	queryMessLength;
	UINT	respMessLength;
	UINT    charOffset;
	BOOL    messageOk;
	BOOL	dataReady;
	BOOL	exceptionAllowed;
} QueryResponse;

void QueryResponse_init(QueryResponse* pQueryResponse, char* szName);

BOOL QueryResponse_isMessageValid(QueryResponse* pQueryResponse);
BOOL QueryResponse_headerCompare( QueryResponse* pQueryResponse, UINT startPos, UINT byteCount );


//******************************************************************************
// 	class Hc1xComm
//
//  Abstract:
//  To communicate to the HC1X IO module from Analogic. This module is designed
// 	to specification 91G-00574 Rev A - March 10, 1998.
//
//	Programmer: Steven Young
//	Date:	04/20/1998
//******************************************************************************
enum 	Parity { None=0, Odd=1, Even=2 };


enum	{	READ_COILS_MESSAGE = 0, 	
			READ_DIGITAL_IN_MESSAGE, 	
			READ_ANALOG_OUT_MESSAGE,		
			READ_ANALOG_IN_MESSAGE,		
			READ_ENCODERS_MESSAGE,		
			WRITE_DIGITAL_OUT_MESSAGE,	
			WRITE_ANALOG_OUT_MESSAGE,	
			NO_OF_QUERY_MESSAGES 
		};

enum 	{ MaxQueryMessages = (NO_OF_QUERY_MESSAGES + 1) };

typedef struct _Hc1xComm_
{
	QueryResponse *pQueryResponse;
	char  name[MaxNameLength+1];

	QueryResponse qr[MaxQueryMessages];				// digital and analog in, digital and analog out.
	BOOL		*pInProcess;
	DWORD		messagesSent;
	DWORD		goodReplies;
	DWORD		messageErrorCount;	
	BOOL		m_sendInProgress;
	BOOL		m_bModbusMaster;

} Hc1xComm;

void Hc1xComm_init(	Hc1xComm* pHc1xComm, const char *szName);

void Hc1xComm_errorCountInc( Hc1xComm* pHc1xComm );
BOOL Hc1xComm_addMessage(Hc1xComm* pHc1xComm, UCHAR messageNo, UCHAR slaveAddress, DWORD startAddress, DWORD noOfPoints);
//const char * const Hc1xComm_getName  ( void ){ return name.getName(); }
void Hc1xComm_resetCommStats(Hc1xComm* pHc1xComm );
void Hc1xComm_sendMessage(Hc1xComm* pHc1xComm, UCHAR messageNo /*= 0*/, BOOL* pProcessState /*= NULL*/);	// set inProcess to FALSE when complete.
QueryResponse * Hc1xComm_getQueryResponseBuffer(Hc1xComm* pHc1xComm, UINT messageId );
BOOL Hc1xComm_commIrqHandler(Hc1xComm* pHc1xComm);

#endif

//Externs
extern Hc1xComm    hc1xComm;
                                                                                
extern IODIN		digitalInDb;
extern IODOUT		digitalOutDb;
extern IOANALOGIN	analogInDb;
extern IOANALOGOUT	analogOutDb;


#endif

