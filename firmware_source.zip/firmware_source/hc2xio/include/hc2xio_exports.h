#ifndef HC2XIO_EXPORTS_H
#define HC2XIO_EXPORTS_H

#include "io_digitio.h"

struct HC2X_IP
{
	unsigned char a;
	unsigned char b;
	unsigned char c;
	unsigned char d;
	unsigned char mac[6];
};

extern struct HC2X_IP hc2xip_addr;

//Global Exported Functions
IODIN *getIODIN( void );
IODOUT *getIODOUT( void );
IOANALOGIN *getIOANALOGIN( void );
IOANALOGOUT *getIOANALOGOUT( void );
void TPO_AddSafeSegment(unsigned int channel, unsigned int weight);
void Scheduler_setModbus(BOOL bOn);
void TPO_testPath(unsigned int iWhichTest, int iTest);

#endif
