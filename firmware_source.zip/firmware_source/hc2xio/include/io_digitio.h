/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//digitio.H
#ifndef __IODIGITIO_H__
#define __IODIGITIO_H__

#include "typedefdefine.h"
#define IOHISTLENGTH 400

#define MaxDin		MAX_DIGITAL_INPUTS
#define MaxDout		MAX_DIGITAL_OUTPUTS
#define MaxAnalogIn  MAX_ANALOG_INPUTS
#define MaxAnalogOut MAX_ANALOG_OUTPUTS


//******************************************************************************
// 									IODIN
//******************************************************************************
typedef struct _IODIN_
{
	char name[MaxNameLength+1];
	BOOL dinputs[MaxDin];
	BOOL dummy;   			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	UCHAR inBuffer[IOHISTLENGTH];//8 characters, 50 long, 5 seconds worth
	UINT iBuffPoint;
	int iTest;
} IODIN;

UCHAR IODIN_BufferGet(IODIN* pDin, UINT index);
UINT IODIN_GetBuffPoint(IODIN* pDin);
void IODIN_init(IODIN* pDin, const char* szDbName);
BOOL* IODIN_GetAt(IODIN* pDin, unsigned int);
const char* IODIN_getName(IODIN* pDin);
void IODIN_process(IODIN* pDin);


//******************************************************************************
// 									IODOUT
//******************************************************************************
typedef struct _IODOUT_
{
	char name[MaxNameLength+1];
	
	BOOL doutputs[MaxDout];
	UCHAR dOutBits[7];   	// The 56 Digital outputs are represented in 7 bytes.
	BOOL dummy;   			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	BOOL bUpdated;
} IODOUT;

void IODOUT_init(IODOUT* pDout, const char *szDbName);
BOOL* IODOUT_GetAt(IODOUT* pDout, unsigned int);
const char* IODOUT_getName(IODOUT* pDout);
void IODOUT_getOutputArray(IODOUT* pDout, UCHAR **ppDigitalOut, UCHAR *pSize );
void IODOUT_process(IODOUT* pDout);


//******************************************************************************
// 									IOANALOGIN
//******************************************************************************
typedef struct _IOANALOGIN_
{
	char name[MaxNameLength+1];

	WORD	 analogInputs[MaxAnalogIn*2];  //Double set for serial controlled board

	//Adjustment for profile channels with plug in
	WORD	 profileOffset; 
	WORD	 dummy;			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	int recordOffsets;
	int recordMem0;
	int recordMem1;
	int startOffsetProgramming;

	WORD offsets[MaxAnalogIn];
	int inputStyles[MaxAnalogIn];
	int recordInputStyles[MaxAnalogIn];
	int iNoSlaveDataCount;
	int iSlaveDataTimeout;
	int m_bAlarmed;
	int miAlarmScanner;
	unsigned int EEpromMap[128][2];
} IOANALOGIN;

void IOANALOGIN_init(IOANALOGIN* pAin, const char *szDbName);
WORD* IOANALOGIN_GetAt(IOANALOGIN* pAin, unsigned int);
WORD* IOANALOGIN_GetAtHigh(IOANALOGIN* p, unsigned int index);
void IOANALOGIN_setProfileOffset(IOANALOGIN* pIn, WORD newProfileOffset);
WORD IOANALOGIN_ReadProfileOffset(IOANALOGIN* pIn);
const char* IOANALOGIN_getName(IOANALOGIN* pIn);
void IOANALOGIN_process(IOANALOGIN* pIn);
WORD IOANALOGIN_GetOffsetAt(IOANALOGIN* pIn, UINT index);
BOOL IOANALOGIN_SetOffsetAt(IOANALOGIN* pIn, UINT index, WORD offsetValue);		
DWORD IOANALOGIN_GetInputStyleAt(IOANALOGIN* pIn, UINT index);
BOOL IOANALOGIN_SetInputStyleAt(IOANALOGIN* pIn, UINT index, UINT iType);

void IOANALOGIN_encoderReader(IOANALOGIN* pANALOGIN);


//******************************************************************************
// 									IOANALOGOUT
//******************************************************************************
typedef struct _IOANALOGOUT_
{
	char name[MaxNameLength+1];

	WORD analogOutputs[MaxAnalogOut];
	WORD dummy;				// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.

	BOOL m_bOwned[MaxAnalogOut]; //for shared outputs(second fluxheater
	BOOL bUpdated;
} IOANALOGOUT;

void IOANALOGOUT_init(IOANALOGOUT* pAout, const char *szDbName);
WORD* IOANALOGOUT_GetAt(IOANALOGOUT* pAOut, unsigned int);
const char* IOANALOGOUT_getName(IOANALOGOUT* pAout );
void IOANALOGOUT_process(IOANALOGOUT* pAout);
void IOANALOGOUT_set(IOANALOGOUT* pAout, UINT index, WORD wValue);
WORD IOANALOGOUT_get(IOANALOGOUT* pAout, UINT index);
void IOANALOGOUT_testMPath(UINT iPath, int iTest);
void IOANALOGOUT_setOwned(IOANALOGOUT * pAout, UINT iIndex);
void IOANALOGOUT_setFree(IOANALOGOUT * pAout, UINT iIndex);
DWORD IOANALOGIN_GetMem(IOANALOGIN* pIn, UINT index, UINT tdm);
void IOANALOGIN_ProgramTDM(IOANALOGIN* pIn, UINT index);

#endif
