/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#define EE_DATA_SIZE	100 //IP(4) + TEMPOFFSET(32 * 2) + TDMTYPE(32) 
#define IP_SIZE 4
#define TDM_TYPE_SIZE 32
#define TEMP_OFFSET_SIZE 64
#define MAC_ADDR_OFFSET	4
#define CONFIG_SIZE	EE_DATA_SIZE + 4

#define TESTBYTE1		CONFIG_SIZE - 4
#define TESTBYTE2		CONFIG_SIZE - 3
#define CRCHBYTE		CONFIG_SIZE - 2
#define CRCLBYTE		CONFIG_SIZE - 1

#define CHECKBYTE1	0x55
#define CHECKBYTE2	0xAA

void SystemInit( void );

#endif
