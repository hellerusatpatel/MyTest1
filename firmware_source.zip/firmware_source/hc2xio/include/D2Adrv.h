/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __D2ADRV_H__
#define __D2ADRV_H__

#define D2A_COUNT			8
#define D2A_START_REF	D2A_COUNT

#define D2A_DATA_MASK	0x00000FF0
#define D2A_DATA_SHIFT	0x00000004

#define D2A_A0				0x00000000 //channels 0 & 4
#define D2A_A1				0x00004000 //channels 1 & 5
#define D2A_A2				0x00008000 //channels 2 & 6
#define D2A_A3				0x0000C000 //channels 3 & 7

unsigned int D2A_ChannelDirty[D2A_COUNT];

void D2A_update( void );
void D2A_SetChannel(unsigned int channel, unsigned int value);

#endif
