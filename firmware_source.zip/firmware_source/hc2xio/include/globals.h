/******************************
 *
 *	globals.h
 *
 *	contains externs declares for variables in globals.c
 *
 *****************************/
#ifndef __GLOBALDEFS_H__
#define __GLOBALDEFS_H__
#include	"project.h"
#include	"MODBus.h"
#include	"confcal.h"

typedef	struct
{
	unsigned char	BYTE3;
	unsigned char	BYTE2;
	unsigned char	BYTE1;
	unsigned char	BYTE0;
}	LONGBYTES;
typedef	struct
{
	unsigned int	HI_WORD;
	unsigned int	LO_WORD;
}	ULONGINT;
typedef	struct
{
	int				HI_WORD;
	unsigned int	LO_WORD;
}	LONGINT;
typedef	union
{
	unsigned long	ULONG;
	ULONGINT	WORD;
	LONGBYTES	BYTE;
//	LONGNIBBLE	NIBBLE;
}	ULONG_UNION;



typedef struct
{
	unsigned long	config;		/* the word to write to A/D's config register	*/
	unsigned char	which;		/* which TDM to do, TDM0 or TDM 1	*/
	unsigned char	cmnd;		/* = GAIN or OFFSET	*/
	unsigned char	PROM_offset;	/* the offset to store the new value	*/
}	CAL_CONFIG;
typedef	union
{
	unsigned int	FLASH_CODE;
	struct
	{
		unsigned char	MANUFACTR;
		unsigned char	DEVICE;
	} 	FL_STRUC;
}	FLASH_ID;
struct	TH_STRC	
{
	double	temp;	/* this is the temperature	*/
	int		error;	/* overflow or underflow flags	*/
} ;

typedef	struct
{
	ULONG_UNION	configreg;		/* a copy of the A/D's config */
	struct ChannelDataStruct Channel[NUMBER_A2D_INPUTS];
	struct ChannelStruct channels[NUMBER_A2D_INPUTS];
	struct	TH_STRC		thrmstr[2];		/* thermister values	*/
		/* the calc'd temp @ each terminal block input */
	double		tblk_temp[TDM_TC_INPUTS];
	unsigned int		conv_errors;	/* number of conversions missed	*/
	unsigned char		chanl_nmbr;		/* what channel is being done	*/
   unsigned char    mux_ptr;    /* pointer into next_addr array  */
   unsigned char    mux_address;   /* what the mux address is    */
   unsigned char    conv_chanl;    /* the present conversion's channel */
   unsigned char    data_ptr;      /* pointer to last conversion data processed*/
   unsigned char    resetvalid;    /* indicates if a valid reset occured  */
   unsigned char    conv_done;     /* result of conversion_done()   */
   unsigned char    conv_cnt;      /* counts # of convert done attempts   */		
	int		setup_valid;	/* TRUE if the setup was successful		*/
}	TDM_STRUCT;
   unsigned char    chanl_nmbr;    /* what channel is being done */


typedef	struct
{
	unsigned char	manufactur;
	unsigned char	device;
}	FLASH_STRUCT;
struct	compr	
{
	unsigned int	start;		/* start address to read or write to	*/
	unsigned int	length; 	/* length of read or write	*/
	unsigned int	dest_bgn;	/* start of compare section address	*/
	unsigned int	dest_siz;	/* size of compare section, all buffers start at 0 */
	unsigned int	src_bgn;	/* where it starts in the source buffer	*/
	unsigned int	begin;		/* valid destination start address of xfer	*/
	unsigned int	end;		/* last valid destination address of xfer */
} ;


extern	ULONG_UNION	ad_reg;		/* a value to read/write with the A/D	*/
extern	struct	compr	addr;	/* struct of buffer rd/wr limits	*/
//extern  const unsigned int_UNION	bitposn[16];/* array to get the bit position	*/
extern	unsigned char		buffr[SECTOR_SIZE];	/* buffer to write to FLASH sector	*/
//extern	unsigned int_UNION	bytes_send;	/* the number of bytes in the response msg	*/
extern	unsigned int		bytes_rec;		/* counts number of bytes received	*/
	/* the mux channel sequence of converting	*/
extern	const unsigned char	chanl_seq[NUMBER_CHNL_SEQ];
extern	unsigned char		coil[NUMBER_COILS];	/* all the MODBus "coils" type	*/
	/* Comm Loss coil values (in vect.asm)	*/
extern	unsigned char		coilCL[NUMBER_COILS];
	/* Comm Loss coil values (in vect.asm)	*/
extern	unsigned char		coilCLH[NUMBER_COILS];
	/* coil Power Up defaults (in vect.asm)	*/
extern	unsigned char		coilPU[NUMBER_COILS];
extern	unsigned char		comm_estbl;		/* set TRUE after comm is established	*/
extern	unsigned int		comm_time;	/* time of last byte recvd (in 10mseconds)	*/
	/* configuration reg values (in vect.asm)	*/
//extern	unsigned int_UNION	config_reg[NUMBER_CONFIG_REG];
#ifndef	SILENTIMER
 extern	unsigned char		chara_recd;		/* we have rec'd a new character	*/
 extern	unsigned int		chara_time;		/* time stamp for rec'd chara's	*/
#endif

extern	unsigned char		crc_posn;		/* where the CRC starts in MODbus msg	*/

extern	float		delta;			/* used to make TPO tables	*/
//extern	unsigned int_UNION	diag[NUMBER_DIAGNOSTIC_REGS];/* diagnostic registers	*/
extern	struct ENCODR	encoder[NUMBER_ENCODERS];	/* encoder data	*/
extern	const unsigned char	encoder_seq[NUMBER_ENCODER_SEQ];
extern	FLASH_ID	fl_ID;	/* identifies the FLASH manufacturer & device	*/
extern	unsigned char    *  flash_addr;		/* start address in FLASH to store data	*/
extern	unsigned int		flash_wr_length;/* number of bytes to write to FLASH	*/
unsigned int	input_reg[NUMBER_INP_REG];	/* input registers	*/
extern	unsigned int		int_spaces;		/* (unsigned int) value of spaces for TPO table	*/
extern	float		interval;		/* pulse interval to make TPO tables	*/
extern	unsigned int		itemp;		/* scratch pad unsigned int */
extern	unsigned int		ITU0_time;	/* ITU0 interrupt timer value	*/
extern	unsigned int		msec500;	/* 500msec time counter for speed time base	*/
//extern	PTR_UNION	mem_ptr;	/* pointer for writing to FLASH	*/
extern	unsigned char		msg_error;	/* receive error definition	*/
//extern	MSG_UNION	msg_in;		/* receive buffer	*/
//extern	MSG_UNION	msg_out;	/* transmisson buffer	*/
extern	unsigned char		mux0_addr, mux1_addr;
extern	const double mV_divsr[NUMBER_GAINS];/* divisor to convert to mvolts	*/
extern	unsigned int		one_sec;	/* counts 1 second ticks for speed time base*/
extern	unsigned int		out_ptr;	/* index for data in msg's to host	*/
extern	float		posn;		/* position of TPO pulse	*/
extern	struct	compr	proc;	/* struct of process rd/wr limits	*/
	/* returns the A/D input voltage range from gain*/
//const double	range[NUMBER_GAINS];
extern	struct	compr	read;	/* struct of read regs rd limits	*/
extern	struct crc_calc	rec_crc;	/* rec CRC structure	*/
extern	unsigned int		rec_time;	/* time of last chara rec'd, if non-zero	*/
extern	unsigned char		recvr_error;	/* SCI receiver flags	*/
extern	unsigned char		send_ptr;		/* points to send chara		*/
extern	unsigned char		send_time;		/* keeps time for sending messages	*/
extern	struct crc_calc	send_crc;	/* send CRC structure	*/
extern	unsigned int		spaces;			/* used to make TPO tables	*/
extern	unsigned int		speed[NUMBER_ENCODERS];	/* speed values for encoders	*/
/*extern*/	unsigned int		sum;		/* used to calc eeprom checksum	*/
extern	unsigned char		temp;		/* scratch pad	*/ 
extern  unsigned char		tempjoecount;
extern  unsigned char 		tempjoe;  
extern 	unsigned char		PortFour;
double		temp_grad;	/* temp gradient along terminal block	*/
extern	unsigned char		TPO[NUMBER_TPO_REGS][TPO_LENGTH];
extern	unsigned char		tpo_flag;	/* TRUE if TPO's to process	*/
extern	unsigned int		tpo_new[TPO_SIZE];	/* list of new TPO	*/
extern	unsigned char		tpo_ptr;	/* Time Proportioinal Output array pointer	*/
extern	unsigned int		two_sec;	/* counts 2 second ticks for speed time base*/
extern	unsigned char		xmit_done;	/* DMA serial 0 xmit transfer is completed	*/

#define OD_ERROR 2 //ERROR BITS ON AN AD CONVERSION
#define OF_ERROR 1


#endif
