/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef ENCODER_H
#define ENCODER_H

void initialize_encoder( void );
void release_encoder( void );
void encoder_handler( int irq, void *dev_id, struct pt_regs *regs );

#define ENCODER_CNT		4

//Encoder Bit locations

#define ENCODER_BASE			0x1
#define ENCODER2_BASE		0x100
#define ENCODER_PHASE_A		1
#define ENCODER_PHASE_B		2
#define ENCODER_LENGTH		3

#define ENCODER0_Z		0x0004 //Interrupt Mask for GPIO06 (portA)
#define ENCODER0_A		0x0040 //GPIO01 (portA)
#define ENCODER0_B		0x0002 //GPIO02 (portA)
#define ENCODER1_Z		0x0020 //Interrupt Mask for GPIO05 (portA)
#define ENCODER1_A		0x0008 //GPIO03 (portA)
#define ENCODER1_B		0x0010 //GPIO04 (portA)
#define ENCODER2_Z		0x0400 //Interrupt Mask for GPIO10
#define ENCODER2_Z_TEST	0x0004 //Test Interrupt Mask for GPIO10
#define ENCODER2_A		0x0001 //GPIO08 (portB)
#define ENCODER2_B		0x0002 //GPIO09 (portB)
#define ENCODER3_Z		0x2000 //Interrupt Mask for GPIO13
#define ENCODER3_Z_TEST	0x0020 //Interrupt Mask for GPIO13
#define ENCODER3_A		0x0008 //GPIO11 (portB)
#define ENCODER3_B		0x0010 //GPIO12 (portB)

#define DEBUG_PORT_PIN	0x0040 // JP6 pin 1

#define ENCDR_DIR_MASK		0x10

//External Global Variables
extern unsigned int nEncoderDir[ENCODER_CNT];
extern long nEncoderPosn[ENCODER_CNT];
extern unsigned int speed[ENCODER_CNT];

#endif
