/***************************************************************************
    Heller, Inc.
    imagic, Inc.    Copyright (C) 1997 - 2004, All Rights Reserved
                    Company Confidential
                                                                                
                                                                                
   File:         hc2xspi.h
                                                                                
   Description:   This is a header file that defines memory access tools.
                                                                                
   Modifications :   Version  Author   Date  Description
                                                                                
   `           A     jmr      09/23/04  Initial pre-release
                                                                                
    This is a trade secret of imagic, inc. and Heller, Inc
    and is protected by copyright. All unauthorized uses prohibited.
***************************************************************************/
#ifndef __HC2XSPI_H__
#define __HC2XSPI_H__

#define SPI_ENABLE		0x00000020
#define SPI_DISABLE		0x00000000

#define SPI_8BIT			0x00000107
#define SPI_16BIT			0x0000010F

#define SPI_CLKDEV		0x00000002

//Status Bit Masks
#define SPI_BSY			0x00000010
#define SPI_RFF			0x00000008
#define SPI_RNE			0x00000004
#define SPI_TNF			0x00000002
#define SPI_TFE			0x00000001

void SetSPIEightBit(void);
void SetSPISixteenBit(void);
void SetSPIDevice(unsigned long nDevice);
int WriteSPI(unsigned int txbuffer);
unsigned int ReadSPI(void);

#endif
