/**************************************************************************
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
    Heller Industries         Company Confidential    
                    

	File:	        SPIdrv.c

	Description:	
					This file contains EP9301 routines to initialize, read and write 
					the SPI interfaces as used by the A2D, D2A and EEPROMS
					device driver. 
					
	Modifications :	Version	Author	Date		Description
	`				A		jwf		10/24/04	Initial pre-release
	
			         
    This is a trade secret of imagic, inc. and Heller Industries   
    and is protected by copyright. All unauthorized uses prohibited.
********************************************************************/
#ifndef __SPIDRV_H__
#define __SPIDRV_H__
void InitSPI(char NoBits, unsigned short clkMask);
void WriteSPI(unsigned short txbuffer);
unsigned short ReadSPI(void);
void SPIWaitTxBusy( void );
void SPIWaitTxNotFull( void );
void EmptyRXFIFO( void );
void SPIWriteCS(unsigned int cs_value);

#define SPICLK_11	0x00C0
#define SPICLK_00 0x0000
#define SPICLK_10 0x0080
#define SPICLK_01 0x0040

#endif
