#ifndef SERIAL_H
#define SERIAL_H

void initialize_uart( void );
void release_uart( void );
//void rx_handler( int irq, void *dev_id, struct pt_regs *regs );
//void tx_handler( int irq, void *dev_id, struct pt_regs *regs );
void rx_handler( void *unused );
void tx_handler( void *unused );
void rxt_bottom_half( void *unused );

//Defines
//#define UART2_CLK	7372800 //Hz (7.3728 MHz)
#define UART2_CLK	14745600 //Hz - from serial subsystem

extern char *g_inBuff;

#endif

