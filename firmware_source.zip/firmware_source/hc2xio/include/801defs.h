#ifndef __801DEFS_H__
#define __801DEFS_H__

/* Definitions */
#ifndef TRUE
	#define TRUE 1
	#define FALSE 0
#endif

#define TCBREAKVALUE			2000.0 /* return value for TC break detect */
#define CJCREFERENCE			2.495	/* cjc reference voltage */
#define BREAKVOLTAGE			-15.0     /* -15 mV */
/* input voltage and thermocouple types */
#define V10			0                   /* 0 to 10 Volt */
//#define V5			1                   /* 0 to 5 Volt */
//#define mV100		2                   /* -100 to +100 mV */ 
#define mV71        3                   /* -71 to +71 mV */
#define Btype       4                   /* B thermocouple */
#define Etype       5                   /* E thermocouple */
#define Jtype       6                   /* J thermocouple */
#define Ktype       7                   /* K thermocouple */
#define Ntype       8                   /* N thermocouple */
#define Rtype       9                   /* R thermocouple */
#define Stype       10                  /* S thermocouple */
#define Ttype       11                  /* T thermocouple */
#define Ctype       12                  /* C thermocouple */
#define Dtype       13                  /* D thermocouple */    

#define CJC_INDEX		MAX_CHANNEL_CNT

#endif
