#ifndef __A2DCDEFS_H__
#define __A2DCDEFS_H__

/* input voltage and thermocouple types */ 


#define R0		100.00   
#define A 		3.9083E-3
#define B		-5.5775E-7

#define ST_CONV		0x00C0	/* perform a single conversion */ 
#define WR_CONFG	0x0084	/* write the configuration register */
#define RD_CONV		0x0096	/* read the conversion */ 
#define WR_OFFSET   0x0080
#define WR_GAIN		0x0082
#define RD_CONFG	0x0094
#define CJC_CHANNEL 16
#define CJC2_CHANNEL 17

#define A2DCONFIG_HI		0x0004
//#define A2DCONFIG_MID	0x0040 
#define A2DCONFIG_MID	0x0000 //15 hz mode
#define A2DCONFIG_LOW	0x0000


/* Definitions */
#ifndef TRUE
	#define TRUE 1
	#define FALSE 0
#endif
unsigned int A2DCRead( struct ChannelDataStruct* ChannelData, unsigned int channel );
void StartAtoD( unsigned int nTDMno );

#define TCBREAKVALUE			2000.0 /* return value for TC break detect */
#define CJCREFERENCE			2.495	/* cjc reference voltage */
#define BREAKVOLTAGE			-15.0     /* -15 mV */
/* input voltage and thermocouple types */
//#define V10			0                   /* 0 to 10 Volt */
//#define V5			1                   /* 0 to 5 Volt */
//#define mV100		2                   /* -100 to +100 mV */ 
//#define mV71        3                   /* -71 to +71 mV */
//#define Btype       4                   /* B thermocouple */
//#define Etype       5                   /* E thermocouple */
//#define Jtype       6                   /* J thermocouple */
//#define Ktype       7                   /* K thermocouple */
//#define Ntype       8                   /* N thermocouple */
//#define Rtype       9                   /* R thermocouple */
//#define Stype       10                  /* S thermocouple */
//#define Ttype       11                  /* T thermocouple */
//#define Ctype       12                  /* C thermocouple */
//#define Dtype       13                  /* D thermocouple */    
extern unsigned int nDiagLine;
void A2DinitChannelStructs(  );
void A2DCSelectAddress( unsigned int address);
int A2DCConfig( int iA2D );

#define R_55MV 1
#define R_5V   4
#define R_2_5V 5
//Location of slope and offset data in eeprom
#define EEPROM_CHAN0 0x3
#define EEPROM_CHAN1 0xB
#define EEPROM_CHAN2 0x15
#define EEPROM_CHAN3 0x1B
#define EEPROM_CHAN4 0x21
#define EEPROM_CHAN5 0x27
#define EEPROM_CHAN6 0x2D
#define EEPROM_CHAN7 0x33
#define EEPROM_CHAN8 0x39
#define EEPROM_CHAN9 0x3F
#define EEPROM_CHAN10 0x45
#define EEPROM_CHAN11 0x4B
#define EEPROM_CHAN12 0x51
#define EEPROM_CHAN13 0x57
#define EEPROM_CHAN14 0x5D
#define EEPROM_CHAN15 0x66
#define EEPROM_CHAN16 0x6C
#define EEPROM_CHAN17 0x6F
#define EEPROM_CHAN18 0x72
#define EEPROM_CHAN19 0x75


#endif
