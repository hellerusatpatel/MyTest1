/**************************************************************************
    Heller, Inc.
    imagic, Inc.    Copyright (C) 1997 - 2004, All Rights Reserved
                    Company Confidential
                                                                                
                                                                                
   File:         hc2xmem.h
                                                                                
   Description:   This is a header file that defines memory access tools.
                                                                                
   Modifications :   Version  Author   Date  Description
                                                                                
   `           A     jmr      09/17/04  Initial pre-release
                                                                                
    This is a trade secret of imagic, inc. and Heller, Inc
    and is protected by copyright. All unauthorized uses prohibited.
***************************************************************************/
#ifndef __HC2XMEM_H__
#define __HC2XMEM_H__

//Memory location of CS1
#define CS0_MEM_BASE		0xf0000000
//Memory Offsets that select CS1
//Used to reference the io buffer to write outputs, 0 based
//#define DIOW1	0x00 //| CS0_MEM_BASE
#define DIR1	0x00 //| CS0_MEM_BASE
#define DOW2	0x01 //| CS0_MEM_BASE
//#define DIOR2	0x01 //| CS0_MEM_BASE
//#define DIOW3	0x02 //| CS0_MEM_BASE
#define DIR3	0x02 //| CS0_MEM_BASE
#define DOW4	0x03 //| CS0_MEM_BASE
//#define DIOR4	0x03 //| CS0_MEM_BASE
//#define DIOW5	0x04 //| CS0_MEM_BASE
#define DIR5	0x04 //| CS0_MEM_BASE
#define DOW6	0x05 //| CS0_MEM_BASE
//#define DIOR6	0x05 //| CS0_MEM_BASE
#define DOW24V	0x06 //| CS0_MEM_BASE
//#define DOR24V	0x06 //| CS0_MEM_BASE
#define DIR24V	0x07 //| CS0_MEM_BASE
#define TPO1	0x07 //| CS0_MEM_BASE
#define TPO2	0x08 //| CS0_MEM_BASE
#define TPO3	0x09 //| CS0_MEM_BASE
#define TPO4	0x0A //| CS0_MEM_BASE
#define SPICS	0x0B //| CS0_MEM_BASE*/

void * ptrDIOW1;
void * ptrDIOW2;
void * ptrDIOW3;
void * ptrDIOW4;
void * ptrDIOW5;
void * ptrDIOW6;
void * ptrDIOR1;
void * ptrDIOR2;
void * ptrDIOR3;
void * ptrDIOR4;
void * ptrDIOR5;
void * ptrDIOR6;
void * ptrDOW24V;
void * ptrDOR24V;
void * ptrDIR24V;
void * ptrTPO1;
void * ptrTPO2;
void * ptrTPO3;
void * ptrTPO4;
void * ptrSPICS;

//SPI Chip Select Masks
#define SPICS_CLEAR	0x000000BB // Deselects all CS
#define SPICS_EECS0	0x000000BA // EEPROM on TDM0
#define SPICS_CSAD0	0x000000B9 // A/D on TDM0
#define SPICS_DIAG0	0x00000004 // DIAG Mux on TDM0
#define SPICS_DACS0	0x000000B3 // D/A chan 0 - 3
#define SPICS_EECS1	0x000000AB // EEPROM on TDM1
#define SPICS_CSAD1	0x0000009B // A/D on TDM1
#define SPICS_DIAG1	0x00000040 // DIAG Mux on TDM1
#define SPICS_DACS1	0x0000003B // D/A chan 4 - 7
#define SPICS_NODIAG	0x00000000 //No Diag Lines will be set

#endif
