/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
#ifndef __SCHEDULER_LOCAL_H__
#define __SCHEDULER_LOCAL_H__
#ifndef __SCHEDULER_H__
#define __SCHEDULER_H__

#include "typedefdefine.h"

#define OVERRUN	   2
#define LOSSOFCOMM 3
unsigned int bSkipIOTickle;
unsigned int bSkipTDMTickle;
unsigned bModbusMaster;
typedef struct _Scheduler_
{
//private:
	// The statics are required because they are used in an interrupt handler at which
	// time there is no definitive object.

	DWORD	        sequenceNo;
	DWORD				timerCount;
	DWORD				scanPeriod;		// set to 10Hz or 100ms
	BOOL				inProcess;
	DWORD				elapsedTempZoneTime; 
	DWORD				lossOfComm;
	DWORD				commError;
	BOOL				upDateTPOs;	
	LONG				elapsedMillisecs;
	LONG				AnalogInTicks;

	DWORD				LowPartTime; 
	LONG				HighPartTime;

	BOOL				m_bTimerFired;
	LONG				lSchedulerEx;

	DWORD				goodCOMM;
	DWORD				consecutiveNoReadScans;
	int					m_iSchedulerCase;

} Scheduler;

BOOL Scheduler_getCommLoss(Scheduler* pScheduler);
void Scheduler_init(Scheduler* pScheduler);

void Scheduler_reset( Scheduler* pScheduler ); 	
void Scheduler_updateEncoders();
void	Scheduler_sequencer(Scheduler* pScheduler);//, KIoRegister ioreg);
void	Scheduler_A2Dsequencer(Scheduler* pScheduler);//, KIoRegister ioreg);
void	Scheduler_monitor_sequencer(Scheduler* pScheduler);//, KIoRegister ioreg);
void	Scheduler_setContainerAddress(Scheduler* pScheduler);
void	Scheduler_resetCommError(Scheduler* pScheduler);
DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler);
#endif

void initialize_timer( void );

//Externs
extern Scheduler scheduler;

#endif
