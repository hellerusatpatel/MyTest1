int FlashTimer;   

unsigned int CurrentChannel;  
//float BreakVoltage; 
//float Temperature, CJCVoltage;   
unsigned int bTempError;

//float CJCTemperature, TCVoltage, CJCOffsetVoltage, CJCSensorRaw;
//float TemperatureVal, InVoltage;
int ChannelType;  

float CJCDegC[10]= {-10.0, 0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0,
					 70.0, 80.0};	   
float RNi1500[10]= {1310.5, 1372.5, 1435.2, 1500.0, 1566.5, 1634.7, 1704.5, 
					1776.0, 1849.2, 1924.0};	   

