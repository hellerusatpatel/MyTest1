/****************************************************************
 *
 *	project.h
 *	
 *	Modification History:
 *	050498	Initial vision
 *			Gerry Riley
 *	081098	Enable to write to Flash memory.
 *			Peter Zhu
 *	082698	Enable Internal WatchDog timer.
 *			Peter Zhu
 *	090398	Define external WatchDog.
 *			Peter Zhu
 *
 ****************************************************************/

//#include	"h8regs.h"

#define	uint	unsigned int
#define	uchar	unsigned char
#define	ulong	unsigned long

/* Enable to write to Flash memory */
#define ENA_FLASH_WR
/* 081098 pz */

/* Enable WatchDog timer */
/*#define ENA_WD_TIMER */
/* 082698 pz */ 
/* comment out ENA_WD_TIMER since using external WatchDog 090398 pz */

/* defines for macros	*/
#define	DIAG0		0x10
#define	DIAG1		0x20
#define	AD0SEL		0x40
#define	AD1SEL		0x80
#define	PROM0SEL	4
#define	PROM1SEL	2
#define	ADCSELPORT	PBDR
#define	PROMSELPORT	P6DR
#define	UI			0x40
#define	I			0x80
/* Macros	*/
#define	Setbyte(A, X)	(*(uchar *)(A) = (X))
#define	Setword(A, X)	(*(uint *)(A) = (X))
#define	Setlong(A, X)	(*(ulong *)(A) = (X))
#define	Getbyte(A)		(*(uchar *)(A))
#define	Getword(A)		(*(uint *)(A))
#define	Getlong(A)		(*(ulong *)(A))
#define	Setbits(A, X)	(*(uchar *)(A) |= (X))
#define	Clrbits(A, X)	(*(uchar *)(A) &= (~X))
#define	Setbitn(A, X)	(*(uchar *)(A) |= (1 << (X & 0x07)))
#define	Clrbitn(A, X)	(*(uchar *)(A) &= (~(1 << (X & 0x07))))
#define	Getbitn(A, X)	((1 << (X & 0x07)) & (*(uchar *)A))
#define	DeselTDM		{ deselADC(); deselEEPROM(); }
#define	EnaINTpri1		and_ccr(~UI);
#define	EnaINTs			and_ccr(~I);
#define	Setflag			Setbitn(P6DR, 0);	/*JFD*/
#define	Clrflag			Clrbitn(P6DR, 0);
/*#define	Watchdog		Setword(TCNT, TCNT_PWORD); */ /* comment out 090398 pz */
#define	Watchdog		io_write(0, XWDOG);			/* define Watchdog to external 090398 pz */
						
//#define	B0	1
#define	B1	2
#define	B2	4
#define	B3	8

/* define the TDM's	*/
#define TDM0	0
#define TDM1	1
#define	NUMBER_OF_TDMS	2
#define	EEPROM0	0
#define	EEPROM1	1
#define	TDM_TC_INPUTS	16
#define	TDM_A2D_INPUTS	24
#define	NUMBER_A2D_INPUTS	20

#define	FALSE		0
#define	TRUE		~FALSE
#define UNDERVAL 	(TRUE - 1)
#define	TB_UNDERVAL	(TRUE - 2)
#define	CANT_DO		(TRUE - 3)
#define OVERVAL 	0x7fff
#define	CONVERT_ERR		0x7ffe
#define	CONVRTR_FAIL	0x7ffd
#define	TB_OVERVAL		0x7ffc
#define	A2D_SIGN_BIT	0x800000l
#define	FULLSCALE		0x7ffffl
#define	SCALE	0x10
#define	SECDIVIDR	100

#define	DOWN	0
#define	UP		1
#define	NEXT	255
#define	NUMBER_CHNL_SEQ	68
#define	NUMBER_GAINS	6

#define	TWO_exp20	(double)(1048576)
#define	TWO_exp23	(double)(8388608)
#define	ONEmV		(double)(0.001)
#define	TENuV		(double)(0.00001)

/* define A/D gain values 	*/
//#define	mV100	0
//#define	mV55	1
//#define	mV25	2
//#define	V1		3
//#define	V5		4
//#define	V2_5	5
//#define	V_NOTUSED	0xf0

/* Host serial buffers	*/
#define	MSG_SIZE		266
#define	SILENT_TIME		4

#define	HOld	1
#define	ON	1
#define	OFF	0

/* refresh clock dividers	*/
#define	RCLK_DIV4k	(CLKS2 | CLKS1 | CLKS0)
#define	RCLK_DIV2k	(CLKS2 | CLKS1)
#define	RCLK_DIV512	(CLKS2 | CLKS0)
#define	RCLK_DIV128	CLKS2
#define	RCLK_DIV32	(CLKS1 | CLKS0)
#define	RCLK_DIV8	CLKS1
#define	RCLK_DIV2	CLKS0
#define	RCLK_RATE	RCLK_DIV128
#define	RCLK_ALL	(CLKS2 | CLKS1 | CLKS0)

/* identify the SYNC interrupt	*/
#define	SYNC_INT	IRQ1E
/* identify the Power fail warning interrupt	*/
#define	POWER_FAIL	IRQ0E
#define	POWER_FAIL_FLAG	IRQ0F

#define	RTSPORT		P9DR
#define	RTS			0x10

#define	SILENT_TIME	4

/********** Temperature Controller Board I/O addresses	**********/
/** on board I/O address for Area 1	*/
#define	IOADDR	0x30000l
/** thes reads keep F & G hi	*/
#define	DIO1R	0x60
#define	DIO2R	0x61
#define	DIO3R	0x62
#define	DIO4R	0x63
#define	DIO5R	0x64
#define	DIO6R	0x65
#define	V24DOR	0x66
#define	TPO1R	0x68
#define	TPO2R	0x69
#define	TPO3R	0x6a
#define	TPO4R	0x6b
#define	V24DIR	0x6e
/** the writes keep F & G  LO	*/
#define	DIO1W	0x10
#define	DIO2W	0x11
#define	DIO3W	0x12
#define	DIO4W	0x13
#define	DIO5W	0x14
#define	DIO6W	0x15
#define	V24DOW	0x16
#define	TPO1W	0x18
#define	TPO2W	0x19
#define	TPO3W	0x1a
#define	TPO4W	0x1b
#define XWDOG	0x1e	/* external watchdog 090398 pz */

/* commands for the EEPROM #NM93C56	*/
#define	EEPROM_WEN	0x4c0	/* enables all programming modes	*/
#define	EEPROM_ERAL	0x480	/* erase all registers	*/
#define	EEPROM_WDS	0x400	/* disables all programming modes	*/
#define	EEPROM_WRALL	0x440	/* writes to all registers	*/

/* EEPROM map	all values are int's	*/
#define	EEPROM_DATA_PER_CHANL	3
#define	EEPROM_SIZE	128		/* the number of locations it has	*/
#define	EEPROM_CHECKSUM	(EEPROM_SIZE - 1)
#define	EEPROM_VERSION	(EEPROM_CHECKSUM - 1)
#define  EEPROM_CALVERSION 32
//#define  EEPROM_CALCHECKSUM 45
#define  EEPROM_MODE1 25
#define  EEPROM_MODE2 26
#define  EEPROM_MODE3 30
#define  EEPROM_MODE4 31

/* constants for 5.926msec timer	*/
#define	A2DSTARTUP		120		/* A/D converter startup time	*/
#define	A2DSTCONV		14		/* time to start ea conversion	*/
#define	CL_TIME			84		/* 0.5 sec multiplier for value	*/
#define	MSEC500_DIV		84		/* 0.5 sec count	*/

#define	ONESEC_DIV		2		/* divide from 500msec count 	*/
#define	TWOSEC_DIV		2		/* divide from 1sec count		*/
/* A/D multiplexor inputs	*/
#define	CH0			0
#define	CH1			1
#define	CH2			2
#define	CH3			3
#define	CH4			4
#define	CH5			5
#define	CH6			6
#define	CH7			7
#define	CH8			8
#define	CH9			9
#define	CHa			0x0a
#define	CHb			0x0b
#define	CHc			0x0c
#define	CHd			0x0d
#define	CHe			0x0e
#define	CHf			0x0f
#define	THERMSTR0	0x13			/* this one in near channels 0 & 1	*/
#define	THERMSTR1	0x12
#define	VGND		0x10
#define	VSUPPLY		0x11

#define	INPUTfirst	CH0
#define	INPUTlast	CHf
#define	THERMIST0	0
#define	THERMIST1	1
#define	THERMISTRS	THERMSTR1


/* for the CJC table	*/

#define CJCENTRIES         56
#define CJCDELTAT       ((CJCTEMPMIN - CJCTEMPMAX) / (CJCENTRIES-1))
#define CJCMAXINDEX		(CJCENTRIES - 1)
#define	NUMBER_TC_TYPES	7

/*	flash memory defines	*/
#define	SECTOR_SIZE	128			/* 128 bytes/sector for Atmel part	*/
#define	SECTOR_MASK	0x1ff80l	/* mask to get start address of sector	*/
#define	SECTOR_ADDR_MASK	(SECTOR_SIZE - 1)

/* the location in RAM that will be loaded with code	*/
#define	RAMCODE_ADDR	0x47c00
