/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
////////////////////////////////////////////////////////////////////////
//
//		hc2xwd.h
//
//		Author: Joe Rogers
//		Created: 9/7/2004
//
//		Notes: Contains exported globals for watchdog operation.
//
//		TIMEOUTS are unsigned integers represented 100ms ticks.
//
////////////////////////////////////////////////////////////////////////
#ifndef HC2XMSTR_H
#define HC2XMSTR_H

#include "hc2xmstr_exports.h"
#include "transferTable.h"

//Global Defines
//First we setup up the IOCTL Define
//This uses the magic number 't' starting at 0x90.
//This starting point was listed as free in the Linux/Documents/ioctl-numbers.txt
//file.  It is a read call.

extern int g_bBlock;
extern BOOL g_bSecondaryBoardActive;
extern struct TRANSFER_TABLE g_transferTable;

#define IOCTL_GET_JIFFIES			_IOR('t', 0x90, unsigned long)
#define IOCTL_SET_SOCKET_ERROR		_IOR('t', 0x91, int)
#define IOCTL_GET_SOCKET_ERROR		_IOR('t', 0x92, int)

#define IOCTL_SET_NO_DATA			_IOR('t', 0x93, int)
#define IOCTL_CLEAR_NO_DATA			_IOR('t', 0x94, int)

#define IOCTL_GET_TRANSFER_TABLE	_IOR('t', 0x95, struct TRANSFER_TABLE* )
#define IOCTL_SET_TRANSFER_TABLE	_IOW('t', 0x96, struct TRANSFER_TABLE* )

#define IOCTL_GET_SECONDARY_ACTIVE	_IOR('t', 0x97, int )
#define IOCTL_SET_SECONDARY_ACTIVE	_IOW('t', 0x98, int )

#endif
