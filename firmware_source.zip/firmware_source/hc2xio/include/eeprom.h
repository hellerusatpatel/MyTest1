/**************************************************************************
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
    Heller Industries         Company Confidential    
                    

	File:	        eeprom.h

	Description:	
					This file contains EP9301 defines and function protypes used
					to access the SPI EERPOM.
					
	Modifications :	Version	Author	Date		Description
	`				A		jmr		11/10/04	Initial pre-release
	
			         
    This is a trade secret of imagic, inc. and Heller Industries   
    and is protected by copyright. All unauthorized uses prohibited.
********************************************************************/
#ifndef __EEPROM_H_2_
#define __EEPROM_H_2_

#define EEWREN		0x0006
#define EEWRDI		0x0004
#define EERDSR		0x0005
#define EEWRSR		0x0001
#define EEREAD		0x0003
#define EEWRITE	0x0002

#define EE_SELECT_CS	0x0000
#define EE_DESELECT_CS 0x0002

#define TDMEEREAD		0x0600
#define TDMEEWEN		0x04C0
#define TDMEEWRITE	0x0500
#define TDMEEWRALL	0x0440
#define TDMEEWDS		0x0400
#define TDMERASE		0x0700
#define TDMERAL		0x0480
char cOffsetBuffer[0x40]; //character buffer for writing offsets to eeprom 2 characters per channel
char vBuffer[0x20]; //character buffer for holding input style, 1 character per channel
unsigned int GetConfig( void );
void StoreConfig(void);
void SelectEESPI( void );
void DeSelectEESPI( void );
void WriteEnableTDMEE( unsigned short val, unsigned int tdmNo);
unsigned int ReadTDMEE(unsigned int addr, unsigned int tdmNo);
void WriteTDMEE(unsigned int addr, unsigned int data, unsigned int tdmNo);
int AssignEEPromMemory(int iLocation, char chaValue);
char GetEEPromMemory(int iLocation);
#endif
