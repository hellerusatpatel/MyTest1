/************************************************************
 *
 *   h8regs.h
 *
 *   Registers and bit names for the H8/3002 processor.
 *   
 *
 *
 ************************************************************/

/******* BUS CONTROLLER REGISTERS	*******/
#define	ABWCR	0xffffec	/* Area 7 to 0 Bus Width Control	rd/wr	*/
					/* 0 = areas 7 to 0 ar 16 bit access areas, 1 = areas are 8 bit access	*/
#define	ASTCR	0xfffed		/* Area 7 to 0 Access State Control	rd/wr	*/
	/* 0 = areas 7 to 0 are accessed in 2 states, 1 = areas are accessed in 3 states */
#define	AST7	0x80
#define	AST6	0x40
#define	AST5	0x20
#define	AST4	0x10
#define	AST3	0x08
#define	AST2	0x04
#define	AST1	0x02
#define	AST0	0x01
#define	BRCR	0xfffff3	/*	Bus Release Control Register	rd/wr	*/
#define	A23E	0x80		/*	0 = PA4 is A23 address output pin, 1 = PA4 is input/output pin	*/
#define	A22E	0x40		/*	0 = PA5 is A22 address output pin, 1 = PA5 is input/output pin	*/
#define	A21E	0x20		/*	0 = PA6 is A21 address output pin, 1 = PA6 is input/output pin	*/ 
#define	BRLE	0x01		/*	0 = bus cannot release to ext device, 1 = bus can be release to ext device	*/
#define	WCER	0xffffef	/*  Wait State Control Enable Register	rd/wr	*/
		/* 0 = wait-state control disabled (pin wait mode 0), 1 = wait-state control enabled */
#define	WCR		0xffffee	/*	Wait Control Register	rd/wr	*/
#define	WMS1	0x08		/*	00 = programable wait mode, 01 = no wait states inserted	*/
#define	WMS0	0x04		/*	 2 = pin wait mode 1, 3 = pin auto-wait mode	*/
#define	WC1		0x02		/*	WC1 & WC0 = # of wait states inserted	*/
#define	WC0		0x01

/******* DMA CONTROLLER REGISTERS	*******/
#define	MAR0AR	0xffff20	/* memory address register	*/
#define	MAR0AE	0xffff21	/* the 4 reg's R,E,H & l make up a 32	*/
#define	MAR0AH	0xffff22	/* bit address	*/
#define	MAR0AL	0xffff23
#define	MAR0BR	0xffff28
#define	MAR0BE	0xffff29
#define	MAR0BH	0xffff2a
#define	MAR0BL	0xffff2b
#define	MAR1AR	0xffff30
#define	MAR1AE	0xffff31
#define	MAR1AH	0xffff32
#define	MAR1AL	0xffff33
#define	MAR1BR	0xffff38
#define	MAR1BE	0xffff39
#define	MAR1BH	0xffff3a
#define	MAR1BL	0xffff3b
#define	ETCR0AH	0xffff24	/* execute transfer count register	*/
#define	ETCR0AL	0xffff25	/* H & L make up a 16 bit xfer count	*/
#define	ETCR0BH	0xffff2c
#define	ETCR0BL	0xffff2d
#define	ETCR1AH	0xffff34
#define	ETCR1AL	0xffff35
#define	ETCR1BH	0xffff3c
#define	ETCR1BL	0xffff3d
#define	IOAR0A	0xffff26	/* I/O address register	*/
#define	IOAR0B	0xffff2e
#define	IOAR1A	0xffff36
#define	IOAR1B	0xffff3e
#define	DTCR0A	0xffff27	/* data transfer control register	*/
#define	DTCR0B	0xffff2f
#define	DTCR1A	0xffff37
#define	DTCR1B	0xffff3f
 /** DTCR bits	*/
#define	DTE		0x80		/* 1 = data transfer enable	*/
#define	DTSZ	0x40		/* data size, 0 = byte, 1 = word	*/
#define	DTID	0x20		/* data transfer 0=inc/1=dec memory addr	*/
#define	RPE		0x10		/* repeat enable	*/
#define	DTIE	0x08		/* data transfer interrupt enable	*/
#define	DTS2	0x04		/* sel xfer activation source	*/
#define	DTS1	0x02
#define	DTS0	0x01

/******* INTERGRATED TIMER UNIT REGISTERS	*******/
/** General registers and buffer registers	*/
#define	TCNT0H	0xffff68
#define	TCNT0L	0xffff69
#define	TCNT1H	0xffff72
#define	TCNT1L	0xffff73
#define	TCNT2H	0xffff7c
#define	TCNT2L	0xffff7d
#define	TCNT3H	0xffff86
#define	TCNT3L	0xffff87
#define	TCNT4H	0xffff96
#define	TCNT4L	0xffff97
#define	BRA3H	0xffff8c
#define	BRA3L	0xffff8d
#define	BRB3H	0xffff8e
#define	BRB3L	0xffff8f
#define	BRA4H	0xffff9c
#define	BRA4L	0xffff9d
#define	BRB4H	0xffff9e
#define	BRB4L	0xffff9f
#define	GRA0H	0xffff6a
#define	GRA0L	0xffff6b
#define	GRB0H	0xffff6c
#define	GRB0L	0xffff6d
#define	GRA1H	0xffff74
#define	GRA1L	0xffff75
#define	GRB1H	0xffff76
#define	GRB1L	0xffff77
#define	GRA2H	0xffff7e
#define	GRA2L	0xffff7f
#define	GRB2H	0xffff80
#define	GRB2L	0xffff81
#define	GRA3H	0xffff88
#define	GRA3L	0xffff89
#define	GRB3H	0xffff8a
#define	GRB3L	0xffff8b
#define	GRA4H	0xffff98
#define	GRA4L	0xffff99
#define	GRB4H	0xffff9a
#define	GRB4L	0xffff9b
/** Timer Start Register	TSTR	rd/wr	*/
#define	TSTR	0xffff60
#define	STR4	0x10		/*	0 = timer/counter 4 is halted, 1 = is counting */
#define	STR3	0x08		/*	0 = timer/counter 3 is halted, 1 = is counting */
#define	STR2	0x04		/*	0 = timer/counter 2 is halted, 1 = is counting */
#define	STR1	0x02		/*	0 = timer/counter 1 is halted, 1 = is counting */
#define	STR0	0x01 		/*	0 = timer/counter 0 is halted, 1 = is counting */
/** Timer SyNChro Register	TSNC	rd/wr	*/
#define	TSNC	0xffff61
/**	Timer MoDe Register		TMDR	rd/wr	*/
#define	TMDR	0xfff62
/** Timer Function Control Register	TFCR	rd/wr	*/
#define	TFCR	0xffff63
#define	CMD1	0x20
#define	CMD0	0x10
#define	BFB4	0x08		/*	0 = GRB4 operates normal, 1 = GRB4 is buffered by BRB4	*/
#define	BFA4	0x04		/*	0 = GRA4 operates normal, 1 = GRA4 is buffered by BRA4	*/
#define	BFB3	0x02		/*	0 = GRB3 operates normal, 1 = GRB3 is buffered by BRB3	*/
#define	BFA3	0x01		/*	0 = GRA3 operates normal, 1 = GRA3 is buffered by BRA3	*/
/**	Timer Output master Enable Register	TOER	rd/wr	*/
#define	TOER	0xffff90
/**	Timer Output Control Register	TOCR	rd/wr	*/
#define	TOCR	0xffff91
/** Timer Control Register	TCR	rd/wr	*/
#define	TCR4	0xffff92	/* Timer Control Register #4	*/
#define	TCR3	0xffff82
#define	TCR2	0xffff78
#define	TCR1	0xffff6e
#define	TCR0	0xffff64
#define	CCLR1	0x40		/*	0 = TCNT is not cleared, 1 = TCNT cleared by GRA compare */
#define	CCLR0	0x20		/*	match, 2 = TCNT cleared by GRB compare match, 3 = symcronous clear */
#define	CKEG1	0x10		/*	0 = count rising edge, 1 = count falling edge, */
#define	CKEG0	0x08		/*	2 = count both edges */
#define	TPSC2	0x04		/*	0 = internal clk, 1 = internal clk/2, 2 = internal clk/4 */
#define	TPSC1	0x02		/*	3 = internal clk/8, 4 = TCLKA input, 5 = TCLKB input */
#define	TPSC0	0x01		/*	6 = TCLKC input, 7 = TCLKD input */
/** Timer Interrupt Enable Register	TIER	rd/wr	*/
#define	TIER0	0xffff66	/* Timer 4 Interrupt Enable Register */
#define	TIER1	0xffff70
#define	TIER2	0xffff7a
#define	TIER3	0xffff84
#define	TIER4	0xffff94
#define	OVIE	0x04		/*	0 = OVI intr req by OVF is disabled, 1 = intr req is enabled	*/
#define	IMIEB	0x02		/* 	0 = IMIB intr req by IMFB is disabled, 1 = intr reg is enabled	*/
#define	IMIEA	0x01		/*	0 = IMIA intr req by IMFA is disabled, 1 = intr req is enabled	*/
/** Timer I/O Control Register	TIOR	rd/wr	*/
#define	TIOR4	0xffff93	/* Timer I/O control register channel #4	*/
#define	TIOR3	0xffff83
#define	TIOR2	0xffff79
#define	TIOR1	0xffff6f
#define	TIOR0	0xffff65
#define	IOB2	0x40
#define	IOB1	0x20
#define	IOB0	0x10
#define	IOA2	0x04
#define	IOA1	0x02
#define	IOA0	0x01
/** Timer Status Register	TSR	rd/wr (only '0' can be written to clear flag	*/
#define	TSR4	0xffff95	/* Timer Status Register channel #4	*/
#define	TSR3	0xffff85
#define	TSR2	0xffff7b
#define	TSR1	0xffff71
#define	TSR0	0xffff67
#define	OVF		0x04		/*	indicates overflow or underflow		*/
#define	IMFB	0x02		/*	GRB compare match or input capture	*/
#define	IMFA	0x01		/*	GRA compare match or input capture	*/

/*******	INTERRUPT CONTROLLER REGISTERS	*******/
/* also see SYSCR in 'mode control registers'	*/
/*	Interrupt Enable Register	IER	rd/wr	*/
#define	IER		0xfffff5
#define	IRQ5E	0x20		/*	0 = IRQ interrupt is disabled, 1 = intr are enabled	*/
#define	IRQ4E	0x10
#define	IRQ3E	0x08
#define	IRQ2E	0x04
#define	IRQ1E	0x02
#define	IRQ0E	0x01

/*	Interrupt Priority Register A	rd/wr	*/
#define	IPRA	0xfffff8
						/*	0 = interrupt request have priority level 0 (low)
							1 = interrupt request have priority level 1 (high)	*/
#define	IPRA7	0x80		/*	select priority of IRQ0	*/
#define	IPRA6	0x40		/*	select priority of IRQ1	*/
#define	IPRA5	0x20		/*	select priority of IRQ2 & IRQ3	*/
#define	IPRA4	0x01		/*	select priority of IRQ4 & IRQ5	*/
#define	IPRA3	0x08		/*	select priority of WDT & refresh controller	*/
#define	IPRA2	0x04		/*	select priority of ITU channel 0	*/
#define	IPRA1	0x02		/*	select priority of ITU channel 1	*/
#define	IPRA0	0x01		/*	select priority of ITU channel 2	*/
/*	Interrupt Priority Register B	rd/wr	*/
#define	IPRB	0xfffff9
						/*	0 = interrupt request have priority level 0 (low)
							1 = interrupt request have priority level 1 (high)	*/
#define	IPRB7	0x80		/*	select priority of ITU channel 3	*/
#define	IPRB6	0x40		/*	select priority of ITU channel 4	*/
#define	IPRB5	0x20		/*	select priority of DMAC	*/
#define	IPRB3	0x08		/*	select priority of SCI channel 0	*/
#define	IPRB2	0x04		/*	select priority of SCI channel 1	*/
#define	IPRB1	0x02		/*	select priority of A/D converter	*/
/*	IRQ Sense Control Register	ISCR	rd/wr	*/
#define	ISCR	0xfffff4
#define	IRQ5SC	0x20		/*	0 = intr requested when input is low,	*/
#define	IRQ4SC	0x10		/*	     1 = intr requested on falling edge		*/
#define	IRQ3SC	0x08		/* 	4 - 0 are the same as IRQ5SC	*/
#define	IRQ2SC	0x04
#define	IRQ1SC	0x02
#define	IRQ0SC	0x01
/*	IRQ Status register	ISR	rd/wr only '0' to clear flags	*/
#define	ISR		0xfffff6
#define	IRQ5F	0x20
#define	IRQ4F	0x10
#define	IRQ3F	0x08
#define	IRQ2F	0x04
#define	IRQ1F	0x02
#define	IRQ0F	0x01

/*******	MODE CONTROL REGISTER	MDCR  rd only	*******/
#define	MDCR	0xfffff1	/*	bits 2 - 0 define current operating mode */
							/*	bits 5 - 3 reserved, read as 0
							 	bits 7 - 6 reserved, read as 1	*/

/*	System Control Register	SYSCR	rd/wr	*/
#define	SYSCR	0xfffff2
#define	SSBY	0x80	/*	Software StandBY */
#define	STS2	0x40	/*	Standby Timer Select bits */
#define	STS1	0x20	
#define	STS0	0x10
#define	UE		0x08	/*	0 = UI bit used as interrupt mask bit, 1 = UI is a user bit */
#define	NMIEG	0x04	/*	0 = interrupt @ falling edge, 1 = interrupt @ rising edge */
#define	RAME	0x01	/*	0 = disable on-chip RAM, 1 = enable on-chip RAM */

/*** Watchdog Timer registers	***/
#define	TCSR	0xffffa8	/* word access only register, needs password	*/
#define	TCSR_PWORD	0xa500	/* password	*/
#define	WD_OVF		0x80
#define	WT_IT	0x40		/* mode select, Watchdog/Interval timer	*/
#define	TME		0x20		/* timer enable	*/
#define	WD_CKS2	0x04		/* Watchdog timer clock select line	*/
#define	WD_CKS1	0x02
#define	WD_CKS0	0x01
#define	TCNT	0xffffa8	/* word access only register, needs password	*/
#define	TCNT_PWORD	0x5a00	/* password	*/
#define	RSTCSR	0xffffab	/* ReSeT Control/Status Register, needs password*/
#define	WRST	0x80		/* watchdog timer reset status	*/
#define	RSTOE	0x40		/* reset output enable	*/
#define	WRST_PWROD	0xa500	/* watchdog reset status bit password	*/
#define	RSTOE_PWORD	0x5a00	/* Reset output enable password	*/

/*******	PORT REGISTERS	*******/
#define	P4DDR	0xffffc5		/* Port 4 Data Direction Register	(wr only)	*/
#define	P4DR	0xffffc7		/* Port 4 Data Register	*/
#define	P4PCR	0xffffda		/* Port 4 input pull-up control register	*/
							/* 0 = pull-up disabled, 1 = pull-up enabled	*/
#define	P6DDR	0xffffc9		/* Port 6 Data Direction Register	(wr only)	*/
#define	P6DR	0xffffcb		/* Port 6 Data Register	*/
#define	P7DR	0xffffce		/* Port 7 Data Register	*/
#define	P8DDR	0xffffcd		/* Port 8 Data Direction Register	(wr only)	*/
#define	P8DR	0xffffcf		/* Port 8 Data Register	*/
#define	P9DDR	0xffffd0		/* Port 9 Data Direction Register	(wr only)	*/
#define	P9DR	0xffffd2		/* Port 9 Data Register	*/
#define	PADDR	0xffffd1		/* Port A Data Direction Register	(wr only)	*/
#define	PADR	0xffffd3		/* Port A Data Register	*/
#define	PBDDR	0xffffd4		/* Port B Data Direction Register	(wr only)	*/
#define	PBDR	0xffffd6		/* Port B Data Register	*/

/******* REFRESH CONTROLLER REGISTERS	*******/
/**	ReFreSH Control Register	rd/wr	*/
#define	RFSHCR	0xffffac
#define	SRFMD	0x80		/*	0 = self refresh disabled in S/W standby mode, 1 = enabled	*/
#define	PSRAME	0x40		/*	used with DRAME, 00 = can be used as interval timer, 01 = DRAM can be.. */
#define	DRAME	0x20		/*	 connected, 2 = PSRAM can be connected, 3 = illegal setting	*/
#define	CASWE 0x10		/*	0 = 2WE\ mode, 1 = 2 CAS\ mode	*/
#define	M9M8	0x08		/*	0 = 8 bit column address mode, 1 = 9 bit column address mode	*/
#define	RFSHE	0x04		/*	RFSH\ pin is disabled, 1 = refresh signal is output at RFSH\ pin */
#define	RCYCE	0x01		/*	0 = refresh cycles are disabled, 1 = enable for area 3	*/
/**	Refresh Time COnstant Register	rd/wr	*/
#define	RTCOR	0xffffaf
/**	Refresh Timer CouNTer	rd/wr	*/
#define	RTCNT	0xffffae
/**	Refresh TiMer Control/Status Register	rdwr	*/
#define	RTMCSR	0xffffad
#define	CMF		0x80	/*	1 = when RTCNT = RTCOR, only 0 can be written	*/
#define	CMIE	0x40	/*	0 = CMI intr req by CMF is disabled, 1 = intr req by CMF is enabled	*/
#define	CLKS2	0x20	/*	CKS2-0:	000 = clock disabled, 001 = clk/2, 010 = clk/8	*/
#define	CLKS1	0x10	/*			011 = clk/32,  100 = clk/128,  101 = clk/512	*/
#define	CLKS0	0x08	/*			110 = clk/2048,  111 = clk/4096		*/

/******* SERIAL PORT REGISTERS	*******/
/**	Bit Rate Register	BRR	rd/wr	*/
#define	BRR0	0xffffb1
#define	BRR1	0xffffb9
/**	Receive Data Register	RDR	rd	*/
#define	RDR0	0xfffb5
#define	RDR1	0xfffbd
/**	Serial Control Register	SCR	rd/wr	*/
#define	SCR0	0xffffb2
#define	SCR1	0xffffba
#define	TIE		0x80	/*	0 = xmit empty intrupt request disabled, 1 = xmit intr empty enabled	*/
#define	RIE		0x40	/*	0 = RXI & ERI intr request disabled, 1 = intr req's enabled	*/
#define	TE		0x20	/*	0 = transmitting disabled, 1 = transmitting enabled	*/
#define	RE		0x10	/*	0 = receiving disabled, 1 = receiving enabled	*/
#define	MPIE	0x08	/*	0 = multiprocessor interrupts are disabled, 1 = enabled	*/
#define	TEIE	0x04	/*	0 = xmit end intr req's  (TEI) are disabled, 1 = intr req's enabled	*/
#define	CKE1	0x02
#define	CKE0	0x01
/**	Serial Mode Register SMR  rd/wr	*/
#define	SMR0	0xffffb0	/* Serial Mode Register for channel 0	*/
#define	SMR1	0xffffb8	/* Serial Mode Register for channel 1	*/
#define	CA		0x80	/*	0 = asyncronous mode, 1 = syncronous mode */
#define	CHR		0x40	/*	0 = 8 bit data, 1 = 7 bit data */
#define	PE		0x20	/*	0 = no parity, 1 = parity enabled */
#define	OE		0x10	/*	0 = even parity, 1 = odd parity */
#define	STOP	0x08	/*	0 = 1 stop bit, 1 = 2 stop bits */
#define	MP		0x04	/*	0 = multiprocessor function disabled, 1 = mulitprosseor */
#define	CKS1	0x02	/*	00 = clock, 01 = clock/4, 2 = clock/16, 3 = clock/64 */
#define	CKS0	0x01	/*	used with CKS1 */
/**	Serial Status Register SSR rd/wr (only '0' can be written to clear flag	*/
#define	SSR0	0xffffb4
#define	SSR1	0xffffbc
#define TDRE    0x80    /*	Transmit Data Register Empty */
#define RDRF    0x40    /*	Read Data Register Full */
#define ORER    0x20    /*	OverRun ErRor */
#define FER     0x10    /*	Framing ErRor */
#define PER     0x08    /*	Parity ErRor */
#define	TEND	0x04	/*	Transmit END */
#define	MPB		0x02	/*	MultiProcessor Bit */
#define	MPBT	0x01	/*	MultiProcessor Bit Transfer */
/**	Transmit Data Register	TDR	rd/wr	*/
#define	TDR0	0xffffb3
#define	TDR1	0xffffbb
