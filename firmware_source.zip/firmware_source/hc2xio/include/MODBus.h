#ifndef __MODBUS_H__
#define __MODBUS_H__
/*********************************

	MODBus.h


 *********************************/
#include	"project.h"

#define	NUMBER_ENCODERS	4
#define	NUMBER_COILS	60
#define	TDM_SPARE_INPUTS	(TDM_A2D_INPUTS - TDM_TC_INPUTS)
/**** addresses of holding registers in sequence for Modbus	*/
#define	HOLDfirst	0
#define	HOLD_REG_SIZE	60
#define	HOLD_REGlast	(HOLDfirst + HOLD_REG_SIZE - 1)
#define	CONFIGfirst		HOLD_REG_SIZE
#define	NUMBER_CONFIG_REG	60
#define	HOLDPUfirst		(CONFIGfirst + NUMBER_CONFIG_REG)
#define	HOLDPUlast		(HOLDPUfirst + HOLD_REG_SIZE - 1)
#define	HOLDCLfirst		(HOLDPUlast + 1)
#define	HOLDCLlast		(HOLDCLfirst + HOLD_REG_SIZE - 1)
#define	DIAGNOSTICfirst	(HOLDCLlast + 1)
#define	DIAGNOSTIClast	(DIAGNOSTICfirst + (2 * TDM_A2D_INPUTS) - 1)
#define	CALIBRATE		(DIAGNOSTIClast + 1)
#define	HOLDtemp_offset	(DIAGNOSTICfirst + HOLD_REG_SIZE)
#define	NUMBER_HOLD_REG	(HOLDtemp_offset + HOLD_REG_SIZE + 1)
/******* addresses of holding registers	**/
#define	TPOfirst	0
#define	TPOlast		31
#define	TPO_SIZE	(TPOlast - TPOfirst + 1)
#define	TPO_LENGTH	256
#define	NUMBER_TPO_REGS	((TPO_SIZE + 7) / 8)
/* offsets for HOLD Comm Lost array	*/
#define	HOLDCLhold0		(TPOlast + 1)
#define	HOLDCLhold1		(HOLDCLhold0 + 1)
/**** list coils in order in memory	*/
#define	COILfirst		0
#define	COILlast		(COILfirst + NUMBER_COILS - 1)
#define	COILPUfirst		(COILlast + 1)
#define	COILPUlast		(COILPUfirst + NUMBER_COILS - 1)
#define	COILCLfirst		(COILPUlast + 1)
/*#define	COILCLlast		((COILCLfirst + (2 * NUMBER_COILS)) - 1)	*/
#define	COILCLlast		(COILCLfirst + NUMBER_COILS - 1)
#define	COILCLHfirst	(COILCLlast + 1)
#define	COILCLHlast		(COILCLHfirst + NUMBER_COILS - 1)
#define	COILS_LENGTH	(COILCLHlast + 1)
#define	COIL_BYTES		((COILS_LENGTH + 7) / 8)
#define	COIL_REGS		((NUMBER_COILS + 7) / 8)
/**** addresses of input status registers	**/
#define	NUMBER_INP_STAT	64
/**** addresses of configuration registers	**/
#define	CONFIG_TDM0		0
#define	CONFIG_TDM0last	(CONFIG_TDM0 + TDM_TC_INPUTS - 1)
#define	CONFIG_TDM1		(CONFIG_TDM0 + TDM_A2D_INPUTS)
#define	CONFIG_TDM1last	(CONFIG_TDM1 + TDM_TC_INPUTS - 1)
#define	CONFIG_CL_TIME	(CONFIG_TDM1 + TDM_A2D_INPUTS)
#define	CONFIG_ENCODER	(CONFIG_CL_TIME + 1)
/* CONFIG_ENCODER register masks	*/
#define	ENCDR_DIR_MASK	0x10
/* #define	SPEED_MASK	NIBBLE.BYTE0.LO_NIBBLE *//* speed not display 072998 pz */
#define SPEED_MASK	BYTE.LO_BYTE & 0x0f
/***  values for configuration registers  **/
#define	TYPE_K	0
#define	VOLT_INPUT	1
#define	TYPE_T	2
#define	TYPE_E	3
#define	TYPE_R	4
#define	TYPE_S	5
#define	TYPE_B	6
#define	TYPE_J	7
#define	INVALID_CONFIG	(VOLT_INPUT + 1)
/* SPEED register values	*/
#define	HALF_SEC	0
#define	ONE_SEC		1
#define	TWO_SEC		2
#define	MAX_SPEED_VALUE	TWO_SEC
/*#define	NUMBER_VOLT_INPUTS	4 */
/**** addresses of input registers	*/
#define	INPUT_REGfirst	0
#define	INPUT_TDM0		0
#define	INPUT_TDM1		(INPUT_TDM0 + TDM_A2D_INPUTS)
#define	ENCODER_REG_LEN	3
#define	ENCODER0		(INPUT_TDM1 + TDM_A2D_INPUTS)
#define	ENCODERS		ENCODER0
#define	ENCODER1		(ENCODER0 + ENCODER_REG_LEN)
#define	ENCODER2		(ENCODER1 + ENCODER_REG_LEN)
#define	ENCODER3		(ENCODER2 + ENCODER_REG_LEN)
#define	TEMPfirst		(ENCODER3 + ENCODER_REG_LEN)
#define	TEMPlast		(TEMPfirst + (2 * TDM_A2D_INPUTS * NUMBER_OF_TDMS) - 1)
#define	NUMBER_INP_REG	(TEMPlast + 1)
#define	POSITIONhi_word	0
#define	POSITIONlo_word	(POSITIONhi_word + 1)
#define	SPEED			(POSITIONlo_word + 1)
#define	HI_RES_TEMP		60
/*** addresses of DIAGNOSTIC registers	*/
#define	DIAG_CALIBRATE	(NUMBER_OF_TDMS * TDM_A2D_INPUTS)
/** diagnostic regs values	*/
#define	mVOLT_OUTPUT	1		/* store value in mVolts	*/
#define	A2D_DATA		2		/* store sign + 15 MSBits	*/
#define	NUMBER_DIAGNOSTIC_REGS	((CALIBRATE) - (DIAGNOSTICfirst) + 1)
#define	DIAG_HIGH_VAL	A2D_DATA
/*** defines for DIAGNOSTIC CALIBRATE register	from host	**/
#define	CALIB_OFFSET	1
#define	CALIB_GAIN		2
#define	CALIB_TDM0		0x000
#define	CALIB_TDM1		0x100

/* define Modbus byte positions	*/
#define	ADDRESS		0
#define	FUNCTION	1
#define	ADDRESS_HI	2
#define	ADDRESS_LO	3
#define	LENGTH_HI	4
#define	LENGTH_LO	5
#define	REC_BYTE_COUNT	6
#define FORCE_DATA      4
#define DATA_HI         4
#define DATA_LO         5
/** define Modbus functions	*/
#define	READ_COIL_STATUS			1
#define	READ_INPUT_STATUS			2
#define	READ_HOLDING_REGISTERS		3
#define	READ_INPUT_REGISTERS		4
#define	FORCE_SINGLE_COIL			5
#define	PRESET_SINGLE_REGISTER		6
#define	DIAGNOSTICS					8
#define	FORCE_MULTIPLE_COILS		15
#define	PRESET_MULTIPLE_REGISTERS	16
#define	REPORT_SLAVE_ID				17
#define	POLL_PROGRAM_COMPLETE				18	/* unknown what it really is! */
/** DIAGNOSTICS subfunctions	*/
#define	RETURN_QUERY_DATA			0x00
#define	RESTART						0x01
#define	CLR_CNTRS__DIAG_REGS		0x0a
#define	RETURN_BUS_MSG_CNT			0x0b
#define	RETURN_BUS_COMM_ERR_CNT		0x0c
#define	RETURN_BUS_EXCPTN_ERR_CNT	0x0d
#define	RETURN_MSG_CNT				0x0e
#define	RETURN_NO_RESP_CNT			0x0f
#define	RETURN_BUS_CHARA_OVERRUN	0x12
/** constants used	*/
#define	BROADCAST		0
#define	CRC_CONSTANT	0xa001
/** define exception responses	*/
#define	ILLEGAL_FUNCTION	1
#define	ILLEGAL_DATA_ADDR	2
#define	ILLEGAL_DATA_VALU	3
#define	SLAVE_DEVICE_FAIL	4
#define	ACKNOWLEDGE			5
#define	SLAVE_DEVICE_BUSY	6
#define	NEG_ACKNOWLEDGE		7
/** Modbus error msg defines	*/
#define	DEV_BUSY	0x80
#define	ACK			0x40
#define	NEG_ACK		0x20
#define	DEV_FAIL	0x10
#define	DATA_ERR	0x08
#define	ADDR_ERR	0x04
#define	CRC_ERR		0x02
#define	EXCEPT		0x01

/* encoder definitions	*/
#define	NUMBER_ENCODER_SEQ	4
#define	ENCODER_SEQ_MASK	(NUMBER_ENCODER_SEQ - 1)

/* Coil conditions	*/
#define	COIL_ON		0xff
#define	COIL_OFF	0x00

#endif
