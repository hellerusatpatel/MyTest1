/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef HC2XIO_H
#define HC2XIO_H

extern int g_encoderCount;

#define HC2XCTLAPP_INIT_TDM				5000000

#define HC2XCTLAPP_SetIPAddress			6000000
#define HC2XCTLAPP_SetMACAddress		6000001
#define HC2XCTLAPP_SetSlaveIPAddress	6000002

#define HC2XCTLAPP_GetIPAddress			7000000
#define HC2XCTLAPP_GetMACAddress		7000001

extern unsigned short bAccessingSPI;
extern unsigned short bAccessingEEPROM;

#endif
