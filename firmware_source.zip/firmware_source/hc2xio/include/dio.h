/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
/***************************************************************************/ 
// digitio.h

#ifndef DIO_H
#define DIO_H

#define SIZE 8
extern unsigned char dio_buffer[SIZE];
//////////////////////////////////////////////
//
//  The index for the following DIO_*() functions
//  are the IDI_* and IDO_* defines used in typedefdefine.h
//
//////////////////////////////////////////////


//
// function: DIO_SET
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Set(unsigned int index, unsigned int value);

//
// function: DIO_Get
// return: bit value at index either 0 or 1, or 0xFFFF if failure
//
unsigned int DIO_Get(unsigned int index);

//
// function: DIO_Write
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Write(unsigned buffer_index);

//
// function: DIO_Read
// return: 0xFFFF if failure, 1 if successful
//
int DIO_Read(unsigned buffer_index);

void DIO_Initialize();
void DIO_ReadAll();
void DIO_Write_Inputs();
void DIO_Write_Outputs();

#endif
