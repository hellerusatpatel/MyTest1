#ifndef __HC2XUTILS_H__
#define __HC2XUTILS_H__

void hc2xsleep( unsigned int milliseconds );

#endif
