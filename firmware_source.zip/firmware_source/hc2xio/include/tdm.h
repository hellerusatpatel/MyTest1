#ifndef TDM_H
#define TDM_H

/* hc2xvars.h */
double BreakVoltage; 
double Temperature, CJCVoltage;   
unsigned int bTempError;
//unsigned int BadChannels;

double CJCTemperature, TCVoltage, CJCOffsetVoltage, CJCSensorRaw;
double TemperatureVal, InVoltage;
int ChannelType;  

double Thermistor[4];
int TDM0_A2D[0x14];
int TDM1_A2D[0x14];

double Min[0x20], Max[0x20];
double CJtemp[0x20], CJC[0x20];
char ChanlStatus[0x20];
char ChanlType[0x20];
unsigned int TempScale, TCBreakPolarity;

/*end hc2xvars.h*/

/* resitor in series with the thermister	*/
#define	RD	6490.0
/* supply voltage to thermister	*/
#define	VREF	2.50

#define GOODCHAN 0x00
#define BADCHAN 0x01

#define TDM_TC_INPUTS 0x10
#define  CHANNELOFFSET 0x10

#define CJCTEMPMIN      -40.0
#define CJCTEMPMAX       70.0
#define CJCENTRIES         56
#define CJCDELTAT       ((CJCTEMPMIN - CJCTEMPMAX) / (CJCENTRIES-1))
#define CJCMAXINDEX		(CJCENTRIES - 1)
  

#define MAXA2DINPUT 0x7FFFFFF
	
enum CHANNEL_TYPES
{ 
	eMV70,			                /* -71.5 to +71.5 mV */
	eK_TYPE,	                        /* K thermocouple */
	eVOLT_TYPE,				/* voltage mode 12-60 mV input
};   
struct   CHANL_STRC
{
   int         mvolts;     /* the A/D's output in mVolts */
   LONG_UNION  raw_val; /* the A/D's output w/ status bits  */
   ULONG_UNION gain[3]; /* A/D gain settings for this channel  */
   LONG_UNION  offset[3];
   uchar    gain_sel;   /* which .chanl.gain[] & .chanl.offset[] to use */
} ;

struct   TH_STRC
{
   double   temp; /* this is the temperature */
   int      error;   /* overflow or underflow flags   */
};



/***************************************************************************
This file contains data for the 192-103LET-A01 (APN 12-990006) thermistor used
on the TDM Module 28983
The data consists of resistance values in ohms that are expected at
temperatures beginning at CJCTEMPMAX, ending at CJCTEMPMIN, and
separated by CJCDELTAT
*****************************************************************************/


#endif
