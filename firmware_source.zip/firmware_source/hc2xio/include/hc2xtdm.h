//*****************************************************************************
// Copyright (c) 1999-2014 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2014 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: hc2xtdm.h
//
// This is a trade secret of iMagic, Inc. and Heller Industries, Inc.
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 17-Sep-04  JMR  Initial pre-release
// 14-Dec-14  FJN  Insert TDM eeprom error reporting from 5.5.0.18 release
//*****************************************************************************
#ifndef __HC2XTDM_H__
#define __HC2XTDM_H__

#include "globals.h"

#define	EEPROM_NUM 2

#define	p0	0.20803843466947e7
#define	p1	0.30286971697440e5
#define	p2	0.60614853300611e2
#define	q0	0.60027203602388e7
#define	q1	0.32772515180829e6
#define	q2	0.17492876890931e4
#define	log2e	1.44269504088896
#define	sqrt2	1.41421356237310
#define	maxf	10000
/* hc2xvars.h */
double BreakVoltage; 
double Temperature, CJCVoltage;   
unsigned int bTempError;
//unsigned int BadChannels;

int eepromVersionError[EEPROM_NUM];
int eepromCrcError[EEPROM_NUM];

int ChannelType;  

int TDM0_A2D[0x14];
int TDM1_A2D[0x14];
int VoltsBuffer[0x20];

int Thermistor[4];
int EngUnitBuffer[0x20];
short offsetBuffer[0x20];
int CJtemp[0x20], CJC[0x20];
char ChanlStatus[0x20];
char ChanlType[0x20];
unsigned int TempScale, TCBreakPolarity;

// fjn -- present in 5.5.0.18 but not in 6.2.0.10
unsigned int EEpromMap[EEPROM_SIZE];
unsigned int EEpromMapx[EEPROM_SIZE][EEPROM_NUM];

// temporary variables
int A2DVal;
int CJCValue;
int Resistance;

/*end hc2xvars.h*/
int iEEPromUpload;
/* define A/D gain values 	*/
#define	mV100	0
#define	mV55	1
#define	mV25	2
#define	V1		3
#define	V5		4
#define	V2_5	5
#define	V_NOTUSED	0xf0

#define MAX_CHANNEL_CNT 16
#define A2DC_ERROR_CONDITION 0x00000300
#define A2DC_MAX_RAW_CNT 0x7FFFF00 //graph display *ptrTDM dependent on ptrTDM now or when in proc_data
//0
#define TCTYPE_PLUS_MINUS_71_mV 0
#define A2D_CONFIG_VALUE_FAST  0x00002020
#define A2D_CONVERSION_DONE 0x00000008

#define TDM_NUM 2
TDM_STRUCT TDM[TDM_NUM];
int TDM0_currentChannel;
int TDM1_currentChannel;
int Tdm_init(int iConfigCall);
void Tdm_beginAcquisition();
void Tdm_initChannels();
unsigned int TDM_returnData(int iTDM, int iChannel);

void TDM_setOffsets(int iTDM, int iIndex, short wOffset);
int TDM_commitOffsetsToEEPROM();
void Tdm_writeEEPromBuffer(unsigned int value, unsigned int location);
//int commitMapToEEPROM(int iTDM);
void TDM_setInputType(int iLocation, short iInputStyle);
void Tdm_processHc2xEEProm();	
int TDM_fresh_memory();		
void TDM_writeMemory(int addr, unsigned int data, unsigned int which);
int TDM_versionError(int which);
int TDM_crcError(int which);
short TDM_getMem(int iLocation, int iTDM);
/*hc2xdefs.h*/
/* resitor in series with the thermister	*/
#define	RD	6490.0
/* supply voltage to thermister	*/
#define	VREF	2.50

#define GOODCHAN 0x00
#define BADCHAN 0x01
#define BADTDM  0x02
#define  CHANNELOFFSET 0x10


#define CJCTEMPMIN      -4000
#define CJCTEMPMAX      7000
#define CJCENTRIES      56
#define CJCDELTAT		-200
#define CJCMAXINDEX		55

#define MAXA2DINPUT 0x7FFFFFF
	
enum CHANNEL_TYPES
{ 
	eMV70,			                /* -71.5 to +71.5 mV */
	eK_TYPE	                        /* K thermocouple */
};    

#endif
