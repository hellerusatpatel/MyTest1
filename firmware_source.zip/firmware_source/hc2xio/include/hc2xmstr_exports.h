/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __HC2XMSTR_EXPORTS_H__
#define __HC2XMSTR_EXPORTS_H__

#include "typedefdefine.h"
#include "transferTable.h"

enum HC2XMSTR_ERROR
{
	HC2XMSTR_NO_ERROR = 0,
	HC2XMSTR_NO_CONNECTION,
	HC2XMSTR_INVALID_DATA,
	HC2XMSTR_NO_SLAVE_IP,
};

//
// TransferTable Interface
//
WORD HC2XMSTR_SecondaryGetAI( int index );
BOOL HC2XMSTR_SecondaryGetDigitalIn( int index );
WORD HC2XMSTR_SecondaryGetTdmOffset( int index );
DWORD HC2XMSTR_SecondaryGetFlags();

BOOL HC2XMSTR_PrimarySetTPO( int index, DWORD dwValue );
BOOL HC2XMSTR_PrimarySetDigitalOut( int index, BOOL bValue );
BOOL HC2XMSTR_PrimarySetConfiguration( struct CONFIGURATION* pConfiguration );

void HC2XMSTR_SetSecondaryActiveFlag( BOOL bActive );

#endif
