/**************************************************************************

    imagic, Inc.    Copyright (C) 2003, All Rights Reserved
                    Company Confidential    
                    

	File:	        confcal.h

	Description:	
					these are the structures used for the Analog Input
					card.
					
	Modifications :	Version	Author	Date	Description
	`				A		jmr		09/03/03	Initial pre-release  
				         
    This is a trade secret of imagic, inc.
    and is protected by copyright. All unauthorized uses prohibited.
********************************************************************/
#ifndef CONFCAL_H
#define CONFCAL_H

struct CalStruct
{
	unsigned long nGain;
	unsigned long nOffset;
	unsigned long nMiliSelect;
	
};
 
/* you cannot change the size of this structure */
struct ChannelStruct
{
	unsigned int nModeSelect;	  //Used to select TC Type or voltage mode.
	unsigned int bInProcess;	  //True if the channel is currently sampling
	unsigned short nEepromIndex; //Start of the cal data in the TDM EEPROMImage
	unsigned char cVoltageMask;  //The bit mask used to set the A2D 
										  //in proper Voltage range
	unsigned char cDiagMask;	  //The bit mask used to the correct mux
	unsigned char cAddressMask;  //The bit mask used to select the currect channel
	struct CalStruct calData;
};

struct ChannelDataStruct
{ 
	unsigned long raw;
	int scaled;
	int output;
	unsigned int bAlarmed;
	unsigned int try_cnt;
	
	double mV;
	double nTemp;
};
/*
struct TDMStruct
{
	struct ChannelStruct channels;
	struct ChannelDataStruct ChannelData;
	unsigned int currentChannel;
};*/

#endif
