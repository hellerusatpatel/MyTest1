/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef TPO_H
#define TPO_H

#define TPO_50_HZ 10169
#define TPO_60_HZ 8474

#define TPO_FREQ_SELECT_BIT	0x80 //bit 7 on Port B
unsigned bSkipTPOTickle;
typedef  struct
{
   unsigned char  HI_BYTE;
   unsigned char  LO_BYTE;
}  INTBYTES;
                                                                                
typedef  union
{
   INTBYTES BYTE;
   unsigned int   UINT;
}  UINT_UNION;

//Global Function Definitions
void TPO_setChannel(unsigned int channel, unsigned int value);
void initialize_tpos( void );
void TPO_CheckInput( void );
void release_tpos( void );
unsigned int TPO_getChannel(unsigned int channel);
#endif
