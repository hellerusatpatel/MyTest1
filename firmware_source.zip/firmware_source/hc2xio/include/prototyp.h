/******************************
 *      prototyp.h
 *
 *      function prototypes for Heller project
 *
 ******************************/
 	/* the comment following each protype is the parameter description	*/
uchar   ADCsetup(uchar);
void	byte2ADC(uchar);		/* byte to send to A/d	*/
int		calc_cjc_temp(uchar, uchar);
void    calc_crc(uchar *, uchar);	/* uchar * is start of array, length of array	*/
void    process_msg(void);		/* function to process Modbus message	*/
uchar	conversion_done(uchar, long *);	/* which TDM, where to store if done, returns TRUE if convert done	*/
void	deselADC(void);			/* de-select the A/D converters	*/
void	deselEEPROM(void);		/* de-select the EEPROMs	*/
void	EEPROM_cmd(uchar, uint);	/* which EEPROM, command to send	*/
uchar	EEPROMdone(uchar);		/* which EEPROM, returns TRUE if done	*/
void	erase_EEPROM(uchar, uchar);	/* which EEPROM, address to erase	*/
void	flash_wr(uchar *, uchar *);	/* source and destination pointers	*/
uchar   io_read(uchar);			/* uchar is address to read, returns read value	*/
void    io_write(uchar, uchar);	/* data to write, address to put it	*/
uchar	is_volt_in_channel(uchar);	/* returns TRUE if channel is voltage input type */
uint	jsr_flash_id(void);		/* returns the FLASH device codes	*/
void	jsr_flash_wr(uchar *, uchar *, uint);	/* source address, destination addr, sector size	*/
void	load_eeprom_data(uchar);	/* which EEPROM to load	*/
void	make_TPO_table(uint);		/* which TPO channel to do	*/
void	mem_move(uchar * , uchar *,  uint); /* source ptr, dest ptr, length	*/
int 	mili_volts(uchar, uchar);	/* the TDM, the channel	*/
void	proc_a2d(void);				/* function to process A/D conversion	*/
//void 	proc_data(uchar, uchar);	/* TDM # and channel #	*/
ulong	readADCdata(void);		/* returns the A/D data in PortFlag mode, 	*/
ulong	readADCreg(uchar);		/* the register to read, returns the value	*/
uint	rd_EEPROM(uchar, uchar);	/* which EEPROM, EERPOM addr, returns the data	*/
int		searchtbl( double *, uint, double * );
void	selEEPROM(uchar);			/* which EEPROM to use	*/
void 	selADC(uchar);				/* which TDM to use	*/
void    set_coil_reg(uchar);		/* which coil register 	*/
void	mux_sel4_bit(uchar, uchar);	/* which TDM, if mux4 bit is set	*/
void	set_tdm_setting(uchar, uchar, uchar);	/* tdm, channel, value to set to*/
void	set_mux_addr(uchar, uchar);	/* which TDM, NEXT or desire channel	*/
void	st_conversion(uchar);		/* which A/D (TDM) to start	*/
double	volts(uchar, uchar);		/* which TDM, which channel	*/
void    wait(uint);
void	watchdog(void);
void	wr_EEPROM(uint, uchar, uchar);	/* data to write, which EEPROM, EEPROM address) */
void	wr_FLASH(void);
void	writeADCreg(uchar, ulong);
uchar	xor(uchar, uchar);
