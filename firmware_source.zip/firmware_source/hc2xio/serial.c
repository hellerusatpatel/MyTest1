/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2012, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <linux/tqueue.h>

//#include <string.h>
                                                                                
#include "hc2xio.h"
#include "serial.h"
#include "hc2xio_exports.h"
#include "hc1xcomm_local.h"
 
                                                                                
unsigned long calc_bauddiv(unsigned long rate);
void enable_tx_int( void );
void disable_tx_int( void );
void enable_rxt_int( void );
void disable_rxt_int( void );
void release_timer( void );
void start_timer( void );
void stop_timer( void );
void initialize_timer(unsigned int baud);

//Global Variable Declarations
char buff[] = {"Got It!\n\r"};
char *g_outBuff = NULL, *g_inBuff = NULL;
unsigned int *g_nRecCnt;
unsigned int nSendCnt = 0, g_bReceived = 0;
unsigned int inbuffCnt = 0;
unsigned int outbuffCnt = 0;
unsigned int bRec = 0;
struct tq_struct rx_task; //this is bottom half structure
struct tq_struct tx_task; //this is bottom half structure
struct tq_struct rxt_task; //this is bottom half structure
unsigned int rx_block = 0;
unsigned int tx_block = 0;
unsigned int rxt_block = 0;

static unsigned int bSerialEnabled = 0;


unsigned int serial_mask;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  rx_handler

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void rx_handler( void *unused )
{
	unsigned long lChar;
	unsigned char cChar;
	unsigned long empty;
	int i;

	if(!bRec)
		bRec = 1;
		
	empty = inl(UART2FR)&0x10;
	for(i = 0; i < 7 && !empty; i++)
	{ //8 chars fire interrupt so always leave on char
		lChar = inl(UART2DR);
		cChar = (unsigned char)lChar;
		if(g_outBuff != NULL)
		{
			g_outBuff[outbuffCnt++] = cChar;
		}
		empty = inl(UART2FR)&0x10;
	}
	outl(0, UART2ICR);
	rx_block = 0;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  tx_handler

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void tx_handler( void *unused )
{
	int i; 
	unsigned long full;

	if(g_inBuff != NULL) 
	{
		if(inbuffCnt < nSendCnt)
		{
			full = inl(UART2FR) & 0x20;
			for(i = 0; i < 16 && inbuffCnt < nSendCnt &&
						  !full; i++)
			{
				outl(g_inBuff[inbuffCnt++], UART2DR);
				full = inl(UART2FR) & 0x20;
			}
		}
		else
		{
			g_inBuff = NULL;
			nSendCnt = 0;
			inbuffCnt = 0;
			disable_tx_int();
		}
	}
	outl(0, UART2ICR);
	tx_block = 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  enable_tx_int

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void enable_tx_int( void )
{
	unsigned long junk = inl(UART2CR);
	inbuffCnt = 0;

	junk |= 0x00000020;
	outl(junk, UART2CR);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  disable_tx_int

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void disable_tx_int( void )
{
	unsigned long junk = inl(UART2CR);
	inbuffCnt = 0;

	junk &= ~(0x00000020);
	outl(junk, UART2CR);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  rxt_bottom_half

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void rxt_bottom_half( void *unused )
{

	unsigned long lChar;
	unsigned char cChar;
	unsigned long empty;
	int i;

		empty = inl(UART2FR)&0x10;
		for(i = 0; i < 16 && !empty; i++)
		{ 
			lChar = inl(UART2DR);
			cChar = (unsigned char)lChar;
			if(g_outBuff != NULL)
			{
				g_outBuff[outbuffCnt++] = cChar;
			}
			empty = inl(UART2FR)&0x10;
		}

		if(empty)
		{
			g_bReceived = 1;
			bRec = 0;
			g_outBuff = NULL;
			if(g_nRecCnt != NULL)
		{
				*g_nRecCnt= outbuffCnt;
		}
			g_nRecCnt = NULL;
			outbuffCnt = 0;
		}

		rxt_block = 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  rxt_handler

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void rxt_handler( int irq, void *dev_id, struct pt_regs *regs )
{
	unsigned long status = inl(UART2IIR);
	unsigned long lsrValue;


	if(status & 0x01)  //data available
	{
		lsrValue=inl(UART2RSR);
		if(lsrValue &0xf)//8 OE, 4 BE, 2 PE, 1 FE
		{
			outl(0, UART2ECR);
		}
	}
	if(status & 0x02) //Holding register empty
	{
		lsrValue=inl(UART2RSR);
		if(lsrValue &0xf)//8 OE, 4 BE, 2 PE, 1 FE
		{
			outl(0, UART2ECR);
		}
		else if(lsrValue !=0)
		{
			printk("lsr status2, %x",lsrValue);
		}
		rx_handler(NULL);
 
	}
	if(status & 0x04)  //Line Status
	{
		lsrValue=inl(UART2RSR);
		if(lsrValue &0xf)//8 OE, 4 BE, 2 PE, 1 FE
		{
			outl(0, UART2ECR);
		}
		outl(0, UART2ECR);
		tx_handler(NULL);
	}
	if(status & 0x08)  //modem status
	{
		lsrValue=inl(UART2RSR);
		if(lsrValue &0xf)//8 OE, 4 BE, 2 PE, 1 FE
		{
			outl(0, UART2ECR);
		}
		rxt_bottom_half(NULL);
		Hc1xComm_commIrqHandler(&hc1xComm);
}

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  initialize_uart

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void initialize_uart( void )
{
	unsigned long lBaudDiv = calc_bauddiv(115200);
	unsigned long lChar = (unsigned long)'a';
	unsigned long junk;
	int result;

	bSerialEnabled = 1;

	//set the system device configuration
	outl(0xAA, SYSCON_SWLOCK);
	junk = inl(SYSCON_DEVCFG);
	junk &= ~(0x10000000); //Set IonU2 to 0
	junk |= 0x00100000; //Set U2EN to 1
	outl(junk, SYSCON_DEVCFG);
	junk = inl(SYSCON_DEVCFG);

	junk = lBaudDiv&0x000000FF;
	outl(junk, UART2CR_L);
	junk = (lBaudDiv >> 8)&0x000000FF;
	outl(junk, UART2CR_M);
	outl(0x00000070, UART2CR_H); //FIFO Enabled
	outl(0x00000051, UART2CR); //
	outl(0, UART2ECR);

	//set up bottom halfs.
   rx_task.routine  = rx_handler;
   rx_task.data = NULL;
   tx_task.routine  = tx_handler;
   tx_task.data = NULL;
   rxt_task.routine  = rxt_bottom_half;
   rxt_task.data = NULL;
 
   result = request_irq(IRQ_UART2, rxt_handler, 0, "hc2xio", NULL);

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  release_uart


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void release_uart( void )
{
	bSerialEnabled = 0;
	free_irq(IRQ_UART2, NULL);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  calc_bauddiv

			
 GLOBALS:
 RETURNS:   unsigned long
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned long calc_bauddiv(unsigned long rate)
{
	unsigned long lClk = UART2_CLK;
	unsigned long lDiv;

	lDiv = (lClk/(16*rate)) - 1; 
	lDiv &= 0x0000FFFF;
	return lDiv;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  sendMessage

			
 GLOBALS:
 RETURNS:   unsigned int 
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned int sendMessage(unsigned int msgCnt, char *inBuff, char *outBuff,
								unsigned int *nRecCnt)
{
	unsigned int nRetVal = 0;
	int i;


	if(g_inBuff == NULL && bSerialEnabled)
 	{
		g_bReceived = 0;
		nRetVal = 1;
		nSendCnt = msgCnt;
		g_outBuff = outBuff;
		g_nRecCnt = nRecCnt;
		g_inBuff = inBuff;
		enable_tx_int();
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  disable_rxt_int

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void disable_rxt_int( void )
{
	free_irq(IRQ_UART2, NULL);
}

