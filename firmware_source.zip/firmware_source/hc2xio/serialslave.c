#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <linux/tqueue.h>
                                                                                
#include "hc2xio.h"
#include "serial.h"
#include "hc2xio_exports.h"
#include "hc1xcomm_local.h"
 
                                                                                
unsigned long calc_bauddiv(unsigned long rate);
void enable_tx_int( void );
void disable_tx_int( void );
void enable_rxt_int( void );
void disable_rxt_int( void );
void release_timer( void );
void start_timer( void );
void stop_timer( void );
void initialize_timer(unsigned int baud);

//Global Variable Declarations
char buff[] = {"Got It!\n\r"};
char *g_outBuff = NULL, *g_inBuff = NULL;
unsigned int *g_nRecCnt;
unsigned int nSendCnt = 0, g_bReceived = 0;
unsigned int inbuffCnt = 0;
unsigned int outbuffCnt = 0;
unsigned int bRec = 0;
struct tq_struct rx_task; //this is bottom half structure
struct tq_struct tx_task; //this is bottom half structure
struct tq_struct rxt_task; //this is bottom half structure
unsigned int rx_block = 0;
unsigned int tx_block = 0;
unsigned int rxt_block = 0;

static unsigned int bSerialEnabled = 0;

//#define DEBUG_ECHO_TX
//#define DEBUG_ECHO_RX

unsigned int serial_mask;

//void rx_handler( int irq, void *dev_id, struct pt_regs *regs )
void rx_handler( void *unused )
{
	unsigned long lChar;
	unsigned char cChar;
	unsigned long empty;
	int i;

	if(!bRec)
		bRec = 1;
		
	empty = inl(UART2FR)&0x10;
	for(i = 0; i < 7 && !empty; i++)
	{ //8 chars fire interrupt so always leave on char
		lChar = inl(UART2DR);
		cChar = (unsigned char)lChar;
		if(g_outBuff != NULL)
		{
			g_outBuff[outbuffCnt++] = cChar;
		}
		empty = inl(UART2FR)&0x10;
	}
	outl(0, UART2ICR);
	rx_block = 0;

	if(outbuffCnt>1)
	{
		if(g_outBuff[1]==0x04) //rread input register
		{
			if(outbuffCnt>=8)
				rxt_bottom_half(NULL);
		}
	}
}
                                                                                
//void tx_handler( int irq, void *dev_id, struct pt_regs *regs )
void tx_handler( void *unused )
{
	int i; 
	unsigned long full;

	if(g_inBuff != NULL) 
	{
		if(inbuffCnt < nSendCnt)
		{
			full = inl(UART2FR) & 0x20;
			for(i = 0; i < 16 && inbuffCnt < nSendCnt &&
						  !full; i++)
			{
				outl(g_inBuff[inbuffCnt++], UART2DR);
				full = inl(UART2FR) & 0x20;
			}
		}
		else
		{
			g_inBuff = NULL;
			nSendCnt = 0;
			inbuffCnt = 0;
			disable_tx_int();
		}
	}
	outl(0, UART2ICR);
	tx_block = 0;
}

void enable_tx_int( void )
{
	unsigned long junk = inl(UART2CR);
	inbuffCnt = 0;

	junk |= 0x00000020;
	outl(junk, UART2CR);
}

void disable_tx_int( void )
{
	unsigned long junk = inl(UART2CR);
	inbuffCnt = 0;

	junk &= ~(0x00000020);
	outl(junk, UART2CR);
}

void rxt_bottom_half( void *unused )
{

	unsigned long lChar;
	unsigned char cChar;
	unsigned long empty;
	int i;

		empty = inl(UART2FR)&0x10;
		for(i = 0; i < 16 && !empty; i++)
		{ 
			lChar = inl(UART2DR);
			cChar = (unsigned char)lChar;
			if(g_outBuff != NULL)
			{
				g_outBuff[outbuffCnt++] = cChar;
			}
			empty = inl(UART2FR)&0x10;
		}

		if(empty)
		{

#ifdef DEBUG_ECHO_RX
		int i;

		printk("hc2xio: Receiving: ");
		for(i = 0; i < outbuffCnt; i++)
			printk("[%x]",g_outBuff[i]);
		printk("\n");
#endif

#if 1
			g_bReceived = 1;
#endif
			bRec = 0;
			if(g_nRecCnt != NULL)
				*g_nRecCnt= outbuffCnt;
			Hc1xComm_commSlaveIrqHandler(&hc1xComm, outbuffCnt);

			g_outBuff = Hc1xComm_setRecieveBuffer(&hc1xComm); //pHc1xComm->qr[messageNo].responseMessage//NULL;
			g_nRecCnt = NULL;
			outbuffCnt = 0;
		}

		rxt_block = 0;
}

void rxt_handler( int irq, void *dev_id, struct pt_regs *regs )
{
   //outl(0, TIMER3CLEAR); /* Write Anything to Clear */
	unsigned long status = inl(UART2IIR);


/*	serial_mask = inl(GPIO_PBDR);
	serial_mask |= 0x1;
	outl(serial_mask, GPIO_PBDR);*/
	if(status&0x01)
	{
		rx_handler(NULL);
	}
	if(status & 0x02)
	{
		rx_handler(NULL);
		/*if(!rx_block)
		{
      	rx_block = 1;
      	queue_task(&rx_task, &tq_immediate);
      	mark_bh(IMMEDIATE_BH);
		}*/
 
	}
	if(status & 0x04)
	{
		tx_handler(NULL);
		/*if(!tx_block)
		{
      	tx_block = 1;
      	queue_task(&tx_task, &tq_immediate);
      	mark_bh(IMMEDIATE_BH);
		}*/
	}
	if(status & 0x08)
	{
		rxt_bottom_half(NULL);
		/*if(!rxt_block)
		{
      	rxt_block = 1;
      	queue_task(&rxt_task, &tq_immediate);
      	mark_bh(IMMEDIATE_BH);
		}*/
	}
/*	serial_mask = inl(GPIO_PBDR);
	serial_mask &= ~(0x1);
	outl(serial_mask, GPIO_PBDR);*/
}

void initialize_uart( void )
{
	unsigned long lBaudDiv = calc_bauddiv(115200);
	unsigned long lChar = (unsigned long)'a';
	unsigned long junk;
	int result;

	bSerialEnabled = 1;

	//set the system device configuration
	outl(0xAA, SYSCON_SWLOCK);
	junk = inl(SYSCON_DEVCFG);
	junk &= ~(0x10000000); //Set IonU2 to 0
	junk |= 0x00100000; //Set U2EN to 1
	outl(junk, SYSCON_DEVCFG);
	junk = inl(SYSCON_DEVCFG);

	junk = lBaudDiv&0x000000FF;
	outl(junk, UART2CR_L);
	junk = (lBaudDiv >> 8)&0x000000FF;
	outl(junk, UART2CR_M);
//	outl(0x00000060, UART2CR_H); //not enabling fifo disabled
	outl(0x00000070, UART2CR_H); //FIFO Enabled
	outl(0x00000051, UART2CR);
	outl(0, UART2ECR);

	//set up bottom halfs.
   rx_task.routine  = rx_handler;
   rx_task.data = NULL;
   tx_task.routine  = tx_handler;
   tx_task.data = NULL;
   rxt_task.routine  = rxt_bottom_half;
   rxt_task.data = NULL;
 


        //result = request_irq(25, rx_handler, 0, "hc2xio", NULL);
        //result = request_irq(26, tx_handler, 0, "hc2xio", NULL);
        result = request_irq(IRQ_UART2, rxt_handler, 0, "hc2xio", NULL);
printk("finished initializing uart\n");
}

void release_uart( void )
{
	//free_irq(25, NULL);
	//free_irq(26, NULL);
	bSerialEnabled = 0;
	free_irq(IRQ_UART2, NULL);
}

unsigned long calc_bauddiv(unsigned long rate)
{
	unsigned long lClk = UART2_CLK;
	unsigned long lDiv;

	lDiv = (lClk/(16*rate)) - 1; 
	lDiv &= 0x0000FFFF;
	return lDiv;
}

unsigned int sendMessage(unsigned int msgCnt, char *inBuff, unsigned int *nRecCnt)
{
	unsigned int nRetVal = 0;
	int i;
//	printk("hc2xio:sendMessage\n"
//		"msgCnt = %d\n"
	//	"outBuff = 0x%x\n"
//		"inBuff = 0x%x\n", msgCnt, inBuff);
//return;
	if(g_inBuff == NULL && bSerialEnabled)
 	{

#ifdef DEBUG_ECHO_TX
		printk("hc2x11io: Transmitting: ");
		for(i = 0; i < msgCnt; i++)
			printk("[%x]",inBuff[i]);
		printk("\n");
#endif
		g_bReceived = 0;
		nRetVal = 1;
		nSendCnt = msgCnt;
//		g_outBuff = outBuff;
		g_nRecCnt = nRecCnt;
		g_inBuff = inBuff;
		enable_tx_int();
	}

	return nRetVal;
}
//a test that justs frees the irq
void disable_rxt_int( void )
{
	free_irq(IRQ_UART2, NULL);
}
