//*****************************************************************************
// Copyright (c) 1999-2014 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2014 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: hc2xtdm.c
//
// Description: this is a device driver module to control the Analogic TDM modules
//
// This is a trade secret of iMagic, Inc. and Heller Industries, Inc.
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 20-Sep-04  JMR  Initial pre-release
// 14-Dec-14  FJN  Insert TDM eeprom error reporting from 5.5.0.18 release
//*****************************************************************************
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include "hc2xtdm.h"
#include "801defs.h"
#include "A2DCdefs.h"
#include "temp_table.h"
#include "tc_v_tbl.h"
#include "globals.h"
#include "tpo.h"
#include "eeprom.h"
#include "SPIdef.h"
#include "confcal.h"
#include "192103l.h"
#include "kttov.h"
#include "kvtot.h"
#include "system.h"
#include "hc2xio.h"
#include "hc2xwd.h"
#define ABORT_DANGER 1

const int eePromMemLoc[20] = {
	3,
	12,
	21,
	27,
	33,
	39,
	45,
	51,
	57,
	63,
	69,
	75,
	81,
	87,
	93,
	102,
	108,
	111,
	114,
	117	
};
const uchar chanl_start[21] = {0x00, 0x09, 0x12, 0x18, 0x1e, 0x24, 0x2a, 0x30, 0x36, 0x3c, 0x42,
0x48, 0x4e, 0x54, 0x5a, 0x63, 0x6c, 0x6f, 0x72, 0x75, 0x78}; //eeprom locations

const uchar offsetEELocation[4]={0x00, 0x06, 0xf, 0x18};//the memory is allocated in channel blocks, distributing the memory across 4 blocks
const uchar offsetEEEndLoc[4]={0x03, 0x0c, 0x15, 0x19};//these will end the four blocks, these memory locations will not be written, should be used in < test
//16 memory location for 16 external channels
const uchar modeEELoc[4] = {EEPROM_MODE1, EEPROM_MODE2, EEPROM_MODE3, EEPROM_MODE4};
//the below values are in project.h for consistency, define names differ
//const uchar modeEELoc1 = 0x22;
//const uchar modeEELoc2 = 0x23;
//const uchar modeEELoc3 = 0x27;
//const uchar modeEELoc4 = 0x28;
//const uchar checkbyteEELoc = 0x29; //not changing the stored version for the new eeprom map so the modules can be hooked into an old hc1x.
void load_eeprom_data(int which);
void FauxA2D(void);
void Tdm_faux_data(void);
void IntSensortoCJCData(char tdm);
void KVoltsToTemp(char channel, char tdm);
void KTempToVolts(char channel, char tdm);
void RawToVoltage(char channel, char tdm);

void proc_data(char tdm);
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Tdm_init

			

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int Tdm_init(int iConfigCall)
{	

	unsigned int iDiagLine = 0;	
	int i = 0;
	int iStarted = 0;
	int iTdm = 0;
	iEEPromUpload = 0;
	int iCurrentChannel = 0;
	int iA2DTriggered = 0;
	TDM[0].setup_valid = 0;
	TDM[1].setup_valid = 0;
	volatile TDM_STRUCT * ptrTDM;
	volatile TDM_STRUCT * ptrTDM2;
	struct ChannelStruct *ptrChannelParam;
	ptrTDM = &TDM[0];
	ptrTDM2 = &TDM[1];
	int iTrigger = 0;

	printk("Tdm_init iConfigCall=%d\n", iConfigCall);
	Tdm_initChannels();
	for(i = 0; i < EEPROM_NUM; i++)
	{
		eepromVersionError[i]=0;
		eepromCrcError[i]=0;
		load_eeprom_data(i);
	}
	iEEPromUpload = 1; //to populate the offset values for the (offset program only, realtime values applied in TDM code)
#if 0
	TDM[0].chanl_nmbr = 0;
	TDM[1].chanl_nmbr = 0;
	TDM[0].setup_valid = A2DCConfig(0);
	TDM[1].setup_valid = A2DCConfig(1);
#else
	for (i = 0; i < EEPROM_NUM; i++)
	{
		TDM[i].chanl_nmbr = 0;
		TDM[i].setup_valid = A2DCConfig(i);
	}
#endif
	for(i = 0; i < EEPROM_NUM; i++)
	{
		if(TDM[i].setup_valid != FALSE)
		{
			TDM[i].chanl_nmbr = 0;
			ptrChannelParam = &TDM[i].channels[TDM[i].chanl_nmbr];
			A2DCSetGainAndOffset(ptrChannelParam, i);
			SelectAtoDChannel(ptrChannelParam->cDiagMask, i, iDiagLine, ptrChannelParam->cVoltageMask);
			StartAtoD(i);
			iStarted = 1;
			if(iA2DTriggered == 0)
			{
				iA2DTriggered = 1;
   				if(iConfigCall)
				{
					//renable once
					iConfigCall = 0;
   					enable_tpo_timer(1);
					iTrigger = 1;
				}
				initialize_A2Dseq_timer();
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Tdm_beginAcquisition

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Tdm_beginAcquisition()
{
	struct ChannelDataStruct* ptrCurrentChannelStruct = NULL;
	struct ChannelStruct* ptrChannelParam = NULL;
	int i = 0;
	double temp1 = 0.0;
	double temp2 = 0.0;
	unsigned int iDiagLine = 0;
	unsigned int intChannelForADType;
	volatile TDM_STRUCT* ptrTDM = NULL;
	volatile TDM_STRUCT* ptrTDM2 = NULL;
	ptrTDM = &TDM[0];
	ptrTDM2 = &TDM[1];
	if(((int)TDM[0].setup_valid) != 0)
	{
		if(A2DCheckForCompletedRead(0))
		{
			intChannelForADType = TDM[0].chanl_nmbr;
			TDM[0].Channel[TDM[0].chanl_nmbr].bAlarmed = 0;
			ptrCurrentChannelStruct = &TDM[0].Channel[TDM[0].chanl_nmbr];
			A2DCRead(ptrCurrentChannelStruct, 0);

			TDM0_A2D[TDM[0].chanl_nmbr] = ptrCurrentChannelStruct->raw; //assign raw reading to Joe's buffer for processing
			if(TDM[0].chanl_nmbr <16)
			{
				VoltsBuffer[TDM[0].chanl_nmbr] = TDM0_A2D[TDM[0].chanl_nmbr];
			}
			TDM[0].chanl_nmbr++;
			if(TDM[0].chanl_nmbr ==NUMBER_A2D_INPUTS)
			{				
				TDM[0].chanl_nmbr = 0;
				IntSensortoCJCData(0);
				proc_data((char)0);
			}
			ptrChannelParam = &TDM[0].channels[TDM[0].chanl_nmbr];
			A2DCSetGainAndOffset(ptrChannelParam, 0);
			if(TDM[0].chanl_nmbr > 13) //set the diag line 
			{
				iDiagLine = 1;
			}
			SelectAtoDChannel(ptrChannelParam->cDiagMask, 0, iDiagLine, ptrChannelParam->cVoltageMask);					
			StartAtoD(0);
		}
		else
		{
			TDM[0].Channel[TDM[0].chanl_nmbr].bAlarmed = 1;
			TDM[0].chanl_nmbr++;
			if(TDM[0].chanl_nmbr == NUMBER_A2D_INPUTS)
			{
				TDM[0].chanl_nmbr = 0;
				IntSensortoCJCData(0);
				proc_data((char)0);
			}
			ptrChannelParam=&TDM[0].channels[TDM[0].chanl_nmbr];
			A2DCSetGainAndOffset(ptrCurrentChannelStruct, 0);
			intChannelForADType = TDM[0].chanl_nmbr;
			if(TDM[0].chanl_nmbr > 13) //set the diag line 
			{
				iDiagLine = 1;
			}
			SelectAtoDChannel(ptrChannelParam->cDiagMask, 0, iDiagLine, ptrChannelParam->cVoltageMask);
			StartAtoD(0);
		}
	}
	if(TDM[1].setup_valid != 0)
	{

		intChannelForADType = TDM[1].chanl_nmbr;	
		ptrCurrentChannelStruct = &TDM[1].Channel[TDM[1].chanl_nmbr];

		if(A2DCheckForCompletedRead(1))
		{
			TDM[1].Channel[TDM[1].chanl_nmbr].bAlarmed = 0;
			A2DCRead(ptrCurrentChannelStruct, 1);
			TDM1_A2D[TDM[1].chanl_nmbr] = ptrCurrentChannelStruct->raw; //assign raw reading to Joe's buffer for processing
			if(TDM[1].chanl_nmbr <16)
			{
				VoltsBuffer[TDM[1].chanl_nmbr+16] = TDM1_A2D[TDM[1].chanl_nmbr];
			}
		}
		else
		{
			TDM[1].Channel[TDM[1].chanl_nmbr].bAlarmed = 1;
		}
		TDM[1].chanl_nmbr++;
		if(TDM[1].chanl_nmbr ==NUMBER_A2D_INPUTS)
		{				
			TDM[1].chanl_nmbr = 0;
			IntSensortoCJCData(1);
			proc_data((char)1);
		}
		ptrChannelParam=&TDM[1].channels[TDM[1].chanl_nmbr];
		intChannelForADType = TDM[1].chanl_nmbr;
		A2DCSetGainAndOffset(ptrChannelParam, 1);
		if(TDM[1].chanl_nmbr > 13) //set the diag line 
		{
			iDiagLine = 1;
		}
		SelectAtoDChannel(ptrChannelParam->cDiagMask, 1, iDiagLine, ptrChannelParam->cVoltageMask);
		StartAtoD(1);
	}
	intChannelForADType = intChannelForADType + 5;
}

void Tdm_initChannels()
{
	unsigned int i, j;
	for(j=0; j<NUMBER_OF_TDMS; j++)
	{
		for(i = 0; i < MAX_CHANNEL_CNT; i++)
		{
			switch(i)
			{
				case THERMSTR0:
				case THERMSTR1:
				case VGND:
				case VSUPPLY:
				TDM[j].channels[i].calData.nMiliSelect =  0;
				break;

				default:
				TDM[j].channels[i].calData.nMiliSelect =  1;
				break;
			}
			TDM[j].channels[i].calData.nGain = 0x00800000; //nGain = 1
			TDM[j].channels[i].calData.nOffset =  0x00000000;			
			TDM[j].channels[i].nModeSelect =TYPE_J;
		
			TDM[j].Channel[i].try_cnt = 0;
			TDM[j].Channel[i].scaled =  0;
			TDM[j].Channel[i].mV = 0.0;
			TDM[j].Channel[i].nTemp =  0.0;
			TDM[j].Channel[i].bAlarmed = 0;
		}
		for(i; i<CJC2_CHANNEL; i++)
		{
			TDM[j].channels[i].nModeSelect =TYPE_K;
			TDM[j].channels[i].calData.nGain  = 0x00800000; //nGain = 1
			TDM[j].channels[i].calData.nOffset = 0x00000000;

			TDM[j].Channel[i].bAlarmed =  0;
			TDM[j].Channel[i].try_cnt = 0;
			TDM[j].Channel[i].scaled = 0;
			TDM[j].Channel[i].mV =  0.0;
			TDM[j].Channel[i].nTemp = 0.0;
		}
		for(i=0; i < 20; i++)
		{
			switch(i)
			{
				case 0:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  0;
				break;
				case 1:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask = 1;
				break;
				case 2:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask =  2;
				break;
				case 3:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask =  3;
				break;
				case 4:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask = 4;
				break;
				case 5:
				TDM[j].channels[i].cVoltageMask  = mV55;
				TDM[j].channels[i].cDiagMask = 5;
				break;
				case 6:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask =  6;
				break;
				case 7:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask = 8;
				break;
				case 8:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  9;
				break;
				case 9:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  10;
				break;
				case 10:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  11;
				break;
				case 11:
				TDM[j].channels[i].cVoltageMask = mV55;
				TDM[j].channels[i].cDiagMask =  12;
				break;
				case 12:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask = 13;
				break;
				case 13:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =14;
				break;
				case 14:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  0;
				break;
				case 15:
				TDM[j].channels[i].cVoltageMask =  mV55;
				TDM[j].channels[i].cDiagMask =  1;
				break;
				case 16:
				TDM[j].channels[i].cVoltageMask = V2_5;//vground
				TDM[j].channels[i].cDiagMask =  2;
				break;
				case 17:
				TDM[j].channels[i].cVoltageMask =  V5;
				TDM[j].channels[i].cDiagMask =  3;
				break;
				case 18:
				TDM[j].channels[i].cVoltageMask  = V2_5;
				TDM[j].channels[i].cDiagMask =  4;
				break;
				case 19:
				TDM[j].channels[i].cVoltageMask  = V2_5;
				TDM[j].channels[i].cDiagMask =  5;
				break;				

				default:
				break;
			}
		}
	}
	for(i=0; i<0x20; i++)
	{
		ChanlType[i] = eK_TYPE;
	}
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_returnData


 GLOBALS:
 RETURNS:   unsigned int
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned int TDM_returnData(int iTDM, int iChannel)
{
	unsigned int uiReturn = CONVRTR_FAIL;

	if(!TDM[iTDM].setup_valid)
	{
		uiReturn = (CONVERT_ERR + 1);
	}
	else if(TDM[iTDM].Channel[iChannel].bAlarmed)
	{
		uiReturn = (CONVERT_ERR + 1);
	}
	else if(TDM[iTDM].channels[iChannel].nModeSelect == 1)
	{
		RawToVoltage(iChannel, iTDM);
		uiReturn = EngUnitBuffer[((iTDM * 16) + iChannel)];
	}	
	else if(EngUnitBuffer [((iTDM * 16) +iChannel)] < 32767) //if bad do not consider offset correction
	{
		uiReturn = EngUnitBuffer[(iTDM * 16)+iChannel] + offsetBuffer[(iTDM * 16)+iChannel];
	}
	else
	{
		uiReturn = EngUnitBuffer[(iTDM * 16) + iChannel];
	}	
	return uiReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_returnData

	this will check the EEPROM data for a valid checksum, if checksum is valid,
 	* it loads the gain & offset tables. If checksum is invalid, it sets Gain 
 	* = 1.0, Offset = 0, for all gain settings
 GLOBALS:
 RETURNS:   unsigned int
 SEE ALSO:
------------------------------------------------------------------------*/
void load_eeprom_data(int which)
{
	unsigned short sum = 0;
	unsigned short tempSum = 0;
	unsigned short calSum = 0;
	uchar i = 0; 
	uchar n = 0; 
	uchar k = 0; 
	uchar uTe = 0;
	uchar ii = 0;
	uchar subLoc = 0;
	uchar curLoc = 0;
	uchar curOffset = 0;
	unsigned int uiEEPromVersion = 0;
	unsigned short  immMode = 0;
	UINT_UNION eeprom_dat[3];
	struct CalStruct* ptrEEPromData = NULL;
	DeSelectEESPI();
	InitSPI(16, SPICLK_11);
	uTe = 0;
	int iContinue = 1;

	printk("load_eeprom_data which=%d\n", which);
	// assume failure
	eepromVersionError[which]=1;
	eepromCrcError[which]=1;

	for(k=0; (k < 3 && iContinue); k++)
	{
		if ((sum = ReadTDMEE(EEPROM_VERSION, which)) == 0)	/* check the version*/
		{
			eepromVersionError[which]=0; //version passed
			for (n = 0; n < NUMBER_A2D_INPUTS; n++)
			{
				ptrEEPromData = &TDM[which].channels[n].calData;
				for (i = 0; (i < ((chanl_start[n+1]-chanl_start[n])/EEPROM_DATA_PER_CHANL)); i++)
				{
//the below read is somewhat of a fiction, some of these memory location are used for Heller offset and mode flagging.  see eeoffsetlocations
					eeprom_dat[0].UINT = ReadTDMEE( chanl_start[n]+(i*3), which);
					sum += eeprom_dat[0].UINT;	/* to calculate the checksum	*/
					eeprom_dat[1].UINT = ReadTDMEE( chanl_start[n]+(i*3)+1, which);
					sum += eeprom_dat[1].UINT;
					eeprom_dat[2].UINT = ReadTDMEE( chanl_start[n]+(i*3)+2, which);
					sum += eeprom_dat[2].UINT;
//bytes appear to be reversed read order from the hc1x verified by emulator 1_15_5
//switching hi bytes for low bytes
					/* now store the gain values	*/
					if(eePromMemLoc[n] == chanl_start[n] + (i*3))//only store the used gain and offset values
					{
						TDM[which].channels[n].calData.nGain = (0xff0000 & eeprom_dat[0].BYTE.LO_BYTE<<16) + (0xff00 & eeprom_dat[0].BYTE.HI_BYTE << 8 ) + eeprom_dat[1].BYTE.LO_BYTE;
					/* now store the offset values	*/
						TDM[which].channels[n].calData.nOffset = (0xff0000 & eeprom_dat[1].BYTE.HI_BYTE<<16) + (0xff00 & eeprom_dat[2].BYTE.LO_BYTE << 8 ) + eeprom_dat[2].BYTE.HI_BYTE;
					}
				}
			}
			uiEEPromVersion = ReadTDMEE(EEPROM_CALVERSION, which);
			if((0 <= uiEEPromVersion) && (uiEEPromVersion <= 5))//the unit has been programmed with temperature corrections
			{
//load temperature offsets and mode flags
				for (i = 0; i < 4; i++)
				{
					curLoc = offsetEELocation[i];
					while(curLoc < offsetEEEndLoc[i])
					{
						calSum += offsetBuffer[curOffset+which*16] = ReadTDMEE(curLoc, which);
						curOffset++;
						curLoc++;
					};
				}
//read mode information, stored in nibbles
				for(i = 0; i < 4; i++)
				{
					calSum += immMode = ReadTDMEE(modeEELoc[i], which );
					TDM[which].channels[i*4].nModeSelect = (immMode >> 12) & 0x0f;
 					TDM[which].channels[i*4+1].nModeSelect = (immMode >> 8) & 0x0f;
 					TDM[which].channels[i*4+2].nModeSelect = (immMode >> 4) & 0x0f;
					TDM[which].channels[i*4+3].nModeSelect = immMode & 0x0f; 
				}
				for(i = 0; i < 16; i++)
				{
					//print out so Heller can observe if neccessary
					printk("TDM: %d, Channel %d, Mode: %d(k=0, voltage = 1)\n", which, i, TDM[which].channels[i].nModeSelect);
					if(TDM[which].channels[i].nModeSelect == VOLT_INPUT)//process as voltage
					{
						ChanlType[(i+(which*16))] = eMV70;
					}
				}

			}
			for (n = chanl_start[NUMBER_A2D_INPUTS]; n < EEPROM_VERSION; n++)
			{
				sum += ReadTDMEE( n, which);		/* read all the locations */
			}
			/* see if the EEPROM checksum matches mine	*/
			if (sum == ReadTDMEE( EEPROM_CHECKSUM, which))
			{
				eepromCrcError[which]=0;

				printk("checksum %x\n", sum);
				printk("checksum passed %d, stored %x\n", which, ReadTDMEE( EEPROM_CHECKSUM, which));
				printk("error %d, crc %d\n",eepromVersionError[which],eepromCrcError[which]);

				iContinue = 0;
			}
			else
			{
				printk("checksum failed %d, calc %x\n", which, sum);
				printk("which :%d stored cs %x", which, ReadTDMEE( EEPROM_CHECKSUM, which)); 
				eepromCrcError[i]=1;
			}
		}
	}
	if(iContinue)
	{
		/* if the checksum is bad set gain = 1.0, offset = 0	*/
		for (n = 0; n < NUMBER_A2D_INPUTS; n++)
		{
			for (i = 0; i < (chanl_start[n+1]-chanl_start[n])/EEPROM_DATA_PER_CHANL; i++)
			{
				TDM[which].channels[n].calData.nGain = 0x800000l;
				/* now store the offset values	*/
				TDM[which].channels[n].calData.nOffset = 0;

			}
		}/*If the checksum is bad set the modes and offsets back to default*/
		for(i=0; i<16; i++)
		{
			TDM[which].channels[i].nModeSelect = TYPE_K;
			offsetBuffer[i+which*16] = 0;
		}
	}
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  proc_data()

 			This function is called to convert the doubleing point
			converted analog inputs into a temperature. 

 RETURNS:	This function returns a doubleing point value in degrees C

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void proc_data(char tdm)
{   

	char i = 0;
	char temp = 0;
	for(i=0;i<0x10;i++)
	{
		if(!tdm)
		{
			temp = ChanlType[i];
		}
		else
		{
			temp = ChanlType[i+CHANNELOFFSET];
		}
		if(temp == eK_TYPE)
		{
			KTempToVolts(i, tdm);     
			KVoltsToTemp(i, tdm); 
		}
		else
		{
			if(!tdm)
			{
				EngUnitBuffer[i] = VoltsBuffer[i]/1000;
			}
			else
			{
				EngUnitBuffer[i+CHANNELOFFSET] = VoltsBuffer[i]/1000;
			}
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  Tdm_faux_data()

 			This function is called to create a static table of A2D inpputs
			to statically test the thermocouple algorithms. 

 RETURNS:	

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void Tdm_faux_data(void)
{
	int iTDM = 0;
	int iChannel = 0;
	for(iTDM = 0; iTDM < NUMBER_OF_TDMS; iTDM++)
	{ 
		TDM[iTDM].setup_valid = 1;
		for(iChannel = 0; iChannel <16; iChannel++)
		{
			TDM[iTDM].Channel[iChannel].bAlarmed = 0;
			EngUnitBuffer[(iTDM * 16) + iChannel] = 15;
		}
	}
	return;
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  IntSensortoCJCData()

	 
	This function calculates the resistance and then the temperature of all the 
	channels of each tdm. It creates the appropriate gradient accross the channels
	by the following formula;

	incremental difference = (Second Thermistor - First Thermistor)/ 15
	this difference is cummed on each of the channels 2 through 15. The 1st and
	last channel are set to the value associated with the proximate thermistor used to
	derive the incremental difference.

	
	The resistance of the thermistor is calculated (Rt) by the following formula:
	Rt = (((VREF - Vgnd) * RD) - ((Vo - Vgnd) * RD)) / (Vo - Vgnd)
	where:	VREF = supply voltage to thermister & Rd (+2.50V)
	 		Vgnd = voltage at grou//		printk("VInput %d\n", VInput);
nd
	 		RD = (6490.0) value of voltage divider resister with the thermister
	 		Vo = thermister number from A/D

	The temperature is derived by using the resistance and doing a linear interpolation 
	between the values in resistance and temperature tables for this thermistor 
	the themistor is a honeywell/fenwal ntc #192-103LET-A01 (APN 12-990006)
	and conforms to fenwall R-T curve #16.

 RETURNS:	

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void IntSensortoCJCData(char tdm)
{

	unsigned int i = 0;
	unsigned int j = 0;
	int temp_grad = 0;
	unsigned int index1 = 0;
	unsigned int Tindex = 0;
	int Vo1 = 0; 
	int	Vo2 = 0; 
	int	Vgrnd = 0;
	int temp1 = 0; 
	int	temp2 = 0;
	int	temp3 = 0; 
	int VInput = 0; 
	int	Vground = 0; 
	int	Rt1 = 0; 
	int	Rt2 = 0;
	int Minus40 = 0; 
	int	Plus70 = 0; 
	int spread = 0; 
	int itemp1 = 0; 
	int itemp2 = 0;
	int itemp3 = 0;
	int temperature1 = 0; 
	int temperature2 = 0;
	int TestVal1 = 0;


	if(!tdm)
	{
		Vo1 = TDM0_A2D[0x13];
		Vo2 = TDM0_A2D[0x12];
		Vgrnd = TDM0_A2D[0x10];	
	}
	else
	{
		Vo1 = TDM1_A2D[0x13];
		Vo2 = TDM1_A2D[0x12];
		Vgrnd = TDM1_A2D[0x10];
	}
	
	// make sure they are in range
	Minus40 = 0x60DDF; // raw voltage at -40 degrees
	Plus70 = 0xFBFA48; // raw voltage at +70 degrees

	if(Vo1 < 0x60DDF || Vo1 > 0xFBFA48 || 
		Vo2 < 0x60DDF || Vo2 > 0xFBFA48)
	{
			
		for(i=0;i<0x10;i++)
		{
			if(!tdm)
			{
				ChanlStatus[i] = BADTDM;
			}
			else
			{
				ChanlStatus[i+CHANNELOFFSET] = BADTDM;
			}
		}

		return;

	}
	else
	{
		for(i=0;i<0x10;i++)
		{
			if(!tdm)
			{
				ChanlStatus[i] = GOODCHAN;
			}
			else
			{
				ChanlStatus[i+CHANNELOFFSET] = GOODCHAN;
			}
		}
		// Calculate the first Thermistor resistance
		temp1 = Vo1 >> 4;
		TestVal1 = temp1*2500;
		VInput = TestVal1 >> 19;
		temp1 = (2500 /*- Vground*/) * 649000;
		temp2 = (VInput /*- Vground*/) * 649000;
		temp3 =  VInput/* - Vground*/;
		Rt1 = (temp1 - temp2) / temp3; 		

		// now do the linear interp for R1
		index1=0;
  		for(i=1;i<CJCMAXINDEX + 1;i++)
		{        
     			if(CJCResTable[i] > Rt1)
     			{
     				index1 = i;
     				break;
     			}     
		}   
		if(!index1)
		{
			for(i=0;i<0x10;i++)
			{
				if(!tdm)
				{
					ChanlStatus[i] = BADCHAN;
				}
				else
				{
					ChanlStatus[i+CHANNELOFFSET] = BADCHAN;
				}
				return;
			}

		}
 		
		// get the index value
		Tindex = index1-1;
		itemp1 = Rt1 - CJCResTable[Tindex];	
		spread = CJCResTable[Tindex +1] - CJCResTable[Tindex];	
		itemp2 = (itemp1 * 100)/ spread;
		itemp3 = itemp2 + (Tindex * 100);

		temperature1 = 7000 + (itemp3 * -2);

		if(!tdm)
		{
			Thermistor[0] = temperature1; 
		}
		else
		{
			Thermistor[2] = temperature1; 
		}

		// Calculate the second Thermistor resistance
		temp1 = Vo2 >> 4;
		TestVal1 = temp1*2500;
		VInput = TestVal1 >> 19;
		temp1 = (2500 /*- Vground*/) * 649000;
		temp2 = (VInput /*- Vground*/) * 649000;
		temp3 =  VInput/* - Vground*/;
		Rt2 = (temp1 - temp2) / temp3; 		

		// now do the linear interp for R1
		index1=0;
  		for(i=1; i<CJCMAXINDEX + 1;i++)
		{        
     			if(CJCResTable[i] > Rt2)
     			{
     				index1 = i;
     				break;
     			}     
		}   
 		// if we don't find a value error and return
		if(!index1)
		{
			for(i=0;i<0x10;i++)
			{
				if(!tdm)
				{
					ChanlStatus[i] = BADCHAN;
				}
				else
				{
					ChanlStatus[i+CHANNELOFFSET] = BADCHAN;
				}
				return;
			}
		}
 		
		// get the index value
		Tindex = index1-1;
		itemp1 = Rt2 - CJCResTable[Tindex];	
		spread = CJCResTable[Tindex +1] - CJCResTable[Tindex];	
		itemp2 = (itemp1 * 100)/ spread;
		itemp3 = itemp2 + (Tindex * 100);

		temperature2 = 7000 + (itemp3 * -2);

		if(!tdm)
		{
			Thermistor[1] = temperature2; 
		}
		else
		{
			Thermistor[3] = temperature2; 
		}
		if(!tdm)
		{

			temp_grad=(Thermistor[1]-Thermistor[0])/14;
			for (i = 0, j=0; i < TDM_TC_INPUTS; i+=2, j+=2)
			{
				CJtemp[j] = Thermistor[0]+(i*temp_grad);
				CJtemp[j+1] = CJtemp[j];
			}
			
			CJtemp[0xe] = Thermistor[1];
			CJtemp[0xf] = Thermistor[1];
		}
		else
		{
			temp_grad=(Thermistor[3]-Thermistor[2])/14;
			for (i = 0, j=0; i < TDM_TC_INPUTS; i+=2, j+=2)
			{
				CJtemp[j+CHANNELOFFSET] = Thermistor[2]+(i*temp_grad);
				CJtemp[j+1+CHANNELOFFSET] = CJtemp[j+CHANNELOFFSET];
			}
			CJtemp[0x1e] = Thermistor[3];
			CJtemp[0x1f] = Thermistor[3];
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  KVoltsToTemp()

 
 RETURNS:	

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void KVoltsToTemp(char channel, char tdm)
{   
	int temperature = 0;
	int TopMv = 0; 
	int LowMv = 0; 
	int millivolts = 0;
	int temp1 = 0; 
	int temp2 = 0;
	int temp3 = 0; 
	int temp4 = 0; 
	int index = 0; 
	int i = 0;
	int fiftyfourmV = 0; 
	int minus1pt5 = 0;
	char Stat = 0;
  
    /* get millivolts  */
	if(!tdm)
	{
		millivolts = VoltsBuffer[channel] + CJC[channel];   /* add cjc voltage */
	}
	else
	{
		millivolts = VoltsBuffer[channel+CHANNELOFFSET] + CJC[channel+CHANNELOFFSET];   /* add cjc voltage */
	}
	 /* check for thermocouple break or bad channel flag */
	if(!tdm)
	{
		Stat = ChanlStatus[channel];
	}
	else 
	{
		Stat = ChanlStatus[channel+CHANNELOFFSET];
	}
	fiftyfourmV = 0x615A24;
	minus1pt5 = -177224;

	if(millivolts > fiftyfourmV || millivolts < minus1pt5 ||
		Stat == BADTDM)
	{  
		if(!tdm)
		{
			EngUnitBuffer[channel] = 32767;
			ChanlStatus[channel] = BADCHAN;
		}
		else
		{
			EngUnitBuffer[channel+CHANNELOFFSET] = 32767;
			ChanlStatus[channel+CHANNELOFFSET] = BADCHAN;
		}

		return;
	}
	else
	{	

		if(!tdm)
		{	
			ChanlStatus[channel] = GOODCHAN;
		}
		else
		{
			ChanlStatus[channel+CHANNELOFFSET] = GOODCHAN;
		}
		// now do the linear interp for R1
		index=0;
  		for(i=1; i<256; i++)
		{  

     		if(InputVoltsTable[i] > millivolts)
     		{
     			index = i;
     			break;
     		}     
		}   
 		// if we don't find a value error and return
		if(!index)
		{
			if(!tdm)
			{
				ChanlStatus[channel] = BADCHAN;
			}
			else
			{
				ChanlStatus[channel+CHANNELOFFSET] = BADCHAN;
			}
			return;
		}		

 		TopMv = InputVoltsTable[index];
		LowMv = InputVoltsTable[index-1];  
		temp1 = millivolts-LowMv; 
		temp2 = TopMv - LowMv;
		temp3 = TemperatureLITable[index] - TemperatureLITable[index-1]; 
		temp4 = temp3*temp1/temp2;


		temperature = temp4 + TemperatureLITable[index-1];
		/* store the result */
		if(!tdm)
		{
			EngUnitBuffer[channel] = temperature; 
		}
		else
		{
			EngUnitBuffer[channel + CHANNELOFFSET] = temperature; 
		}
	}
} 

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  KTempToVolts()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void KTempToVolts(char channel, char tdm)
{

	int temperature = 0; 
	int	TopTp = 0; 
	int	LowTp = 0; 
	int	millivolts = 0;
	int temp1 = 0; 
	int	temp2 = 0; 
	int	temp3 = 0; 
	int	temp4 = 0; 
	int	index = 0; 
	int	i = 0;
	int Minus40 = 0; 
	int	Plus70 = 0;
	char Stat = 0;
   
    /* get millivolts  */
	if(!tdm)
	{
		temperature = CJtemp[channel];   /* add cjc voltage */
	}
	else
	{
		temperature = CJtemp[channel+CHANNELOFFSET];   /* add cjc voltage */
	}
	 
	/* check for thermocouple break or bad channel flag */
	if(!tdm)
	{
		Stat = ChanlStatus[channel];
	}
	else 
	{
		Stat = ChanlStatus[channel+CHANNELOFFSET];
	}
	Plus70 = 7000;
	Minus40 = -4000;

	if((temperature > 7000) || temperature < Minus40 || (Stat))
	{   
		if(!tdm)
		{
			EngUnitBuffer[channel] = 32767;
			CJC[channel] = 0x7fffff;
			ChanlStatus[channel] = BADCHAN;
		}
		else
		{
			EngUnitBuffer[channel+CHANNELOFFSET] = 32767;
			CJC[channel] = 0x7fffff;
			ChanlStatus[channel+CHANNELOFFSET] = BADCHAN;
		}
		return;
	}
	else
	{	

		// now do the linear interp for temperatures
		index=0;
  		for(i=1;i<256;i++)
		{        
     		if(CJCInputTTbl[i] > temperature)
     		{
     			index = i;
     			break;
     		}     
		}   
 		// if we don't find a value error and return
		if(!index)
		{
			if(!tdm)
			{
				ChanlStatus[channel] = BADCHAN;
			}
			else
			{
				ChanlStatus[channel+CHANNELOFFSET] = BADCHAN;
			}
			return;
		}		

		//TopTp, LowTp,
 		TopTp = CJCInputTTbl[index];
		LowTp = CJCInputTTbl[index-1];  
		temp1 = temperature-LowTp; 
		temp2 = TopTp - LowTp;
		temp3 = CJCOutputVTbl[index] - CJCOutputVTbl[index-1]; 
		temp4 = temp3*temp1/temp2;


		millivolts = temp4 + CJCOutputVTbl[index-1];
		/* store the result */
		if(!tdm)
		{
			CJC[channel] = millivolts; 
		}
		else
		{
			CJC[channel+CHANNELOFFSET] = millivolts; 
		}		             
	}
}  


/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  FauxA2D()

 			This function is called to create a static table of A2D inpputs
			to statically test the thermocouple algorithms. 

 RETURNS:	void

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void FauxA2D(void)
{
		unsigned int iCurrentChannel = 0;
		unsigned int i = 0; 
		unsigned int j = 0;

		for(iCurrentChannel = 0; iCurrentChannel < 20; iCurrentChannel++)
		{
			switch(iCurrentChannel)
			{
				case 	0x13:			/* this one in near channels 0 & 1	*/
					TDM1_A2D[iCurrentChannel] = 0x2fffff; //CJCValue;//3145727;
					break;
				case	0x12: //THERMSTR1:	
					TDM1_A2D[iCurrentChannel] = 0x200000; //CJCValue;
					break;
				case	0x10: //VGND:
					TDM1_A2D[iCurrentChannel] = 0;
					break;
				case	0x11: //VSUPPLY:
					TDM1_A2D[iCurrentChannel]= 0;
					break;
				default:
					TDM1_A2D[iCurrentChannel] = /*A2DVal;*/ 0x3fffff;
					break;
			}
		}
		for(i=0x0; i<0x20; i++)
		{
			ChanlType[i] = eK_TYPE;
		}

		j = 0x10;
		for(i=0x0; i<0x10; i++)
		{
			VoltsBuffer[j] = TDM1_A2D[i];
			j++;
		}
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_setOffsets()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void TDM_setOffsets(int iTDM, int iIndex, short wOffset)
{
	offsetBuffer[(iTDM * 16)+iIndex] = wOffset;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_setInputType()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void TDM_setInputType(int iLocation, short iInputStyle)
{
	int iWhichTDM = 0;
	int iWChannel = 0;
	int i = 0;
	if(iLocation <= 39) //only store infomation on thermal zones
	{
		if(iLocation < 24)
		{
			iWhichTDM = 0;
			iWChannel = iLocation;
		}
		else
		{
			iWhichTDM = 1;
			iWChannel = iLocation - 24;
			iLocation = iLocation - 8; //to make one contigous block from 0 to 31 for assignment
		}
		TDM[iWhichTDM].channels[iWChannel].nModeSelect = iInputStyle;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_commitOffsetsToEEPROM()

 
 RETURNS:	int 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
int TDM_commitOffsetsToEEPROM()
{
	unsigned short immMode = 0;
	unsigned short checkSum = 0;
	uchar iCT = 0; 
	uchar i = 0;  
	uchar j = 0;  
	uchar k = 0;  
	uchar n = 0; 
	uchar curLoc = 0; 
	uchar curOffset = 0; 
	sch_suspendTimer(0);
	enable_tpo_timer(0);
	InitSPI(16, SPICLK_11);                                                                                                

	for(iCT = 0; iCT < 2; iCT++)
	{
		TDM_writeMemory(EEPROM_CALVERSION, 0, iCT);
      	checkSum = 0;
      	curOffset = 0;
      	for (i = 0; i < 4; i++)
      	{
           curLoc = offsetEELocation[i];
           while(curLoc < offsetEEEndLoc[i])
           {
            TDM_writeMemory(curLoc, offsetBuffer[curOffset + iCT * 16], iCT);
            curLoc++;
            curOffset++;
           };
      	}
                                            
      	for(i = 0; i < 4; i++)
      	{
           immMode = 0;
           for(j = 0; j < 4; j++)
           {
				if(j)
				{
					immMode = (immMode << 4) & 0xfff0;
				}
				if(TDM[iCT].channels[i*4+j].nModeSelect == VOLT_INPUT)//For now only two types are allowed, volt and k
				{
					immMode += TDM[iCT].channels[i*4+j].nModeSelect & 0x0f;
				}
			}
			TDM_writeMemory(modeEELoc[i], immMode, iCT);
      	}
		TDM_writeMemory(EEPROM_CALVERSION, 5, iCT);//using 5, this will allow for 0-4 to be used for future version processing while remaining backward compatible
 
//enter all data above here, checksum calculation and assignment below 
        for (n = 0; n < EEPROM_VERSION; n++)
		{
			checkSum += ReadTDMEE( n, iCT);     /* read all the locations */
		}
		TDM_writeMemory(EEPROM_CHECKSUM, checkSum, iCT);
	}
	Tdm_init(1);
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  Tdm_processHc2xEEProm()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void Tdm_processHc2xEEProm()
{
	int i = 0;
	int iMemPassedCrc = 0;
	int iWhichTDM = 0;
	int iWChannel = 0;
	bAccessingEEPROM = 1;
	char charData = 0;
	for(i = 0; i < 10000 && bAccessingSPI; i++);
	if ( bAccessingSPI )
	{
		bAccessingEEPROM = 0;
	}
	else
	{
		iMemPassedCrc = GetConfig();
		bAccessingEEPROM = 0;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_fresh_memory()

 
 RETURNS:	int 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
int TDM_fresh_memory()
{
	int iReturn = iEEPromUpload;
	iEEPromUpload = 0;
	return iReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_getOffsets()

 
 RETURNS:	short 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
short TDM_getOffsets(int iIndex)
{
	return offsetBuffer[iIndex];	
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_getInputType()

 
 RETURNS:	short 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
short TDM_getInputType(int iLocation)
{
	int iWhichTDM;
	int iWChannel;
	short wReturn;
	if(iLocation > 39)
		return 0;
	if(iLocation < 24)
	{
		iWhichTDM = 0;
		iWChannel = iLocation;
	}
	else
	{
		iWhichTDM = 1;
		iWChannel = iLocation - 24;
		iLocation = iLocation - 8; //to make one contigous block from 0 to 31 for assignment
	}
	wReturn = TDM[iWhichTDM].channels[iWChannel].nModeSelect;
	wReturn = wReturn &0xff;
	return wReturn;

}

short TDM_getMem(int iLocation, int iTDM)
{
	if (iLocation < EEPROM_SIZE && iTDM < TDM_NUM)
	{
		return EEpromMapx[iLocation][iTDM];
	}
	return 0;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  TDM_writeMemory()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void TDM_writeMemory(int addr, unsigned int data, unsigned int which)
{
	DeSelectEESPI();
	WriteEnableTDMEE(TRUE, which);
	WriteTDMEE(addr, data,  which);
	WriteEnableTDMEE(FALSE, which);
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
 FUNCTION:  RawToVoltage()

 
 RETURNS:	void 

 SEE ALSO:  
------------------------------------------------------------------------*/ 
void RawToVoltage(char channel, char tdm)
{
	uchar pos= (tdm * 16)+channel;
	long long lBuf = 0;
	lBuf = VoltsBuffer[pos] / 0x10;
	lBuf=lBuf*7150;
	lBuf=lBuf>>19;
	EngUnitBuffer[pos]=(long)lBuf;
	return;
}

int TDM_versionError(int which)
{
	if(which<EEPROM_NUM)
		return eepromVersionError[which];
	return 1;
}
int TDM_crcError(int which)
{
	if(which<EEPROM_NUM)
		return eepromCrcError[which];
	return 1;

}
void Tdm_writeEEPromBuffer(unsigned int value, unsigned int location)
{
	//printk("in write\n");
	if(location<EEPROM_SIZE)
	{
		EEpromMap[location]=value;
	}
}
