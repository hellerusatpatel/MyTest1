/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>

#include "hc2xio.h"
#include "encoder.h"

#include "hc2xmem.h"

//Global Variable Declarations
unsigned int nEncoderDir[ENCODER_CNT];
long nEncoderPosn[ENCODER_CNT];
unsigned int speed[ENCODER_CNT];

//******************************************************************************
// initialize_encoder
//
// Abstract:
//	High Level Function called from init_module used to set the startup
//	conditions of the encoders.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void initialize_encoder( void )
{
	unsigned int i;

	for(i = 0; i < 4; i++)
	{
		nEncoderPosn[i] = 0;
		speed[i] = 0;
	}
	g_encoderCount = 0;
   request_irq(59, encoder_handler, 0, "hc2xio", NULL);
}

//******************************************************************************
// release_encoder
//
// Abstract:
//	Frees GPIO interrupt.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void release_encoder( void )
{
	free_irq(59, NULL);
}

//******************************************************************************
// tpo_handler
//
// Abstract:
//	Interrupt function that reads the encoders when the move.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void encoder_handler( int irq, void *dev_id, struct pt_regs *regs )
{
   unsigned int input;
	unsigned int intmask1, intmask2;
	unsigned int intClearMask1, intClearMask2 = 0;
	unsigned int intEdge;

	intmask1 = inl(GPIO_INTSTATUSA);
	intmask2 = inl(GPIO_INTSTATUSB);
   outl(ENCODER0_B | ENCODER1_B, GPIO_AEOI); /* Clear the interrupt */
   outl(ENCODER2_B | ENCODER3_B, GPIO_BEOI); /* Clear the interrupt */
                                                                                
                                                                                
  	g_encoderCount++;
	input = inl(GPIO_PADR);
	input = ~input;
//	intmask = inl(GPIO_INTSTATUSA);

	//Now walk the interrupt mask
	if(intmask1 & ENCODER0_B)
	{
		intEdge = inl(GPIO_AINTTYPE2);
		if(intEdge & ENCODER0_B)
			intEdge &= ~ENCODER0_B;
		else
			intEdge |= ENCODER0_B;
		outl(intEdge, GPIO_AINTTYPE2);

		speed[0]++;
		if(input & ENCODER0_B) //Phase B is high
		{
			if(input & ENCODER0_A) //Phase A is high
			{
					nEncoderPosn[0]++;
			}
			else
			{
					nEncoderPosn[0]--;
			}
		}
		else //Phase B is low
		{
			if(input & ENCODER0_A) //Phase A is high
			{
					nEncoderPosn[0]--;
			}
			else
			{
					nEncoderPosn[0]++;
			}
		}
		intClearMask1 |= ENCODER0_Z;
//     	outl(ENCODER0_Z, GPIO_AEOI); /* Clear the interrupt */
	}
	if(intmask1 & ENCODER1_B)
	{
		intEdge = inl(GPIO_AINTTYPE2);
		if(intEdge & ENCODER1_B)
			intEdge &= ~ENCODER1_B;
		else
			intEdge |= ENCODER1_B;
		outl(intEdge, GPIO_AINTTYPE2);

		speed[1]++;
		if(input & ENCODER1_B) //Phase B is high
		{
			if(input & ENCODER1_A) //Phase A is high
			{
					nEncoderPosn[1]++;
			}
			else
			{
					nEncoderPosn[1]--;
			}
		}
		else //Phase B is low
		{
			if(input & ENCODER1_A) //Phase A is high
			{
					nEncoderPosn[1]--;
			}
			else
			{
					nEncoderPosn[1]++;
			}
		}
		intClearMask1 |= ENCODER1_Z;
//     	outl(ENCODER1_Z, GPIO_AEOI); /* Clear the interrupt */
	}
	input = inl(GPIO_PBDR);
	input = ~input;
//	intmask = inl(GPIO_INTSTATUSB);
//	printk("PortB = 0x%x, IntStatusB = 0x%x\n", input, intmask);
	if(intmask2 & ENCODER2_B)
	{
		intEdge = inl(GPIO_BINTTYPE2);
		if(intEdge & ENCODER2_B)
			intEdge &= ~ENCODER2_B;
		else
			intEdge |= ENCODER2_B;
		outl(intEdge, GPIO_BINTTYPE2);

		speed[2]++;
//		printk("speed2 = %d\n", speed[2]);
		if(input & ENCODER2_B) //Phase B is high
		{
			if(input & ENCODER2_A) //Phase A is high
			{
					nEncoderPosn[2]++;
			}
			else
			{
					nEncoderPosn[2]--;
			}
		}
		else //Phase B is low
		{
			if(input & ENCODER2_A) //Phase A is high
			{
					nEncoderPosn[2]--;
			}
			else
			{
					nEncoderPosn[2]++;
			}
		}
		intClearMask2 |= ENCODER2_Z;
//        	outl(ENCODER2_Z, GPIO_BEOI); /* Clear the interrupt */
	}
	if(intmask2 & ENCODER3_B)
	{
		intEdge = inl(GPIO_BINTTYPE2);
		if(intEdge & ENCODER3_B)
			intEdge &= ~ENCODER3_B;
		else
			intEdge |= ENCODER3_B;
		outl(intEdge, GPIO_BINTTYPE2);

		speed[3]++;
		if(input & ENCODER3_B) //Phase B is high
		{
			if(input & ENCODER3_A) //Phase A is high
			{
					nEncoderPosn[3]++;
			}
			else
			{
					nEncoderPosn[3]--;
			}
		}
		else //Phase B is low
		{
			if(input & ENCODER3_A) //Phase A is high
			{
					nEncoderPosn[3]--;
			}
			else
			{
					nEncoderPosn[3]++;
			}
		}
		intClearMask2 |= ENCODER3_Z;
//        	outl(ENCODER3_Z, GPIO_BEOI); /* Clear the interrupt */
	}
//   outl(intClearMask1, GPIO_AEOI); /* Clear the interrupt */
//   outl(intClearMask2, GPIO_BEOI); /* Clear the interrupt */
}
