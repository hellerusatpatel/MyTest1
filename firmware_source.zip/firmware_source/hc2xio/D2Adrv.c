/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/tqueue.h>

#include "hc2xio.h"
#include "tpo.h"
#include "hc2xmem.h"
#include "D2Adrv.h"
#include "MODBus.h"
#include "SPIdef.h"

void D2A_WriteChannel(unsigned int channel, unsigned int value);

unsigned int D2A_regs[D2A_COUNT];
unsigned int D2A_in_regs[D2A_COUNT];

void D2A_init( void )
{
	unsigned int i;

	for(i = 0; i < D2A_COUNT; i++)
	{
		D2A_regs[i] = D2A_in_regs[i] = 0;
	}
}

void D2A_update( void )
{
	unsigned int i;

	for(i = 0; i < D2A_COUNT; i++)
	{
		if(D2A_regs[i] != D2A_in_regs[i])
			D2A_WriteChannel(i, D2A_in_regs[i]);
	}
}

void D2A_SetChannel(unsigned int channel, unsigned int value)
{
	if(channel >=0 && channel < D2A_COUNT)
	{
		if(value >255)
			value = 255; //TPO's have a valid value of 256, AO's do not
		D2A_in_regs[channel] = value;
	}
}

void D2A_WriteChannel(unsigned int channel, unsigned int value)
{
	unsigned int output;
	if(channel < D2A_COUNT && value < 256 &&
		value != D2A_regs[channel])
	{
		D2A_regs[channel] = value;
		switch(channel)
		{
			case 0:
			case 4:
				output = D2A_A0;
				break;
			case 1:
			case 5:
				output = D2A_A1;
				break;
			case 2:
			case 6:
				output = D2A_A2;
				break;
			case 3:
			case 7:
				output = D2A_A3;
				break;
		}
		output |= (value << D2A_DATA_SHIFT) & D2A_DATA_MASK;
#if 1
		InitSPI(16, SPICLK_10);
		DeSelectEESPI();
		if(channel < 4)
			SPIWriteCS(SPICS_DACS0);
		else
			SPIWriteCS(SPICS_DACS1);

		WriteSPI(output);
		SPIWaitTxBusy();
		SPIWriteCS(SPICS_CLEAR);
		ReadSPI();
#endif
	}
}
