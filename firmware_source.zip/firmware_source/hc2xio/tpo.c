/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include <linux/module.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>
#include <linux/timer.h>
#include <linux/tqueue.h>

#include "hc2xio.h"
#include "tpo.h"
#include "tpotable.h"
#include "hc2xmem.h"
#include "D2Adrv.h"
#include "hc2xwd.h"
#include "schedule.h"
#include "hc2xio_exports.h"

//Global Variable Declarations
int iPath8Test;
int iPath10Test;
int iPrintkCheck;
 UINT_UNION tpo_hold_reg[HOLD_REG_SIZE];
 UINT_UNION tpo_in_hold_reg[HOLD_REG_SIZE];
unsigned char TPO[NUMBER_TPO_REGS][TPO_LENGTH];
unsigned int tpoHandlerElapses[TPO_SIZE];
unsigned int controlCheck[TPO_SIZE];
unsigned int finalControlCheck[TPO_SIZE];

const UINT_UNION  bitposn[16] = {	

   0x00, 0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08,
   0x00, 0x10, 0x00, 0x20, 0x00, 0x40, 0x00, 0x80,
   0x01, 0x00, 0x02, 0x00, 0x04, 0x00, 0x08, 0x00,
   0x10, 0x00, 0x20, 0x00, 0x40, 0x00, 0x80, 0x00 };
unsigned int tpo_nFreqCount;
struct tq_struct tpo_timer_task; //this is bottom half structure

//Local Function Declarations.
void make_TPO_table(unsigned int channel);
void initialize_tpo_timer( void );


//******************************************************************************
// TPO_GetFrequency
//
// Abstract:
//	Returns the clock ticks necessary to operate Timer 3 at the proper 
//	frequency.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
unsigned int TPO_GetFrequency( void )
{
	unsigned int nRetVal = TPO_50_HZ;

	unsigned int nPortBVal= 0;
	unsigned int mask = 0;

	nPortBVal = ~inl(GPIO_PBDR);

	
	if(!(nPortBVal & TPO_FREQ_SELECT_BIT))
	{
		nRetVal = TPO_60_HZ;
	}
	return nRetVal;
}

//******************************************************************************
// tpo_bottom_half
//
// Abstract:
//	Debug Function used to toggle a port pin.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void tpo_bottom_half( void *unused )
{
	unsigned int mask = 0;
	static unsigned int index = 0;

	if(!bSkipTPOTickle)
	{
		hc2xwd_TickleDog(TPO_DOG);
	}
}

//******************************************************************************
// tpo_handler
//
// Abstract:
//	Interrupt functiont that executes outputs the TPO bits 8 at a time.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void tpo_handler( int irq, void *dev_id, struct pt_regs *regs )
{
	static unsigned int index = 0;
	int i = 0;
	unsigned long regVal = 0;
	unsigned char charWrite[4] = {0};
	charWrite[0] = 0;
	charWrite[1] = 0;
	charWrite[2] = 0;
	charWrite[3] = 0;


	outl(0, TIMER3CLEAR); /* Write Anything to Clear */

	if(tpo_nFreqCount != TPO_GetFrequency())
	{
		initialize_tpo_timer();
	}

	charWrite[0] = TPO[0][index];
	charWrite[1] = TPO[1][index];

	charWrite[2] = TPO[2][index];
	charWrite[3] = TPO[3][index];

 
	for(i = 0; i<TPO_SIZE; i++)
	{
		if(finalControlCheck[i] != 0x1f )
		{
			charWrite[i/8] &= ~(bitposn[i%8].BYTE.LO_BYTE);
		}
	}
	//Needs to be added in, when hardware arrives.
	if(index >= 255)
	{
		index = 0;
	}
	writeb( charWrite[0], ptrTPO1);
	writeb( charWrite[1], ptrTPO2);
	writeb( charWrite[2], ptrTPO3);
	writeb( charWrite[3], ptrTPO4);

	if(index < TPO_SIZE)
	{
		tpoHandlerElapses[index]++;

		if(tpoHandlerElapses[index] != 0)
		{
			finalControlCheck[index]=controlCheck[index];
			if(controlCheck[index] & 0x02)//the get should not be cleared, it needs to be done at least once
			{	
				controlCheck[index] =0x02;
			}
			else
			{
				controlCheck[index] = 0;
			}
			tpoHandlerElapses[index] = 0;
		}
	}
	index++;
	tpo_bottom_half( NULL );

}

//******************************************************************************
// tpo_handler
//
// Abstract:
//	Function that sets Timer 3 up at the proper frequency.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void initialize_tpo_timer( void )
{
	int i;
	for(i=0; i < TPO_SIZE; i++)
	{
		tpoHandlerElapses[i] = 0;
	}
	tpo_nFreqCount = TPO_GetFrequency();
	hc2xwd_EnableDog(TPO_DOG, TRUE);
	// at 60 hz timer ~16.7 ms
	//at 50 hz timer ~20 ms
   	// timeout = time * freq of 508468.9Hz
   	// timeout can't be greater than 2^32
   	outl(tpo_nFreqCount, TIMER3LOAD); 
	//Now set the timer in Enable, Periodic Mode, and the above
	//frequency.
   	outl(0xC8, TIMER3CONTROL);
   	outl(0, TIMER3CLEAR); /* Write Anything to Clear */

	//IRQ51 is the Timer3 Interrupt
   request_irq(51, tpo_handler, 0, "hc2xio", NULL);
}
////////////////////////////////////////////////////////////////////////////////////////////
//
//This function will suspend/resume tpo irq activity based on the parameter
//The intent is to suspend operations during offset writes to the SPI for storing 
//TDM offsets
////////////////////////////////////////////////////////////////////////////////////////////
void enable_tpo_timer(int iEnable)
{
	if(iEnable)//turn on irq
	{
		bSkipTPOTickle = 0;
		hc2xwd_EnableDog(TPO_DOG, TRUE);
		request_irq(51, tpo_handler, 0, "hc2xio", NULL);
	}
	else //turn of the irq
	{
		release_tpos();
	}
}
//******************************************************************************
// initialize_tpos
//
// Abstract:
//	High Level Function called from init_module used to set the startup
//	conditions of the TPOs.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void initialize_tpos( void )
{
	unsigned int io_mask = 0;
	int i = 0;


	iPath8Test = 0;
	iPath10Test = 0;
	for(i = 0; i < TPO_SIZE; i++)
	{
		tpo_hold_reg[i].UINT = tpo_in_hold_reg[i].UINT = 0;
		make_TPO_table(i);
	}
	initialize_tpo_timer();
}

//******************************************************************************
// release_tpos
//
// Abstract:
//	Frees the Timer 3 interrupt.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void release_tpos( void )
{
	free_irq(51, NULL);
}

//******************************************************************************
// TPO_CheckInput
//
// Abstract:
//	Checks incomming values from the hc2xctl driver.  If a new value arrives,
//	the TPO output table for the value is recalculated.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void TPO_CheckInput( void )
{
	unsigned int i = 0;
	unsigned int index = 0;
	for(i = 0; i < TPO_SIZE; i++)
	{
		if(!iPath10Test)
		{
			TPO_AddSafeSegment(i, 0x010);
		}
		if(tpo_hold_reg[i].UINT != tpo_in_hold_reg[i].UINT)
		{
			tpo_hold_reg[i].UINT = tpo_in_hold_reg[i].UINT;
			make_TPO_table(i);
		}
	}
}

//******************************************************************************
// make_TPO_table
//
// Abstract:
//	Recalculates the output table for the specified channel.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void make_TPO_table(unsigned int channel)
{
   unsigned int posn = 0;  /* this will load the TPO table from 'const' */
   if (channel < TPO_SIZE)
   {
	//make tpo table does not need to execute...
	   for (posn = 0; posn < TPO_LENGTH; posn++)
	   {
		  if (TPO_table[tpo_hold_reg[channel].UINT][posn/8] & 1 << (posn%8))
		  {
 				TPO[channel /8][(unsigned char)posn] |= bitposn[channel % 8].BYTE.LO_BYTE;
			}
			else
			{
			 	TPO[channel /8][(unsigned char)posn] &= ~bitposn[channel %8].BYTE.LO_BYTE;
			}
	   }
   }
}

//******************************************************************************
// TPO_setChannel
//
// Abstract:
//	Function that allows the interface to the hc2xctl driver to set an output.
//
//	NOTE:
//		This function is shared by the new Analog Outputs.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
void TPO_setChannel(unsigned int channel, unsigned int value)
{
	if(channel < TPO_SIZE)
	{

		tpo_in_hold_reg[channel].UINT = value;
		if(!iPath8Test)
		{
			TPO_AddSafeSegment(channel, 0x08);
		}
	}
}

//******************************************************************************
// TPO_setChannel
//
// Abstract:
//	Function that allows the D2Adrv interface to get an output value.
//
// Programmer: Joe Rogers
// Date: 11/01/2004
//
//******************************************************************************
unsigned int TPO_getChannel(unsigned int channel)
{
	unsigned int nRetVal = TPO_SIZE; //indicates error!

	if(channel < TPO_SIZE)
	{
		nRetVal = tpo_hold_reg[channel].UINT;
	}
	return nRetVal;
}

void TPO_TriggerWatchDog()
{
	bSkipTPOTickle = 1;
}

void TPO_testPath(unsigned int iWhichTest, int iTest)
{
	switch(iWhichTest)
	{
		case 1:
		iPath8Test = iTest;
		break;

		case 2:
		iPath10Test = iTest;
		break;
	}	
}

void TPO_AddSafeSegment(unsigned int channel, unsigned int weight)
{
	if(channel < TPO_SIZE)
		controlCheck[channel] |= weight;
}
