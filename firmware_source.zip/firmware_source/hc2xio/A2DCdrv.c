/**************************************************************************

    imagic, Inc.    Copyright (C) 2003, All Rights Reserved
                    Company Confidential    
                    

	File:	        A2DCdrv.c

	Description:	
					This file contains routines that handles the Analog-to-Digital
					converter data collection.
					
	Modifications :	Version	Author	Date		Description
					A		jmr		07/09/03	Initial pre-release 

    This is a trade secret of imagic, inc. and is protected by copyright.
    All unauthorized uses prohibited.
********************************************************************/
 
/*===========================================================================
 *
 * INCLUDE FILES:
 *
/*==========================================================================*/
#include <linux/param.h>
#include <linux/poll.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <linux/interrupt.h>

#include "confcal.h"
#include "A2DCdefs.h"
#include "801defs.h"
#include "hc2xtdm.h"
#include "hc2xmem.h"
#include "801vars.h"
#include "SPIdef.h"

#include "hc2xwd.h"

unsigned active_channel = 0;

/*debug*/
unsigned long SlopeArray[4], OffsetArray[4];

unsigned int A2DCConfigConfirm(unsigned int index);
unsigned int A2DCConfirmSlopeAndOffset(unsigned int index);

//This variable is OR'd in with the SPICS to select
//the appropriate diag line.
static unsigned int nDiagLine = SPICS_NODIAG;

/*int Cdata[4][128];
unsigned int Cindex = 0;*/

/*===========================================================================
 *
 * EXTERNAL DECLARATIONS:
 *
/*==========================================================================*/
/*struct ChannelDataStruct ChannelData0[MAX_CHANNEL_CNT + 2];
struct ChannelDataStruct ChannelData1[MAX_CHANNEL_CNT + 2];
struct ChannelStruct channels0[MAX_CHANNEL_CNT + 2];
struct ChannelStruct channels1[MAX_CHANNEL_CNT + 2];*/

unsigned int bGlobalA2DStatus0;
unsigned int bGlobalA2DStatus1;

//extern float Temperature;
extern float CJCResistance;
//extern float CJCTemperature;
extern unsigned int bTempError;

void hc2xsleep( unsigned int milliseconds )
{
	unsigned long start = jiffies;

	while((jiffies - start) < milliseconds);
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2initChannelStructs

    This function initializes the internal structures used to read the
	 TDM Modules.

 GLOBALS:	ChannelData0, ChannelData1, channels0, channels1

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void A2DinitChannelStructs( void )
{
/*	unsigned int i;

	for(i = 0; i < MAX_CHANNEL_CNT; i++)
	{
		channels0[i].nModeSelect = channels1[i].nModeSelect = Jtype;
		channels0[i].calData.nGain = channels1[i].calData.nGain = 0x00800000; //nGain = 1
		channels0[i].calData.nOffset = channels1[i].calData.nOffset = 0x00000000;
		
		ChannelData0[i].try_cnt = ChannelData1[i].try_cnt = 0;
		ChannelData0[i].scaled = ChannelData1[i].scaled = 0;
		ChannelData0[i].mV = ChannelData1[i].mV = 0.0;
		ChannelData0[i].nTemp = ChannelData1[i].nTemp = 0.0;
		ChannelData0[i].bAlarmed = ChannelData1[i].bAlarmed = FALSE;
		channels1[i].nModeSelect = channels1[i].nModeSelect = Jtype;
		channels1[i].calData.nGain = channels1[i].calData.nGain = 0x00800000; //nGain = 1
		channels1[i].calData.nOffset = channels1[i].calData.nOffset = 0x00000000;
		
		ChannelData1[i].try_cnt = ChannelData1[i].try_cnt = 0;
		ChannelData1[i].scaled = ChannelData1[i].scaled = 0;
		ChannelData1[i].mV = ChannelData1[i].mV = 0.0;
		ChannelData1[i].nTemp = ChannelData1[i].nTemp = 0.0;
		ChannelData1[i].bAlarmed = ChannelData1[i].bAlarmed = FALSE;
	}
	for(i; i<CJC2_CHANNEL; i++)
	{
		channels0[i].nModeSelect = channels1[i].nModeSelect = mV71;
		channels0[i].calData.nGain = 
			channels1[i].calData.nGain = 0x00800000; //nGain = 1
		channels0[i].calData.nOffset = 
			channels1[i].calData.nOffset = 0x00000000;

		ChannelData0[i].bAlarmed = ChannelData1[i].bAlarmed = FALSE;
		ChannelData0[i].try_cnt = ChannelData1[i].try_cnt = 0;
		ChannelData0[i].scaled = ChannelData1[i].scaled = 0;
		ChannelData0[i].mV = ChannelData1[i].mV = 0.0;
		ChannelData0[i].nTemp = ChannelData1[i].nTemp = 0.0;
		switch(i)
		{
		case 0:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 0;
			break;
		case 1:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 1;
			break;
		case 2:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 2;
			break;
		case 3:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 3;
			break;
		case 4:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 4;
			break;
		case 5:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 5;
			break;
		case 6:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 6;
			break;
		case 7:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 8;
			break;
		case 8:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 9;
			break;
		case 9:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 10;
			break;
		case 10:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 11;
			break;
		case 11:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 12;
			break;
		case 12:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 13;
			break;
		case 13:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 14;
			break;
		case 14:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 0;
			break;
		case 15:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_55MV;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 1;
			break;
		case 16:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_2_5V;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 4;
			break;
		case 17:
		ChannelData0[i].cVoltageMask = ChannelData1[i].cVoltageMask = R_2_5V;
		ChannelData0[i].cDiagMask = ChannelData1[i].cDiagMask = 5;
			break;
		default:
			break;
		}
	}*/
}	

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCSetAddress

    This function sets the MUX correctly to write to the A2D converter
    indicated by address.

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void A2DCSelectAddress( unsigned int address)
{
	unsigned int mask = 0x0000;
	
	if(!address)
		mask = SPICS_CSAD0;
	else
		mask = SPICS_CSAD1;
		
	SPIWriteCS(mask);
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCDeSelectAddress

    This function deselects the CS and MISO select for all of the A2D's.

 GLOBALS: 	port0009, port000A

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void A2DCDeSelectAddress( void )
{
	SPIWriteCS(SPICS_CLEAR);
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DReset

    This function resets the currently selected A2D converter.
    
    NOTE: You must select the A2D before calling this function.

 GLOBALS: 	SPIrxbufP

 RETURNS:   TRUE if the A2D resets correctly.

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int A2DReset( int channel )
{
	unsigned int bRetVal = FALSE,i;
	int ReadData;
	unsigned long l1, l2, l3, nRegValue;

	A2DCSelectAddress(channel);

	WriteSPI(WR_CONFG); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	WriteSPI(0x0080);//sets the reset bit rs
	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	
	
	hc2xsleep(40); /* wait 40ms for reset */

	A2DCSelectAddress(channel);

	WriteSPI(WR_CONFG); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	SPIWaitTxBusy();
	A2DCDeSelectAddress();
	
	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	
	ReadData = ReadSPI(); 	

	nRegValue = 0;

	A2DCSelectAddress(channel);
	WriteSPI(0x0094); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	ReadData = ReadSPI();
	ReadData = ReadSPI();
	l1 = (unsigned long)ReadData << 16;  
	ReadData = ReadSPI();  
	l2 = (unsigned long)ReadData << 8;  
	ReadData = ReadSPI();  
	l3 = (unsigned long)ReadData;

	nRegValue = l1 | l2 | l3;
	
	if(nRegValue & 0x00000040)
	{
		bRetVal = TRUE;
	}
	printk( "a2dreset %d\n", bRetVal);
	return bRetVal;
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCConfig

    This function sets up all of the A2D's for conversion.

 GLOBALS: 	SPIrxbufP, ChannelStatus

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
int A2DCConfig( int iA2D )
{
	int i, index, ReadData;
	unsigned int nMask;

    /* first wait for the oscillators to start */
	hc2xsleep(150);
	
	InitSPI(8, SPICLK_00);
	A2DCSelectAddress(iA2D);
				
	for(i=0; i < 16; i++)
	{
		SPIWaitTxNotFull();
		WriteSPI(0x00FF);
	}
	SPIWaitTxNotFull();
	WriteSPI(0x00FE);

	SPIWaitTxBusy();
	//hc2xsleep(150); /* original value */
	hc2xsleep(200);
	A2DCDeSelectAddress();

	EmptyRXFIFO();
			
	if(A2DReset(iA2D))
	{
		A2DCSelectAddress(iA2D);
		WriteSPI(WR_CONFG); 
			
		WriteSPI(A2DCONFIG_HI); 
		WriteSPI(A2DCONFIG_MID); 
		WriteSPI(A2DCONFIG_LOW); 
		SPIWaitTxBusy();
		A2DCDeSelectAddress();
		ReadData = ReadSPI(); 	
		ReadData = ReadSPI(); 	
		ReadData = ReadSPI(); 	
		ReadData = ReadSPI(); 	
		
			
		hc2xsleep(20); /* wait 20ms for reset */
		if(!A2DCConfigConfirm(iA2D))
		{
			return 0;
		}
		printk("a2d config returning true");
		return 1;
	}
	return 0;

}	

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCReady

    This function tests the state of the busy line on the currently 
    addressed A2D converter.

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  A2DCSetAddress
------------------------------------------------------------------------*/
unsigned int A2DCReady(unsigned int index)
{
	unsigned int retVal = 1, mask, junk; 
	
	if(index >= 0 && index < MAX_CHANNEL_CNT)
	{
		A2DCSelectAddress(index);
		
		mask = 0x0001 << index;
		
		//TODO This needs to be crafted
		//junk = port000B;
		
		if(junk & mask)
		{
			A2DCDeSelectAddress();
			retVal = 0;
		}
		else
			retVal = 1;
	}
	else
		retVal = 0;
	return retVal;
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCRead

    This function initiates all A2D converter acquisitions and conversions,
    and collects the data.

 GLOBALS: ChannelData, channels.

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int A2DCRead( struct ChannelDataStruct* ChannelData, unsigned int joeTemp )
{
	unsigned int i;
	unsigned int retVal = FALSE;
	unsigned int junk ;
	unsigned long l1, l2, l3;
	unsigned long lConversion;
	unsigned int testInt;
	testInt = joeTemp;
	InitSPI(8, SPICLK_00);
	A2DCSelectAddress(testInt);
	/* Read A2DC */
	WriteSPI(RD_CONV); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 

	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	ReadSPI();
	junk = ReadSPI();
	l1 = (unsigned long)junk << 16;

	junk = ReadSPI();
	l2 = (unsigned long)junk << 8;

	junk = ReadSPI();
	l3 = (unsigned long)junk ;
	
	lConversion = l1 | l2 | l3;
	if(lConversion & 0x800000)
		lConversion |=0xff000000;
	ChannelData->raw = lConversion;
	retVal = TRUE;
	if(ChannelData->raw & OD_ERROR)
	{
		ChannelData->bAlarmed = 1;
		retVal = FALSE;
	}
	if(ChannelData->raw & OF_ERROR)
	{
		ChannelData->bAlarmed = 2;
		retVal = FALSE;
	}
//	printk("read value %d\n", testInt);
	return retVal;
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  Prescale
                                                                                                                             
    This function applies the calibration date (slope and offset) to the
    raw data depending on the mode of that channel.
                                                                                                                             
 GLOBALS: ChannelData, channels.
                                                                                                                             
 RETURNS:   none
                                                                                                                             
 SEE ALSO:
------------------------------------------------------------------------*/
#if 0
void Prescale( struct ChannelStruct *channels, 
					struct ChannelDataStruct *ChannelData,
					unsigned int index )
{
   float nMaxVoltage = 71.0;
   float nPercent;
                                                                                                                             
   long nValue;
                                                                                                                             
   if(index <= MAX_CHANNEL_CNT)
   {
      nValue = ChannelData[index].raw & ~A2DC_ERROR_CONDITION;
      if(nValue == 0.0)
         nPercent = 0.0;
      else
      {
         nPercent = (float)nValue/(float)A2DC_MAX_RAW_CNT;
         ChannelData[index].mV = nPercent * nMaxVoltage;
      }
   }
}
#endif
/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  
 

    This function applies the percentage scaling to the prescaled data
    depending on the mode of that channel.

 GLOBALS: ChannelData, channels.

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
#if 0
void Postscale(struct ChannelStruct *channels,
					struct ChannelDataStruct *ChannelData, 
					unsigned int index)
{
   int i;// = FindIndex(index); TODO need to include this later
   int temp1, j;
   float temp2;
   float percent;
   float nMaxVoltage = 71.0;
   unsigned int nErrorCondition = 0;

   if(index <= MAX_CHANNEL_CNT)
   {
      if(channels[i].nModeSelect == TCTYPE_PLUS_MINUS_71_mV)
      {
				ChannelData[i].scaled = (int)(ChannelData[i].mV * 100.0);
      }
      else
      {
         ChannelData[i].nTemp = Temperature; 
         if(ChannelData[i].nTemp == TCBREAKVALUE ||
            bTempError ||
            CJCTemperature >= 70.0 || CJCTemperature <= (-10.0))
				ChannelData[i].bAlarmed = TRUE;
         else
				ChannelData[i].bAlarmed = FALSE;

      	ChannelData[i].scaled = (int)(ChannelData[i].nTemp * 10.0);
      }
   }
}
#endif
/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  ReadStatusBits

    This function reads the digital ins, to determine whether or not any
    of the channels are disturbed.

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int ReadStatusBits( struct ChannelDataStruct *ChannelData, 
										unsigned int index )
{
   unsigned int temp = 0;

   if(index <= MAX_CHANNEL_CNT)
   {
      if(ChannelData[index].raw & A2DC_ERROR_CONDITION)
      {
			ChannelData[index].bAlarmed = TRUE;
         temp =1;
      }
      else
			ChannelData[index].bAlarmed = FALSE;
   }

   return temp;

}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCSetGainAndOffset

    This function writes the calibration data to the selected A2D.

 GLOBALS: 	channels, SPIrxbufP

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void A2DCSetGainAndOffset( struct ChannelStruct *channels, unsigned int index )
{

	int i, ReadData;
	unsigned int nOutput, nByte;
	unsigned long nOffset, nGain;
//	printk("setting gain offset tdm %d\n", index);
	nOffset =  channels/*[index]*/->calData.nOffset;
	nGain = channels/*[index]*/->calData.nGain;

	InitSPI(8, SPICLK_00);
	/* Assert the A2DC chip select */ 
	A2DCSelectAddress(index);
	
	/* First write the offset */
	WriteSPI(WR_OFFSET);
   for(i = 2; i >= 0; i--)
   {
    	nByte = (unsigned int)((nOffset >> i*8) 
    					& 0x00FF);
    	nOutput = nByte;
		WriteSPI(nOutput);
	}
	SPIWaitTxBusy();
	A2DCDeSelectAddress();
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 
	
	
	A2DCSelectAddress(index);
	
	/* Now write the gain */
	WriteSPI(WR_GAIN);
   for(i = 2; i >= 0; i--)
   {
    	nByte = (unsigned int)((nGain >> i*8) 
    					& 0x00FF);
    	nOutput = nByte;
		WriteSPI(nOutput);
	}
	SPIWaitTxBusy();
	A2DCDeSelectAddress();
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 
	ReadData = ReadSPI(); 

//	A2DCConfirmSlopeAndOffset(index);
	
	/* Assert the A2DC chip select */ 
//	A2DCSelectAddress(index);

//	WriteSPI(0x00A0); 

//	ReadData = ReadSPI();

	/* De-assert the A2DC chip select */
//	A2DCDeSelectAddress();
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  StartAtoD

    this function starts the AtoD converter by triggering the bit in the 
    command register

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void StartAtoD( unsigned int nTDMno ) 
{     

	unsigned int  ReadData;
//	printk("starting a2d tdm %d\n", nTDMno);

	InitSPI(8, SPICLK_00);
	
	A2DCSelectAddress(nTDMno);
 	WriteSPI(ST_CONV); 
	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	ReadData = ReadSPI();   
	
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  SelectAtoDChannel

    this function selects the correct mux setting

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void SelectAtoDChannel(unsigned int channelNum, unsigned int nTDMno, unsigned int bDiag, unsigned int rangeVal)
{   

	unsigned int temp;
	unsigned int ReadData;
	
	if(nTDMno) //TDM number 1
	{
		if(bDiag)
			nDiagLine |= SPICS_DIAG1;
		else
			nDiagLine &= ~SPICS_DIAG1;
	}
	else //TDM number 0
	{
		if(bDiag)
			nDiagLine |= SPICS_DIAG0;
		else
			nDiagLine &= ~SPICS_DIAG0;
	}
	

	temp = channelNum;
	temp = temp << 4; 
	temp &= 0x00f0; 
	temp |= A2DCONFIG_HI; 
    /* need to write the config data to the individual bytes */
	 
	InitSPI(8, SPICLK_00);
	/*	
	select the configiguration register
	to write to
	*/
	//printk("High byte is 0x%x\n", temp); 
	A2DCSelectAddress(nTDMno);
//MODIFY WRITE BELOW
	WriteSPI(WR_CONFG);
	WriteSPI(temp);

	//reusing temp for mv range write
	temp = (rangeVal << 1);
	temp &= 0x000e;
	temp |= A2DCONFIG_MID;
	WriteSPI(temp); 

	WriteSPI(A2DCONFIG_LOW); 
	SPIWaitTxBusy();
	A2DCDeSelectAddress();
	
	ReadSPI();
	ReadSPI();
	ReadSPI();
	ReadSPI();
}

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  InitiateSample
                                                                     
    This function starts a single sample on the A2D associated with the 
    channel indicated.

 GLOBALS: rtd_channels

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
void InitiateSample( unsigned int a2d, unsigned int channel )
{

	if(channel >= 0 && channel < MAX_CHANNEL_CNT)
	{
		A2DCSelectAddress(channel);
	//Needs to be set for thermocouples
	//	SelectAtoDChannel(rtd_channels[channel].nSampleState[rtd_channels[channel].nSampleIndex]);
		A2DCDeSelectAddress();

		A2DCSelectAddress(channel);
		StartAtoD(a2d);
		A2DCDeSelectAddress();
	}
}  
 
/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  ReadAnalogIns
                                                                     
    This function reads the analog ins, the status bits, and scales the
    data appropriately.

 GLOBALS: 

 RETURNS:   none

 SEE ALSO:  
------------------------------------------------------------------------*/
/*void ReadAnalogIns( int iTdm, int iCurrChannel )
{
   unsigned int i, mask, tempIndex;
 //  static unsigned int currChannel = MAX_CHANNEL_CNT;
   static unsigned int junk = FALSE; 
   struct ChannelStruct* ptrCurrentData;
   struct ChannelDataStruct* ptrDataStructure;
   unsigned long ulOffset = 0;
   unsigned long ulSlope = 0;

	switch(iTdm)
	{
	case 0:
		ptrCurrentData = channels0;
		ptrDataStructure = ChannelData0;
		break;

	case 1:
		ptrCurrentData = channels1;
		ptrDataStructure = ChannelData1;
		break;

	default:
		ptrCurrentData = channels0;
		ptrDataStructure = ChannelData0;
		break;

	}


   if(iCurrChannel == MAX_CHANNEL_CNT)
   {
      tempIndex = CJC_CHANNEL;
   }
//   else TODO This needs to be include somehow.
//      tempIndex = FindIndex(currChannel);
	if(*ptrCurrentData[iCurrChannel].bInProcess && A2DCRead(*ptrDataStructure, iCurrChannel))
   {
      mask = ~(0x0001 << tempIndex);
		//TODO might have to resurect the status mask
//      bGlobalA2DStatus &= mask;
 //     Prescale(channels0, ChannelData0, tempIndex);
      if(currChannel < MAX_CHANNEL_CNT) 
      {		  
         if(*ptrCurrentData[iCurrChannel].nModeSelect != TCTYPE_PLUS_MINUS_71_mV)
         {
//TODO            TCConversion(ChannelData0[tempIndex].mV,
//                        CJCResistance,
//                        channels0[tempIndex].nModeSelect);
         }
         ReadStatusBits(ChannelData0, tempIndex);
         Postscale(channels0, ChannelData0, currChannel);
      }
      else 
      {
			A2DCSelectAddress(0);
//TODO         CalculateCJCResistance(ChannelData0);
		}
		channels0[tempIndex].bInProcess = FALSE;
	}
	else if(!channels0[tempIndex].bInProcess)
   {
      channels0[tempIndex].bInProcess = TRUE;
      A2DCSetGainAndOffset( channels0, tempIndex );
      InitiateSample(0, tempIndex);
	}

	//Now repeat for second TDM
   if(channels1[tempIndex].bInProcess && A2DCRead(ChannelData1, tempIndex))
   {
      mask = ~(0x0001 << tempIndex);
		//TODO make have to use this later
//      bGlobalA2DStatus &= mask;
      Prescale(channels1, ChannelData1, tempIndex);
      if(currChannel < MAX_CHANNEL_CNT) 
      {
         if(channels1[tempIndex].nModeSelect != TCTYPE_PLUS_MINUS_71_mV)
         {
//            TCConversion(ChannelData1[tempIndex].mV,
//                        CJCResistance,
//                        channels1[tempIndex].nModeSelect);
         }
         ReadStatusBits(ChannelData1, tempIndex);
         Postscale(channels1, ChannelData1, currChannel);
      }
      else 
      {
         A2DCSelectAddress(1);
//TODO         CalculateCJCResistance(ChannelData1);
      }
      channels1[tempIndex].bInProcess = FALSE;
   }
   else if(!channels1[tempIndex].bInProcess)
   {
      channels1[tempIndex].bInProcess = TRUE;
      A2DCSetGainAndOffset( channels1, tempIndex );
      InitiateSample(1, tempIndex);
   }
}*/

/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCConfigConfirm

    This function reads the configuration from the A2D and compares it to
    the expected value.

 GLOBALS: 	SPIrxbufP

 RETURNS:   TRUE if the configuration passes.
 			FALSE otherwise.

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int A2DCConfigConfirm(unsigned int index)
{
	unsigned int nRetVal = FALSE;
	unsigned int junk ;
	unsigned long l1, l2, l3, nRegValue;

	unsigned long config_value = (A2DCONFIG_HI << 16) |
										  (A2DCONFIG_MID << 8) |
										  (A2DCONFIG_LOW);
	
	int i, ReadData;
	unsigned int nMask;
	
	InitSPI(8, SPICLK_00);
	A2DCSelectAddress(index);
		
	WriteSPI(0x0094); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	WriteSPI(0x0000); 
	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	junk = ReadSPI();
	junk = ReadSPI();
	l1 = (unsigned long)junk << 16;  

	junk = ReadSPI();
	l2 = (unsigned long)junk << 8;  

	junk = ReadSPI();
	l3 = (unsigned long)junk;

	nRegValue = l1 | l2 | l3;

	if(nRegValue & ~(config_value))
		printk("read back failed");
	else
	{
		printk("read back succedded");
		nRetVal = TRUE;
	}
	
	return nRetVal;
}


/*--(PUBLIC FUNCTION)------------------------------------------------------
 FUNCTION:  A2DCSetGainAndOffset

    This function reads the calibration from the A2D and compares it to
    the expected value.

 GLOBALS: 	SPIrxbufP

 RETURNS:   TRUE if the configuration passes.
 			FALSE otherwise.

 SEE ALSO:  
------------------------------------------------------------------------*/
unsigned int A2DCConfirmSlopeAndOffset(unsigned int index)
{
	unsigned int nRetVal = FALSE;
	unsigned int junk ;
	unsigned long l1, l2, l3, nOffset, nGain;
	
	if(index >= 0 && index < MAX_CHANNEL_CNT)
	{
		/*Read back the configuration*/		
		A2DCSelectAddress(index);
		
		WriteSPI(0x0090); 
		WriteSPI(0x0000); 
		WriteSPI(0x0000); 
		WriteSPI(0x0000); 
		SPIWaitTxBusy();
		A2DCDeSelectAddress();

		junk = ReadSPI();
		junk = ReadSPI();
		l1 = (unsigned long)junk << 16;  

		junk = ReadSPI();  
		l2 = (unsigned long)junk << 8;  

		junk = ReadSPI();  
		l3 = (unsigned long)junk;
		
		nOffset = l1 | l2 | l3;
		OffsetArray[index] = nOffset;
		
		/*Read back the configuration*/		
		A2DCSelectAddress(index);
		
		WriteSPI(0x0092); 
		WriteSPI(0x0000); 
		WriteSPI(0x0000); 
		WriteSPI(0x0000); 
		SPIWaitTxBusy();
		A2DCDeSelectAddress();
		junk = ReadSPI();

		junk = ReadSPI();
		l1 = (unsigned long)junk << 16;  

		junk = ReadSPI();  
		l2 = (unsigned long)junk << 8;  

		junk = ReadSPI();  
		l3 = (unsigned long)junk;
		
		nGain = l1 | l2 | l3;
		SlopeArray[index] = nGain;
		
	} 
	
	return nRetVal;
}

unsigned int A2DReturnData(struct ChannelDataStruct *ChannelData, int iChannel)
{
	return (unsigned int)(ChannelData[iChannel].nTemp * 10);
}

int A2DCheckForCompletedRead( unsigned int nTDMno)
{
	int bReturn = 0;
	static int nCnt = 0;
	bReturn = FALSE;

	unsigned int nRetVal = FALSE;
	unsigned int junk ;
	unsigned long l1, l2, l3, nRegValue;	
//	printk("check for complete read tdm %d \n", nTDMno);	
	InitSPI(8, SPICLK_00);
	
	A2DCSelectAddress(nTDMno);		
	WriteSPI(RD_CONFG);
	WriteSPI(0x0000);
	WriteSPI(0x0000);
	WriteSPI(0x0000);
	SPIWaitTxBusy();
	A2DCDeSelectAddress();

	ReadSPI();
	junk = ReadSPI();
	l1 = (unsigned long)junk << 16;
	junk = ReadSPI();
	l2 = (unsigned long)junk << 8; 
	junk = ReadSPI();
	l3 = (unsigned long)junk;
	
	nRegValue = l1 | l2 | l3;
		
	if(nRegValue & A2D_CONVERSION_DONE)//conversion completed
	{
		nRetVal = TRUE;
	}
	else
	{
//		printk("Ready Failed on TDM %d Config = 0x%x\n", nTDMno, nRegValue);
		nRetVal = FALSE;
	}
	
	return nRetVal;

}
