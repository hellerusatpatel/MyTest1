/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.

// Version history
// 23-Dec-16  TP   Update version printk 8.0.0.16 20161223 to match PC program version only
// 01-Feb-17  TP   Update version printk 8.0.0.17 20170201 to match PC program version
// 03-Apr-17  TP   Update version printk 8.0.0.18 20170403
// 16-Apr-17  TP   Update version printk 8.0.0.19 20170416
// 25-Apr-17  TP   Update version printk 8.0.0.20 20170425
/***************************************************************************/ 
#ifndef __KERNEL__
	#define __KERNEL__
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <asm/semaphore.h>
#include <asm/segment.h>
#include <asm/uaccess.h>

#include "hc2xwd.h"

int driver_major  = 0;

unsigned int wd_counts[MAX_DOG_CNT];
unsigned int wd_timeouts[MAX_DOG_CNT];
unsigned int wd_enabled[MAX_DOG_CNT];
unsigned int wd_forced[MAX_DOG_CNT];

unsigned int wd_first_time = 0;
unsigned int wd_timedOut = 0;

struct timer_list wd_timer;
void wd_initialize_timer( void );

void hc2xwd_enableWatchDogByIndex(unsigned int index, int enable);
void hc2xwd_tickleWatchDogByIndex(unsigned int index);

//******************************************************************************
// hc2xwd_sleep
//
// 	Abstract:
//  		This function suspends the cpu for the time specified by milliseconds.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
void hc2xwd_sleep( unsigned int milliseconds )
{
	unsigned long start = jiffies;

	while((jiffies - start) < milliseconds);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_ioctl

			The ioctl() interface for this driver.

 RETURNS:   int-0
 SEE ALSO:
------------------------------------------------------------------------*/
int hc2xwd_ioctl(struct inode* inode, struct file* f, unsigned int cmd, unsigned long arg)
{
	unsigned int index = APP_DOG;
	if ( arg != 0 )
	{
		index = arg;
	}

	switch (cmd)
	{
		case IOCTL_ENABLE_WD:
			hc2xwd_enableWatchDogByIndex(index, 1);
			break;
	
		//if we do not disable the application watchdog the system will reboot when 
		//the application is in the select statement waiting for a client.  calling
		//the tickle from a timer is not an option as it will kill the select or wait
		// on the select, depending on the sigaction flag this is probably why a
		// application watchdog was not included during initial development.  As implemented the watchdog will function when a client connects until all clients release WDT
		case IOCTL_DISABLE_WD:
			hc2xwd_enableWatchDogByIndex(index, 0);
			break;
	
		case IOCTL_TICKLE_DOG:
			hc2xwd_tickleWatchDogByIndex( index );
			break;
	
		default:
			break;
	}

	return 0;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  tickledog

			This function writes the Watchdog hardware register prevented a timeout
			and subsequent reboot.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void tickledog( void )
{
	outl(WD_TICKLE, WATCHDOG);
	mb();
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  enabledog

			This function writes the Watchdog hardware register and enables the
			watchdog.	

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void enabledog( void )
{
	outl(WD_ENABLE, WATCHDOG);
	mb();
	return;
}

//******************************************************************************
// setstatus
//
// 	Abstract:
//  		This function the status value to the status register in the watchdog.
//			This value is used to indicate which driver or part of, timed out.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
void setstatus(unsigned int status)
{
	outl(status, WDSTATUS);
	mb();
}

//******************************************************************************
// getstatus
//
// 	Abstract:
//  		This function returns the status value from the status register in the
//			watchdog.  This value is used to indicate which driver or part of, 
//			timed out.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
unsigned int getstatus( void )
{
	unsigned int nRetVal = MAX_DOG_CNT;
	nRetVal = (unsigned int)inl(WDSTATUS);
	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  wd_timer_handler

			This function is called by the kernel timer.  It currently executes
			every 100mSec.  It checks each individual watchdog to make sure non
			of them have expired.  If they have not, the watchdog is "tickled".
			If any of the watchdogs have timed out, the status register is 
			written with the index of the expired watchdog, and the hardware
			is not "tickled", allowing the processor to reset.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void wd_timer_handler(unsigned long arg)
{
	unsigned int i;

	if(wd_first_time)
	{
		wd_first_time = 0;
		enabledog();
	}

	for( i = 0; (i < MAX_DOG_CNT) && (wd_timedOut == 0); i++)
	{
		if ( wd_enabled[i] )
		{
			if ( wd_forced[i] )
			{
				printk("watchdog Forced %d timeout\n", i);
				wd_timedOut = 1;
			}
			else
			{
				wd_counts[i] += WD_DELAY;
				if( wd_counts[i] > wd_timeouts[i] )
				{
					printk("watchdog %d timeout (%d > %d)\n", 
						i, wd_counts[i], wd_timeouts[i]);
					wd_timedOut = 1;
				}
			}

			if ( wd_timedOut )
			{
				setstatus(i);
			}
		}
	}

	if( !wd_timedOut )
	{
		tickledog();
	}

	wd_initialize_timer();
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  wd_initialize_timer

			This function starts the watchdog timer.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void wd_initialize_timer( void )
{
	unsigned long mask;

	init_timer(&wd_timer);
	wd_timer.function = wd_timer_handler;
	wd_timer.data = 0;
	wd_timer.expires = jiffies + WD_DELAY;//(.1*HZ); // 100 mSecs.

	add_timer(&wd_timer);

	//The following code, while serving no useful purpose,
	//must remain as exiting from this function too quickly
	//appears to cause a kernel panic...IIIIEEEEEE.
	if(mask & 0x2)
	{
	   mask &= ~(0x2);
	}
	else
	{
	   mask |= 0x2;
	}
	return;
}
                                                                                
//******************************************************************************
// driver_release
//
// 	Abstract:
//  		This function is a called when the driver is closed by an application.
//			This is a standard Linux driver function.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
int driver_release(struct inode *inode, struct file *filp)
{
	MOD_DEC_USE_COUNT;
	return 0;
}

//******************************************************************************
// driver_open
//
// 	Abstract:
//  		This function is a called when the driver is opened by an application.
//			This is a standard Linux driver function.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
int driver_open(struct inode* i, struct file* f)
{
	MOD_INC_USE_COUNT;
	return 0;
}

//******************************************************************************
// driver_read
//
// 	Abstract:
//  		This function is a called when the driver file is read by an application.
//			This is a standard Linux driver function, and is currently not
//			implemented in this driver.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
ssize_t driver_read(struct file* f, char* buf, size_t count, loff_t* f_pos)
{
	ssize_t retValue = 1;//-ENOMEM;

	return retValue;
}

//******************************************************************************
// driver_write
//
// 	Abstract:
//  		This function is a called when the driver file is written to by an 
//			application.  This is a standard Linux driver function, and is 
//			currently not implemented in this driver.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
ssize_t driver_write(struct file* f, const char* buf, size_t len, loff_t* f_pos)
{
	ssize_t retValue = 1;//-ENOMEM;

	return retValue;
}

struct file_operations driver_fops =
{
	open:		driver_open,
	release:    driver_release,
	ioctl:		hc2xwd_ioctl,
//	write:		driver_write,
//	read:		driver_read,
};

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  init_module

  		This function is a called when the driver is loaded by the operating
			system.  This is a standard Linux driver function.

 RETURNS:   int 0 or < 0 on error
 SEE ALSO:
------------------------------------------------------------------------*/
int init_module()
{
	int status = 0;
	unsigned int i;
	unsigned int wdstatus;

	printk("hc2xwd: entering init_module %d, %ld\n", HZ, jiffies);

	driver_fops.owner = THIS_MODULE;

	/*
	* Register your major, and accept a dynamic number. This is the
	* first thing to do, in order to avoid releasing other module's
	* fops in scull_cleanup_module()
	*/
	status = register_chrdev(driver_major, "hc2xwd", &driver_fops);
	if (status < 0)
	{
		printk(KERN_WARNING "hc2xwd: can't get major %d\n", driver_major);
		return status;
	}

	if (driver_major == 0)
	{
		driver_major = status; /* dynamic */
	}

	//printk("hc2xwd: register_chrdev... succeeded\n");
	long pwStatus = inl(SYSCON_PWRSR);
	printk("power on status reg: %x\n", pwStatus);

	long dcStatus = inl(SYSCON_DEVCFG);
	printk("device configuration register: %x\n", dcStatus);

	outl(0, SYSCON_STFCLR);

	long wdStatus = inl(WATCHDOG);
	printk("watch dog register value: %x\n", wdStatus);

	wdstatus = getstatus();
	switch(wdstatus)
	{
		case CTL_DOG:
			printk("hc2xwd: Reboot occured for hc2xctl watchdog\n");
			break;
		case IO_DOG:
			printk("hc2xwd: Reboot occured for hc2xio IO watchdog\n");
			break;
		case TPO_DOG:
			printk("hc2xwd: Reboot occured for hc2xio TPO watchdog\n");
			break;
		case TDM_DOG:
			printk("hc2xwd: Reboot occured for hc2xio TDM watchdog\n");
			break;
		case APP_DOG:
			printk("hc2xwd: Reboot occured for application watchdog\n");
			break;
		case MSTR_DOG:
			printk("hc2xwd: Reboot occured for hc2xmstr watchdog\n");
			break;
		case UPDATER_DOG:
			printk("hc2xwd: Reboot occured for Hc2Updater watchdog\n");
			break;
	}
	printk("wdstatus %d\n", wdstatus);

	setstatus(MAX_DOG_CNT);
	for(i = 0; i < MAX_DOG_CNT; i++)
	{
		wd_counts[i] = 0;
		wd_enabled[i] = 0;
		wd_forced[i] = 0;
		wd_timeouts[i] = DEFAULT_TIMEOUT;
	}

	wd_timedOut = 0;

	wd_first_time = 1;
	wd_initialize_timer();
	printk("hc2xwd::init_module() loaded version 8.0.0.28 20180208\n");

	return 0;
}

//******************************************************************************
// init_module
//
// 	Abstract:
//  		This function is a called when the driver is closed by the operating
//			system.  This is a standard Linux driver function.
//
// Programmer: Joe Rogers
// Date: 11/09/04
//
//******************************************************************************
void cleanup_module()
{
	unregister_chrdev(driver_major, "hc2xwd");
}

//Global Access Functions for other Drivers
///////////////////////////////////////////

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_EnableDog

	  		This function sets the enabled flag of the watchdog indicated by index
			to the value indicated by state.  Use this to enable and disable a
			particular watchdog from another driver.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_EnableDog(unsigned int index, unsigned int state)
{
	if(index < MAX_DOG_CNT)
	{
		wd_enabled[index] = state;
	}
	return;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_TickleDog

  			This function resets the conter of the watchdog indicated by index.  
			This prevents the watchdog from rebooting the CPU.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_TickleDog(unsigned int index)
{
	if(index < MAX_DOG_CNT)
	{
		wd_counts[index] = 0;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_GetTimeOut

  			This function returns the timeout in milliseconds to the watchdog
			indicated by index.

 RETURNS:   unsigned int value of the timeout
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned int hc2xwd_GetTimeOut(unsigned int index)
{
	unsigned nRetVal = 0;

	if(index < MAX_DOG_CNT)
	{
		nRetVal = wd_timeouts[index];
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_SetTimeOut

  			This function sets the timeout in milliseconds to the watchdog
			indicated by index.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_SetTimeOut(unsigned int index, unsigned int timeout)
{
	if(index < MAX_DOG_CNT)
	{
		wd_timeouts[index] = timeout;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_enableWatchDogByIndex

			Enable either the application or updater watchdog at the given index.
			The application watchdog will have a longer timeout of 4 seconds
			that will be set from the enable routine.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_enableWatchDogByIndex(unsigned int index, int enable)
{
	if(index < MAX_DOG_CNT)
	{
		if(index == APP_DOG)//application has a long timeout to allow for socket operations, updater is quicker leaving index at 0 for backwards compatibility
		{
			hc2xwd_SetTimeOut(index, 600000);
			hc2xwd_EnableDog(index, enable);
		}
		else
		{
			hc2xwd_SetTimeOut(index, 4000);
			hc2xwd_EnableDog(index, enable);
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_tickleWatchDogByIndex

			Tickle the watchdog (app or updater)

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_tickleWatchDogByIndex(unsigned int index)
{

	if(index < MAX_DOG_CNT)
	{
		if(index == APP_DOG)//application has a long timeout to allow for socket operations, updater is quicker leaving index at 0 for backwards compatibility
		{
			hc2xwd_TickleDog(APP_DOG);
		}
		else if(index == UPDATER_DOG)
		{
			hc2xwd_TickleDog(UPDATER_DOG);
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  hc2xwd_force

			This routine will force an enabled watchdog to failure state.
			This is used for manual triggering of the control watchdog for a heatzone
			That has exceeded the global high process

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void hc2xwd_force(unsigned int index)
{
	if(index < MAX_DOG_CNT)
	{
		wd_forced[index] = 1;
		printk("watch dog forced %d\n", index);
	}
	return;
}
