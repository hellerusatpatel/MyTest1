/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2004, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
////////////////////////////////////////////////////////////////////////
//
//		hc2xwd.h
//
//		Author: Joe Rogers
//		Created: 9/7/2004
//
//		Notes: Contains exported globals for watchdog operation.
//
//		TIMEOUTS are unsigned integers represented 100ms ticks.
//
////////////////////////////////////////////////////////////////////////
#ifndef HC2XWD_H
#define HC2XWD_H

//Global Defines
#define WD_DELAY			50 //number of milliseconds between timer events

#define WD_ENABLE			0x0000AAAA
#define WD_TICKLE			0x00005555
#define WD_DISABLE		0x0000AA55

#define MAX_DOG_CNT 	8

#define IO_DOG			1
#define TPO_DOG			2
#define TDM_DOG			3
#define APP_DOG			4
#define CTL_DOG			5
#define MSTR_DOG		6
#define UPDATER_DOG		7

#define DEFAULT_TIMEOUT 1000

#define IOCTL_ENABLE_WD _IOR('t', 0x97, unsigned long)
#define IOCTL_TICKLE_DOG _IOR('t', 0x98, unsigned long)
#define IOCTL_DISABLE_WD _IOR('t', 0x99, unsigned long)

void hc2xwd_TriggerTimer(int state);
void hc2xwd_EnableDog(unsigned int index, unsigned int state);
void hc2xwd_TickleDog(unsigned int index);
unsigned int hc2xwd_GetTimeOut(unsigned int index);
void hc2xwd_SetTimeOut(unsigned int index, unsigned int timeout);
#endif
