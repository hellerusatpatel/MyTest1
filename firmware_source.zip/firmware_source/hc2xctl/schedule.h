/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			schedule.h

	Description:	scheduler

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __SCHEDULER_H__
#define __SCHEDULER_H__

#include "typedefdefine.h"

#define OVERRUN	   2
#define LOSSOFCOMM 3

extern unsigned char gSeqeunceStatus;

typedef struct _Scheduler_
{
//private:
	// The statics are required because they are used in an interrupt handler at which
	// time there is no definitive object.

	DWORD	        sequenceNo;
	DWORD				timerCount;
	DWORD				scanPeriod;		// set to 10Hz or 100ms
	DWORD				elapsedTempZoneTime; 
	DWORD				lossOfComm;
	BOOL				upDateTPOs;	
	LONG				elapsed100Nanos;

	DWORD				LowPartTime; 
	LONG				HighPartTime;

	BOOL				m_bTimerFired;

	DWORD				consecutiveNoReadScans;
	int					m_iSchedulerCase;
	BOOL					bProcess;

	int testDog;
	int iScheduleLoopCount;

	BOOL m_bResetTrackingLane0;
	BOOL m_bResetTrackingLane1;
	BOOL m_bResetTrackingLane2;
	BOOL m_bResetTrackingLane3;

} Scheduler;

void Scheduler_init(Scheduler* pScheduler);

void Scheduler_reset( Scheduler* pScheduler ); 	
void	Scheduler_sequencer(Scheduler* pScheduler);
void	Scheduler_monitor_sequencer(Scheduler* pScheduler);;
void	Scheduler_setContainerAddress(Scheduler* pScheduler);
DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler);
void Scheduler_start( Scheduler *pScheduler );
void Scheduler_stop( Scheduler *pScheduler );
void Scheduler_switchLoops( Scheduler *pScheduler , int bValue);
void Scheduler_testDog(Scheduler *pScheduler);

#endif
