//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: oven.c
//
// Description: oven logic processing
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Process current monitor delayed cooldown
// 03-Dec-14  FJN  Process heater failure delayed cooldown
// 03-Feb-15  FJN  For Oven_setJob start timer for all SMEMA 9851 lanes
// 04-Mar-16  FJN  Implement custom alarms 4 and 5
// 16-Nov-17  TP	Implement Oven_checkRecipeLoadBoardEntryWait
//
//*****************************************************************************
#include <string.h>

#include "contain.h"
#include "oven.h"
#include "hellerenumerations.h"
#include "typedefdefine.h"
#include "digitio.h"
#include "alarm.h"
#include "newboardq.h"
#include "newboardqNoLP.h"
#include "bdrop.h"
#include "belt.h"
#include "timer.h"
#include "smema.h"
#include "nitrogen.h"
#include "fluxcondensor.h"
#include "../hc2xio/include/hc2xio_exports.h"
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"
#include "purge.h"

extern DbContainer g_dbContainer;

unsigned char g_ucSetSecsgemOption;
unsigned char g_ucSecsgemOptionSetTo;
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_init
			The oven system parameters and state of operation.			


 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_init(Oven* pOven)
{
	if(pOven)
	{
		pOven->scanPeriod = 0;
		pOven->jobNo = COOLDOWN;
		pOven->noHeatZones = 0;
		pOven->coolDown	= FALSE;
		pOven->noBelts = 1;
		pOven->noRails = 0;
		pOven->bdrop = NONE;
		pOven->digitalCoolingFan = FALSE;
		pOven->calibration	= FALSE;
		pOven->autoLube	= FALSE;
		pOven->eStopSet	= FALSE;
		pOven->jobLoadInProgress	=	FALSE;
		pOven->jobStartupComplete	= FALSE;
		pOven->lowExhaustWarningSent	=	FALSE;
		pOven->demoMode	= FALSE;
		pOven->startLowExhaustTime	= 0;
		pOven->smemaConfig	= 0;
		pOven->boardDropConfig	= L1_TIMED_L2_NONE;
		pOven->boardsProcessedConfig = 1;
		pOven->boardsInOvenConfig = 1;
		pOven->animationConfig = 0;
		pOven->startHighWaterTempTime = 0;
		pOven->wantResume = TRUE;
		pOven->scanCounts = 0;
		pOven->leftToRight = TRUE;
		pOven->modelNo = 0;
		pOven->startOverTempTime = 0;
		pOven->startBlowerFailTime = 0;
		pOven->redundantOverTempOptionEnabled = FALSE;
		pOven->blowerFailureCheckEnabled = FALSE;
		pOven->autoCleanFluxMode = FALSE;
		pOven->FiveSecondTimerIsRunning = FALSE;
		pOven->startUpWithJob = FALSE;
		pOven->m_bFailureNotified = FALSE;
		pOven->startPowCooldownFailTime = 0;
		pOven->m_bIsPowerOKForWarningTime  = TRUE;
		pOven->m_bExhaustWarningsEnabled = TRUE;
		pOven->m_bExhaustAlarmsEnabled = TRUE;
		pOven->m_bSelfAcknowledgeDisabled = FALSE;
		pOven->m_bDisableDevAlarmInStartup = FALSE;
		pOven->m_StartupCompletePlusDelayTime = 0;
		pOven->m_iPowerfailureTime = POWER_FAIL_TIME_10THS;
		pOven->m_bDelayedCooldown = FALSE;
		pOven->m_bCurrentMonitorDelayedCooldown = FALSE;
		pOven->m_bHeaterFailureDelayedCooldown = FALSE;
		pOven->m_dwrdDelayedCooldownTime = 0;
		pOven->m_bCooldownCountOn = FALSE;
		pOven->m_bRequestCooldown = FALSE;
		pOven->m_bStarted = FALSE;
		pOven->recipeName[0] = '\0';
		pOven->m_dwrCurrentGroup = 1;
		pOven->m_bPendingCooldown = FALSE;
		Oven_setBoardProcessConfigOptions(pOven);
		pOven->m_bFanFaultAlarm = TRUE;
		pOven->m_bAudibleBlowFail = TRUE;
		pOven->m_bBFWarn = TRUE;
		pOven->m_iBFATime = BLOWER_FAIL_ALARM_DEFAULT;
		pOven->m_iBFWTime = BLOWER_FAIL_WARNING_DEFAULT;
		pOven->m_uAllowBarcodeAgain = 0;
		pOven->mbEnergyStandy = FALSE;
		pOven->mbEnergyCooldown = FALSE;
		pOven->mDenergyCoolTime=0;
		pOven->mDenergyTime=0;
		pOven->mStartEnergyCountdown=0;
		pOven->mbEnergyRecipe=FALSE;
		pOven->mDwrdEnergyInput=IDI_NULL;
		pOven->mbEnergyNoteSent=FALSE;
		pOven->mbEnergyInputHasLowed=FALSE;
		pOven->mbOvenActive = 0;

		pOven->m_EnergySaving_IntelExhaust_Enabled = FALSE;
		pOven->m_EnergySaving_IntelExhaust_Speed = 0;
		pOven->m_EnergySaving_StandbyMode1_Enabled = FALSE;
		pOven->m_EnergySaving_StandbyMode1_ExhaustSpeed = 0;
		pOven->m_EnergySaving_StandbyMode1_ZoneSpeed = 0;
		pOven->m_EnergySaving_StandbyMode1_Conveyor_Enabled = FALSE;
		pOven->m_EnergySaving_StandbyMode1_ConveyorSpeed = 0;
		pOven->m_EnergySaving_StandbyMode1_N2Off = FALSE;
		pOven->m_EnergySaving_StandbyMode1_N2Low = FALSE;
		pOven->m_EnergySaving_eStandbyMode1 = MODE1_NONE;
		pOven->m_EnergySaving_eStandbyMode2_LoadRecipe = FALSE;
		pOven->standbyMode1Time = STANDBY_MODE1_DEFAULT;
		pOven->mbDoReset = FALSE;
		pOven->mEnergyCooldownTimer = 0;
		pOven->m_dwrdStartUpElapse = 0;
		pOven->mbAlarmScanner = FALSE;
		pOven->miAlarmOutput = ODO_NULL;
		pOven->mbAlarmState = TRUE;
		pOven->skipClear = 0;	
		pOven->m_EnergySaving_MaxBlower = MAXIMUM_PERCENTAGE;
		pOven->m_EnergySaving_MinBlower = 0;
		pOven->m_Standby_MaxBlower = MAXIMUM_PERCENTAGE;
		pOven->m_Standby_MinBlower = 0;
		pOven->loadTime = 0;	//ver8.0.0.24
		pOven->boardEntryWait = 0;	//ver8.0.0.24

		g_ucSetSecsgemOption = 0;
		g_ucSecsgemOptionSetTo = 0;
	}
	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardDropConfig
		LANE1	LANE2	
 0.	NONE	NONE	4.	TIMED	NONE	8.	BEAM	NONE	12.	BOTH	NONE
 1. NONE	TIMED	5.	TIMED	TIMED	9.	BEAM	TIMED	13. BOTH	TIMED
 2.	NONE	BEAM	6.	TIMED	BEAM	10.	BEAM	BEAM	14.	BOTH	BEAM	
 3.	NONE	BOTH	7.	TIMED	BOTH	11.	BEAM	BOTH	15.	BOTH	BOTH			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setBoardDropConfig(Oven* pOven, DWORD bdConfigSetting )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setBoardDropConfig", 0);

	if ( bdConfigSetting < 16 )
	{
		pOven->boardDropConfig = bdConfigSetting;
		status = Oven_setBoardProcessConfigOptions(pOven);
	}
	Oven_setBelts(pOven, pOven->noBelts );
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardsProcessedConfig
		LANE1	LANE2
 0.     0		0
 1.		1		0
 2.		0       1
 3.     1       1			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setBoardsProcessedConfig(Oven* pOven, DWORD bpConfigSetting )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setBoardsProcessedConfig", 0);
	
	if ( bpConfigSetting < 4 )
	{
		pOven->boardsProcessedConfig = bpConfigSetting;
		status = Oven_setBoardProcessConfigOptions(pOven);
	}
	Oven_setBelts(pOven, pOven->noBelts );
	Oven_EnergyClearTime(pOven);//to clear any countdown on oven start
	return status;
}
	
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardsInOvenConfig
	LANE1	LANE2
 0.	  0		  0
 1.	  1		  0
 2.	  0	      1
 3.   1       1				
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setBoardsInOvenConfig(Oven* pOven, DWORD boConfigSetting )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setBoardsInOvenConfig", 0);

	if ( boConfigSetting < 4 )
	{
		pOven->boardsInOvenConfig = boConfigSetting;
		status = Oven_setBoardProcessConfigOptions(pOven);
	}
	Oven_setBelts(pOven, pOven->noBelts );
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setJob

 A new job can be loaded when:
		1. the new job no is not the same as the current job no.
		2. As long as threre are no unacknoledged alarms.
		3. COOLDOWN can be loaded at any time.			
 
 RETURNS:   void
 ------------------------------------------------------------------------*/
void Oven_setJob(Oven* pOven, unsigned int nJobNo)
{
	BOOL bAlarmsPresent;

	bAlarmsPresent = FALSE;

	if(pOven)
	{
		if ( nJobNo != pOven->jobNo )	// when these are not equal the job has changed.
		{
			// start timer for all SMEMA 9851 lanes
			if (g_dbContainer.smema1.SMEMA_Type == SMEMA_9851)
				g_dbContainer.smema1.dwrdNewRecipeTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			if (g_dbContainer.smema2.SMEMA_Type == SMEMA_9851)
				g_dbContainer.smema2.dwrdNewRecipeTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			if (g_dbContainer.smema3.SMEMA_Type == SMEMA_9851)
				g_dbContainer.smema3.dwrdNewRecipeTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			if (g_dbContainer.smema4.SMEMA_Type == SMEMA_9851)
				g_dbContainer.smema4.dwrdNewRecipeTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);

			g_dbContainer.smema1.cSecgemEntry = 0;
			g_dbContainer.smema2.cSecgemEntry = 0;
			g_dbContainer.smema3.cSecgemEntry = 0;
			g_dbContainer.smema4.cSecgemEntry = 0;

			pOven->m_dwrdStartUpElapse=0;
			if(pOven->skipClear==0)//setjob is called twice during recipe load,can't clearbarcode on multilane recipe load, as one lane must remain on
			{
				SMEMA_clearBarcode();
			}
			else
			{
				pOven->skipClear--;
			}
			Purge_resetCAs(&(g_dbContainer.purge));
			g_dbContainer.alarmQueueDb.m_bAudibleEnergySave=FALSE;
			pOven->mbEnergyRecipe=FALSE;
			Belts_standbyMode(&(g_dbContainer.beltsDb),FALSE);


			pOven->m_bRequestCooldown = FALSE;
			pOven->jobStartupComplete	= FALSE; 
			Oven_initiateCooldownCountdown(pOven, FALSE); //Clear any impending cooldown launch
	
			if(nJobNo)//if not loading cooldown, clear warnings
			{
				AlarmQueue_clearAllWarnings(&(g_dbContainer.alarmQueueDb));
			}
			bAlarmsPresent = AlarmQueue_alarmsPresent(&(g_dbContainer.alarmQueueDb));
			if ( ( nJobNo != COOLDOWN ) && 
				( bAlarmsPresent == FALSE ) )
			{
				pOven->tempJobNo = nJobNo;
				pOven->m_bFailureNotified = FALSE;
			}	


			if(pOven->m_uAllowBarcodeAgain == 1)
			{
				SMEMA_holdAllow();
				SMEMA_entry(&(g_dbContainer.smema1));	
				pOven->m_uAllowBarcodeAgain--;
			}
			else if(pOven->m_uAllowBarcodeAgain > 0)
			{
				pOven->m_uAllowBarcodeAgain--;		
			}
		}
		if (  nJobNo == COOLDOWN )
		{
	
			pOven->skipClear=0;
			pOven->jobNo = pOven->tempJobNo = nJobNo;
			AlarmQueue_setVIPMode(&(g_dbContainer.alarmQueueDb), FALSE);
			LightTower_setVIPMode(&(g_dbContainer.lightTower), FALSE);
			pOven->m_uAllowBarcodeAgain=0;
			g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
			g_dbContainer.smema1.m_bIsIndividualFree=FALSE;
			g_dbContainer.smema1.m_bBarcodeAllowAgain=FALSE;

			g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
			g_dbContainer.smema2.m_bIsIndividualFree=FALSE;
			g_dbContainer.smema2.m_bBarcodeAllowAgain=FALSE;

			g_dbContainer.smema3.m_bBarcodeAllow=FALSE;
			g_dbContainer.smema3.m_bIsIndividualFree=FALSE;
			g_dbContainer.smema3.m_bBarcodeAllowAgain=FALSE;
		
			g_dbContainer.smema4.m_bBarcodeAllow=FALSE;
			g_dbContainer.smema4.m_bIsIndividualFree=FALSE;
			g_dbContainer.smema4.m_bBarcodeAllowAgain=FALSE;
		}

		TempZones_enableTDMErrors(&g_dbContainer.tempZonesDb);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 Oven_setBelts

 Abstract:
 The system can be configured for 2 belts and up to four rails. There is
an iteraction between belts and rails.
 			1 Rail			2 Rails			3 Rails			4 Rails
 Belt1	b1=counter0     b1=counter0     b1=counter0     b1=AI30
			r1=counter1		r1=counter1		r1=counter1		r1=counter1
							r2=counter2   	r2=counter2  	r2=counter2
											r3=counter3		r3=counter3
															r4=counter4

 Belt2	b1=counter0 	b1=counter0		b1=counter0		b1=AI30
			r1=counter1		r1=counter1		r1=counter1		r1=counter1
			b2=counter3		r2=counter2 	r2=counter2 	r2=counter2
							b2=counter3		r3=counter3		r3=counter3
											b2=AI31			r4=counter4
															b2=AI31
 The IO points will change for the belt when there 3 or 4 rails and 2 belts
 or 4 rails with 1 belt.
 rails range: 0-4
 belts range: 1-2
 If the belt speed changes during the run then the system may lose accurate
 position information. This should not be done per Doug Smith, Heller 4/1/1998.
 When using the freq to analog converters the belt speed will need to be
 effectively integrated in order to get the distance or a time may be used.
 These options will need to be considered in the belt module.

 RETURN: BOOL - validState
------------------------------------------------------------------------*/
BOOL Oven_setBelts(Oven* pOven, DWORD nBelts )
{
	BOOL validState;

	validState = FALSE;

	if( NULL != pOven )
	{
		pOven->noBelts = (UINT)nBelts; // set in oven module
		validState = TRUE;

		Belts_setNoOfActiveBelts(&(g_dbContainer.beltsDb), pOven->noBelts );

		//NOTE: Configure both Lot processing and Non Lot processing board processing
		newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ0_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ1_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ2_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ3_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );

		newBoardQueue_configure(&(g_dbContainer.boardQ0), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure(&(g_dbContainer.boardQ1), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure(&(g_dbContainer.boardQ2), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		newBoardQueue_configure(&(g_dbContainer.boardQ3), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
	}

	return validState;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setFourthLaneEnabled
 Whenever the e-stop button is pressed load the cooldown job and set the
 E-Stop reset lamp.
 Do not allow the eStopSet flag to be cleared until the E-Stop Reset button
 is pressed.
 In the event the E-Stop button is pressed while the E-Stop Reset button is
 depressed make sure the E-Stop has priority by checking last.
 E-Stop button pressed holds the highest priority for safety reasons.			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_checkE_Stop(Oven* pOven )
{
	PARAM_CHECK( pOven, "Oven_checkE_Stop");
	if ( *(DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_ESTOP)) == TRUE  )  	// E-Stop button pressed.
	{
		pOven->eStopSet = TRUE;
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, E_STOP_ALARM, 0 );
	}
	else
	{
		pOven->eStopSet = FALSE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setFourthLaneEnabled
	From Specifications of 2/3/1998
	Oven Power Failure - Digital Input 2 - Don't scan Digital Input 2 until
	the first start group begins. If digital input 2 is low for 15 seconds
	load COOLDOWN, display power failure in alarm log, and display a popup
	dialog box "Power Failure has occurred and COOLDOWN has been loaded. OK"
	While in COOLDOWN ignore digital input 2.
  The software for power on sequencing is developed so that sequencing begins
 	immediately upon the loading of a new job or a change in set points for the
 	temperature. Essentially if the job is not COOLDOWN and a Power failure
 	does occur then load COOLDOWN. If already in COOLDOWN ignore checking for
 	power failure.
 	elapseTimer.getCurrentTics() will never return 0 tics.			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_checkForPowerFail(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkForPowerFail");
#ifdef BAD_FRANK
	return;
#else
	//Heller wants the powerfailure alarm to occur even in cooldown mode 
	//we will send a log event while in cooldown WDT 04.27.01
    if ( pOven->jobNo == COOLDOWN || pOven->jobLoadInProgress == TRUE ) 		// nothing happens on COOLDOWN
	{
		pOven->startPowFailTime = 0;
//if all these conditions are true we need to notify of the powerfailure
		if(pOven->jobLoadInProgress == FALSE)
		{
			if( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_OVEN_POWER_NORMAL) == FALSE)
			{
				if (  pOven->startPowCooldownFailTime == 0 )
				{
					pOven->startPowCooldownFailTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));	// one shot - no power and haven't started time
					pOven->currentPowFailCooldownTime = 0;
				}
				if(pOven->startPowCooldownFailTime)
				{
					pOven->currentPowFailCooldownTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
//adding three second delay see comment further down in else statement WDT 07.19.01
					if(!pOven->m_bFailureNotified)
					{
						if ( (pOven->currentPowFailCooldownTime - pOven->startPowCooldownFailTime)  >= POWER_FAIL_WARNING_TIME_10THS )
						{
							pOven->m_bFailureNotified = TRUE; 
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, POWER_FAILURE_EVENT, 0);
							pOven->m_bIsPowerOKForWarningTime = FALSE;
						}
					}
				}
			}
			else
			{
				pOven->startPowCooldownFailTime = 0;
				pOven->currentPowFailCooldownTime = 0;
				pOven->m_bIsPowerOKForWarningTime = TRUE;
			}
		}
	}
	else
	{
		if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_OVEN_POWER_NORMAL) == TRUE )
		{
			pOven->startPowFailTime = 0; // if the power is on don't worry about.
			pOven->m_bIsPowerOKForWarningTime = TRUE;
		}
		else
		{	// the power has failed
			if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_OVEN_POWER_NORMAL) == FALSE && pOven->startPowFailTime == 0 )
			{
				pOven->startPowFailTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));	// one shot - no power and haven't started time
			}

			if ( pOven->startPowFailTime )
			{
//add an logged event if in cooldown otherwise havoc arises
//alright Tushar wants this to act a little differently.  The event should now occur immediately on 
//power failure in both operate and  cooldown mode WDT 05.01.05
//Heller has reported that the warning is triggered even if power is on, there must be interference
//or very short periods of inconcequential power loss.  They would now like a two second delay on the power
//loss warning WDT 07.19.01
				pOven->currentPowFailTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));

				if(!pOven->m_bFailureNotified)
				{
					if(pOven->currentPowFailTime - pOven->startPowFailTime >= POWER_FAIL_WARNING_TIME_10THS)
					{
						pOven->m_bFailureNotified = TRUE; 
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, POWER_FAILURE_EVENT, 0);
						pOven->m_bIsPowerOKForWarningTime = FALSE;
					}
				}

				// 150 tenths of seconds == 15 seconds
				if ( (pOven->currentPowFailTime - pOven->startPowFailTime)  >= pOven->m_iPowerfailureTime )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, POWER_FAILURE_ALARM, 0);
				}
			}
		}
	}
#endif
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_checkForLowExhaust
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/

void Oven_checkForLowExhaust(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkForLowExhaust");
	if ( pOven->jobNo == COOLDOWN ) 		// nothing happens on COOLDOWN
	{
		pOven->startLowExhaustTime = 0;
	}
	else
	{	
		// Not failsafe per Ray Lachenauer 09/29/98
		// On low exhaust the relay will energize causing the warning and alarm
		// conditions.
		// change IDI_EXHAUST_FLOW_NORMAL to IDI_LOW_EXHAUST
		// sdy - 09/29/98

		if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_LOW_EXHAUST) == FALSE )	// Relay not energized.
		{
			pOven->startLowExhaustTime = 0; // exhaust OK don't worry.
		}
		else
		{	
			// Modified per Ray Lacheneaur 09/29/98
			// sdy - 09/29/98
			if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_LOW_EXHAUST) == TRUE && pOven->startLowExhaustTime == 0 )
			{
				pOven->startLowExhaustTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));	// one shot - no power and haven't started time
				pOven->lowExhaustWarningSent = FALSE;
			}

			if ( pOven->startLowExhaustTime )
			{

				if ( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startLowExhaustTime) > (DWORD) pOven->m_iLowExhWarning )
				{
					if(pOven->m_bExhaustWarningsEnabled)
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, LOW_EXHAUST_WARNING, 0);
					}
					pOven->lowExhaustWarningSent = TRUE;
				}
				if(pOven->lowExhaustWarningSent == TRUE)
				{   // 30 Seconds in tenths of seconds = 300--replaced, dynamically linked to system record
					if ( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startLowExhaustTime) > (DWORD) pOven->m_iLowExhAlarm )
					{
						if(pOven->m_bExhaustAlarmsEnabled)
						{
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, LOW_EXHAUST_ALARM, 0);
						}
					}
				}
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_checkBlowerFailure
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_checkBlowerFailure(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkBlowerFailure");
	if ( pOven->blowerFailureCheckEnabled )
	{
		if ( pOven->jobNo == COOLDOWN ) 		// nothing happens on COOLDOWN
		{
			pOven->startBlowerFailTime = 0;
		}
		else
		{			
			if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_BLOWER_FAILURE) == TRUE )	 // 24V Signal is OK.
			{
				pOven->startBlowerFailTime = 0; // exhaust OK don't worry.
			}
			else
			{	
				if ( pOven->startBlowerFailTime == 0 )  // 24V signal is gone
				{
					pOven->startBlowerFailTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));	// one shot - no power and haven't started time
				}

				if ( pOven->startBlowerFailTime )
				{
					if(pOven->m_bFanFaultAlarm==TRUE)
					{
						if ( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startBlowerFailTime) > pOven->m_iBFATime ) // wait for 15 seconds to send alarm.
						{
							
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, HEAT_FAN_FAULT_ALARM_CODE, 0);
						}
					}
					if(pOven->m_bBFWarn == TRUE)
					{
						if ( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startBlowerFailTime) > pOven->m_iBFWTime ) // wait for 15 seconds to send alarm.
						{
							if(pOven->m_bAudibleBlowFail==TRUE)
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, HEAT_FAN_FAULT_WARN_CODE, 0);
							}
							else
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, HEAT_FAN_FAULT_WARN_CODE_NONAUDIBLE, 0);
							}
						}
					}
				}
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_checkForHighWaterTemp
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_checkForHighWaterTemp(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkForHighWaterTemp");
	if ( pOven->jobNo == COOLDOWN ) 		// nothing happens in cooldown
	{
		pOven->startHighWaterTempTime = 0;
	}
	else // actual job running
	{
		// jwf 01/25/01 || nitrogenDb.getNitrogenEnable() == TRUE
		// removed from the if statement in order to seperate the 
		// h20 high temp alarm from the nitrogen alarm
		if ( *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_HI_H2O_TEMP) == FALSE  ) // no problems  
		{
			pOven->startHighWaterTempTime = 0;
		}
		else 
		{
			if ( pOven->startHighWaterTempTime == 0 )	// a problem may be in progress
			{
				pOven->startHighWaterTempTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
			}
			else // The problem has been in progress and if it lasts for more than specified seconds alarm and/or warn
			{
				// check alarm time
				if( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startHighWaterTempTime) / 10 > pOven->m_dwrdWaterTempHighAlarmTime)
				{
					if(pOven->m_bWaterTempHighEnable)
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, HIGH_H2O_TEMP_ALARM, 0);
					}
				}
				// check warning time
				if( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startHighWaterTempTime) / 10 > pOven->m_dwrdWaterTempHighWarningTime)
				{
					if(pOven->m_bWaterTempHighEnable)
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, HIGH_H2O_TEMP_WARNING, 0);
					}
				}
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SetJobNewJobLoadedOutput
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_SetJobNewJobLoadedOutput(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_SetJobNewJobLoadedOutput");
	
	if (Oven_isJobLoadInProgress(pOven) && !pOven->FiveSecondTimerIsRunning)  //
	{
		pOven->FiveSecondStartTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
		pOven->FiveSecondTimerIsRunning = TRUE;	
	}
	else
	{
		if(pOven->FiveSecondTimerIsRunning)
		{
			if(pOven->jobNo != COOLDOWN)
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = TRUE;
			pOven->FiveSecondCurrentTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
			if ((pOven->FiveSecondCurrentTime - pOven->FiveSecondStartTime) >= FIVE_SECOND_DELAY)
			{
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = FALSE;
				pOven->FiveSecondTimerIsRunning = FALSE;
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_process

			Main Loop Oven Processing 
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_process(Oven* pOven)
{
	DWORD dif;
	DWORD tim;
	BOOL bLaunchCooldown;
	DWORD localCooldownTime;
	UINT requestLevel;

	signed int nBoardCount;
	signed int blowerBoardLoad;
	BOOL bInCooldown;

	dif = 0;
	tim = 0;
	bLaunchCooldown = FALSE;
	localCooldownTime = 0;
	requestLevel = RUN_LEVEL_LOW;

	nBoardCount = 0;
	blowerBoardLoad = 0;
	bInCooldown = FALSE;

	Oven_set_globals(); //sets oven parameters, to cooridinate with schedule loop

	if( NULL != pOven)
	{
		tim = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));

		if(pOven->wantResume == FALSE) //job load has not completed, timeout?
		{
			dif = tim - pOven->m_dwrdLoadTime;
			if(dif > RECIPE_LOAD_TIMEOUT)
			{
				Oven_setJob(pOven, COOLDOWN);
			}

		}
		// PROCESS E-STOP
		Oven_checkE_Stop(pOven);
		Oven_checkForPowerFail(pOven);
		Oven_checkForLowExhaust(pOven);
		Oven_checkForHighWaterTemp(pOven);
		Oven_checkForOverTemp(pOven);
		Oven_checkBlowerFailure(pOven);
		if( (pOven->m_EnergySaving_StandbyMode1_Enabled==TRUE) || (pOven->mbEnergyStandy==TRUE)||
			(pOven->mbEnergyCooldown==TRUE) || pOven->m_EnergySaving_eStandbyMode2_LoadRecipe==TRUE )
		{
			Oven_EnergyProcessing(pOven);
		}
		if ( ( pOven->jobNo == COOLDOWN ) && ( pOven->tempJobNo == COOLDOWN ) )
		{
			Oven_setSecondaryJob(pOven, pOven->jobNo);	
		}
	
		Oven_checkJobLoad(pOven);
		if( !pOven->m_bFiveSecondDisabled )//need output for second audible alarm in some ovens
		{
			Oven_SetJobNewJobLoadedOutput(pOven); // added 1/25/01 jwf
		}

		pOven->scanCounts++;
		if(pOven->jobNo == COOLDOWN)
		{
			pOven->m_bPendingCooldown=FALSE;
			pOven->mStartEnergyCountdown=tim;
			pOven->mEnergyCooldownTimer=tim;
			pOven->mbEnergyNoteSent=FALSE;
		}
		if (pOven->jobNo != COOLDOWN )
		{
			if( pOven->m_bPendingCooldown == TRUE )
			{
				bLaunchCooldown = Oven_LaunchCooldown(pOven);
				if( bLaunchCooldown == TRUE )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_CLEARED_COOLDOWN, 0);
					pOven->m_bPendingCooldown = FALSE;				
					pOven->m_bRequestCooldown = TRUE;
				}
			}
			if(pOven->m_bCooldownCountOn == TRUE)
			{
				localCooldownTime = pOven->m_dwrdCooldownStartTime + (pOven->m_dwrdDelayedCooldownTime * OVEN_ONE_MINUTE);
				if( localCooldownTime < tim )
				{
					pOven->m_bCooldownCountOn = FALSE;
					Oven_setJob(pOven, COOLDOWN);
					pOven->m_bRequestCooldown = TRUE;
				}
			}
		}

		if ( ( pOven->jobNo != COOLDOWN ) && ( pOven->jobLoadInProgress == FALSE ) )
		{
			*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_CONVEYOR_BLOWER) = TRUE;
			pOven->COOLDOWNachievedFlag = FALSE;
		}
		else 
		{
			if(pOven->jobNo == COOLDOWN)
			{
				pOven->m_bPendingCooldown = FALSE;
			}

			bInCooldown = Oven_isCOOLDOWNcomplete(pOven);
			if (  bInCooldown == TRUE )
			{
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_CONVEYOR_BLOWER) = FALSE;
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = FALSE;
			}
		}

		requestLevel = RUN_LEVEL_LOW;
		nBoardCount = Oven_GetBoardCount(pOven);
		blowerBoardLoad = 0;

		blowerBoardLoad = g_dbContainer.boardQ0_NoLP.blowerBoardLoad;

		if ( nBoardCount >= blowerBoardLoad )
		{
			requestLevel = RUN_LEVEL_HIGH;	
		}
		else if ( nBoardCount > 0 )
		{
			requestLevel = RUN_LEVEL_MEDIUM;
		}

		HeatZoneBlowers_requestIE(&(g_dbContainer.heatZoneBlowers),requestLevel);
		Fans_requestIE(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan), requestLevel);
		
		if(pOven->mbAlarmScanner==TRUE)
		{
			if(pOven->miAlarmOutput!=ODO_NULL)//option can be used without an output selection
			{
				*DOUT_GetAt(&(g_dbContainer.digitalOutDb), pOven->miAlarmOutput) =  
					pOven->mbAlarmState;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setSMEMAConfig

			Configures the oven's SMEMA options

 RETURNS:   BOOL - valid Configuration
------------------------------------------------------------------------*/
BOOL Oven_setSMEMAConfig(Oven* pOven, DWORD smemaConfigOption )
{
	BOOL validConfig;
	UINT lowerNibble;
	UINT upperNibble;
	UINT smema3lower;
	UINT smema3upper;
	
	validConfig = TRUE;
	lowerNibble = smemaConfigOption & SMEMACONFIG_LOWER_NIBBLE_MASK;
	upperNibble = smemaConfigOption & SMEMACONFIG_UPPER_NIBBLE_MASK;
	smema3lower = smemaConfigOption & SMEMA3_LOWER_BIT;
	smema3upper = smemaConfigOption & SMEMA3_UPPER_BIT;

	if( NULL != pOven )
	{
		if( smema3lower == SMEMA3_LOWER_BIT )
		{
			lowerNibble=SMEMA_9851_BELT1_BIT;
		}

		if( smema3upper == SMEMA3_UPPER_BIT )
		{
			upperNibble = SMEMA_9851_BELT2_BIT;
		}

		switch ( lowerNibble )
		{
			case SMEMA_NOSMEMA_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), NO_SMEMA );
				SMEMA_setType(&(g_dbContainer.smema3), NO_SMEMA );
				break;
			case SMEMA_SMEMAII_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), SMEMA_II );
				SMEMA_setType(&(g_dbContainer.smema3), SMEMA_II );
				break;
			case SMEMA_TDK_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), TDK );
				SMEMA_setType(&(g_dbContainer.smema3), TDK );
				break;
			case SMEMA_FUJI_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), FUJI );
				SMEMA_setType(&(g_dbContainer.smema3), FUJI );	
				break;
			case SMEMA_SEAGATE_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), SEAGATE );
				SMEMA_setType(&(g_dbContainer.smema3), SEAGATE );
				break;
			case SMEMA_9851_BELT1_BIT:
				SMEMA_setType(&(g_dbContainer.smema1), eSMEMA_9851INTERFACES );
				SMEMA_setType(&(g_dbContainer.smema3), eSMEMA_9851INTERFACES );

				//NOTE: Both LotProcessing and Non LotProcessing Queues are
				//set to active.
				g_dbContainer.boardQ0_NoLP.boardQueueActive = TRUE;
				g_dbContainer.boardQ2_NoLP.boardQueueActive = TRUE;
				g_dbContainer.boardQ0.boardQueueActive = TRUE;
				g_dbContainer.boardQ2.boardQueueActive = TRUE;
				break;
			default:
				validConfig = FALSE;
		}
	
		switch ( upperNibble )
		{
			case SMEMA_NOSMEMA_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), NO_SMEMA );
				SMEMA_setType(&(g_dbContainer.smema4), NO_SMEMA );
				break;
			case SMEMA_SMEMAII_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), SMEMA_II );
				SMEMA_setType(&(g_dbContainer.smema4), SMEMA_II );
				break;
			case SMEMA_TDK_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), TDK );
				SMEMA_setType(&(g_dbContainer.smema4), TDK );
				break;
			case SMEMA_FUJI_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), FUJI );
				SMEMA_setType(&(g_dbContainer.smema4), FUJI );
				break;
			case SMEMA_SEAGATE_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), SEAGATE );
				SMEMA_setType(&(g_dbContainer.smema4), SEAGATE );
				break;
			case SMEMA_9851_BELT2_BIT:
				SMEMA_setType(&(g_dbContainer.smema2), eSMEMA_9851INTERFACES );
				SMEMA_setType(&(g_dbContainer.smema4), eSMEMA_9851INTERFACES );

				//NOTE: Set both Lot Processing and Non Lot Processing queues active
				g_dbContainer.boardQ1_NoLP.boardQueueActive = TRUE;
				g_dbContainer.boardQ3_NoLP.boardQueueActive = TRUE;

				g_dbContainer.boardQ1.boardQueueActive = TRUE;
				g_dbContainer.boardQ3.boardQueueActive = TRUE;
				break;
			default:
				validConfig = FALSE;
				break;
		}
	
		pOven->smemaConfig = smemaConfigOption;
	}

	return validConfig;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardAnimationConfig
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setBoardAnimationConfig(Oven* pOven, DWORD boardAnimationConfigOption )
{
	BOOL validConfig = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setBoardAnimationConfig", 0);

	if ( boardAnimationConfigOption <= 3 )
	{
		pOven->animationConfig	= boardAnimationConfigOption;
		validConfig = TRUE;
	}
	return validConfig;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardProcessConfigOptions

			Configures the board processing for the Oven			
			
 RETURNS:   BOOL - True if successful; False otherwise
------------------------------------------------------------------------*/
BOOL Oven_setBoardProcessConfigOptions(Oven* pOven )
{
	BOOL status;
	BOOL bConfigStatus;

	status = TRUE;
	bConfigStatus = FALSE;

	if( NULL != pOven )
	{
		//NOTE: Configure both Lot Processing and Non Lot Processing Queues.
		bConfigStatus = newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ0_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ1_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ2_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure_NoLP(&(g_dbContainer.boardQ3_NoLP), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure(&(g_dbContainer.boardQ0), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure(&(g_dbContainer.boardQ1), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure(&(g_dbContainer.boardQ2), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		bConfigStatus = newBoardQueue_configure(&(g_dbContainer.boardQ3), pOven->boardDropConfig, pOven->boardsProcessedConfig, pOven->boardsInOvenConfig );
		if ( bConfigStatus == FALSE )
		{
			status = FALSE;
		}

		if ( BoardDropLB_configure(&(g_dbContainer.boardDropLB0), pOven->boardDropConfig ) == FALSE )
		{
			status = FALSE;
		}
		if ( BoardDropLB_configure(&(g_dbContainer.boardDropLB1), pOven->boardDropConfig ) == FALSE )
		{
			status = FALSE;
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_pause
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_pause(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_pause");
	pOven->m_dwrdLoadTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	pOven->jobLoadInProgress = TRUE;
	pOven->wantResume = FALSE;
	pOven->scanCounts = 0;
	pOven->loadTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);	//ver8.0.0.24

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_resume


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_resume(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_resume");
	pOven->wantResume = TRUE;
	Oven_setStartWithJob(pOven, TRUE );
	pOven->m_bStarted = TRUE;


}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_checkJobLoad
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_checkJobLoad(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_checkJobLoad");
	BOOL bProcessLoopStarted = AlarmQueue_getProcessLoopStarted(&(g_dbContainer.alarmQueueDb));

	if ( pOven->wantResume == TRUE && pOven->scanCounts >= 2 )
	{
		//This will tell the alarmqueue not to register the TIMER_LOSS
		//alarm once external timer tick is stable.
		if(!bProcessLoopStarted)
		{
			AlarmQueue_setProcessLoopStarted(&(g_dbContainer.alarmQueueDb), TRUE);
		}
		if(pOven->jobNo != pOven->tempJobNo)
		{
			pOven->skipClear=0;
			FluxCondensor_recipeStarted(&(g_dbContainer.fluxCondensor));
		}
		pOven->jobNo = pOven->tempJobNo;
		pOven->jobLoadInProgress = FALSE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setScanPeriod
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setScanPeriod(Oven* pOven, DWORD scanTime )
{
	PARAM_CHECK( pOven, "Oven_setScanPeriod");
	pOven->scanPeriod = scanTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getScanTime
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getScanTime( Oven* pOven )
{
	PARAM_CHECK_RETURN( pOven, "Oven_getScanTime", 0);
	return pOven->scanPeriod;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setRecipeName
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setRecipeName(Oven* pOven, char *recipe_name )
{
	unsigned long recipeNameLength = 0;
	char *pRecipeName = pOven->recipeName;
	char *pRecipe_Name = recipe_name;
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pOven, "Oven_setRecipeName", 0);

	recipeNameLength = strlen(recipe_name);
	if ( recipeNameLength >= MAX_RECIPE_NAME_LENGTH )
	{
		*(recipe_name + MAX_RECIPE_NAME_LENGTH-1) = '\0';
		status = FALSE;
	}
	
	strncpy( pRecipeName, pRecipe_Name, MAX_RECIPE_NAME_LENGTH );

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getRecipeName
			
 GLOBALS:
 RETURNS:   char*
 SEE ALSO:
------------------------------------------------------------------------*/
char* Oven_getRecipeName(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getRecipeName", 0);
	return pOven->recipeName;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setModelNo
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_setModelNo(Oven* pOven, DWORD model_no )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pOven, "Oven_setModelNo", 0);
	
	if ( model_no < eADD_ABOVE_OVENMODEL )
	{
		pOven->modelNo = model_no;
		status = TRUE;
	}
	else
	{
		printk("error in primary setModelNo, value %d out of range %d\n", model_no, eADD_ABOVE_OVENMODEL);
	}
	if( (model_no == e1913_OVENMODELS)|| model_no == e1914_OVENMODELS)
	{
		FluxCondensor_useHighFluxHeater(&(g_dbContainer.fluxCondensor), TRUE);		
	}
	else
	{
		FluxCondensor_useHighFluxHeater(&(g_dbContainer.fluxCondensor), FALSE);		
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getModelNo
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getModelNo(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getModelNo", 0);
	return pOven->modelNo;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setDirection

			sets the direction
			TRUE = left to right - the standard direction.
			FALSE = right to left - the non-standard direction.

 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_setDirection(Oven* pOven, BOOL standardDirection )
{
	if(NULL != pOven)
	{
		pOven->leftToRight = standardDirection;

		if ( (pOven->modelNo == e2060_OVENMODELS) ||
			(pOven->modelNo == e1914_OVENMODELS) )
		{
			DbContainer_configureIO( &g_dbContainer );
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getDirection
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getDirection(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDirection", 0);
	return pOven->leftToRight;
}

//******************************************************************************
// Oven_checkForOverTemp
//
// Abstract:
// The redundant overtemp is an addon that is configured at Heller Industries 
// to generate a 24v signal to indicate that an alarm condition exists. No 
// configuration is required therefor the alarm condition only exists when a
// 24v signal is present which eliminating fail safe operation. 
//
//	Programmer: Steven Young
//	Date: 08/16/1999
//******************************************************************************
void Oven_checkForOverTemp(Oven* pOven)
{
	BOOL* pOverTemp;
	PARAM_CHECK( pOven, "Oven_checkForOverTemp");
	if ( pOven->redundantOverTempOptionEnabled == TRUE )
	{
		if ( pOven->jobNo == COOLDOWN || pOven->jobLoadInProgress == TRUE ) 		// nothing happens on COOLDOWN
		{
			pOven->startOverTempTime = 0;
		}
		else
		{
			pOverTemp = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_REDUNDANT_OVERTEMP);
			if ( *pOverTemp  == FALSE )
			{
				pOven->startOverTempTime = 0; // The temp is below alarm conditions or overtemp not present.
			}
			else
			{	// the power has failed
				if (  pOven->startOverTempTime == 0 )
				{
					pOven->startOverTempTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));	// one shot - no power and haven't started time
				}	

				if ( pOven->startOverTempTime )
				{
					// 50 tenths of seconds == 5 seconds
					if ( (Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pOven->startOverTempTime)  >= OVERTEMP_DELAY_TIME )
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, OVERTEMP_ALARM, 0);
					}
				}
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_ExternalCheckForPowerFailure
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_ExternalCheckForPowerFailure(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_ExternalCheckForPowerFailure", 0);
	return 	 pOven->m_bIsPowerOKForWarningTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_initiateCooldownCountdown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_initiateCooldownCountdown(Oven* pOven, BOOL bInit)
{
	PARAM_CHECK( pOven, "Oven_initiateCooldownCountdown");
	if(bInit) //start countdown
	{
		if(!pOven->m_dwrdDelayedCooldownTime)
		{
			Oven_setJob(pOven, COOLDOWN);
		}
		else
		{
			if(!pOven->m_bCooldownCountOn)
			{
				pOven->m_bRequestCooldown = FALSE;
				pOven->m_dwrdCooldownStartTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
				pOven->m_bCooldownCountOn = TRUE;
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, COOLDOWN_COUNTDOWN_STARTED, 0);
			}
		}
	}
	else //terminate countdown
	{
		if(pOven->m_bCooldownCountOn)
		{
			AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, COOLDOWN_COUNTDOWN_ABORTED, 0);
		}
		pOven->m_bCooldownCountOn = FALSE;
	}

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setDelayedCooldown(Oven* pOven, BOOL cooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setDelayedCooldown");
	pOven->m_bDelayedCooldown = cooldownDelayed;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDelayedCooldown", 0);
	return pOven->m_bDelayedCooldown;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setCurrentMonitorDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setCurrentMonitorDelayedCooldown(Oven* pOven, BOOL currentMonitorCooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setCurrentMonitorDelayedCooldown");
	pOven->m_bCurrentMonitorDelayedCooldown = currentMonitorCooldownDelayed;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getCurrentMonitorDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getCurrentMonitorDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getCurrentMonitorDelayedCooldown", 0);
	return pOven->m_bCurrentMonitorDelayedCooldown;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setHeaterFailureDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setHeaterFailureDelayedCooldown(Oven* pOven, BOOL heaterFailureCooldownDelayed)
{
	PARAM_CHECK( pOven, "Oven_setHeaterFailureDelayedCooldown");
	pOven->m_bHeaterFailureDelayedCooldown = heaterFailureCooldownDelayed;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getHeaterFailureDelayedCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getHeaterFailureDelayedCooldown(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getHeaterFailureDelayedCooldown", 0);
	return pOven->m_bHeaterFailureDelayedCooldown;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setDelayedCooldownTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setDelayedCooldownTime(Oven* pOven, int iTime)
{
	PARAM_CHECK( pOven, "Nitrogen_setCoolRunTime");
	pOven->m_dwrdDelayedCooldownTime = (DWORD)iTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getAppCoolFlag
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getAppCoolFlag(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getAppCoolFlag", 0);
	BOOL bReturnFlag = pOven->m_bRequestCooldown;
	
	if(pOven->jobLoadInProgress)//dont trigger cooldown when a load is in process
	{
		bReturnFlag=FALSE;
	}
	return bReturnFlag;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_ClearCN
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void OVEN_ClearCN(Oven* pOven)
{
	pOven->m_bRequestCooldown =FALSE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_isEStopSet
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_isEStopSet(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_isEStopSet", 0);
	return pOven->eStopSet; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getNoBelts
			
 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Oven_getNoBelts(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getNoBelts", 0);
	return pOven->noBelts; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SetDemoMode
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_SetDemoMode(Oven* pOven, BOOL demoModeState) 
{
	PARAM_CHECK( pOven, "Oven_SetDemoMode");
	pOven->demoMode = demoModeState; 
	

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getDemoMode
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getDemoMode(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getDemoMode", 0);
	return pOven->demoMode; 
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getJob
			
 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Oven_getJob(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getJob", 0);
	return pOven->jobNo; 
}		

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_isJobStartupComplete
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_isJobStartupComplete(Oven* pOven)		
{
	PARAM_CHECK_RETURN( pOven, "Oven_isJobStartupComplete", 0);
	return pOven->jobStartupComplete; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setJobStartupComplete
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setJobStartupComplete(Oven* pOven, BOOL jobStartupState /*= TRUE*/ )	
{
	PARAM_CHECK( pOven, "Oven_setJobStartupComplete");
	pOven->jobStartupComplete = jobStartupState;
	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_isJobLoadInProgress
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_isJobLoadInProgress(Oven* pOven)	
{
	PARAM_CHECK_RETURN( pOven, "Oven_isJobLoadInProgress", 0);
	return pOven->jobLoadInProgress; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setCOOLDOWNachieved
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setCOOLDOWNachieved (Oven* pOven, BOOL atCoolDown )
{ 
	PARAM_CHECK( pOven, "Oven_setCOOLDOWNachieved");
	pOven->COOLDOWNachievedFlag = atCoolDown;
} 		

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_isCOOLDOWNcomplete
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_isCOOLDOWNcomplete(Oven* pOven)	
{
	PARAM_CHECK_RETURN( pOven, "Oven_isCOOLDOWNcomplete", 0);
	return  pOven->COOLDOWNachievedFlag; 
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setStartWithJob

			used by the scheduler

 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_setStartWithJob(Oven* pOven, BOOL jobState /*= FALSE*/ )
{
	if(jobState)
	{
		gSeqeunceStatus |= STARTUP_WITHJOB;
	}
	else
	{
		gSeqeunceStatus  &= ~(STARTUP_WITHJOB);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setRedundantOverTempOption
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setRedundantOverTempOption(Oven* pOven, BOOL option /*= TRUE*/ )
{
	PARAM_CHECK( pOven, "Oven_setRedundantOverTempOption");
	pOven->redundantOverTempOptionEnabled = option; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setLTOption
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setLTOption(Oven* pOven, BOOL option /*= TRUE*/ ) 
{
	PARAM_CHECK( pOven, "Oven_setLTOption");
	pOven->lto = option; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getLTOption
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getLTOption(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getLTOption", 0);
	return pOven->lto; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBlowerFailureOption
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setBlowerFailureOption(Oven* pOven, BOOL option /*= TRUE*/)
{
	PARAM_CHECK( pOven, "Oven_setBlowerFailureOption");
	pOven->blowerFailureCheckEnabled = option; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getBlowerFailureOption
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getBlowerFailureOption(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getBlowerFailureOption", 0);
	return pOven->blowerFailureCheckEnabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setAutoCleanFlux
			
			populates the buffer in networkbridge control to group send a recipe

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setAutoCleanFlux(Oven* pOven, BOOL autoCleanMode /*= TRUE*/) 
{
	PARAM_CHECK( pOven, "Oven_setAutoCleanFlux");
	pOven->autoCleanFluxMode = autoCleanMode; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getAutoCleanFlux
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getAutoCleanFlux(Oven* pOven) 
{
	PARAM_CHECK_RETURN( pOven, "Oven_getAutoCleanFlux", 0);
	return pOven->autoCleanFluxMode;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setThirdLaneEnabled
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setThirdLaneEnabled(Oven* pOven, BOOL laneEnabled ) 
{
	PARAM_CHECK( pOven, "Oven_setThirdLaneEnabled");
	pOven->lane3Enabled = laneEnabled; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setFourthLaneEnabled
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setFourthLaneEnabled(Oven* pOven, BOOL laneEnabled ) 
{
	PARAM_CHECK( pOven, "Oven_setFourthLaneEnabled");
	pOven->lane4Enabled = laneEnabled; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setLowExhaustWarningTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setLowExhaustWarningTime(Oven* pOven, int LEwarn)	
{
	PARAM_CHECK( pOven, "Oven_setLowExhaustWarningTime");
	pOven->m_iLowExhWarning=LEwarn;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setLowExhaustAlarmTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setLowExhaustAlarmTime(Oven* pOven, int LEalarm)
{
	PARAM_CHECK( pOven, "Oven_setLowExhaustAlarmTime");
	pOven->m_iLowExhAlarm=LEalarm;
	
}
#if 0
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setAsBoardTypeA
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setAsBoardTypeA(Oven* pOven, BOOL bType)
{
	PARAM_CHECK( pOven, "Oven_setAsBoardTypeA");
	pOven->m_bTypeA = bType;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getIsBoardTypeA
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getIsBoardTypeA(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsBoardTypeA", 0);
	return pOven->m_bTypeA;
}
#else
void Oven_waterTempHighEnable(Oven *pOven, BOOL bEnable)
{
	pOven->m_bWaterTempHighEnable = bEnable;
}

void Oven_waterTempHighAlarmTime(Oven *pOven, DWORD dwrdAlarmTime)
{
	pOven->m_dwrdWaterTempHighAlarmTime = dwrdAlarmTime;
}

void Oven_waterTempHighWarningTime(Oven *pOven, DWORD dwrdWarningTime)
{
	pOven->m_dwrdWaterTempHighWarningTime = dwrdWarningTime;
}
#endif
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setExhaustWarningEnable
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setExhaustWarningEnable(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_setExhaustWarningEnable");
	pOven->m_bExhaustWarningsEnabled = !bDisabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setExhaustAlarmEnable
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setExhaustAlarmEnable(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_setExhaustAlarmEnable");
	pOven->m_bExhaustAlarmsEnabled = !bDisabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_disableAutoAcknowledge
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_disableAutoAcknowledge(Oven* pOven, BOOL bEntered)
{
	PARAM_CHECK( pOven, "Oven_disableAutoAcknowledge");
	pOven->m_bSelfAcknowledgeDisabled = bEntered;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_disableDevAlarmInStartup
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_disableDevAlarmInStartup(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_disableDevAlarmInStartup");
	pOven->m_bDisableDevAlarmInStartup = bDisabled;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getIsAutoAcknowledgedDisabled
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getIsAutoAcknowledgedDisabled(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsAutoAcknowledgedDisabled", 0);
	return pOven->m_bSelfAcknowledgeDisabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getIsDevAlarmInStartupDisabled
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getIsDevAlarmInStartupDisabled(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getIsDevAlarmInStartupDisabled", 0);
	return pOven->m_bDisableDevAlarmInStartup;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setStartupCompletePlusDelay
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setStartupCompletePlusDelay(Oven* pOven, int iTimeInSec)
{
	PARAM_CHECK( pOven, "Oven_setStartupCompletePlusDelay");
	pOven->m_StartupCompletePlusDelayTime = (DWORD)(iTimeInSec * 10);  //Time in 10th of seconds
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getStartupCompletePlusDelayTime
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getStartupCompletePlusDelayTime(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getStartupCompletePlusDelayTime", 0);
	return pOven->m_StartupCompletePlusDelayTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setPowerFailureTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setPowerFailureTime(Oven* pOven, UINT fTime)
{
	PARAM_CHECK( pOven, "Oven_setPowerFailureTime");
	pOven->m_iPowerfailureTime = fTime;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setFiveSecondDisable
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setFiveSecondDisable(Oven* pOven, BOOL bDisabled)
{
	PARAM_CHECK( pOven, "Oven_setFiveSecondDisable");
	pOven->m_bFiveSecondDisabled = bDisabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getFiveSecondDisable
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getFiveSecondDisable(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getFiveSecondDisable", 0);
	return pOven->m_bFiveSecondDisabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getTempJobNo
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getTempJobNo(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getTempJobNo", 0);	
	return pOven->tempJobNo;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setAppFlag
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setAppFlag(Oven* pOven, BOOL bWeNeedCooldown)
{
	PARAM_CHECK( pOven, "Oven_setAppFlag");
	pOven->m_bRequestCooldown = bWeNeedCooldown;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_cooldownModePending
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_cooldownModePending(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_cooldownModePending", 0);
	return pOven->m_bCooldownCountOn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_returnOvenProgrammed
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_returnOvenProgrammed(Oven * pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_returnOvenProgrammed", 0);
	return pOven->m_bStarted;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBoardStopOption

			Configures the Board Stop Option for the specified lane
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_setBoardStopOption(BOOL bEnabled, int iMainLane)
{	
	if( iMainLane == 1 )//apply lane 1 to lanes 1 and 3
	{
		//NOTE: Set both Lot Processing and Non Lot Processing Queues
		newBoardQueue_enableBoardStop_NoLP(&(g_dbContainer.boardQ0_NoLP), bEnabled);
		newBoardQueue_enableBoardStop_NoLP(&(g_dbContainer.boardQ2_NoLP), bEnabled);
		newBoardQueue_enableBoardStop(&(g_dbContainer.boardQ0), bEnabled);
		newBoardQueue_enableBoardStop(&(g_dbContainer.boardQ2), bEnabled);
	}
	else
	{
		//NOTE: Set both Lot Processing and Non Lot Processing Queues
		newBoardQueue_enableBoardStop_NoLP(&(g_dbContainer.boardQ1_NoLP), bEnabled);
		newBoardQueue_enableBoardStop_NoLP(&(g_dbContainer.boardQ3_NoLP), bEnabled);
		newBoardQueue_enableBoardStop(&(g_dbContainer.boardQ1), bEnabled);
		newBoardQueue_enableBoardStop(&(g_dbContainer.boardQ3), bEnabled);
	}

	return;
}
			
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setStartupGroup
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setStartupGroup(Oven* pOven, DWORD dwrdGroup)
{
	PARAM_CHECK( pOven, "Oven_setStartupGroup");
	pOven->m_dwrCurrentGroup = dwrdGroup;
	if(dwrdGroup > 1)
	{
		Oven_setSecondaryJob(pOven, pOven->jobNo);
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getStartupGroup
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getStartupGroup(Oven* pOven)
{
	return pOven->m_dwrCurrentGroup;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_LaunchCooldown

			Launches the cooldown job

 RETURNS:   BOOL - TRUE is successful; FALSE otherwise
------------------------------------------------------------------------*/
BOOL Oven_LaunchCooldown(Oven* pOven)
{
	BOOL bReturn;
	BOOL bNoLaunch;

	bReturn = TRUE;
	bNoLaunch = FALSE;

	if( NULL != pOven )
	{
		if( FALSE == g_bLotProcessingEnable )
		{
			bNoLaunch = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), 0) || 
						newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), 0) || 
						newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), 0) ||
						newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), 0);
		}
		else
		{
			bNoLaunch = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), 0) || 
						newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), 0) || 
						newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), 0) ||
						newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), 0);
		}

		if( bNoLaunch )
		{
			bReturn = FALSE;
		}
		else
		{
			Oven_setJob(pOven, COOLDOWN);
		}
	}
	else
	{
		bReturn = FALSE;
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_requestCooldown
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_requestCooldown(Oven* pOven)
{
	BOOL bCooldownAlreadyPending = pOven->m_bPendingCooldown;
		
	pOven->m_bPendingCooldown = !Oven_LaunchCooldown(pOven);
	if((pOven->m_bPendingCooldown == TRUE) && (bCooldownAlreadyPending!=TRUE))//no need to inform gui if cooldown already pending
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_COOLDOWN_WAIT, 0);
	}
	else if(pOven->m_bPendingCooldown ==FALSE)//TO INFORM GUI OF COOLDOWN
	{
		pOven->m_bRequestCooldown=TRUE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_alarmOnFF
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_alarmOnFF(Oven* pOven, BOOL bOn)
{
	pOven->m_bFanFaultAlarm = bOn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_BFAudible
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_BFAudible(Oven* pOven, BOOL bAud)
{
	pOven->m_bAudibleBlowFail = bAud;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBFATime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setBFATime(Oven* pOven, int iTime)
{
	pOven->m_iBFATime = iTime;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBFWTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setBFWTime(Oven* pOven, int iTime)
{
	pOven->m_iBFWTime = iTime;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_BFWarn
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_BFWarn(Oven* pOven, BOOL bOn)
{
	pOven->m_bBFWarn = bOn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setSecondaryJob
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setSecondaryJob(Oven* pOven, UINT nJobNo )
{
	PARAM_CHECK( pOven, "Oven_setSecondaryJob");	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_EnergyProcessing
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_EnergyProcessing(Oven* pOven)
{
	DWORD dwrdStage2Tim;
	DWORD dwrdCdTim;
	BOOL bReset;
	DWORD tim;
	BOOL bPositiveBrdCnt;
	DWORD cnt1;
	DWORD cnt2;
	DWORD cnt3;
	DWORD cnt4;
	BOOL bEnergyInput;
	BOOL din;

	dwrdStage2Tim = pOven->mDenergyTime;
	dwrdCdTim = pOven->mDenergyCoolTime;
	bReset = FALSE;
	tim = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	bPositiveBrdCnt = FALSE;
	cnt1 = 0;
	cnt2 = 0;
	cnt3 = 0;
	cnt4 = 0;
	bEnergyInput = FALSE;
	din = FALSE;

	if( NULL != pOven )
	{
		if(pOven->mbDoReset==TRUE)
		{
			bReset = TRUE;
			pOven->mbDoReset = FALSE;
			if(pOven->mbEnergyRecipe!=TRUE)//dont reset the cooldown timer when the standby recipe is running
			{
				pOven->mEnergyCooldownTimer = tim;
			}
			else //Accordint to tushar we must "pause" the timer for cooldown when standby is sequencing
			{
				pOven->m_dwrdStartUpElapse++;
			}
			pOven->mStartEnergyCountdown = tim;
		}
		if(pOven->m_EnergySaving_StandbyMode1_Enabled)
		{
			dwrdStage2Tim = pOven->mDenergyTime+pOven->standbyMode1Time;
		}
		if(pOven->m_EnergySaving_StandbyMode1_Enabled)
		{
			dwrdCdTim = pOven->mDenergyCoolTime+pOven->standbyMode1Time;
		}
		if(pOven->mbEnergyStandy==TRUE)
		{
			dwrdCdTim = dwrdCdTim + pOven->mDenergyTime;
		}
		if(pOven->mDwrdEnergyInput!=IDI_NULL)
		{

			din = *(DIN_GetAt(&(g_dbContainer.digitalInDb), pOven->mDwrdEnergyInput));
			if( din == FALSE)
			{
				pOven->mbEnergyInputHasLowed=TRUE;
			}
			else if(pOven->mbEnergyCooldown==TRUE&&pOven->jobNo==COOLDOWN&&pOven->mbEnergyInputHasLowed==TRUE)
			{
				HeatZoneBlower_toggleSMOne(&(g_dbContainer.heatZoneBlowers),FALSE);
				Fans_toggleSMOne(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan),FALSE);
				pOven->mbEnergyInputHasLowed=FALSE;
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, EXIT_ENERGY_MODE, 0 );
			}
		}

		if( FALSE == g_bLotProcessingEnable )
		{
			cnt1 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), 0);
			cnt2 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), 0);
			cnt3 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), 0);
			cnt4 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), 0);

			if( cnt1 != 0 || cnt2 != 0 || cnt3 != 0 || cnt4 != 0 )
			{
				bPositiveBrdCnt = TRUE;
			}
		}
		else
		{
			cnt1 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), 0);
			cnt2 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), 0);
			cnt3 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), 0);
			cnt4 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), 0);

			if( cnt1 != 0 || cnt2 != 0 || cnt3 != 0 || cnt4 != 0 )
			{
				bPositiveBrdCnt = TRUE;
			}
		}

		if( TRUE == bPositiveBrdCnt )
		{
			pOven->mStartEnergyCountdown = tim;
			pOven->mEnergyCooldownTimer = tim;
			pOven->mbEnergyNoteSent=FALSE;
		}
		else if(pOven->jobStartupComplete==FALSE)//keep counting down in standby for cooldown
		{

			if(pOven->mDwrdEnergyInput!=IDI_NULL)
			{
				bEnergyInput  = *(DIN_GetAt(&(g_dbContainer.digitalInDb), pOven->mDwrdEnergyInput));
				if( bEnergyInput == TRUE )
				{
					if((pOven->mbEnergyRecipe==TRUE)&&(pOven->mbEnergyInputHasLowed==TRUE))
					{
						pOven->mbEnergyInputHasLowed=FALSE;
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, EXIT_ENERGY_MODE, 0 );
					}
					else
					{
						HeatZoneBlower_toggleSMOne(&(g_dbContainer.heatZoneBlowers),FALSE);
						Fans_toggleSMOne(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan),FALSE);
					}
					pOven->mEnergyCooldownTimer = tim;
					pOven->mStartEnergyCountdown = tim;
					pOven->mbEnergyNoteSent=FALSE;

				}
			}
		}
		else
		{
			if(pOven->mDwrdEnergyInput!=IDI_NULL)
			{
				bEnergyInput = *(DIN_GetAt(&(g_dbContainer.digitalInDb), pOven->mDwrdEnergyInput));
				if( bEnergyInput == TRUE )
				{
					if((pOven->mbEnergyRecipe==TRUE)&&(pOven->mbEnergyInputHasLowed==TRUE))
					{
						pOven->mbEnergyInputHasLowed=FALSE;
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, EXIT_ENERGY_MODE, 0 );
					}
					pOven->mEnergyCooldownTimer = tim;
					pOven->mStartEnergyCountdown = tim;
					pOven->mbEnergyNoteSent=FALSE;
					HeatZoneBlower_toggleSMOne(&(g_dbContainer.heatZoneBlowers),FALSE);
					Fans_toggleSMOne(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan),FALSE);

				}
			}
		}
		if(pOven->mbEnergyCooldown==TRUE)
		{
			if((tim-pOven->mEnergyCooldownTimer)>(dwrdCdTim+pOven->m_dwrdStartUpElapse))
			{
				Oven_requestCooldown(pOven);
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), INFORMATION, ENTERING_ENERGY_COOLDOWN, 0 );
			}
		}
		if((pOven->mbEnergyStandy==TRUE)&&(pOven->jobNo!=COOLDOWN))
		{
			if((pOven->mbEnergyRecipe==FALSE&&pOven->mbEnergyNoteSent==FALSE)&&((tim-pOven->mStartEnergyCountdown)>dwrdStage2Tim)&&pOven->mbEnergyStandy==TRUE)
			{
				pOven->mbEnergyNoteSent=TRUE;
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), INFORMATION, ENTERING_ENERGY_MODE, 0 );
			}
		}
		if(pOven->m_EnergySaving_eStandbyMode2_LoadRecipe==TRUE&&(pOven->jobNo!=COOLDOWN))//user initiated energy standby recipe
		{
			pOven->m_EnergySaving_eStandbyMode2_LoadRecipe=FALSE;
			pOven->mbEnergyNoteSent=TRUE;
			AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), INFORMATION, ENTERING_ENERGY_MODE, 0 );
		}
	}

	return;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_EnergyClearTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_EnergyClearTime(Oven* pOven)
{
	PARAM_CHECK( pOven, "Oven_EnergyClearTime");
	DWORD tim = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	pOven->mEnergyCooldownTimer = tim;
	pOven->mStartEnergyCountdown = tim;
	pOven->mbEnergyNoteSent=FALSE;
	Belts_standbyMode(&(g_dbContainer.beltsDb),FALSE);
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setTerminal
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setTerminal(Oven* pOven, DWORD on)
{
	PARAM_CHECK( pOven, "Oven_setTerminal");
	pOven->mbOvenActive=on;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getTerminal
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Oven_getTerminal(Oven* pOven)
{
	return pOven->mbOvenActive;
}

BOOL Oven_inIE(Oven* pOven)
{
	return pOven->m_EnergySaving_IntelExhaust_Enabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_sm1
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_sm1(Oven* pOven)
{
	return pOven->m_EnergySaving_StandbyMode1_Enabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_sm2
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_sm2(Oven* pOven)
{
	return pOven->m_EnergySaving_eStandbyMode2_LoadRecipe;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_esCooldown
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_esCooldown(Oven* pOven)
{
	return FALSE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_GetBoardCount

			Sums the board counts in all 4 board queues
			
 RETURNS:   int
------------------------------------------------------------------------*/
int  Oven_GetBoardCount(Oven* pOven)
{
	int nCount;

	nCount = 0;

	if( FALSE == g_bLotProcessingEnable )
	{
		nCount += g_dbContainer.boardQ0_NoLP.boardCount;
		nCount += g_dbContainer.boardQ1_NoLP.boardCount;
		nCount += g_dbContainer.boardQ2_NoLP.boardCount;
		nCount += g_dbContainer.boardQ3_NoLP.boardCount;
	}
	else
	{
		nCount += g_dbContainer.boardQ0.m_boardCount;
		nCount += g_dbContainer.boardQ1.m_boardCount;
		nCount += g_dbContainer.boardQ2.m_boardCount;
		nCount += g_dbContainer.boardQ3.m_boardCount;
	}

	return nCount;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SlaveConfiguration
			
			this function probes objects to determine if the secondary board
			is needed
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_SlaveConfiguration()
{
	BOOL bSlave = FALSE;
	//do we have mass controllers?
	int i = 0;
	for( i = 0; ((i < MAX_MASS_CONTROLLERS) && (bSlave == FALSE)); i++)
	{
		if(g_dbContainer.masscontroller.enabled[i]==TRUE)
		{
			bSlave = TRUE;
		}
	}
	if(!bSlave)
	{
		bSlave = TempZones_useSecondaryBoard(&(g_dbContainer.tempZonesDb));
	}

	g_dbContainer.slaveConfig.bSecondaryActive = bSlave;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SetStandbyModeExhaustSpeed

 sets m_EnergySaving_StandbyMode1_ExhaustSpeed with bound check
			and warning generations

 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_SetStandbyModeExhaustSpeed(UINT speed)
{
	if( (speed >= g_dbContainer.ovenDb.m_Standby_MinBlower) && (speed <= g_dbContainer.ovenDb.m_Standby_MaxBlower) )
	{
		g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ExhaustSpeed = speed;
	}
	else
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, EXHAUSTSPEED_OUTOFRANGE, 0 );

		if(speed > g_dbContainer.ovenDb.m_Standby_MaxBlower)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ExhaustSpeed = g_dbContainer.ovenDb.m_Standby_MaxBlower;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ExhaustSpeed = g_dbContainer.ovenDb.m_Standby_MinBlower;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SetStandbyModeIESpeed

 sets m_EnergySaving_IntelExhaust_Speed with bound check
			and warning generations

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_SetStandbyModeIESpeed(UINT speed)
{
	if( (speed >= g_dbContainer.ovenDb.m_EnergySaving_MinBlower) && (speed <= g_dbContainer.ovenDb.m_EnergySaving_MaxBlower) )
	{
		g_dbContainer.ovenDb.m_EnergySaving_IntelExhaust_Speed = speed;
	}
	else
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, IESPEED_OUTOFRANGE, 0 );

		if(speed > g_dbContainer.ovenDb.m_EnergySaving_MaxBlower)
		{
			g_dbContainer.ovenDb.m_EnergySaving_IntelExhaust_Speed = g_dbContainer.ovenDb.m_EnergySaving_MaxBlower;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_IntelExhaust_Speed = g_dbContainer.ovenDb.m_EnergySaving_MinBlower;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_SetStandbyModeExhaustSpeed

 sets m_EnergySaving_StandbyMode1_ExhaustSpeed with bound check
			and warning generations

 RETURNS:   void
------------------------------------------------------------------------*/
void Oven_SetStandbyModeZoneSpeed(UINT speed)
{
	if( (speed >= g_dbContainer.ovenDb.m_Standby_MinBlower) && (speed <= g_dbContainer.ovenDb.m_Standby_MaxBlower) )
	{
		g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ZoneSpeed = speed;
	}		
	else
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, MODESPEED_OUTOFRANGE, 0 );

		if(speed > g_dbContainer.ovenDb.m_Standby_MaxBlower)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ZoneSpeed = g_dbContainer.ovenDb.m_Standby_MaxBlower;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_ZoneSpeed = g_dbContainer.ovenDb.m_Standby_MinBlower;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_allowPowerLossWarning

			 if the system is not in cooldown, resets the power failure warning

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void OVEN_allowPowerLossWarning()
{
	if(g_dbContainer.ovenDb.jobNo != COOLDOWN)
	{
		g_dbContainer.ovenDb.m_bFailureNotified = FALSE;
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_set_globals

			 sets data used by the schedule loop.  Set here so it can be set at top of 
			 schedule execution

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_set_globals()
{
	if(g_ucSetSecsgemOption)
	{
		g_ucSetSecsgemOption = 0;
		SMEMA_SecsGemEntryOption(&(g_dbContainer.smema1), g_ucSecsgemOptionSetTo);
		SMEMA_SecsGemEntryOption(&(g_dbContainer.smema2), g_ucSecsgemOptionSetTo);
		SMEMA_SecsGemEntryOption(&(g_dbContainer.smema3), g_ucSecsgemOptionSetTo);
		SMEMA_SecsGemEntryOption(&(g_dbContainer.smema4), g_ucSecsgemOptionSetTo);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_setBeltStopWhenRailMoving(Oven* pOven, BOOL bEnabled)
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Oven_setBeltStopWhenRailMoving(Oven* pOven, BOOL bEnabled)
{
	PARAM_CHECK( pOven, "Oven_setBeltStopWhenRailMoving");
	pOven->m_bBeltStopWhenRailMoving = bEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Oven_getBeltStopWhenRailMoving
			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Oven_getBeltStopWhenRailMoving(Oven* pOven)
{
	PARAM_CHECK_RETURN( pOven, "Oven_getBeltStopWhenRailMoving", 0);
	return pOven->m_bBeltStopWhenRailMoving;
}

//Function to set board entry wait time from setup wizard
void Oven_recipeLoadBoardEntryWait(Oven* pOven, DWORD seconds)
{
	pOven->boardEntryWait = seconds;
}

BOOL Oven_checkRecipeLoadBoardEntryWait(Oven* pOven)
{
#ifdef DEBUG_BOARDENTRYWAIT
	static DWORD lastReport = 0;
#endif
	// if user has specified non-zero delay after recipe load before recognizing board entry
	if (pOven->boardEntryWait > 0 &&
		// and recipe has been loaded
		pOven->loadTime > 0 &&
		// and recipe was loaded within delay margin
		(Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - pOven->loadTime) / 10 < pOven->boardEntryWait)
	{
#ifdef DEBUG_BOARDENTRYWAIT
		if (Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastReport > 10)
		{
			lastReport = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("Oven_checkRecipeLoadBoardEntryWait TRUE\n");
		}
#endif
		// then disregard boards entering
		return(TRUE);
	}
	// otherwise check SMEMA for boards entering
#ifdef DEBUG_BOARDENTRYWAIT
		if (Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastReport > 10)
		{
			lastReport = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("Oven_checkRecipeLoadBoardEntryWait FALSE\n");
		}
#endif

	return(FALSE);
}
