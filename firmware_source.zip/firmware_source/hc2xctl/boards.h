/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			boards.h

	Description:	board object 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

#ifndef __BOARDS_H__
#define __BOARDS_H__

#include "typedefdefine.h"
#include "utility.h"

/*--(LOCAL FUNCTION)----------------------------------------------------
 Class Board

 Abstract:
	Each board in the oven will have known positions or times.
	If counters are used then the position of the belt in centimeters can be used.
	If a frequency to analog converter is used then the summation of the speeds 
	divided by the number of counts to get average speed which will be as close
	as we can get to the distance the board has traveled with the best possible
  resolution.

	Programmer: Steven Young
	Date: 05/14/1998
------------------------------------------------------------------------*/
typedef struct _Board_
{
	BOOL			bInUse;					// TRUE: Board object is in use in the oven
	BOOL			hasCarrier;

	DWORD			boardLengthCounts;		// board length in counts
	DWORD			startPositionCounts;	// absolute position of belt.
	DWORD			elapsedPositionCounts;	// distance the board has travelled.

	BOOL			bBoardDropped;			// set when a board drop is detected
	BOOL			bCooldown;				// set to TRUE if the board is in the oven when COOLDOWN occurs	int iID;

	struct
	{
		LocalTime	entryLeadingEdge;
		LocalTime	entryTrailingEdge;
		LocalTime	exitLeadingEdge;
		LocalTime	exitTrailingEdge;

		BOOL		bValidEntryLeading;
		BOOL		bValidEntryTrailing;
		BOOL		bValidExitLeading;
		BOOL		bValidExitTrailing;

		BOOL		bEntryEventAdded;

	} timeStamps;

} Board;

void Board_init(Board* pBoard);
void Board_setStartPosition(Board* pBoard, DWORD boardEntryCounts ) ;
void Board_setLength(Board* pBoard,  DWORD bdLenCounts );
DWORD Board_getElapsedPositionCounts(Board* pBoard);

void Board_TimeStampSetEntry( Board* pBoard, BOOL bLeading, LocalTime* pTimeStamp );
void Board_TimeStampSetExit( Board* pBoard, BOOL bLeading, LocalTime* pTimeStamp ); 
void Board_Copy(Board* pDest, Board* pSource);

typedef struct _BoardData_
{
	const Board *pBoardArray;
	UINT  headIndex;
	UINT  tailIndex;
	DWORD maxBoards;
	DWORD boardCount;
} BoardData;

#endif
