/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __ERROR_H__
#define __ERROR_H__

#include "typedefdefine.h"

typedef struct _ErrorContainer_
{
	DWORD analogInputOverrun;
	DWORD analogOutputOverrun;
	DWORD digitalInputOverrun;
	DWORD digitalOutputOverrun;
} ErrorContainer;

void ErrorContainer_init(ErrorContainer* pErrorContainer);
void ErrorContainer_incAnalogInOverrun   (ErrorContainer* pErrorContainer);
void ErrorContainer_incAnalogOutOverrun  (ErrorContainer* pErrorContainer);
void ErrorContainer_incDigitalInOverrun  (ErrorContainer* pErrorContainer);
void ErrorContainer_incDigitalOutOverrun (ErrorContainer* pErrorContainer);

DWORD ErrorContainer_getAnalogInOverrun  (ErrorContainer* pErrorContainer);
DWORD ErrorContainer_getAnalogOutOverrun (ErrorContainer* pErrorContainer);	
DWORD ErrorContainer_getDigitalInOverrun (ErrorContainer* pErrorContainer);
DWORD ErrorContainer_getDigitalOutOverrun(ErrorContainer* pErrorContainer);

#endif

