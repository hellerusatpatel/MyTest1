//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: smema.c
//
// Description: code for smema (entrance/exit control)
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 08-Jan-15  FJN  Modify SMEMA_SMEMA_9851_LightTower1_process to hold SMEMA feed when board in entrance sensor
// 08-Jan-15  FJN  Modify SMEMA_SMEMA_9851_LightTower2_process to hold SMEMA feed when board in entrance sensor
// 03-Feb-15  FJN  Modify SMEMA_SMEMA_9851_LightTowerN_process to delay five seconds after recipe load before asserting SMEMA feed
// 03-Feb-15  FJN  Modify pBelt to be array of MAX_SMEMA_LANES
// 13-Apr-16  FJN  Modify SMEMA_checkForPastDeadBandEntrance to support m_smemaOnMinDist for SMEMA_II
// 24-Jun-16  FJN  Implement SMEMA_SetLaneHold
//*****************************************************************************
#include <memory.h>
#include "contain.h"
#include "smema.h"
#include "oven.h"
#include "belt.h"
#include "digitio.h"
#include "litetowr.h"
#include "timer.h"
#include "nitrogen.h"
#include "newboardq.h"
#include "newboardqNoLP.h"
#include "alarm.h"

extern DbContainer g_dbContainer;

DIN*					digInputs;
DOUT*					digOutputs;
Oven*					ovenDb;
Belts*					belts;
LightTower*				lightTower;
Timer*					elapseTimer;
SMEMA*					smema1;
SMEMA*					smema2;
SMEMA*					smema3;
SMEMA*					smema4;
Nitrogen*				nitrogen;
Belt*					pBelt[MAX_SMEMA_LANES];
newBoardQueue_NoLP*		boardQ0_NoLP;
newBoardQueue_NoLP*		boardQ1_NoLP;
newBoardQueue_NoLP*		boardQ2_NoLP;
newBoardQueue_NoLP*		boardQ3_NoLP;

newBoardQueue*			boardQ0;
newBoardQueue*			boardQ1;
newBoardQueue*			boardQ2;
newBoardQueue*			boardQ3;

BOOL bBoardEntering[MAX_SMEMA_LANES];
DWORD dwBoardEnteringTime[MAX_SMEMA_LANES];
UINT uBoardEnteringSignal[MAX_SMEMA_LANES];

static int bcEntry = 0;
static int laneCount = 0;
static int s_iMES_entryAllowed[NUM_FILE_CONTROLLED_SMEMA]; //TRUE/FALSE
static int s_iMESActive[NUM_FILE_CONTROLLED_SMEMA]; //sw setting
static int s_iMESAllowed[NUM_FILE_CONTROLLED_SMEMA]; //runtime parameter

unsigned char uc9851Lock1;
unsigned char uc9851Lock2;
unsigned char uc9851Lock3;
unsigned char uc9851Lock4;


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_init

			There can be 0 to 2 SMEMA interfaces, with the possibility 
			of one to two to a belt.

 RETURNS:   void 
------------------------------------------------------------------------*/
void SMEMA_init(SMEMA* pSMEMA, UCHAR smemaIDNo )
{
	int i;
	i = 0;

	if( NULL != pSMEMA )
	{
		pSMEMA->SMEMA_Type          = NO_SMEMA;
		pSMEMA->smemaID             = smemaIDNo;
		pSMEMA->boardLastDetectPositionEntrance	= 0;
		pSMEMA->boardLastDetectPositionExit		= 0;
		pSMEMA->currentBeltPositionEntrance		= 0;
		pSMEMA->currentBeltPositionExit			= 0;
		pSMEMA->pastDeadBandEntrance			= FALSE;
		pSMEMA->pastDeadBandExit				= TRUE;
		pSMEMA->boardDetectTimeEntrance			= 0;
		pSMEMA->boardDetectTimeExit				= 0;
		pSMEMA->deadBandCounts					= 0;
		pSMEMA->ioConfigComplete				= FALSE;
		memset(pBelt, 0, sizeof(pBelt));
	
		digInputs = &( g_dbContainer.digitalInDb );
		digOutputs = &( g_dbContainer.digitalOutDb );
		belts = &( g_dbContainer.beltsDb );
		lightTower = &( g_dbContainer.lightTower );
		elapseTimer = &( g_dbContainer.elapseTimer );
		ovenDb = &( g_dbContainer.ovenDb );
		smema1 = &( g_dbContainer.smema1 );
		smema2 = &( g_dbContainer.smema2 );
		smema3 = &( g_dbContainer.smema3 );
		smema4 = &( g_dbContainer.smema4 );
		nitrogen = &( g_dbContainer.nitrogen );

		boardQ0_NoLP = &(g_dbContainer.boardQ0_NoLP);
		boardQ1_NoLP = &(g_dbContainer.boardQ1_NoLP);
		boardQ2_NoLP = &(g_dbContainer.boardQ2_NoLP);
		boardQ3_NoLP = &(g_dbContainer.boardQ3_NoLP);

		boardQ0 = &(g_dbContainer.boardQ0);
		boardQ1 = &(g_dbContainer.boardQ1);
		boardQ2 = &(g_dbContainer.boardQ2);
		boardQ3 = &(g_dbContainer.boardQ3);

		pSMEMA->uiLotFlag = 1;
		pSMEMA->m_bSmema9851HoldDueToSensor=FALSE;
		pSMEMA->m_CureOption=0;
		pSMEMA->beltOffTimeRead=FALSE;
		pSMEMA->beltOffTime=TRUE;
		pSMEMA->m_bCureSuspend=FALSE;
		pSMEMA->m_ExitAvailTime=0;
		pSMEMA->m_bExitOn=FALSE;
		pSMEMA->m_iMachineBStatus=SM_MACHINE_STATUS_COMPLETE;
		pSMEMA->m_bTestForB=FALSE;
		pSMEMA->m_bAllowNext=TRUE;
		pSMEMA->m_bBoardLeft=FALSE;
		pSMEMA->dwdSquareTime=0;
		pSMEMA->squareTimeTaken=FALSE;
		pSMEMA->m_bAllowNextPend=TRUE;
		pSMEMA->m_smemaOnInputDist=0;
		pSMEMA->m_smemaOnMinDist=0;
		pSMEMA->m_bBarcodeControlled=FALSE;
		pSMEMA->m_bBarcodeAllow=FALSE;
		pSMEMA->m_bBarcodeAllowAgain=FALSE;
		pSMEMA->dwrdNewRecipeTime=0;
		pSMEMA->m_bLaneHold = FALSE;

		pSMEMA->m_bMaxBoardsPerLaneEnable = FALSE;
		pSMEMA->m_nMaxBoardsPerLaneCount = SMEMA_MAXBOARDS_DEFAULT;
		pSMEMA->m_bNoBoardAnimation = FALSE;
	
		pSMEMA->m_bIsIndividualFree = FALSE;
		pSMEMA->m_bIndvAllow=FALSE;
		pSMEMA->m_imesBoardEntering = FALSE;
		if(smemaIDNo == 0)
		{
			for(i = 0; i < NUM_FILE_CONTROLLED_SMEMA; i++)
			{
				s_iMES_entryAllowed[i] = 1; //TRUE/FALSE
				s_iMESActive[i] = 0; //sw setting
				s_iMESAllowed[i] = 0; //runtime parameter
			}
		}
		pSMEMA->cSecgemControl = 0;
		pSMEMA->cSecgemEntry = 1;
	}
	uc9851Lock1 = 0;
	uc9851Lock2 = 0;
	uc9851Lock3 = 0;
	uc9851Lock4 = 0;

	// initialize ODO_SMEMAx_ENTRANCE hold logic
	for (i = 0; i < MAX_SMEMA_LANES; i++)
	{
		bBoardEntering[i] = FALSE;
		dwBoardEnteringTime[i] = 0;
		switch (i)
		{
		case 0 :
			uBoardEnteringSignal[i] = ODO_SMEMA1_ENTRANCE;
			break;
		case 1 :
			uBoardEnteringSignal[i] = ODO_SMEMA2_ENTRANCE;
			break;
		case 2 :
			uBoardEnteringSignal[i] = ODO_SMEMA3_ENTRANCE;
			break;
		case 3 :
			uBoardEnteringSignal[i] = ODO_SMEMA4_ENTRANCE;
			break;
		}
	}

	return;
}

void SMEMA_setType(SMEMA* pSMEMA, enum SMEMA_Interface newType )
{ 
	PARAM_CHECK( pSMEMA, "SMEMA_setType");
	pSMEMA->SMEMA_Type = newType;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_process

			main process loop for smema, called from schedule.c

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_process(SMEMA* pSMEMA)
{
	if(pSMEMA)
	{
		if ( !pSMEMA->ioConfigComplete )
		{
			SMEMA_setIOConfig(pSMEMA);
		}

		if(pSMEMA->SMEMA_Type != NO_SMEMA)
		{
			SMEMA_checkForPastDeadBandEntrance(pSMEMA);
			SMEMA_checkForPastDeadBandExit(pSMEMA);
		}

		switch ( pSMEMA->SMEMA_Type )
		{
			case NO_SMEMA:	// do nothing
				break;

			case SMEMA_II:
				SMEMA_SMEMA_II_process(pSMEMA);
				break;

			case TDK:
				SMEMA_TDK_process(pSMEMA);
				break;

			case FUJI:
				SMEMA_FUJI_process(pSMEMA);
				break;

			case SEAGATE:
				SMEMA_SEAGATE_process(pSMEMA);
				break;

			case SMEMA_9851:
				SMEMA_SMEMA_9851_process(pSMEMA);
				break;

			default:
				break;
		}
	}
	return;
}

//******************************************************************************
// void SMEMA_setIOConfig
//
// Abstract:
// In order to set the correct configuration the VxD must wait until the system
// configuration is downloaded. This is required in order to assign the correct
// io based on the number of belts. The drawback to using this function is that
// if the number of belts is ever changed the system must be rebooted to reconfigure
// this IO.
//
// Programmer: Steven Young
// Date: 02/17/2000
//******************************************************************************
void SMEMA_setIOConfig(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_setIOConfig");
	pSMEMA->noOfBelts = Oven_getNoBelts(ovenDb);
	switch( pSMEMA->smemaID )
	{
	case 0:
		pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];
		pSMEMA->pBoardEnteringOven = DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN );
		pSMEMA->pBoardLeavingOven = DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
		break;
	case 1:
		pSMEMA->pBoardEnteringOven = DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN);
		pSMEMA->pBoardLeavingOven = DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
		switch( pSMEMA->noOfBelts )
		{
		case 1: 
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];		// belt dependent IO
			break;
		case 2:
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[1];
			break;
		default:
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];	// don't know what else to do if this value is not 1 or 2
			break;
		}
		break;
	case 2:
		pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];						// The third smema is always tied to belt 1
		pSMEMA->pBoardEnteringOven = DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN );
		pSMEMA->pBoardLeavingOven = DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
		break;
	case 3:
		pSMEMA->pBoardEnteringOven = DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN );
		pSMEMA->pBoardLeavingOven = DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
		switch( pSMEMA->noOfBelts )
		{
		case 1:
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];		// belt dependent IO
			break;
		case 2:
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[1];
			break;
		default:
			pBelt[pSMEMA->smemaID] = &g_dbContainer.belt[0];	// don't know what else to do if this value is not 1 or 2
			break;
		}
		break;
	default:
		pBelt[0] = &g_dbContainer.belt[0];		// need to point somewhere event though this should be an error condition.
		break;
	}
	pSMEMA->ioConfigComplete = TRUE;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_checkForPastDeadBandEntrance

			Need to be able to detect the end of a board and the board 
			spacing before allowing another board to enter.

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_checkForPastDeadBandEntrance(SMEMA* pSMEMA)
{
	BOOL bStartSmema;
	BOOL bPendSmema;
	DWORD deltaTime;
	DWORD deltaPos;
	DWORD currentTime;

	DWORD dwrdBeltPos;

	dwrdBeltPos = 0;

	bStartSmema = FALSE;
	bPendSmema = FALSE;
	deltaTime = 0;
	deltaPos = 0;
	currentTime = 0;

	if( NULL != pSMEMA )
	{
		// if SMEMA 9851
		switch (pSMEMA->SMEMA_Type)
		{
		case SMEMA_9851 :
			switch ( pSMEMA->smemaID )
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						bStartSmema = g_dbContainer.boardQ0_NoLP.m_bStartSmema;
					}
					else
					{
						bStartSmema = g_dbContainer.boardQ0.m_bStartSmema;
					}

					currentTime =  Timer_getCurrentTime10ths(elapseTimer);
					deltaTime = differenceWithRollover(currentTime, pSMEMA->boardDetectTimeEntrance );
					dwrdBeltPos = Belt_getPosition(pBelt[pSMEMA->smemaID]);
					deltaPos = differenceWithRollover(dwrdBeltPos, pSMEMA->m_smemaOnInputDist);

					if( bStartSmema == TRUE )
					{
						pSMEMA->bBoardHasEntered=TRUE;
						uc9851Lock1 = 1;

						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						}
						pSMEMA->pastDeadBandEntrance = TRUE;
						pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);
						pSMEMA->m_smemaOnInputDist = Belt_getPosition(pBelt[pSMEMA->smemaID]);
					}
					else if( ( pSMEMA->bBoardHasEntered==TRUE ) && 
						     ( ( deltaTime < SMEMA_DEADBAND_CNT ) || ( pSMEMA->m_smemaOnMinDist > deltaPos ) ) )
					{
						pSMEMA->pastDeadBandEntrance = FALSE;
					}
					else
					{
						if (pSMEMA->pastDeadBandEntrance == FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
							SMEMA_SecsGemSetting(pSMEMA, 0);
						}

						pSMEMA->pastDeadBandEntrance = TRUE;
						pSMEMA->bBoardHasEntered=FALSE;	

						if( FALSE == g_bLotProcessingEnable )
						{
							bPendSmema = g_dbContainer.boardQ0_NoLP.m_bPendSmema;
						}
						else
						{
							bPendSmema = g_dbContainer.boardQ0.m_bPendSmema;
						}

						if( bPendSmema == FALSE )
						{	
							pSMEMA->m_bSmema9851HoldDueToSensor = FALSE;
						}
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
					}
					break;
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						bStartSmema = g_dbContainer.boardQ1_NoLP.m_bStartSmema;
					}
					else
					{
						bStartSmema = g_dbContainer.boardQ1.m_bStartSmema;
					}

					currentTime = Timer_getCurrentTime10ths(elapseTimer);
					deltaTime = differenceWithRollover( currentTime, pSMEMA->boardDetectTimeEntrance );
					dwrdBeltPos = Belt_getPosition(pBelt[pSMEMA->smemaID]);
					deltaPos = differenceWithRollover(dwrdBeltPos, pSMEMA->m_smemaOnInputDist);

					if( bStartSmema == TRUE )
					{
						uc9851Lock2 = 1;
						pSMEMA->bBoardHasEntered=TRUE;
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
					}
					else if( ( pSMEMA->bBoardHasEntered == TRUE ) && 
						     ( ( deltaTime < SMEMA_DEADBAND_CNT ) || ( pSMEMA->m_smemaOnMinDist > deltaPos ) ) )
					{
						pSMEMA->pastDeadBandEntrance=FALSE;
					}
					else
					{
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
							SMEMA_SecsGemSetting(pSMEMA, 0);
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->bBoardHasEntered=FALSE;	

						if( FALSE == g_bLotProcessingEnable )
						{
							bPendSmema = g_dbContainer.boardQ1_NoLP.m_bPendSmema;
						}
						else
						{
							bPendSmema = g_dbContainer.boardQ1.m_bPendSmema;
						}

						if( bPendSmema == FALSE )
						{
							pSMEMA->m_bSmema9851HoldDueToSensor = FALSE;
						}
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						bStartSmema = g_dbContainer.boardQ2_NoLP.m_bStartSmema;
					}
					else
					{
						bStartSmema = g_dbContainer.boardQ2.m_bStartSmema;
					}

					currentTime = Timer_getCurrentTime10ths(elapseTimer);
					deltaTime = differenceWithRollover( currentTime, pSMEMA->boardDetectTimeEntrance );
					dwrdBeltPos = Belt_getPosition(pBelt[pSMEMA->smemaID]);
					deltaPos = differenceWithRollover(dwrdBeltPos, pSMEMA->m_smemaOnInputDist);

					if( bStartSmema == TRUE )
					{
						uc9851Lock3 = 1;
						pSMEMA->bBoardHasEntered=TRUE;
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
					}
					else if( ( pSMEMA->bBoardHasEntered == TRUE ) && 
						     ( ( deltaTime < SMEMA_DEADBAND_CNT ) || ( pSMEMA->m_smemaOnMinDist > deltaPos ) ) )

					{
						pSMEMA->pastDeadBandEntrance=FALSE;
					}
					else
					{
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
							SMEMA_SecsGemSetting(pSMEMA, 0);
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->bBoardHasEntered=FALSE;			

						if( FALSE == g_bLotProcessingEnable )
						{
							bPendSmema = g_dbContainer.boardQ2_NoLP.m_bPendSmema;
						}
						else
						{
							bPendSmema = g_dbContainer.boardQ2.m_bPendSmema;
						}

						if( bPendSmema == FALSE )
						{
							pSMEMA->m_bSmema9851HoldDueToSensor = FALSE;
						}
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						bStartSmema = g_dbContainer.boardQ3_NoLP.m_bStartSmema;
					}
					else
					{
						bStartSmema = g_dbContainer.boardQ3.m_bStartSmema;
					}

					currentTime = Timer_getCurrentTime10ths(elapseTimer);
					deltaTime = differenceWithRollover( currentTime, pSMEMA->boardDetectTimeEntrance );
					dwrdBeltPos = Belt_getPosition(pBelt[pSMEMA->smemaID]);
					deltaPos = differenceWithRollover(dwrdBeltPos, pSMEMA->m_smemaOnInputDist);

					if( bStartSmema == TRUE )
					{
						uc9851Lock4 = 1;
						pSMEMA->bBoardHasEntered=TRUE;
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
					}
					else if(  (pSMEMA->bBoardHasEntered == TRUE ) && 
						      ( ( deltaTime < SMEMA_DEADBAND_CNT ) || ( pSMEMA->m_smemaOnMinDist > deltaPos ) ) )
					{
						pSMEMA->pastDeadBandEntrance=FALSE;
					}
					else
					{
						pSMEMA->m_smemaOnInputDist=Belt_getPosition(pBelt[pSMEMA->smemaID]);
						if(pSMEMA->pastDeadBandEntrance==FALSE)
						{
							g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
							g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
							SMEMA_SecsGemSetting(pSMEMA, 0);
						}
						pSMEMA->pastDeadBandEntrance=TRUE;
						pSMEMA->bBoardHasEntered=FALSE;			
						if( FALSE == g_bLotProcessingEnable )
						{
							bPendSmema = g_dbContainer.boardQ3_NoLP.m_bPendSmema;
						}
						else
						{
							bPendSmema = g_dbContainer.boardQ3.m_bPendSmema;
						}

						if( bPendSmema == FALSE )
						{
							pSMEMA->m_bSmema9851HoldDueToSensor = FALSE;
						}
					}
					break;
				default:
					break;
			}
			break;
		case SMEMA_II :
			// entrance sensor blocked -- board present
			if (*pSMEMA->pBoardEnteringOven)
			{
				// detect that sensor is blocked for 0.3 seconds.
				// snapshot timer if not yet done for this board
				if (pSMEMA->boardDetectTimeEntrance == 0)
					pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);

				currentTime = Timer_getCurrentTime10ths(elapseTimer);
				deltaTime = differenceWithRollover(currentTime, pSMEMA->boardDetectTimeEntrance);

				// if entrance sensor has remained blocked for 300ms
				if (deltaTime > SMEMA_300MS)
				{
					// if the sensor is blocked for more than .3 seconds then a board is assumed to be 
					// present. As long as a board is present detect the last position that the board
					// is detected.
					pSMEMA->boardLastDetectPositionEntrance = Belt_getPosition(pBelt[pSMEMA->smemaID]);
		
					if (pSMEMA->pastDeadBandEntrance)
					{
						pSMEMA->m_bIndvAllow = FALSE;
						SMEMA_SecsGemSetting(pSMEMA, 0);

						if (bcEntry > 0)
						{
							bcEntry--;
							switch (laneCount)
							{
							case 0: //FALL THROUGH
							case 1:
								bcEntry = 0;
								break;
							case 2: //FALL THROUGH
							case 3:
							case 4:
								if (bcEntry >= laneCount)
									bcEntry = laneCount - 1;
								break;
							default:
								break;
							}
						}
				
						if (!pSMEMA->m_bIsIndividualFree)
						{
							switch (pSMEMA->smemaID)
							{
							case 0:
								g_dbContainer.smema2.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema3.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema4.m_bBarcodeAllow = FALSE;
								break;
							case 1:
								g_dbContainer.smema1.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema3.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema4.m_bBarcodeAllow = FALSE;						
								break;
							case 2:
								g_dbContainer.smema1.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema2.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema4.m_bBarcodeAllow = FALSE;
								break;
							case 3:
								g_dbContainer.smema1.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema2.m_bBarcodeAllow = FALSE;
								g_dbContainer.smema3.m_bBarcodeAllow = FALSE;						
								break;
							default:
								break;
							}
						}
						else
						{
							//We have released a board but it is not passed deadband
							pSMEMA->m_bIsIndividualFree = FALSE;
						}
				
						pSMEMA->pastDeadBandEntrance = FALSE;
					}
				}
			}
			// entrance sensor not blocked -- board not present
			else
			{
				// zero timer snapshot
				pSMEMA->boardDetectTimeEntrance = 0;

				// snapshot belt position
				pSMEMA->currentBeltPositionEntrance = Belt_getPosition(pBelt[pSMEMA->smemaID]);

				// compute difference of board last present belt position and board not present belt position
				pSMEMA->elapsedPositionEntrance = differenceWithRollover(pSMEMA->currentBeltPositionEntrance, pSMEMA->boardLastDetectPositionEntrance);

				if (pSMEMA->elapsedPositionEntrance >= pSMEMA->deadBandCounts + pSMEMA->m_smemaOnMinDist)
				{
					if (pSMEMA->m_bBarcodeAllowAgain)
						pSMEMA->m_bBarcodeAllowAgain = FALSE;
					if (pSMEMA->m_bIsIndividualFree) //We are managing all lanes with a single Barcode
					{
						if (!pSMEMA->m_bBarcodeAllowAgain)
							pSMEMA->m_bBarcodeAllow = TRUE;
					}
					else if (bcEntry > 0)
					{
						if (!g_dbContainer.smema1.m_bBarcodeAllowAgain)
							g_dbContainer.smema1.m_bBarcodeAllow = TRUE;	
						if (!g_dbContainer.smema2.m_bBarcodeAllowAgain)
							g_dbContainer.smema2.m_bBarcodeAllow = TRUE;	
						if (!g_dbContainer.smema3.m_bBarcodeAllowAgain)
							g_dbContainer.smema3.m_bBarcodeAllow = TRUE;	
						if (!g_dbContainer.smema4.m_bBarcodeAllowAgain)
							g_dbContainer.smema4.m_bBarcodeAllow = TRUE;
					}
					else
					{
						if (!pSMEMA->m_bIndvAllow)
							pSMEMA->m_bBarcodeAllow = FALSE;
					}
					pSMEMA->pastDeadBandEntrance = TRUE;
				}
			}
			break;
		default :
			if ( *(pSMEMA->pBoardEnteringOven) )
			{
				// detect that sensor is blocked for .3 seconds.
				if( pSMEMA->boardDetectTimeEntrance == 0 )
				{
					pSMEMA->boardDetectTimeEntrance = Timer_getCurrentTime10ths(elapseTimer);
				}

				currentTime = Timer_getCurrentTime10ths(elapseTimer);
				deltaTime = differenceWithRollover( currentTime, pSMEMA->boardDetectTimeEntrance );

				if( deltaTime > SMEMA_300MS )
				{
					// if the sensor is blocked for more than .3 seconds then a board is assumed to be 
					// present. As long as a board is present detect the last position that the board
					// is detected.
					pSMEMA->boardLastDetectPositionEntrance = Belt_getPosition(pBelt[pSMEMA->smemaID]);
		
					if(pSMEMA->pastDeadBandEntrance==TRUE)
					{
						pSMEMA->m_bIndvAllow=FALSE;
						SMEMA_SecsGemSetting(pSMEMA, 0);

						if(bcEntry>0)
						{
							bcEntry--;
							switch(laneCount)
							{
								case 0: //FALL THROUGH
								case 1:
									bcEntry=0;
									break;
						
								case 2: //FALL THROUGH
								case 3:
								case 4:
									if(bcEntry>=laneCount)
									{
										bcEntry=(laneCount-1);
									}
									break;
								default:
									break;
							}
						}
				
						if((pSMEMA->m_bIsIndividualFree) == FALSE)
						{
							switch(pSMEMA->smemaID)
							{
								case 0:
									g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema3.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema4.m_bBarcodeAllow=FALSE;
									break;
								case 1:
									g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema3.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema4.m_bBarcodeAllow=FALSE;						
									break;
								case 2:
									g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema4.m_bBarcodeAllow=FALSE;
									break;
								case 3:
									g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
									g_dbContainer.smema3.m_bBarcodeAllow=FALSE;						
									break;
								default:
									break;
							}
						}
						else
						{
							//We have released a board but it is not passed deadband
							pSMEMA->m_bIsIndividualFree = FALSE;
						}
				
						pSMEMA->pastDeadBandEntrance = FALSE;
					}
				}
			}
			else
			{
				pSMEMA->boardDetectTimeEntrance = 0;
				pSMEMA->currentBeltPositionEntrance = Belt_getPosition(pBelt[pSMEMA->smemaID]);
				pSMEMA->elapsedPositionEntrance = differenceWithRollover( pSMEMA->currentBeltPositionEntrance,
													pSMEMA->boardLastDetectPositionEntrance );

				if( pSMEMA->elapsedPositionEntrance > pSMEMA->deadBandCounts )
				{
					if(pSMEMA->m_bBarcodeAllowAgain==TRUE)
					{
						pSMEMA->m_bBarcodeAllowAgain = FALSE;
					}
					if(pSMEMA->m_bIsIndividualFree == TRUE) //We are managing all lanes with a single Barcode
					{
						if(pSMEMA->m_bBarcodeAllowAgain==FALSE)
						{
							pSMEMA->m_bBarcodeAllow=TRUE;
					
						}
					}
					else if (bcEntry > 0 )
					{
						if( g_dbContainer.smema1.m_bBarcodeAllowAgain == FALSE )
						{
							g_dbContainer.smema1.m_bBarcodeAllow=TRUE;	
						}
						if (g_dbContainer.smema2.m_bBarcodeAllowAgain == FALSE )
						{
							g_dbContainer.smema2.m_bBarcodeAllow=TRUE;	
						}
						if( g_dbContainer.smema3.m_bBarcodeAllowAgain == FALSE )
						{
							g_dbContainer.smema3.m_bBarcodeAllow=TRUE;	
						}
						if( g_dbContainer.smema4.m_bBarcodeAllowAgain == FALSE )
						{
							g_dbContainer.smema4.m_bBarcodeAllow=TRUE;
						}
					}
					else
					{
						if(pSMEMA->m_bIndvAllow==FALSE)
						{
							pSMEMA->m_bBarcodeAllow=FALSE;
						}
					}
				
					pSMEMA->pastDeadBandEntrance = TRUE;
				}
			}
			break;
		}
	}

	return;
}

//******************************************************************************
// void SMEMA_checkForPastDeadBandExit()
//
// Abstract:
// Need to be able to detect the end of a board and the board spacing before allowing
// another board to enter.
//
// Programmer: Steven Young
// Date: 02/17/2000
//******************************************************************************
void SMEMA_checkForPastDeadBandExit(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_checkForPastDeadBandExit");
	if ( *(pSMEMA->pBoardLeavingOven) )
	{
		// detect that sensor is blocked for .2 seconds.
		if( pSMEMA->boardDetectTimeExit == 0 )
		{
			pSMEMA->boardDetectTimeExit = Timer_getCurrentTime10ths(elapseTimer);
		}
		if( differenceWithRollover( Timer_getCurrentTime10ths(elapseTimer), pSMEMA->boardDetectTimeExit ) > 2 )
		{
			// if the sensor is blocked for more than .2 seconds then a board is assumed to be 
			// present. As long as a board is present detect the last position that the board
			// is detected.
			pSMEMA->boardLastDetectPositionExit = Belt_getPosition(pBelt[pSMEMA->smemaID]);
			if(pSMEMA->m_bAllowNext==TRUE)//if the current board is already allowed, reset if squarewave recieved
			{
				pSMEMA->m_iMachineBStatus=0;
			}
			pSMEMA->pastDeadBandExit = FALSE;
			pSMEMA->m_bAllowNextPend=FALSE;
//			SQUARE WAVE READ FALSE
		}
	}
	else
	{
		pSMEMA->boardDetectTimeExit = 0;
		pSMEMA->currentBeltPositionExit = Belt_getPosition(pBelt[pSMEMA->smemaID]);
		pSMEMA->elapsedPositionExit = differenceWithRollover( pSMEMA->currentBeltPositionExit, pSMEMA->boardLastDetectPositionExit );
		if( pSMEMA->elapsedPositionExit >= pSMEMA->exitDeadBandCounts )
		{

			pSMEMA->pastDeadBandExit = TRUE;
			if(pSMEMA->m_bAllowNextPend==TRUE)
			{
				pSMEMA->m_bAllowNext=TRUE;
			}
			else
			{
				pSMEMA->m_bAllowNext=FALSE;
			}		
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SMEMA_II_process

			main loop for SMEMA II

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_SMEMA_II_process(SMEMA* pSMEMA)
{
	DWORD deltaTime;
	DWORD deltaOTime;
	BOOL bStatus;
	BOOL bDin;
	DWORD dwrdDif;

	BOOL bLT1Green;
	BOOL bLT2Green;
	int iFileAllow;
	DWORD tim;
	DWORD dwrdNRtim;

	BOOL bHoldSmema;
	int iEntry;
	BOOL bDin2;
	BOOL bDin3;
	BOOL bDout1;

	char cUserAllowed;

	cUserAllowed = 0;

	bDout1 = FALSE;
	bDin3 = FALSE;
	bDin2 = FALSE;
	iEntry = 0;
	bHoldSmema = FALSE;

	dwrdNRtim = 0;
	tim = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	deltaTime = 0;
	deltaOTime = 0;
	bStatus = FALSE;

	bLT1Green = FALSE;
	bLT2Green = FALSE;
	iFileAllow = 0;
	bDin = FALSE;
	dwrdDif = 0;

	SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );

	if(pSMEMA)
	{
		if(pSMEMA->dwrdNewRecipeTime)
		{
			dwrdNRtim = tim - pSMEMA->dwrdNewRecipeTime;
			if(dwrdNRtim > NEW_RECIPE_TIME_S2)
			{
				pSMEMA->dwrdNewRecipeTime = 0;
			}
		}

		//
		// Lanes 0 and 2 processing for Light Tower 1
		//
		bHoldSmema = LightTower_getHoldSmema(lightTower);
		if ( bLT1Green && (bHoldSmema == FALSE) )
		{
			bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
			if ( bStatus == FALSE )
			{
				switch ( pSMEMA->smemaID )
				{
					case 0:	
						if(pSMEMA->m_CureOption != 0)
						{
							SMEMA_squareWave(pSMEMA);
						
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN);
							if((pSMEMA->m_bAllowNext==FALSE) && (bDin==TRUE) )
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime = tim;
									pSMEMA->squareTimeTaken = TRUE;
								}
								dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
								if(dwrdDif >= 1)
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}
						}
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
						if ( bDin == TRUE )
						{
							pSMEMA->m_bCureSuspend = FALSE;
							pSMEMA->beltOffTimeRead = FALSE;
							iFileAllow = SMEMA_EntryAllowed(pSMEMA);
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN );
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

							if ( ( bDin == FALSE) && 
								pSMEMA->pastDeadBandEntrance && 
								(pSMEMA->uiLotFlag==1) && 
								iFileAllow &&
								cUserAllowed &&
								!pSMEMA->m_bLaneHold)
							{
								if (pSMEMA->m_bBarcodeControlled)
								{						
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = ( ( pSMEMA->m_bBarcodeAllow == TRUE) && ( pSMEMA->dwrdNewRecipeTime == 0 ) );
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = TRUE;
								}
							}
							else 
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
							}
						}
						else 
						{
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_CureOption != 0) && bDin)	
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime = tim;
								}
								deltaTime = tim - pSMEMA->beltOffTime;
								if(deltaTime >= SMEMA_200MS)
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else	
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}
	
							if (pSMEMA->m_CureOption)
							{
								bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN ); 
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								if ( (bDin == FALSE) && 
									pSMEMA->pastDeadBandEntrance && 
									(pSMEMA->uiLotFlag==1) &&
									iEntry &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
							}
						}
						break;
					
					case 2:
						if(pSMEMA->m_CureOption != 0)
						{
							SMEMA_squareWave(pSMEMA);
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_bAllowNext==FALSE ) && ( bDin == TRUE ) )	
							{
								if(pSMEMA->squareTimeTaken == FALSE)
								{
									pSMEMA->dwdSquareTime = tim;
									pSMEMA->squareTimeTaken = TRUE;
								}
								dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
								if( dwrdDif >= 1 )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}
						}
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
						if ( bDin == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN );
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);
							if ( (bDin == FALSE) && 
								pSMEMA->pastDeadBandEntrance &&
								(pSMEMA->uiLotFlag==1) && 
								iEntry  && 
								cUserAllowed &&
								!pSMEMA->m_bLaneHold)
							{
								if(pSMEMA->m_bBarcodeControlled==TRUE)
								{						
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = ((pSMEMA->m_bBarcodeAllow == TRUE) && (pSMEMA->dwrdNewRecipeTime==0));
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = TRUE;
								}
							}
							else 
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
							}
						}
						else 
						{
							bDin = *DIN_GetAt( digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
							if((pSMEMA->m_CureOption!=0) && bDin)
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime=tim;
								}
								deltaTime = tim - pSMEMA->beltOffTime;
								if(deltaTime >= SMEMA_200MS)
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else	
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
	
							}
	
							if (pSMEMA->m_CureOption)
							{
								bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN );
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								if ( (bDin == FALSE) && 
									pSMEMA->pastDeadBandEntrance && 
									(pSMEMA->uiLotFlag==1) && 
									iEntry &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
							}
						}
						break;

					default:
						break;
				}
			}
		}
		else 
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;	

					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=tim;
								pSMEMA->squareTimeTaken=TRUE;
							}
							dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
							if( dwrdDif >= 1 )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
					if( ( bDin != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bDin2 == TRUE ) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime = tim;
						}
						 deltaTime = tim - pSMEMA->beltOffTime;
						if(deltaTime>=SMEMA_200MS)
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}			
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;

				case 2:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;			
					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=tim;
								pSMEMA->squareTimeTaken=TRUE;
							}
							dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
							if(dwrdDif >= 1 )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
					if(( bDin != TRUE ) && 
						(pSMEMA->m_CureOption!=0) && 
						(bDin2 == TRUE) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=tim;
						}
						 deltaTime = tim - pSMEMA->beltOffTime;
						if(deltaTime>=SMEMA_200MS)
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;
				default:
					break;
			}
		}

		//
		// Lanes 1 and 3 processing for Light Tower 2
		//
		bHoldSmema = LightTower_getHoldSmema(lightTower);
		if ( bLT2Green && (bHoldSmema==FALSE) )
		{
			bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
			if ( bStatus == FALSE )
			{
				switch ( pSMEMA->smemaID )
				{
					case 1:
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime = tim;
									pSMEMA->squareTimeTaken=TRUE;
								}
								dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
								if(dwrdDif >= 1 )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}

						}
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );
						if ( bDin == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN );
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);
							if ( ( bDin == FALSE ) && 
								pSMEMA->pastDeadBandEntrance && 
								(pSMEMA->uiLotFlag==1) && 
								iEntry && 
								cUserAllowed &&
								!pSMEMA->m_bLaneHold)
							{
								if(pSMEMA->m_bBarcodeControlled==TRUE)
								{	
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = ((pSMEMA->m_bBarcodeAllow == TRUE) && (pSMEMA->dwrdNewRecipeTime==0));
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = TRUE;
								}
							}
							else 
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
							}
						}
						else 
						{
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_CureOption != 0 ) && bDin )
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime = tim;
								}
								deltaTime = tim - pSMEMA->beltOffTime;
								if(deltaTime >= SMEMA_200MS)
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if (pSMEMA->m_CureOption &&
								!pSMEMA->m_bLaneHold)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
						
								bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN );
								if ( ( bDin == FALSE ) && 
									pSMEMA->pastDeadBandEntrance && 
									(pSMEMA->uiLotFlag==1) && 
									iEntry)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
							}


						}
						break;

					case 3:
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime = tim;
									pSMEMA->squareTimeTaken=TRUE;
								}
								dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
								if( dwrdDif >= 1 )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}
						}
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
						if ( bDin == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							iEntry = SMEMA_EntryAllowed(pSMEMA);

							bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN );
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

							if ( ( bDin == FALSE) &&  
								pSMEMA->pastDeadBandEntrance && 
								(pSMEMA->uiLotFlag==1) && 
								iEntry && 
								cUserAllowed &&
								!pSMEMA->m_bLaneHold)
							{
								if(pSMEMA->m_bBarcodeControlled==TRUE)
								{						
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = ((pSMEMA->m_bBarcodeAllow == TRUE) && (pSMEMA->dwrdNewRecipeTime==0));
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = TRUE;
								}
							}
							else 
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;
							}
						}
						else 
						{
							bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
							if( ( pSMEMA->m_CureOption != 0 ) && bDin )
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime = tim;
								}
								deltaTime = tim - pSMEMA->beltOffTime;
								if(deltaTime >= SMEMA_200MS)
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if (pSMEMA->m_CureOption)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN );
								if ( ( bDin == FALSE) && 
									pSMEMA->pastDeadBandEntrance && 
									(pSMEMA->uiLotFlag==1) && 
									iEntry &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;
							}

						}
						break;

					default:
						break;
				}
			}
		}
		else 
		{
			switch ( pSMEMA->smemaID )
			{
				case 1:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;

					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=tim;
								pSMEMA->squareTimeTaken=TRUE;
							}
							dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
							if(dwrdDif >= 1 )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}

					}
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );		
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
					if( ( bDin != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bDin2 == TRUE ) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=tim;
						}
						 deltaTime = tim - pSMEMA->beltOffTime;
						if(deltaTime >= SMEMA_200MS)
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;

				case 3:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;	

					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);
						bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bDin == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime = tim;
								pSMEMA->squareTimeTaken=TRUE;
							}
							dwrdDif = differenceWithRollover( tim, pSMEMA->dwdSquareTime );
							if( dwrdDif >= 1 )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
					if(( bDin != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bDin2 == TRUE ) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=tim;
						}
						 deltaTime = tim - pSMEMA->beltOffTime;
						if(deltaTime >= SMEMA_200MS)
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;

				default:
					break;

			}
		}

		// The pastDeadBandExit is used to stretch the pulse of a board that may have holes 
		// that would make the board appear shorter than it is physically. In order for this
		// not to work properly a hole greater than the deadband or boardspacing must exist on
		// the board. The theory is that if a board is detected turn on the take up conveyor to
		// remove the board. If a hole exists without this code the takeup conveyor would shut
		// off when the sensor detects the hole. Now it waits for the board spacing to pass before
		// shutting off.
		// SDY 02/18/2000
		switch ( pSMEMA->smemaID )
		{
			case 0:
				bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
				if ( bDin || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption != 0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime = tim;
							*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = tim - pSMEMA->m_ExitAvailTime;
							if(deltaOTime>=1)
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
				}
				break;

			case 1:		
				bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
				if ( bDin || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption != 0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime = tim;
							*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = tim - pSMEMA->m_ExitAvailTime;
							if(deltaOTime>=1)
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;						
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
					}
				}			
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
				}
				break;

			case 2:		
				bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
				if ( bDin || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime = tim;
							*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = tim - pSMEMA->m_ExitAvailTime;
							if(deltaOTime >= 1)
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
				}
				break;
			case 3:
				bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
				if ( bDin || !pSMEMA->pastDeadBandExit )			
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime = tim;
							*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = tim - pSMEMA->m_ExitAvailTime;
							if(deltaOTime>=1)
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
				}
				break;

			default:
				break;
		}

		if(pSMEMA->m_CureOption!=0)
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
					bDin3 = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
					bDout1 = *DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT );				
					break;

				case 1:
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );
					bDin3 = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
					bDout1 = *DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT );
					break;

				case 2:
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
					bDin3 = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
					bDout1 = *DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT );
					break;

				case 3:
					bDin = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
					bDin2 = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
					bDin3 = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
					bDout1 = *DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT );
					break;

				default:
					break;
			}
			if( ( (bDin == TRUE) || 
					( ( bDin2 == FALSE ) &&
					( bDin3 == FALSE ) && 
					( bDout1 == FALSE) ) ) )
			{
				pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,0);
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SMEMA_9851_LightTower1_process

			Processes Lanes 0 and 2 for Light Tower 1

 RETURNS:   void
 SEE ALSO: SMEMA_SMEMA_9851_process
------------------------------------------------------------------------*/
void SMEMA_SMEMA_9851_LightTower1_process(SMEMA* pSMEMA)
{
	DWORD deltaTime;
	DWORD deltaOTime;
	BOOL bStatus;
	BOOL bLT1Green;
	BOOL bLT2Green;

	BOOL bSMEMAHold;
	BOOL bBoardLeaving;
	BOOL bBoardBackup;
	BOOL bSmema9851HoldDueToSensor;
	DWORD currentTime;
	DWORD boardCount;

	int iEntry;
	char cUserAllowed;

	cUserAllowed = 0;
	iEntry = 0;

	deltaTime = 0;
	deltaOTime = 0;
	bStatus = FALSE;
	bLT1Green = FALSE;
	bLT2Green = FALSE;

	bSMEMAHold = FALSE;
	bBoardLeaving = FALSE;
	bBoardBackup = FALSE;
	bSmema9851HoldDueToSensor = FALSE;
	currentTime = 0;

	if( NULL != pSMEMA )
	{
		// stop new oven job timer after NEW_RECIPE_TIME_S2 period
		if (pSMEMA->dwrdNewRecipeTime &&
			Timer_getCurrentTime10ths(elapseTimer) - pSMEMA->dwrdNewRecipeTime >= NEW_RECIPE_TIME_S2)
			pSMEMA->dwrdNewRecipeTime = 0;
			
		// get lane board count
		switch (pSMEMA->smemaID)
		{
		case 0 :
			boardCount = boardQ0_NoLP->boardCount + boardQ0->m_boardCount;
			break;
		case 1 :
			boardCount = boardQ1_NoLP->boardCount + boardQ1->m_boardCount;
			break;
		case 2 :
			boardCount = boardQ2_NoLP->boardCount + boardQ2->m_boardCount;
			break;
		case 3 :
			boardCount = boardQ3_NoLP->boardCount + boardQ3->m_boardCount;
			break;
		default :
			boardCount = 0;
			break;
		}
		// if lane board count zero
		if (boardCount == 0)
		{
			bBoardEntering[pSMEMA->smemaID] = FALSE;
			dwBoardEnteringTime[pSMEMA->smemaID] = 0;
#ifdef DEBUG_SMEMA_HOLD
			printk("9851 LightTower1 Lane%d board count zero, disable hold\n", pSMEMA->smemaID + 1);
#endif
		}
		// if SMEMA entrance feed TRUE and board entering and cure option disabled
		if (*DOUT_GetAt(digOutputs, uBoardEnteringSignal[pSMEMA->smemaID]) &&
			bBoardEntering[pSMEMA->smemaID] &&
			pSMEMA->m_CureOption == 0)
		{
			// if SMEMA entrance feed not held TRUE too long
			if ((Timer_getCurrentTime10ths(elapseTimer) - dwBoardEnteringTime[pSMEMA->smemaID]) / 10 < MAX_SMEMA_HOLD_SECONDS)
			{
				// announce SMEMA entrance feed held TRUE
#ifdef DEBUG_SMEMA_HOLD
				printk("9851 LightTower1 Lane%d hold ON\n", pSMEMA->smemaID + 1);
#endif
				return;
			}
			// if SMEMA entrance feed held TRUE too long
			else
			{
				// stop SMEMA entrance feed hold
				bBoardEntering[pSMEMA->smemaID] = FALSE;
				dwBoardEnteringTime[pSMEMA->smemaID] = 0;
#ifdef DEBUG_SMEMA_HOLD
				printk("9851 LightTower1 Lane%d hold timeout\n", pSMEMA->smemaID + 1);
#endif
			}
		}

		SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );

		//
		// Lanes 0 and 2 processing for Light Tower 1
		//
		bSMEMAHold = LightTower_getHoldSmema(lightTower);
		if ( bLT1Green && ( bSMEMAHold == FALSE ) )
		{
			bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
			if ( bStatus == FALSE )
			{
				switch ( pSMEMA->smemaID )
				{
					case 0:	
				
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);

							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) ) 
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
									pSMEMA->squareTimeTaken=TRUE;
								}

								currentTime = Timer_getCurrentTime10ths(elapseTimer);
								deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

								if( deltaTime >= SMEMA_100MS )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}

						}

						bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );

						if ( bBoardBackup == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;			
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

							if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
								(pSMEMA->uiLotFlag==1) && 
								(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE) && 
								(iEntry || pSMEMA->m_imesBoardEntering) &&
								cUserAllowed &&
								pSMEMA->dwrdNewRecipeTime == 0 &&
								!pSMEMA->m_bLaneHold)
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = TRUE;
							}
							else 
							{
								pSMEMA->m_imesBoardEntering = FALSE;
								Break9851Lock(pSMEMA->smemaID);
								*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ0_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ0.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor = TRUE;
								}
							}
						}
						else 
						{
							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_CureOption != 0 ) && ( bBoardLeaving == TRUE ) )
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
								}

								deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->beltOffTime;

								if( deltaTime >= SMEMA_200MS )
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if (pSMEMA->m_CureOption)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);
	
								if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
									(pSMEMA->uiLotFlag==1) && (
									pSMEMA->m_bSmema9851HoldDueToSensor==FALSE) && 
									(iEntry || pSMEMA->m_imesBoardEntering)&&
									cUserAllowed &&
									pSMEMA->dwrdNewRecipeTime == 0 &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = TRUE;
								}
								else
								{
									pSMEMA->m_imesBoardEntering = FALSE;
									*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
									Break9851Lock(pSMEMA->smemaID);

									if( FALSE == g_bLotProcessingEnable )
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0_NoLP.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ0_NoLP.m_bPendSmema == TRUE );
									}
									else
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ0.m_bPendSmema == TRUE );
									}

									//if smema is deactivated and a board is entering, do not renable until the board is in
									if( TRUE == bSmema9851HoldDueToSensor )
									{
										pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
									}
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ0_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ0.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						break;
					
					case 2:
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);

							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
						
							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
									pSMEMA->squareTimeTaken=TRUE;
								}

								currentTime = Timer_getCurrentTime10ths(elapseTimer);
								deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

								if( deltaTime >= SMEMA_100MS )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}
						}

						bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );

						if ( bBoardBackup == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);
							if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
								(pSMEMA->uiLotFlag==1) &&
								(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE && 
								(iEntry || pSMEMA->m_imesBoardEntering)) &&
								cUserAllowed &&
								pSMEMA->dwrdNewRecipeTime == 0 &&
								!pSMEMA->m_bLaneHold)
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = TRUE;
							}
							else 
							{
								pSMEMA->m_imesBoardEntering = FALSE;
								*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
								Break9851Lock(pSMEMA->smemaID);

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ2_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ2.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						else 
						{
							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_CureOption != 0 ) && ( bBoardLeaving == TRUE ) )
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
								}

								deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->beltOffTime;
							
								if( deltaTime >= SMEMA_200MS )
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if (pSMEMA->m_CureOption)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

								if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
									(pSMEMA->uiLotFlag==1) &&
									(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE) && 
									(iEntry || pSMEMA->m_imesBoardEntering) &&
									cUserAllowed &&
									pSMEMA->dwrdNewRecipeTime == 0 &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = TRUE;
								}
								else
								{
									pSMEMA->m_imesBoardEntering = FALSE;
									*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
									Break9851Lock(pSMEMA->smemaID);

									if( FALSE == g_bLotProcessingEnable )
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2_NoLP.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ2_NoLP.m_bPendSmema == TRUE );
									}
									else
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ2.m_bPendSmema == TRUE );
									}

									//if smema is deactivated and a board is entering, do not renable until the board is in
									if( TRUE == bSmema9851HoldDueToSensor )
									{
										pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
									}

								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ2_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ2.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						break;

					default:
						break;
				}
			}
		}
		else 
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);

						bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );

						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
								pSMEMA->squareTimeTaken=TRUE;
							}

							currentTime = Timer_getCurrentTime10ths(elapseTimer);
							deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

							if( deltaTime >= SMEMA_100MS )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}
				

					if( FALSE == g_bLotProcessingEnable )
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0_NoLP.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ0_NoLP.m_bPendSmema == TRUE );
					}
					else
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ0.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ0.m_bPendSmema == TRUE );
					}

					//if smema is deactivated and a board is entering, do not renable until the board is in
					if( TRUE == bSmema9851HoldDueToSensor )
					{
						pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;				
					}
					
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );

					if( ( bBoardBackup != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bBoardLeaving == TRUE ) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						}

						deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->beltOffTime;

						if( deltaTime >= SMEMA_200MS )
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}			
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;
				case 2:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;

					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);

						bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );

						if( ( pSMEMA->m_bAllowNext == FALSE ) &&  (bBoardLeaving == TRUE ) )
						{
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
								pSMEMA->squareTimeTaken=TRUE;
							}

							currentTime = Timer_getCurrentTime10ths(elapseTimer);
							deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

							if( deltaTime >= SMEMA_100MS )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}

					if( FALSE == g_bLotProcessingEnable )
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2_NoLP.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ2_NoLP.m_bPendSmema == TRUE );
					}
					else
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ2.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ2.m_bPendSmema == TRUE );
					}

					//if smema is deactivated and a board is entering, do not renable until the board is in
					if( TRUE == bSmema9851HoldDueToSensor )
					{
						pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
					}

					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );

					if(( bBoardBackup != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bBoardLeaving == TRUE ) )
					{
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						}
						deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->beltOffTime;
						if(deltaTime>=SMEMA_200MS)
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}			
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;
				default:
					break;
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SMEMA_9851_LightTower2_process

			Processes Lanes 1 and 3 for Light Tower 2

 RETURNS:   void
 SEE ALSO: SMEMA_SMEMA_9851_process
------------------------------------------------------------------------*/
void SMEMA_SMEMA_9851_LightTower2_process(SMEMA* pSMEMA)
{
	DWORD deltaTime;
	DWORD deltaOTime;
	DWORD currentTime;
	DWORD boardCount;
	BOOL bStatus;
	BOOL bBoardLeaving;

	BOOL bBoardBackup;
	BOOL bLT1Green;
	BOOL bLT2Green;
	BOOL bSMEMAHold;
	BOOL bSmema9851HoldDueToSensor;

	int iEntry;
	char cUserAllowed;

	cUserAllowed = 0;
	iEntry = 0;

	deltaTime = 0;
	deltaOTime = 0;
	currentTime = 0;
	bStatus = FALSE;
	bBoardLeaving = FALSE;

	bBoardBackup = FALSE;
	bLT1Green = FALSE;
	bLT2Green = FALSE;
	bSMEMAHold = FALSE;
	bSmema9851HoldDueToSensor = FALSE;

	if( NULL != pSMEMA )
	{
		// stop new oven job timer after NEW_RECIPE_TIME_S2 period
		if (pSMEMA->dwrdNewRecipeTime &&
			Timer_getCurrentTime10ths(elapseTimer) - pSMEMA->dwrdNewRecipeTime >= NEW_RECIPE_TIME_S2)
			pSMEMA->dwrdNewRecipeTime = 0;
			
		// get lane board count
		switch (pSMEMA->smemaID)
		{
		case 0 :
			boardCount = boardQ0_NoLP->boardCount + boardQ0->m_boardCount;
			break;
		case 1 :
			boardCount = boardQ1_NoLP->boardCount + boardQ1->m_boardCount;
			break;
		case 2 :
			boardCount = boardQ2_NoLP->boardCount + boardQ2->m_boardCount;
			break;
		case 3 :
			boardCount = boardQ3_NoLP->boardCount + boardQ3->m_boardCount;
			break;
		default :
			boardCount = 0;
			break;
		}
		// if lane board count zero
		if (boardCount == 0)
		{
			bBoardEntering[pSMEMA->smemaID] = FALSE;
			dwBoardEnteringTime[pSMEMA->smemaID] = 0;
#ifdef DEBUG_SMEMA_HOLD
			printk("9851 LightTower2 Lane%d board count zero, disable hold\n", pSMEMA->smemaID + 1);
#endif
		}
		// if SMEMA entrance feed TRUE and board entering and cure option disabled
		if (*DOUT_GetAt(digOutputs, uBoardEnteringSignal[pSMEMA->smemaID]) &&
			bBoardEntering[pSMEMA->smemaID] &&
			pSMEMA->m_CureOption == 0)
		{
			// if SMEMA entrance feed not held TRUE too long
			if ((Timer_getCurrentTime10ths(elapseTimer) - dwBoardEnteringTime[pSMEMA->smemaID]) / 10 < MAX_SMEMA_HOLD_SECONDS)
			{
				// announce SMEMA entrance feed held TRUE
#ifdef DEBUG_SMEMA_HOLD
				printk("9851 LightTower2 Lane%d hold ON\n", pSMEMA->smemaID + 1);
#endif
				return;
			}
			// if SMEMA entrance feed held TRUE too long
			else
			{
				// stop SMEMA entrance feed hold
				bBoardEntering[pSMEMA->smemaID] = FALSE;
				dwBoardEnteringTime[pSMEMA->smemaID] = 0;
#ifdef DEBUG_SMEMA_HOLD
				printk("9851 LightTower2 Lane%d hold timeout\n", pSMEMA->smemaID + 1);
#endif
			}
		}

		SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );

		//
		// Lanes 1 and 3 processing for Light Tower 2
		//
		bSMEMAHold = LightTower_getHoldSmema(lightTower);
		if ( bLT2Green && ( bSMEMAHold == FALSE) )
		{
			bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
			if ( bStatus == FALSE )
			{
				switch ( pSMEMA->smemaID )
				{					
					case 1:
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);

							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN ); 

							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
							{
								currentTime = Timer_getCurrentTime10ths(elapseTimer);

								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime = currentTime;
									pSMEMA->squareTimeTaken=TRUE;
								}

								currentTime = Timer_getCurrentTime10ths(elapseTimer);
								deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );
								if( deltaTime >= SMEMA_100MS )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}
						}

						bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP);

						if ( bBoardBackup == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

							if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
								(pSMEMA->uiLotFlag==1)&&
								(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE) && 
								(iEntry || pSMEMA->m_imesBoardEntering) &&
								 cUserAllowed &&
								pSMEMA->dwrdNewRecipeTime == 0 &&
								!pSMEMA->m_bLaneHold)
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = TRUE;
							}
							else 
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
								Break9851Lock(pSMEMA->smemaID);
								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ1_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ1.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						else 
						{
							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_CureOption != 0 ) && ( bBoardLeaving == TRUE ) )
							{
								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
								}

								deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->beltOffTime;

								if( deltaTime >= SMEMA_200MS )
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if(pSMEMA->m_CureOption!=0)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

								if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
									(pSMEMA->uiLotFlag==1) &&
									(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE)  && 
									(iEntry || pSMEMA->m_imesBoardEntering) &&
									cUserAllowed &&
									pSMEMA->dwrdNewRecipeTime == 0 &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;

									if( FALSE == g_bLotProcessingEnable )
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1_NoLP.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ1_NoLP.m_bPendSmema == TRUE );
									}
									else
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ1.m_bPendSmema == TRUE );
									}

									//if smema is deactivated and a board is entering, do not renable until the board is in
									if( TRUE == bSmema9851HoldDueToSensor )
									{
										pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
									}
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ1_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ1.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						break;
					case 3:
						if(pSMEMA->m_CureOption!=0)
						{
							SMEMA_squareWave(pSMEMA);

							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
							{
								if(pSMEMA->squareTimeTaken==FALSE)
								{
									pSMEMA->dwdSquareTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
									pSMEMA->squareTimeTaken=TRUE;
								}

								currentTime = Timer_getCurrentTime10ths(elapseTimer);
								deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

								if( deltaTime >= SMEMA_100MS )
								{
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
								}
							}

						}

						bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );

						if ( bBoardBackup == TRUE )
						{
							pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							iEntry = SMEMA_EntryAllowed(pSMEMA);
							cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

							if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
								(pSMEMA->uiLotFlag==1) &&
								(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE) && 
								(iEntry || pSMEMA->m_imesBoardEntering) &&
								cUserAllowed &&
								pSMEMA->dwrdNewRecipeTime == 0 &&
								!pSMEMA->m_bLaneHold)
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = TRUE;
							}
							else 
							{
								Break9851Lock(pSMEMA->smemaID);
								*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ3_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ3.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						else 
						{
							bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );

							if( ( pSMEMA->m_CureOption != 0 ) && ( bBoardLeaving == TRUE ) )
							{
								currentTime = Timer_getCurrentTime10ths(elapseTimer);

								if(pSMEMA->beltOffTimeRead==FALSE)
								{
									pSMEMA->beltOffTimeRead=TRUE;
									pSMEMA->beltOffTime = currentTime;
								}

								deltaTime = currentTime - pSMEMA->beltOffTime;
							
								if( deltaTime >= SMEMA_200MS )
								{
									pSMEMA->m_bCureSuspend=TRUE;
									Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
								}
							}
							else
							{
								pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
							}

							if (pSMEMA->m_CureOption)
							{
								iEntry = SMEMA_EntryAllowed(pSMEMA);
								cUserAllowed = SMEMA_SecsgemEntryAllowed(pSMEMA);

								if ( (pSMEMA->pastDeadBandEntrance==TRUE) && 
									(pSMEMA->uiLotFlag==1) &&
									(pSMEMA->m_bSmema9851HoldDueToSensor==FALSE)  && 
									(iEntry || pSMEMA->m_imesBoardEntering) &&
									cUserAllowed &&
									pSMEMA->dwrdNewRecipeTime == 0 &&
									!pSMEMA->m_bLaneHold)
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = TRUE;
								}
								else
								{
									*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;

									if( FALSE == g_bLotProcessingEnable )
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3_NoLP.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ3_NoLP.m_bPendSmema == TRUE );
									}
									else
									{
										bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3.m_bStartSmema == TRUE ) || 
																	( pSMEMA->bBoardHasEntered == TRUE ) || 
																	( g_dbContainer.boardQ3.m_bPendSmema == TRUE );
									}

									//if smema is deactivated and a board is entering, do not renable until the board is in
									if( TRUE == bSmema9851HoldDueToSensor )
									{
										pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
									}
								}
							}
							else
							{
								*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;

								if( FALSE == g_bLotProcessingEnable )
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3_NoLP.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ3_NoLP.m_bPendSmema == TRUE );
								}
								else
								{
									bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3.m_bStartSmema == TRUE ) || 
																( pSMEMA->bBoardHasEntered == TRUE ) || 
																( g_dbContainer.boardQ3.m_bPendSmema == TRUE );
								}

								//if smema is deactivated and a board is entering, do not renable until the board is in
								if( TRUE == bSmema9851HoldDueToSensor )
								{
									pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
								}
							}
						}
						break;

					default:
						break;
				}
			}
		}
		else 
		{
			switch ( pSMEMA->smemaID )
			{
				case 1:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;			
					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);
						
						bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );

						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
						{
							currentTime = Timer_getCurrentTime10ths(elapseTimer);

							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=currentTime;
								pSMEMA->squareTimeTaken=TRUE;
							}

							deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

							if( deltaTime >= SMEMA_100MS )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}
	

					if( FALSE == g_bLotProcessingEnable )
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1_NoLP.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ1_NoLP.m_bPendSmema == TRUE );
					}
					else
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ1.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ1.m_bPendSmema == TRUE );
					}

					//if smema is deactivated and a board is entering, do not renable until the board is in
					if( TRUE == bSmema9851HoldDueToSensor )
					{
						pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
					}
					
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );

					if( ( bBoardBackup != TRUE ) && ( pSMEMA->m_CureOption != 0 ) && ( bBoardLeaving == TRUE ) )
					{
						currentTime = Timer_getCurrentTime10ths(elapseTimer);
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=currentTime;
						}

						deltaTime = currentTime - pSMEMA->beltOffTime;

						if( deltaTime >= SMEMA_200MS )
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}			
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}
					break;
				case 3:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;	

					if(pSMEMA->m_CureOption!=0)
					{
						SMEMA_squareWave(pSMEMA);

						bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );

						if( ( pSMEMA->m_bAllowNext == FALSE ) && ( bBoardLeaving == TRUE ) )
						{
							currentTime = Timer_getCurrentTime10ths(elapseTimer);
							if(pSMEMA->squareTimeTaken==FALSE)
							{
								pSMEMA->dwdSquareTime=currentTime;
								pSMEMA->squareTimeTaken=TRUE;
							}

							deltaTime = differenceWithRollover( currentTime, pSMEMA->dwdSquareTime );

							if( deltaTime >= SMEMA_100MS )
							{
								Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,1);
							}
						}
					}

					if( FALSE == g_bLotProcessingEnable )
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3_NoLP.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ3_NoLP.m_bPendSmema == TRUE );
					}
					else
					{
						bSmema9851HoldDueToSensor = ( g_dbContainer.boardQ3.m_bStartSmema == TRUE ) || 
													( pSMEMA->bBoardHasEntered == TRUE ) || 
													( g_dbContainer.boardQ3.m_bPendSmema == TRUE );
					}

					//if smema is deactivated and a board is entering, do not renable until the board is in
					if( TRUE == bSmema9851HoldDueToSensor )
					{
						pSMEMA->m_bSmema9851HoldDueToSensor =TRUE;
					}

					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );

					if( ( bBoardBackup != TRUE ) && 
						( pSMEMA->m_CureOption != 0 ) && 
						( bBoardLeaving == TRUE ) )
					{
						currentTime = Timer_getCurrentTime10ths(elapseTimer);
						if(pSMEMA->beltOffTimeRead==FALSE)
						{
							pSMEMA->beltOffTimeRead=TRUE;
							pSMEMA->beltOffTime=currentTime;
						}

						deltaTime = currentTime - pSMEMA->beltOffTime;
						
						if( deltaTime >= SMEMA_200MS )
						{
							pSMEMA->m_bCureSuspend=TRUE;
							Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,TRUE,0);
						}
					}			
					else
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;
					}			
					break;

				default:
					break;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SMEMA_9851_process

			Main Process function for SMEMA 9851

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_SMEMA_9851_process(SMEMA* pSMEMA)
{
	DWORD deltaTime;
	DWORD deltaOTime;
	BOOL bStatus;
	BOOL bBoardLeaving;
	BOOL bExit;
	BOOL bBoardBackup;

	deltaTime = 0;
	deltaOTime = 0;
	bStatus = FALSE;
	bBoardLeaving = FALSE;
	bExit = FALSE;
	bBoardBackup = FALSE;

	if( NULL != pSMEMA )
	{
		SMEMA_SMEMA_9851_LightTower1_process( pSMEMA );
		SMEMA_SMEMA_9851_LightTower2_process( pSMEMA );

		// The pastDeadBandExit is used to stretch the pulse of a board that may have holes 
		// that would make the board appear shorter than it is physically. In order for this
		// not to work properly a hole greater than the deadband or boardspacing must exist on
		// the board. The theory is that if a board is detected turn on the take up conveyor to
		// remove the board. If a hole exists without this code the takeup conveyor would shut
		// off when the sensor detects the hole. Now it waits for the board spacing to pass before
		// shutting off.
		// SDY 02/18/2000
		switch ( pSMEMA->smemaID )
		{
			case 0:
				bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );

				if ( bBoardLeaving || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
							*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->m_ExitAvailTime;

							if( deltaOTime >= SMEMA_100MS )
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
							}
						}
					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
				}
				break;
			case 1:
				bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );

				if ( bBoardLeaving || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
							*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->m_ExitAvailTime;

							if( deltaOTime >= SMEMA_100MS )
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
				}
				break;
			case 2:
				bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );

				if ( bBoardLeaving || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
							*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->m_ExitAvailTime;

							if( deltaOTime >= SMEMA_100MS )
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
				}
				break;
			case 3:
				bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );

				if ( bBoardLeaving || !pSMEMA->pastDeadBandExit )
				{
					if(pSMEMA->m_CureOption!=0)
					{
						if(pSMEMA->m_bExitOn==FALSE)
						{
							pSMEMA->m_bExitOn=TRUE;
							pSMEMA->m_ExitAvailTime=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
							*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
						}
						else
						{
							deltaOTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pSMEMA->m_ExitAvailTime;

							if( deltaOTime >= SMEMA_100MS )
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
							}
							else
							{
								*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
							}
						}

					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
					}
				}
				else 
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
				}
				break;
		}

		if(pSMEMA->m_CureOption!=0)
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN );
					bExit = *DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT );

					if( ( ( bBoardBackup == TRUE ) || 
						( ( bBoardBackup == FALSE ) && ( bBoardLeaving == FALSE ) && ( bExit == FALSE ) ) ) )
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;

						Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,0);
					}				
					break;
				case 1:
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN );
					bExit = *DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT );

					if( ( ( bBoardBackup == TRUE ) || 
						( ( bBoardBackup == FALSE ) && ( bBoardLeaving == FALSE ) && ( bExit == FALSE ) ) ) )
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;

						Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,0);
					}
					break;
				case 2:
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN );
					bExit = *DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT );

					if( ( ( bBoardBackup == TRUE ) || 
						( ( bBoardBackup == FALSE ) && ( bBoardLeaving == FALSE ) && ( bExit == FALSE ) ) ) )
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;

						Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,0);
					}
					break;
				case 3:
					bBoardBackup = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP );
					bBoardLeaving = *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN );
					bExit = *DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT );

					if( ( ( bBoardBackup == TRUE ) || 
						( ( bBoardBackup == FALSE ) && ( bBoardLeaving == FALSE ) && ( bExit == FALSE ) ) ) )
					{
						pSMEMA->m_bCureSuspend=pSMEMA->beltOffTimeRead=FALSE;

						Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,0);
					}
					break;

				default:
					break;
			}
		}
	}

	return;
}

void SMEMA_TDK_process(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_TDK_process");

	BOOL bStatus;

	BOOL bLT1Green = FALSE;
	BOOL bLT2Green = FALSE;
	SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );

	//
	// Lanes 0 and 2 processing for Light Tower 1
	//
	if ( bLT1Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = TRUE;
					break;
				case 2:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = TRUE;
					break;
			}
		}
	}			
	else	
	{			
		switch ( pSMEMA->smemaID )
		{
			case 0:
				*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
				break;
			case 2:
				*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
				break;
		}
	}

	//
	// Lanes 1 and 3 processing for Light Tower 2
	//
	if ( bLT2Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{
				case 1:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = TRUE;
					break;
				case 3:
					*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = TRUE;
					break;
			}
		}
	}			
	else	
	{			
		switch ( pSMEMA->smemaID )
		{
			case 1:
				*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
				break;
			case 3:
				*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;
				break;
		}
	}

	switch ( pSMEMA->smemaID )
	{
		case 0:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
			}
			else 
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
			}
			break;
		case 1:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
			}
			else 
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
			}
			break;
		case 2:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
			}
			else 
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
			}
			break;
		case 3:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
			}
			else 
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
			}
			break;
	}
}

void SMEMA_FUJI_process(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_FUJI_process");
	BOOL bStatus;

	BOOL bLT1Green = FALSE;
	BOOL bLT2Green = FALSE;
	SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );

	//
	// Lanes 0 and 2 processing for Light Tower 1
	//
	if ( bLT1Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN ) == TRUE )
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE )	= TRUE;
					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE )	= FALSE;
					}
					break;
				case 2:
					if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN ) == TRUE )
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE )	= TRUE;
					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE )	= FALSE;
					}
					break;
			}
		}

		// Do exit processing
		switch ( pSMEMA->smemaID )
		{
			case 0:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN ) == TRUE )
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
				}
				break;
			case 2:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN ) == TRUE )
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
				}
				break;
		}
	}
	else		// GREEN light is out
	{
		switch ( pSMEMA->smemaID )
		{
			case 0:
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE )	= FALSE;
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT )		= FALSE;
				break;
			case 2:
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE )	= FALSE;
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT )		= FALSE;
				break;
		}
	}

	//
	// Lanes 1 and 3 processing for Light Tower 2
	//
	if ( bLT2Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{
				case 1:
					if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN ) == TRUE )
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE )	= TRUE;
					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE )	= FALSE;
					}
					break;
				case 3:
					if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN ) == TRUE )
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE )	= TRUE;
					}
					else
					{
						*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE )	= FALSE;
					}
					break;
			}
		}

		// Do exit processing
		switch ( pSMEMA->smemaID )
		{
			case 1:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN ) == TRUE )
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
				}
				break;
			case 3:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN ) == TRUE )
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
				}
				break;
		}
	}
	else		// GREEN light is out
	{
		switch ( pSMEMA->smemaID )
		{
			case 1:
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE )	= FALSE;
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT )		= FALSE;
				break;
			case 3:
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE )	= FALSE;
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT )		= FALSE;
				break;
		}
	}
}


void SMEMA_SEAGATE_process(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_SEAGATE_process");
	BOOL bStatus;

	BOOL bLT1Green = FALSE;
	BOOL bLT2Green = FALSE;
	SMEMA_GetLightTowerStatus( &bLT1Green, &bLT2Green );
				
	// If the amber light, low nitrogen, or red light ( board backup) are present then no boards should be entering the oven.
	// SDY - 06-15-2000

	//
	// Lanes 0 and 2 processing for Light Tower 1
	//
	if ( bLT1Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{
				case 0:
					*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE ) = FALSE;
					if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_ENTERING_OVEN ) == FALSE && pSMEMA->pastDeadBandEntrance )
					{
						if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == TRUE )
						{
							*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE ) = TRUE;
						}
					}
					break;
				case 2:
					*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE ) = FALSE;
					if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_ENTERING_OVEN ) == FALSE && pSMEMA->pastDeadBandEntrance )
					{
						if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == TRUE )
						{
							*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE ) = TRUE;
						}
					}
					break;
			}
		}
	}
	else
	{	// The light tower is not green so do not allow boards to enter the oven.
		// SDY 06-15-2000
		*DOUT_GetAt(digOutputs, ODO_SMEMA1_ENTRANCE ) = FALSE;	
		*DOUT_GetAt(digOutputs, ODO_SMEMA3_ENTRANCE ) = FALSE;
	}

	//
	// Lanes 1 and 3 processing for Light Tower 2
	//
	if ( bLT2Green && (LightTower_getHoldSmema(lightTower)==FALSE) )
	{
		bStatus = SMEMA_ProcessMaxBoardsPerLane( pSMEMA );
		if ( bStatus == FALSE )
		{
			switch ( pSMEMA->smemaID )
			{				
				case 1:
					*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE ) = FALSE;
					if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_ENTERING_OVEN ) == FALSE && pSMEMA->pastDeadBandEntrance )
					{
						if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == TRUE )
						{
							*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE ) = TRUE;
						}
					}
					break;
				case 3:
					*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE ) = FALSE;
					if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_ENTERING_OVEN ) == FALSE && pSMEMA->pastDeadBandEntrance )
					{
						if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == TRUE )
						{
							*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE ) = TRUE;
						}
					}
					break;
			}
		}
	}
	else
	{	// The light tower is not green so do not allow boards to enter the oven.
		// SDY 06-15-2000
		*DOUT_GetAt(digOutputs, ODO_SMEMA2_ENTRANCE ) = FALSE;
		*DOUT_GetAt(digOutputs, ODO_SMEMA4_ENTRANCE ) = FALSE;
	}
	
	switch ( pSMEMA->smemaID )
	{
		case 0:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) = FALSE;
			}
			break;
		case 1:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) = FALSE;
			}
			break;
		case 2:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) = FALSE;
			}
			break;
		case 3:
			if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN ) || !pSMEMA->pastDeadBandExit )
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) = FALSE;
			}
			break;
	}
	
	//
	// Lanes 0 and 2 processing for Light Tower 1
	//
	if ( bLT1Green )
	{
		if( (*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema1) != SEAGATE) &&
			(*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema3) != SEAGATE ) )
		{
			LightTower_smemaSetRed(lightTower, FALSE );	
		}

		switch ( pSMEMA->smemaID )
		{
			case 0:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == FALSE )
				{
					LightTower_smemaSetRed(lightTower, TRUE );
				}
				break;
			case 2:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == FALSE )
				{
					LightTower_smemaSetRed(lightTower, TRUE );
				}
				break;
		}
	}
	else
	{
		if( (*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema1) == NO_SMEMA)  &&
			(*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema3) == NO_SMEMA) )
		{
			LightTower_smemaSetRed(lightTower, FALSE );	
		}
	}

	//
	// Lanes 1 and 3 processing for Light Tower 2
	//
	if ( bLT2Green )
	{
		if( (*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema2) != SEAGATE )	&&
			(*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema4) != SEAGATE ) )
		{
			LightTower_LT2_smemaSetRed(lightTower, FALSE );	
		}

		switch ( pSMEMA->smemaID )
		{
			case 1:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == FALSE )
				{
					LightTower_LT2_smemaSetRed(lightTower, TRUE );
				}
				break;
			case 3:
				if ( *DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == FALSE )
				{
					LightTower_LT2_smemaSetRed(lightTower, TRUE );
				}
				break;
		}
	}
	else
	{
		if( (*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema2) == NO_SMEMA)	&&
			(*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == TRUE || SMEMA_getSMEMAtype(smema4) == NO_SMEMA) )
		{
			LightTower_LT2_smemaSetRed(lightTower, FALSE );	
		}
	}

	// under these conditions it does not matter which SMEMA interface is SEAGATE,
	// we know at least one of them is so set the amber light if the light is GREEN.

	LightTower_smemaSetAmber(lightTower, FALSE);
	if ( bLT1Green )
	{
		if ( !Nitrogen_isNitrogenPressureOK(nitrogen) )
		{
			LightTower_smemaSetAmber(lightTower, TRUE);
		}
	}

	LightTower_LT2_smemaSetAmber(lightTower, FALSE);
	if ( bLT2Green )
	{
		if ( !Nitrogen_isNitrogenPressureOK(nitrogen) )
		{
			LightTower_LT2_smemaSetAmber(lightTower, TRUE);
		}
	}
}

enum SMEMA_Interface SMEMA_getSMEMAtype( SMEMA* pSMEMA )
{
	PARAM_CHECK_RETURN( pSMEMA, "SMEMA_getSMEMAtype", 0);
	return pSMEMA->SMEMA_Type; 
}

void SMEMA_setDeadBandCounts(SMEMA* pSMEMA, DWORD SMEMAdeadBandCounts ) 
{
	PARAM_CHECK( pSMEMA, "SMEMA_setDeadBandCounts");
	pSMEMA->deadBandCounts = SMEMAdeadBandCounts; 
}

void SMEMA_setSmemaExitLength(SMEMA* pSMEMA, DWORD exitDeadbandCounts)
{
	PARAM_CHECK( pSMEMA, "SMEMA_setDeadBandCounts");
	pSMEMA->exitDeadBandCounts = exitDeadbandCounts;
}
void SMEMA_LotDisable(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_LotDisable");
	pSMEMA->uiLotFlag=0;
}

void SMEMA_LotEnable(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_LotEnable");
	pSMEMA->uiLotFlag=1;
}
void SMEMA_exitCureSetting(SMEMA* pSMEMA, DWORD setting)
{
	PARAM_CHECK( pSMEMA, "SMEMA_exitCureSetting");
	pSMEMA->m_CureOption=setting;
}

void SMEMA_informGUIofBeltStop(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_informGUIofBeltStop");
	AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, (SMEMA_EXIT_ERR+pSMEMA->smemaID), pSMEMA->smemaID );
}

void SMEMA_squareWave(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_squareWave");
	unsigned int digIn;
//	unsigned int digIn2;
	switch(pSMEMA->smemaID)
	{
		case 0:
			digIn=IDI_SMEMA1_BOARD_BACKUP;
			if(((*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == FALSE)&&(*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}
			if(/*(g_dbContainer.boardQ0.exitBoardDeadbandCounts==0)&&*/((*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_BACKUP ) == TRUE)&&(*DIN_GetAt(digInputs, IDI_SMEMA1_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA1_EXIT ) == FALSE)))	
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}
//			digIn2=IDI_SMEMA1_BOARD_LEAVING_OVEN;
			break;
		case 1:
			digIn=IDI_SMEMA2_BOARD_BACKUP;
			if(((*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == FALSE)&&(*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}			
			if(/*(g_dbContainer.boardQ1.exitBoardDeadbandCounts==0)&&*/((*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_BACKUP ) == TRUE)&&(*DIN_GetAt(digInputs, IDI_SMEMA2_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA2_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}
//			digIn2=IDI_SMEMA2_BOARD_LEAVING_OVEN;
			break;
		case 2:
			digIn=IDI_SMEMA3_BOARD_BACKUP;
			if(((*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == FALSE)&&(*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}			
			if(/*(g_dbContainer.boardQ2.exitBoardDeadbandCounts==0)&&*/((*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_BACKUP ) == TRUE)&&(*DIN_GetAt(digInputs, IDI_SMEMA3_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA3_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}
//			digIn2=IDI_SMEMA3_BOARD_LEAVING_OVEN;
			break;
		case 3:
			digIn=IDI_SMEMA4_BOARD_BACKUP;
			if(((*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == FALSE)&&(*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}			
			if(/*(g_dbContainer.boardQ3.exitBoardDeadbandCounts==0)&&*/((*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_BACKUP ) == TRUE)&&(*DIN_GetAt(digInputs, IDI_SMEMA4_BOARD_LEAVING_OVEN ) == FALSE)&&(*DOUT_GetAt(digOutputs, ODO_SMEMA4_EXIT ) == FALSE)))
			{
				Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			}
//			digIn2=IDI_SMEMA4_BOARD_LEAVING_OVEN;
			break;
	}
//	if(*DIN_GetAt(digInputs, digIn2)==FALSE)
//	{
		switch(pSMEMA->m_iMachineBStatus)
		{
		case 0: //0 ready
		case 1: //waiting for high condition (error smema pattern)
//note remove the first High test per conversation with Tushar due to testing with 0 board spacing
//we will only look for transition from low to high
		case 2: //2 line high initial
			if(*DIN_GetAt(digInputs, digIn) == FALSE)
			{
				pSMEMA->m_iMachineBStatus=3;
			}
			break;
		case 3: //low occured
			if(/*(pSMEMA->pastDeadBandExit==TRUE)&&*/(*DIN_GetAt(digInputs, digIn) == TRUE))
			{
				pSMEMA->m_iMachineBStatus=4;
			}
			break;
		case 4: //square wave completed
			if(pSMEMA->pastDeadBandExit == FALSE)//if we get square wave when the next board is under sensor, allow it to continue
			{
				pSMEMA->m_bAllowNext=TRUE;
			}
			pSMEMA->m_bAllowNextPend=TRUE;
			Belt_SuspendForSmema(pBelt[pSMEMA->smemaID],pSMEMA->smemaID,FALSE,1);
			pSMEMA->squareTimeTaken=FALSE;
		break;
		}
//	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_bSmemaEnabled


 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int SMEMA_bSmemaEnabled(SMEMA* pSMEMA)
{
	PARAM_CHECK_RETURN( pSMEMA, "SMEMA_bSmemaEnabled", 0);
	int iReturn=1;

	if(pSMEMA->SMEMA_Type==NO_SMEMA)
	{
		iReturn=0;
	}

	return iReturn;
}

void SMEMA_bcScanned(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_bcScanned");
	
	bcEntry++;
}

void SMEMA_setLaneCount(SMEMA* pSMEMA, DWORD dwrdLC)
{ 
	PARAM_CHECK( pSMEMA, "SMEMA_setLaneCount");
	laneCount=dwrdLC;
}

void SMEMA_holdAllow()
{
	smema1->dwrdNewRecipeTime = Timer_getCurrentTime10ths(elapseTimer);
	smema2->dwrdNewRecipeTime = Timer_getCurrentTime10ths(elapseTimer);
	smema3->dwrdNewRecipeTime = Timer_getCurrentTime10ths(elapseTimer);
	smema4->dwrdNewRecipeTime = Timer_getCurrentTime10ths(elapseTimer);	
}

void SMEMA_clearBarcode()
{
	bcEntry = 0;
	smema1->m_bIsIndividualFree=FALSE;
	smema2->m_bIsIndividualFree=FALSE;
	smema3->m_bIsIndividualFree=FALSE;
	smema4->m_bIsIndividualFree=FALSE;

	smema1->m_bBarcodeAllowAgain=FALSE;
	smema2->m_bBarcodeAllowAgain=FALSE;
	smema3->m_bBarcodeAllowAgain=FALSE;
	smema4->m_bBarcodeAllowAgain=FALSE;			
	smema1->m_bBarcodeAllow=FALSE;
	smema2->m_bBarcodeAllow=FALSE;
	smema3->m_bBarcodeAllow=FALSE;
	smema4->m_bBarcodeAllow=FALSE;	
	smema1->m_bIndvAllow=FALSE;
	smema2->m_bIndvAllow=FALSE;
	smema3->m_bIndvAllow=FALSE;
	smema4->m_bIndvAllow=FALSE;
}

void SMEMA_entry(SMEMA* pSMEMA)
{
	PARAM_CHECK( pSMEMA, "SMEMA_entry");
	SMEMA_bcScanned(&(g_dbContainer.smema1));
	if(SMEMA_bSmemaEnabled(&(g_dbContainer.smema1)))
	{
		if((g_dbContainer.smema1.m_bBarcodeAllow==TRUE)&&(g_dbContainer.smema1.pastDeadBandEntrance==FALSE))
		{
			g_dbContainer.smema1.m_bBarcodeAllowAgain = TRUE;
		}
		g_dbContainer.smema1.m_bBarcodeAllow = TRUE;
		
	}
	if(SMEMA_bSmemaEnabled(&(g_dbContainer.smema2)))
	{
		if((g_dbContainer.smema2.m_bBarcodeAllow==TRUE)&&(g_dbContainer.smema2.pastDeadBandEntrance==FALSE))
		{
			g_dbContainer.smema2.m_bBarcodeAllowAgain = TRUE;
		}
		g_dbContainer.smema2.m_bBarcodeAllow = TRUE;
	}
	if(SMEMA_bSmemaEnabled(&(g_dbContainer.smema3)))
	{
		if((g_dbContainer.smema3.m_bBarcodeAllow==TRUE)&&(g_dbContainer.smema3.pastDeadBandEntrance==FALSE))
		{
			g_dbContainer.smema3.m_bBarcodeAllowAgain = TRUE;
		}
		g_dbContainer.smema3.m_bBarcodeAllow = TRUE;
	}
	if(SMEMA_bSmemaEnabled(&(g_dbContainer.smema4)))
	{
		if((g_dbContainer.smema4.m_bBarcodeAllow==TRUE)&&(g_dbContainer.smema4.pastDeadBandEntrance==FALSE))
		{
			g_dbContainer.smema4.m_bBarcodeAllowAgain = TRUE;
		}
		g_dbContainer.smema4.m_bBarcodeAllow = TRUE;
	}
}

void SMEMA_SetMaxBoardsPerLaneEnable(SMEMA* pSMEMA, BOOL bEnable)
{
	pSMEMA->m_bMaxBoardsPerLaneEnable = bEnable;
}

void SMEMA_SetMaxBoardsPerLaneSetCount(SMEMA* pSMEMA, DWORD dwCount)
{
	pSMEMA->m_nMaxBoardsPerLaneCount = dwCount;
}

void SMEMA_SetNoBoardAnimationEnable(SMEMA* pSMEMA, BOOL bEnable)
{
	pSMEMA->m_bNoBoardAnimation = bEnable;
}

void SMEMA_SetLaneHold(SMEMA* pSMEMA, BOOL bHold)
{
	pSMEMA->m_bLaneHold = bHold;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_ProcessMaxBoardsPerLane

			If the number of boards in the lane has reached the 
			m_nMaxBoardsPerLaneCount, then turn off the Entrance Sensor.

 RETURNS:   BOOL - TRUE if entrance sensor turned off; FALSE otherwise
------------------------------------------------------------------------*/
BOOL SMEMA_ProcessMaxBoardsPerLane(SMEMA* pSMEMA)
{
	BOOL bProcessed;
	BOOL bSensorOff;

	bProcessed = FALSE;
	bSensorOff = FALSE;

	if( NULL != pSMEMA )
	{
		// The variables m_bMaxBoardsPerLaneEnable and m_nMaxBoardsPerLaneCount are set 
		// via the SetupWizard and should never be changed manually.
		if ( pSMEMA->m_bMaxBoardsPerLaneEnable )
		{
			// If the number of boards in the lane has reached the 
			// m_nMaxBoardsPerLaneCount, then turn off the Entrance Sensor.

			switch( pSMEMA->smemaID )
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						bSensorOff = boardQ0_NoLP->boardQueueActive && (boardQ0_NoLP->boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}
					else
					{
						bSensorOff = boardQ0->boardQueueActive && (boardQ0->m_boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}

					if ( TRUE == bSensorOff )
					{
						*DOUT_GetAt(digOutputs,	ODO_SMEMA1_ENTRANCE ) = FALSE;
						bProcessed = TRUE;
					}
					break;

				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						bSensorOff = boardQ1_NoLP->boardQueueActive && (boardQ1_NoLP->boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}
					else
					{
						bSensorOff = boardQ1->boardQueueActive && (boardQ1->m_boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}

					if ( TRUE == bSensorOff )
					{
						*DOUT_GetAt(digOutputs,	ODO_SMEMA2_ENTRANCE ) = FALSE;
						bProcessed = TRUE;

					}
					break;

				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						bSensorOff = boardQ2_NoLP->boardQueueActive && (boardQ2_NoLP->boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}
					else
					{
						bSensorOff = boardQ2->boardQueueActive && (boardQ2->m_boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}

					if ( TRUE == bSensorOff )
					{
						*DOUT_GetAt(digOutputs,	ODO_SMEMA3_ENTRANCE ) = FALSE;
						bProcessed = TRUE;

					}
					break;

				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						bSensorOff = boardQ3_NoLP->boardQueueActive && (boardQ3_NoLP->boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}
					else
					{
						bSensorOff = boardQ3->boardQueueActive && (boardQ3->m_boardCount >= pSMEMA->m_nMaxBoardsPerLaneCount);
					}

					if ( TRUE == bSensorOff )
					{
						*DOUT_GetAt(digOutputs,	ODO_SMEMA4_ENTRANCE ) = FALSE;
						bProcessed = TRUE;

					}
					break;

				default:
					break;
			}
		}
	}

	return bProcessed;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_GetLightTowerStatus

			sets the parameters to true if the light tower is in green state
			and not in comm loss

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_GetLightTowerStatus(BOOL* pbLT1Green, BOOL* pbLT2Green)
{
	if(lightTower)
	{
		if ( pbLT1Green && pbLT2Green )
		{
			*pbLT1Green = FALSE;
			*pbLT2Green = FALSE;

			if ( lightTower->m_LT2_bEnable )
			{
				// Test light tower 1 and 2
				switch ( lightTower->m_ltOvenState1 )
				{
					case LTOS_READY_EMPTY:
					case LTOS_READY_BOARDS:
						*pbLT1Green = TRUE;
						break;
					default:
						break;
				}

				switch ( lightTower->m_ltOvenState2 )
				{
					case LTOS_READY_EMPTY:
					case LTOS_READY_BOARDS:
						*pbLT2Green = TRUE;
						break;
					default:
						break;
				}
			}
			else
			{
				// Only test light tower 1 and if LT1 is green
				// then "LT2" is green also.
				switch ( lightTower->m_ltOvenState1 )
				{
					case LTOS_READY_EMPTY:
					case LTOS_READY_BOARDS:
						*pbLT1Green = TRUE;
						*pbLT2Green = TRUE;
						break;
					default:
						break;
				}
			}
			if(lightTower->m_bCommLoss)
			{
				*pbLT1Green = FALSE;
				*pbLT2Green = FALSE;
			}
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_BoardEntered

			called when the board is recognized by the hc2xctl
 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_BoardEntered()
{
	int i;

	i = 0;

	//mark for all lanes, will go low on smema output false 9851
	smema1->m_imesBoardEntering = TRUE;
	smema2->m_imesBoardEntering = TRUE;
	smema3->m_imesBoardEntering = TRUE;
	smema4->m_imesBoardEntering = TRUE;
	for(i = 0; i < NUM_FILE_CONTROLLED_SMEMA; i++)
	{
		if(s_iMESActive[i] && s_iMESAllowed[i])
		{
			if(i==APCO_INDEX)
			{
				AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, APCO_SMEMA_DISALLOWED, 0 );
			}
			s_iMES_entryAllowed[i] = 0;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_MESSmemaVariable
			
			sets file control smema variables

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_MESSmemaVariable(int iEntry, int iIndex)
{
	int iWhich;
	int i;

	i = 0;
	iWhich = 0;
	if(iIndex == NUM_FILE_CONTROLLED_SMEMA)
	{

		for(i = 0; i < NUM_FILE_CONTROLLED_SMEMA; i++)
		{
			if(s_iMESActive[i] && s_iMESAllowed[i])
			{
				if(i==APCO_INDEX)
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, APCO_SMEMA_ALLOWED, 0 );
				}
				s_iMES_entryAllowed[i] = iEntry; //TRUE/FALSE
			}
			else
			{
				s_iMES_entryAllowed[i] = 1; //when the option is not on, always allow		
			}
		}
	}
	else if(iIndex < NUM_FILE_CONTROLLED_SMEMA)
	{
		if(s_iMESActive[iIndex] && s_iMESAllowed[iIndex])
		{
			s_iMES_entryAllowed[iIndex] = iEntry; //TRUE/FALSE
		}
		else
		{
			s_iMES_entryAllowed[iIndex] = 1; //when the option is not on, always allow		
		}

	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_MESActivate
 
			this function sets a file controlled barcode smema option to active

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_MESActivate(int iActive, int iIndex)
{
	if(iIndex < NUM_FILE_CONTROLLED_SMEMA)
	{
		s_iMESActive[iIndex] = iActive; //sw setting
		if(iActive == 0)
		{
			s_iMES_entryAllowed[iIndex] = 1; //when the option is not on, always allow		
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_MESAllowed

			Allows an entry for a file controlled smema system

 RETURNS:   void
------------------------------------------------------------------------*/
void SMEMA_MESAllowed(int iAllowed, int iIndex)
{
	if(iIndex < NUM_FILE_CONTROLLED_SMEMA)
	{
		if((s_iMESAllowed[iIndex] == 0) && iAllowed
			&& s_iMESActive[iIndex])//system is transitioning on,
		{
			s_iMES_entryAllowed[iIndex] = 0;
		}
		if(iAllowed == 0)
		{
			s_iMES_entryAllowed[iIndex] = 1; //when the option set off, allow		
		}
		s_iMESAllowed[iIndex] = iAllowed; //runtime parameter
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_EntryAllowed

			Allows an entry for a file controlled smema system
			if the file has been read.  includes a "lock" for 9851
			to hold high until it naturally goes low

 RETURNS:   int 0 false, 1 true
------------------------------------------------------------------------*/
int SMEMA_EntryAllowed(SMEMA* pSMEMA)
{
	int iReturn;
	int i;
	char cLock;

	cLock = 0;
	iReturn = 1;
	i = 0;
	
	if(pSMEMA)
	{
		if(pSMEMA->SMEMA_Type == SMEMA_9851)
		{
			switch(pSMEMA->smemaID)
			{
				case 0:
					cLock = uc9851Lock1; 
					break;

				case 1:
					cLock = uc9851Lock2; 
					break;

				case 2:
					cLock = uc9851Lock3; 
					break;

				case 3:
					cLock = uc9851Lock4; 
					break;

				default:
					break;
			}
		}
	}
	for(i = 0; i < NUM_FILE_CONTROLLED_SMEMA; i++)
	{
		if(!s_iMES_entryAllowed[i] )
		{
			iReturn = 0;
		}
		if(cLock)
		{
			iReturn = 1;
		}
	}

	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Break9851Lock

			Clears the 9851 lock

 RETURNS:   nothing
------------------------------------------------------------------------*/
void Break9851Lock(UINT smemaID)
{
	switch(smemaID)
	{
		case 0:
			uc9851Lock1 = 0;
			break;

		case 1:
			uc9851Lock2 = 0;
			break;

		case 2:
			uc9851Lock3 = 0;
			break;

		case 3:
			uc9851Lock4 = 0;
			break;

		default:
			break;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SecsGemEntryOption

			sets the smema secsgem option

 RETURNS:  nothing
------------------------------------------------------------------------*/
void SMEMA_SecsGemEntryOption(SMEMA* pSMEMA,char iSetting)
{
	if(pSMEMA)
	{
		pSMEMA->cSecgemControl = iSetting;
		pSMEMA->cSecgemEntry = 0;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SecsGemSetting

			The ec was set at the UI level

 RETURNS:   nothing
------------------------------------------------------------------------*/
void SMEMA_SecsGemSetting(SMEMA* pSMEMA, char onOff)
{
	if(pSMEMA)
	{
		pSMEMA->cSecgemEntry = onOff;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SecsgemEntryAllowed

			used by smema routine to set output

 RETURNS:   char 1 or 0
------------------------------------------------------------------------*/
char SMEMA_SecsgemEntryAllowed(SMEMA* pSMEMA)
{
	char cReturn;
	char cControlled;
	char cAllowed;
	char cLocked;

	cLocked = 0;
	cAllowed = 0;
	cControlled = 0;
	cReturn = 1; //default to allow

	if(pSMEMA)
	{
		cControlled = pSMEMA->cSecgemControl;
		if(cControlled)
		{
			switch(pSMEMA->smemaID)
			{
				case 0:
					cLocked = uc9851Lock1; 
					break;

				case 1:
					cLocked = uc9851Lock2; 
					break;

				case 2:
					cLocked = uc9851Lock3; 
					break;

				case 3:
					cLocked = uc9851Lock4; 
					break;

				default:
					break;
			}


			cAllowed = pSMEMA->cSecgemEntry;
			cReturn = (cAllowed || cLocked);
		}
	}

	return cReturn;
}
