/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
 ***************************************************************************/
#ifndef __NEWBOARDQ_H__
#define __NEWBOARDQ_H__

/*=======================================================================
 *
 * INCLUDE FILES:
 *
 *=======================================================================*/

#include "boards.h"
#include "typedefdefine.h"

/*========================================================================
 *
 * GLOBALS DEFINED
 *
 *=======================================================================*/   

enum { MaxBoards = 512 };

/*========================================================================
 *
 * struct Definition: newBoardQueue
 *
 *=======================================================================*/   

typedef struct _newBoardQueue_
{
	Board		boards[MaxBoards];

	UINT		boardQIdIndex;
	char	name[MaxNameLength+1];
	UINT		boardQId;
	Belt		*pBeltIOTied;		// pointer to the parent belt.

	BOOL	*pBoardEnteringOven;
	BOOL	*pBoardLeavingOven;
	BOOL		boardQueueActive;
	DWORD		boardDeadbandCounts;
	DWORD		distanceBetweenSensorsCounts;
	DWORD		currentBeltPosition;
	DWORD		boardsProcessed;

	// lastBoardDetectPosition and lastBoardDetectTime save the belt position and the elapseTimer's value when the input sensor goes OFF.
	DWORD		lastBoardDetectPosition;
	DWORD		lastBoardDetectTime;

	UINT		headIndex;
	UINT		tailIndex;
	DWORD		m_boardCount;

	BOOL		timedBoarddropEnabled;
	BOOL		boardsInOvenEnabled;
	BOOL		boardsProcessedEnabled;

	BOOL		previousBoardDetectState;

	// m_startBoardInDetectTime saves the elapseTimer's value for when the input sensor transitions from OFF to ON
	DWORD		m_startBoardInDetectTime;

	// m_localTimeEntryLeadingEdge references the m_currentTime's value for the last time the board entry input was OFF
	LocalTime	m_localTimeEntryLeadingEdge;

	// m_localTimeEntryTrailingEdge references the m_currentTime's value for the last time the board entry input was ON
	LocalTime	m_localTimeEntryTrailingEdge;

	// m_localTimeExitLeadingEdge references the m_currentTime's value for the last time the board exit input was OFF
	LocalTime	m_localTimeExitLeadingEdge;

	// m_localTimeExitTrailingEdge references the m_currentTime's value for the last time the board exit input was ON
	LocalTime	m_localTimeExitTrailingEdge;

	DWORD		expectLowInputAfterCounts;
	
	UINT		filterCount;

	BOOL		boardEntranceJamState;
	BOOL		previousBoardOutDetectState;
	DWORD		startBoardOutDetectTime;
	DWORD		boardBackUpTime;
	BOOL		lowHasOccurred;
	BoardData   boardData;
	BOOL		m_bBoardOnEntrySensor;
	BOOL		m_bEnableBoardStop;
	DWORD 	exitBoardDeadbandCounts;
	DWORD		boardDropTol;
	UINT		uintBoardDropTime;
	DWORD		m_uintTimeBackupBegan;
	DWORD		m_uintTimeEntranceJamBegan;
	DWORD		boardDropTolNeg;	
	DWORD		selfAckCode;
	DWORD		selfAckAdd;
	BOOL 		m_bPendSmema;
	BOOL		m_bStartSmema;
	DWORD 		smema9851startBoardInDetectDist;
	BOOL		m_bLengthAssigned;
	BOOL		m_bBoardBackUpState;
	int notifyBoard;
	int notifyBoardOut;
	BOOL m_bSprayEnabled;
	DWORD dwSprayLength;
	DWORD	m_dwSprayDist;
	DWORD	m_FCExit;
	BOOL	m_bBoardExitFull;
	DWORD	m_dwrdLastBeltPosWNoBoards;

	BOOL	m_boardHeadReadEntry;
	DWORD	m_boardStartPosEntry;

	BOOL	m_boardHeadReadExit;
	DWORD	m_boardStartPosExit;

	BOOL	m_b9851Enter;
	DWORD	m_9851distanceTraveled;

	BOOL	m_bIgnoreBoardLength;	// used to ignore board length in the board drop calculation
	
	BOOL	m_bEnablePredefinedBoardLength;
	DWORD	m_PredefinedBoardLength;

	BOOL	m_bEntranceJamWarning;
	BOOL    m_bEnteranceJamStampTaken;
	DWORD	m_enteranceJamBeginDist;
	BOOL    m_bExitJamStampTaken;
	DWORD	m_exitJamBeginDist;
	BOOL	boardExitJamState;
	DWORD	m_uintTimeExitJamBegan;

	// TimeStamp used to coordinate the time between the PC and the driver.
	LocalTime	m_currentTime;
	unsigned   long	m_jiffies;

	UINT	uiCurrentJob;
	BOOL 	timeStamped;
	BOOL	timeStampedL;
	DWORD	existingBoardDropID;
	DWORD	inputHighCount;

	UINT	m_lastJob;
	BOOL	m_bleadingEdgeLow;

} newBoardQueue;


void		newBoardQueue_init(newBoardQueue* pNBQ, const char *szName );

BOOL		newBoardQueue_ioConfig(newBoardQueue* pNBQ, UINT activeBelts );
BOOL		newBoardQueue_bdConfig(newBoardQueue* pNBQ, DWORD boardDropConfig );
BOOL		newBoardQueue_bpConfig(newBoardQueue* pNBQ, DWORD boardsProcessedConfig );
BOOL		newBoardQueue_boConfig(newBoardQueue* pNBQ, DWORD boardsInOvenConfig );
void		newBoardQueue_checkForBoardEntering(newBoardQueue* pNBQ);
void		newBoardQueue_checkForBoardDrop(newBoardQueue* pNBQ);
void		newBoardQueue_checkForBoardLeaving(newBoardQueue* pNBQ);
void		newBoardQueue_checkForEntranceBoardJam(newBoardQueue* pNBQ);
void		newBoardQueue_checkForBoardBackup(newBoardQueue* pNBQ);
void		newBoardQueue_checkForBoardFCExit(newBoardQueue* pNBQ);
void		newBoardQueue_hasLowOccurred(newBoardQueue* pNBQ);
void		newBoardQueue_checkForLeadingEdgeLow(newBoardQueue* pNBQ);

BOOL		newBoardQueue_addBoard(newBoardQueue* pNBQ);
void		newBoardQueue_removeBoard(newBoardQueue* pNBQ);

void		newBoardQueue_setLength(newBoardQueue* pNBQ);
void		newBoardQueue_newBoard(newBoardQueue* pNBQ, DWORD beltPositionInCounts );
void		newBoardQueue_updateBoardPositions(newBoardQueue* pNBQ);

BOOL		newBoardQueue_configure(newBoardQueue* pNBQ, DWORD boardDropConfig, DWORD boardsProcessedConfig, DWORD boardsInOvenConfig );
DWORD		newBoardQueue_getBoardsInOvenCount(newBoardQueue* pNBQ, UINT ui_Type);
DWORD		newBoardQueue_getBoardsProcessed(newBoardQueue* pNBQ);
BOOL		newBoardQueue_isPastDeadBand(newBoardQueue* pNBQ);
void		newBoardQueue_setBoardsProcessed(newBoardQueue* pNBQ, DWORD noOfBoardsProcessed );
void		newBoardQueue_clearBoardsProcessed(newBoardQueue* pNBQ);
DWORD		newBoardQueue_getMaxBoards(newBoardQueue* pNBQ);
void		newBoardQueue_process(newBoardQueue* pNBQ);
const char *newBoardQueue_getName(newBoardQueue* pNBQ);
void		newBoardQueue_clearBoardsInOven(newBoardQueue* pNBQ);
void		newBoardQueue_setSensorDistance(newBoardQueue* pNBQ, DWORD distanceBetweenSensorsInCounts );
DWORD		newBoardQueue_getSensorDistance(newBoardQueue* pNBQ);
void		newBoardQueue_setBoardDeadBandDistance(newBoardQueue* pNBQ,  DWORD boardDeadBandInCounts );
void 		newBoardQueue_enableBoardStop(newBoardQueue* pNBQ, BOOL enableState);
const BoardData *  newBoardQueue_getBoardAnimationData(newBoardQueue* pNBQ);
void     newBoardQueue_setExitBoardDeadbandCounts(newBoardQueue* pNBQ, DWORD boardDeadbandExitInCounts);
void		newBoardQueue_setBoardDropTolerance(newBoardQueue* pNBQ, DWORD bdt);
void		newBoardQueue_setBoardDropTime(newBoardQueue* pNBQ,UINT bTime);
void		newBoardQueue_setBoardDropToleranceNeg(newBoardQueue* pNBQ,DWORD bdt);
void 		newBoardQueue_enableSpraySensor(newBoardQueue* pNBQ, BOOL bEnable);
void  	newBoardQueue_addSprayLength(newBoardQueue* pNBQ, DWORD dwrLength);
void  	newBoardQueue_setSprayDist(newBoardQueue* pNBQ,DWORD dwDist);
BOOL 		newBoardQueue_checkForSpray(newBoardQueue* pNBQ);
void		newBoardQueue_setBoardFCExtraTravel(newBoardQueue* pNBQ, DWORD extra);

void		newBoardQueue_updateCurrentTime( newBoardQueue* pNBQ );
void		newBoardQueue_setTimeStampWithCurrentTime( newBoardQueue* pNBQ, LocalTime* pTimeStamp );

void		newBoardQueue_markBoardsWithCooldown( newBoardQueue* pNBQ );
UINT		newBoardQueue_getNextIndex(newBoardQueue* pNBQ);
void		newBoardQueue_removeBoardFromCircularBuffer(newBoardQueue* pNBQ);

#endif
