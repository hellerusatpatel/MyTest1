/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999-2014, All Rights Reserved
                    Company Confidential

	File:			tempzs.h

	Description:	tempzones master object

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __TEMPZS_H__
#define __TEMPZS_H__

#include "tempzone.h"
#include "typedefdefine.h"
/*******************************************************************************
 *
 * DEFINES
 *
 *******************************************************************************/
 #define SGC_UNKNOWN_STATE	-1
 #define SGC_OFF_STATE		0
 #define SGC_ON_STATE		1
 
#define MaxTempZones  (MAX_TEMP_ZONES_MASTER + MAX_TEMP_ZONES_SLAVE) 

typedef struct  _TempZones_
{
//private:

	UINT      		maxGroups;

	UINT		 	tempZoneCount;				// Zones start at 1 against a zero based array.
	UINT			highestActiveGroupNo;
	UINT		 	currentZone;
	UINT			startUpPowerPercentTPOcounts;
	UINT			heaterRiseRatePeriod10ths;
	UINT			minimumRiseDegrees;
	UINT			delayStartPeriod10ths; 		// The number of seconds that must
												// elapse after starting a new job
												// before monitoring
	UINT			elapsedStartPeriod;
	BOOL			timerOn;

	TempZone 	tempZone[MaxTempZones+1]; 	// use default constructor
	BOOL			nextGroup;
	BOOL			powerUpSequencingInProgress;
	BOOL			allZonesInDeadBand;
	BOOL			intermediateAllzonesInDb;
	BOOL			bNewSequenceStarted;
	
	enum OperationMode 	tempState;       	// the state of the temp zones
	DWORD		 	startUpGroup;            	// the current startup group 1 to 12
	UINT			secondBoardTimeout;
	short			m_iNumberZonesForDrawwarn;

	BOOL			waitingForTimer;
	DWORD			storedGroup;
	DWORD			maxTimeOut;
	short			m_sActiveZoneCount;
	DWORD			m_dwrdCooldownSetpoint;
	UINT			bZoneProcessed;
	BOOL			m_bRiseRateWarning;
	UINT			readDelay;
	int				m_iResequenceDelay;	
	DWORD			m_timeStartupCompleted;
	BOOL			m_bTimerStartupEventFired;
	BOOL			m_bAudibleAlarms_savedState;
	
	//Variables manage the Startup Group controlled relay output
	BOOL			m_bStartupGrpControlledOutputEnabled;
	DWORD			m_nStartupGrpControlledDO;
	BOOL			m_nStartupGrpControlledGroup;
	signed int		m_bStartupGrpControlledOutputValue;

	BOOL			m_bIOMapTaken;
	BOOL			m_bCheckIOErrors;
	BOOL			m_bIOErrorActive[2];
	int				m_ieePromError[2];
	int				m_iCrcError[2];
} TempZones;

void TempZones_setRiseRateWarning(TempZones* pTempZones, BOOL bRiseRateWarning);
UINT TempZones_riseRateWarning(TempZones* pTempZones);
void TempZones_init(TempZones* pTempZones);
void TempZones_configureTempZoneIO( TempZones* pTempZones );

void TempZones_resetZonesToResequence(TempZones* pTempZones);		
void TempZones_doPowerUpSequencing(TempZones* pTempZones);
void TempZones_CheckMaxPowerZones(TempZones* pTempZones);
void TempZones_GetMaxSequenceGroupNo(TempZones* pTempZones);
void TempZones_completePowerupSequencing(TempZones* pTempZones);
UINT TempZones_getNumberOfChannelsInGroup(TempZones* pTempZones, UINT uiGroup);
void TempZones_initializePowerUpSequencing(TempZones* pTempZones);
BOOL TempZones_setStartUpPowerPercent(TempZones* pTempZones, DWORD uStartUpPowerPercent ); 

void TempZones_completePowerupSequencingTimer(TempZones* pTempZones);

TempZone* TempZones_GetZone(TempZones* pTempZones, DWORD tzIndex);
BOOL TempZones_AllZonesSequencedBelowDraw(TempZones* pTempZones);
void TempZones_process(TempZones* pTempZones);						// calls subfunctions that do all processing
BOOL TempZones_setMaxSequenceGroups(TempZones* pTempZones, UINT uiSequenceGroups 	);
BOOL TempZones_setMaxTempZones(TempZones* pTempZones, UINT uiMaxTempZones		);
void TempZones_setDelayStartPeriod(TempZones* pTempZones, UINT uDelayStartPeriod	);		
void TempZones_setMinRiseDegreeCounts(TempZones* pTempZones, DWORD minRiseDegrees);
void TempZones_setRiseRatePeriod(TempZones* pTempZones, DWORD riseRatePeriodIn10ths );
BOOL TempZones_setOperationMode(TempZones* pTempZones, enum OperationMode mode);
BOOL TempZones_coolDownReachedAllZones		(TempZones* pTempZones);
enum OperationMode  	TempZones_getOperationMode	(TempZones* pTempZones);
BOOL TempZones_isAllZonesInDeadBand(TempZones* pTempZones);
BOOL TempZones_IsWarningConditionPresent(TempZones* pTempZones, short tempzoneNo);
void TempZones_ActivateZones(TempZones* pTempZones, short groupNum);
void TempZones_DeActivateZones(TempZones* pTempZones);
void TempZones_ResetStartupSequenceTimer(TempZones* pTempZones);
void TempZones_secondaryTPOtest(TempZones* pTempZones);
void TempZones_setSecondaryBoardDirection(TempZones* pTempZones, BOOL bDirect);
void TempZones_setTCWarnPercentage(TempZones* pTempZones, int wPercent);
void TempZones_enableDrawWarning(TempZones* pTempZones, BOOL bEnable);
SHORT TempZones_zonesAreInDeviationState(TempZones* pTempZones);
void TempZones_configureIO(TempZones* pTempZones, short ActiveZones);
void TempZones_setNumberDrawWarningZones(TempZones* pTempZones, short sZones);
void TempZones_setHiProcDelay(TempZones* pTempZones, int iDelay);
void TempZones_setGlobalHighProcess(TempZones* pTempZones, LONG lHP);
void TempZones_testCriticalPath(TempZones* pTempZones, int iTest);
void TempZones_setCooldownSP(TempZones* pTempZones, DWORD sp);
void TempZones_setCoolPeriod(TempZones* pTempZones, DWORD period);
void TempZones_cooling(TempZones* pTempZones);
void TempZones_coolingInCooldown(TempZones* pTempZones, DWORD on);
BOOL TempZones_useSecondaryBoard(TempZones* pTempZones);

void TEMPZONES_setSGCEnable( BOOL enable );
void TEMPZONES_setSGCOutput( DWORD digitalOutput );
void TEMPZONES_setSGCGroup( DWORD group );
void TempZones_setSGCOutputValue( signed int value );

void TempZones_enableTDMErrors(TempZones* pTempZones);
void TempZones_tdmTest(TempZones* pTempZones);

#endif

