/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			boards.cpp

	Description:	main define file 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#include "boards.h"
#include "belt.h"
#include "contain.h"
#include "timer.h"
#include "oven.h"
#include "utility.h"

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_init

			initialization routine for the board

 RETURNS:   void
------------------------------------------------------------------------*/
void Board_init(Board* pBoard)
{
	if(pBoard)
	{
		pBoard->bInUse = FALSE;
		pBoard->hasCarrier = FALSE;
		pBoard->boardLengthCounts = 0;
		pBoard->startPositionCounts = 0;
		pBoard->elapsedPositionCounts = 0;
	
		pBoard->bBoardDropped = FALSE;
	
		pBoard->bCooldown = FALSE;
	
		LocalTime_resetTime( &(pBoard->timeStamps.entryLeadingEdge) );
		LocalTime_resetTime( &(pBoard->timeStamps.entryTrailingEdge) );
		LocalTime_resetTime( &(pBoard->timeStamps.exitLeadingEdge) );
		LocalTime_resetTime( &(pBoard->timeStamps.exitTrailingEdge) );
	
		pBoard->timeStamps.bValidEntryLeading = FALSE;
		pBoard->timeStamps.bValidEntryTrailing = FALSE;
		pBoard->timeStamps.bValidExitLeading = FALSE;
		pBoard->timeStamps.bValidExitTrailing = FALSE;
	
		pBoard->timeStamps.bEntryEventAdded = FALSE;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_setStartPosition

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Board_setStartPosition(Board* pBoard, DWORD boardEntryCounts ) 
{ 
	PARAM_CHECK( pBoard, "Board_setStartPosition");
	pBoard->startPositionCounts = boardEntryCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_setLength

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Board_setLength(Board* pBoard,  DWORD bdLenCounts )
{
	PARAM_CHECK( pBoard, "Board_setLength");
	pBoard->boardLengthCounts = bdLenCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_getElapsedPositionCounts

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Board_getElapsedPositionCounts(Board* pBoard)
{
	PARAM_CHECK_RETURN( pBoard, "Board_getElapsedPositionCounts", FALSE);
	return pBoard->elapsedPositionCounts;		
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_TimeStampSetEntry

            Sets the entry side time stamps.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Board_TimeStampSetEntry( Board* pBoard, BOOL bLeading, LocalTime* pTimeStamp )
{
	if ( pBoard && pTimeStamp )
	{
		if ( bLeading )
		{
			pBoard->timeStamps.bValidEntryLeading = TRUE;
			LocalTime_copy( pTimeStamp, &(pBoard->timeStamps.entryLeadingEdge) );
		}
		else
		{
			pBoard->timeStamps.bValidEntryTrailing = TRUE;
			LocalTime_copy( pTimeStamp, &(pBoard->timeStamps.entryTrailingEdge) );
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_TimeStampSetExit

            Sets the exit side timestamps.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Board_TimeStampSetExit( Board* pBoard, BOOL bLeading, LocalTime* pTimeStamp )
{
	if ( pBoard && pTimeStamp )
	{
		if ( bLeading )
		{
			pBoard->timeStamps.bValidExitLeading = TRUE;
			LocalTime_copy( pTimeStamp, &(pBoard->timeStamps.exitLeadingEdge) );
		}
		else
		{
			pBoard->timeStamps.bValidExitTrailing = TRUE;
			LocalTime_copy( pTimeStamp, &(pBoard->timeStamps.exitTrailingEdge) );
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Board_Copy

            copies one board's data to another location

 RETURNS:   void
------------------------------------------------------------------------*/
void Board_Copy(Board* pDest, Board* pSource)
{
	if ( pDest && pSource )
	{
		pDest->bInUse = pSource->bInUse;
		pDest->hasCarrier = pSource->hasCarrier;

		pDest->boardLengthCounts = pSource->boardLengthCounts;
		pDest->startPositionCounts = pSource->startPositionCounts;
		pDest->elapsedPositionCounts = pSource->elapsedPositionCounts;

		pDest->bBoardDropped = pSource->bBoardDropped;

		pDest->bCooldown = pSource->bCooldown;

		LocalTime_copy( &(pSource->timeStamps.entryLeadingEdge),&(pDest->timeStamps.entryLeadingEdge) );
		LocalTime_copy( &(pSource->timeStamps.entryTrailingEdge),&(pDest->timeStamps.entryTrailingEdge) );
		LocalTime_copy( &(pSource->timeStamps.exitLeadingEdge),&(pDest->timeStamps.exitLeadingEdge) );
		LocalTime_copy( &(pSource->timeStamps.exitTrailingEdge),&(pDest->timeStamps.exitTrailingEdge) );

		pDest->timeStamps.bValidEntryLeading = pSource->timeStamps.bValidEntryLeading;
		pDest->timeStamps.bValidEntryTrailing = pSource->timeStamps.bValidEntryTrailing;
		pDest->timeStamps.bValidExitLeading = pSource->timeStamps.bValidExitLeading;
		pDest->timeStamps.bValidExitTrailing = pSource->timeStamps.bValidExitTrailing;

		pDest->timeStamps.bEntryEventAdded = pSource->timeStamps.bEntryEventAdded;
	}
	return;
}
