/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// pid.cpp
#include <stdlib.h>
#include "pid.h"


/******************************************************************************
 class PID_PID

 function: constructor

 Abstract:
 The pid algorithm is based on gains, error and error accumulation.
 Upon initialization all errors must be cleared.
 All numbers are long integer types with fixed points to one hundredth.

 programmer: Steven Young
 date: 03/12/1998
******************************************************************************/
void PID_init(PID* pPID,	LONG *usSetPoint, LONG *usProcVariable,
		 LONG* lTPOoutput, enum Action directReverse )
{
	pPID->sp			= usSetPoint;
	pPID->pv			= usProcVariable;
	pPID->iTerm		= 0;
	pPID->tpoOutput	= lTPOoutput;
	pPID->pb			= 250;
	pPID->ti			= 100000;
	pPID->td			= 0;
	pPID->PIDMode		= TRUE;
	pPID->sumErrors	= 0;
	pPID->outputAction = directReverse;
	pPID->m_bAdjustSumOfErrorsToSlowControl = 0;
}

//******************************************************************************
// PID_setMode
//
// Abstract:
// In order to allow the PID to function as an off type control the state 
// needs to be stored.
//
// Programmer: Steven Young
// Date: 06/01/1999
//
//******************************************************************************
void PID_setPIDMode(PID* pPID, BOOL pidModeEnabled )
{
	if( pidModeEnabled == TRUE )
	{
		if (pPID->PIDMode == FALSE) // A transition from on/off to PID control has occurred
		{
			pPID->PIDMode = pidModeEnabled;
		}
	}
	else
	{
		if( pPID->PIDMode == TRUE )
		{
			pPID->PIDMode = pidModeEnabled;
		}
	}
}
BOOL PID_getMode(PID* pPID)
{
	return pPID->PIDMode;
}
//******************************************************************************
// PID_setAction
//
// Abstract:
// To set the action of the PID calculation to be either directly proportional
// inversely proportional. Increasing the TPO output percent is directly
// proportional to raising temperature, whereas increasing TPO output percent
// on a cooling device would have a greater cooling effect or be inversely
// proportional. Setting the Action variable incorrectly will cause the device
// to work opposite of intended desires. For example to cool a zone would require
// less TPO percent output, with the Action flag set incorrectly cooling would
// cause the oven to get hotter until an alarm is triggered.
//
// Programmer: Steven Young
// Date: 04/13/1998
//
//******************************************************************************
void PID_setAction(PID* pPID, enum Action nAction )
{
	pPID->outputAction = nAction;
}

//******************************************************************************
// PID_setPb
//
//	Abstract:
//	Set the propotional band value. All proportional band settings must be less
//	than the maximum Propotional band.
//	Range 0 to 65535.
//
//
// Programmer: Steven Young
// Date: 05/31/1998
//******************************************************************************
void  PID_setPb(PID* pPID, DWORD proportionalBand )
{
	pPID->pb = proportionalBand;
	
}

void PID_reset(PID* pPID)
{
    pPID->sumErrors = 0;
}

//******************************************************************************
// PID_setTi
//
// Abstract:
// Change the integral reset time (seconds).
// The purpose of multiplying integralResetTimeSeconds by 1000 is:
// The update period of the HC1X controller is 1.3 seconds, since 
// floating point cannot be used the update time becomes 13 in tenths
// of seconds so integralResetTimeSeconds has to be multiplied by 10.
// Since the output is in terms of percent and we are multiplying by
// 256 or 100% tpo output, this must be converted by multiplying by 100,
// thus the 1000 factor.
//
//
// Programmer: Steven Young
// Date: 03/13/1998
//******************************************************************************
void PID_setTi(PID* pPID, DWORD integralResetTimeSeconds )
{
	if ( pPID->ti == 0 )
	{
		pPID->sumErrors = 0;
	}
	else 
	{
		pPID->sumErrors = (integralResetTimeSeconds * 100 * pPID->sumErrors)/pPID->ti;
	}
	pPID->ti = integralResetTimeSeconds * 100;	// convert to tenths of seconds	
}

//******************************************************************************
// PID_setTd
//
// Abstract:
// Change the gain of the derivative.
//
//
// Programmer: Steven Young
// Date: 05/31/1998
//******************************************************************************
void PID_setTd(PID* pPID, DWORD derivativeTime )
{
	pPID->td = derivativeTime * 10;			// convert to tenths of seconds
}

//******************************************************************************
// PID_calcPID
//
// Abstract:
// Calculate a percentage output to control a process. The parameters that are
// passed are primarily references to variables in the containing scope.
//
// pTerm = 100/Pb*error 
// Where Pb is the percentage of Pb Max and error is a percentage of Pb Max
// 
//
// Programmer: Steven Young
// Date: 03/12/1998
//******************************************************************************
void PID_calcPID(PID* pPID )
{
	LONG outputValue;
	LONG deltaError;
	LONG traceError;

	if ( pPID->lastSetPoint != *(pPID->sp) )
	{
		if ( *(pPID->sp) < pPID->lastSetPoint && pPID->lastSetPoint!=0)
		{
			pPID->sumErrors = (*(pPID->sp) * pPID->sumErrors)/pPID->lastSetPoint;
		}
		pPID->lastSetPoint = *(pPID->sp);
	}

	if ( pPID->outputAction == Direct )
	{
		pPID->error = *(pPID->pv) - *(pPID->sp);
		traceError = pPID->error;
	}
	else
	{
		pPID->error = *(pPID->sp) - *(pPID->pv);
		traceError = pPID->error;
	}

	if (pPID->PIDMode == FALSE )
	{
		if ( pPID->error > 0 )
		{
			*(pPID->tpoOutput) = MAX_TPO_COUNTS;
		}
		else
		{
			*(pPID->tpoOutput) = 0;
		}
	}
	else
	{
		if ( !pPID->error || pPID->pb == 0 )
		{
			pPID->pTerm = 0;
		}
		else
		{

			pPID->pTerm = (pPID->error * 256)/pPID->pb;
			if ( pPID->pTerm > 256 )
			{
				pPID->pTerm = 256;
			}
			else 
			{
				if ( pPID->pTerm < -256 )
				{
					pPID->pTerm = -256;
				}
			}
		}

		pPID->dt = 10;	// update this value every 1 second in tenths. 
					// if the scan time or number of scans before the next
					// process calculation changes then this value must change.
					// currently 8/26/98 - Tyler's Birthday, the value is
					// set to the following: 
					// 100 ms scan time and process every 10 scans for 1 second.
					// converted to tenths = 10.

		if ( (pPID->ti == 0) || (abs(pPID->pTerm) == 256) )
		{
			pPID->iTerm = 0;
			pPID->sumErrors = 0;
		}
		else 
		{
			// A properly tuned heater zone will set the pb value so that the 
			// temperature falls below the setpoint without oscillating around,
			// in other words the pb is to small effectively increasing the gain.
			// Assuming this assertion is always correct then the ITERM must always
			// be positive, therefor the sum of the errors must always be 0 or 
			// greater. 
			pPID->sumErrors += pPID->error;

			if ( pPID->sumErrors < 0 )
			{
				pPID->sumErrors = 0;
			}
		
			pPID->iTerm = (pPID->sumErrors * pPID->dt*256)/pPID->ti;
	
			if ( pPID->iTerm  > 256 )
			{
				pPID->iTerm = 256;
				pPID->sumErrors = ((pPID->iTerm * pPID->ti)/pPID->dt)/256;	// now calculate the error
			}
		}


		deltaError = pPID->error - pPID->lastError;
		pPID->dTerm = ((pPID->td * deltaError*256)/pPID->dt)/100;			// dt can never be 0
		pPID->lastError = pPID->error;

		outputValue = pPID->pTerm + pPID->iTerm + pPID->dTerm;
//		printk("outputValue = %d\nprocessVar = %d\nsetpoint = %d\n",
//				outputValue, *(pPID->pv), *(pPID->sp));

		if ( outputValue > 256 )
		{
			outputValue = MAX_TPO_COUNTS;
		}
		else
		{
			if( outputValue < 0 )
			{
				outputValue = 0;
			}
		}
	
		*(pPID->tpoOutput) = outputValue; 
	}
}



//******************************************************************************
// PID_calcBeltPID
//
// Abstract:
// Calculate a percentage output to control a process. The parameters that are
// passed are primarily references to variables in the containing scope.
//
// pTerm = 100/Pb*error 
// Where Pb is the percentage of Pb Max and error is a percentage of Pb Max
// 
//
// Programmer: Steven Young
// Date: 03/12/1998
//******************************************************************************
void PID_calcBeltPID(PID* pPID, UINT enterDT )
{
	LONG outputValue = 0;
	LONG deltaError = 0;

//adjust sum of errors when moving from 1/10 second control to 1 second
	if(pPID->m_bAdjustSumOfErrorsToSlowControl)
	{
		pPID->sumErrors = pPID->sumErrors / 10;
		pPID->m_bAdjustSumOfErrorsToSlowControl = FALSE;
	}

	if ( pPID->lastSetPoint != *(pPID->sp) )
	{
		if ( *(pPID->sp) < pPID->lastSetPoint &&	pPID->lastSetPoint!=0)
		{
			pPID->sumErrors = (*(pPID->sp) * pPID->sumErrors)/pPID->lastSetPoint;
		}
		pPID->lastSetPoint = *(pPID->sp);
	}
	if ( pPID->outputAction == Direct )
	{
		pPID->error = *(pPID->pv) - *(pPID->sp);
	}
	else
	{
		pPID->error = *(pPID->sp) - *(pPID->pv);
	}

	if (pPID->PIDMode == FALSE )
	{
		if ( pPID->error > 0 )
		{
			*(pPID->tpoOutput) = 256;
		}
		else
		{
			*(pPID->tpoOutput) = 0;
		}
	}
	else
	{
		if ( !pPID->error || pPID->pb == 0 )
		{
			pPID->pTerm = 0;
		}
		else
		{

			pPID->pTerm = (pPID->error * 256)/pPID->pb;
			if ( pPID->pTerm >= 256 )
			{
				pPID->pTerm = MAX_TPO_COUNTS;
			}
			else 
			{
				if ( pPID->pTerm <= -256 )
				{
					pPID->pTerm = -256;
				}
			}
		}

		pPID->dt = (USHORT)enterDT; // if the scan time or number of scans before the next
					  // process calculation changes then this value must change.
					  // currently 8/26/98 - Tyler's Birthday, the value is
					  // set to the following: 
					  // 100 ms scan time and process every 10 scans for 1 second.
					  // converted to tenths = 10.

		if ( (pPID->ti == 0) || (abs(pPID->pTerm) == 256) )
		{
			pPID->iTerm = 0;
			pPID->sumErrors = 0;
		}
		else 
		{
			// A properly tuned heater zone will set the pb value so that the 
			// temperature falls below the setpoint without oscillating around,
			// in other words the pb is to small effectively increasing the gain.
			// Assuming this assertion is always correct then the ITERM must always
			// be positive, therefor the sum of the errors must always be 0 or 
			// greater. 
			
			pPID->sumErrors += pPID->error;

			
			if ( pPID->sumErrors < 0 )
			{
				pPID->sumErrors = 0;
			}

			pPID->iTerm = (pPID->sumErrors * pPID->dt*256/pPID->ti);
	
			if ( pPID->iTerm  > 256 )
			{
				pPID->iTerm = 256;
				pPID->sumErrors = ((pPID->iTerm * pPID->ti)/pPID->dt)/256;	// now calculate the error
			}
		}

		deltaError = pPID->error - pPID->lastError;
		pPID->dTerm = ((pPID->td * deltaError*256)/pPID->dt)/100;			// dt can never be 0
		pPID->lastError = pPID->error;

		outputValue = pPID->pTerm + pPID->iTerm + pPID->dTerm;

		if ( outputValue >= 256 )
		{
			outputValue = MAX_TPO_COUNTS;
		}
		else
		{
			if( outputValue < 0 )
			{
				outputValue = 0;
			}
		}
	
		*(pPID->tpoOutput) = outputValue; 
	}
}

//This function sets a boolean that will instruct the calcbeltpid loop to reduce the sum
// of errors by /10 to adjust from 1/10 second control to 1 second control
void PID_reduceSumOfErrorsByFactor10(PID* pPID)
{
	pPID->m_bAdjustSumOfErrorsToSlowControl = TRUE;
}

DWORD  PID_getPb	(PID* pid) 	
{ 
	return pid->pb;		
}

DWORD  PID_getTi	(PID* pid) 	
{
	return pid->ti/100;	
}

DWORD  PID_getTd	(PID* pid) 	
{
	return pid->td/10;	
}

LONG   PID_getPterm (PID* pid)	
{
	return pid->pTerm;		
}

LONG   PID_getIterm (PID* pid)	
{
	return pid->iTerm;		
}

LONG   PID_getDterm	(PID* pid)	
{
	return pid->dTerm;		
} 

enum Action PID_getAction(PID* pid) 
{
	return pid->outputAction; 
}
