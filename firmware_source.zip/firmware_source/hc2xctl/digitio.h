/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//digitio.H
#ifndef __DIGITIO_H__
#define __DIGITIO_H__

#include "typedefdefine.h"
#define IOHISTLENGTH 400

#define MaxDin  MAX_DIGITAL_INPUTS
#define MaxDout MAX_DIGITAL_OUTPUTS
#define MaxAnalogIn  MAX_ANALOG_INPUTS
#define MaxAnalogOut MAX_ANALOG_OUTPUTS


//******************************************************************************
// 									DIN
//******************************************************************************
typedef struct _DIN_
{
	BOOL dinputs[MaxDin];
	BOOL dummy;   			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	UCHAR inBuffer[IOHISTLENGTH];//8 characters, 50 long, 5 seconds worth
	UINT iBuffPoint;
	int iTest;
} DIN;

UCHAR DIN_BufferGet(DIN* pDin, UINT index);
UINT DIN_GetBuffPoint(DIN* pDin);
void DIN_init(DIN* pDin);
BOOL* DIN_GetAt(DIN* pDin, unsigned int);
void DIN_process(DIN* pDin);


//******************************************************************************
// 									DOUT
//******************************************************************************
typedef struct _DOUT_
{
	
	BOOL doutputs[(MaxDout * 2)];
	UCHAR dOutBits[7];   	// The 56 Digital outputs are represented in 7 bytes.
	BOOL dummy;   			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	BOOL bUpdated;
} DOUT;

void DOUT_init(DOUT* pDout);
BOOL* DOUT_GetAt(DOUT* pDout, unsigned int);
void DOUT_getOutputArray(DOUT* pDout, UCHAR **ppDigitalOut, UCHAR *pSize );
void DOUT_process(DOUT* pDout);
void DOUT_process_local_output();
BOOL* DOUT_getIODriverOutput(UINT index);

//******************************************************************************
// 									ANALOGIN
//******************************************************************************
typedef struct _ANALOGIN_
{

	WORD	 analogInputs[MaxAnalogIn*2];  //Double set for serial controlled board
	WORD	 secondaryAnalogInput[MaxAnalogIn*2]; //set for secondary board plus its serial slave

	//Adjustment for profile channels with plug in
	WORD	 profileOffset; 
	WORD	 dummy;			// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.
	int recordOffsets;
	int startOffsetProgramming;

	WORD offsets[MaxAnalogIn];
	int inputStyles[MaxAnalogIn];
	int recordInputStyles[MaxAnalogIn];
	int iSlaveDataTimeout;
	int m_bAlarmed;
	int miAlarmScanner;
} ANALOGIN;

void ANALOGIN_init(ANALOGIN* pAin);
WORD* ANALOGIN_GetAt(ANALOGIN* pAin, unsigned int);
WORD* ANALOGIN_GetAtHigh(ANALOGIN* p, unsigned int index);
void ANALOGIN_setProfileOffset(ANALOGIN* pIn, WORD newProfileOffset);
WORD ANALOGIN_ReadProfileOffset(ANALOGIN* pIn);
void ANALOGIN_process(ANALOGIN* pIn);
WORD ANALOGIN_GetOffsetAt(UINT index);
BOOL ANALOGIN_SetOffsetAt(UINT index, WORD offsetValue);		
DWORD ANALOGIN_GetInputStyleAt(UINT index);
BOOL ANALOGIN_SetInputStyleAt(UINT index, UINT iType);
void ANALOGIN_PopulateSecondaryOffsets(ANALOGIN* pIn);
WORD ANALOGIN_GetOffsetFromSecondBoard(ANALOGIN* pIn, UINT index);
//******************************************************************************
// 									ANALOGOUT
//******************************************************************************
typedef struct _ANALOGOUT_
{

	WORD analogOutputs[(MaxAnalogOut * 2)];
	WORD dummy;				// The dummy value is used in the event reading past
							// the end of the array index is attempted. Although
							// there may be an attempt to change this value, it
							// is obvious there is some error occurring and a change
							// to the actual inputs is not allowed.

	BOOL m_bOwned[(MaxAnalogOut * 2)]; //for shared outputs(second fluxheater
	BOOL bUpdated;
} ANALOGOUT;

void ANALOGOUT_init(ANALOGOUT* pAout);
WORD* ANALOGOUT_GetAt(ANALOGOUT* pAOut, unsigned int);
void ANALOGOUT_process(ANALOGOUT* pAout);
void ANALOGOUT_set(ANALOGOUT* pAout, UINT index, WORD wValue);
void ANALOGOUT_setIODriverAnalogout(UINT index, WORD wValue);
WORD ANALOGOUT_get(ANALOGOUT* pAout, UINT index);
void ANALOGOUT_testMPath(UINT iPath, int iTest);
void ANALOGOUT_setOwned(ANALOGOUT * pAout, UINT iIndex);
void ANALOGOUT_setFree(ANALOGOUT * pAout, UINT iIndex);
UINT ANALOGIN_indexToSecondaryIndex(UINT index);
UINT ANALOGOUT_indexToSecondaryIndex(UINT index);

#endif
