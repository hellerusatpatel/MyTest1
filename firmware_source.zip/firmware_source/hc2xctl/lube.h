/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//LUBE
#ifndef __LUBE_H__
#define __LUBE_H__

#include "typedefdefine.h"

//******************************************************************************
// class Lube
//
// Abstract:
//
// After calculating the distance the belt has traveled compare to the distance
// traveled between lubes. If the distance is greater than or equal to then
// start a lube cycle. In the event an estop is pressed while a lube cycle is
// in progress kill the solenoid power and terminate the lube cycle.
//
// All belt positions are in absolute values of the counts. The counts
// will reset at 2^32. Belt distance at max speed = 188cm/min = 2400pulses/min
// Typical time between lubes used to be 1 hour = 144000pulses/hr. Rollover
// will occur every 30,000 hours. Should be just enough.
//
// Programmer: Steven Young
// Date: 04/13/1998
//
//******************************************************************************
typedef struct _Lube_
{
//private:

	DWORD			lubeIntervalTime;			// distance belt travels between lubes in pulses
	DWORD			lastCheckTime;
	DWORD			elapsedTime;
	DWORD			lubeDuration10ths;			// gravity feed lube system.
	DWORD			startTime;
	DWORD			currentTime;
	BOOL			optionEnabled;
	BOOL 			lubeInProgress;
	unsigned int    lubeIdNo;
} Lube;

void Lube_init(Lube* pLube, unsigned int idNo);

void	Lube_optionEnable(Lube* pLube, BOOL enable);
void	Lube_process(Lube* pLube);
void	Lube_setLubeIntervalTime(Lube* pLube, DWORD lubeIntervalTimeValue );
void	Lube_setLubeDurationTime(Lube* pLube, DWORD lubeDurationTime10thsOfSec );
DWORD	Lube_getLubeIntervalTime(Lube* pLube);
DWORD	Lube_getLubeDurationTime(Lube* pLube);
void	Lube_setElapsedTime10ths(Lube* pLube, DWORD savedCounts );
DWORD	Lube_getElapsedTime10ths(Lube* pLube);

#endif
