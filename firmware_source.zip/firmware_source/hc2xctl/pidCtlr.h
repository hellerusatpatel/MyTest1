/*******************************************************************************
Heller industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential

 	File:			pidCtlr.h

	Description:	pid master, moved to tempzones
                                                                                                                 
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __PIDZ_H__
#define __PIDZ_H__
                                                                                                                  
#include "typedefdefine.h"
#include "hellerenumerations.h"
#include "pid.h"

#define NULL_OUTPUT_POINTER 0xff
typedef struct _PIDController_
{
 	BOOL	m_bOff;	
	BOOL 		pidEnabled;  	// Auto or Manual mode - PID's active or not.
	enum ZoneTriState		zoneAuto;
	BOOL		bZoneActive;  	// Has the zone been turned off by operator.
	DWORD 	zoneNo;			// A value defining the zone id
	DWORD  	groupNo;      	// which group does this zone belong to
	LONG 		sp;	 			// setpoint
	LONG		coolSP;
	LONG		coolSPOffset;
	LONG 		pv;	        	// process variable
	
	WORD		*pTcInput;		// a pointer to the value in the io tables.
	int		m_nTcInput;
	DWORD		dwrdOurOutput;
	WORD		*pTPOoutput;  	// a pointer to the TPO output table.
	int		m_nTPOoutput;
	
	LONG		tpoOutput;
	LONG		tpoOutputCooling;

	DWORD		previousJobNo;
	DWORD		currentTooth;
	PID		pid;
	PID		coolPID;
	
	UINT		printkDelay;
	
	BOOL		bLocalZone;	// TRUE if local temp zone, FALSE if remote
	
	// in the event of trying to access the wrong zone
	// this will help to prevent a null pointer error.	
	WORD		dummyValue;
	BOOL		m_bSuspended;
	BOOL		m_bSetpointSendFailed;
	UINT 		bRetry;

	BOOL				htAlarmEnable;
	BOOL 				ltAlarmEnable;
	BOOL 				htWarnEnable;
	BOOL				ltWarnEnable;
	
	DWORD				dwrdTPOWithoutPID;
	BOOL				bTPOTimeStampTaken;
	BOOL				bTPOOffDueToLackOfPID;	

	LONG 				globalhp;

	BOOL 				alarmBandsEnabled;	// The pv is within deadband.
	BOOL				m_bDoRiseRateCheck;

	// Alarms and Warnings values
	BOOL				inDeadBand;

	DWORD  		currentTime;   		// for calculatin the elapsed time  - in milliseconds.

	//boolean to lock out process loop until group delay period has elapsed
	BOOL				m_bPowerUpDelayElapsed;


	///////////

	LONG 				highProcess;			// The absolute high temp alarm
	LONG 				lowProcess;    			// The absoluter low temp alarm
	BOOL 				loProcAlarmEnable;	//	if alarm is not active do not process.
	BOOL 				hiProcAlarmEnable;	// default to TRUE for all actives
	DWORD 				alarmHighTempOffset;    // setpoint + = high deviation alarm
	DWORD 				alarmLowTempOffset;     // setpoint - = low deviation alarm
	DWORD  				warnHighTempOffset;		// setpoint + = high deviation warning
	DWORD 				warnLowTempOffset;      // setpoint - = low deviation warning
	DWORD 				deadBandHighTempOffset; // setpoint + = high dboffset should be within warnings and alarms
	DWORD 				deadBandLowTempOffset;	// setpoint - = high dboffset should be within warnings and alarms

	//////////////

	DWORD				selfAckAlarmNo;			// the self acknowledging alarm number for warnings.

	DWORD				m_dwrdHiProcDelay;
	BOOL				m_bHiProcCountdownOn;
	DWORD				m_dwrdHiProcBeginTime;
	BOOL				m_bInternalTestForDrawWarning;
	BOOL				deadBandEnableStatus;
	BOOL				m_bOpenThermocouple;
	DWORD 				saFromSlave;

	BOOL				zoneInactiveToActiveTransition; 

	BOOL				riseRateSetPointChange;
	DWORD				riseRateDelayStartTime;	// the time the rise rate period on a job change. 
	LONG 				coolOutput;
	DWORD				period;
	DWORD				mDwrdOutput;
	DWORD				mCoolingOutputPercentX100;
	DWORD				mCoolingOnInCooldown;
	DWORD				coolOnOff;
	BOOL				mbSequence;

} PIDController;

void PIDController_suspendSecondaryWrite(PIDController* pidControl, BOOL bSuspend);

void PIDController_init(PIDController* pidControl, int zoneNo, BOOL bLocalZone);

void PIDController_configureSlaveIO(PIDController* pPID);
void PIDController_pidSetTdCool(PIDController* pidControl, DWORD dwTd);
void PIDController_pidSetTiCool(PIDController* pidControl, DWORD dwTi);
void PIDController_pidSetPbCool(PIDController* pidControl, DWORD proportionalBand);
void PIDController_setInternalTestForDrawWarning(PIDController* pidControl, BOOL bSetTo);


void PIDController_setPidEnable(PIDController* pidControl, BOOL bEnable);
void PIDController_setActive(PIDController* pidControl, BOOL bActive);
void PIDController_setZoneMode(PIDController* pPID, enum ZoneTriState mode);
void PIDController_setAction(PIDController* pPID, enum Action iAction);
void PIDController_setGroupNo(PIDController* pPID, int nGroupNo);
void PIDController_setSP(PIDController* pPID, LONG nSP);
void PIDController_setCoolSPOffset(PIDController* pPID, LONG nSP);
void PIDController_setCoolOnOff(PIDController* pPID, DWORD nOff);
void PIDController_CooldownSequenced(PIDController* pPID, DWORD nOff);

void PIDController_setPV(PIDController* pPID, LONG nPV);
void PIDController_setPVSecondary(PIDController* pPID, LONG nPV);
void PIDController_setTpo(PIDController* pPID, DWORD tpoOut);
void PIDController_setPreviousJob(PIDController* pPID, DWORD job);
void PIDController_setDeadBandState(PIDController* pidControl, BOOL dbState ) ;
void PIDController_setAlarmsEnabled(PIDController* pidControl, BOOL state );
void PIDController_setRiseRateCheck(PIDController* pidControl, BOOL state );
void PIDController_setPowerUpComplete(PIDController* pidControl, BOOL bSetTo );

BOOL PIDController_setHiProcTemp(PIDController* pidControl, DWORD newHighProcess );
BOOL PIDController_setLoProcTemp(PIDController* pidControl, DWORD newLowProcess );
void PIDController_enableHiProcAlarm(PIDController* pidControl, BOOL enable );
void PIDController_enableLoProcAlarm(PIDController* pidControl, BOOL enable );       
BOOL PIDController_setAlarmHiTempOffset(PIDController* pidControl, DWORD newAlarmHighTempOffset);
BOOL PIDController_setAlarmLoTempOffset(PIDController* pidControl, DWORD newAlarmLowTempOffset);
BOOL PIDController_setWarnHiTempOffset(PIDController* pidControl, DWORD newWarnHighTempOffset);
BOOL PIDController_setWarnLoTempOffset(PIDController* pidControl, DWORD newWarnLowTempOffset);
BOOL PIDController_setDeadBandHiTempOffset(PIDController* pidControl, DWORD newDeadBandHighTempOffset);
BOOL PIDController_setDeadBandLoTempOffset(PIDController* pidControl, DWORD newDeadBandLowTempOffset);

void PIDController_setHiProcDelay(PIDController* pidControl, int iDelay);
void PIDController_setHiProcCountdownOn(PIDController* pidControl, BOOL bSetTo);

void PIDController_enableDeadBandRangeCheck(PIDController* pidControl, BOOL dbFlag /*= TRUE*/ );
BOOL PIDController_isInDeadBandRangeCheckEnabled(PIDController* pidControl);

char PIDController_updatePV(PIDController* pPID); // returns 1 on success, 0 on failure

void PIDController_writeTpo(PIDController* pPID, WORD tpoOut);
void PIDController_writeCalculatedTpo(PIDController* pPID);
void PIDController_writeTpoSecondary(PIDController* pPID, WORD tpoOut);

DWORD PIDController_getPV(PIDController* pPID);
DWORD PIDController_getTPO(PIDController* pPID);
void PIDController_TPOToDigitalTime(PIDController* pPID);
void PIDController_calcPid(PIDController* pPID);
void PIDController_setStartState(PIDController* pPID, BOOL bOn);

void PIDController_pidSetPb(PIDController* pidControl, DWORD propotionalBand);
void PIDController_pidSetTi(PIDController* pidControl, DWORD dwTi);
void PIDController_pidSetTd(PIDController* pidControl, DWORD uTd);
void PIDController_pidSetAction(PIDController* pidControl, enum Action pidResponseAction);
void PIDController_pidSetMode(PIDController* pidControl, BOOL bModeEnabled);

void PIDController_AddSafeSegment(PIDController* pPID, unsigned int channel, unsigned int weight);

void PIDController_configureIO(PIDController* pPID, UINT ai, UINT tpo);
int PIDController_getClearLocal( PIDController* pidControl);
void PIDController_cooling(PIDController* pPID);

void PIDController_enableHiDeviationAlarm(PIDController* pidControl, BOOL enable );
void PIDController_enableLoDeviationAlarm(PIDController* pidControl, BOOL enable );
void PIDController_enableHiDeviationWarn(PIDController* pidControl, BOOL enable );
void PIDController_enableLoDeviationWarn(PIDController* pidControl, BOOL enable );
void PIDController_timeoutOutput(PIDController* pidControl);
void PIDCOntroller_clearTimeout(PIDController* pidControl);

void PIDController_setGlobalHighProcess(PIDController* pidControl, LONG newHP);
int PIDController_checkGlobalHighProcess(PIDController* pidControl);

BOOL PIDController_checkRiseRate(PIDController* pidControl);//	If temperature rise rate not achieved set alarm

void PIDController_checkAlarmBands(PIDController* pidControl);

void PIDController_checkSelfAcknowledgeAlarms(PIDController* pidControl);
DWORD PIDController_getSelfAckAlarmNo( PIDController* pidControl);

DWORD PIDController_getAbsoluteTempZoneNumber(PIDController* pidControl);
DWORD PIDController_getRelativeTempZoneNumber(PIDController* pidControl);

void PIDController_setIO(PIDController* pidControl, DWORD in, DWORD out);
void PIDController_setCoolOutput(PIDController* pidControl, DWORD output);
void PIDController_setCoolPeriod(PIDController* pidControl, DWORD period);
void PIDController_coolingInCooldown(PIDController* pPID, DWORD on);
BOOL PIDController_canWriteTPO( PIDController* pidControl );

int PIDController_getSecondBoardIndex(PIDController* pidControl);

#endif
  
