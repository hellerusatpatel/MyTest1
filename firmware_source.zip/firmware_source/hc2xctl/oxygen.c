/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "oxygen.h"
#include "digitio.h"

extern DbContainer g_dbContainer;

ANALOGIN* analogInputs;

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	Oxygen_init

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void Oxygen_init(Oxygen* pOxygen)
{
	PARAM_CHECK( pOxygen, "Oxygen_init");
	pOxygen->oxygenInputVoltage = 32768;				 // for lack of a better choice set to max
	pOxygen->enabled = FALSE;

	analogInputs = &( g_dbContainer.analogInDb );
}


LONG Oxygen_getOxygenVolts(Oxygen* pOxygen)
{
	PARAM_CHECK_RETURN( pOxygen, "Oxygen_getOxygenVolts", 0);
	return pOxygen->oxygenInputVoltage;
}

void Oxygen_process(Oxygen* pOxygen)
{
	PARAM_CHECK( pOxygen, "Oxygen_process");
	if ( pOxygen->enabled == TRUE )
	{
		pOxygen->oxygenInputVoltage = *ANALOGIN_GetAt(analogInputs, AI_FREE_L2SR);
	}
}

void Oxygen_setEnabled(Oxygen* pOxygen, BOOL enableState )
{
	PARAM_CHECK( pOxygen, "Oxygen_setEnabled");
	pOxygen->enabled = enableState;
}


