/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// boardque.h
#ifndef __BOARDQUEUE_H__
#define __BOARDQUEUE_H__

#include "boards.h"
#include "typedefdefine.h"
#include "alarm.h"
#include "digitio.h"
#include "belt.h"				// needed for forward referencing.
#include "timer.h"
#include "oven.h"
#include "contain.h"	// using include files causes circular include problems
						// due to the interrelationship between the modules.

typedef struct _BoardQueue_
{
//public:
	static		UINT boardQIdIndex;
	char name[MaxNameLength+1];
	AlarmQueue	*alarmQueueDb;
	DIN			*digitalInDb;
	Timer		*elapseTimer;
	Oven		*ovenDb;
	UINT		boardQId;
	Belts		*pBelts;			// pointer to the belt container.
	Belt		*pBeltIOTied;		// pointer to the parent belt.

//private:
	const BOOL	*pBoardEnteringOven;
	const BOOL	*pBoardLeavingOven;
	BOOL		boardQueueActive;
	DWORD		boardDeadbandCounts;
	DWORD		distanceBetweenSensorsCounts;
	DWORD		currentBeltPosition;
//		Board*		boards[MaxBoards];
	Board		boards[MaxBoards];
//		DWORD		boardsInOven;
	DWORD		boardsProcessed;
	DWORD		lastBoardDetectPosition;
	DWORD		lengthInCounts;
	UINT		headIndex;
	UINT		tailIndex;
	//UINT		prevHeadIndex;		// used to detect when a board has left the oven so as not to count holes.
	DWORD		boardCount;

	BOOL		timedBoarddropEnabled;
	BOOL		boardsInOvenEnabled;
	BOOL		boardsProcessedEnabled;
	BOOL		boardDetectIn;
	BOOL		boardDetectOut;
	BOOL		boardInputValid;
	BOOL		previousBoardDetectState;
	DWORD		startBoardInDetectTime;
	DWORD		expectLowInputAfterCounts;
	UINT		filterCount;
	UINT		filterCount2;
	UINT		filterCount3;
	BOOL		boardOutputValid;
	BOOL		boardBackUpState;
	BOOL		previousBoardOutDetectState;
	DWORD		startBoardOutDetectTime;
	DWORD		boardBackUpTime;
	BOOL		lowHasOccurred;
    BOOL        updateComplete;
	BoardData   boardData;
	BOOL		m_bBoardOnEntrySensor;
	BOOL		m_bEnableBoardStop;
//public:
	int notifyBoard;
	int notifyBoardOut;
	
		
} BoardQueue;

void BoardQueue_init( BoardQueue* pBoardq, const char *szName="" );

BOOL		BoardQueue_ioConfig( UINT activeBelts );
BOOL		BoardQueue_bdConfig( DWORD boardDropConfig );
BOOL		BoardQueue_bpConfig( DWORD boardsProcessedConfig );
BOOL		BoardQueue_boConfig( DWORD boardsInOvenConfig );
void		BoardQueue_checkForBoardEntering(void);
void		BoardQueue_checkForBoardDrop(void);
void		BoardQueue_checkForBoardLeaving(void);
void		BoardQueue_checkForBoardBackup();
void		BoardQueue_hasLowOccurred( void );
BOOL		BoardQueue_addBoard(void);
void		BoardQueue_removeBoard(void);
void		BoardQueue_setLength(void);
void		BoardQueue_newBoard( DWORD beltPositionInCounts );
void		BoardQueue_updateBoardPositions(void);
void		BoardQueue_setQueuePtrs(AlarmQueue *a);

BOOL		BoardQueue_configure( DWORD boardDropConfig, DWORD boardsProcessedConfig, DWORD boardsInOvenConfig );
DWORD		BoardQueue_getBoardsInOvenCount(void);
DWORD		BoardQueue_getBoardsProcessed	(void);
BOOL		BoardQueue_isPastDeadBand		(void);
void		BoardQueue_setBoardsProcessed	( DWORD noOfBoardsProcessed ){ boardsProcessed = noOfBoardsProcessed;}	
void		BoardQueue_clearBoardsProcessed(void){ boardsProcessed = 0;	}
DWORD		BoardQueue_getMaxBoards		(void)	{ return MaxBoards;		}
void		BoardQueue_process				(void);
const char* BoardQueue_getName				(void)	{ return name.getName();	}
void		BoardQueue_clearBoardsInOven	(void);
void		BoardQueue_setSensorDistance	( DWORD distanceBetweenSensorsInCounts );
DWORD		BoardQueue_getSensorDistance	( void ) { return distanceBetweenSensorsCounts; }
void		BoardQueue_setBoardDeadBandDistance ( DWORD boardDeadBandInCounts );
void 		BoardQueue_enableBoardStop(BOOL enableState);
const BoardData*  BoardQueue_getBoardAnimationData( void );

#endif
