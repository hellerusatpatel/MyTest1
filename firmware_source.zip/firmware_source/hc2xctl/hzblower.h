/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __HEAT_ZONE_BLOWERS_H__
#define __HEAT_ZONE_BLOWERS_H__

#include "typedefdefine.h"
//for flush 2 reporting
#define GROUP_A 0x01
#define GROUP_B 0x02
#define GROUP_C 0x04
#define GROUP_D 0x08
#define GROUP_E 0x010
//******************************************************************************
// Class:HeatZoneBlowers
//
// Abstract:
// To allow the capability to change the blower settings for the heat zones 
// within the oven. To replace the manually set potentiometers with a software
// settable option. 
//  	
// 
// During Cooldown the blower value will not change.
//
//	Programmer: Steven Young
//	Date: 07/12/1999
//******************************************************************************

enum { MAX_HEAT_ZONE_BLOWERS = 4 };//the 4th hz blower is a phantom, only used to write standby
//control messages/ timers when no blowers are present
// 80% is the maximum current draw. 
enum { MIN_OUT_PERCENTAGE=0, MAX_OUT_PERCENTAGE=100 };

typedef struct _HeatZoneBlowers_
{
//private:
	unsigned int    TPOBlowerPercent[MAX_HEAT_ZONE_BLOWERS];
	BOOL			enabled[MAX_HEAT_ZONE_BLOWERS];		
	UINT			LowSetting[MAX_HEAT_ZONE_BLOWERS];
	UINT			MediumSetting[MAX_HEAT_ZONE_BLOWERS];
	UINT			HighSetting[MAX_HEAT_ZONE_BLOWERS];
	DWORD			flushTime;
	UINT			jobNo;
	DWORD			startTime;
	UINT			controlType[MAX_HEAT_ZONE_BLOWERS];
	UINT			ieRequestLevel[MAX_SMEMA_LANES];
	UINT			lastStepTime[MAX_HEAT_ZONE_BLOWERS];
	UINT			runLevel[MAX_HEAT_ZONE_BLOWERS];
	DWORD			standbyTime[MAX_HEAT_ZONE_BLOWERS];
	BOOL 			m_bInStandby[MAX_HEAT_ZONE_BLOWERS];
	BOOL			bInStartupMode;
	BOOL 			b0100[MAX_HEAT_ZONE_BLOWERS];
	DWORD			minimum[MAX_HEAT_ZONE_BLOWERS];
	DWORD			m_dwrdMaximum[MAX_HEAT_ZONE_BLOWERS];
	DWORD			currentIELevel[MAX_HEAT_ZONE_BLOWERS];
	DWORD			startupAlg;
	DWORD			ssTime;
	BOOL 			bFlush2;
	BOOL			m_bOutOfRangeHigh[MAX_BLOWERS_INCLUDING_FANS];
	BOOL			m_bOutOfRangeLo[MAX_BLOWERS_INCLUDING_FANS];
	BOOL			m_bFlush;
	UINT			m_uintAutoClean;
	unsigned char	m_charBounded[MAX_BLOWERS_INCLUDING_FANS];
} HeatZoneBlowers;

void HeatZoneBlowers_init(HeatZoneBlowers* pHeatZoneBlowers );
void HeatZoneBlower_StandbyResetForSequencing(HeatZoneBlowers* pHeatZoneBlowers);
void HeatZoneBlowers_process( HeatZoneBlowers* pHeatZoneBlowers );
unsigned int HeatZoneBlowers_getOutputPercent(HeatZoneBlowers* pHeatZoneBlowers, unsigned int ZoneNo );
void HeatZoneBlowers_setEnable(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, BOOL enable /*= TRUE*/ );
BOOL HeatZoneBlowers_getIfHZBlowerIsEnabled(HeatZoneBlowers* pHeatZoneBlowers, int blowerID);
void HeatZoneBlowers_setLowSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting);
void HeatZoneBlowers_setMediumSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting);
void HeatZoneBlowers_setHighSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting);
UINT HeatZoneBlowers_getLowSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID);
UINT HeatZoneBlowers_getMediumSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID);
UINT HeatZoneBlowers_getHighSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID);
void HeatZoneBlowers_setFlushTime(HeatZoneBlowers* pHeatZoneBlowers, DWORD flshTime);	
void HeatZoneBlowers_testTPOPath(int iTest);
BOOL HeatZoneBlowers_IELevelTest(HeatZoneBlowers* pHeatZoneBlowers);
BOOL HeatZoneBlowers_StandbyModeTest(HeatZoneBlowers* pHeatZoneBlowers);
void HeatZoneBlowers_requestIE(HeatZoneBlowers* pHeatZoneBlowers, int iRequestIELevel);
void HeatZoneBlowers_setFlush2Sent(HeatZoneBlowers* pHeatZoneBlowers, BOOL bSent);
void HeatZoneBlower_toggleSMOne(HeatZoneBlowers* pHeatZoneBlowers, BOOL on);
typedef struct _GlobalBlower_
{
//public:
	DWORD startTime;
	DWORD TPOBlowerPercent;
	DWORD jobNo;
	BOOL setPointChanged;
	BOOL enabled;
//private:
	DWORD flushTime;
	UINT controlType; 
	DWORD standbyTime;
	UINT ieRequestLevel;
	UINT lastStepTime;
	UINT runLevel;
	BOOL bInStartupMode;
	DWORD LowSetting;
	DWORD MediumSetting;
	DWORD HighSetting;
	BOOL b0100;
	DWORD minimum;
	DWORD m_dwrdMaximum;
	BOOL bInStandbyMode;
	DWORD currentIELevel;
	DWORD ssTime;
	BOOL bFlush2;
	BOOL m_bFlush;
} GlobalBlower;

void GlobalBlower_init(GlobalBlower* pGlobalBlower);
void GlobalBlower_StandbyResetForSequencing(GlobalBlower* pGlobalBlower);

DWORD GlobalBlower_getOutputPercent( GlobalBlower* pGlobalBlower );
DWORD GlobalBlower_getTPOoutputCounts( GlobalBlower* pGlobalBlower );
void GlobalBlower_setEnableState(GlobalBlower* pGlobalBlower, BOOL enableState /*= TRUE*/ );
BOOL GlobalBlower_getEnableState( GlobalBlower* pGlobalBlower );
void GlobalBlower_setPointChange(GlobalBlower* pGlobalBlower, BOOL setPointHasChanged /*= TRUE*/ );
void GlobalBlower_process(GlobalBlower* pGlobalBlower);
void GlobalBlower_setFlushTime(GlobalBlower* pGlobalBlower, DWORD flshTime);	

 typedef struct _AnalogFan_
{
//public:
	DWORD		startTime;
	DWORD		TPOBlowerPercent;
	DWORD		jobNo;
	BOOL		setPointChanged;
	BOOL 		enabled;
	
//private:
	DWORD flushTime;
	UINT controlType; 
	DWORD standbyTime;
	UINT ieRequestLevel;
	UINT lastStepTime;
	UINT runLevel;
	BOOL bInStartupMode;
	DWORD LowSetting;
	DWORD mediumSetting;
	DWORD HighSetting;
	BOOL b0100;
	DWORD minimum;
	DWORD m_dwrdMaximum;
	BOOL bInStandbyMode;
	DWORD currentIELevel;
	DWORD ssTime;
	BOOL bFlush2;
	BOOL m_bFlush;
} AnalogFan;

void AnalogFan_init(AnalogFan* pAnalogFan);
void AnalogFan_StandbyResetForSequencing(AnalogFan* pAnalogFan);

void AnalogFan_setEnableState (AnalogFan* pAnalogFan, BOOL enableState /*= TRUE */);
BOOL AnalogFan_getEnableState	( AnalogFan* pAnalogFan );
DWORD AnalogFan_getOutputPercent(AnalogFan* pAnalogFan);
DWORD AnalogFan_getTPOoutputCounts(AnalogFan* pAnalogFan);
void AnalogFan_setPointChange(AnalogFan* pAnalogFan, BOOL setPointHasChanged /*= TRUE*/ );
void AnalogFan_process(AnalogFan* pAnalogFan);
void AnalogFan_setFlushTime(AnalogFan* pAnalogFan, DWORD flshTime);	
void AnalogFan_testCriticalPath(int iTest);
void Fans_requestIE(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, int requestLevel);
BOOL AnalogFan_IELevelTest(AnalogFan* pAnalogFan);
BOOL AnalogFan_StandbyModeTest(AnalogFan* pAnalogFan);
BOOL GlobalBlower_IELevelTest(GlobalBlower* pGlobalBlower);
BOOL GlobalBlower_StandbyModeTest(GlobalBlower* pGlobalBlower);
void Fans_toggleSMOne(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, BOOL on);
BOOL Fans_anyInFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers);
void Fans_beginFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers);
void Fans_endFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers);
void Fans_setMaximumOutput(int blowerGroup, int MaxPercentage);
BOOL Fans_setOutputPercent(unsigned int ZoneNo, int outputPercent );
void Fans_setMinimum(unsigned int ZoneNo, int Minimum );

#endif
