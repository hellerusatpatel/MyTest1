/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//fluxfilt.cpp
#include "contain.h"
#include "typedefdefine.h"
#include "fluxfilt.h"
#include "alarm.h"
#include "digitio.h"
#include "oven.h"
#include "timer.h"

extern DbContainer g_dbContainer;

DIN	*digitalInDb;
DOUT *digitalOutDb;
Oven *ovenDb;
Timer *elapseTimer;
AlarmQueue *alarmQueueDb;


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxFilter_init

  
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxFilter_init(FluxFilter* pFluxFilter )
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_init");
	pFluxFilter->elapsedTimeLastClean10ths = 0;
	pFluxFilter->elapsedTimeDoorOpen = 0;
	pFluxFilter->lastCheckTime10ths = 0;
	pFluxFilter->doorOpenStartTime10ths = 0;
	pFluxFilter->intervalBetweenCleaning10ths = ONE_HOUR_10THS;
	pFluxFilter->messageSent = FALSE;
	pFluxFilter->priorContactorState = FALSE;
	pFluxFilter->cleanFilter = FALSE;
	pFluxFilter->fluxFilterDoorOpened = FALSE;
	pFluxFilter->fluxFilterEnabled = FALSE;
	pFluxFilter->bSetDO = FALSE;
	pFluxFilter->bDoorOpenSent = FALSE;
	digitalInDb = &( g_dbContainer.digitalInDb );
	digitalOutDb = &( g_dbContainer.digitalOutDb );
	elapseTimer = &( g_dbContainer.elapseTimer );
	alarmQueueDb = &( g_dbContainer.alarmQueueDb );
	ovenDb = &( g_dbContainer.ovenDb );
}

void FluxFilter_fluxFilterEnable(FluxFilter* pFluxFilter,  BOOL enable )
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_fluxFilterEnable");
	pFluxFilter->fluxFilterEnabled = enable;
}


DWORD FluxFilter_getElapsedTime10ths(FluxFilter* pFluxFilter)
{
	PARAM_CHECK_RETURN( pFluxFilter, "FluxFilter_getElapsedTime10ths", 0);
	return pFluxFilter->elapsedTimeLastClean10ths;
}

void FluxFilter_setElapsedTime10ths(FluxFilter* pFluxFilter, DWORD elapsedTime10ths )
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_setElapsedTime10ths");
	pFluxFilter->elapsedTimeLastClean10ths = elapsedTime10ths;
}

void FluxFilter_setFluxFilterCleaningInterval10ths(FluxFilter* pFluxFilter, DWORD cleanInterval10ths )
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_setFluxFilterCleaningInterval10ths");
	pFluxFilter->intervalBetweenCleaning10ths = cleanInterval10ths;
}

DWORD FluxFilter_getFluxFilterCleaningInterval10ths( FluxFilter* pFluxFilter )
{
	PARAM_CHECK_RETURN( pFluxFilter, "FluxFilter_getFluxFilterCleaningInterval10ths", 0);
	return pFluxFilter->intervalBetweenCleaning10ths;
}

BOOL FluxFilter_getCleaningStatus(FluxFilter* pFluxFilter)
{
	PARAM_CHECK_RETURN( pFluxFilter, "FluxFilter_getCleaningStatus", 0);
	return pFluxFilter->cleanFilter;
}

void FluxFilter_process(FluxFilter* pFluxFilter)
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_process");

	if ( pFluxFilter->fluxFilterEnabled == TRUE )
	{
		if ( *DIN_GetAt(digitalInDb, IDI_FLUX_FILTER_DOOR_CLOSED) == TRUE )  // door closed
		{
		   if(!Oven_isCOOLDOWNcomplete(ovenDb) || !Oven_getJob(ovenDb) == COOLDOWN)
				*DOUT_GetAt(digitalOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = *DOUT_GetAt(digitalOutDb, ODO_CONVEYOR_BLOWER);
		}
		else
		{
			// For safety reasons anytime the Flux Filter door is open the flux filter must
			// be turned off.
			// Doug Smith 3/10/99
			// Modification SDY 3/10/99
			*DOUT_GetAt(digitalOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
			if(pFluxFilter->bSetDO)
				*DOUT_GetAt(digitalOutDb, ODO_NEW_JOB_FIVESEC) = FALSE;
		}
		if ( pFluxFilter->priorContactorState == FALSE && 
				*DIN_GetAt(digitalInDb, ODO_HEATER_CONTACT) == TRUE )
		{
			pFluxFilter->lastCheckTime10ths = Timer_getCurrentTime10ths(elapseTimer);
		}
		pFluxFilter->priorContactorState = *DIN_GetAt(digitalInDb, ODO_HEATER_CONTACT);
		// accumulate time only if the heater contactor is on. If the clean filter
		// flag gets set then the clean filter will be displayed in the event 
		// COOLDOWN is loaded. 
		if ( *DIN_GetAt(digitalInDb, ODO_HEATER_CONTACT) == TRUE || pFluxFilter->cleanFilter == TRUE )
		{
			pFluxFilter->currentTime10ths = Timer_getCurrentTime10ths(elapseTimer); 
			pFluxFilter->deltaTime =  pFluxFilter->currentTime10ths - pFluxFilter->lastCheckTime10ths; 
			pFluxFilter->lastCheckTime10ths = pFluxFilter->currentTime10ths;
			pFluxFilter->elapsedTimeLastClean10ths += pFluxFilter->deltaTime;

			// has enough time elapsed to signal the cleaning of the flux filter.

			if ( pFluxFilter->elapsedTimeLastClean10ths >= pFluxFilter->intervalBetweenCleaning10ths )
			{
				pFluxFilter->cleanFilter = TRUE;

				if ( pFluxFilter->messageSent == FALSE )
				{
					// send this message only once every twenty minutes.

					AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, FLUX_FILTER_CLEANING_REQUIRED, 0 );
					pFluxFilter->messageSendTime10ths = Timer_getCurrentTime10ths(elapseTimer);
					pFluxFilter->messageSent = TRUE;
				}
				else
				{
					pFluxFilter->deltaTime = Timer_getCurrentTime10ths(elapseTimer) - pFluxFilter->messageSendTime10ths;
					if (  pFluxFilter->deltaTime >= TWENTY_MINUTES_TENTHS_SECONDS )
					{
						pFluxFilter->messageSent = FALSE;
					}
				}
				
				// the door must be open for at least five seconds before the flux filter 
				// will be indicated as being cleaned.

				// a transition of closed to open is need to set start time. 
				if ( *DIN_GetAt(digitalInDb, IDI_FLUX_FILTER_DOOR_CLOSED) == TRUE )
				{	// If the door was closed and is now open set the time.
					pFluxFilter->doorOpenStartTime10ths = Timer_getCurrentTime10ths(elapseTimer);
				}

				if ( *DIN_GetAt(digitalInDb, IDI_FLUX_FILTER_DOOR_CLOSED) == FALSE ) // the door is open
				{
					// this is not accumualted but contiguous time. The door must be opened
					// for a minimum of 5 seconds continuously.
					pFluxFilter->doorOpenTime10ths = Timer_getCurrentTime10ths(elapseTimer) - pFluxFilter->doorOpenStartTime10ths;
					if ( pFluxFilter->doorOpenTime10ths >= FLUX_FILTER_DOOR_OPEN_TIME )
					{
						pFluxFilter->fluxFilterDoorOpened = TRUE;
					}	

					// if the door has been opened for at least five seconds and is now closed then the
					// filter has been cleaned.
					if ( pFluxFilter->fluxFilterDoorOpened == TRUE && *DIN_GetAt(digitalInDb, IDI_FLUX_FILTER_DOOR_CLOSED) == TRUE )
					{
						pFluxFilter->fluxFilterDoorOpened = FALSE;
						pFluxFilter->cleanFilter = FALSE;
						pFluxFilter->elapsedTimeLastClean10ths = 0;
						pFluxFilter->messageSent = FALSE;
					}
				}
			}
		}
	
		if ( *DIN_GetAt(digitalInDb, IDI_FLUX_FILTER_DOOR_CLOSED) == FALSE )
		{
			// continously send this message until the door is closed. 
			pFluxFilter->bDoorOpenSent = TRUE; //we now inform the terminal of a clear
			AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, FLUX_FILTER_DOOR_OPEN, 0);
		}
		else if(pFluxFilter->bDoorOpenSent)
		{
			pFluxFilter->bDoorOpenSent = FALSE;
			AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, FLUX_FILTER_DOOR_CLOSED, 0);
		}
	}
}

void FluxFilter_setDOAvailibility(FluxFilter* pFluxFilter, BOOL bAvail)
{
	PARAM_CHECK( pFluxFilter, "FluxFilter_setDOAvailibility");
	pFluxFilter->bSetDO = bAvail;
}
