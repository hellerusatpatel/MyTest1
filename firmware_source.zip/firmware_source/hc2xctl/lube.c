/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "lube.h"
#include "oven.h"
#include "alarm.h"
#include "digitio.h" 
#include "timer.h"

extern DbContainer g_dbContainer;

Oven			*ovenDb;
DOUT 			*digOutDb;
Timer			*elapseTimer;
AlarmQueue		*alarmQueueDb;

//******************************************************************************
// Lube_Lube		Constructor
//
// Abstract:
// The lube module is an option that is used to lubricate the belt. The oil
// is dispersed into a felt pad that stores the oil and releases through capillary
// action as the belt contacts this pad.
// Typical period between cycles is 1 hour with a duration of 3 seconds.
// Per conversation with Ray Lanchenauer of Heller Industries 4/15/1998,
// the time option will be replaced with a distance of belt travel between lube
// cycles.
// 1 hours distance = 188cm/minute * 60minutes = 11,280cm/hour
// duration remains at 3 seconds.
//
// Programmer: Steven Young
// Date: 04/15/1998
//******************************************************************************
void Lube_init(Lube* pLube, unsigned int idNo)
{
	PARAM_CHECK( pLube, "Lube_init");

	pLube->optionEnabled	= FALSE;
	pLube->lubeInProgress	= FALSE;
	pLube->lubeIntervalTime = 0;
	pLube->lastCheckTime	= 0;
	pLube->lubeIdNo        = idNo;

	ovenDb = &( g_dbContainer.ovenDb		);
	digOutDb = &( g_dbContainer.digitalOutDb	);
	elapseTimer = &( g_dbContainer.elapseTimer	);
	alarmQueueDb = &( g_dbContainer.alarmQueueDb	);
}

//******************************************************************************
// Lube_optionEnable
//
// Abstract:
// Not all ovens have the lube option installed and may not need this module.
//
// Programmer: Steven Young
// Date: 04/10/1998
//******************************************************************************
void Lube_optionEnable(Lube* pLube, BOOL enable )
{
	PARAM_CHECK( pLube, "Lube_optionEnable");
	pLube->optionEnabled = enable;
}

//******************************************************************************
// Lube_process()
//
// Abstract:
// If the lube option is enabled, then this is the processing that occurs on
// each scan of the loop.
// Belt constants:
//		12.7 pulses/cm.
// 		Max Rate: 188cm/minute.
//  	Max Pulses/Minute = 188cm/minute * 12.7pulses/cm = 2400pulses/min = 40pulses/sec
//		Speeds: <=12mv = 0cm/min, 100%=188cm/minute = 60mv@40pulses/sec freq to analog conversion
//		The above numbers need to be made configurable.
//		Need to have the OCX interface handle conversions of unit distance to encoder counts.
//		The lube timing is always off of belt one, there is only one lube solenoid. Per Ray L.
//
// Programmer: Steven Young
// Date: 04/15/1998
// Revisions:
// The auto lube was controlled by elapsed distance of the belt. Heller requested
// that this be changed to time base instead of distance based.
// SDY - 11/16/99
//******************************************************************************
void Lube_process( Lube* pLube )
{
   DWORD deltaTime;
	PARAM_CHECK( pLube, "Lube_process");
   
   if ( pLube->optionEnabled == TRUE )
   {	
		if ( pLube->lubeInProgress == FALSE )
		{
			// if the belt is not enabled then time should not be elapsing so make the last time checked
			// equal to the current time so that the elapsed time is 0.
			// SDY - 11/17/99
			if ( *DOUT_GetAt(digOutDb, ODO_CONVEYOR_BLOWER) == FALSE || 
				pLube->lastCheckTime == 0 )
			{
				pLube->lastCheckTime = Timer_getCurrentTime10ths(elapseTimer);

			}
			
			pLube->currentTime = Timer_getCurrentTime10ths(elapseTimer);
			deltaTime = differenceWithRollover( pLube->currentTime, pLube->lastCheckTime );
			pLube->elapsedTime += deltaTime;	  // accumulate the elapsed time.
			pLube->lastCheckTime = pLube->currentTime; 
		}

		// The following block of code only gets one shotted by setting the elapsed time to 0.
		if ( pLube->elapsedTime >= pLube->lubeIntervalTime && Oven_getJob(ovenDb) != COOLDOWN  )
		{
			pLube->elapsedTime = 0;
            switch ( pLube->lubeIdNo )
            {
			case 1:
				*DOUT_GetAt(digOutDb, ODO_AUTOLUBE_SOLENOID_1) = TRUE;	// turn on lube solenoid.
				AlarmQueue_addAlarm(alarmQueueDb,  LOGGED_EVENT, AUTOLUBE_CYCLE_ACTIVATED, 0);
				break;
			case 2:

				*DOUT_GetAt(digOutDb, ODO_AUTOLUBE_SOLENOID_2) = TRUE;	// turn on lube solenoid.
				AlarmQueue_addAlarm(alarmQueueDb,  LOGGED_EVENT, AUTOLUBE_CYCLE_ACTIVATED_2, 0 );
				break;
            }

			pLube->lubeInProgress = TRUE;
			pLube->startTime = Timer_getCurrentTime10ths(elapseTimer);
		}


		// since the oven can go into COOLDOWN at anytime, no definitive time on how long COOLDOWN will take, 
		// for example all tempzones at 95C or less and since the lube duration time can last more than the time
		// COOLDOWN takes. Since COOLDOWN is required before shutting off oven then turn off the SOLENOID, so it 
		// cannot be left on for an extended duration.
		if ( pLube->lubeInProgress == TRUE )
		{
			pLube->currentTime = Timer_getCurrentTime10ths(elapseTimer);
			deltaTime =  differenceWithRollover(pLube->currentTime, pLube->startTime);

			if ( deltaTime >= pLube->lubeDuration10ths || Oven_getJob(ovenDb) == COOLDOWN )
			{
				switch ( pLube->lubeIdNo )
				{
                case 1:
							*DOUT_GetAt(digOutDb, ODO_AUTOLUBE_SOLENOID_1) = FALSE; 	// lube cycle complete
							pLube->lubeInProgress = FALSE;
							break;
                case 2: 

                    *DOUT_GetAt(digOutDb, ODO_AUTOLUBE_SOLENOID_2) = FALSE; 	// lube cycle complete
				    pLube->lubeInProgress = FALSE;
                    break;
				}
			}
		}
	}
}

void Lube_setElapsedTime10ths(Lube* pLube, DWORD savedTimeInTenthsOfSeconds)
{
	PARAM_CHECK( pLube, "Lube_setElapsedTime10ths");
	pLube->elapsedTime = savedTimeInTenthsOfSeconds;
}

DWORD Lube_getElapsedTime10ths(Lube* pLube)
{
	PARAM_CHECK_RETURN( pLube, "Lube_getElapsedTime10ths", 0);
	return pLube->elapsedTime;
}

void Lube_setLubeIntervalTime(Lube* pLube, DWORD lubeIntervalInMinutes )
{
	PARAM_CHECK( pLube, "Lube_setLubeIntervalTime");
	pLube->lubeIntervalTime = lubeIntervalInMinutes * 600;  // the number of tenths of seconds in an hour.
}

void Lube_setLubeDurationTime(Lube* pLube, DWORD lubeDurationTime10thsOfSec )
{
	PARAM_CHECK( pLube, "Lube_setLubeDurationTime");
	pLube->lubeDuration10ths = lubeDurationTime10thsOfSec;
}

DWORD Lube_getLubeIntervalTime(Lube* pLube )
{
	PARAM_CHECK_RETURN( pLube, "Lube_getLubeIntervalTime", 0);
	return pLube->lubeIntervalTime/36000;							// convert back to hours.
}

DWORD Lube_getLubeDurationTime(Lube* pLube )
{
	PARAM_CHECK_RETURN( pLube, "Lube_getLubeDurationTime", 0);
	return pLube->lubeDuration10ths;
}

