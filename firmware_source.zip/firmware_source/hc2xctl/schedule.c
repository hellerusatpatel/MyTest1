/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			schedule.c

	Description:	schedule loop

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "schedule.h"
#include "contain.h"
#include "hc2xwd.h"
#include "../hc2xio/include/hc2xio_exports.h"
#include "xpdriverdevice.h"
#include "barcodeDIO.h"
#include "transferTable.h"
#include "hc2xmstr_exports.h"
#include "carrierEvents.h"

extern DbContainer g_dbContainer;

unsigned char gSeqeunceStatus;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_init

			initialization

 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_init(Scheduler* pScheduler)
{
	gSeqeunceStatus = 0;
	pScheduler->iScheduleLoopCount = 0;
	pScheduler->sequenceNo   =  0;
	pScheduler->timerCount   =  0;	
	pScheduler->scanPeriod   =  100;	// in ms
	pScheduler->consecutiveNoReadScans = 0;
	pScheduler->elapsedTempZoneTime = 0;
	pScheduler->m_bTimerFired = FALSE;
	pScheduler->HighPartTime = 0;
	pScheduler->LowPartTime = 0;
	pScheduler->elapsed100Nanos = 0;
	pScheduler->testDog = 0;

	pScheduler->m_bResetTrackingLane0 = FALSE;
	pScheduler->m_bResetTrackingLane1 = FALSE;
	pScheduler->m_bResetTrackingLane2 = FALSE;
	pScheduler->m_bResetTrackingLane3 = FALSE;
	return;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_setContainerAddress

			The scheduler needs the address of the container in order to call the
			processing functions. Once it is set then we can set interrupts to 
			happen.
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_setContainerAddress(Scheduler* pScheduler)
{
	  // this is the closest thing to a constructor withouth having to make it
	  // part of the DbContainer class. 
	  Oven_setScanPeriod(&(g_dbContainer.ovenDb), pScheduler->scanPeriod);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_sequencer

			The sequencer is triggered on each 1ms interrupt and a counter 
			is incremented to maintain a sequence position. When the 
			counter reaches the scanPeriod time it is reset to start 
			processing the loop again.  Interrupts need to be turned off 
			when setting the inProcess flag. Should not need to worry 
			about when setting to FALSE because no other process should
			be able to run process functions if inProcess is TRUE.  In 
			the event of an overrun, it is assumed that if the HC1X IO 
			Controller does not respond by the following sequence step 
			it will not.
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_sequencer(Scheduler* pScheduler)
{
	DWORD flags;
	IOANALOGIN* pANALOGIN;
	BOOL bStartup;

	flags = 0;
	pANALOGIN = NULL;
	bStartup = FALSE;

	if( NULL != pScheduler )
	{
		if(!pScheduler->testDog)
		{
			hc2xwd_TickleDog(CTL_DOG);
		}	
		switch(gSeqeunceStatus)
		{
			case MONITOR_SEQUENCE:
				Scheduler_monitor_sequencer(pScheduler);			
				break;

			case CONTROL_SEQUENCE:
				Timer_add10thSecond(&(g_dbContainer.elapseTimer));

				pANALOGIN = getIOANALOGIN();	
				if(pANALOGIN)
				{

					IOANALOGIN_encoderReader(pANALOGIN);
				}

				DIN_process(&(g_dbContainer.digitalInDb));		// put the data in an array for processing.

				DOUT_process(&(g_dbContainer.digitalOutDb));		// put the data in an array for processing.
				ANALOGIN_process(&(g_dbContainer.analogInDb));
				ANALOGOUT_process(&(g_dbContainer.analogOutDb));
				HC2XMSTR_SetSecondaryActiveFlag( g_dbContainer.slaveConfig.bSecondaryActive );

				if ( g_dbContainer.slaveConfig.bSecondaryActive )
				{
					flags = HC2XMSTR_SecondaryGetFlags();
					if(g_dbContainer.slaveConfig.bConfigure)//configuration to be written, write until read back
					{

						HC2XMSTR_PrimarySetConfiguration(&(g_dbContainer.slaveConfig.config));
						if((flags & StatusFlagConfigured))
						{
							g_dbContainer.slaveConfig.bConfigure = FALSE;
						}
					}

					if(g_dbContainer.slaveConfig.bWaitingForOffset)
					{
						if((flags & StatusFlagOffsets))
						{
							g_dbContainer.slaveConfig.bWaitingForOffset = FALSE;
							ANALOGIN_PopulateSecondaryOffsets(&(g_dbContainer.analogInDb));
						}
					}

					if(flags & StatusFlagNoData)//master app communication to secondary timed out
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), ALARM, TZ_SLAVE_COMM_FAILURE, 0);
					}
					else if(flags & StatusFlagCommTimeout)//slave was running with defaults
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, SLAVE_COMM_DEFAULT, 0);
					}
				}

			 	pScheduler->elapsedTempZoneTime++;
				
				//moving the belt outside of the ten count.  The belt pid will occur more often when below deadband, once in deadband
				//we'll use a count internally in the belt class so the pid happens 1/10 as often WDT 07/27/01
				Belts_SetBeltSpeedPIDTrig(&(g_dbContainer.beltsDb), TRUE);

				if ( pScheduler->elapsedTempZoneTime >= FREQUENCY100MS )	// the analog inputs are updated every 1.25 seconds or 1250ms ms
				{
					if(pScheduler->m_bResetTrackingLane0 == TRUE)
					{
						pScheduler->m_bResetTrackingLane0 = FALSE;
						if( FALSE == g_bLotProcessingEnable )
						{
							newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ0_NoLP));
						}
						else
						{
							newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ0));
						}
					}
					else if(pScheduler->m_bResetTrackingLane1 == TRUE)
					{
						pScheduler->m_bResetTrackingLane1 = FALSE;
						if( FALSE == g_bLotProcessingEnable )
						{
							newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ1_NoLP));
						}
						else
						{
							newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ1));
						}
					}
					else if(pScheduler->m_bResetTrackingLane2 == TRUE)
					{
						pScheduler->m_bResetTrackingLane2 = FALSE;
						if( FALSE == g_bLotProcessingEnable )
						{
							newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ2_NoLP));
						}
						else
						{
							newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ2));
						}
					}
					else if(pScheduler->m_bResetTrackingLane3 == TRUE)
					{
						pScheduler->m_bResetTrackingLane3 = FALSE;
						if( FALSE == g_bLotProcessingEnable )
						{
							newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ3_NoLP));
						}
						else
						{
							newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ3));
						}
					}

					// if the elapsedTempZoneTime changes or the scanPeriod value is changed
					// then the dt in the PID calculation must be changed to correspond to 
					// the sum of the error that elapses during the latency period between 
					// process calculation.

					//  master mode
					TempZones_process((&g_dbContainer.tempZonesDb));

					FluxHeater_process(&(g_dbContainer.fluxHeater));
					FluxHeater_process(&(g_dbContainer.fluxHeater1));
					FluxHeater_process(&(g_dbContainer.fluxHeater2));
					FluxHeater_process(&(g_dbContainer.fluxHeater3));
					FluxHeater_process(&(g_dbContainer.fluxHeater4));
					pScheduler->elapsedTempZoneTime = 0;
				}
				TempZones_cooling(&(g_dbContainer.tempZonesDb));

				Belts_process(&(g_dbContainer.beltsDb));
				Belts_SetBeltSpeedPIDTrig(&(g_dbContainer.beltsDb), FALSE);
				//if you reorder the gb, fan, oven, or hz examine the energy mode timer reset
				Oven_process(&(g_dbContainer.ovenDb));
				CoolPipe_process(&g_dbContainer.coolPipeDb);

				
				if( TRUE == g_bLotProcessingEnable)
				{
					newBoardQueue_process(&(g_dbContainer.boardQ0));
					newBoardQueue_process(&(g_dbContainer.boardQ1));
					newBoardQueue_process(&(g_dbContainer.boardQ2));
					newBoardQueue_process(&(g_dbContainer.boardQ3));
					LotProcessing_process( &(g_dbContainer.m_lotProcessing) );
				}
				else
				{
					newBoardQueue_process_NoLP(&(g_dbContainer.boardQ0_NoLP));
					newBoardQueue_process_NoLP(&(g_dbContainer.boardQ1_NoLP));
					newBoardQueue_process_NoLP(&(g_dbContainer.boardQ2_NoLP));
					newBoardQueue_process_NoLP(&(g_dbContainer.boardQ3_NoLP));
				}

				Nitrogen_process((&g_dbContainer.nitrogen));
				Lube_process(&(g_dbContainer.lube1));
				Lube_process(&(g_dbContainer.lube2));
				LightTower_process(&(g_dbContainer.lightTower));
					
				Rails_process(&(g_dbContainer.railsDb));

				BoardDropLB_process(&(g_dbContainer.boardDropLB0));
				BoardDropLB_process(&(g_dbContainer.boardDropLB1));
				FluxFilter_process(&(g_dbContainer.fluxFilter));
				CBS_process(&(g_dbContainer.cbs));
				//if you reorder the gb, fan, oven, or hz examine the energy mode timer reset
				GlobalBlower_process(&(g_dbContainer.globalBlower));
				HeatZoneBlowers_process(&(g_dbContainer.heatZoneBlowers));
				MassController_process( &(g_dbContainer.masscontroller) );
				AnalogFan_process(&(g_dbContainer.analogFan));
				Oxygen_process(&(g_dbContainer.oxygen));
				Maintenance_process(&(g_dbContainer.maintenance));
				SMEMA_process(&(g_dbContainer.smema1));
				SMEMA_process(&(g_dbContainer.smema2));
				SMEMA_process(&(g_dbContainer.smema3));
				SMEMA_process(&(g_dbContainer.smema4));

				Flasher_process(&(g_dbContainer.flasherSPChange));
				Flasher_process(&(g_dbContainer.flasherReady));
				Flasher_process(&(g_dbContainer.flasherReadyBoards));
				Flasher_process(&(g_dbContainer.flasherWarning));
				Flasher_process(&(g_dbContainer.flasherAlarmCooldown));
				Flasher_process(&(g_dbContainer.flasherEstopCooldown));

				Purge_process(&(g_dbContainer.purge));
				FluxCondensor_process(&(g_dbContainer.fluxCondensor));
				BCIO_process(( &(g_dbContainer.barcodeDio)));			
				break;

			default:
				break;

		}

	}

	return;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_monitor_sequencer

			for exclusive lock from the monitor applicaion
 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_monitor_sequencer(Scheduler* pScheduler)
{
	unsigned int i;
	i = 0;

	// need to keep an accurate time to the tenth of a second.

	if ( pScheduler->timerCount >= 100 ) // to be exactly 100ms
	{
		Timer_add10thSecond(&(g_dbContainer.elapseTimer));
		pScheduler->timerCount = 0;
	}
	pScheduler->timerCount += 10; //ms

	// The sequencer scan time
	
	pScheduler->sequenceNo += 10;//ms
	if ( pScheduler->sequenceNo >= pScheduler->scanPeriod )  
	{
		pScheduler->sequenceNo = 0x0;
	}
	
  
	if(pScheduler->sequenceNo == 40) //40 ms out of 100			
	{
		//need process to right the buffer(s) to the array.
		DIN_process(&(g_dbContainer.digitalInDb));		// put the data in an array for processing.

		ANALOGIN_process(&(g_dbContainer.analogInDb));
		for(i = 0; i < MAX_TPOS; i++)
		{
			TPO_AddSafeSegment(i, SAFE_SEGMENT_CONTROL);
		}
		pScheduler->elapsedTempZoneTime++;
		//moving the belt outside of the ten count.  The belt pid will occur more often when below deadband, once in deadband
		//we'll use a count internally in the belt class so the pid happens 1/10 as often WDT 07/27/01
		if ( pScheduler->elapsedTempZoneTime >= 10 )	// the analog inputs are updated every 1.25 seconds or 1250ms
		{
			// if the elapsedTempZoneTime changes or the scanPeriod value is changed
			// then the dt in the PID calculation must be changed to correspond to 
			// the sum of the error that elapses during the latency period between 
			// process calculation.
			pScheduler->elapsedTempZoneTime = 0;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_reset

			resets variables in the schedule loo

 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_reset( Scheduler* pScheduler )
{ 
	pScheduler->sequenceNo = 0;	
	pScheduler->m_bTimerFired = FALSE; 
	pScheduler->LowPartTime = 0; 
	pScheduler->HighPartTime = 0;
	return;
}

DWORD	Scheduler_getScanPeriodMs(Scheduler* pScheduler)
{
	return pScheduler->scanPeriod; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_start

			starts the scheduler execution of control loops
 
 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_start( Scheduler *pScheduler )
{
	gSeqeunceStatus|= BPROCESS; 
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_stop
			Stops the scheduler execution of control loops
 
 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_stop( Scheduler *pScheduler )
{
	gSeqeunceStatus  &= ~(BPROCESS);

	DbContainer_slaveConfigure( &g_dbContainer, FALSE );
	HC2XMSTR_PrimarySetConfiguration(&(g_dbContainer.slaveConfig.config));

	g_dbContainer.slaveConfig.bSecondaryActive = FALSE;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Scheduler_switchLoops

	This function will set a boolean to be used in the sequence routine.  When true the 
	normal oven controller will be bypassed for direct io control

 RETURNS:   void
------------------------------------------------------------------------*/
void Scheduler_switchLoops( Scheduler *pScheduler , int bValue)
{
	if(bValue)
	{
		gSeqeunceStatus = STARTUP_WITHJOB;
	}
	else
	{
		gSeqeunceStatus  &= ~(STARTUP_WITHJOB);
	}
	return;
}

////////////////////////////////////////////////////////////////////////////
//Scheduler_testDog
//
//This function will cause the reset of the watchdog to skip, thus the board
//should watchdog due to the scheduler test
////////////////////////////////////////////////////////////////////////////
void Scheduler_testDog(Scheduler *pScheduler)
{
	pScheduler->testDog = 1;
}
