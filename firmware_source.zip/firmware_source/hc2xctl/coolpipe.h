typedef struct
{
	int enable;
	int analogInputTC1;
	int analogInputTC2;
	int tempTC1;
	int tempDelta;
	int delay;
	DWORD onsetTime;
} CoolPipe;

void CoolPipe_init(CoolPipe*);
void CoolPipe_process(CoolPipe*);
