/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// cbs.h - Center Board Support
#ifndef __CBS_H__
#define __CBS_H__

#include "typedefdefine.h"

enum CBS_State { Down = 0, Up = 1 };

typedef struct _CBS_
{
//private:
	char name[MaxNameLength+1];
	enum CBS_State cbs_Up;
	enum CBS_State cbs_SecondUp;
	enum CBS_State ds_Up;
	BOOL firstCBSActiveFeedback;
	BOOL secondCBSActiveFeedback;
//Heller wants a delay on the green light test 3 seconds should suffice
	UINT firstCBSInPositionTime;
	UINT secondCBSInPositionTime;
	BOOL bDSEnabled;
	int iDSDigitalIn;
	int iDSDigitalOut;
	BOOL cbs1Enabled;
	BOOL cbs2Enabled;

} CBS;

void CBS_init(CBS* pCbs);

void CBS_setStates(CBS* pCbs, enum CBS_State nState, UINT CBSIndex );
enum CBS_State CBS_GetState(CBS* pCbs);
enum CBS_State CBS_GetSecondState(CBS* pCbs);
const char * CBS_getName(CBS* pCbs);
void CBS_process(CBS* pCbs);
void CBS_setFeedbackType(CBS* pCbs, BOOL isReadBack, UINT CBSIndex);
void CBS_setEnable(CBS* pCbs, BOOL bEnable, UINT nIndex);
void CBS_setInput(CBS* pCbs, int iInput, UINT nIndex);
void CBS_setOutput(CBS* pCbs, int iOutput, UINT nIndex);

BOOL CBS_areAllBoardSupportsInCorrectPosition(CBS* pCbs);
BOOL CBS_isFirstBoardSupportInCorrectPosition(CBS* pCbs);
BOOL CBS_isSecondBoardSupportInCorrectPosition(CBS* pCbs);

#endif
