/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999-2014, All Rights Reserved
                    Company Confidential
 
	File:			newBoardQueueNoLP.h

	Description:	board tracking with no lot processing
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __NEWBOARDQ_NOLP_H__
#define __NEWBOARDQ_NOLP_H__

#include "boards.h"
#include "typedefdefine.h"

/*----------------------------------------------------------------------
 *
 *	DEFINES AND TYPEDEFS
 *
 *---------------------------------------------------------------------*/

typedef struct _carrierEvent_
{
	DWORD Lane;
	DWORD CarrierNumber;
	DWORD TimeHigh;
	DWORD TimeLow;
	DWORD Leaving;
	DWORD LotID;
	DWORD milli;
} carrierEvent;

typedef struct _newBoardQueue_NoLP_
{

//private:
	Board		boards[MaxBoards];

UINT		boardQId;
	Belt		*pBeltIOTied;		// pointer to the parent belt.

	BOOL	*pBoardEnteringOven;
	BOOL	*pBoardLeavingOven;
	BOOL		boardQueueActive;
	DWORD		inputHighCount;
	DWORD		boardDeadbandCounts;
	DWORD		distanceBetweenSensorsCounts;
	DWORD		currentBeltPosition;
	DWORD		boardsProcessed;
	DWORD		lastBoardDetectPosition;
	DWORD		lengthInCounts;
	UINT		headIndex;
	UINT		tailIndex;
	DWORD		boardCount;
	BOOL		timedBoarddropEnabled;
	BOOL		boardsInOvenEnabled;
	BOOL		boardsProcessedEnabled;
	BOOL		boardDetectIn;
	BOOL		boardDetectOut;
	BOOL		boardInputValid;
	BOOL		previousBoardDetectState;
	DWORD		startBoardInDetectTime;
	DWORD		expectLowInputAfterCounts;
	DWORD		m_dwrdTrailingEdgeCounts;//for board backup test

	// m_localTimeEntryLeadingEdge references the m_currentTime's value for the last time the board entry input was OFF
	LocalTime	m_localTimeEntryLeadingEdge;
	// m_localTimeEntryTrailingEdge references the m_currentTime's value for the last time the board entry input was ON
	LocalTime	m_localTimeEntryTrailingEdge;
	// m_localTimeExitLeadingEdge references the m_currentTime's value for the last time the board exit input was OFF
	LocalTime	m_localTimeExitLeadingEdge;
	// m_localTimeExitTrailingEdge references the m_currentTime's value for the last time the board exit input was ON
	LocalTime	m_localTimeExitTrailingEdge;

	UINT		filterCount;
	UINT		filterCount2;
	UINT		filterCount3;
	BOOL		boardOutputValid;
	BOOL		boardBackUpState;
	BOOL		boardEntranceJamState;
	BOOL		previousBoardOutDetectState;
	DWORD		startBoardOutDetectTime;
	DWORD		boardBackUpTime;
	BOOL		lowHasOccurred;
    BOOL        updateComplete;
	BoardData   boardData;
	BOOL		m_bBoardOnEntrySensor;
	BOOL		m_bEnableBoardStop;
	DWORD 	exitBoardDeadbandCounts;
	DWORD		boardDropTol;
	UINT		uintBoardDropTime;
	DWORD		m_uintTimeBackupBegan;
	DWORD		m_uintTimeEntranceJamBegan;
	DWORD		boardDropTolNeg;	
	DWORD		selfAckCode;
	DWORD		selfAckAdd;
	DWORD		selfAckExit;
	BOOL 		m_bPendSmema;
	BOOL		m_bStartSmema;
	DWORD 		smema9851startBoardInDetectDist;
	BOOL		m_bBoardRemoved; //used for cure oven smema to see if the belt should be stopped on next board exit
	BOOL		m_bLengthAssigned;
//public:

	int notifyBoard;
	int notifyBoardOut;
	BOOL m_bSprayIsOn;
	BOOL m_bSprayEnabled;
	DWORD dwSprayLength;
	DWORD	m_dwSprayDist;
	DWORD	m_FCExit;
	BOOL	m_bBoardExitFull;
	DWORD	m_dwrdLastBeltPosWNoBoards;
	DWORD 	m_dwZoneADist;
	BOOL	boardHeadRead;
	DWORD	boardStartPos;
	BOOL	m_b9851Enter;
	DWORD	m_9851distanceTraveled;
	DWORD	cureOven;
	BOOL	m_bCureRemove;
	BOOL	m_bCureRemoveDistStamped;
	DWORD   m_cureRemoveDist;
	BOOL	m_skipTail;

	BOOL	m_bIgnoreBoardLength;	// used to ignore board length in the board drop calculation
	
	BOOL	m_bEnablePredefinedBoardLength;
	DWORD	m_PredefinedBoardLength;

	BOOL	m_bEntranceJamWarning;
	BOOL    m_bEnteranceJamStampTaken;
	DWORD	m_enteranceJamBeginDist;
	BOOL	m_bExitJamWarning;
	BOOL    m_bExitJamStampTaken;
	DWORD	m_exitJamBeginDist;
	BOOL	boardExitJamState;
	DWORD	m_uintTimeExitJamBegan;
	DWORD 	blowerBoardLoad;
	DWORD	m_dMilli;
	DWORD 	m_dHigh;
	DWORD	m_dLow;
	DWORD	m_highTime;
	DWORD	m_lowTime;
	DWORD	m_highTimeL;
	DWORD	m_lowTimeL;
	DWORD	m_lotEntering;
	DWORD 	m_lotExiting;
	DWORD	m_lotEnteringCount;
	DWORD	m_lotExitingCount;
	unsigned   long	m_jiffies;
	UINT	uiCurrentJob;
	BOOL 	timeStamped;
	BOOL	timeStampedL;
	DWORD	existingBoardDropID;
	BOOL 	ltTracking;
	DWORD 	dwrdPosWhenHigh;
	BOOL	bBoardLeft;
	// TimeStamp used to coordinate the time between the PC and the driver.
	LocalTime	m_currentTime;
} newBoardQueue_NoLP;

/*----------------------------------------------------------------------
 *
 *	GLOBAL VARIABLES EXPORTS
 *
 *---------------------------------------------------------------------*/
extern BOOL g_bPanelIDEnable;
extern BOOL g_bLotProcessingEnable;


/*----------------------------------------------------------------------
 *
 *	FUNCTION PROTOTYPES
 *
 *---------------------------------------------------------------------*/

void		newBoardQueue_initGlobalVariables( void );
void		newBoardQueue_init_NoLP(newBoardQueue_NoLP* pNBQ);

BOOL		newBoardQueue_ioConfig_NoLP(newBoardQueue_NoLP* pNBQ, UINT activeBelts );
BOOL		newBoardQueue_bdConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDropConfig );
BOOL		newBoardQueue_bpConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardsProcessedConfig );
BOOL		newBoardQueue_boConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardsInOvenConfig );
void		newBoardQueue_checkForBoardEntering_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_checkForBoardDrop_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_checkForBoardLeaving_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_checkForEntranceBoardJam_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_checkForBoardBackup_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_checkForBoardFCExit_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_hasLowOccurred_NoLP(newBoardQueue_NoLP* pNBQ);
BOOL		newBoardQueue_addBoard_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_removeBoard_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_setLength_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_newBoard_NoLP(newBoardQueue_NoLP* pNBQ, DWORD beltPositionInCounts );
void		newBoardQueue_updateBoardPositions_NoLP(newBoardQueue_NoLP* pNBQ);


BOOL		newBoardQueue_configure_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDropConfig, DWORD boardsProcessedConfig, DWORD boardsInOvenConfig );
DWORD		newBoardQueue_getBoardsInOvenCount_NoLP(newBoardQueue_NoLP* pNBQ, UINT ui_Type);
DWORD		newBoardQueue_getBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ);
BOOL		newBoardQueue_isPastDeadBand_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_setBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ, DWORD noOfBoardsProcessed );
void		newBoardQueue_clearBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ);
DWORD		newBoardQueue_getMaxBoards_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_process_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_clearBoardsInOven_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_setSensorDistance_NoLP(newBoardQueue_NoLP* pNBQ, DWORD distanceBetweenSensorsInCounts );
DWORD		newBoardQueue_getSensorDistance_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_setBoardDeadBandDistance_NoLP(newBoardQueue_NoLP* pNBQ,  DWORD boardDeadBandInCounts );
void 		newBoardQueue_enableBoardStop_NoLP(newBoardQueue_NoLP* pNBQ, BOOL enableState);
const BoardData *  newBoardQueue_getBoardAnimationData_NoLP(newBoardQueue_NoLP* pNBQ);
void     newBoardQueue_setExitBoardDeadbandCounts_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDeadbandExitInCounts);
void		newBoardQueue_setBoardDropTolerance_NoLP(newBoardQueue_NoLP* pNBQ, DWORD bdt);
void		newBoardQueue_setBoardDropTime_NoLP(newBoardQueue_NoLP* pNBQ,UINT bTime);
void		newBoardQueue_setBoardDropToleranceNeg_NoLP(newBoardQueue_NoLP* pNBQ,DWORD bdt);
void 		newBoardQueue_enableSpraySensor_NoLP(newBoardQueue_NoLP* pNBQ, BOOL bEnable);
void  	newBoardQueue_addSprayLength_NoLP(newBoardQueue_NoLP* pNBQ, DWORD dwrLength);
void  	newBoardQueue_setSprayDist_NoLP(newBoardQueue_NoLP* pNBQ,DWORD dwDist);
BOOL 		newBoardQueue_checkForSpray_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_setBoardFCExtraTravel_NoLP(newBoardQueue_NoLP* pNBQ, DWORD extra);
void 		newBoardQueue_setBarcodeEvents_NoLP(UINT bcEvent);

BOOL		newBoardQueue_GetSmemaNoAnimation_NoLP( newBoardQueue_NoLP *pNBQ );
void		newBoardQueue_updateCurrentTime_NoLP( newBoardQueue_NoLP* pNBQ );
void		newBoardQueue_setTimeStampWithCurrentTime_NoLP( newBoardQueue_NoLP* pNBQ, LocalTime* pTimeStamp );
UINT		newBoardQueue_getNextIndex_NoLP(newBoardQueue_NoLP* pNBQ);
void		newBoardQueue_removeBoardFromCircularBuffer_NoLP(newBoardQueue_NoLP* pNBQ);

void		newBoardQueue_addOutstandingEntryEvents_NoLP(newBoardQueue_NoLP* pNBQ);

#endif
