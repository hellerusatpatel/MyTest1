/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "fluxcondensor.h"
#include "fluxheater.h"
#include "purge.h"
#include "alarm.h"
#include "oven.h"
#include "timer.h"
#include "tempzs.h"
#include "digitio.h"
#include "modbcrc.h"	// added by classview

extern DbContainer g_dbContainer;
#define AUTOCLEAN_T2_VALUE 2
AlarmQueue	* alarmQueueDb;
DIN			* digInDb;
DOUT		* digOutDb;
Timer		* elapseTimer;
Oven		* ovenDb;
TempZones	* tempZonesDb;
FluxHeater  * fluxHeat;
FluxHeater  * fluxHeat1;
FluxHeater  * fluxHeat2;
Nitrogen	* nitrogenControl;
Purge		* purgeControl;

//**************************************************************************
// class FluxCondensor_FluxCondensor
//
// Abstract:
// The Flux Condensor functions by having a cooling fan turned on during normal
// operation causing the flux to condense on cooling fins. After an elapsed interval
// time the fan is turned off causing the cooling fins to heat up and the flux
// to melt and collected. 
//
// Programmer: Steven Young
// Date 12/02/99
// 
//**************************************************************************
void FluxCondensor_init(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_init");
	pFluxCondensor->durationTime = 36000;	// duration lasts 60minutes as default converted to 10ths of seconds
	pFluxCondensor->intervalTime = 6048000; // 168 hours(1 week) converted to 10ths of seconds.
	pFluxCondensor->durationTimer = 0;
	pFluxCondensor->intervalTimer = 0;
	pFluxCondensor->autoCycle = FALSE;
	pFluxCondensor->manualCycle = FALSE;
	pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = FALSE;
	pFluxCondensor->recipeOptionEnabled = FALSE;
	pFluxCondensor->stateFlag = FLUX_NORMAL;
	pFluxCondensor->t3Timer	= 54000;			//90 minutes in tenths of seconds
	pFluxCondensor->countDownToCycleTimer = 0;
	pFluxCondensor->cycleDelayTimer = 24000;
	pFluxCondensor->bOvenAchievedOKStatus = FALSE;
	pFluxCondensor->bActivateFEBlowers = TRUE;
	pFluxCondensor->bRecipeCycleEndsWithNitro = FALSE;
	pFluxCondensor->bJobAtEndEnabled = FALSE;
	pFluxCondensor->m_bGen9 = FALSE;
	pFluxCondensor->phase1Time = 40;
	pFluxCondensor->phase2Time = 20;
	pFluxCondensor->phase1Timer = 0;
	pFluxCondensor->m_bType2 = FALSE;
	pFluxCondensor->m_uintAutoClean = 0;

	alarmQueueDb = &( g_dbContainer.alarmQueueDb);
	digInDb = &( g_dbContainer.digitalInDb	);
	digOutDb = &( g_dbContainer.digitalOutDb );
	elapseTimer = &( g_dbContainer.elapseTimer );
	ovenDb = &( g_dbContainer.ovenDb );
	tempZonesDb = &( g_dbContainer.tempZonesDb );
	fluxHeat = &( g_dbContainer.fluxHeater );
	fluxHeat1 = &( g_dbContainer.fluxHeater1 );
	fluxHeat2 = &( g_dbContainer.fluxHeater2 );
	nitrogenControl = &( g_dbContainer.nitrogen	);
	purgeControl = &( g_dbContainer.purge);
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	FluxCondensor_process

		After the elapsed period a cycle starts putting the state of the flux 
		condensor in CYCLE_IN_PROGRESS. If COOLDOWN is loaded during a 
		CYCLE_IN_PROGRESS the cycle will restart after all the temperature zones
		are within deadband. The interval timer is reset only after the cycle
		is terminated. This will allow for the computer to be shut down and the
		elapsed time reloaded causing a new cycle to start if the system is 
		shutdown before the CYCLE_IN_PROGESS terminates.

	GLOBALS:
	RETURNS:   void
	SEE ALSO:  
------------------------------------------------------------------------*/
void FluxCondensor_process(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_process");
	UINT jobNo = Oven_getJob(ovenDb);
	UINT tempJobNo = Oven_getTempJobNo(ovenDb);
	BOOL bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
	BOOL bHeaterContactor = FALSE;
	if ( pFluxCondensor->optionEnabled )
	{
		pFluxCondensor->currentTime = Timer_getCurrentTime10ths(elapseTimer);
		if(jobNo == COOLDOWN )
		{
			if(pFluxCondensor->recipeOptionEnabled) //For recipe option trigger the flux exhaust blowers
			{
			   if(!bCooldownComplete)
			   {
					*DOUT_GetAt(digOutDb, ODO_NEW_JOB_FIVESEC) = TRUE;
			   } 
				pFluxCondensor->bActivateFEBlowers = TRUE;
				if(tempJobNo == COOLDOWN)//without this test the output will be stepped on if it is the initially selected recipe
				{
					Purge_enableRecipeOutput(purgeControl, FALSE);
				}
			}

			pFluxCondensor->toggleState = FALSE; // If the toggle button is pressed in COOLDOWN make sure
								 // it does not get held over into operation mode.
			// need to accumulate time, during this time the oven can go into COOLDOWN
			// at whch point time is not to accumuate.
			if(!bCooldownComplete)
			{
				*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = TRUE;
			}
			bHeaterContactor = *DIN_GetAt(digInDb, ODO_HEATER_CONTACT);
			if (!bHeaterContactor)
			{	
				pFluxCondensor->lastCheckTime = pFluxCondensor->currentTime;
			}
	
			// indicate that the cycle had been interrupted only one time.
			// Must be done with at least two seconds before the cycle 
				
			if ( pFluxCondensor->stateFlag == CYCLE_IN_PROGRESS && !pFluxCondensor->fanOFF_AUTOCLEANJOB_Running )
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_CYCLE_INTERRUPTED, 0 );
				FluxCondensor_terminateCycle(pFluxCondensor, 2);
				if ( pFluxCondensor->autoCycle )
				{
					pFluxCondensor->stateFlag = INTERRUPTED_IN_AUTO;
				}
				else
				{
					pFluxCondensor->stateFlag = INTERRUPTED;
				}
			}
			else
			{
				if ( pFluxCondensor->stateFlag == CYCLE_IN_PROGRESS )	// autoclean recipe running
				{
					FluxCondensor_terminateCycle(pFluxCondensor, 0);	// When a new recipe or COOLDOWN is loaded that's the end of autoclean.
				}
			}

		}
		else  //NOT COOLDOWN
		{
			// do not terminate cycle if the cycle is interrupted by COOLDOWN.
			// Must wait for the Zones to complete startup cycle before it can
			// be toggled off.
			// check only when job no has changed.	
			if ( !pFluxCondensor->recipeOptionEnabled )
			{
				pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = FALSE;
				Oven_setAutoCleanFlux(ovenDb, FALSE);
			} //getJob insufficent, moved to dedicated functions

			
			if( pFluxCondensor->toggleState )
			{
				pFluxCondensor->toggleState = FALSE;	// Changed via the APP, reset via the VxD.
				if ( !pFluxCondensor->autoCycle )
				{
					switch ( pFluxCondensor->stateFlag )
					{
						case FLUX_NORMAL:
							FluxCondensor_startCycle(pFluxCondensor);
							pFluxCondensor->manualCycle = TRUE;
							break;
						case CYCLE_IN_PROGRESS:
							FluxCondensor_terminateCycle(pFluxCondensor, 1);
							break;
						default:
							break;
					}
				}
			}

			switch ( pFluxCondensor->stateFlag )
			{
				case FLUX_NORMAL:
					if(pFluxCondensor->m_bType2 && !pFluxCondensor->m_bGen9)
					{
						*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
					}
					else
					{
						*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = TRUE;
					}
					
					pFluxCondensor->intervalTimer += differenceWithRollover( pFluxCondensor->currentTime, pFluxCondensor->lastCheckTime);
					pFluxCondensor->lastCheckTime = pFluxCondensor->currentTime;
					if( (pFluxCondensor->intervalTimer >= pFluxCondensor->intervalTime) && !pFluxCondensor->recipeOptionEnabled )//timed mode
					{
						pFluxCondensor->autoCycle = TRUE;
						FluxCondensor_startCycle(pFluxCondensor);
					}
					if( pFluxCondensor->fanOFF_AUTOCLEANJOB_Running)//recipe mode, autoclean job running
					{

						pFluxCondensor->autoCycle = TRUE;
						FluxCondensor_startCycle(pFluxCondensor);
						*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
						if(pFluxCondensor->m_bGen9)
						{
							pFluxCondensor->bActivateFEBlowers = FALSE;
						}
					}			
					break;
				case CYCLE_IN_PROGRESS:
					if(pFluxCondensor->m_bGen9)
					{
						pFluxCondensor->phase1Timer = 
							differenceWithRollover( pFluxCondensor->currentTime, 
								pFluxCondensor->startCycleTime );
						if(pFluxCondensor->phase1Timer >= pFluxCondensor->phase1Time)
						 //in phase 2 turn on output
						{
							//end of phase 1, fire message for beginning of phase
							if(!pFluxCondensor->bActivateFEBlowers)
							{
								//not adding the event if there is no phase 2
								if(pFluxCondensor->phase2Time) 
								{
									AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, 
										FLUXCON_PHASE2, 0 );
								}
							}
							pFluxCondensor->bActivateFEBlowers = TRUE;
							if(pFluxCondensor->phase1Timer >= (pFluxCondensor->phase1Time + pFluxCondensor->phase2Time))//cycle to end
							{								
								if(!pFluxCondensor->bJobAtEndEnabled)
								{
									Nitrogen_setRunNitroInCooldown(nitrogenControl, pFluxCondensor->bRecipeCycleEndsWithNitro);
									Purge_setOutputOnForCooldown(purgeControl, TRUE);
									Oven_setJob(ovenDb, COOLDOWN );
								}
								else
								{
									FluxCondensor_terminateCycle(pFluxCondensor, 0);	
								}								
							}	
						}
						else //still in phase1 dout25 off
						{
							pFluxCondensor->bActivateFEBlowers	= FALSE;
						}
					}
					else
					{
						pFluxCondensor->durationTimer = differenceWithRollover( pFluxCondensor->currentTime, pFluxCondensor->startCycleTime );
						if ( (pFluxCondensor->durationTimer >= pFluxCondensor->durationTime) && !pFluxCondensor->fanOFF_AUTOCLEANJOB_Running )
						{
							FluxCondensor_terminateCycle(pFluxCondensor, 0);
						}
						if(pFluxCondensor->durationTimer >= pFluxCondensor->durationTime )
						{
							if(pFluxCondensor->recipeOptionEnabled )
							{	
								if(!pFluxCondensor->bJobAtEndEnabled)
								{
									Nitrogen_setRunNitroInCooldown(nitrogenControl, 
										pFluxCondensor->bRecipeCycleEndsWithNitro);
									Purge_setOutputOnForCooldown(purgeControl, TRUE);
									Oven_setJob(ovenDb, COOLDOWN );
								}
								else
								{
									FluxCondensor_terminateCycle(pFluxCondensor, 0);						
								}
					
							}
						}
						pFluxCondensor->bActivateFEBlowers=FALSE;//per tushar gen 5 output is off during cycle
					}
					break;
				case INTERRUPTED:
				case INTERRUPTED_IN_AUTO:		
					// If interrupted in the middle of an auto cycle the autocycle flag must reamain true if
					// it was true in order to prevent the user from terminating the cycle.
					if ( pFluxCondensor->stateFlag == INTERRUPTED_IN_AUTO )
					{
						pFluxCondensor->autoCycle = TRUE;
					}
					
					if ( TempZones_isAllZonesInDeadBand(tempZonesDb) && *DIN_GetAt(digInDb, ODO_HEATER_CONTACT) )
					{
						FluxCondensor_startCycle(pFluxCondensor);
					}
					
					break;
				default:
					FluxCondensor_terminateCycle(pFluxCondensor, 1);
					break;
			}
			if(pFluxCondensor->recipeOptionEnabled) //For recipe option trigger the flux exhaust blowers based on processing conditions
			{
			   if(!Oven_isCOOLDOWNcomplete(ovenDb) || !Oven_getJob(ovenDb) == COOLDOWN)
			   {
					if(pFluxCondensor->bActivateFEBlowers)
					{
						*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = TRUE;
					}
					else
					{
						*DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_NEW_JOB_FIVESEC) = FALSE;
					}
			   } 
			}
		}
	}
	return;
}		
			
//**************************************************************************
// class FluxCondensor_startCycle()
//
// Abstract:
// During a Flux Condensor Heat Up Cycle the elapsed time will stop accumulating.
// The cycle requires the heat from the temperature zones to melt the flux. The
// cycle cannot begin until all zones are at temperature.   	
//
// Programmer: Steven Young
// Date 12/07/99
// 
//**************************************************************************
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxCondensor_startCycle
			
			start cycle

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxCondensor_startCycle(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_startCycle");
	BOOL bFluxFail = FALSE;
	BOOL bFlux1Fail = FALSE;
	BOOL bFlux2Fail = FALSE;
	BOOL bTestFlux1 = FALSE;
	BOOL bTestFlux2 = FALSE;
	BOOL bFluxInDeadband = FALSE;
	BOOL bFluxHeaterInDeadband = FALSE;
	BOOL bFluxHeater1InDeadband = FALSE;
	BOOL bFluxHeater2InDeadband = FALSE;
	BOOL bTempzonesInDeadband = FALSE;
	bTempzonesInDeadband = TempZones_isAllZonesInDeadBand(tempZonesDb);
	
	if(pFluxCondensor->recipeOptionEnabled)
	{
		if(!pFluxCondensor->m_bGen9)
		{
			if(pFluxCondensor->m_bType2)
			{
				pFluxCondensor->bActivateFEBlowers = FALSE;
			}
			else
			{
				pFluxCondensor->bActivateFEBlowers = (FluxHeater_getOutput25Flag(fluxHeat) || FluxHeater_getOutput25Flag(fluxHeat1) || FluxHeater_getOutput25Flag(fluxHeat2));//IF either are in startup deactivate output
			}	
		}
		bTestFlux1 = FluxHeater_isFluxHeaterEnabled(fluxHeat1);
		bTestFlux2 = FluxHeater_isFluxHeaterEnabled(fluxHeat2);
		if(bTestFlux1)
		{
			bFlux1Fail =(!FluxHeater_isInDeadBand(fluxHeat1) || !FluxHeater_isInDeadBandRangeEnabled(fluxHeat1) );
		}
		if(bTestFlux2)
		{
			bFlux2Fail =(!FluxHeater_isInDeadBand(fluxHeat2) || !FluxHeater_isInDeadBandRangeEnabled(fluxHeat2) );
		}
	
		bFluxFail =  !FluxHeater_isInDeadBandRangeEnabled(fluxHeat);
		bFluxInDeadband = FluxHeater_isInDeadBand(fluxHeat);
		if(!bFluxInDeadband)
		{
			bFluxFail = TRUE;
		}
		if ( (!bTempzonesInDeadband || bFluxFail || 
			bFlux1Fail || bFlux2Fail) &&
			!pFluxCondensor->bOvenAchievedOKStatus)
		{

			if(pFluxCondensor->m_bGen9) //outputs off until cycle start
			{
				pFluxCondensor->bActivateFEBlowers = FALSE;
			}
			else
			{
				pFluxCondensor->bActivateFEBlowers = (FluxHeater_getOutput25Flag(fluxHeat) || FluxHeater_getOutput25Flag(fluxHeat1) || FluxHeater_getOutput25Flag(fluxHeat2));//IF either are in startup deactivate output
			}
			pFluxCondensor->stateFlag = FLUX_NORMAL;
			if( (Timer_getCurrentTime10ths(elapseTimer) - pFluxCondensor->countDownToCycleTimer) > pFluxCondensor->t3Timer) //temperature zones have timed out
			{
				FluxCondensor_terminateCycle(pFluxCondensor, 3);
			}
		}
		else
		{
			if(pFluxCondensor->m_bGen9) //cycle startED, Outputs on
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCON_PHASE1, 0 );
				pFluxCondensor->bActivateFEBlowers = TRUE;
			}

			pFluxCondensor->bOvenAchievedOKStatus = TRUE;
			pFluxCondensor->stateFlag = CYCLE_IN_PROGRESS;
			pFluxCondensor->startCycleTime = Timer_getCurrentTime10ths(elapseTimer);
			if ( pFluxCondensor->autoCycle )
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_AUTO_CYCLE_START, 0 );
			}
			else
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_MANUAL_CYCLE_START, 0 );
			}
		}
	}
	else
	{
		bFluxHeaterInDeadband = FluxHeater_isInDeadBand(fluxHeat);
		bFluxHeater1InDeadband = FluxHeater_isInDeadBand(fluxHeat1);
		bFluxHeater2InDeadband = FluxHeater_isInDeadBand(fluxHeat2);

		if ( !pFluxCondensor->fanOFF_AUTOCLEANJOB_Running && 
				(!bTempzonesInDeadband || 
				(pFluxCondensor->recipeOptionEnabled && !bFluxHeaterInDeadband) || 
				(pFluxCondensor->recipeOptionEnabled && !bFluxHeater1InDeadband) || 
				(pFluxCondensor->recipeOptionEnabled && !bFluxHeater2InDeadband)))
		{
			pFluxCondensor->stateFlag = FLUX_NORMAL;
		}
		else
		{
			pFluxCondensor->stateFlag = CYCLE_IN_PROGRESS;
			*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
			pFluxCondensor->startCycleTime = Timer_getCurrentTime10ths(elapseTimer);
			if ( pFluxCondensor->autoCycle )
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_AUTO_CYCLE_START, 0 );
			}
			else
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_MANUAL_CYCLE_START, 0 );
			}
		}
	}	
	return;	 
}

void FluxCondensor_terminateCycle(FluxCondensor* pFluxCondensor, unsigned int completionState )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_terminateCycle");

	pFluxCondensor->stateFlag = FLUX_NORMAL;
	pFluxCondensor->bActivateFEBlowers = TRUE;

	// autoCycle = FALSE;
	// manualCycle = FALSE; jwf 3/5/01 to correct hopefully the 
	// incorrect auto/manual state after resumption from cooldown

	pFluxCondensor->lastCheckTime = pFluxCondensor->currentTime;
	if(!Oven_isCOOLDOWNcomplete(ovenDb) || !Oven_getJob(ovenDb) == COOLDOWN)
		*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = TRUE;
	if(pFluxCondensor->recipeOptionEnabled)
	{
		//(*(digOutDb))[ODO_NITROGEN_LOW_FLOW] = FALSE;
		Purge_enableRecipeOutput(purgeControl, FALSE);
	}
	
	switch ( completionState )
	{
	case 0:
		pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = FALSE;
		AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_CYCLE_COMPLETE, 0);
		pFluxCondensor->intervalTimer = 0;
		pFluxCondensor->autoCycle = FALSE;
		pFluxCondensor->manualCycle = FALSE;
		break;
	case 1:	
		AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_CYCLE_TERMINATED_BY_OPERATOR, 0 );
		break;
	case 2:
		AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_CYCLE_TERMINATED, 0);
		break;
	case 3:
		AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXCONDENSOR_CYCLE_ABORTED, 0);
		break;
	}
}

void FluxCondensor_setDurationTime(FluxCondensor* pFluxCondensor, DWORD durationTimeInMinutes )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setDurationTime");
	if ( durationTimeInMinutes <= 60 )
	{
		pFluxCondensor->durationTime  = durationTimeInMinutes * 600;		// convert to 10ths of seconds
	}
}

DWORD FluxCondensor_getDurationTime(FluxCondensor* pFluxCondensor)
{  
	PARAM_CHECK_RETURN( pFluxCondensor, "FluxCondensor_getDurationTime", 0);
	return pFluxCondensor->durationTime/600;
}

void FluxCondensor_setIntervalTime(FluxCondensor* pFluxCondensor, DWORD intervalTimeInHours )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setIntervalTime");
	if ( intervalTimeInHours <= 336 )  // 2 weeks in hours.
	{
		pFluxCondensor->intervalTime = intervalTimeInHours * 36000;	// convert to 10ths of seconds
	}
}

DWORD FluxCondensor_getIntervalTime (FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK_RETURN( pFluxCondensor, "FluxCondensor_getIntervalTime", 0);
	return pFluxCondensor->intervalTime/36000;
}

DWORD FluxCondensor_getElapsedTime10ths(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK_RETURN( pFluxCondensor, "FluxCondensor_getElapsedTime10ths", 0);
	return pFluxCondensor->intervalTimer;		// save the elapsed time in 10ths of seconds to registry
}

void FluxCondensor_setElapsedTime10ths(FluxCondensor* pFluxCondensor, DWORD elapsedTime )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setElapsedTime10ths");
	pFluxCondensor->intervalTimer = elapsedTime;
}

void FluxCondensor_enableOption(FluxCondensor* pFluxCondensor, BOOL bOptionEnabled )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_enableOption");
	pFluxCondensor->optionEnabled = bOptionEnabled;
}

void FluxCondensor_recipeOption(FluxCondensor* pFluxCondensor, BOOL bRecipeOptionEnabled )
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_recipeOption");
	pFluxCondensor->recipeOptionEnabled = bRecipeOptionEnabled;
}

BOOL FluxCondensor_setToggle(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK_RETURN( pFluxCondensor, "FluxCondensor_setToggle", 0);
	pFluxCondensor->toggleState = TRUE;
	return(pFluxCondensor->toggleState);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxCondensor_recipeStarted
			
	
 GLOBALS:	fluxHeat,fluxHeat1, fluxHeat2
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxCondensor_recipeStarted(FluxCondensor* pFluxCondensor)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_recipeStarted");
	BOOL bCooldownComplete = FALSE;
	BOOL cooldownJob = FALSE;
	UINT nJob = COOLDOWN;
	BOOL bFlux1Enabled = FALSE;
	BOOL bFlux2Enabled = FALSE;
	enum FluxCondensorState pState = FLUX_NORMAL;
	if(pFluxCondensor->optionEnabled)//do nothing if the fluxcondensor is inactive
	{
		pState = pFluxCondensor->stateFlag;
		if ( pFluxCondensor->recipeOptionEnabled )
		{
			if(pFluxCondensor->m_uintAutoClean == AUTOCLEAN_T2_VALUE)
			{
				pFluxCondensor->m_bType2 = TRUE;
			}
			else
			{
				pFluxCondensor->m_bType2 = FALSE;
			}
			fluxHeat->m_bType2 = pFluxCondensor->m_bType2;
			fluxHeat1->m_bType2 = pFluxCondensor->m_bType2;
			fluxHeat2->m_bType2 = pFluxCondensor->m_bType2;

			pFluxCondensor->stateFlag = FLUX_NORMAL;
			pFluxCondensor->lastCheckTime = pFluxCondensor->currentTime;
			bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
			nJob = Oven_getJob(ovenDb);
			cooldownJob = ( nJob== COOLDOWN);

			if(!bCooldownComplete || !cooldownJob)
			{
				*DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = FALSE;
			}
			else
			{
			  *DOUT_GetAt(digOutDb, ODO_1088_DIGITAL_FAN_FLUX_FILTER) = TRUE;
			}
		   pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = FALSE;
		   Oven_setAutoCleanFlux(ovenDb, FALSE);

		   if (pFluxCondensor->m_uintAutoClean)
		   {
			    Purge_enableRecipeOutput(purgeControl, TRUE);
				pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = TRUE;
				Oven_setAutoCleanFlux(ovenDb, TRUE);
				pFluxCondensor->countDownToCycleTimer = Timer_getCurrentTime10ths(elapseTimer);
				pFluxCondensor->bOvenAchievedOKStatus = FALSE;
				FluxHeater_setIfInDeadBand(fluxHeat, FALSE);
				bFlux1Enabled = FluxHeater_isFluxHeaterEnabled(fluxHeat1);
				bFlux2Enabled = FluxHeater_isFluxHeaterEnabled(fluxHeat2);
				if(bFlux1Enabled)
				{
					FluxHeater_setIfInDeadBand(fluxHeat1, FALSE);
				}
				if(bFlux2Enabled)
				{
					FluxHeater_setIfInDeadBand(fluxHeat2, FALSE);
				}
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUXCONDENSOR_TIMERS_STARTED, 0 );
		   }
		   else 
		   {
				pFluxCondensor->bOvenAchievedOKStatus = TRUE;
				pFluxCondensor->fanOFF_AUTOCLEANJOB_Running = FALSE;	// When the fan is off, the flux is melting or cleaning.
				Oven_setAutoCleanFlux(ovenDb, FALSE);
				Purge_enableRecipeOutput(purgeControl, FALSE);
				if( !pFluxCondensor->manualCycle )
				{
					if(pState == CYCLE_IN_PROGRESS)
					{
						FluxCondensor_terminateCycle(pFluxCondensor, 0);
					}
					else
					{
						pFluxCondensor->intervalTimer = 0;
						pFluxCondensor->autoCycle = FALSE;
						pFluxCondensor->manualCycle = FALSE;
					}
				}
				if(!pFluxCondensor->m_bGen9)
				{
					pFluxCondensor->bActivateFEBlowers = TRUE;	
				}
			}
	    }
	}
	return;
}

void FluxCondensor_setT3Timer(FluxCondensor* pFluxCondensor, DWORD t3TimeInMinutes)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setT3Timer");
	pFluxCondensor->t3Timer = t3TimeInMinutes * 600; //convert from minutes to 1/10 second units
}

void FluxCondensor_setDelayTimer(FluxCondensor* pFluxCondensor, DWORD dTimeInMinutes)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setDelayTimer");
	pFluxCondensor->cycleDelayTimer = dTimeInMinutes * 600;  //convert from minutes to 1/10 second units
}

///////////////////////////////////////////////////////////////////////////////
//
//void FluxCondensor_recipePreStart(BOOL bRecipeOptionEnabled)
//
//Currently we do initialization in recipeStart.  This can cause a problem with the test
//to determine flux condensation start, basically the cycle believes it is starting in the 
//period between the initialization of the fluxheaters and the flux condensors.  To correct
//this we will terminate the existing cycle before initializing the flux heaters, thus the recipe
//preStart message(function)
//
//////////////////////////////////////////////////////////////////////////////////
void FluxCondensor_recipePreStart(FluxCondensor* pFluxCondensor, BOOL bRecipeOptionEnabled)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_recipePreStart");
	if(pFluxCondensor->optionEnabled)//do nothing if the fluxcondensor is inactive
	{
		if(pFluxCondensor->stateFlag == CYCLE_IN_PROGRESS)
			FluxCondensor_terminateCycle(pFluxCondensor, 1);
	}
}

void FluxCondensor_gen9Option(FluxCondensor* pFluxCondensor, BOOL bGen9)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_gen9Option");
	pFluxCondensor->m_bGen9 = bGen9;
	FluxHeater_setGen9(fluxHeat, bGen9);
	FluxHeater_setGen9(fluxHeat1, bGen9);
	FluxHeater_setGen9(fluxHeat2, bGen9);
}

void FluxCondensor_setPhase1Time(FluxCondensor* pFluxCondensor, int iTime)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setPhase1Time");
	pFluxCondensor->phase1Time = iTime;
}

void FluxCondensor_setPhase2Time(FluxCondensor* pFluxCondensor, int iTime)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setPhase2Time");
	pFluxCondensor->phase2Time = iTime;
}

void FluxCondensor_setCycleEndNitro(FluxCondensor* pFluxCondensor, BOOL bWithNitro)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setCycleEndNitro");
	pFluxCondensor->bRecipeCycleEndsWithNitro = bWithNitro;
}

void FluxCondensor_setJobAtEnd(FluxCondensor* pFluxCondensor, BOOL bJob)
{
	PARAM_CHECK( pFluxCondensor, "FluxCondensor_setJobAtEnd");
	pFluxCondensor->bJobAtEndEnabled = bJob;
}

void FluxCondensor_useHighFluxHeater(FluxCondensor* pFluxCondensor, BOOL bUse)
{
	PARAM_CHECK(pFluxCondensor, "FluxCondensor_setJobAtEnd");
	if(bUse)
	{
		fluxHeat = &( g_dbContainer.fluxHeater3);
		fluxHeat1 = &( g_dbContainer.fluxHeater4);
	}
	else
	{
		fluxHeat = &( g_dbContainer.fluxHeater);
		fluxHeat1 = &( g_dbContainer.fluxHeater1);
	}
}

