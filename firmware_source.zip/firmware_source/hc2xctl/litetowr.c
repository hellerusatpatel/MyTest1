//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: litetowr.c
//
// Description: light tower processing
//
// This is a trade secret of Heller Industries, Inc. and is protected by copyright.
// All unauthorized uses prohibited.
//
// Edit History:
//
// 15-Dec-15  FJN  Signal alarms for all transitions to RED and for OFF to YELLOW
//*****************************************************************************
#include "contain.h"
#include "litetowr.h"
#include "digitio.h"
#include "rails.h"
#include "flasher.h"
#include "belt.h"
#include "purge.h"
#include "tempzs.h"
#include "alarm.h"
#include "oven.h"
#include "nitrogen.h"
#include "fluxheater.h"
#include "cbs.h"
#include "hzblower.h"
#include <linux/poll.h>



extern DbContainer g_dbContainer;

TempZones	*tempZones;
DOUT		*digOutDb;
DIN			*digInDb;
AlarmQueue 	*alarmQueueDb;
Oven		*ovenDb;
Rails		*railsDb;
Nitrogen	*nitrogen;

Flasher		*flasherSPChange;
Flasher		*flasherReady;
Flasher		*flasherReadyBoards;
Flasher		*flasherWarning;
Flasher		*flasherAlarmCooldown;
Flasher		*flasherEstopCooldown;

Belts		*beltsDb;
FluxHeater  *fluxHeater;
FluxHeater  *fluxHeater1;
FluxHeater  *fluxHeater2;
FluxHeater  *fluxHeater3;
FluxHeater  *fluxHeater4;
CBS			*cbs;
Purge		*purge;
GlobalBlower			*globalBlower;
HeatZoneBlowers		    *heatZoneBlowers;
AnalogFan				*analogFan;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_init
			
			

 GLOBALS:	g_dbContainer
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LightTower_init(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_init");

	pLightTower->lightState = TRUE;

	pLightTower->lightColor1 = Light_OFF;
	pLightTower->lightColor2 = Light_OFF;

	pLightTower->smemaAmber1 = FALSE;
	pLightTower->smemaRed1 = FALSE;
	pLightTower->smemaAmber2 = FALSE;
	pLightTower->smemaRed2 = FALSE;

	pLightTower->iToggleForSonyGreenLight = FALSE;

	pLightTower->bODONewJobFree = TRUE;
	pLightTower->m_bRedOnBoardError = FALSE;

	tempZones = &( g_dbContainer.tempZonesDb);
	digOutDb = &( g_dbContainer.digitalOutDb);
	digInDb = &( g_dbContainer.digitalInDb);
	alarmQueueDb = &( g_dbContainer.alarmQueueDb);
	railsDb = &( g_dbContainer.railsDb);
	ovenDb = &( g_dbContainer.ovenDb);
	nitrogen = &( g_dbContainer.nitrogen);

	flasherSPChange = &(g_dbContainer.flasherSPChange);
	flasherReady = &(g_dbContainer.flasherReady);
	flasherReadyBoards = &(g_dbContainer.flasherReadyBoards);
	flasherWarning = &(g_dbContainer.flasherWarning);
	flasherAlarmCooldown = &(g_dbContainer.flasherAlarmCooldown);
	flasherEstopCooldown = &(g_dbContainer.flasherEstopCooldown);

	beltsDb = &( g_dbContainer.beltsDb);
	cbs = &( g_dbContainer.cbs);

	fluxHeater = &( g_dbContainer.fluxHeater	);
	fluxHeater1 = &( g_dbContainer.fluxHeater1	);
	fluxHeater2 = &( g_dbContainer.fluxHeater2  );
	fluxHeater3 = &( g_dbContainer.fluxHeater3	);
	fluxHeater4 = &( g_dbContainer.fluxHeater4  );

	globalBlower = &( g_dbContainer.globalBlower  );
	heatZoneBlowers = &( g_dbContainer.heatZoneBlowers  );
	analogFan = &( g_dbContainer.analogFan  );

	purge = &( g_dbContainer.purge);
	pLightTower->bGreenError = FALSE;
	pLightTower->m_iCommLossOption=0;
	pLightTower->m_lLastCommandTime = jiffies;	
	pLightTower->m_bCommLoss = FALSE;
	pLightTower->selfAckAlarmNo=0;
	pLightTower->dwrdInputTimeStart=pLightTower->dwrdBarcodeTime=Timer_getCurrentTime10ths( &( g_dbContainer.elapseTimer ));
	pLightTower->bBarcodeActive=FALSE;
	pLightTower->bVIPMode = FALSE;
	pLightTower->bLT1=FALSE;
	pLightTower->bLT2=FALSE;
	pLightTower->bLT3=FALSE;
	pLightTower->bLT4=FALSE;
	pLightTower->bLTSpecialHigh=FALSE;
	pLightTower->bLampsOff=FALSE;
	pLightTower->bLTSpecialMode=FALSE;
	pLightTower->dwrdLTInput=IDI_NULL;
	pLightTower->dwrdLTTime=0;
	pLightTower->bLTSpecialSolid=FALSE;

	pLightTower->m_LT2_bEnable = FALSE;
	pLightTower->m_LT2_DORed = ODO_NULL;
	pLightTower->m_LT2_DOYellow = ODO_NULL;
	pLightTower->m_LT2_DOGreen = ODO_NULL;
	pLightTower->mbScannerHold = FALSE;	

	pLightTower->m_bAudibleAlarmSet = FALSE;
	pLightTower->m_ltOvenState1 = LTOS_NONE;
	pLightTower->m_ltOvenState2 = LTOS_NONE;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_getCombinedStatus


 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT LightTower_getCombinedStatus(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_getCombinedStatus", 0);

	UINT uiReturn = pLightTower->lightColor1;

	if ( pLightTower->m_LT2_bEnable )
	{
		if ( (pLightTower->lightColor1 == GREEN) &&
			(pLightTower->lightColor2 == GREEN) )
		{
			uiReturn = GREEN;
		}
		else
		{
			// choose the worse state of the two
			if ( (pLightTower->lightColor1 == RED) || 
				(pLightTower->lightColor2 == RED) )
			{
				uiReturn = RED;
			}
			else if ( (pLightTower->lightColor1 == AMBER) || 
				(pLightTower->lightColor2 == AMBER) )
			{
				uiReturn = AMBER;
			}
			else
			{
				uiReturn = pLightTower->lightColor1;
			}
		}
	}

	if ( uiReturn == GREEN )
	{
		if ( pLightTower->bAutoModeYellow == TRUE )//allow smema but don't allow green lt
		{
			if(pLightTower->bLTSpecialSolid)
			{
				uiReturn = YELLOW_SPECIAL_SOLID;	
			}
			else	
			{
				uiReturn = YELLOW_SPECIAL;
			}
		}
	}

	return uiReturn;
}

UINT LightTower_getLT1Status(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_getLT1Status", 0);

	UINT uiReturn = pLightTower->lightColor1;
	if ( uiReturn == GREEN )
	{
		if ( pLightTower->bAutoModeYellow == TRUE )//allow smema but don't allow green lt
		{
			if(pLightTower->bLTSpecialSolid)
			{
				uiReturn = YELLOW_SPECIAL_SOLID;	
			}
			else	
			{
				uiReturn = YELLOW_SPECIAL;
			}
		}
	}

	return uiReturn;
}

UINT LightTower_getLT2Status(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_getLT2Status", 0);

	UINT uiReturn = GREEN;

	if ( pLightTower->m_LT2_bEnable )
	{
		uiReturn = pLightTower->lightColor2;
		if ( uiReturn == GREEN )
		{
			if ( pLightTower->bAutoModeYellow == TRUE )//allow smema but don't allow green lt
			{
				if(pLightTower->bLTSpecialSolid)
				{
					uiReturn = YELLOW_SPECIAL_SOLID;	
				}
				else	
				{
					uiReturn = YELLOW_SPECIAL;
				}
			}
		}
	}

	return uiReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LightTower_process( LightTower* pLightTower)
				main loop for the light tower(s)
				

	RETURNS:   void
------------------------------------------------------------------------*/
void LightTower_process( LightTower* pLightTower)
{
	enum LT_OVEN_STATE ltNewOvenState1;
	enum LT_OVEN_STATE ltNewOvenState2;
	enum Light_States lampColor;
	BOOL bSetAudibleAlarm;
	BOOL bEStop;

	BOOL bShared_Amber;
	BOOL bLT1_Amber;
	BOOL bLT2_Amber;
	BOOL bRailsTest;
	BOOL bLT1_SPChange;	// used for new recipes, or for set-point changes.

	BOOL bLT2_SPChange;	// used for new recipes, or for set-point changes.	DWORD dwrdJob;
	BOOL bCooldownComplete;
	int* pInt1;
	int* pInt2;
	DWORD dwrdJob;

	BOOL bRail0SPChanged;
	BOOL bRail1SPChanged;
	BOOL bRail2SPChanged;
	BOOL bRail3SPChanged;
	DWORD dwrdJiffies;

	BOOL bAlarmPresent;
	BOOL bPurgeRed;
	BOOL bTempzonesInDeadband;
	BOOL bFluxHeater1;
	BOOL bFluxHeater2;

	BOOL bFluxHeater3;
	BOOL bFluxHeater4;
	BOOL bFluxHeater5;
	DWORD dwrdBeltState;
	BOOL bOvenFlux;

	BOOL bFluxInDev1;
	BOOL bFluxInDev2;
	BOOL bFluxInDev3;
	BOOL bFluxInDev4;
	BOOL bFluxInDev5;

	SHORT sDeviation;
	BOOL bBarcodeHalt;
	BOOL bFanFlush;
	BOOL bCooldownPending;
	BOOL bPresetWarn1;
	BOOL bPresetWarn2;
	BOOL bFirstSupport;
	UINT sBeltState;
	UINT uSmemaAllow;
	UINT uSmemaSuspend;

	bPresetWarn1 = FALSE;
	bPresetWarn2 = FALSE;
	bFirstSupport = FALSE;
	sBeltState = 0;
	uSmemaAllow = 0;
	uSmemaSuspend = 0;
	bOvenFlux = FALSE;
	bFanFlush = FALSE;
	bBarcodeHalt = FALSE;
	sDeviation = 0;
	bFluxInDev1 = FALSE;

	bFluxInDev2 = FALSE;
	bFluxInDev3 = FALSE;
	bFluxInDev4 = FALSE;
	bFluxInDev5 = FALSE;
	bFluxHeater5 = FALSE;

	dwrdBeltState = 0;
	bAlarmPresent = FALSE;
	bPurgeRed = FALSE;
	bCooldownPending = FALSE;

	bTempzonesInDeadband = FALSE;
	bFluxHeater1 = FALSE;
	bFluxHeater2 = FALSE;
	bFluxHeater3 = FALSE;
	bFluxHeater4 = FALSE;
	dwrdJiffies = 0;

	bRail0SPChanged = FALSE;
	bRail1SPChanged = FALSE;
	bRail2SPChanged = FALSE;
	bRail3SPChanged = FALSE;

	pInt1 = NULL;
	pInt2 = NULL;
	dwrdJob = COOLDOWN;
	bCooldownComplete = FALSE;
	ltNewOvenState1 = LTOS_NONE;

	ltNewOvenState2 = LTOS_NONE;
	lampColor = Light_OFF;
	bSetAudibleAlarm = FALSE;
	bEStop = FALSE;
	bShared_Amber = FALSE;

	bLT1_Amber = FALSE;
	bLT2_Amber = FALSE;
	bRailsTest = TRUE;
	bLT1_SPChange = FALSE;	// used for new recipes, or for set-point changes.
	bLT2_SPChange = FALSE;	// used for new recipes, or for set-point changes.

	if(NULL != pLightTower)
	{
		LightTower_automaticMode(pLightTower);

		if ( pLightTower->m_iCommLossOption )
		{
			dwrdJiffies = g_dbContainer.m_jiffies + COMM_LOSS_JIFFIES;
			if ( jiffies > dwrdJiffies ) //comm loss timer time~to windows timeout 3890 setting to 5 sec per Tushar not wanting the hc2 to alert before the pc
			{
				pLightTower->m_bCommLoss = TRUE;
			}
			else
			{
				pLightTower->m_bCommLoss = FALSE;
			}
		}

		if ( pLightTower->LiteTowrEnabled )
		{
		   /*********************************************************************************************
			*
			* turning a light on initializes a count to 1 and after 50 times through the processing routine 
			* the digital output is enabled, should the condition be set to false, the digital output is 
			* set to false
			*
			*********************************************************************************************/     

			/*****************************************************************************************
			*
			* Leave audible alarm on even when COOLDOWN is complete. Audible Alarm is enabled
			* when an alarm exists or in the event of a Board Drop.SDY - 11/16/99
			*
			*****************************************************************************************/
			LightTower_setGreenError(pLightTower, ovenDb->m_bPendingCooldown);

			/*****************************************************************************************
			*   If oven is in cooldown mode and cooldown is complete set all the lights off     
			*   else process other conditions
			*
			*****************************************************************************************/

			bSetAudibleAlarm = FALSE;
			dwrdJob = Oven_getJob(ovenDb);
			bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);	
			if ( ( dwrdJob == COOLDOWN ) && 
				bCooldownComplete == TRUE )
			{
				pInt1 =(int*) &ltNewOvenState1;
				pInt2 = (int*) &ltNewOvenState2;
				bSetAudibleAlarm = LightTower_processHardCooldown( pInt1, pInt2);
			}
			/*****************************************************************************************
			*   The following else routine encapsulates the rest of the process routine    
			*   if not in cooldow and cooldown complete state this code is executed
			*
			*****************************************************************************************/
			else                                                     
			{
				pLightTower->sonyBoardDrop = FALSE;

				if (pLightTower->m_bRedOnBoardError == TRUE )                                         
				{
					if (AlarmQueue_getBoardDropStatusLightTower(alarmQueueDb) )                                
					{
						pLightTower->sonyBoardDrop = TRUE;
					}                                                                      
				}    

				bAlarmPresent = AlarmQueue_alarmsPresent(alarmQueueDb);
				bPurgeRed = Purge_lightTowerShouldBeRed(purge);

				if ( bAlarmPresent == TRUE || 
					( pLightTower->sonyBoardDrop == TRUE ) || 
					bPurgeRed )
				{
					bEStop = AlarmQueue_hasEStopAlarm(alarmQueueDb);
					if ( bEStop )
					{
						lampColor = flasherEstopCooldown->flasherColor;
						pLightTower->lightState = Flasher_getFlashState(flasherEstopCooldown);
						bSetAudibleAlarm = flasherEstopCooldown->m_bAudibleAlarm;
						ltNewOvenState1 = LTOS_ESTOP;
						ltNewOvenState2 = LTOS_ESTOP;

						LightTower_SetLightColor( pLightTower, lampColor, FALSE );
						LightTower_LT2_SetLightColor( pLightTower, lampColor, FALSE );
					}
					else
					{
						// This is RED on warning, so treat as ALARM COOLDOWN.
						lampColor = flasherAlarmCooldown->flasherColor;
						pLightTower->lightState = Flasher_getFlashState(flasherAlarmCooldown);
						bSetAudibleAlarm = flasherAlarmCooldown->m_bAudibleAlarm;
						ltNewOvenState1 = LTOS_ALARM;
						ltNewOvenState2 = LTOS_ALARM;

						LightTower_SetLightColor( pLightTower, lampColor, FALSE );
						LightTower_LT2_SetLightColor( pLightTower, lampColor, FALSE );
					}
				}
				else if ( pLightTower->bVIPMode )
				{
					// 
					// VIP mode
					//

					pLightTower->lightState = Flasher_ON;
					bSetAudibleAlarm = FALSE;
					ltNewOvenState1 = LTOS_NONE;
					ltNewOvenState2 = LTOS_NONE;

					LightTower_AmberLampOFF(pLightTower);
					LightTower_GreenLampOn(pLightTower);

					if ( pLightTower->m_LT2_bEnable )
					{
						LightTower_LT2_AmberLampOFF(pLightTower);
						LightTower_LT2_GreenLampOn(pLightTower);
					}
				}
				else
				{
					//
					// Normal processing...
					//

					if ( pLightTower->m_LT2_bEnable == FALSE )
					{
						bRailsTest = !Rails_inWarningRailsPreset(railsDb, 0);
					}
					else
					{
						bRailsTest = !Rails_inWarningRailsPresetSharedDual(railsDb);
					}
					bRail0SPChanged = Rail_getSPChanged(&(railsDb->rail0));
					bRail1SPChanged = Rail_getSPChanged(&(railsDb->rail1));
					bRail2SPChanged = Rail_getSPChanged(&(railsDb->rail2));
					bRail3SPChanged = Rail_getSPChanged(&(railsDb->rail3));


					bTempzonesInDeadband = TempZones_isAllZonesInDeadBand(tempZones);
					bFluxHeater1 = FluxHeater_InDeadBandOrIsNotEnabled(fluxHeater);
					bFluxHeater2 = FluxHeater_InDeadBandOrIsNotEnabled(fluxHeater1);
					bFluxHeater3 = FluxHeater_InDeadBandOrIsNotEnabled(fluxHeater2);
					bFluxHeater4 = FluxHeater_InDeadBandOrIsNotEnabled(fluxHeater3);
					bFluxHeater5 = FluxHeater_InDeadBandOrIsNotEnabled(fluxHeater4);
					dwrdBeltState = Belt_getCurrentState( &(g_dbContainer.belt[0]) );

					// Check for a new recipe or a set point change.
					if ( (bTempzonesInDeadband == 0)
						|| !bFluxHeater1		// shared
						|| !bFluxHeater2	// shared
						|| !bFluxHeater3	// shared
						|| !bFluxHeater4	// shared					
						|| !bFluxHeater5	// shared
						|| (dwrdBeltState == 0) 
						|| (bRail0SPChanged==TRUE)
						|| (bRail2SPChanged==TRUE)	)
					{
						bLT1_SPChange = TRUE;
					}
					dwrdBeltState = Belt_getCurrentState( &(g_dbContainer.belt[1]) );

					if ( (bTempzonesInDeadband == 0)
						|| !bFluxHeater1		// shared
						|| !bFluxHeater2	// shared
						|| !bFluxHeater3	// shared
						|| !bFluxHeater4	// shared					
						|| !bFluxHeater5	// shared
						|| (dwrdBeltState == 0)  
						|| (bRail1SPChanged==TRUE)
						|| (bRail3SPChanged==TRUE)	)

					{
						bLT2_SPChange = TRUE;
					}

					bCooldownPending = Oven_cooldownModePending(ovenDb);
					bOvenFlux = Oven_getAutoCleanFlux(ovenDb);
					bFanFlush = Fans_anyInFlush2(globalBlower, analogFan, heatZoneBlowers);
					bBarcodeHalt = LightTower_barcodeHalt(pLightTower);
					sDeviation = TempZones_zonesAreInDeviationState(tempZones);
					bFluxInDev1 = FluxHeater_isInDeviationAlarmZone(fluxHeater);
					bFluxInDev2 = FluxHeater_isInDeviationAlarmZone(fluxHeater1);
					bFluxInDev3 = FluxHeater_isInDeviationAlarmZone(fluxHeater2);
					bFluxInDev4 = FluxHeater_isInDeviationAlarmZone(fluxHeater3);
					bFluxInDev5 = FluxHeater_isInDeviationAlarmZone(fluxHeater4);

					// SHARED amber decision
					if ( !bTempzonesInDeadband				// shared
						|| !bFluxHeater1		// shared
						|| !bFluxHeater2	// shared
						|| !bFluxHeater3	// shared
						|| !bFluxHeater4	// shared					
						|| !bFluxHeater5	// shared					
						|| bOvenFlux	// shared		// if autoclean recipe is loaded light stays yellow.
						|| bFluxInDev1	// shared
						|| bFluxInDev2 // shared
						|| bFluxInDev3 // shared
						|| bFluxInDev4 // shared
						|| bFluxInDev5 // shared
						|| sDeviation	// shared
						|| bCooldownPending		// shared
						|| (ovenDb->mbEnergyRecipe==TRUE) // shared
						|| pLightTower->mbScannerHold 	// shared
						|| bBarcodeHalt 	// shared
						|| bFanFlush
						|| bRailsTest )	// shared
					{
						bShared_Amber = TRUE;
					}

					bPresetWarn1 = Rails_inWarningRailsPreset(railsDb, 1);
					bPresetWarn2 = Rails_inWarningRailsPreset(railsDb, 3);
					bFirstSupport = CBS_isFirstBoardSupportInCorrectPosition(cbs);
					sBeltState = Belt_getCurrentState( &(g_dbContainer.belt[0]) );
					uSmemaAllow = Belt_smemaAllow(&(g_dbContainer.belt[0]));
					uSmemaSuspend = Belt_getSMEMASuspend(&(g_dbContainer.belt[0]));

					// Light Tower 1 amber decision
					if ( !bPresetWarn1
						|| !bPresetWarn2
						|| !bFirstSupport
						|| sBeltState == 0 
						|| (uSmemaAllow==0)
						|| (uSmemaSuspend==1) )
					{
						bLT1_Amber = TRUE;
					}
					bPresetWarn1 = Rails_inWarningRailsPreset(railsDb, 2);
					bPresetWarn2 = Rails_inWarningRailsPreset(railsDb, 4);
					bFirstSupport = CBS_isSecondBoardSupportInCorrectPosition(cbs);
					sBeltState = Belt_getCurrentState( &(g_dbContainer.belt[1]) );
					uSmemaAllow = Belt_smemaAllow(&(g_dbContainer.belt[1]));
					uSmemaSuspend = Belt_getSMEMASuspend(&(g_dbContainer.belt[1]));

					// Light Tower 2 amber decision
					if ( !bPresetWarn1
						|| !bPresetWarn2
						|| !bFirstSupport
						|| sBeltState == 0 
						|| (uSmemaAllow==0)
						|| (uSmemaSuspend==1) )
					{
						bLT2_Amber = TRUE;
					}

					pInt1 =(int*) &ltNewOvenState1;
					pInt2 = (int*) &ltNewOvenState2;

					if ( pLightTower->m_LT2_bEnable )
					{
						bSetAudibleAlarm = LightTower_process2LightTowers( bShared_Amber, bLT1_Amber, bLT2_Amber, bLT1_SPChange, bLT2_SPChange, pInt1, pInt2);					
					}
					else
					{
						//
						// Common processing for single light tower
						//
						bSetAudibleAlarm = LightTower_processSingleLightTower(bShared_Amber, bLT1_Amber,  bLT2_Amber, bLT1_SPChange, bLT2_SPChange, pInt1, pInt2 );						
					}
				}
			}

			// Change of oven state needs to reset the audible alarms flag
			// so that the alarm will sound if needed.
			if ( ltNewOvenState1 != pLightTower->m_ltOvenState1 )
			{
				if((ltNewOvenState1 != LTOS_ALARM || pLightTower->m_ltOvenState1 != LTOS_ESTOP)//transition between these two states should not reset the audible alarm
					|| ( ltNewOvenState1 != LTOS_ESTOP || pLightTower->m_ltOvenState1 != LTOS_ALARM) )
				{
					alarmQueueDb->m_bAlarmsTriggerAudibleEvent = TRUE;
				}
				pLightTower->m_ltOvenState1 = ltNewOvenState1;
			}

			if ( ltNewOvenState2 != pLightTower->m_ltOvenState2 )
			{
				if((ltNewOvenState2 != LTOS_ALARM || pLightTower->m_ltOvenState2 != LTOS_ESTOP)//transition between these two states should not reset the audible alarm
					|| ( ltNewOvenState2 != LTOS_ESTOP || pLightTower->m_ltOvenState2 != LTOS_ALARM) )
				{
					alarmQueueDb->m_bAlarmsTriggerAudibleEvent = TRUE;
				}
				pLightTower->m_ltOvenState2 = ltNewOvenState2;
			}

			LightTower_processAudibleAlarm( pLightTower, bSetAudibleAlarm );
		}
	}
	return;
}



/*********************************************************************************************
*
*           Lamps On Member Functions 
*
*********************************************************************************************/  
void LightTower_GreenLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_GreenLampOn");

	if ( pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( pLightTower->bAutoModeYellow == TRUE )//allow smema but don't allow green lt
		{
			*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = FALSE;

			if(pLightTower->bLTSpecialSolid == TRUE)
			{
				*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = pLightTower->lightState;
			}
		}
		else
		{
			if ( pLightTower->bGreenError )
			{
				*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = pLightTower->lightState;
			}
			else
			{
				*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = pLightTower->lightState;
			}
		}
	}
}

void LightTower_GreenLampOnSony(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_GreenLampOnSony");

	if ( pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if(pLightTower->bAutoModeYellow == TRUE)//allow smema but don't allow green lt
		{
			*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = FALSE;

			if(pLightTower->bLTSpecialSolid == TRUE)
			{
				*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = pLightTower->lightState;
			}
		}
		else
		{
			*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = pLightTower->lightState;
		}
	}
}

void LightTower_AmberLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_AmberLampOn");

	if ( pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( pLightTower->bLTSpecialSolid == TRUE &&
			pLightTower->bAutoModeYellow == TRUE )
		{
			*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = TRUE;
		}
		else
		{
			*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = pLightTower->lightState;
		}
	}

	if ( pLightTower->m_bCommLoss &&
		(pLightTower->bLampsOff == FALSE) )
	{
		*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = TRUE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_RedLampOn


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LightTower_RedLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_RedLampOn");

	if ( pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		*DOUT_GetAt(digOutDb, ODO_RED_LIGHT_TOWER) = pLightTower->lightState;
	}
}

void LightTower_LT2_GreenLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_GreenLampOn");

	if ( pLightTower->m_LT2_bEnable &&
		pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( pLightTower->bAutoModeYellow == TRUE )//allow smema but don't allow green lt
		{
			if ( ODO_NULL != pLightTower->m_LT2_DOGreen )
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = FALSE;
			}

			if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
			{
				if ( pLightTower->bLTSpecialSolid == TRUE )
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = pLightTower->lightState;
				}
			}
		}
		else
		{
			if ( ODO_NULL != pLightTower->m_LT2_DOGreen )
			{
				if ( pLightTower->bGreenError )
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = pLightTower->lightState;
				}
				else
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = pLightTower->lightState;
				}
			}
		}
	}
}

void LightTower_LT2_GreenLampOnSony(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_GreenLampOnSony");

	if ( pLightTower->m_LT2_bEnable &&
		pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if(pLightTower->bAutoModeYellow == TRUE)//allow smema but don't allow green lt
		{
			if ( ODO_NULL != pLightTower->m_LT2_DOGreen )
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = FALSE;
			}

			if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
			{
				if(pLightTower->bLTSpecialSolid == TRUE)
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = pLightTower->lightState;
				}
			}
		}
		else
		{
			if ( ODO_NULL != pLightTower->m_LT2_DOGreen )
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = pLightTower->lightState;
			}
		}
	}
}

void LightTower_LT2_AmberLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_AmberLampOn");

	if ( pLightTower->m_LT2_bEnable && 
		pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
		{
			if ( pLightTower->bLTSpecialSolid == TRUE &&
				pLightTower->bAutoModeYellow == TRUE )
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = pLightTower->lightState;
			}
		}
	}

	if ( pLightTower->m_bCommLoss &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
		{
			*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = TRUE;
		}
	}
}

void LightTower_LT2_RedLampOn(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_RedLampOn");

	if ( pLightTower->m_LT2_bEnable &&
		pLightTower->LiteTowrEnabled &&
		(pLightTower->bLampsOff == FALSE) )
	{
		if ( ODO_NULL != pLightTower->m_LT2_DORed )
		{
			*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DORed) = pLightTower->lightState;
		}
	}
}

/*********************************************************************************************
*
*           Lamps OFF Member Functions 
*
*********************************************************************************************/  
void LightTower_GreenLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_GreenLampOFF");

	*DOUT_GetAt(digOutDb, ODO_GREEN_LIGHT_TOWER) = FALSE;
}

void LightTower_AmberLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_AmberLampOFF");

	BOOL bState = FALSE;
	if ( pLightTower->m_bCommLoss )
	{
		bState = TRUE;
	}

	*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = bState;
}

void LightTower_RedLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_RedLampOFF");

    *DOUT_GetAt(digOutDb, ODO_RED_LIGHT_TOWER) = FALSE;   
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_LT2_GreenLampOFF


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LightTower_LT2_GreenLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_GreenLampOFF");

	if ( ODO_NULL != pLightTower->m_LT2_DOGreen )
	{
		*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOGreen) = FALSE;
	}
}

void LightTower_LT2_AmberLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_AmberLampOFF");

	BOOL bState = FALSE;
	if ( pLightTower->m_bCommLoss )
	{
		bState = TRUE;
	}

	if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
	{
		*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = bState;
	}
}

void LightTower_LT2_RedLampOFF(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_RedLampOFF");

	if ( ODO_NULL != pLightTower->m_LT2_DORed )
	{
		*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DORed) = FALSE;   
	}
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_SmemaRedProcess


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LightTower_SmemaRedProcess(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_SmemaRedProcess");


	// LightTower_smemaSetRed() is only called by the SMEMA_SEAGATE_process() routine.
	// However all LightTower_process() calls utilize this function.
	// If SEAGATE is not the current SMEMA setting, skip this processing.

	const BOOL bIsSeagateSmema = LightTower_IsSeagateSmemaSet();
	if ( bIsSeagateSmema )
	{
		if ( pLightTower->LiteTowrEnabled &&
			(pLightTower->bLampsOff == FALSE) )
		{
			if (pLightTower->smemaRed1)
			{
				*DOUT_GetAt(digOutDb, ODO_RED_LIGHT_TOWER) = pLightTower->lightState;
			}
			else
			{
				*DOUT_GetAt(digOutDb, ODO_RED_LIGHT_TOWER) = FALSE;
			}
		}
	}
}

void LightTower_SmemaAmberProcess(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_SmemaAmberProcess");

	const BOOL bIsSeagateSmema = LightTower_IsSeagateSmemaSet();
	if ( bIsSeagateSmema )
	{
		if(pLightTower->LiteTowrEnabled)
		{
			if (pLightTower->smemaAmber1 &&
				(pLightTower->bLampsOff == FALSE) )
			{
				*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = pLightTower->lightState;
			}
			else
			{
				if(pLightTower->bAutoModeYellow == FALSE)
				{
					*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = FALSE;
				}
			}
		}
	}

	if ( pLightTower->m_bCommLoss && 
		(pLightTower->bLampsOff == FALSE) )
	{
		*DOUT_GetAt(digOutDb, ODO_AMBER_LIGHT_TOWER) = TRUE;
	}
}

void LightTower_LT2_SmemaRedProcess(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_SmemaRedProcess");

	const BOOL bIsSeagateSmema = LightTower_IsSeagateSmemaSet();
	if ( bIsSeagateSmema )
	{
		if ( pLightTower->m_LT2_bEnable )
		{
			if ( pLightTower->LiteTowrEnabled &&
				(pLightTower->bLampsOff == FALSE) )
			{
				if ( ODO_NULL != pLightTower->m_LT2_DORed )
				{
					if (pLightTower->smemaRed2)
					{
						*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DORed) = pLightTower->lightState;
					}
					else
					{
						*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DORed) = FALSE;
					}
				}
			}
		}
	}
}

void LightTower_LT2_SmemaAmberProcess(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_SmemaAmberProcess");

	const BOOL bIsSeagateSmema = LightTower_IsSeagateSmemaSet();

	if ( pLightTower->m_LT2_bEnable )
	{
		if ( ODO_NULL != pLightTower->m_LT2_DOYellow )
		{
			if ( bIsSeagateSmema )
			{
				if(pLightTower->LiteTowrEnabled)
				{
					if (pLightTower->smemaAmber2 &&
						(pLightTower->bLampsOff == FALSE) )
					{
						*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = pLightTower->lightState;
					}
					else
					{
						if(pLightTower->bAutoModeYellow == FALSE)
						{
							*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = FALSE;
						}
					}
				}
			}

			if ( pLightTower->m_bCommLoss && 
				(pLightTower->bLampsOff == FALSE) )
			{
				*DOUT_GetAt(digOutDb, pLightTower->m_LT2_DOYellow) = TRUE;
			}
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LightTower_Enable(LightTower* pLightTower)



	GLOBALS:
	RETURNS:   long
	SEE ALSO:  
------------------------------------------------------------------------*/
long LightTower_Enable(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_Enable", 0);
	pLightTower->LiteTowrEnabled=TRUE;
	return 5;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LightTower_Disable(LightTower* pLightTower)



	GLOBALS:
	RETURNS:   long
	SEE ALSO:  
------------------------------------------------------------------------*/
long LightTower_Disable(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_Disable", 0);

	LightTower_GreenLampOFF(pLightTower);
	LightTower_AmberLampOFF(pLightTower);
	LightTower_RedLampOFF(pLightTower);

	pLightTower->LiteTowrEnabled=FALSE;
	return 0;
}

void LightTower_smemaSetRed(LightTower* pLightTower, BOOL state /*= TRUE*/ )
{
	PARAM_CHECK( pLightTower, "LightTower_smemaSetRed");
	pLightTower->smemaRed1 = state;		
}

void LightTower_smemaSetAmber(LightTower* pLightTower, BOOL state /*= TRUE*/ )
{
	PARAM_CHECK( pLightTower, "LightTower_smemaSetAmber");
	pLightTower->smemaAmber1 = state;	
}

void LightTower_LT2_smemaSetRed(LightTower* pLightTower, BOOL state /*= TRUE*/ )
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_smemaSetRed");
	pLightTower->smemaRed2 = state;		
}

void LightTower_LT2_smemaSetAmber(LightTower* pLightTower, BOOL state /*= TRUE*/ )
{
	PARAM_CHECK( pLightTower, "LightTower_LT2_smemaSetAmber");
	pLightTower->smemaAmber2 = state;	
}

void LightTower_setSonyGreenLightOption(LightTower* pLightTower, BOOL off) 
{
	PARAM_CHECK( pLightTower, "LightTower_setSonyGreenLightOption");
	pLightTower->iToggleForSonyGreenLight = off;
}

void LightTower_setDOAvailibility(LightTower* pLightTower, BOOL bFree)
{
	PARAM_CHECK( pLightTower, "LightTower_setDOAvailibility");
	pLightTower->bODONewJobFree = bFree;
}


void LightTower_setRedOnBoardError(LightTower* pLightTower, BOOL bRed)
{
	PARAM_CHECK( pLightTower, "LightTower_setRedOnBoardError");
	pLightTower->m_bRedOnBoardError = bRed;
}

void LightTower_setGreenError(LightTower* pLightTower, BOOL bFlash)
{
	PARAM_CHECK( pLightTower, "LightTower_setGreenError");
	pLightTower->bGreenError = bFlash;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_getHoldSmema


 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL LightTower_getHoldSmema(LightTower* pLightTower)
{
	PARAM_CHECK_RETURN( pLightTower, "LightTower_getHoldSmema",0);
	return pLightTower->bGreenError;
}

void LightTower_setCommLoss(LightTower* pLightTower, UINT lEnabled)
{
	PARAM_CHECK( pLightTower, "LightTower_setCommLoss");
	pLightTower->m_iCommLossOption = lEnabled;
}

void LightTower_barcodePing(LightTower* pLightTower)
{
	PARAM_CHECK( pLightTower, "LightTower_barcodePing");

	pLightTower->dwrdBarcodeTime=Timer_getCurrentTime10ths( &( g_dbContainer.elapseTimer ));

	if ( pLightTower->selfAckAlarmNo != 0 )
	{
		AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pLightTower->selfAckAlarmNo);
		pLightTower->selfAckAlarmNo=0;
	}
}

void LightTower_barcodeOption(LightTower* pLightTower, BOOL bOn)
{
	PARAM_CHECK( pLightTower, "LightTower_barcodeOption");
	pLightTower->dwrdBarcodeTime=Timer_getCurrentTime10ths( &( g_dbContainer.elapseTimer ));
	pLightTower->bBarcodeActive=bOn;
}		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_barcodeHalt
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL LightTower_barcodeHalt(LightTower* pLightTower)
{
	BOOL bReturn = FALSE;

	if(pLightTower->bBarcodeActive == FALSE)
	{
		bReturn = FALSE;
	}
	else
	{
		if(differenceWithRollover(Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)),pLightTower->dwrdBarcodeTime )>50)
		{
			pLightTower->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, BARCODE_TIMEOUT, 0);
			bReturn = TRUE;
		}
	}
	return bReturn;
}

void LightTower_setVIPMode(LightTower* pLightTower, BOOL bOn)
{
	PARAM_CHECK( pLightTower, "LightTower_setVIPMode");
	pLightTower->bVIPMode=bOn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_automaticMode


 RETURNS:   void
------------------------------------------------------------------------*/
void LightTower_automaticMode(LightTower* pLightTower)
{
	DWORD tim;
	BOOL din;

	tim = Timer_getCurrentTime10ths( &( g_dbContainer.elapseTimer ));
	din = FALSE;

	if( NULL != pLightTower )
	{
		if(pLightTower->bLTSpecialMode==TRUE)
		{
			if(pLightTower->dwrdLTInput!=IDI_NULL)
			{
				din = *DIN_GetAt(&(g_dbContainer.digitalInDb), pLightTower->dwrdLTInput);
				if( din == pLightTower->bLTSpecialHigh )
				{
					pLightTower->dwrdInputTimeStart=tim;
				}
			}

			//NOTE: If Lot Processing is enable, the SEC Light tower
			//feature will not be handled correctly.
			if( FALSE == g_bLotProcessingEnable )
			{
				if ( pLightTower->bLT1==TRUE &&
					g_dbContainer.boardQ0_NoLP.ltTracking==TRUE )
				{
					g_dbContainer.boardQ0_NoLP.ltTracking=FALSE;
					pLightTower->dwrdInputTimeStart=tim;
				}

				if ( pLightTower->bLT2 == TRUE &&
					g_dbContainer.boardQ1_NoLP.ltTracking == TRUE )
				{
					g_dbContainer.boardQ1_NoLP.ltTracking=FALSE;
					pLightTower->dwrdInputTimeStart=tim;
				}

				if ( pLightTower->bLT3 == TRUE &&
					g_dbContainer.boardQ2_NoLP.ltTracking == TRUE )
				{
					g_dbContainer.boardQ2_NoLP.ltTracking=FALSE;
					pLightTower->dwrdInputTimeStart=tim;
				}

				if ( pLightTower->bLT4 == TRUE &&
					g_dbContainer.boardQ3_NoLP.ltTracking == TRUE )
				{
					g_dbContainer.boardQ3_NoLP.ltTracking=FALSE;
					pLightTower->dwrdInputTimeStart=tim;
				}
			}

			if( (tim - pLightTower->dwrdInputTimeStart) > pLightTower->dwrdLTTime )
			{
				if(pLightTower->bAutoModeYellow == FALSE)
				{
					pLightTower->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, IN_SEC_YELLOW, 0);
				}
				pLightTower->bAutoModeYellow=TRUE;
			}
			else
			{
				if(pLightTower->bAutoModeYellow == TRUE)
				{
					pLightTower->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, OUT_SEC_YELLOW, 0);
				}
				pLightTower->bAutoModeYellow=FALSE;
			}
		}
		else
		{
			pLightTower->bAutoModeYellow=FALSE;
		}
	}

	return;
}

BOOL LightTower_LT2_IsEnabled(LightTower* pLightTower)
{
	BOOL bReturn = FALSE;

	if ( pLightTower )
	{
		bReturn = pLightTower->m_LT2_bEnable;
	}

	return bReturn;
}

void LightTower_LT2_SetEnable(LightTower* pLightTower, BOOL bEnable)
{
	if ( pLightTower )
	{
		pLightTower->m_LT2_bEnable = bEnable;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_LT2_SetDigitalOutput
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LightTower_LT2_SetDigitalOutput(LightTower* pLightTower, enum Light_States state, UINT digOut )
{
	if ( pLightTower )
	{
		switch ( state )
		{
		case RED:
			pLightTower->m_LT2_DORed = digOut;
			break;

		case AMBER:
			pLightTower->m_LT2_DOYellow = digOut;
			break;

		case GREEN:
			pLightTower->m_LT2_DOGreen = digOut;
			break;
		default:
			break;
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_SetLightColor

			Sets the color state for Light Tower 1

 RETURNS:   void
------------------------------------------------------------------------*/
void LightTower_SetLightColor(LightTower* pLightTower, enum Light_States color, BOOL bSony)
{

	if ( NULL != pLightTower )
	{
		switch ( color )
		{
			case Light_OFF:
				LightTower_RedLampOFF(pLightTower);
				LightTower_AmberLampOFF(pLightTower);
				LightTower_GreenLampOFF(pLightTower);	
				pLightTower->lightColor1 = Light_OFF;
				break;
				
			case RED:
				LightTower_RedLampOn(pLightTower);
				LightTower_AmberLampOFF(pLightTower);
				LightTower_GreenLampOFF(pLightTower);
				switch (pLightTower->lightColor1)
				{
				case GREEN :
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT_GREEN_TO_RED, 0);
					break;
				case AMBER :
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT_YELLOW_TO_RED, 0);
					break;
				}
				pLightTower->lightColor1 = RED;
				break;
				
			case AMBER:
				if ( bSony )
				{
			        // job startup has a flashing green for the Sony option.
				    LightTower_RedLampOFF(pLightTower);
	                LightTower_AmberLampOFF(pLightTower);
	                LightTower_GreenLampOnSony(pLightTower);
				}
				else
				{
					LightTower_RedLampOFF(pLightTower);
					LightTower_AmberLampOn(pLightTower);
					LightTower_GreenLampOFF(pLightTower);
				}
				
				if( GREEN == pLightTower->lightColor1 )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, LT_GREEN_TO_YELLOW, 0);
				}

				if (pLightTower->lightColor1 == Light_OFF)
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT_OFF_TO_YELLOW, 0);
	
				pLightTower->lightColor1 = AMBER;
				break;
				
			case GREEN:
				if ( bSony )
				{
		            // Sony would like the green light to be turned off when the oven 
		            // has completed startup sequencing.
		            // SDY - 08/14/2000
					// Changed their mind and want it ON jwf 2/15/01
					//Heller has requested the ability to toggle the control on/off
					LightTower_RedLampOFF(pLightTower);
					LightTower_AmberLampOFF(pLightTower);
					LightTower_GreenLampOFF(pLightTower);
				}
				else
				{
					LightTower_RedLampOFF(pLightTower);
					LightTower_AmberLampOFF(pLightTower);
					LightTower_GreenLampOn(pLightTower);
				}
	
				if( AMBER == pLightTower->lightColor1 )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, LT_YELLOW_TO_GREEN, 0);
				}
	
				pLightTower->lightColor1 = GREEN;
				break;
	
			default:
				break;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_LT2_SetLightColor

			Sets the color state for Light Tower 2

 RETURNS:   void
------------------------------------------------------------------------*/
void LightTower_LT2_SetLightColor(LightTower* pLightTower, enum Light_States color, BOOL bSony)
{
	if ( NULL != pLightTower &&
		 pLightTower->m_LT2_bEnable )
	{
		switch ( color )
		{
			case Light_OFF:
				LightTower_LT2_RedLampOFF(pLightTower);
				LightTower_LT2_AmberLampOFF(pLightTower);
				LightTower_LT2_GreenLampOFF(pLightTower);	
				pLightTower->lightColor2 = Light_OFF;
				break;
				
			case RED:
				LightTower_LT2_RedLampOn(pLightTower);
				LightTower_LT2_AmberLampOFF(pLightTower);
				LightTower_LT2_GreenLampOFF(pLightTower);
				switch (pLightTower->lightColor2)
				{
				case GREEN :
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT2_GREEN_TO_RED, 0);
					break;
				case AMBER :
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT2_YELLOW_TO_RED, 0);
					break;
				}
				pLightTower->lightColor2 = RED;
				break;
				
			case AMBER:
				if ( bSony )
				{
			        // job startup has a flashing green for the Sony option.
				    LightTower_LT2_RedLampOFF(pLightTower);
	                LightTower_LT2_AmberLampOFF(pLightTower);
	                LightTower_LT2_GreenLampOnSony(pLightTower);
				}
				else
				{
					LightTower_LT2_RedLampOFF(pLightTower);
					LightTower_LT2_AmberLampOn(pLightTower);
					LightTower_LT2_GreenLampOFF(pLightTower);
				}
	
				if( GREEN == pLightTower->lightColor2 )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, LT2_GREEN_TO_YELLOW, 0);
				}

				if (pLightTower->lightColor2 == Light_OFF)
					AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, LOGGED_EVENT, LT2_OFF_TO_YELLOW, 0);
	
				pLightTower->lightColor2 = AMBER;
				break;
				
			case GREEN:
				if ( bSony )
				{
		            // Sony would like the green light to be turned off when the oven 
		            // has completed startup sequencing.
		            // SDY - 08/14/2000
					// Changed their mind and want it ON jwf 2/15/01
					//Heller has requested the ability to toggle the control on/off
					LightTower_LT2_RedLampOFF(pLightTower);
					LightTower_LT2_AmberLampOFF(pLightTower);
					LightTower_LT2_GreenLampOFF(pLightTower);
				}
				else
				{
					LightTower_LT2_RedLampOFF(pLightTower);
					LightTower_LT2_AmberLampOFF(pLightTower);
					LightTower_LT2_GreenLampOn(pLightTower);
				}
	
				if( AMBER == pLightTower->lightColor2 )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, LT2_YELLOW_TO_GREEN, 0);
				}
	
				pLightTower->lightColor2 = GREEN;
				break;
	
			default:
				break;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_processAudibleAlarm
			
			audible processing

 RETURNS:   void
------------------------------------------------------------------------*/
void LightTower_processAudibleAlarm(LightTower* pLightTower, BOOL bSetAudibleAlarm)
{
	UINT nOutput;
	UINT nAlarmCondition;
	BOOL bHasUserWarnings; 
	BOOL bAlarmOutput;
	BOOL bFiveSecond;

	bFiveSecond = FALSE;
	nOutput = AlarmQueue_getAlarmOutput(alarmQueueDb);
	nAlarmCondition = AlarmQueue_returnInAudibleCondition(alarmQueueDb);
	bHasUserWarnings = AlarmQueue_audibleUserWarningsPresent( alarmQueueDb ); 
	bAlarmOutput = bSetAudibleAlarm;
	if( ( nOutput != ODO_AUDIBLE_ALARM ) && ( nOutput != ODO_NULL ) )//The warning output and normal alarm output are mutually exclusive
	{
		*DOUT_GetAt(digOutDb, ODO_AUDIBLE_ALARM) = FALSE;
	}
	// Check if the user has suppressed the alarm from sounding.
	if ( alarmQueueDb->m_bAlarmsTriggerAudibleEvent )
	{
		// The custom light tower's audible state can be overriden by any 
		// of the user settable alarms regardless of what the current audible state is.
		if ( bHasUserWarnings )
		{
			bAlarmOutput = TRUE;
		}
	}
	else
	{
		bAlarmOutput = FALSE;
	}
	if(alarmQueueDb->m_bBlowerInWarning)
	{
		bAlarmOutput = TRUE;
	}

	switch( nAlarmCondition )
	{
		case ALARMCONDITION_NONE:
			// NO AUDIBLE ALARMS

			*DOUT_GetAt(digOutDb, nOutput) = bAlarmOutput;			
			bFiveSecond = Oven_getFiveSecondDisable(ovenDb);
			if( bFiveSecond )//if disabled set the output
			{
				*DOUT_GetAt(digOutDb, ODO_NEW_JOB_FIVESEC) = FALSE;
			}
			break;

		case ALARMCONDITION_NORMAL:
			// NORMAL AUDIBLE ALARMS

			*DOUT_GetAt(digOutDb, nOutput) = bAlarmOutput; //TRUE;

			bFiveSecond = Oven_getFiveSecondDisable(ovenDb);
			if(bFiveSecond && pLightTower->bODONewJobFree)//if disabled set the output, the autoclean recipe cycle must not be using it
			{
				*DOUT_GetAt(digOutDb, ODO_NEW_JOB_FIVESEC) = FALSE;
			}
			break;

		case ALARMCONDITION_SPECIAL:
			// SPECIAL AUDIBLE ALARMS

			bFiveSecond = Oven_getFiveSecondDisable(ovenDb);
			if(bFiveSecond)
			{
				if(pLightTower->bODONewJobFree)//if disabled set the output, the autoclean recipe cycle must not be using it
				{
					*DOUT_GetAt(digOutDb, ODO_NEW_JOB_FIVESEC) = bAlarmOutput;
				}
				else  //otherwise audible warnings will trigger the normal alarm output
				{
					//bAlarmOutput = TRUE;
					*DOUT_GetAt(digOutDb, nOutput) = bAlarmOutput;
				}
			}
			else
			{
				//bAlarmOutput = TRUE;
				*DOUT_GetAt(digOutDb, nOutput) = bAlarmOutput;
			}
			break;

		default:
			break;
	}


	pLightTower->m_bAudibleAlarmSet = bAlarmOutput;
	return;
}

BOOL LightTower_isAudibleAlarmSet(LightTower* pLightTower)
{
	BOOL bReturn = FALSE;

	if ( pLightTower )
	{
		bReturn = pLightTower->m_bAudibleAlarmSet;
	}

	return bReturn;
}

BOOL LightTower_IsSeagateSmemaSet()
{
	enum SMEMA_Interface type = NO_SMEMA;
	BOOL bReturn = FALSE;
	int i = 0;

	SMEMA* allSmemas[4] = { &(g_dbContainer.smema1), &(g_dbContainer.smema2), 
		&(g_dbContainer.smema3), &(g_dbContainer.smema4) };

	for ( i = 0; (i < 4) && (bReturn == FALSE); i++ )
	{
		type = SMEMA_getSMEMAtype( allSmemas[i] );
		if ( type == SEAGATE )
		{
			bReturn = TRUE;
		}
	}

	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_processHardCooldown
			
			subfunction to process called when in cooldown
			and system is below cooldown SP

 RETURNS:   BOOL, sets the audible output
------------------------------------------------------------------------*/
BOOL LightTower_processHardCooldown( int* pltNewOvenState1, int* pltNewOvenState2)
{
	BOOL bEStop;
	enum Light_States lampColor;
	BOOL bSetAudibleAlarm;
	BOOL bAlarms;
	BOOL bShouldBeRed;
	
	bEStop = AlarmQueue_hasEStopAlarm(alarmQueueDb);
	lampColor = Light_OFF;
	bSetAudibleAlarm = FALSE;
	bAlarms = AlarmQueue_alarmsPresent(alarmQueueDb);
	bShouldBeRed = Purge_lightTowerShouldBeRed(purge);


	if ( bEStop )
	{
		lampColor = flasherEstopCooldown->flasherColor;
		g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherEstopCooldown);
		bSetAudibleAlarm = flasherEstopCooldown->m_bAudibleAlarm;
		*pltNewOvenState1 = LTOS_ESTOP;
		*pltNewOvenState2 = LTOS_ESTOP;

		LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
		LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
	}
	else if ( AlarmQueue_alarmsPresent(alarmQueueDb) == TRUE || 
		Purge_lightTowerShouldBeRed(purge))        
	{
		lampColor = flasherAlarmCooldown->flasherColor;
		g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherAlarmCooldown);
		bSetAudibleAlarm = flasherAlarmCooldown->m_bAudibleAlarm;
		*pltNewOvenState1 = LTOS_ALARM;
		*pltNewOvenState2 = LTOS_ALARM;

		LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
		LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
	}
	else
	{
		bSetAudibleAlarm = FALSE;
		*pltNewOvenState1 = LTOS_NONE;
		*pltNewOvenState2 = LTOS_NONE;

		LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
		LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
	}
	return bSetAudibleAlarm;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_process2LightTowers
			
			normal mode processing for all light towers
			when the second light tower option is active

 RETURNS:   Value used to set the audible output indicator
------------------------------------------------------------------------*/
BOOL LightTower_process2LightTowers(BOOL bShared_Amber, BOOL bLT1_Amber, BOOL bLT2_Amber, BOOL bLT1_SPChange, BOOL bLT2_SPChange, int*  pltNewOvenState1, int* pltNewOvenState2 )
{
	int nBoardCountInOven;
	BOOL bGreenSony;
	BOOL bLTO;
	BOOL bLT1_Warnings;
	BOOL bLT2_Warnings;
	BOOL bCommon_Warnings;
	enum Light_States lampColor;
	BOOL bSetAudibleAlarm;
	unsigned char cWarningQuality;
	BOOL bPurge;
	
	nBoardCountInOven = Oven_GetBoardCount( ovenDb );
	bGreenSony = FALSE;
	bLTO = FALSE;
	bLT1_Warnings = AlarmQueue_warningsPresent_lt1(alarmQueueDb);
	bLT2_Warnings = AlarmQueue_warningsPresent_lt2(alarmQueueDb);
	bCommon_Warnings = AlarmQueue_warningsPresent_common(alarmQueueDb);
	lampColor = Light_OFF;
	bSetAudibleAlarm = FALSE;
	bPurge = Purge_lightTowerShouldBeYellow(purge);
	cWarningQuality = 0;

	if ( bPurge )
	{
		bLT1_Warnings = TRUE;
		bLT2_Warnings = TRUE;
	}
	//
	// Independent processing of each light tower
	//
	if ( bLT1_Warnings || bCommon_Warnings )
	{
		lampColor = flasherWarning->flasherColor;
		g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
		bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
		*pltNewOvenState1 = LTOS_WARNING;
		cWarningQuality = AlarmQueue_SecsgemLightTower();
		switch(cWarningQuality)
		{
			case WARNING_TYPE_ALL_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_ALL:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_BOTH_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;
	
			case WARNING_TYPE_SECSGEM_RED_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_RED:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_YELLOW_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_YELLOW:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;

			case WARNING_TYPE_SECSGEM_BOTH_RED_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH_RED:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_BOTH_YELLOW_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH_YELLOW:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;

			case WARNING_TYPE_STANDARD: //fall through
			default:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				break;
		}
	}
	else /*  NO ALARMS OR WARNINGS */                                      
	{
		// this needs to be changed to indicate when all active 
		// tempzones are within deadband.
		if ( bLT1_SPChange )
		{
			lampColor = flasherSPChange->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherSPChange);
			bSetAudibleAlarm = flasherSPChange->m_bAudibleAlarm;
			*pltNewOvenState1 = LTOS_SP_CHANGE;
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else if ( bShared_Amber || bLT1_Amber )
		{
			lampColor = flasherWarning->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
			bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
			*pltNewOvenState1 = LTOS_WARNING;
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else
		{

			if ( nBoardCountInOven == 0 )
			{
				// Use the Ready state for the empty oven.
				lampColor = flasherReady->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReady);
				bSetAudibleAlarm = flasherReady->m_bAudibleAlarm;
				*pltNewOvenState1 = LTOS_READY_EMPTY;
			}
			else
			{
				// Use the Ready state for when there are boards in the oven.
				lampColor = flasherReadyBoards->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReadyBoards);
				bSetAudibleAlarm = flasherReadyBoards->m_bAudibleAlarm;
				*pltNewOvenState1 = LTOS_READY_BOARDS;
			}

			if ( Oven_getLTOption(ovenDb) == FALSE )
			{
				bGreenSony = FALSE;
			}
			else
			{
				// Sony would like the green light to be turned off when the oven 
				// has completed startup sequencing.
				// SDY - 08/14/2000
				// Changed their mind and want it ON jwf 2/15/01
				//Heller has requested the ability to toggle the control on/off
				if ( g_dbContainer.lightTower.iToggleForSonyGreenLight )
				{
					bGreenSony = TRUE;

					lampColor = GREEN;
					g_dbContainer.lightTower.lightState = Flasher_ON;
					bSetAudibleAlarm = TRUE;
				}
			}

			LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, bGreenSony );
			LightTower_SmemaRedProcess(&(g_dbContainer.lightTower));
			LightTower_SmemaAmberProcess(&(g_dbContainer.lightTower));
   		}
	}

	if ( bLT2_Warnings || bCommon_Warnings )
	{
		lampColor = flasherWarning->flasherColor;
		g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
		bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
		*pltNewOvenState2 = LTOS_WARNING;

		LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
	}
	else /*  NO ALARMS OR WARNINGS */                                      
	{
		if ( bLT2_SPChange )
		{
			lampColor = flasherSPChange->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherSPChange);
			bSetAudibleAlarm = flasherSPChange->m_bAudibleAlarm;
			*pltNewOvenState2 = LTOS_SP_CHANGE;
	
			if ( Oven_getLTOption(ovenDb) == FALSE )
			{
				LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else if ( bShared_Amber || bLT2_Amber )
		{
			lampColor = flasherWarning->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
			bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
			*pltNewOvenState2 = LTOS_WARNING;
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else
		{
			if ( nBoardCountInOven == 0 )
			{
				// Use the Ready state for the empty oven.

				lampColor = flasherReady->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReady);
				bSetAudibleAlarm = flasherReady->m_bAudibleAlarm;
				*pltNewOvenState2 = LTOS_READY_EMPTY;
			}
			else
			{
				// Use the Ready state for when there are boards in the oven.

				lampColor = flasherReadyBoards->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReadyBoards);
				bSetAudibleAlarm = flasherReadyBoards->m_bAudibleAlarm;
				*pltNewOvenState2 = LTOS_READY_BOARDS;
			}
			bLTO =  Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				bGreenSony = FALSE;
			}
			else
			{
				// Sony would like the green light to be turned off when the oven 
				// has completed startup sequencing.
				// SDY - 08/14/2000
				// Changed their mind and want it ON jwf 2/15/01
				//Heller has requested the ability to toggle the control on/off
				if ( g_dbContainer.lightTower.iToggleForSonyGreenLight )
				{
					bGreenSony = TRUE;

					lampColor = GREEN;
					g_dbContainer.lightTower.lightState = Flasher_ON;
					bSetAudibleAlarm = TRUE;
				}
			}

			LightTower_LT2_SetLightColor( &(g_dbContainer.lightTower), lampColor, bGreenSony );

			LightTower_LT2_SmemaRedProcess(&(g_dbContainer.lightTower));
			LightTower_LT2_SmemaAmberProcess(&(g_dbContainer.lightTower));
   		}
	}
	return bSetAudibleAlarm;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LightTower_processSingleLightTower
			
			normal mode processing for THE light tower
			(when the second light tower option is inactive)

 RETURNS:   Value used to set the audible output indicator
------------------------------------------------------------------------*/
BOOL LightTower_processSingleLightTower(BOOL bShared_Amber, BOOL bLT1_Amber, BOOL bLT2_Amber, BOOL bLT1_SPChange, BOOL bLT2_SPChange, int* pltNewOvenState1, int* pltNewOvenState2 )
{
	unsigned char cWarningQuality;
	int nBoardCountInOven;
	BOOL bGreenSony;
	BOOL bLTO;
	BOOL bSetAudibleAlarm;
	BOOL bLT1_Warnings;
	BOOL bLT2_Warnings;
	BOOL bCommon_Warnings;
	enum Light_States lampColor;
	BOOL bPurge;

	cWarningQuality = 0;
	nBoardCountInOven = Oven_GetBoardCount( ovenDb );
	bGreenSony = FALSE;
	bLTO = FALSE;
	bSetAudibleAlarm = FALSE;
	bLT1_Warnings = AlarmQueue_warningsPresent_lt1(alarmQueueDb);
	bLT2_Warnings = AlarmQueue_warningsPresent_lt2(alarmQueueDb);
	bCommon_Warnings = AlarmQueue_warningsPresent_common(alarmQueueDb);
	lampColor = Light_OFF;
	bPurge = Purge_lightTowerShouldBeYellow(purge);

	if ( bPurge )
	{
		bLT1_Warnings = TRUE;
		bLT2_Warnings = TRUE;
	}
	if ( bLT1_Warnings ||
		bLT2_Warnings || 
		bCommon_Warnings )
	{
		lampColor = flasherWarning->flasherColor;
		g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
		bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
		*pltNewOvenState1 = LTOS_WARNING;
		cWarningQuality = AlarmQueue_SecsgemLightTower();
		switch(cWarningQuality)
		{

			case WARNING_TYPE_ALL_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_ALL:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_BOTH_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;
	
			case WARNING_TYPE_SECSGEM_RED_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_RED:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_YELLOW_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_YELLOW:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), Light_OFF, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;

			case WARNING_TYPE_SECSGEM_BOTH_RED_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH_RED:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_RedLampOn(&(g_dbContainer.lightTower));
				break;

			case WARNING_TYPE_SECSGEM_BOTH_YELLOW_AUDIBLE: //fall through
				bSetAudibleAlarm = TRUE;
			case WARNING_TYPE_SECSGEM_BOTH_YELLOW:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				LightTower_AmberLampOn(&(g_dbContainer.lightTower));	
				break;

			case WARNING_TYPE_STANDARD: //fall through
			default:
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
				break;
		}
	}
	else /*  NO ALARMS OR WARNINGS */                                      
	{
		// this needs to be changed to indicate when all active 
		// tempzones are within deadband.
		if ( bLT1_SPChange || bLT2_SPChange )
		{
			lampColor = flasherSPChange->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherSPChange);
			bSetAudibleAlarm = flasherSPChange->m_bAudibleAlarm;
			*pltNewOvenState1 = LTOS_SP_CHANGE;
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else if ( bShared_Amber || 
			bLT1_Amber || 
			bLT2_Amber )
		{
			lampColor = flasherWarning->flasherColor;
			g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherWarning);
			bSetAudibleAlarm = flasherWarning->m_bAudibleAlarm;
			*pltNewOvenState1 = LTOS_WARNING;
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, FALSE );
			}
			else /*  NO ALARMS OR WARNINGS AND EVERYTHING IN DEADBAND*/
			{
				bSetAudibleAlarm = TRUE;

				// job startup has a flashing green for the Sony option.
				LightTower_SetLightColor( &(g_dbContainer.lightTower), AMBER, TRUE );
			}
		}
		else
		{
			if ( nBoardCountInOven == 0 )
			{
				// Use the Ready state for the empty oven.

				lampColor = flasherReady->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReady);
				bSetAudibleAlarm = flasherReady->m_bAudibleAlarm;
				*pltNewOvenState1 = LTOS_READY_EMPTY;
			}
			else
			{
				// Use the Ready state for when there are boards in the oven.

				lampColor = flasherReadyBoards->flasherColor;
				g_dbContainer.lightTower.lightState = Flasher_getFlashState(flasherReadyBoards);
				bSetAudibleAlarm = flasherReadyBoards->m_bAudibleAlarm;
				*pltNewOvenState1 = LTOS_READY_BOARDS;
			}
			bLTO = Oven_getLTOption(ovenDb);
			if ( bLTO == FALSE )
			{
				bGreenSony = FALSE;
			}
			else
			{
				// Sony would like the green light to be turned off when the oven 
				// has completed startup sequencing.
				// SDY - 08/14/2000
				// Changed their mind and want it ON jwf 2/15/01
				//Heller has requested the ability to toggle the control on/off
				if ( g_dbContainer.lightTower.iToggleForSonyGreenLight )
				{
					bGreenSony = TRUE;

					lampColor = GREEN;
					g_dbContainer.lightTower.lightState = Flasher_ON;
					bSetAudibleAlarm = TRUE;
				}
			}

			LightTower_SetLightColor( &(g_dbContainer.lightTower), lampColor, bGreenSony );

			LightTower_SmemaRedProcess(&(g_dbContainer.lightTower));
			LightTower_SmemaAmberProcess(&(g_dbContainer.lightTower));
   		}
	}
	return bSetAudibleAlarm;
}
