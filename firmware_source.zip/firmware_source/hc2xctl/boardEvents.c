/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			boardEvents.c

	Description:	Implementation of the CHellerCommCtrl OLE control class

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

/*=======================================================================
 *
 * INCLUDE FILES:
 *
*=======================================================================*/

#include "contain.h"
#include "boardEvents.h"
#include "newboardq.h"
#include "newboardqNoLP.h"
#include "boards.h"
#include "oven.h"
#include "typedefdefine.h"
#include "BoardEventCmds.h"
#include "utility.h"

extern DbContainer g_dbContainer;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEvent_init

            Initialization routine.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void BoardEvent_init(BoardEvent* pBoardEvent)
{
	if ( pBoardEvent )
	{
		pBoardEvent->highTime = 0;
		pBoardEvent->lowTime = 0;
		pBoardEvent->milliseconds = 0;
		pBoardEvent->eventSeqNum = 0;
		pBoardEvent->inUse = 0;
		pBoardEvent->lane = 0;
		pBoardEvent->cooldown = 0;
		pBoardEvent->reset = 0;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEntryEvents_init

            Initialization routine.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void BoardEntryEvents_init(BoardEntryEvents* pBoardEvents)
{
	int i = 0;

	if ( pBoardEvents )
	{
		for ( i = 0; i < MAX_CARRIER_EVENT_COUNT; i++ )
		{
			BoardEvent_init( &(pBoardEvents->m_array[i]) );
		}

		pBoardEvents->m_count = 0;
		pBoardEvents->m_sequenceNum = 0;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEntryEvents_eventAdd

			Returns the index of the added event, or -1.
			Sets the in-use flag and updates the sequence number 
			of the event at the returned index.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
int BoardEntryEvents_eventAdd(BoardEntryEvents* pBoardEvents)
{
	int nReturnIndex = -1;
	BoardEvent* pBoardEvent = NULL;
	int i = 0;

	// Run through the event array looking for an empty space.
	if ( pBoardEvents )
	{
		if ( pBoardEvents->m_count < MAX_CARRIER_EVENT_COUNT )
		{
			for ( i = 0; (i < MAX_CARRIER_EVENT_COUNT) && (nReturnIndex == -1); i++ )
			{
				pBoardEvent = &(pBoardEvents->m_array[ i ]);
				if ( pBoardEvent->inUse == FALSE )
				{
					nReturnIndex = i;

					pBoardEvent->inUse = TRUE;
					pBoardEvent->eventSeqNum = pBoardEvents->m_sequenceNum;

					// reset has occurred, set reset bit to reset OCX counter
					if ( pBoardEvents->m_sequenceNum == 0 )
					{
						pBoardEvent->reset = BOARDEVENT_SEQUENCE_RESET;
					}

					pBoardEvents->m_sequenceNum++;
					pBoardEvents->m_count++;
				}
			}
		}
	}

	return nReturnIndex;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEntryEvents_eventRemove

			Returns TRUE if a LotProcEvent with the given sequenceNum was removed.
			Removes the LotProcEvent with the given sequenceNum and 
			decrements the count.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL BoardEntryEvents_eventRemove(BoardEntryEvents* pBoardEvents, WORD sequenceNum)
{
	BOOL bReturn = FALSE;
	BoardEvent* pBoardEvent = NULL;
	int i = 0;

	// Run through the event array looking for an empty space.
	if ( pBoardEvents )
	{
		if ( pBoardEvents->m_count < MAX_CARRIER_EVENT_COUNT )
		{
			for ( i = 0; (i < MAX_CARRIER_EVENT_COUNT) && (bReturn == FALSE); i++ )
			{
				pBoardEvent = &(pBoardEvents->m_array[ i ]);
				if ( (pBoardEvent->inUse == TRUE)
					&& (pBoardEvent->eventSeqNum == sequenceNum) )
				{
					bReturn = TRUE;

					BoardEvent_init( pBoardEvent );

					if ( pBoardEvents->m_count > 0 )
					{
						pBoardEvents->m_count--;
					}
				}
			}
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEntryEvents_AddBoardEntryEvent

			Determines if an entry side event needs to be added for the board.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL BoardEntryEvents_AddBoardEntryEvent( BoardEntryEvents* pBoardEvents, Board* pBoard, int nLane )
{
	BOOL bReturn = FALSE;

	BoardEvent* pEvent = NULL;
	int nEventIndex = 0;

	const BOOL bCoolDown = (g_dbContainer.ovenDb.jobNo == COOLDOWN);

	if ( pBoardEvents && pBoard )
	{
		if ( pBoard->bInUse )
		{
			// Entry Leading Edge
			if ( pBoard->timeStamps.bValidEntryLeading 
				&& (pBoard->timeStamps.bEntryEventAdded == FALSE) )
			{
				// Create the event.
				nEventIndex = BoardEntryEvents_eventAdd( pBoardEvents );
				if ( nEventIndex >= 0 )
				{
					pBoard->timeStamps.bEntryEventAdded = TRUE;

					// upate the event data.
					pEvent = &(pBoardEvents->m_array[nEventIndex]);

					pEvent->highTime = pBoard->timeStamps.entryLeadingEdge.dwHigh;
					pEvent->lowTime = pBoard->timeStamps.entryLeadingEdge.dwLow;
					pEvent->milliseconds = pBoard->timeStamps.entryLeadingEdge.dwMilli;

					pEvent->lane = nLane;

					if ( bCoolDown || pBoard->bCooldown )
					{
						pEvent->cooldown = TRUE;
					}

					bReturn = TRUE;
				}
			}
		}
	}

	return bReturn;
}
