/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999-2014, All Rights Reserved
                    Company Confidential

	File:			litetowr.h

	Description:	lighttower processing 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __LITETOWR_H__
#define __LITETOWR_H__

#include "typedefdefine.h"

//below lightStates are two defines used in get light tower status, enum should skip these values
enum Light_States{ Light_OFF = 0, RED = 1, AMBER= 2, GREEN= 4  };
# define YELLOW_SPECIAL_SOLID 5	
# define YELLOW_SPECIAL 6

enum Light_Action
{
	LA_FLASH = 0, 
	LA_SOLID = 1, 
};

enum LT_OVEN_STATE
{
	LTOS_NONE = 0,
	LTOS_SP_CHANGE,
	LTOS_READY_EMPTY,
	LTOS_READY_BOARDS,
	LTOS_WARNING,
	LTOS_ALARM,
	LTOS_ESTOP,
};

typedef struct _LightTower_
{
	BOOL		smemaRed1;
	BOOL		smemaAmber1;
	BOOL		smemaRed2;
	BOOL		smemaAmber2;

	BOOL		sonyBoardDrop;

	BOOL		lightState;

	// If m_LT2_bEnable then lightColor2
	// corresponds to the second light tower.
	enum Light_States	lightColor1;
	enum Light_States	lightColor2;

	enum LT_OVEN_STATE	m_ltOvenState1;	// current state of the oven
	enum LT_OVEN_STATE	m_ltOvenState2;	// current state of the oven


	BOOL		iToggleForSonyGreenLight;
	BOOL		bODONewJobFree;
	DWORD		storedLightColor;
	BOOL		LiteTowrEnabled;
	BOOL		m_bRedOnBoardError;
	BOOL		bGreenError;
	UINT		m_iCommLossOption;
	unsigned long	m_lLastCommandTime;	
	BOOL 		m_bCommLoss;
	DWORD		dwrdBarcodeTime;
	DWORD		selfAckAlarmNo;
	BOOL		bBarcodeActive;
	BOOL		bVIPMode;
	BOOL		bLT1;
	BOOL		bLT2;
	BOOL		bLT3;
	BOOL		bLT4;
	BOOL		bLTSpecialHigh;
	BOOL 		bLampsOff;
	BOOL		bLTSpecialMode;
	DWORD		dwrdLTInput;
	DWORD		dwrdLTTime;
	DWORD		dwrdInputTimeStart;
	BOOL		bAutoModeYellow;
	BOOL		bLTSpecialSolid;

	BOOL		m_bAudibleAlarmSet;

	//
	// 2nd Light Tower option
	//
	BOOL m_LT2_bEnable;
	UINT m_LT2_DORed;
	UINT m_LT2_DOYellow;
	UINT m_LT2_DOGreen;
	BOOL mbScannerHold;

} LightTower;

void LightTower_init(LightTower* pLightTower);

UINT LightTower_getLT1Status(LightTower* pLightTower);
UINT LightTower_getLT2Status(LightTower* pLightTower);
UINT LightTower_getCombinedStatus(LightTower* pLightTower);

void LightTower_smemaSetRed(LightTower* pLightTower, BOOL state /*= TRUE*/ );
void LightTower_smemaSetAmber(LightTower* pLightTower, BOOL state /*= TRUE*/ );

void LightTower_process(LightTower* pLightTower);

BOOL LightTower_processHardCooldown(int* ltNewOvenState1, int* ltNewOvenState2 );

BOOL LightTower_process2LightTowers(BOOL bShared_Amber, BOOL bLT1_Amber, BOOL bLT2_Amber, BOOL bLT1_SPChange, BOOL bLT2_SPChange, int* ltNewOvenState1, int* ltNewOvenState2   );
BOOL LightTower_processSingleLightTower( BOOL bShared_Amber, BOOL bLT1_Amber, BOOL bLT2_Amber, BOOL bLT1_SPChange, BOOL bLT2_SPChange, int* ltNewOvenState1,  int* ltNewOvenState2);
void LightTower_processAudibleAlarm(LightTower* pLightTower, BOOL bSetAudibleAlarm);

void LightTower_SmemaRedProcess(LightTower* pLightTower);
void LightTower_SmemaAmberProcess(LightTower* pLightTower);

void LightTower_GreenLampOn(LightTower* pLightTower);
void LightTower_GreenLampOnSony(LightTower* pLightTower);
void LightTower_AmberLampOn(LightTower* pLightTower);
void LightTower_RedLampOn(LightTower* pLightTower);

void LightTower_GreenLampOFF(LightTower* pLightTower);
void LightTower_AmberLampOFF(LightTower* pLightTower);
void LightTower_RedLampOFF(LightTower* pLightTower);

long LightTower_Enable(LightTower* pLightTower);
long LightTower_Disable(LightTower* pLightTower);

void LightTower_setRedOnBoardError(LightTower* pLightTower, BOOL bRed);

void LightTower_setSonyGreenLightOption(LightTower* pLightTower, BOOL off);
void LightTower_setDOAvailibility(LightTower* pLightTower, BOOL bFree);
void LightTower_setGreenError(LightTower* pLightTower, BOOL bFlash);
BOOL LightTower_getHoldSmema(LightTower* pLightTower);
void LightTower_setCommLoss(LightTower* pLightTower, UINT lEnabled);
void LightTower_barcodePing(LightTower* pLightTower);
void LightTower_barcodeOption(LightTower* pLightTower, BOOL bOn);
BOOL LightTower_barcodeHalt(LightTower* pLightTower);
void LightTower_setVIPMode(LightTower* pLightTower, BOOL bOn);
void LightTower_automaticMode(LightTower* pLightTower);

void LightTower_SetLightColor(LightTower* pLightTower, enum Light_States color, BOOL bSony);

void LightTower_DEBUG_printks();

//
// Dual Tower methods
//
BOOL LightTower_LT2_IsEnabled(LightTower* pLightTower);
void LightTower_LT2_SetEnable(LightTower* pLightTower, BOOL bEnable);
void LightTower_LT2_SetDigitalOutput(LightTower* pLightTower, enum Light_States state, UINT digOut ); 
void LightTower_LT2_GreenLampOn(LightTower* pLightTower);
void LightTower_LT2_GreenLampOnSony(LightTower* pLightTower);
void LightTower_LT2_AmberLampOn(LightTower* pLightTower);
void LightTower_LT2_RedLampOn(LightTower* pLightTower);
void LightTower_LT2_GreenLampOFF(LightTower* pLightTower);
void LightTower_LT2_AmberLampOFF(LightTower* pLightTower);
void LightTower_LT2_RedLampOFF(LightTower* pLightTower);
void LightTower_LT2_SmemaRedProcess(LightTower* pLightTower);
void LightTower_LT2_SmemaAmberProcess(LightTower* pLightTower);
void LightTower_LT2_SetLightColor(LightTower* pLightTower, enum Light_States color, BOOL bSony);

void LightTower_LT2_smemaSetRed(LightTower* pLightTower, BOOL state );
void LightTower_LT2_smemaSetAmber(LightTower* pLightTower, BOOL state );

BOOL LightTower_isAudibleAlarmSet(LightTower* pLightTower);

BOOL LightTower_IsSeagateSmemaSet();

#endif

