/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			CarrierEvents.h

	Description:	Implementation of the CHellerCommCtrl OLE control class

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
 ***************************************************************************/

#ifndef __CARRIEREVENTS_H__
#define __CARRIEREVENTS_H__

/*=======================================================================
 *
 * INCLUDE FILES:
 *
 *=======================================================================*/

#include "LotProcessingCmds.h"
#include "typedefdefine.h"
#include "utility.h"
#include "newboardq.h"
#include "newboardqNoLP.h"

#define MAX_INVALID_LOT	2

/*========================================================================
 *
 * Forward Declarations
 *
 *=======================================================================*/   
struct _Board_;

/*========================================================================
 *
 * struct Definition: carrierBoard
 *
 *=======================================================================*/   

typedef struct _carrierBoard_
{
	BOOL		m_bInUse;		// TRUE: structure has valid data; FALSE: structure is free

	// A reference to the board that is in the oven.  
	// A board is "deleted" by the newBoardQueue once the Board's exit leading and trailing
	// timestamps stamps are both valid.  The "deleted" board will be recycled for other entering boards.
	// Once both of the Carrier's exit leading and trailing timestamps are set,
	// reset the pointer as it won't be of use to us any more.
	struct _Board_* m_pBoard;	

	CHAR			m_lane;		// the line index of the board (0-based)
	
	WORD		m_lotID;		// ID of the Lot
	WORD		m_carrierIndex;	// carrier's position in the lot (1-based)

	// These time stamps mirror the time stamps in the m_pBoard.
	// By comparing our time stamps to the board's we can determine if
	// the board's timestamp is new and then create the appropriate 
	// event.
	struct
	{
		LocalTime	entryLeadingEdge;
		LocalTime	entryTrailingEdge;
		LocalTime	exitLeadingEdge;
		LocalTime	exitTrailingEdge;

		BOOL		bValidEntryLeading;
		BOOL		bValidEntryTrailing;
		BOOL		bValidExitLeading;
		BOOL		bValidExitTrailing;

	} timeStamps;

} CarrierBoard;

/*========================================================================
 *
 * struct Definition: carrierBoard
 *
 *=======================================================================*/   
typedef struct _Lot_
{
	BOOL		m_bInUse;			// TRUE: structure has valid data; FALSE: structure is free

	WORD		m_lotId;			// unique identifier for the lot
	WORD		m_expectedCount;	// expected count of carriers defined in the lot

	BOOL		m_bAbortEarly;		// TRUE: don't add any new carriers to this lot, instead delete the lot early

	// nInOvenCount and nProcessedCount keep a running tally of the lot's status.
	// nInOvenCount is incremented upon an entry-side leading-edge, and decremented upon an exit leading edge.
	// nProcessedCount is incremented upon an entry-side leading-edge.
	WORD	m_nInOvenCount;
	WORD	m_nProcessedCount;

	struct
	{
		CarrierBoard	m_boards[MaxBoards];		// for each Board in the oven there is an associated carrier board

		// m_carrierBoards is a circular array.  The head and tail index are used to modify this circular array.
		UINT		m_headIndex;
		UINT		m_tailIndex;
		DWORD		m_count;	// count of objects in the array
	} m_carrier;

} Lot ;

/*========================================================================
 *
 * struct Definition: LotProcessing
 *
 *=======================================================================*/   
typedef struct _LotProcessing_
{
	//
	// Lots are added by the user from the UI.
	// Lots are deleted when all the expeced carrier boards, 
	// or if the bAbortEarly flag is set, all the current boards 
	// have their exit trailing time stamps set.  This will
	// ensure lots are deleted after their carrier events are created. 
	//
	Lot		m_lot[MAX_LOT_COUNT];
	WORD	m_lotCount;
	UINT	m_lotHeadIndex;	// head points to current lot in use
	UINT	m_lotTailIndex;	// tail points to newest lot defined

	// The INVALID lot is a place holder for incoming carriers that don't belong to a lot.
	// There are two invalid lots to accomodate when one invalid lot has reached its 
	// max carrier count and can be deleted while the newer carriers are added to the next
	// available invalid lot.
	// Lots are deleted when all MaxBoards-count boards have their exit-trailing time stamp set.
	Lot		m_lotInvalid[MAX_INVALID_LOT];
	UINT	m_lotInvalidIndex;	// points to current invalid lot in use

	struct
	{
		LotProcEvent	m_array[MAX_CARRIER_EVENT_COUNT];	// the listing of carrier events.

		// m_events is a circular array.  The head and tail index are used to modify this circular array.
		UINT		m_headIndex;
		UINT		m_tailIndex;
		DWORD		m_count;	// count of objects in the array

		WORD		m_sequenceNum;	// all new events get a unique sequence number.
	} m_events;


} LotProcessing;


/*========================================================================
 *
 * Function Declarations
 *
 *=======================================================================*/   

void CarrierBoard_init(CarrierBoard* pCarrierBoard);
void LotProcEvent_init(LotProcEvent* pLotProcEvent);

void Lot_init(Lot* pLot, BOOL bInvalidLot);
signed int Lot_carrierAdd(Lot* pLot);	// returns the index of the added carrier, or -1
signed int Lot_carrierGetByBoard(Lot* pLot, Board* pBoard); // returns the index of the carrier by the Board pointer, or -1 

void LotProcessing_init(LotProcessing* pLotProc);
void LotProcessing_process(LotProcessing* pLotProc);
void LotProcessing_checkForNewBoards( LotProcessing* pLotProc, newBoardQueue* pNBQ );
void LotProcessing_checkForNewEvents( LotProcessing* pLotProc );
void LotProcessing_clearCompletedLots( LotProcessing* pLotProc );

BOOL LotProcessing_boardHasAssociatedCarrier( LotProcessing* pLotProc, Board* pBoard ); // returns TRUE if Board has an associated carrier
CarrierBoard* LotProcessing_getCarrierByBoard( LotProcessing* pLotProc, Board* pBoard );

signed int LotProcessing_eventAdd(LotProcessing* pLotProc);	// returns the index of the added event, or -1

signed int LotProcessing_lotAdd(LotProcessing* pLotProc, WORD lotID, WORD count );	// returns 1-based index of new lot (1, 2, or 3)
void LotProcessing_lotRemove(LotProcessing* pLotProc);	//	removes the lot at the head
void LotProcessing_lotRemoveByIndex(LotProcessing* pLotProc, UINT index);
BOOL LotProcessing_lotAbort(LotProcessing* pLotProc, WORD lotID);

signed int	LotProcessing_lotGetCurrentLot(LotProcessing* pLotProc); // returns index of valid lot, or -1 if no lots defined
signed int	LotProcessing_lotGetInvalidLot(LotProcessing* pLotProc); // returns index of invalid lot, never returns -1

#endif
