/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			nitrogen.c

	Description:	nitrogen class 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#include "contain.h"
#include "nitrogen.h"
#include "oven.h"
#include "smema.h"
#include "alarm.h"
#include "digitio.h"
#include "timer.h"
#include "belt.h"
#include "intercommtransferclass.h"
#include "smema.h"

extern DbContainer g_dbContainer;

AlarmQueue			* alarmQueueDb;			
Oven 				* ovenDb;
DIN					* digitalInDb;
DOUT 				* digitalOutDb;
Timer				* elapseTimer;
SMEMA				* smema1;
SMEMA				* smema2;
SMEMA				* smema3;
SMEMA				* smema4;
InterCommTransferClass	* interCommTransferClass;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_init
			
			Initialize the database addresses that this module will need to query in order
			to get the state of the oven.

 RETURNS:   void
------------------------------------------------------------------------*/
void Nitrogen_init(Nitrogen* pNitrogen)
{

	if(pNitrogen)
	{
		pNitrogen->uiPurgeTime10ths = DEFAULT_NITRO_PURGE_PERIOD;
		pNitrogen->purgeTimeDuration10ths	= 0;
		pNitrogen->startPurgeTime10ths	= 0;
		pNitrogen->lowPressureStartTime10ths	= 0;
		pNitrogen->elapsedTime10ths		= 0;
		pNitrogen->startNormalTime10ths = 0;
		pNitrogen->normalTimeDuration10ths	= DEFAULT_NITRO_NORMAL_PERIOD;
		pNitrogen->enabled					= FALSE;
		pNitrogen->inLowPressureCheckCycle		= FALSE;
		pNitrogen->inPurgeCycle				= FALSE;
		pNitrogen->previousNitrogenState		= FALSE;
		pNitrogen->nitrogenStateOnOff	= FALSE;
		pNitrogen->currentState		= NOTACTIVE;
		pNitrogen->lastState = NOTACTIVE;
		pNitrogen->oneShotNitrogenFlag	= TRUE;
		pNitrogen->nitrogenPressureLow	= FALSE;
		pNitrogen->fullPurgeInProgress	= FALSE;
		pNitrogen->nitroCooldownRunTime = 0;
		pNitrogen->currentCooldownHasNitro = FALSE;
		pNitrogen->cooldownRunStartTime = 0;
		pNitrogen->bRunNitroFlushInCooldown = FALSE;
		pNitrogen->nitroFlowLevel = fINIT;
		pNitrogen->dsNitroFlow = fINIT;
		pNitrogen->m_bClosedLoopDansensor = FALSE;
		pNitrogen->m_bDeactivatePurgeOutputs = FALSE;
		pNitrogen->m_iDSFlowControl = 0;
		pNitrogen->iRedundantInputSensor = IDI_NULL;
		pNitrogen->allLanesTimer	=  0;
		pNitrogen->warnEnable=FALSE;
		pNitrogen->alarmEnable=FALSE;
		pNitrogen->mbStandbyNitroOff=FALSE;
		pNitrogen->mbStandbyNitroLow=FALSE;
		pNitrogen->mbLowState=FALSE;
		pNitrogen->mbWriteLowState=FALSE;

	}
	alarmQueueDb = &( g_dbContainer.alarmQueueDb	);
	ovenDb = &( g_dbContainer.ovenDb				);
	digitalInDb = &( g_dbContainer.digitalInDb		);
	digitalOutDb = &( g_dbContainer.digitalOutDb	);
	elapseTimer = &( g_dbContainer.elapseTimer		);
	smema1 = &( g_dbContainer.smema1				);
	smema2 = &( g_dbContainer.smema2				);
	smema3 = &( g_dbContainer.smema3				);
	smema4 = &( g_dbContainer.smema4				);
	interCommTransferClass = &( g_dbContainer.CommTransferClass);
	return;
}

//******************************************************************************
// Nitrogen_setActive
//
// Abstract:
//	Turn on or off the nitrogen flow.
//
// Programmer: Steven Young
// Date: 05/19/1998
//
//******************************************************************************
BOOL Nitrogen_setActive(Nitrogen* pNitrogen, BOOL state )
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_setActive", 0);

	if( pNitrogen->enabled == TRUE )
	{
		pNitrogen->nitrogenStateOnOff = state;
	}
	else
	{
		pNitrogen->nitrogenStateOnOff = FALSE;
		status = FALSE;
	}
	return status;
}

BOOL Nitrogen_getActive(Nitrogen *pNitrogen)
{
	if (pNitrogen->enabled)
		return(pNitrogen->nitrogenStateOnOff);
	return(FALSE);
}

//******************************************************************************
// Nitrogen_setNitrogenEnable
//
// Abstract:
//	From setup - is this option available to be turned on.
//
// Programmer: Steven Young
// Date: 05/19/1998
//
//******************************************************************************
void Nitrogen_setNitrogenEnable(Nitrogen* pNitrogen, BOOL state )
{
	PARAM_CHECK( pNitrogen, "Nitrogen_setNitrogenEnable");
	pNitrogen->enabled = state;
}

//******************************************************************************
// Nitrogen_getNitrogenEnable
//
// Abstract:
//	For the user interface to be abled to determine the state of the nitrogen 
//  module.
//
// Programmer: Steven Young
// Date: 07/02/1998
//
//******************************************************************************
BOOL Nitrogen_getNitrogenEnable(Nitrogen* pNitrogen )
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_getNitrogenEnable", 0);
	return pNitrogen->enabled;
}

//******************************************************************************
// Nitrogen_setPurgeTime10ths
//
// Abstract:
//	Set the purge time in 10ths of seconds.
//
// Programmer: Steven Young
// Date: 07/02/1998
//
//******************************************************************************
void Nitrogen_setPurgeTime10ths(Nitrogen* pNitrogen, DWORD purgeTime10thsOfSeconds )
{
	PARAM_CHECK( pNitrogen, "Nitrogen_setPurgeTime10ths");
	pNitrogen->uiPurgeTime10ths = purgeTime10thsOfSeconds;
}

//******************************************************************************
// Nitrogen_getPurgeTime10ths
//
// Abstract:
//	Return the purge time in 10ths of seconds.
//
// Programmer: Steven Young
// Date: 07/02/1998
//
//******************************************************************************
DWORD Nitrogen_getPurgeTime10ths(Nitrogen* pNitrogen )
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_getPurgeTime10ths", 0);
	return pNitrogen->uiPurgeTime10ths;
}

//******************************************************************************
// Nitrogen_setNormalTime10ths
//
// Abstract:
//	Normal time is the time that occurs after a purge is complete and there are 
//  boards in the oven. Effectively Normal time is the last time a board is 
//  detected entering the oven, if the Nortmal time elapses before a new board 
//  enters the oven then low flow mode is entered. If there are no detectors
//  for determining if a board is in the oven then normal time should be set
//  to zero.
//
// Programmer: Steven Young
// Date: 07/02/1998
//
//******************************************************************************
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_setNormalTime10ths
			
			Normal time is the time that occurs after a purge is complete and there are 
  			boards in the oven. Effectively Normal time is the last time a board is 
			detected entering the oven, if the Nortmal time elapses before a new board 
			enters the oven then low flow mode is entered. If there are no detectors
			for determining if a board is in the oven then normal time should be set

 RETURNS:   void
------------------------------------------------------------------------*/
void Nitrogen_setNormalTime10ths(Nitrogen* pNitrogen, DWORD normalTime10thsOfSeconds )
{
	if(pNitrogen)
	{
		pNitrogen->normalTimeDuration10ths = normalTime10thsOfSeconds;
	}
	return;
}

//******************************************************************************
// Nitrogen_checkForCoolDown()
//
// Abstract:
//	If COOLDOWN - Job 0 is loaded then turn off Nitrogen On/Off digital Output 15
//
// Programmer: Steven Young
// Date: 05/19/1998
//
//******************************************************************************
BOOL Nitrogen_checkForCoolDown(Nitrogen* pNitrogen )
{
	BOOL isCoolDown = FALSE;
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_checkForCoolDown", 0);

	if ( Oven_getJob(ovenDb) == COOLDOWN ) // 0 = COOLDOWN
	{
		isCoolDown = TRUE;
		if(pNitrogen->runNitroInCooldown)//set flag for this recipe, reset the control bool
		{
			pNitrogen->runNitroInCooldown = FALSE;
			pNitrogen->currentCooldownHasNitro = TRUE;
			pNitrogen->cooldownRunStartTime = 0;
		}
	}
	else
	{
		pNitrogen->currentCooldownHasNitro = FALSE;
	}
 	return isCoolDown;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_process
			
			process loop for nitrogen

 RETURNS:   void
------------------------------------------------------------------------*/
void Nitrogen_process(Nitrogen* pNitrogen)
{
	BOOL bInCooldown;
	BOOL bOutputVal;
	BOOL bBoardEntering;
	DWORD tim;
	DWORD dwrdTimDiff;

	dwrdTimDiff = 0;
	tim = 0;
	bBoardEntering = FALSE;
	bOutputVal = FALSE;
	bInCooldown = FALSE;
	// The condition of setting the Low Pressure warning is 
	// Nitogen NOT Enabled AND NOT in Cooldown AND 
	// 
	if(pNitrogen)
	{
		bInCooldown = Nitrogen_checkForCoolDown(pNitrogen);
		
		//for transition out of standby low flow, we need to restore last state of output or it remains on
		if( ( pNitrogen->mbWriteLowState == TRUE ) && ( pNitrogen->mbStandbyNitroLow == FALSE ) )
		{
			bOutputVal = *DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON);
			if( bOutputVal == FALSE )
			{
				pNitrogen->mbLowState = FALSE;
			}
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = pNitrogen->mbLowState;
			pNitrogen->mbWriteLowState = FALSE;
		}
		if(pNitrogen->currentCooldownHasNitro && bInCooldown)
		{
			pNitrogen->bRunNitroFlushInCooldown = Nitrogen_TestForCooldownRun(pNitrogen);
		}
		else
		{
			pNitrogen->bRunNitroFlushInCooldown = FALSE;
		}
		if (pNitrogen->enabled == FALSE && !bInCooldown )
		{
			Nitrogen_checkPressure(pNitrogen);
		}


		if ( ( bInCooldown && !pNitrogen->bRunNitroFlushInCooldown ) || 
			!pNitrogen->enabled || ( !pNitrogen->nitrogenStateOnOff && 
			!pNitrogen->bRunNitroFlushInCooldown ) )	
		{

			pNitrogen->fullPurgeInProgress = FALSE;
			pNitrogen->currentState = NOTACTIVE;
			pNitrogen->nitrogenPressureLow = FALSE;
		}
		else
		{
			Nitrogen_checkPressure(pNitrogen);		// if low pressure condition exists an alarm is sent and COOLDOWN loaded.
			if ( pNitrogen->autoPurgeEnabled == FALSE )	 
			{
				// if the autopurge option is not available then just set to normal flow.
				//not if the autopurge selection is false, output 22 should not be set in setsolenoids
				pNitrogen->currentState = NITRO_NORMAL;
			}
			else // autopurge option enabled.
			{
				// in order to do a purge the toggle switch must change state from off to on OR
				// 
				switch ( pNitrogen->currentState )
				{
					case NOTACTIVE:
						if ( pNitrogen->nitrogenStateOnOff == TRUE )  
						{
							pNitrogen->inPurgeCycle = FALSE;
							pNitrogen->purgeMode = FULL;
							pNitrogen->purgeTimeDuration10ths = pNitrogen->uiPurgeTime10ths;	// all times converted to 10ths of seconds
							pNitrogen->currentState = PURGE;
						}
						break;		

					case PURGE:
						// When the purge cycle is complete wait for the normal time period for a board
						// to enter before going into standby mode.
						pNitrogen->startNormalTime10ths = Timer_getCurrentTime10ths(elapseTimer);
						Nitrogen_doPurge(pNitrogen);
						break;
					
					case NITRO_NORMAL:
						bBoardEntering = Nitrogen_checkBoardsEnteringInOven(pNitrogen);
						if (  bBoardEntering )	
						{
							// Whenever a board is detected reset the normal time. Default normal time is set at 5 min.
							// SDY 07/15/99
							pNitrogen->startNormalTime10ths = Timer_getCurrentTime10ths(elapseTimer);
						}	
						tim = Timer_getCurrentTime10ths(elapseTimer);
						dwrdTimDiff = tim - pNitrogen->startNormalTime10ths;
						if ( ( dwrdTimDiff > pNitrogen->normalTimeDuration10ths) && (pNitrogen->normalTimeDuration10ths != 0) )
						{
							// to get here a board has not been detected for the normal time period.
							pNitrogen->currentState	= STANDBY;
						}
						break;

					case STANDBY:
						bBoardEntering = Nitrogen_checkBoardsEnteringInOven(pNitrogen);
						if (  bBoardEntering )	
						{
							pNitrogen->inPurgeCycle = FALSE;
							pNitrogen->purgeMode = HALF;
							pNitrogen->purgeTimeDuration10ths = pNitrogen->uiPurgeTime10ths >> 1; // divide purge time in half
							pNitrogen->currentState = PURGE;
						}
						break;
					default:
						break;
				}	
			}
		}
		if(pNitrogen->enabled==TRUE)
		{
			Nitrogen_setSolenoids(pNitrogen);
		}
	}
	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_setSolenoids
			
			sets the flow outputs

 RETURNS:   void
------------------------------------------------------------------------*/
void Nitrogen_setSolenoids(Nitrogen* pNitrogen)
{

	BOOL bDoLowStandby;

	bDoLowStandby  = TRUE;
	
	if(pNitrogen)
	{
		if(pNitrogen->mbStandbyNitroLow == TRUE)//only set output on in low flow if it was already on
		{
			bDoLowStandby = *DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON);
		}
		*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON) = TRUE;		
		if(pNitrogen->mbStandbyNitroOff == TRUE)//standbyoff
		{

			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON) = FALSE;		
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = FALSE;
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_NORMAL_FLOW) = FALSE;
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_HIGH_FLOW)	= FALSE;
		}
		else if(pNitrogen->mbStandbyNitroLow == TRUE && bDoLowStandby)//standby low
		{

			if(pNitrogen->mbWriteLowState==FALSE || pNitrogen->lastState != pNitrogen->currentState)
			{
				pNitrogen->mbWriteLowState=TRUE;	
				pNitrogen->mbLowState=*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW);
				pNitrogen->lastState = pNitrogen->currentState;//used in case enduser changes nitrogen switch
			} 
			switch ( pNitrogen->currentState )
			{
				case NOTACTIVE:
					*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON) = FALSE;	
					*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = FALSE;
					break;

				case PURGE: //fall through
				case NITRO_NORMAL:
				case STANDBY:
				default:
					*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON) = TRUE;	
					*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = TRUE;
					break;
			}
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_NORMAL_FLOW) = FALSE;
			*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_HIGH_FLOW)	= FALSE;
			pNitrogen->lastState = pNitrogen->currentState;//used in case enduser changes 	
		}
		else
		{
			if(pNitrogen->autoPurgeEnabled && !pNitrogen->m_bDeactivatePurgeOutputs)
			{
				*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = FALSE;
			}

			if(pNitrogen->autoPurgeEnabled && !pNitrogen->m_bDeactivatePurgeOutputs)
			{
				*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_NORMAL_FLOW) = FALSE;
				*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_HIGH_FLOW)	= FALSE;
			}
			
			switch ( pNitrogen->currentState )
			{
				case NOTACTIVE:
					if(pNitrogen->m_bClosedLoopDansensor)
					{
						if(pNitrogen->dsNitroFlow != fOFF)
						{
							pNitrogen->m_iDSFlowControl = DS_FLOW_NORMAL;  //normal
							pNitrogen->dsNitroFlow = fOFF;
						}
					}
					*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_ON) = FALSE;
					if( ( pNitrogen->autoPurgeEnabled == TRUE ) && !pNitrogen->m_bDeactivatePurgeOutputs )
					{
						if(pNitrogen->nitroFlowLevel != fOFF)
						{
							pNitrogen->nitroFlowLevel = fOFF;
							AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, NITRO_OFF, 0 );
						}
					}				
					break;

				case NITRO_NORMAL:
					if(pNitrogen->m_bClosedLoopDansensor)
					{
						if(pNitrogen->dsNitroFlow != fMED)
						{
							pNitrogen->m_iDSFlowControl = DS_FLOW_NORMAL;  //normal
							pNitrogen->dsNitroFlow = fMED;
						}
					}
					if(pNitrogen->autoPurgeEnabled == TRUE && !pNitrogen->m_bDeactivatePurgeOutputs)//Activate the output only if the autopurge option is selected
					{
						*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_NORMAL_FLOW) = TRUE;
						if(pNitrogen->nitroFlowLevel != fMED)
						{
							pNitrogen->nitroFlowLevel = fMED;
							AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, NITRO_MEDIUM, 0 );
						}
					}
					break;

				case STANDBY:
					if(pNitrogen->m_bClosedLoopDansensor)
					{
						if(pNitrogen->dsNitroFlow != fLOW)
						{
							pNitrogen->m_iDSFlowControl = DS_FLOW_STANDBY;  //standby
							pNitrogen->dsNitroFlow = fLOW;
						}
					}


					if(pNitrogen->autoPurgeEnabled == TRUE && !pNitrogen->m_bDeactivatePurgeOutputs)//Activate the output only if the autopurge option is selected
					{
	
						*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_LOW_FLOW) = TRUE;
						if(pNitrogen->nitroFlowLevel != fLOW)
						{
							pNitrogen->nitroFlowLevel = fLOW;
							AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, NITRO_LOW, 0 );
						}
					}
					break;
	
				case PURGE:
					if(pNitrogen->m_bClosedLoopDansensor)
					{
						if(pNitrogen->dsNitroFlow != fHIGH)
						{
							pNitrogen->m_iDSFlowControl = DS_FLOW_NORMAL;  //normal
							pNitrogen->dsNitroFlow = fHIGH;
						}
					}
					if(pNitrogen->autoPurgeEnabled == TRUE && !pNitrogen->m_bDeactivatePurgeOutputs)//Activate the output only if the autopurge option is selected
					{
						*DOUT_GetAt(digitalOutDb, ODO_NITROGEN_HIGH_FLOW) = TRUE;
						if(pNitrogen->nitroFlowLevel != fHIGH)
						{
							pNitrogen->nitroFlowLevel = fHIGH;
							AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT , NITRO_HIGH, 0);
						}
					}
					break;

				default:
					break;
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_checkPressure
			checks the input for low pressure warning/alarm

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Nitrogen_checkPressure(Nitrogen* pNitrogen)
{
	PARAM_CHECK( pNitrogen, "Nitrogen_checkPressure");
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	BOOL bLoInput = (*(DIN_GetAt(digitalInDb, IDI_LOW_N2_PRESSURE) ) );
	enum SMEMA_Interface smema1interface = NO_SMEMA;
	enum SMEMA_Interface smema2interface = NO_SMEMA;
	enum SMEMA_Interface smema3interface = NO_SMEMA;
	if ( bLoInput == FALSE ) // no problems
	{
		pNitrogen->oneShotNitrogenFlag = TRUE;
		pNitrogen->inLowPressureCheckCycle = FALSE;
		pNitrogen->nitrogenPressureLow = FALSE;
	}
	else	
	{
		if ( pNitrogen->inLowPressureCheckCycle == FALSE )  
		{
			pNitrogen->lowPressureStartTime10ths = Timer_getCurrentTime10ths(elapseTimer);
			pNitrogen->inLowPressureCheckCycle = TRUE;
		}
		else
		{
			if ( ( (tim - pNitrogen->lowPressureStartTime10ths ) >= pNitrogen->alarmTime)  &&
				pNitrogen->alarmEnable )
			{
				pNitrogen->nitrogenPressureLow = TRUE;
				smema1interface = SMEMA_getSMEMAtype(smema1);
				smema2interface = SMEMA_getSMEMAtype(smema2);
				smema3interface = SMEMA_getSMEMAtype(smema3);

				if ( (smema1interface == SEAGATE) || (smema2interface == SEAGATE) || 
					(smema3interface == SEAGATE) )
				{
					if ( pNitrogen->oneShotNitrogenFlag == TRUE )
					{
						pNitrogen->oneShotNitrogenFlag = FALSE;

					}
				}
				else
				{
					AlarmQueue_addAlarm(alarmQueueDb, ALARM, NITROGEN_LO_PRESSURE_ALARM, 0);
				}
			}

			if ( ( tim - pNitrogen->lowPressureStartTime10ths ) >= 
					pNitrogen->warnTime && pNitrogen->warnEnable)
			{
				AlarmQueue_addAlarm(alarmQueueDb, WARNING, NITROGEN_LO_PRESSURE_WARNING, 0);
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_doPurge

	 	A purge is the release of Nitrogen through the high flow solenoid for a
		period of purgeTimePeriod if being turned on from an off state. In the
		event the system was in standby then only half the purgeTimePeriod is used.
		Whenever half or more of the setPurgeTime period is used turn on the green
		light if possible.
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Nitrogen_doPurge(Nitrogen* pNitrogen)
{
	BOOL bAllow;

	bAllow = TRUE;
	
	if(pNitrogen)
	{
		if(pNitrogen->m_bClosedLoopDansensor && InterCommTransferClass_getDanState(interCommTransferClass) == -1)
		{
			bAllow = FALSE;
		}	
		if(bAllow)
		{
			if ( pNitrogen->inPurgeCycle == FALSE )
			{
				pNitrogen->startPurgeTime10ths = Timer_getCurrentTime10ths(elapseTimer);
				pNitrogen->inPurgeCycle = TRUE;
			}
	
			pNitrogen->elapsedTime10ths = Timer_getCurrentTime10ths(elapseTimer)- pNitrogen->startPurgeTime10ths;
			if ( pNitrogen->elapsedTime10ths > pNitrogen->purgeTimeDuration10ths  )  // purge time is complete
			{
				pNitrogen->currentState = NITRO_NORMAL;
	
	
			}
	
			pNitrogen->fullPurgeInProgress = FALSE;
	
			if ( pNitrogen->purgeMode == FULL )
			{
				if ( pNitrogen->elapsedTime10ths < (pNitrogen->purgeTimeDuration10ths >> 1) )
				{
					pNitrogen->fullPurgeInProgress = TRUE;  // one shot the warning
				}
			}
		}
	}
	return;
}

void Nitrogen_setAutoPurgeEnable(Nitrogen* pNitrogen, BOOL autoPurgeEnable )
{
	PARAM_CHECK( pNitrogen, "Nitrogen_setAutoPurgeEnable");
	pNitrogen->autoPurgeEnabled = autoPurgeEnable;
}

BOOL Nitrogen_getAutoPurgeEnable(Nitrogen* pNitrogen )
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_getAutoPurgeEnable", 0);
	return pNitrogen->autoPurgeEnabled;
}

/*
The following function is used only by the Seagate smema Doug reported that the
light tower that was working with a 1060 patch was functioning correctly.  Seagate
green should be on and yellow blink under low nitrogen conditions.  The nitrogenPressureLow
variable is reset to true on every process loop so I have migrated to oneShotNitrogenFlag
which appears not be used anywhere.  WDT 02/22/2
 */
BOOL Nitrogen_isNitrogenPressureOK(Nitrogen* pNitrogen)
{
/*		if ( nitrogenPressureLow == FALSE )
			return TRUE;*/
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_isNitrogenPressureOK", 0);
	if(pNitrogen->oneShotNitrogenFlag ==TRUE)
		return TRUE;
	return FALSE;
}

/////////////////////////////////////////////////////////////////////
//
//Nitrogen_TestForCooldownRun()
//
//This function tests an internal boolean and a control timer to enable/
//disable the nitrogen flow during cooldown mode.  The timer will function
// as a normal Heller timer, except 0 will signal an indefinate run.
//
/////////////////////////////////////////////////////////////////////
BOOL	Nitrogen_TestForCooldownRun(Nitrogen* pNitrogen)
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_TestForCooldownRun", 0);
	if(pNitrogen->currentCooldownHasNitro)
	{
		if(pNitrogen->nitroCooldownRunTime)//its timed
		{
			if(!pNitrogen->cooldownRunStartTime)//read start cycle time
			{
				pNitrogen->cooldownRunStartTime = Timer_getCurrentTime10ths(elapseTimer);
				return TRUE;  //lets start the nitro
			}
			else
			{
				if(Timer_getCurrentTime10ths(elapseTimer) - pNitrogen->cooldownRunStartTime > pNitrogen->nitroCooldownRunTime)
				{
					pNitrogen->currentCooldownHasNitro = FALSE;
					pNitrogen->cooldownRunStartTime = 0;
					return FALSE;  //time expired
				}
				return TRUE;  //Time has not run out
			}
		}
		else
		{
			return TRUE;  //run indefinately
		}
	}
	return FALSE;  //regular nitrogen processing
}

BOOL Nitrogen_isPurgeInProgress( Nitrogen* pNitrogen )		
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_isPurgeInProgress", 0);
	return pNitrogen->fullPurgeInProgress; 
}

void Nitrogen_setCoolRunTime(Nitrogen* pNitrogen, LONG lTime)
{
	PARAM_CHECK( pNitrogen, "Nitrogen_setCoolRunTime");
	pNitrogen->nitroCooldownRunTime = lTime;
}

void Nitrogen_setRunNitroInCooldown(Nitrogen* pNitrogen, BOOL bRun)
{
	PARAM_CHECK( pNitrogen, "Nitrogen_setRunNitroInCooldown");
	pNitrogen->runNitroInCooldown = bRun;
}

BOOL Nitrogen_isNitroOnInCooldown(Nitrogen* pNitrogen)
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_isNitroOnInCooldown", 0);
	return pNitrogen->bRunNitroFlushInCooldown;
}

UINT Nitrogen_readFlowControl(Nitrogen* pNitrogen)
{
	PARAM_CHECK_RETURN( pNitrogen, "Nitrogen_isNitroOnInCooldown", 0);
	UINT uiReturn = pNitrogen->m_iDSFlowControl;
	pNitrogen->m_iDSFlowControl = 0;
	return uiReturn;
}

void Nitrogen_setDSState(Nitrogen* pNitrogen, BOOL blc)
{
	pNitrogen->m_bClosedLoopDansensor = blc;
}

void Nitrogen_setOutputAvail(Nitrogen* pNitrogen, BOOL boff)
{
	pNitrogen->m_bDeactivatePurgeOutputs = boff;
}

void Nitrogen_setInputForRedundant(Nitrogen* pNitrogen, UINT iRedundant)
{
	pNitrogen->iRedundantInputSensor = iRedundant;
}

void Nitrogen_enableWarning(Nitrogen* pNitrogen, BOOL we)
{
	pNitrogen->warnEnable=we;
}
void Nitrogen_enableAlarm(Nitrogen* pNitrogen, BOOL ae)
{
	pNitrogen->alarmEnable=ae;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_setAlarmTime
			sets the timeout for the low nitrogen alarm

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Nitrogen_setAlarmTime(Nitrogen* pNitrogen, DWORD at)
{
	pNitrogen->alarmTime = at;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_setStandbyMode
			sets the timeout for the low nitrogen warning

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Nitrogen_setWarningTime(Nitrogen* pNitrogen, DWORD wt)
{
	pNitrogen->warnTime=wt;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_setStandbyMode

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Nitrogen_setStandbyMode(Nitrogen* pNitrogen, BOOL on)
{
	if(on==FALSE)
	{
		pNitrogen->mbStandbyNitroOff=FALSE;
		pNitrogen->mbStandbyNitroLow=FALSE;
	}
	else if(ovenDb->m_EnergySaving_StandbyMode1_N2Off==TRUE)
	{
		pNitrogen->mbStandbyNitroOff=TRUE;
	}
	else if(ovenDb->m_EnergySaving_StandbyMode1_N2Low==TRUE)
	{
		pNitrogen->mbStandbyNitroLow=TRUE;
	}

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Nitrogen_checkBoardsEnteringInOven
			
			checks for boards preentering (purge input) or are in the oven

 RETURNS:   0 if empty 1 if entering or has a board count
------------------------------------------------------------------------*/
BOOL Nitrogen_checkBoardsEnteringInOven(Nitrogen* pNitrogen )
{
	DWORD tim;
	DWORD dwrdCount;
	DWORD dwrdInLane;
	BOOL bEntering;
	BOOL bReturn;

	DWORD dif;

	dif = 0;

	tim = 0;
	bReturn = FALSE;
	bEntering = FALSE;
	dwrdInLane = 0;
	dwrdCount = 0;

	if(pNitrogen)
	{
		//changed time to match the board entering (.2 seconds)	
		if(pNitrogen->iRedundantInputSensor!=IDI_NULL)
		{
			tim = Timer_getCurrentTime10ths(elapseTimer);
	 		
			bEntering = *DIN_GetAt(digitalInDb, pNitrogen->iRedundantInputSensor);

			if(!bEntering)
			{
				pNitrogen->allLanesTimer = 0;
			}
			else
			{
				if(pNitrogen->allLanesTimer == 0)
				{
					pNitrogen->allLanesTimer = Timer_getCurrentTime10ths(elapseTimer);
				}

				dif = differenceWithRollover(tim, pNitrogen->allLanesTimer);
				if(dif > FILTER_COUNT_FOR_BOARD_INPUT)
				{
					bReturn = TRUE;
				}
			} 
		}
	}

	if( FALSE == g_bLotProcessingEnable )
	{
		dwrdInLane = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), 1);
		dwrdCount += dwrdInLane;
	}
	else
	{
		dwrdInLane = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), 1);
		dwrdCount += dwrdInLane;
		dwrdInLane = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), 1);
	}
	if(dwrdCount > 0)
	{
		bReturn = TRUE;
	}
	return bReturn;
}
