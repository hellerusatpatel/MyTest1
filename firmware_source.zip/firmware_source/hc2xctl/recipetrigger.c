//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: smema.c
//
// Description: recipe management
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 
//*****************************************************************************
#include <string.h>
#include "contain.h"
#include "recipetrigger.h"
#include "oven.h"

extern DbContainer g_dbContainer;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_init



 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void recipeTrigger_init(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK( pRecipeTrigger, "recipeTrigger_init");
	pRecipeTrigger->bNotify = 0;
	pRecipeTrigger->bSaveRecipePath = 0;
	pRecipeTrigger->bFireRecipeNotification = 0;
	pRecipeTrigger->m_numberComms = 0;
	pRecipeTrigger->bHellerProgramExited = FALSE;
	pRecipeTrigger->bHellerUp = FALSE;
	pRecipeTrigger->iAckedControl=0;
	pRecipeTrigger->cooldown[0]='C';
	pRecipeTrigger->cooldown[1]='O';
	pRecipeTrigger->cooldown[2]='O';
	pRecipeTrigger->cooldown[3]='L';
	pRecipeTrigger->cooldown[4]='D';
	pRecipeTrigger->cooldown[5]='O';
	pRecipeTrigger->cooldown[6]='W';
	pRecipeTrigger->cooldown[7]='N';
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_ExecuteLoad



 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void recipeTrigger_ExecuteLoad(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK( pRecipeTrigger, "recipeTrigger_ExecuteLoad");
	pRecipeTrigger->m_actionControl = 1;
	//pRecipeTrigger->loadTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);

#ifdef DEBUG_BOARDENTRYWAIT
			printk("recipeTrigger_ExecuteLoad() called.\n");
#endif
}

void recipeTrigger_IncrementInstance(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK( pRecipeTrigger, "recipeTrigger_IncrementInstance");
	(pRecipeTrigger->m_numberComms)++;
}

void recipeTrigger_DecrementInstance(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK( pRecipeTrigger, "recipeTrigger_DecrementInstance");
	(pRecipeTrigger->m_numberComms)--;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_getRecipePath(recipeTrigger* pRecipeTrigger) 


 GLOBALS:
 RETURNS:   char*
 SEE ALSO:
------------------------------------------------------------------------*/
char* recipeTrigger_getRecipePath(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_getRecipePath", 0);
	char * p = pRecipeTrigger->recipeTransferPath;
	return p;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_setRecipePath



 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL recipeTrigger_setRecipePath(recipeTrigger* pRecipeTrigger, char *recipe_name )
{
	unsigned long recipeNameLength = 0;
	char *pRecipe_Name = recipe_name;
	BOOL status = TRUE;
	UINT i = 0;
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_setRecipePath", 0);

	recipeNameLength = strlen(recipe_name);
	if(recipeNameLength >MAX_RECIPE_NAME_LENGTH)
	{
		recipeNameLength = MAX_RECIPE_NAME_LENGTH-1;
	}
	for( i=0; i<recipeNameLength; i++ )
	{
		if(i < (MAX_RECIPE_NAME_LENGTH - 1))
		{
			pRecipeTrigger->recipeTransferPath[i] = pRecipe_Name[i];
		}
	}
	while (i<MAX_RECIPE_NAME_LENGTH)
	{
		pRecipeTrigger->recipeTransferPath[i]=' ';
		i++;
	}
	return status;
}


char* recipeTrigger_getRecipeSavePath(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_getRecipeSavePath", 0);
	return pRecipeTrigger->recipeTransferPath;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_setRecipeTransferPath


 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL recipeTrigger_setRecipeTransferPath(recipeTrigger* pRecipeTrigger, char *recipe_name )
{
	unsigned long recipeNameLength = 0;
	char *pRecipe_Name = recipe_name;
	BOOL status = TRUE;
	UINT i = 0;
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_setRecipeTransferPath", 0);
	recipeNameLength = strlen(recipe_name);
	if ( recipeNameLength > MAX_RECIPE_NAME_LENGTH )
	{
		recipeNameLength = MAX_RECIPE_NAME_LENGTH-1;
	}
		for(i=0; i<recipeNameLength; i++ )
		{
			if(i<(MAX_RECIPE_NAME_LENGTH -1))
			{
				pRecipeTrigger->recipeSaveTransferPath[i]=pRecipe_Name[i];
			}
		}
		while (i<MAX_RECIPE_NAME_LENGTH)
		{
			pRecipeTrigger->recipeSaveTransferPath[i]=' ';
			i++;
		}

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_getRecipeSaveTransferPath


 GLOBALS:
 RETURNS:   char*
 SEE ALSO:
------------------------------------------------------------------------*/
char* recipeTrigger_getRecipeSaveTransferPath(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_getRecipeSaveTransferPath", 0);
	return pRecipeTrigger->recipeSaveTransferPath;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_getHellerUp
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL recipeTrigger_getHellerUp(recipeTrigger* pRecipeTrigger)
{
	PARAM_CHECK_RETURN( pRecipeTrigger, "recipeTrigger_getHellerUp", 0);
	return pRecipeTrigger->bHellerUp;
}

void recipeTrigger_setHellerUp(recipeTrigger* pRecipeTrigger, BOOL bUP)
{
	PARAM_CHECK( pRecipeTrigger, "recipeTrigger_setHellerUp");
	pRecipeTrigger->bHellerUp = bUP;
}

void recipeTrigger_setReadControl(recipeTrigger* pRecipeTrigger, int iControl)
{
	pRecipeTrigger->iAckedControl=iControl;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  recipeTrigger_getReadControl


 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int recipeTrigger_getReadControl(recipeTrigger* pRecipeTrigger)
{
	int iReturn = 0;
	if(pRecipeTrigger->bNotify==0)//if it is changing, skip
	{
		iReturn = pRecipeTrigger->iAckedControl;
	}
	return iReturn;
}

