/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//Board Drop Light
#ifndef __BOARDDROP_H__
#define __BOARDDROP_H__

#include "typedefdefine.h"


//*****************************************************************************
// class BoardDropLB
//
// Abstract:
// Beam board drop detection if enabled detects when the beam is broken to indicate 
// a board drop. During COOLDOWN all board drop warnings are ignored.
// The light beam board drop detector is by lane and is not associated by belt 
// in any way.
//
// Programmer: Steven Young
// Date: 06/26/1998
//
//*****************************************************************************

typedef struct _BoardDropLB_
{
	UINT	idNo;
	DWORD		startTime;
	BOOL		boardDropTimeOutMode;
	BOOL		enabled;
	BOOL* 	pBoardDropInput;
	DWORD		elapsedTime;
} BoardDropLB;

void BoardDropLB_init(BoardDropLB* pBD);

void BoardDropLB_configureIO(BoardDropLB* pBD);
BOOL BoardDropLB_configure(BoardDropLB* pBD, DWORD configOption );
void BoardDropLB_enableOption(BoardDropLB* pBD, BOOL optionEnable );
void BoardDropLB_process(BoardDropLB* pBD);

#endif
