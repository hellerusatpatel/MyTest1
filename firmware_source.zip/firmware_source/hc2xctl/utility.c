/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#include "utility.h"

DWORD differenceWithRollover( DWORD  newValue, DWORD prevValue )
{
   DWORD  absDiff;
                                                                                
   if ( (DWORD)newValue < (DWORD)prevValue )
   {
      absDiff = newValue + ~prevValue+1;
   }
   else
   {
      absDiff = newValue - prevValue;
   }
                                                                                
   return absDiff;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LocalTime_resetTime

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LocalTime_resetTime( LocalTime* pLocalTime )
{
	if ( pLocalTime )
	{
		pLocalTime->dwMilli = 0;
		pLocalTime->dwHigh = 0;
		pLocalTime->dwLow = 0;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LocalTime_setTime

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LocalTime_setTime( LocalTime* pLocalTime, DWORD dwHigh, DWORD dwLow, DWORD dwMilli )
{
	if ( pLocalTime )
	{
		pLocalTime->dwHigh = dwHigh;
		pLocalTime->dwLow = dwLow;
		pLocalTime->dwMilli = dwMilli;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LocalTime_copy

			Copies the Source structure into the Destination structure.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LocalTime_copy( LocalTime* pLocalTimeSource, LocalTime* pLocalTimeDestination )
{
	if ( pLocalTimeSource && pLocalTimeDestination )
	{
		pLocalTimeDestination->dwHigh = pLocalTimeSource->dwHigh;
		pLocalTimeDestination->dwLow = pLocalTimeSource->dwLow;
		pLocalTimeDestination->dwMilli = pLocalTimeSource->dwMilli;
	}
}
