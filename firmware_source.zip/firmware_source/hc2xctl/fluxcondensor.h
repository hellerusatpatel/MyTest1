/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __FLUXCONDENSOR_H__
#define __FLUXCONDENSOR_H__

#include "typedefdefine.h"

enum FluxCondensorState{ FLUX_NORMAL = 0, CYCLE_IN_PROGRESS, INTERRUPTED, INTERRUPTED_IN_AUTO };

typedef struct _FluxCondensor_
{
//private:
	DWORD		durationTime;
	DWORD		intervalTime;
	DWORD		durationTimer;	
	DWORD		intervalTimer;
	DWORD		phase1Timer;
	DWORD		lastCheckTime;
	DWORD		currentTime;
	DWORD		startCycleTime;
	enum FluxCondensorState stateFlag;

	BOOL		toggleState;
	BOOL		optionEnabled;
	BOOL		autoCycle;
	BOOL		manualCycle;
	BOOL		fanOFF_AUTOCLEANJOB_Running;
	BOOL		recipeOptionEnabled;
	char		tempRecipe[14];
	DWORD		t3Timer;
	DWORD		countDownToCycleTimer;
	DWORD		cycleDelayTimer;
	BOOL		bOvenAchievedOKStatus;
	BOOL		bActivateFEBlowers;
	BOOL		bRecipeCycleEndsWithNitro;
	BOOL		bJobAtEndEnabled;
	BOOL		m_bGen9;
	DWORD		phase1Time;
	DWORD		phase2Time;
	BOOL		m_bType2;
	UINT		m_uintAutoClean;
} FluxCondensor;

void FluxCondensor_init( FluxCondensor* pFluxCondensor);

void FluxCondensor_startCycle(FluxCondensor* pFluxCondensor);
void FluxCondensor_terminateCycle(FluxCondensor* pFluxCondensor, unsigned int completionState );
void FluxCondensor_process( FluxCondensor* pFluxCondensor );
void FluxCondensor_setDurationTime(FluxCondensor* pFluxCondensor, DWORD durationTimeInMinutes );
DWORD FluxCondensor_getDurationTime( FluxCondensor* pFluxCondensor );			// return time in minutes
void FluxCondensor_setIntervalTime( FluxCondensor* pFluxCondensor, DWORD intervalTimeInHours );
DWORD FluxCondensor_getIntervalTime( FluxCondensor* pFluxCondensor );			// return time in hours
DWORD FluxCondensor_getElapsedTime10ths( FluxCondensor* pFluxCondensor );		// read in 10ths of seconds to be stored in registry
void FluxCondensor_setElapsedTime10ths(FluxCondensor* pFluxCondensor, DWORD elapsedTime );
void FluxCondensor_enableOption(FluxCondensor* pFluxCondensor, BOOL bOptionEnabled );
void FluxCondensor_recipeOption(FluxCondensor* pFluxCondensor, BOOL bRecipeOptionEnabled );
BOOL FluxCondensor_setToggle(FluxCondensor* pFluxCondensor);
void FluxCondensor_recipeStarted(FluxCondensor* pFluxCondensor);
void FluxCondensor_setT3Timer(FluxCondensor* pFluxCondensor, DWORD t3TimeInMinutes);
void FluxCondensor_setDelayTimer(FluxCondensor* pFluxCondensor, DWORD dTimeInMinutes);
void FluxCondensor_setCycleEndNitro(FluxCondensor* pFluxCondensor, BOOL bWithNitro);
void FluxCondensor_setJobAtEnd(FluxCondensor* pFluxCondensor, BOOL bJob);
void FluxCondensor_recipePreStart(FluxCondensor* pFluxCondensor, BOOL bRecipeOptionEnabled);
void FluxCondensor_gen9Option(FluxCondensor* pFluxCondensor, BOOL bGen9);
void FluxCondensor_setPhase1Time(FluxCondensor* pFluxCondensor, int iTime);
void FluxCondensor_setPhase2Time(FluxCondensor* pFluxCondensor, int iTime);
void FluxCondensor_useHighFluxHeater(FluxCondensor* pFluxCondensor, BOOL bUse);

#endif

