/**************************************************************************
    Heller Industries, Inc.
    Copyright (C) 1999 - 2016, All Rights Reserved
                    Company Confidential
	
	File:			tempzs.c

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.

// 26-Sep-16 TP   Update TempZones_completePowerupSequencingTimer() to use settable Oven_getStartupCompletePlusDelayTime()
***************************************************************************/ 
#include "contain.h"
#ifdef _HELLER_COMM_CTRL_
	#include "stdafx1.h"
#endif

#include "tempzs.h"
#include "contain.h"
#include "alarm.h"
#include "digitio.h"
#include "timer.h"
#include "oven.h"
#include "fluxheater.h"
#include "litetowr.h"
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"

#include "pidCtlr.h"


int TDM_versionError(int which);
int TDM_crcError(int which);
extern DbContainer g_dbContainer;

//#define v4018
AlarmQueue		* alarmQDb;
ANALOGIN 		* analogInDb;
ANALOGOUT 		* analogOutDb;
DIN 			* digInDb;
DOUT 			* digOutDb;
Timer			* timerDb;
Oven 			* ovenDb;
FluxHeater		* flxHeat;
FluxHeater		* flxHeat1;
FluxHeater		* flxHeat2;
FluxHeater		* flxHeat3;
FluxHeater		* flxHeat4;
LightTower		* lightTower;

//******************************************************************************
// class TempZones_Tempzones
//
// Abstract:
// The TempZones class contains an array of TempZone objects. Since it contains
// multiple objects it seemed apparent to title this class TempZones.
// As always a concern about static variables must be observed. Since each
// object of TempZone is a member of an array then the default constructor
// is utilized. In addition the TempZone objects utilize references,
// references must be initialized in the constructor initializer list. The
// objects need to be able to access a pseudo global variable, ie a static
// that gets set in TempZones. This is performed by a class, TzoneStaticFix.
// This class must be declared/defined prior to the array of TempZone objects.
// Remember classes are initialized in the order of declaration and not by
// constructor initializer list.
//
// Note: This and all applications must be aware of the usage of static variables.
//			Static variables are not stored as part of the class but in the data
//			segment. The purpose of this application requires two executables,
//			therefor two static variables. The correct static variable to use is
//			the one associated with the VxD, not the Windows Application. In
//			order to achieve this each object must contain a pointer to it's
//			static variable.
//
// Programmer: Steven Young
//	Date 03/19/1998
//******************************************************************************

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  TempZones_init

				Initiaize the temperature zones associated with the
				provided data structure pointer

	RETURNS:	N/A
--------------------------------------------------------------------*/
void TempZones_init(TempZones* pTempZones)
{
	int iHighLimit;
	int i;
	BOOL bLocal;
	
	iHighLimit = MaxTempZones+1;
	bLocal = TRUE;
	i = 0;
	
	if( NULL != pTempZones )
	{
		pTempZones->tempZoneCount = 0;
		pTempZones->maxGroups = MaxTempZones;
		pTempZones->delayStartPeriod10ths = DEFAULT_DELAYPERIOD10TH;
		pTempZones->heaterRiseRatePeriod10ths = DEFAULT_RISERATE_PERIOD;
		pTempZones->minimumRiseDegrees =  DEFAULT_RISE_DEGREES;
		pTempZones->intermediateAllzonesInDb = FALSE;
		pTempZones->nextGroup = FALSE;
		pTempZones->startUpGroup = 0;
		pTempZones->highestActiveGroupNo = 0;
		pTempZones->allZonesInDeadBand = FALSE;
		pTempZones->elapsedStartPeriod = 0;
		pTempZones->timerOn = FALSE;
		pTempZones->waitingForTimer = FALSE;
		pTempZones->storedGroup = 0;
		pTempZones->maxTimeOut = 0;
		pTempZones->secondBoardTimeout = 0;
		pTempZones->m_sActiveZoneCount = 0;
		pTempZones->bNewSequenceStarted = FALSE;
		pTempZones->m_iNumberZonesForDrawwarn = DEFAULT_DRAW_WARNING;
		pTempZones->startUpPowerPercentTPOcounts = DEFAULT_STARTUP_POWER_COUNTS;
		pTempZones->m_iResequenceDelay=DEFAULT_RESEQUENCE;
	
		pTempZones->m_timeStartupCompleted = 0;
		pTempZones->m_bTimerStartupEventFired = FALSE;
	
		alarmQDb = &( g_dbContainer.alarmQueueDb );
		digInDb = &( g_dbContainer.digitalInDb );
		digOutDb = &( g_dbContainer.digitalOutDb );
		analogInDb = &( g_dbContainer.analogInDb );
		analogOutDb = &( g_dbContainer.analogOutDb );
		ovenDb = &( g_dbContainer.ovenDb );
		timerDb = &( g_dbContainer.elapseTimer );
		flxHeat = &( g_dbContainer.fluxHeater );
		flxHeat1 = &( g_dbContainer.fluxHeater1	);
		flxHeat2 = &(g_dbContainer.fluxHeater2);
		flxHeat3 = &( g_dbContainer.fluxHeater3);
		flxHeat4 = &(g_dbContainer.fluxHeater4);
		lightTower = &( g_dbContainer.lightTower );
	
		pTempZones->bZoneProcessed = 0;
		pTempZones->m_bRiseRateWarning = FALSE;

		pTempZones->m_bIOMapTaken = FALSE;
		pTempZones->m_bCheckIOErrors = FALSE;
		pTempZones->m_bIOErrorActive[0] = FALSE;
		pTempZones->m_bIOErrorActive[1] = FALSE;

		for(i = 0; i < iHighLimit; i++)
		{
			bLocal = TRUE;
		
			if ( i >= MAX_TEMP_ZONES_MASTER )
			{
				bLocal = FALSE;
			}
			TempZone_init(&(pTempZones->tempZone[i]), bLocal);
	
			pTempZones->tempZoneCount++;
		}
		
		pTempZones->m_bStartupGrpControlledOutputEnabled = FALSE;
		pTempZones->m_nStartupGrpControlledDO = ODO_NULL;
		pTempZones->m_nStartupGrpControlledGroup = 1;
		pTempZones->m_bStartupGrpControlledOutputValue = SGC_UNKNOWN_STATE;
	}
	
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_configureTempZoneIO
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_configureTempZoneIO( TempZones* pTempZones )
{
	int i;

	for(i=0; i<(MaxTempZones+1); i++)
	{
		TempZone* pTempZone = &(pTempZones->tempZone[i]);

		if ( pTempZone->pidCtrl.bLocalZone )
		{
			TempZone_configureIO( pTempZone );
		}
	}
}

//******************************************************************************
// TempZones_Operator[]
//******************************************************************************
TempZone* TempZones_GetZone(TempZones* pTempZones, DWORD tzIndex)
{
	PARAM_CHECK_RETURN( pTempZones, "TempZones_GetZone", 0);
	
	
	if ( tzIndex < MaxTempZones )	// zero based.
	{

		return &(pTempZones->tempZone[tzIndex]);
	}
	else
	{
	
		return &(pTempZones->tempZone[MaxTempZones]); // need to return something so return an invalid zone.
									   // at least nothing can happen here.	
	}
}


//******************************************************************************
// TempZones_setOperationMode
//
// Abstract:
// The oven can be in one of three modes: CoolDown, PowerUpSequencing or
// Operational.
//
// Programmer: Steven Young
// Date: 03/19/1998
//******************************************************************************
BOOL TempZones_setOperationMode(TempZones* pTempZones, enum OperationMode mode )
{
	BOOL status;
	PARAM_CHECK_RETURN( pTempZones, "TempZones_setOperationMode", 0);
	switch (mode)
	{
		case CoolDown:
		case PowerUpSequencing:
		case Operational:
			pTempZones->tempState = mode;
			status = TRUE;
			break;
		//when job load we must check if a sequencing is pending
		case JobLoading:
		case JobLoadComplete:
			if(pTempZones->startUpGroup != 1)
			{
				pTempZones->tempState = mode;
			}
			else
			{
			   pTempZones->tempState = PowerUpSequencing;
			}
			status = TRUE;
			break;
		default:
			status = FALSE;
		break;
	}

	return status;
};

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_initializePowerUpSequencing
			This event must occur once in order to set all the zones to the appropriate
			state such as whether it is in automatic mode, PID calculations on or
			manual mode where the operator has the ability to change the output
			power. All zones associated with group 1 will have the their modes set
			to automatic. No changes in tpo output percentages will be allowed for any
			zone during power up sequencing for a zone that is in manual.

 RETURNS:   void
------------------------------------------------------------------------*/
void TempZones_initializePowerUpSequencing(TempZones* pTempZones )
{
	int currentZone;
	TempZone* pTZone;
	UINT sequenceGroup;
	BOOL bFluxEnabled;
	BOOL bActive;

	int iHighZone;

	iHighZone = MaxTempZones-1;

	currentZone = 0;
	pTZone = NULL;
	sequenceGroup = 0;
	bFluxEnabled = FALSE;
	bActive = FALSE;

	pTempZones->m_timeStartupCompleted = 0;
	pTempZones->m_bTimerStartupEventFired = FALSE;

	FluxHeater_initializePowerUpSequencing(&( g_dbContainer.fluxHeater ));
	FluxHeater_initializePowerUpSequencing(&( g_dbContainer.fluxHeater1 ));
	FluxHeater_initializePowerUpSequencing(&( g_dbContainer.fluxHeater2 ));
	FluxHeater_initializePowerUpSequencing(&( g_dbContainer.fluxHeater3 ));
	FluxHeater_initializePowerUpSequencing(&( g_dbContainer.fluxHeater4 ));
	
	// Save the current state of the audible alarms to restore them after
	// the power up sequencing completes.
	pTempZones->m_bAudibleAlarms_savedState = alarmQDb->m_bOKForAudibleWarnings;
	AlarmQueue_enableAudibleWarnings(alarmQDb, FALSE);

	AlarmQueue_clearLoggedEvents(alarmQDb);
	
	TempZones_ResetStartupSequenceTimer(pTempZones);
	TempZones_setOperationMode(pTempZones, PowerUpSequencing);
	
	*DOUT_GetAt(digOutDb, ODO_CONVEYOR_BLOWER) = TRUE;
	*DOUT_GetAt(digOutDb, ODO_HEATER_CONTACT) = TRUE;	// On all jobs but cooldown turn on heater contactor.
	
	pTempZones->powerUpSequencingInProgress	= TRUE;
	pTempZones->startUpGroup = 1;// Always Start with group one
	
	Oven_setStartupGroup(ovenDb, pTempZones->startUpGroup);
	
	pTempZones->nextGroup = FALSE;	
	pTempZones->waitingForTimer = FALSE;
	
	Belts_initializePowerUpSequencing(&(g_dbContainer.beltsDb));
	
	FluxHeater_setPowerUpDelayFlag(flxHeat, FALSE);
	FluxHeater_blowerFailure(flxHeat, FALSE);//Zone should operate normally
	FluxHeater_ActivateZones(flxHeat, (short)pTempZones->startUpGroup, TRUE);

	FluxHeater_setPowerUpDelayFlag(flxHeat1, FALSE);
	FluxHeater_blowerFailure(flxHeat1, FALSE);//Zone should operate normally
	FluxHeater_ActivateZones(flxHeat1, (short)pTempZones->startUpGroup, TRUE);

	FluxHeater_setPowerUpDelayFlag(flxHeat2, FALSE);
	FluxHeater_blowerFailure(flxHeat2, FALSE);//Zone should operate normally
	FluxHeater_ActivateZones(flxHeat2, (short)pTempZones->startUpGroup, TRUE);

	FluxHeater_setPowerUpDelayFlag(flxHeat3, FALSE);
	FluxHeater_blowerFailure(flxHeat3, FALSE);//Zone should operate normally
	FluxHeater_ActivateZones(flxHeat3, (short)pTempZones->startUpGroup, TRUE);

	FluxHeater_setPowerUpDelayFlag(flxHeat4, FALSE);
	FluxHeater_blowerFailure(flxHeat4, FALSE);//Zone should operate normally
	FluxHeater_ActivateZones(flxHeat4, (short)pTempZones->startUpGroup, TRUE);
	
	Belts_doPowerUpSequencing(&(g_dbContainer.beltsDb), pTempZones->startUpGroup);
	sequenceGroup = FluxHeater_getSequenceGroup(flxHeat1);
	bFluxEnabled = FluxHeater_isFluxHeaterEnabled(flxHeat1);
	if( ( sequenceGroup == TH_STARTUPGROUP ) && bFluxEnabled )//TH zone
	{
		FluxHeater_setPowerUpDelayFlag(flxHeat1, TRUE);
		FluxHeater_setPIDenable(flxHeat1, TRUE);	// pid's enabled.
		FluxHeater_process(flxHeat1);			// need to do this so second group doesn't start to early.
		FluxHeater_setTPOoutput(flxHeat1, MAX_TPO_COUNTS);
	}

	sequenceGroup = FluxHeater_getSequenceGroup(flxHeat);
	bFluxEnabled = FluxHeater_isFluxHeaterEnabled(flxHeat);

	if( ( sequenceGroup == TH_STARTUPGROUP ) && bFluxEnabled)//TH zone
	{
		FluxHeater_setPowerUpDelayFlag(flxHeat, TRUE);
		FluxHeater_setPIDenable(flxHeat, TRUE);	// pid's enabled.
		FluxHeater_process(flxHeat2);			// need to do this so second group doesn't start to early.
		FluxHeater_setTPOoutput(flxHeat, MAX_TPO_COUNTS);
	}
	
	//note we are deactivating from high to low as low zones are ussually started first.  This was attempt to eliminate the 5 zone overdraw warning.
	//it failed so the change was not ported to the Hc1 base
	for ( currentZone = iHighZone; currentZone >-1; currentZone-- )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		bActive = TempZone_isActive(pTZone);
		if ( bActive == TRUE )
		{
			TempZone_blowerFailure(pTZone, FALSE);//Zone should operate normally
			TempZone_setPowerUpComplete(pTZone, FALSE); // disable rise rate check until power up group hit
			TempZone_setAlarmsEnabled(pTZone, FALSE); // don't mess with inactive zones
			TempZone_setGroupStarted(pTZone, FALSE);

			sequenceGroup = TempZone_getSequenceGroup(pTZone);
			if ( sequenceGroup == pTempZones->startUpGroup )
			{
				TempZone_setPowerUpComplete(pTZone, TRUE);
				TempZone_setPIDenable(pTZone, TRUE);	// pid's enabled.
				TempZone_process(pTZone);			// need to do this so second group doesn't start to early.
				TempZone_enableDeadBandRangeCheck(pTZone, TRUE);
				TempZone_setGroupStarted(pTZone, TRUE);

				//attempt to fix do power sequence error
				TempZone_setTPOoutput(pTZone, MAX_TPO_COUNTS);
			}
			else if(sequenceGroup == TH_STARTUPGROUP)//TH zone
			{
				TempZone_setPowerUpComplete(pTZone, TRUE);
				TempZone_setPIDenable(pTZone, TRUE);	// pid's enabled.
				TempZone_process(pTZone);			// need to do this so second group doesn't start to early.
				TempZone_enableDeadBandRangeCheck(pTZone, TRUE);
				TempZone_setTPOoutput(pTZone, MAX_TPO_COUNTS);
			}
			else if(sequenceGroup > pTempZones->startUpGroup) // zone is greater than current startup group.
			{

				TempZone_setPIDenable(pTZone, FALSE);	// manual and 0% output.
				TempZone_setTPOoutput(pTZone, 0);
				TempZone_enableDeadBandRangeCheck(pTZone, FALSE);	
			}
		}
		else  // zone is not active
		{
			TempZone_setPIDenable(pTZone, FALSE);		// manual and 0% output.
			TempZone_setTPOoutput(pTZone, 0);
			TempZone_enableDeadBandRangeCheck(pTZone, FALSE);
		}
	}
	pTempZones->bNewSequenceStarted = TRUE;
	
	TempZones_setSGCOutputValue( SGC_OFF_STATE );

	pTempZones->bZoneProcessed = 0;	
	Oven_setSecondaryJob(ovenDb,ovenDb->tempJobNo);
	return;
}

BOOL TempZones_setStartUpPowerPercent(TempZones* pTempZones, DWORD dStartUpPowerPercent )
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pTempZones, "TempZones_setStartUpPowerPercent", 0);

	if ( dStartUpPowerPercent <= 100 )
	{
		pTempZones->startUpPowerPercentTPOcounts = dStartUpPowerPercent * 256/100;
		status = TRUE;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_setDelayStartPeriod
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_setDelayStartPeriod(TempZones* pTempZones, UINT delayStartPeriod10thsOfSeconds )
{
	PARAM_CHECK( pTempZones, "TempZones_setDelayStartPeriod");
	pTempZones->delayStartPeriod10ths = delayStartPeriod10thsOfSeconds;

}

void TempZones_completePowerupSequencingTimer(TempZones* pTempZones)
{
	if ( pTempZones->m_bTimerStartupEventFired == FALSE )
	{
		const BOOL bStartupComplete = Oven_isJobStartupComplete(ovenDb);
		const DWORD dwrdStartupCompleteDelayIn10thSec = Oven_getStartupCompletePlusDelayTime(ovenDb);  //ver8.0.0.12

		if ( bStartupComplete && pTempZones->m_timeStartupCompleted )
		{
			const DWORD currentTime = Timer_getCurrentTime10ths( timerDb );
			//printk( "TempZones_process: current time %d\n", currentTime );

			//if ( differenceWithRollover(currentTime, pTempZones->m_timeStartupCompleted) >= 1200 ) 
			if ( differenceWithRollover(currentTime, pTempZones->m_timeStartupCompleted) >= dwrdStartupCompleteDelayIn10thSec ) //ver8.0.0.12
			{
				AlarmQueue_addAlarm(alarmQDb, INFORMATION, TEMPZONE_SEQ_COMPLETE_TIMER, 0);
				pTempZones->m_bTimerStartupEventFired = TRUE;

				// restore the audible alarms state				
				AlarmQueue_enableAudibleWarnings(alarmQDb, pTempZones->m_bAudibleAlarms_savedState);
			}
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  TempZones_process

				Calls all the functions that are associated with the 
				tempzone operation.  CoolDown, Power Up Sequencing, 
				PID calculations alarm and warning monitoring.

	RETURNS:	N/A
--------------------------------------------------------------------*/
void TempZones_process(TempZones* pTempZones )
{
	/* Once the timerOn boolean is true the counter will increment elapsedstartperiod10ths
	if it matches the delay set in the setup wizard the next group will heat up and we reset the 
	control to native state to await the next group */

	UINT delayStartPeriodSeconds ;
	unsigned int currentZone;
	unsigned int lcv;
	TempZone* pTZone;
	BOOL bCooldownComplete;
	int chan_count;
	BOOL bJobLoadInProgress;
	UINT currJob;
	BOOL bJobStartupComplete;
	TempZone* pTZ;
	UINT uTowerStat;
	UINT tempJob;
	BOOL* pDout;
	BOOL bFluxHeaterActive;
	BOOL bTempZoneActive;
	BOOL bTempZoneInDeadband;
	SHORT sZoneState;

	delayStartPeriodSeconds = pTempZones->delayStartPeriod10ths/10;
	currentZone = 0;
	lcv = 0;
	pTZone = NULL;
	bCooldownComplete = FALSE;
	chan_count = 0;
	bJobLoadInProgress = FALSE;
	currJob = 0;
	bJobStartupComplete = FALSE;
	pTZ = NULL;
	uTowerStat = 0;
	tempJob = 0;
	pDout = NULL;
	bFluxHeaterActive = FALSE;
	bTempZoneActive = FALSE;
	bTempZoneInDeadband = FALSE;
	sZoneState = 0;
	
	if( NULL != pTempZones )
	{	
		if(pTempZones->startUpGroup > STARTUP_GROUPS)//all groups have sequenced, allow dual input/motor activation on belts
		{
			Belts_TempzonesAreSequenced(&(g_dbContainer.beltsDb), TRUE);
			g_dbContainer.heatZoneBlowers.bInStartupMode = FALSE;
			g_dbContainer.globalBlower.bInStartupMode = FALSE;
			g_dbContainer.analogFan.bInStartupMode = FALSE;
		}
		else
		{
			Belts_TempzonesAreSequenced(&(g_dbContainer.beltsDb), FALSE);
		}
	
	
		if(pTempZones->delayStartPeriod10ths && pTempZones->timerOn)
		{
			TempZones_secondaryTPOtest(pTempZones);
			(pTempZones->elapsedStartPeriod)++;
	
			chan_count = TempZones_getNumberOfChannelsInGroup(pTempZones, pTempZones->startUpGroup);
	
			if( (pTempZones->elapsedStartPeriod >= delayStartPeriodSeconds) ||
				(chan_count == 0) )
			{
				pTempZones->nextGroup = TRUE;
				pTempZones->elapsedStartPeriod=0;
				pTempZones->timerOn=FALSE;			
			}
		}

		bJobLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
		if ( bJobLoadInProgress == TRUE )
		{
			TempZones_setOperationMode(pTempZones,  JobLoading );
		}
		
		bJobLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
		if ( (bJobLoadInProgress == FALSE) && (pTempZones->tempState == JobLoading) )
		{
			TempZones_setOperationMode(pTempZones,  JobLoadComplete );
		}
		
		currJob = Oven_getJob(ovenDb);
		if ( currJob != COOLDOWN )
		{
			bJobStartupComplete = Oven_isJobStartupComplete(ovenDb);
			if ( bJobStartupComplete == FALSE && pTempZones->tempState != PowerUpSequencing )
			{
				if ( pTempZones->tempState != JobLoading  )
				{
					TempZones_GetMaxSequenceGroupNo(pTempZones);
				}
			}
	
			if ( pTempZones->tempState == JobLoading  )
			{
				for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
				{
					pTZ = TempZones_GetZone(pTempZones, currentZone);
					
					if( NULL != pTZ )
					{
						TempZone_setPIDenable(pTZ, FALSE);		
						// per meeting with D. Heller, D. Smith, M. Vincent, Roger ? 
						// and S. Young the tpo output will be 0% reference bug 
						// no 492.
						TempZone_setTPOoutput(pTZ, 0);	
					}
				}
			}
	
			bJobStartupComplete = Oven_isJobStartupComplete(ovenDb);
			uTowerStat = LightTower_getCombinedStatus(lightTower);
			if( bJobStartupComplete && uTowerStat == GREEN)
			{
				TempZones_enableDrawWarning(pTempZones, TRUE);
			}
	
			bJobStartupComplete = Oven_isJobStartupComplete(ovenDb);
			currJob = Oven_getJob(ovenDb);
			tempJob = Oven_getTempJobNo(ovenDb);
			if ( (bJobStartupComplete == FALSE) && 
				  (pTempZones->tempState == PowerUpSequencing) && 
				  (currJob != COOLDOWN) && 
				  (tempJob != COOLDOWN) )
			{
			
				//initializepowerupsequencing should be called before the do power up sequencing
				//note I am requiring one process loop before doing power up sequencing to allow 
				//the individual temp zones to calculate an output.  Maybe the problem with the 
				//phantom overdraw?
				if( pTempZones->startUpGroup && 
				    (pTempZones->startUpGroup < STARTUP_GROUPS_PLUSONE) && 
					 pTempZones->bZoneProcessed )
				{
					TempZones_doPowerUpSequencing(pTempZones);
				}
				
				if(pTempZones->startUpGroup >= STARTUP_GROUPS_PLUSONE)
				{
					TempZones_completePowerupSequencing(pTempZones);
				}
				
				pTempZones->bZoneProcessed = 1;
			}
			else
			{
				pTempZones->bZoneProcessed = 0;
			}
		}
		else
		{
			TempZones_enableDrawWarning(pTempZones, FALSE);
			tempJob = Oven_getTempJobNo(ovenDb);
			if( tempJob == CoolDown )
			{
				TempZones_setOperationMode(pTempZones, CoolDown);
				pDout = DOUT_GetAt(digOutDb, ODO_HEATER_CONTACT);
				if( NULL != pDout )
				{
					*pDout = FALSE;		// turn off heat relay contact
				}
			}
			//note the oven job is not set for 2 scan counts, this causes a 
			//problem on the hc2 as the pid can be disabled after the 
			//sequencing is started.  Using the temp job no which is set at 
			//0 scan counts and cleared when cooldown is activated 
			bJobLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
			tempJob = Oven_getTempJobNo(ovenDb);
			if ( bJobLoadInProgress == FALSE && tempJob == COOLDOWN )
			{
				for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
				{
					pTZone = &(pTempZones->tempZone[currentZone]);
					
					if( NULL != pTZone )
					{
						TempZone_setSetPoint(pTZone, (LONG)pTempZones->m_dwrdCooldownSetpoint/* COOLDOWN_SETPOINT */);	// 95 degrees C or 950 counts.
						TempZone_setAlarmsEnabled(pTZone, FALSE);
						TempZone_setTPOoutput(pTZone, 0);
						TempZone_setPIDenable(pTZone, FALSE);
						TempZone_enableDeadBandRangeCheck(pTZone, FALSE);
					}
					
					// check all zones to see if the cooldown temp of 95 degrees c has been reached.
					// if so let the oven database module know so the other modules can perform
					// there funcions.
					Oven_setCOOLDOWNachieved(ovenDb, TempZones_coolDownReachedAllZones(pTempZones));
				}
				
				//set the flux heaters to cooldown sp
				bFluxHeaterActive = FluxHeater_isActive(flxHeat);
				if( bFluxHeaterActive )
				{
					FluxHeater_setSetPoint(flxHeat,(LONG)pTempZones->m_dwrdCooldownSetpoint);
				}
				
				bFluxHeaterActive = FluxHeater_isActive(flxHeat1);
				if( bFluxHeaterActive )
				{
					FluxHeater_setSetPoint(flxHeat1,(LONG)pTempZones->m_dwrdCooldownSetpoint);
				}
				
				bFluxHeaterActive = FluxHeater_isActive(flxHeat2);
				if( bFluxHeaterActive )
				{
					FluxHeater_setSetPoint(flxHeat2,(LONG)pTempZones->m_dwrdCooldownSetpoint);
				}
				
				bFluxHeaterActive = FluxHeater_isActive(flxHeat3);
				if( bFluxHeaterActive )
				{
					FluxHeater_setSetPoint(flxHeat3,(LONG)pTempZones->m_dwrdCooldownSetpoint);
				}
				
				bFluxHeaterActive = FluxHeater_isActive(flxHeat4);
				if( bFluxHeaterActive )
				{
					FluxHeater_setSetPoint(flxHeat4,(LONG)pTempZones->m_dwrdCooldownSetpoint);
				}
			}
			
			//We are in COOLDOWN, so test to see if it is time to 
			//Turn off the Startup Group Controlled Relay Output
			bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
			
			if( bCooldownComplete )
			{
				TempZones_setSGCOutputValue( SGC_OFF_STATE );
			}
		}
		// when going through the zones check and see which ones are in deadband. If they are then 
		// the green light can be set.
	
		pTempZones->intermediateAllzonesInDb = TRUE;
	
		for ( lcv = 0; lcv < pTempZones->maxGroups; lcv++ )
		{
			// if the temperature zone is off then the oven state of not being within deadband 
			// should not be determined by zones that are intentionally turned. If the
			// zones are turned off deadband will never be achieved.
			// SDY - 10/07/1998
			bTempZoneActive = TempZone_isActive(&(pTempZones->tempZone[lcv]));
			bTempZoneInDeadband = TempZone_isInDeadBandZone(&(pTempZones->tempZone[lcv]));
			sZoneState = TempZone_getZoneState(&(pTempZones->tempZone[lcv]));
			if ( (bTempZoneActive == TRUE) && 
				  (bTempZoneInDeadband == FALSE && 
					sZoneState != eOFF ))
			{
				pTempZones->intermediateAllzonesInDb = FALSE;
			}
			TempZone_process( &(pTempZones->tempZone[lcv]) );
		}
		if(pTempZones->m_bCheckIOErrors==TRUE)
		{
			TempZones_tdmTest(pTempZones);
		}
		TempZones_CheckMaxPowerZones(pTempZones); 
		pTempZones->allZonesInDeadBand = pTempZones->intermediateAllzonesInDb;
		
		TempZones_completePowerupSequencingTimer(pTempZones);
	}
	
	return;
}

BOOL TempZones_coolDownReachedAllZones(TempZones* pTempZones)
{
	BOOL coolDownComplete = TRUE;
	TempZone *pTempZone;
	UINT currentZone;
	PARAM_CHECK_RETURN( pTempZones, "TempZones_coolDownReachedAllZones", 0);
	
	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTempZone = &(pTempZones->tempZone[currentZone]);
		if ( TempZone_isActive(pTempZone) )
		{
			if ( TempZone_getProcVar(pTempZone) >= pTempZones->m_dwrdCooldownSetpoint /* COOLDOWN_SETPOINT*/ )
			{
				coolDownComplete = FALSE;
			}
		}
	}

	if(FluxHeater_isActive(flxHeat))
		if(FluxHeater_getProcVar(flxHeat) >= pTempZones->m_dwrdCooldownSetpoint /*COOLDOWN_SETPOINT*/)
			coolDownComplete = FALSE;

	if(FluxHeater_isActive(flxHeat1))
		if(FluxHeater_getProcVar(flxHeat1) >= pTempZones->m_dwrdCooldownSetpoint /*COOLDOWN_SETPOINT*/)
			coolDownComplete = FALSE;

	if(FluxHeater_isActive(flxHeat2))
		if(FluxHeater_getProcVar(flxHeat2) >= pTempZones->m_dwrdCooldownSetpoint /*COOLDOWN_SETPOINT*/)
			coolDownComplete = FALSE;
	if(FluxHeater_isActive(flxHeat3))
		if(FluxHeater_getProcVar(flxHeat3) >= pTempZones->m_dwrdCooldownSetpoint )
			coolDownComplete = FALSE;
	if(FluxHeater_isActive(flxHeat4))
		if(FluxHeater_getProcVar(flxHeat4) >= pTempZones->m_dwrdCooldownSetpoint )
			coolDownComplete = FALSE;
	return coolDownComplete;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_doPowerUpSequencing
 
 				Processes the power up sequencing

 RETURNS:   void
------------------------------------------------------------------------*/
void TempZones_doPowerUpSequencing(TempZones* pTempZones )
{

	UINT iTotalInStartupGroup = 0;
	UINT iTotalBelowStartupPercentage = 0;
	UINT fluxGroup = 0;
	DWORD TPOOutputReading;
	DWORD TPOTestOutputs;
	int currentZone = 0;
	TempZone* pTZone;
	UINT NumChansInGroup;
	BOOL bFluxHeaterActive;
	BOOL bFluxHeaterInAutoMode;
	DWORD dFluxHeaterTPO;
	BOOL bFluxHeaterEnable;
	DWORD dSeqGrp;
	BOOL bTempZoneActive;
	DWORD dTPOoutput;
	int chan_count;
	
	iTotalInStartupGroup = 0;
	iTotalBelowStartupPercentage = 0;
	fluxGroup = 0;
	TPOOutputReading = 0;
	TPOTestOutputs = 0;
	currentZone = 0;
	pTZone = NULL;
	NumChansInGroup = 0;
	bFluxHeaterActive = FALSE;
	bFluxHeaterInAutoMode = FALSE;
	dFluxHeaterTPO = 0;
	bFluxHeaterEnable = FALSE;
	dSeqGrp = 0;
	bTempZoneActive = FALSE;
	dTPOoutput = 0;
	chan_count = 0;

	if( NULL != pTempZones )
	{
		if ( pTempZones->powerUpSequencingInProgress == TRUE)
		{
			if(pTempZones->bNewSequenceStarted)
			{
				pTempZones->bNewSequenceStarted = FALSE;
				
				NumChansInGroup = TempZones_getNumberOfChannelsInGroup(pTempZones, pTempZones->startUpGroup);
				if( 0 != NumChansInGroup )
				{
					AlarmQueue_addAlarm(alarmQDb, LOGGED_EVENT, TZ_STARTUP_GROUP_CALLED, pTempZones->startUpGroup);
				}
			}
	
			if ( pTempZones->nextGroup == FALSE )
			{
				if(!pTempZones->waitingForTimer)
				{
					pTempZones->nextGroup = TRUE;
				}
				if(!pTempZones->waitingForTimer)
				{
					fluxGroup = FluxHeater_getSequenceGroup(flxHeat);
					if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
					{
						bFluxHeaterActive = FluxHeater_isActive(flxHeat);
						bFluxHeaterInAutoMode = FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat);
						if( bFluxHeaterActive == TRUE && bFluxHeaterInAutoMode == TRUE )
						{
							iTotalInStartupGroup++;
							
							dFluxHeaterTPO = FluxHeater_getTPOoutput(flxHeat);
							if( dFluxHeaterTPO > pTempZones->startUpPowerPercentTPOcounts)
							{
								pTempZones->nextGroup = FALSE;
							}
							else
							{
								iTotalBelowStartupPercentage++;
							}
						}
					}

					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat1);
					if( bFluxHeaterEnable )
					{
						fluxGroup = FluxHeater_getSequenceGroup(flxHeat1);
						if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
						{
							bFluxHeaterActive = FluxHeater_isActive(flxHeat1);
							bFluxHeaterInAutoMode = FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat1);
							if( bFluxHeaterActive == TRUE && bFluxHeaterInAutoMode ==TRUE )
							{
								iTotalInStartupGroup++;
	
								dFluxHeaterTPO = FluxHeater_getTPOoutput(flxHeat1);
								if( dFluxHeaterTPO > pTempZones->startUpPowerPercentTPOcounts)
								{
									pTempZones->nextGroup = FALSE;
								}
								else
								{
									iTotalBelowStartupPercentage++;
								}
							}
						}
					}
					
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat2);
					if( bFluxHeaterEnable )
					{
						fluxGroup = FluxHeater_getSequenceGroup(flxHeat2);
						if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
						{
							bFluxHeaterActive = FluxHeater_isActive(flxHeat2);
							bFluxHeaterInAutoMode = FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat2);
							if( bFluxHeaterActive == TRUE && bFluxHeaterInAutoMode ==TRUE )
							{
								iTotalInStartupGroup++;
	
								dFluxHeaterTPO = FluxHeater_getTPOoutput(flxHeat2);
								if( dFluxHeaterTPO > pTempZones->startUpPowerPercentTPOcounts )
								{
									pTempZones->nextGroup = FALSE;
								}
								else
								{
									iTotalBelowStartupPercentage++;
								}
							}
						}
					}
										
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat3);
					if( bFluxHeaterEnable )
					{
						fluxGroup = FluxHeater_getSequenceGroup(flxHeat3);
						if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
						{
							bFluxHeaterActive = FluxHeater_isActive(flxHeat3);
							bFluxHeaterInAutoMode = FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat3);
							if( bFluxHeaterActive == TRUE && bFluxHeaterInAutoMode ==TRUE )
							{
								iTotalInStartupGroup++;
	
								dFluxHeaterTPO = FluxHeater_getTPOoutput(flxHeat3);
								if( dFluxHeaterTPO > pTempZones->startUpPowerPercentTPOcounts)
								{
									pTempZones->nextGroup = FALSE;
								}
								else
								{
									iTotalBelowStartupPercentage++;
								}
							}
						}
					}
										
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat4);
					if( bFluxHeaterEnable )
					{
						fluxGroup = FluxHeater_getSequenceGroup(flxHeat4);
						if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
						{
							bFluxHeaterActive = FluxHeater_isActive(flxHeat4);
							bFluxHeaterInAutoMode = FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat4);
							if( bFluxHeaterActive == TRUE && bFluxHeaterInAutoMode ==TRUE )
							{
								iTotalInStartupGroup++;
	
								dFluxHeaterTPO = FluxHeater_getTPOoutput(flxHeat4);
								if( dFluxHeaterTPO > pTempZones->startUpPowerPercentTPOcounts)
								{
									pTempZones->nextGroup = FALSE;
								}
								else
								{
									iTotalBelowStartupPercentage++;
								}
							}
						}
					}
				}
	
				for ( currentZone=0; currentZone < MaxTempZones; currentZone++ )
				{
					if(!pTempZones->waitingForTimer)
					{
						pTZone = &(pTempZones->tempZone[currentZone]);
		
						dSeqGrp = TempZone_getSequenceGroup(pTZone);
						if ( dSeqGrp == pTempZones->startUpGroup )
						{
							pTZone->readDelay=pTempZones->readDelay;

							bTempZoneActive = TempZone_isActive(pTZone);
							if ( (bTempZoneActive == TRUE) && (pTZone->pidCtrl.zoneAuto == eAUTO) )
							{
								TPOOutputReading = TempZone_getTPOoutput(pTZone);
	
								TPOTestOutputs = pTempZones->startUpPowerPercentTPOcounts;
								iTotalInStartupGroup++;
								{
									dTPOoutput = TempZone_getTPOoutput(pTZone);
									if ( (pTZone->readDelay>0) || 
									     ( dTPOoutput >= pTempZones->startUpPowerPercentTPOcounts) ) 
									{
										pTempZones->nextGroup = FALSE;
										pTZone->readDelay--;
									}
									else
									{
										iTotalBelowStartupPercentage++;
									}
								}
								TempZone_setGroupStarted(pTZone, TRUE);
							
							}
							else if ( bTempZoneActive == TRUE )
							{
								TempZone_manualZoneSequencedOn(pTZone);
							}
						}
					}
					else 
					{
						pTZone = &(pTempZones->tempZone[currentZone]);
					}
				}
				if( pTempZones->readDelay > 0 )
				{
					pTempZones->readDelay--;
				}
	
				if(iTotalInStartupGroup == iTotalBelowStartupPercentage && !pTempZones->waitingForTimer)
				{
					if(pTempZones->delayStartPeriod10ths == 0)
					{
						pTempZones->nextGroup = TRUE;
						pTempZones->waitingForTimer = TRUE;
					}
					else
					{
						pTempZones->nextGroup = FALSE;
						pTempZones->timerOn = TRUE;
						pTempZones->waitingForTimer = TRUE;
					}
				}
				else
				{
					pTempZones->nextGroup = FALSE;
				}
	
			}
			else 
			{
				chan_count = 0;
			
				// skip over empty startup groups.
				do
				{
					(pTempZones->startUpGroup)++;
					chan_count = TempZones_getNumberOfChannelsInGroup(pTempZones, pTempZones->startUpGroup);
				}
				while ( (chan_count == 0) && (pTempZones->startUpGroup <= pTempZones->maxGroups) );
				
				//Here we activate the Startup Group Controlled Output Relay 
				//if the feature is enabled. The function determines if it
				//is valid to set the output.
				if( pTempZones->startUpGroup >= pTempZones->m_nStartupGrpControlledGroup )
				{
					TempZones_setSGCOutputValue( SGC_ON_STATE );
				}
				
				Oven_setSecondaryJob(ovenDb,ovenDb->jobNo);
				
				if(ovenDb->wantResume==TRUE)//to ensure that secondary is matching primary
				{
					Oven_resume(ovenDb);
				}
				else
				{
					Oven_pause(ovenDb);
				}
				if(pTempZones->delayStartPeriod10ths >1)//allow time for slave tpo propigation
				{
					pTempZones->readDelay = MINIMUM_READ_DELAY;
				}
				Oven_setStartupGroup(ovenDb, pTempZones->startUpGroup);
				pTempZones->waitingForTimer = FALSE;
				if ( pTempZones->startUpGroup <= pTempZones->maxGroups )
				{
					pTempZones->nextGroup = FALSE;

					NumChansInGroup = TempZones_getNumberOfChannelsInGroup(pTempZones, pTempZones->startUpGroup);
					if( 0 != NumChansInGroup )
					{
						AlarmQueue_addAlarm(alarmQDb, LOGGED_EVENT, TZ_STARTUP_GROUP_CALLED, pTempZones->startUpGroup);
					}
					Belts_doPowerUpSequencing(&(g_dbContainer.beltsDb), pTempZones->startUpGroup);
	
					FluxHeater_ActivateZones(flxHeat, (short) pTempZones->startUpGroup, TRUE);

					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat1);
					if( bFluxHeaterEnable )
					{
						FluxHeater_ActivateZones(flxHeat1, (short) pTempZones->startUpGroup, TRUE);
					}
					
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat2);
					if( bFluxHeaterEnable )
					{
						FluxHeater_ActivateZones(flxHeat2, (short) pTempZones->startUpGroup, TRUE);
					}
					
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat3);
					if( bFluxHeaterEnable )
					{
						FluxHeater_ActivateZones(flxHeat3, (short) pTempZones->startUpGroup, TRUE);
					}
					
					bFluxHeaterEnable = FluxHeater_isFluxHeaterEnabled(flxHeat4);
					if( bFluxHeaterEnable )
					{
						FluxHeater_ActivateZones(flxHeat4, (short) pTempZones->startUpGroup, TRUE);
					}
	
					for ( currentZone=0; currentZone < MaxTempZones; currentZone++ )
					{
						pTZone = &(pTempZones->tempZone[currentZone]);

						if( NULL != pTZone )
						{
							bTempZoneActive = TempZone_isActive(pTZone);
							if ( bTempZoneActive == TRUE )
							{
	
								dSeqGrp = TempZone_getSequenceGroup(pTZone);
								if ( dSeqGrp == pTempZones->startUpGroup )
								{
									TempZone_setPowerUpComplete(pTZone, TRUE);
		
									TempZone_setPIDenable(pTZone, TRUE);
									TempZone_enableDeadBandRangeCheck(pTZone, TRUE);
								}
							}
						}
					}
				}
			}
		}
	}
	
	return;
}

//******************************************************************************
// void TempZones_setMinRiseDegreeCounts( DWORD minRiseDegrees )
//
// Abstract:
// The minimum rise degree counts is the number of degrees rise per unit time,
// a rate, that must be achieved to prevent an alarm. 
// 
// Programmer: Steven Young
// Date: 07/02/1998
//******************************************************************************
void TempZones_setMinRiseDegreeCounts(TempZones* pTempZones, DWORD minRiseDegrees)
{
	PARAM_CHECK( pTempZones, "TempZones_setMinRiseDegreeCounts");
	pTempZones->minimumRiseDegrees = minRiseDegrees;
}

//******************************************************************************
// void TempZones_setMinRiseRatePeriod10ths( DWORD riseRatePeriodIn10ths )
//
// Abstract:
// The time required for a heater zone to rise a minimum of minimumRiseDegrees
// without causing an alarm.	 
//
// Programmer: Steven Young
// Date: 07/02/1998
//******************************************************************************
void TempZones_setRiseRatePeriod(TempZones* pTempZones, DWORD riseRatePeriodIn10ths )
{
	PARAM_CHECK( pTempZones, "TempZones_setRiseRatePeriod");
	pTempZones->heaterRiseRatePeriod10ths = riseRatePeriodIn10ths;

}

//******************************************************************************
// void TempZones_CheckMaxPowerZones( )
//
// Abstract:
// If more than 5 zones are at 100% then start a new power up sequence. Can be
// caused by opening the hood or shutting off the circuit breakers.
// Discussed with Doug Smith and Jim Neville on 10/29/99. Doug felt the best way
// to handle was to institute an Alarm Condition loading COOLDOWN. Sony did not
// want alarm if hood opened. I agreed with Doug originally but believe the power
// up sequencing is probably best in production. Will verify with Doug.
//
// Programmer: Steven Young
// Date: 10/29/1999
//
//******************************************************************************
void TempZones_CheckMaxPowerZones(TempZones* pTempZones )
{
	static int totalZonesAt100Percent;
	int zoneNo = 0;
	TempZone* pTZone = NULL;
	DWORD dwrdZoneOutput = 0;
	DWORD dwrdSequence = 0;

	PARAM_CHECK( pTempZones, "TempZones_CheckMaxPowerZones");

	totalZonesAt100Percent = 0;
	BOOL bResequenced=FALSE;
	for( zoneNo = 0; zoneNo < MaxTempZones; zoneNo++ )
	{
		pTZone = &(pTempZones->tempZone[zoneNo]);
		BOOL bActive = TempZone_isActive(pTZone);
		if(bActive)
		{
			dwrdZoneOutput = TempZone_getTPOoutput(pTZone);
			dwrdSequence = TempZone_getSequenceGroup(pTZone);
			if ( (dwrdZoneOutput ==  MAX_TPO_COUNTS) && (dwrdSequence != 100))
			{
				totalZonesAt100Percent++;
				if ( totalZonesAt100Percent >=  pTempZones->m_iNumberZonesForDrawwarn  &&bResequenced==FALSE)
				{
					bResequenced=TRUE;
					if(pTempZones->m_iResequenceDelay<=0)
					{
						Oven_setJobStartupComplete(ovenDb, FALSE);
						TempZones_resetZonesToResequence(pTempZones);
						TempZones_initializePowerUpSequencing(pTempZones);
						AlarmQueue_addAlarm(alarmQDb, WARNING, OVER_CURRENTDRAW, 0);
						pTempZones->m_iResequenceDelay=4;
					
					}
					else
					{
						pTempZones->m_iResequenceDelay--;
					}
				}
				else
				{
					pTempZones->m_iResequenceDelay=0;
				}
			}
		}
	}
}

//******************************************************************************
// void TempZones_ResetZonesToResequence( )
//
// Abstract:
// If more than 5 zones are at 100% then a resequence needs to be restarted.
// In order to this the deadband, alarmbands flags must be set to false.
// The riseRateSetPointChange is more of a redundancy that may not be required.	
//
//
// Programmer: Steven Young
// Date: 02/17/2000
//
//******************************************************************************
void TempZones_resetZonesToResequence(TempZones* pTempZones)
{
	TempZone* pTZone;
	unsigned int zoneNo;
	PARAM_CHECK( pTempZones, "TempZones_resetZonesToResequence");

	for( zoneNo = 0; zoneNo < MaxTempZones; zoneNo++ )
	{
		pTZone = &(pTempZones->tempZone[zoneNo]);

		TempZone_setDeadBandState( pTZone, FALSE );
		TempZone_setAlarmsEnabled( pTZone,  FALSE );

		pTZone->riseRateSetPointChange = TRUE;
	}
}

//******************************************************************************
// void TempZones_CalculateMinMaxEnabledZone( )
//
// Abstract:
// Due to a potential problem with the reflow zone(s) being at a temperature 
// high enough not to allow the temperature to drop below the startup sequence
// power level, typically 80%, the reflow zones when its PID is enabled will
// indicate the end of the startup.
// If a zone in the middle causes a similar scenario, the sequencing will just
// stop until the power level drops below the startup sequence power level. This
// in theory could take forever.
// If the last active zone is on the bottom then reference back to top which should
// be in the same start up zone.
//
// Programmer: Steven Young
// Date: 02/09/1999
//
//******************************************************************************
void TempZones_GetMaxSequenceGroupNo(TempZones* pTempZones)
{
	TempZone* pTZone;
	UINT currentZone;
	PARAM_CHECK( pTempZones, "TempZones_GetMaxSequenceGroupNo");

	pTempZones->highestActiveGroupNo = 0;

	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[pTempZones->currentZone]);
		
		if ( TempZone_isActive(pTZone) )
		{
			if ( TempZone_getZoneState(pTZone) == eAUTO )
			{
				if( TempZone_getSequenceGroup(pTZone) > pTempZones->highestActiveGroupNo )
				{
					 pTempZones->highestActiveGroupNo = TempZone_getSequenceGroup(pTZone);
				}
			}
		}
	}
}

BOOL TempZones_IsWarningConditionPresent(TempZones* pTempZones, short tempzoneNo)
{
	PARAM_CHECK_RETURN( pTempZones, "TempZones_IsWarningConditionPresent", 0);
    return TempZone_IsZoneInWarning( &(pTempZones->tempZone[tempzoneNo]) );
}

//This turns on the process loop for one group of heatzones
void TempZones_ActivateZones(TempZones* pTempZones, short groupNum)
{
	PARAM_CHECK( pTempZones, "TempZones_ActivateZones");
//	if(capOnZoneGroupActivation < groupNum)
//		capOnZoneGroupActivation = groupNum;
/*	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		if ( tempZone[currentZone].isActive()== TRUE )
		{
			if ( tempZone[currentZone].getSequenceGroup() == groupNum )
				tempZone[currentZone].setPowerUpComplete( TRUE);
		}
	} */
}

//turns off the heatzone process loop
void TempZones_DeActivateZones(TempZones* pTempZones)
{
	PARAM_CHECK( pTempZones, "TempZones_DeActivateZones");
//	capOnZoneGroupActivation = 0;

/*	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		if ( tempZone[currentZone].isActive()== TRUE )
			tempZone[currentZone].setPowerUpComplete( FALSE);
	}
*/
}

/* Implicitely turn off the timer when new job is loaded to ensure that the second
group is not activated due to timer WDT */
void TempZones_ResetStartupSequenceTimer(TempZones* pTempZones)
{
	PARAM_CHECK( pTempZones, "TempZones_ResetStartupSequenceTimer");
	pTempZones->elapsedStartPeriod=0;
	pTempZones->timerOn=FALSE;
}

void TempZones_secondaryTPOtest(TempZones* pTempZones)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK( pTempZones, "TempZones_secondaryTPOtest");

	for ( currentZone=0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);

		if ( TempZone_getSequenceGroup(pTZone) == pTempZones->startUpGroup )
		{
			if ( (TempZone_isActive(pTZone) == TRUE) && (pTZone->pidCtrl.zoneAuto == eAUTO) )
			{
				if ( (TempZone_getTPOoutput(pTZone) > pTempZones->startUpPowerPercentTPOcounts) && 
					(TempZone_getSequenceGroup(pTZone) < pTempZones->highestActiveGroupNo ) ) 
				{
					pTempZones->elapsedStartPeriod= 0;
				}
			}
		}
	}
}


void TempZones_setTCWarnPercentage(TempZones* pTempZones, int wPercent)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK( pTempZones, "TempZones_setTCWarnPercentage");

	for (  currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		TempZone_setDrawWarningPercentage(pTZone, wPercent);
	}
}

void TempZones_enableDrawWarning(TempZones* pTempZones, BOOL bEnable)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK( pTempZones, "TempZones_enableDrawWarning");
	//printk("enabling draw warning = %d\n", bEnable);

	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		TempZone_EnableDrawWarning(pTZone, bEnable);
	}
}

SHORT TempZones_zonesAreInDeviationState(TempZones* pTempZones)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK_RETURN( pTempZones, "TempZones_zonesAreInDeviationState", 0);

	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		if(TempZone_isInDeviationAlarmZone(pTZone))
			return TempZone_isInDeviationAlarmZone(pTZone);
	}
	return 0;
}
//Note to operate correctely configureIO depends on execution of tempzones from 0 to max
//if the execution is changed zones will be allocated with incorrect i/o pointers since when
//we set the flag we have no way of knowing what is active/inactive
void TempZones_configureIO(TempZones* pTempZones, short ActiveZones)
{
	PARAM_CHECK( pTempZones, "TempZones_configureIO");
	pTempZones->m_sActiveZoneCount = ActiveZones;
}

void TempZones_completePowerupSequencing(TempZones* pTempZones)
{
	PARAM_CHECK( pTempZones, "TempZones_completePowerupSequencing");
	
	pTempZones->m_timeStartupCompleted = Timer_getCurrentTime10ths( &(g_dbContainer.elapseTimer) );
	//printk( "TempZones_completePowerupSequencing(): time stamp taken %d\n", pTempZones->m_timeStartupCompleted );	

	AlarmQueue_addAlarm(alarmQDb, INFORMATION, TEMPZONE_SEQ_COMPLETE, 0);
	TempZones_setOperationMode(pTempZones, Operational);
	pTempZones->powerUpSequencingInProgress = FALSE;
	Oven_setJobStartupComplete(ovenDb, TRUE);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_getNumberOfChannelsInGroup
			
			returns the count of the tempzones, belts, and/or fluxheaters that are active and in the group
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
UINT TempZones_getNumberOfChannelsInGroup(TempZones* pTempZones, UINT uiGroup)
{
	UINT groupCount = 0;
	UINT fluxGroup = 0; 
	int currentZone = 0;
	TempZone* pTZone = NULL;
	PARAM_CHECK_RETURN( pTempZones, "TempZones_getNumberOfChannelsInGroup", 0);

	for ( currentZone=0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		if ( TempZone_getSequenceGroup(pTZone) == uiGroup )
		{
			if ( (TempZone_isActive(pTZone) == TRUE) && ((pTZone->pidCtrl.zoneAuto == eAUTO)|| (pTZone->pidCtrl.zoneAuto == eMANUAL)) )
			{
				groupCount++;
			}
		}
	}

	fluxGroup = FluxHeater_getSequenceGroup(flxHeat);
	if(fluxGroup && (fluxGroup == uiGroup))
	{
		if(FluxHeater_isActive(flxHeat) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat))
		{
			groupCount++;
		}
	}

	if(FluxHeater_isFluxHeaterEnabled(flxHeat1))
	{
		fluxGroup = FluxHeater_getSequenceGroup(flxHeat1);
		if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
		{
			if(FluxHeater_isActive(flxHeat1) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat1))
			{
				groupCount++;
			}
		}
	}
	if(FluxHeater_isFluxHeaterEnabled(flxHeat2))
	{
		fluxGroup = FluxHeater_getSequenceGroup(flxHeat2);
		if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
		{
			if(FluxHeater_isActive(flxHeat2) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat2))
			{
				groupCount++;
			}
		}
	}
	if(FluxHeater_isFluxHeaterEnabled(flxHeat3))
	{
		fluxGroup = FluxHeater_getSequenceGroup(flxHeat3);
		if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
		{
			if(FluxHeater_isActive(flxHeat3) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat3))
			{
				groupCount++;
			}
		}
	}
	if(FluxHeater_isFluxHeaterEnabled(flxHeat4))
	{
		fluxGroup = FluxHeater_getSequenceGroup(flxHeat4);
		if(fluxGroup && (fluxGroup == pTempZones->startUpGroup))
		{
			if(FluxHeater_isActive(flxHeat4) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(flxHeat4))
			{
				groupCount++;
			}
		}
	}
	groupCount = groupCount + Belts_returnNumberOfBeltsInStartUpSequence(&(g_dbContainer.beltsDb), uiGroup);


	return groupCount;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_setHiProcDelay
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_setHiProcDelay(TempZones* pTempZones, int iDelay)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK( pTempZones, "TempZones_setHiProcDelay");

	for ( currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		TempZone_setHiProcDelay(pTZone, iDelay * 10);//adjust to tenths of seconds
	}
}

enum OperationMode  	TempZones_getOperationMode	(TempZones* pTempZones)
{
	PARAM_CHECK_RETURN( pTempZones, "TempZones_getOperationMode", 0);
	return pTempZones->tempState; 
}

BOOL TempZones_isAllZonesInDeadBand(TempZones* pTempZones)
{
	PARAM_CHECK_RETURN( pTempZones, "TempZones_isAllZonesInDeadBand", 0);
	return pTempZones->allZonesInDeadBand; 
}

void TempZones_setNumberDrawWarningZones(TempZones* pTempZones, short sZones)
{
	PARAM_CHECK( pTempZones, "TempZones_setNumberDrawWarningZones");
	pTempZones->m_iNumberZonesForDrawwarn = sZones;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_setGlobalHighProcess
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_setGlobalHighProcess(TempZones* pTempZones, LONG lHP)
{
	PARAM_CHECK(pTempZones, "TempZones_setGlobalHighProcess");
	int currentZone;	
	TempZone* pTempZone;	
	for(currentZone = 0; currentZone < MaxTempZones; currentZone++)
	{
		pTempZone = &(pTempZones->tempZone[currentZone]);
		TempZone_setGlobalHighProcess(pTempZone, lHP);
	}
}

void TempZones_testCriticalPath(TempZones * pTempZones, int iTest)
{
	PARAM_CHECK(pTempZones, "TempZone_testCriticalPath");
	int currentZone;
	TempZone* pTempZone;
	for(currentZone = 0; currentZone < MaxTempZones; currentZone++)
	{
		pTempZone = &(pTempZones->tempZone[currentZone]);
		TempZone_testTPOPath(pTempZone, iTest);
	}
}

void TempZones_setCooldownSP(TempZones * pTempZones, DWORD sp)
{
	PARAM_CHECK(pTempZones, "TempZones_setCooldown");
	pTempZones->m_dwrdCooldownSetpoint = sp;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_setRiseRateWarning
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_setRiseRateWarning(TempZones* pTempZones, BOOL bRiseRateWarning)
{
	pTempZones->m_bRiseRateWarning = bRiseRateWarning;
}

UINT TempZones_riseRateWarning(TempZones* pTempZones)
{
	return pTempZones->m_bRiseRateWarning;
}
void TempZones_setCoolPeriod(TempZones* pTempZones, DWORD period)
{
	int currentZone;
	TempZone* pTZone;
	PARAM_CHECK( pTempZones, "TempZones_setCoolPeriod");

	for (  currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		TempZone_setCoolPeriod(pTZone, period);
	}
	FluxHeater_setCoolPeriod(flxHeat, period);
	FluxHeater_setCoolPeriod(flxHeat1, period);
	FluxHeater_setCoolPeriod(flxHeat2, period);
	FluxHeater_setCoolPeriod(flxHeat3, period);
	FluxHeater_setCoolPeriod(flxHeat4, period);

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_cooling
			
			
 GLOBALS:	flxHeat, flxHeat1, flxHeat2, flxHeat3, flxHeat4
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_cooling(TempZones* pTempZones)
{
	int currentZone = 0;
	TempZone* pTZone = NULL;
	PARAM_CHECK( pTempZones, "TempZones_cooling");

	for (  currentZone = 0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = &(pTempZones->tempZone[currentZone]);
		if(pTZone)
		{
			if(pTZone->pidCtrl.coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
			{
				PIDController_cooling(&(pTZone->pidCtrl));
			}
		}
	}
	if(flxHeat->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		FluxHeater_cooling(flxHeat);
	}
	if(flxHeat1->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		FluxHeater_cooling(flxHeat1);
	}
	if(flxHeat2->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		FluxHeater_cooling(flxHeat2);
	}
	if(flxHeat3->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		FluxHeater_cooling(flxHeat3);
	}
	if(flxHeat4->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		FluxHeater_cooling(flxHeat4);
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_coolingInCooldown
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZones_coolingInCooldown(TempZones* pTempZones, DWORD on)
{
	int currentZone = 0;
	TempZone* pTZone = NULL;
	PARAM_CHECK( pTempZones, "coolingInCooldown");
	for (  currentZone=0; currentZone < MaxTempZones; currentZone++ )
	{
		pTZone = TempZones_GetZone(pTempZones, currentZone);
		PIDController_coolingInCooldown(&(pTZone->pidCtrl), on);
	}
	FluxHeater_coolingInCooldown(flxHeat, on);
	FluxHeater_coolingInCooldown(flxHeat1, on);
	FluxHeater_coolingInCooldown(flxHeat2, on);
	FluxHeater_coolingInCooldown(flxHeat3, on);
	FluxHeater_coolingInCooldown(flxHeat4, on);

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_AllZonesSequencedBelowDraw
			
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TempZones_AllZonesSequencedBelowDraw(TempZones* pTempZones)
{
	BOOL bReturn = TRUE; 
	bReturn = TRUE;
	int currentZone;
	currentZone = 0;
	TempZone* pTZone;
	pTZone = NULL;
	FluxHeater* pFlux;
	pFlux = NULL;
	if(pTempZones->tempState != Operational)
	{
		bReturn = FALSE;
	}
	else
	{
		for (  currentZone=0; (currentZone < MaxTempZones) && (bReturn == TRUE); currentZone++ )
		{
			pTZone = &(pTempZones->tempZone[currentZone]);

			if ( (pTZone != NULL) &&(TempZone_isActive(pTZone) == TRUE) && (pTZone->pidCtrl.zoneAuto == eAUTO) )
			{
				if(TempZone_getTPOoutput(pTZone) >= pTempZones->startUpPowerPercentTPOcounts)
				{
					bReturn = FALSE;
				}
			}
		}
		if(bReturn == TRUE)
		{
			for(currentZone = 0; (currentZone < MAX_FLUXHEATERS) && (bReturn == TRUE); currentZone++ )
			{
				switch(currentZone)
				{
				case 0:
					pFlux = flxHeat;
					break;
				case 1:
					pFlux = flxHeat1;
					break;
				case 2:
					pFlux = flxHeat2;
					break;
				case 3:
					pFlux = flxHeat3;
					break;
				case 4:
					pFlux = flxHeat4;
					break;
				default:
					pFlux = NULL;
					break;
				}
			}
				
			if(pFlux != NULL && FluxHeater_isFluxHeaterEnabled(pFlux))
			{
				{
					if(FluxHeater_isActive(pFlux) == TRUE && FluxHeater_IsFluxHeaterInAutoManualMode(pFlux)==TRUE)
					{
						if(FluxHeater_getTPOoutput(pFlux) > pTempZones->startUpPowerPercentTPOcounts)
						{
							bReturn = FALSE;
						}
					}
				}
			}
		}
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_useSecondaryBoard
			
			loops through tempzones, checks for active and IO on second board
 
 RETURNS:   BOOL true if io from the second board is configured, false otherwise
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL TempZones_useSecondaryBoard(TempZones* pTempZones)
{
	PARAM_CHECK_RETURN( pTempZones, "TempZones_useSecondaryBoard", 0);
	int currentZone = 0;
	TempZone* pTempZone = NULL;
	BOOL bReturn = FALSE;
	for ( currentZone = 0; ((currentZone < MaxTempZones) && (bReturn == FALSE)); currentZone++ )
	{
		pTempZone = &(pTempZones->tempZone[currentZone]);
		if ( TempZone_isActive(pTempZone) )
		{
			if( (pTempZone->pidCtrl.m_nTcInput > MaxAnalogIn) || (pTempZone->pidCtrl.dwrdOurOutput > MaxAnalogOut) )//zone uses analogs on the second board
			{
				bReturn = TRUE;
			}
			if ( (pTempZone->pidCtrl.coolOutput != (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) && 
				(pTempZone->pidCtrl.coolOutput > MaxDout) )
			{
				bReturn = TRUE;
			}
		}
	}
	if (  (flxHeat->coolOutput != (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) &&
		(flxHeat->coolOutput > MaxDout) && flxHeat->zoneActive)
	{
		bReturn = TRUE;
	}
	if ( (flxHeat1->coolOutput != ( MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) && 
		(flxHeat1->coolOutput > MaxDout) && flxHeat1->zoneActive)
	{
		bReturn = TRUE;
	}
	if ( (flxHeat2->coolOutput != ( MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) && 
		(flxHeat2->coolOutput > MaxDout) && flxHeat2->zoneActive)
	{
		bReturn = TRUE;
	}
	if ( (flxHeat3->coolOutput != ( MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) && 
		(flxHeat3->coolOutput > MaxDout) && flxHeat3->zoneActive)
	{
		bReturn = TRUE;
	}
	if (  (flxHeat4->coolOutput != ( MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) ) && 
		(flxHeat4->coolOutput > MaxDout) && flxHeat4->zoneActive)
	{
		bReturn = TRUE;
	}
	return bReturn;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_setSGCEnable
			
				Enables/Disables the Startup Group Controlled Output Feature
 
 RETURNS:   N/A
------------------------------------------------------------------------*/
void TEMPZONES_setSGCEnable( BOOL enable )
{

	g_dbContainer.tempZonesDb.m_bStartupGrpControlledOutputEnabled = enable;
			
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_setSGCOutput
			
				Sets the Digital Output for the Startup Group Controlled 
				Output Feature
 
 RETURNS:   N/A
------------------------------------------------------------------------*/
void TEMPZONES_setSGCOutput( DWORD digitalOutput )
{
	g_dbContainer.tempZonesDb.m_nStartupGrpControlledDO = digitalOutput;

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_setSGCGroup
			
				Sets the Startup Group for the Startup Group Controlled 
				Output Feature
 
 RETURNS:   N/A
------------------------------------------------------------------------*/
void TEMPZONES_setSGCGroup( DWORD group )
{
	g_dbContainer.tempZonesDb.m_nStartupGrpControlledGroup = group;

	
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZones_setSGCOutputValue
			
				Sets the Digital Output value for the Startup Group Controlled 
				Output Feature if it is enabled and the Digital Output is 
				properly assigned.
 
 RETURNS:   N/A
------------------------------------------------------------------------*/
void TempZones_setSGCOutputValue( signed int value )
{
	BOOL bEnabled;
	DWORD dOut;
	BOOL* pOutput;
	
	pOutput = NULL;
	bEnabled = g_dbContainer.tempZonesDb.m_bStartupGrpControlledOutputEnabled;
	dOut = g_dbContainer.tempZonesDb.m_nStartupGrpControlledDO;
	
	if( bEnabled && 
		 ODO_NULL != dOut &&
		 NULL != digOutDb )
	{
		if( g_dbContainer.tempZonesDb.m_bStartupGrpControlledOutputValue !=
			value )
		{
			pOutput = DOUT_GetAt(digOutDb, dOut);
			if( NULL != pOutput )
			{
				g_dbContainer.tempZonesDb.m_bStartupGrpControlledOutputValue = value;
				*pOutput = value;
				if(value == SGC_ON_STATE)
				{
					AlarmQueue_addAlarm(alarmQDb, INFORMATION, STARTUP_CONTROL_OUTPUT, 0);
				}
			}
		}
	}
	
	return;	
}

void TempZones_enableTDMErrors(TempZones* pTempZones)
{
	PARAM_CHECK(pTempZones, "TempZones_enableTDMErrors");
	pTempZones->m_bCheckIOErrors=TRUE;
}

void TempZones_tdmTest(TempZones* pTempZones)
{
	PARAM_CHECK(pTempZones, "TempZones_tdmTest");
	int i;
	int currentZone;
	TempZone *pTZone;

	if(pTempZones->m_bIOMapTaken==FALSE)
	{
//TAKE IO MAP	
		for ( currentZone = MaxTempZones - 1; currentZone > -1; currentZone-- )
		{
			pTZone = &pTempZones->tempZone[currentZone];

			if ( TempZone_isActive(pTZone)== TRUE && pTZone->pidCtrl.bLocalZone )
			{
				pTempZones->m_bIOMapTaken = TRUE;
				if(pTZone->pidCtrl.m_nTcInput>=AI_TCPORT1 && pTZone->pidCtrl.m_nTcInput<=AI_LOWZ6)
				{
					pTempZones->m_bIOErrorActive[0]=TRUE;
				}
			
				if(pTZone->pidCtrl.m_nTcInput>=AI_TCPORT4 && pTZone->pidCtrl.m_nTcInput<=AI_FREE_L2SR)
				{
					pTempZones->m_bIOErrorActive[1]=TRUE;
				}
				for(i=0; i<2; i++)
				{
					pTempZones->m_ieePromError[i] = TDM_versionError(i);
					pTempZones->m_iCrcError[i] = TDM_crcError(i);
				}
			}
		}
		if(flxHeat1->zoneActive==TRUE)
		{
			if(flxHeat1->m_nTcInput>=AI_TCPORT4)
			{
				pTempZones->m_bIOErrorActive[1]=TRUE;
			}
			else
			{
				pTempZones->m_bIOErrorActive[0]=TRUE;
			}

		}
		if(flxHeat2->zoneActive==TRUE)
		{
			if(flxHeat2->m_nTcInput>=AI_TCPORT4)
			{
				pTempZones->m_bIOErrorActive[1]=TRUE;
			}
			else
			{
				pTempZones->m_bIOErrorActive[0]=TRUE;
			}

		}
		if(flxHeat3->zoneActive==TRUE)
		{
			if(flxHeat3->m_nTcInput>=AI_TCPORT4)
			{
				pTempZones->m_bIOErrorActive[1]=TRUE;
			}
			else
			{
				pTempZones->m_bIOErrorActive[0]=TRUE;
			}

		}
		if(flxHeat4->zoneActive==TRUE)
		{
			if(flxHeat4->m_nTcInput>=AI_TCPORT4)
			{
				pTempZones->m_bIOErrorActive[1]=TRUE;
			}
			else
			{
				pTempZones->m_bIOErrorActive[0]=TRUE;
			}
		}
	}
#ifndef BAD_FRANK
	else
	{
		for(i=0; i<2; i++)
		{
			if(pTempZones->m_ieePromError[i] && pTempZones->m_bIOErrorActive[i]==TRUE)
			{
				if(i==0)
				{
					printk("TempZones_tdmTest NO_TDM_VERSION0\n");
					AlarmQueue_addAlarm(alarmQDb, ALARM, NO_TDM_VERSION0, 0);
				}
				else
				{
					printk("TempZones_tdmTest NO_TDM_VERSION1\n");
					AlarmQueue_addAlarm(alarmQDb, ALARM, NO_TDM_VERSION1, 0);
				}
			}
			if(pTempZones->m_iCrcError[i] && pTempZones->m_bIOErrorActive[i]==TRUE)
			{

				if(i==0)
				{
					AlarmQueue_addAlarm(alarmQDb, ALARM, CHECKSUM_ERROR0, 0);
				}
				else
				{
					AlarmQueue_addAlarm(alarmQDb, ALARM, CHECKSUM_ERROR1, 0);
				}
			}
		}
	}
#endif
}
