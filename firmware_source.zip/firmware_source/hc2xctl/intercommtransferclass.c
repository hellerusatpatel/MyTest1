/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 

#include "contain.h"
#include "intercommtransferclass.h"
#include "digitio.h"
#include "rails.h"
#include "flasher.h"
#include "belt.h"

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_init
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void InterCommTransferClass_init(InterCommTransferClass* pICTC)
{
	PARAM_CHECK( pICTC, "InterCommTransferClass_init");
	pICTC->dansensorStateInfo = -6;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_InitMap
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void InterCommTransferClass_InitMap(InterCommTransferClass* pICTC)
{
	PARAM_CHECK( pICTC, "InterCommTransferClass_InitMap");
	int i = 0;

	for (i = 0; i < ICTC_MaxNumberChannels; i++)
	{
		pICTC->channelArray[i].channel=0; 
		pICTC->channelArray[i].type=0; 
		pICTC->channelArray[i].enabled=0;
	}
	pICTC->activeHeatCount=0;
	pICTC->activeBeltCount=0;
	pICTC->activeRailCount=0;
	pICTC->activeProfileCount=0;
	pICTC->totalChannelsEntered = 0;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_EnterChannel
			
	 inserts the channel id+1, type, and state into an array of ichannels
	 also sets a pointer array to four specific types of enabled channels in four seperate arrays

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void InterCommTransferClass_EnterChannel(InterCommTransferClass* pICTC, long channelid, 
										 short type, BOOL state)
{
	PARAM_CHECK( pICTC, "InterCommTransferClass_EnterChannel");

	//initialize map
	if(channelid == -1)
	{
		InterCommTransferClass_InitMap(pICTC);
	}
	if( (pICTC->totalChannelsEntered <= ICTC_MaxNumberChannels) && 
		(channelid >= 0) && (channelid < ICTC_MaxNumberChannels ) )
	{
		pICTC->channelArray[channelid].channel=channelid+1;
		pICTC->channelArray[channelid].type=type;
		pICTC->channelArray[channelid].enabled=state;

		if( (type == LOW_HEATZONE_TYPE) && (state == 1) )
		{
			pICTC->activeHeatChannels[pICTC->activeHeatCount] = &(pICTC->channelArray[channelid]);
			pICTC->activeHeatCount++;
		}
		if( (type == BELT_TYPE) && (state == 1) )
		{
			pICTC->activeBelts[pICTC->activeBeltCount] = &(pICTC->channelArray[channelid]);
			pICTC->activeBeltCount++;
		}
		if( (type == PROFILE_TYPE) && (state == 1) )
		{
			pICTC->activeProfileChannels[pICTC->activeProfileCount] = &(pICTC->channelArray[channelid]);
			pICTC->activeProfileCount++;
		}
		if( (type == RAIL_TYPE) && (state == 1) )
		{
			pICTC->activeRailSets[pICTC->activeRailCount] = &(pICTC->channelArray[channelid]);
			pICTC->activeRailCount++;
		}

		if( (type == FLUXHEATZONE_TYPE) && (state == 1) )
		{

			pICTC->activeFluxHeatChannels[pICTC->activeFluxHeaterCount] = &(pICTC->channelArray[channelid]);
			pICTC->activeFluxHeaterCount++;
		}	
	}
	if(channelid == (ICTC_MaxNumberChannels - 1) )
	{
		if(pICTC->activeFluxHeaterCount > 0)
		{
			InterCommTransferClass_appendFluxHeatersToheatzones(pICTC);
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_setDanState
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void InterCommTransferClass_setDanState(InterCommTransferClass* pICTC, int stateInfo)
{
	PARAM_CHECK( pICTC, "InterCommTransferClass_setDanState");
	pICTC->dansensorStateInfo = stateInfo;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_getDanState
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
int InterCommTransferClass_getDanState(InterCommTransferClass* pICTC)
{
	PARAM_CHECK_RETURN( pICTC, "InterCommTransferClass_getDanState", 0);
	return pICTC->dansensorStateInfo; 
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  InterCommTransferClass_appendFluxHeatersToheatzones
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void InterCommTransferClass_appendFluxHeatersToheatzones(InterCommTransferClass* pInterCommTransferClass)
{
	PARAM_CHECK(pInterCommTransferClass, "InterCommTransferClass_getName");
	int i = 0;

	while(pInterCommTransferClass->activeFluxHeaterCount>0)
	{
		pInterCommTransferClass->activeHeatChannels[pInterCommTransferClass->activeHeatCount] = pInterCommTransferClass->activeFluxHeatChannels[i];
		pInterCommTransferClass->activeHeatCount++;
		pInterCommTransferClass->activeFluxHeaterCount--;
		i++;
	};
	return; 
}

