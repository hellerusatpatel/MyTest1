/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			nitrogen.h

	Description:	nitrogen class 



    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/
#ifndef __NITROGEN_H__
#define __NITROGEN_H__

#include "typedefdefine.h"

enum NitroState { NOTACTIVE = 0, PURGE = 1, NITRO_NORMAL = 2, STANDBY = 3 };
enum FlowMode {fINIT = 0, fOFF = 1, fLOW = 2, fMED = 3, fHIGH = 4 };
enum PurgeMode	{ FULL = 1, HALF = 2 };

typedef struct _Nitrogen_
{
//public:

//private:
	enum PurgeMode			purgeMode;

	DWORD					allLanesTimer;
	DWORD 					purgeTimeDuration10ths;			// from user interface	
	DWORD					startPurgeTime10ths;
	DWORD					uiPurgeTime10ths;	
	DWORD					lowPressureStartTime10ths;	
	DWORD					elapsedTime10ths;
	DWORD					startNormalTime10ths;
	DWORD					normalTimeDuration10ths;
	BOOL 					enabled;					// option is set in set up screen.
	BOOL					autoPurgeEnabled;			// Auto purge option from setup screen.
	BOOL					inLowPressureCheckCycle;	// a low nitrogen pressure has occurred
	BOOL					inPurgeCycle;
	BOOL					previousNitrogenState;
	BOOL					nitrogenStateOnOff;
	BOOL					fullPurgeInProgress;
	enum NitroState 		currentState;
	enum NitroState 		lastState;
	enum FlowMode			nitroFlowLevel;
	enum FlowMode			dsNitroFlow;
	BOOL					oneShotNitrogenFlag;
	BOOL					nitrogenPressureLow;
	LONG					nitroCooldownRunTime;
	BOOL					runNitroInCooldown;//will run the nitrogen during cooldown for nitroCooldownRunTime
	BOOL					currentCooldownHasNitro;
	DWORD					cooldownRunStartTime;
	BOOL					bRunNitroFlushInCooldown;
	BOOL 					m_bClosedLoopDansensor;
	BOOL					m_bDeactivatePurgeOutputs;
	UINT					m_iDSFlowControl;
	UINT					iRedundantInputSensor;
	BOOL					warnEnable;
	BOOL					alarmEnable;
	DWORD					alarmTime;
	DWORD					warnTime;
	BOOL					mbStandbyNitroOff;
	BOOL					mbStandbyNitroLow;
	BOOL 					mbLowState;
	BOOL					mbWriteLowState;
} Nitrogen;

void	Nitrogen_init(Nitrogen* pNitrogen);
void 	Nitrogen_enableWarning(Nitrogen* pNitrogen, BOOL we);
void 	Nitrogen_enableAlarm(Nitrogen* pNitrogen, BOOL ae);
void 	Nitrogen_setAlarmTime(Nitrogen* pNitrogen, DWORD at);
void 	Nitrogen_setWarningTime(Nitrogen* pNitrogen, DWORD wt);

BOOL	Nitrogen_checkNitrogenToggleOn	( Nitrogen* pNitrogen );
BOOL	Nitrogen_checkForCoolDown		( Nitrogen* pNitrogen );
BOOL	Nitrogen_TestForCooldownRun (Nitrogen* pNitrogen);
void				Nitrogen_checkPressure		(Nitrogen* pNitrogen);
void				Nitrogen_doPurge			(Nitrogen* pNitrogen);
void				Nitrogen_process			(Nitrogen* pNitrogen);
BOOL				Nitrogen_setActive			(Nitrogen* pNitrogen, BOOL state );
BOOL				Nitrogen_getActive			(Nitrogen* pNitrogen);
void				Nitrogen_setNitrogenEnable	(Nitrogen* pNitrogen, BOOL state );
BOOL				Nitrogen_getNitrogenEnable	(Nitrogen* pNitrogen);			
void				Nitrogen_setPurgeTime10ths	(Nitrogen* pNitrogen, DWORD purgeTime10thsOfSeconds );
DWORD				Nitrogen_getPurgeTime10ths	(Nitrogen* pNitrogen );
void				Nitrogen_setNormalTime10ths	(Nitrogen* pNitrogen, DWORD normalTime10thsOfSeconds );
DWORD				Nitrogen_getNormalTime10ths	(Nitrogen* pNitrogen );
void				Nitrogen_setAutoPurgeEnable	(Nitrogen* pNitrogen, BOOL autoPurgeEnable /*= TRUE */);
BOOL				Nitrogen_getAutoPurgeEnable	(Nitrogen* pNitrogen );
BOOL				Nitrogen_isPurgeInProgress	(Nitrogen* pNitrogen );
BOOL				Nitrogen_checkBoardsEnteringInOven( Nitrogen* pNitrogen );
void				Nitrogen_setSolenoids		(Nitrogen* pNitrogen );
void				Nitrogen_setCoolRunTime		(Nitrogen* pNitrogen, LONG lTime);
void				Nitrogen_setRunNitroInCooldown(Nitrogen* pNitrogen, BOOL bRun);
BOOL				Nitrogen_isNitrogenPressureOK(Nitrogen* pNitrogen);
BOOL				Nitrogen_isNitroOnInCooldown(Nitrogen* pNitrogen);
void				Nitrogen_setDSState(Nitrogen* pNitrogen, BOOL blc);
void				Nitrogen_setOutputAvail(Nitrogen* pNitrogen, BOOL boff);
UINT				Nitrogen_readFlowControl(Nitrogen* pNitrogen);
void				Nitrogen_setInputForRedundant(Nitrogen* pNitrogen, UINT iRedundant);
void 				Nitrogen_setStandbyMode(Nitrogen* pNitrogen, BOOL on);

#endif

