//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: xpdriverdevice.c
//
// Description: code for interface object
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Implement OVEN_currentDelayedCooldown and OVEN_currentDelayCooldown_Handler
// 14-Nov-14  FJN  Implement OVEN_currentMonitorFailure and OVEN_currentMonitorFailure_Handler
// 03-Dec-14  FJN  Rename OVEN_currentDelayCooldown to OVEN_currentMonitorDelayCooldown
// 03-Dec-14  FJN  Implement OVEN_heaterFailureDelayCooldown and OVEN_heaterFailureDelayCooldown_Handler
// 03-Dec-14  FJN  Implement OVEN_heaterFailure and OVEN_heaterFailure_Handler
// 22-Dec-14  FJN  Implement IOCTL_GATHER_TDM_EEPROM, IOCTL_SET_TDM_EEPROM and IOCTL_PROGRAM_TDM
// 04-Jan-15  FJN  Use hc2xio IOANALOGIN rather than hc2xctl ANALOGIN
// 07-Jan-15  FJN  Split current monitor failure and heater failure functions into temp zone and flux zone implementations
// 11-Feb-15  FJN  Implement OVEN_currentMonitorCommFailure
// 15-Mar-15  FJN  Implement OVEN_currentMonitorTempZoneFailureHigh_Handler and OVEN_currentMonitorFluxZoneFailureHigh_Handler
// 23-May-15  FJN  Implement COOLPIPE_xxx
// 09-Feb-16  FJN  Implement BELTS_setDigitalStopSensor
// 04-Mar-16  FJN  Implement custom alarms 4 and 5
// 07-Apr-16  FJN  Modify DIGITALOUT_setValue to test for secondary HC-2
// 08-Apr-16  FJN  Implement SMEMA_LaneBoardSpacing
// 11-Apr-16  FJN  Implement SMEMA_LaneBoardLength
// 24-Jun-16  FJN  Implement SMEMA_setLaneHold
// 05-Oct-16  FJN  Implement NITROGEN_getNitrogenEnable and NITROGEN_getActive
// 21-Feb-17  TP   Implement OVEN_setBeltStopWhenRailMoving, ver8.0.0.18
// 14-Nov-17  FJN, TP  Implement OVEN_recipeLoadBoardEntryWait_Handler
//*****************************************************************************
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"
#include "msglog.h"
#include "fluxheater.h"
#include "utility.h"
#include <string.h>
#include <linux/poll.h>

#include "io_digitio.h"
#include "hc2xio_exports.h"
#include "newboardq.h"
#include "newboardqNoLP.h"

extern int carrierInCount;
extern int carrierOutCount;
extern int carrierInLotTotal;
extern int carrierOutLotTotal;
extern IOANALOGIN analogInDb;
extern Oven *ovenDb;
extern AlarmQueue *alarmQueueDb;
extern DbContainer g_dbContainer;

void deactivateIO(IODOUT* pDigOut, IOANALOGOUT* pAnOut);
void testIOWatchDogs(UINT iWhichOne);
DWORD IOANALOGIN_GetMem(IOANALOGIN* pIn, UINT index, UINT tdm);
void IOANALOGIN_ProgramTDM(IOANALOGIN* pIn, UINT index);
void Tdm_writeEEPromBuffer(unsigned int value, unsigned int location);

#define _BLOCK_TRACE
enum CONFIG_PARAMS  {
		INVALID_PARAM = 0,
		ENABLE_FLAG_PARAM,//defined as START_CHANNEL_PARAMS
		SETPOINT_PARAM,
		PROP_PARAM,
		INT_PARAM,
		DERIV_PARAM, //5
		DF_PARAM,
		STARTUP_GROUP_PARAM,
		MANUAL_CTRL_PARAM,
		OUTPUT_PERCENT_PARAM,
		OUTPUT_ACTION_PARAM,  //10
		ALARM_DEADBAND_PARAM,
		ALARM_HI_PROC_ENABLE_PARAM,
		ALARM_HI_PROC_OFFSET_PARAM,
		ALARM_HI_DEV_ENABLE_PARAM,
		ALARM_HI_DEV_OFFSET_PARAM,  //15
		ALARM_HI_WARN_ENABLE_PARAM,
		ALARM_HI_WARN_OFFSET_PARAM,
		ALARM_LO_WARN_ENABLE_PARAM,
		ALARM_LO_WARN_OFFSET_PARAM,
		ALARM_LO_PROC_ENABLE_PARAM,  //20
		ALARM_LO_PROC_OFFSET_PARAM,
		ALARM_LO_DEV_ENABLE_PARAM,
		ALARM_LO_DEV_OFFSET_PARAM,		

		OUTPUT_TYPE_PARAM,
		INPUT_TYPE_PARAM, //defined as STOP_CHANNEL_PARAMS 25

		USER_CHANNEL_NUMBER_PARAM,

		//NEW 2nd FluxHeater Parameters
		INPUT_OFFSET,
		SECONDARY_FLUXHEATER_ENABLE,
		SECONDARY_PV,	
		SECONDARY_OP,
};

DbContainer g_dbContainer;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  XpDriverDevice_init

			The device constructor is typically responsible for allocating
			any physical resources that are associated with the device.

 RETURNS:   void
------------------------------------------------------------------------*/
void XpDriverDevice_init(XpDriverDevice* pXpDriverDevice, ULONG Unit)
{
	if( NULL != pXpDriverDevice)
	{
		pXpDriverDevice->m_alarm_id = 0;
		pXpDriverDevice->m_bMonitorMode = FALSE;
		pXpDriverDevice->m_Unit = Unit;
		pXpDriverDevice->m_bOvenIsPaused = FALSE;
		pXpDriverDevice->m_bTimerFailWarningSent = FALSE;
		pXpDriverDevice->m_bOvenStarted = FALSE;
		pXpDriverDevice->m_bOvenControlled = 0;
		DbContainer_init(&g_dbContainer);
		Scheduler_init(&(pXpDriverDevice->m_Scheduler));
		Scheduler_setContainerAddress(&(pXpDriverDevice->m_Scheduler));
		g_dbContainer.m_jiffies = jiffies;

		newBoardQueue_initGlobalVariables();
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  XpDriverDevice_DeviceControl
			This routine is the first handler for Device Control requests.

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS XpDriverDevice_DeviceControl(XpDriverDevice* pXpDriverDevice, KIrp* I) 
{
	NTSTATUS status;
	
	status = STATUS_SUCCESS;

	g_dbContainer.m_jiffies = jiffies;

	if(I)
	{	

		switch (I->m_ioctlCode)
		{
			case OVEN_variousSettingsX:
				status = OVEN_variousSettingsX_Handler(I);
				break;

			case OVEN_variousSettingsVIII:
				status = OVEN_variousSettingsVIII_Handler(I);
				break;

			case GetBitPackedData:
				status = GetBitPackedData_Handler(I);
				break;

			case SMEMA_SecsGemControl:
				status = SMEMA_SecsGemControl_Handler(I);
				break;

			case OVEN_APCORuntimeEnable:
				status = OVEN_APCORuntimeEnable_Handler(I);
				break;

			case APCO_InvalidateScan:
				status =  APCO_InvalidateScan_Handler(I);
				break;

			case APCO_ValidScan:
				status = APCO_ValidScan_Handler(I);
				break;

			case SECSGEM_Entry_option:
				SECSGEM_Entry_option_Handler(I);
				break;

			case OVEN_variousSettingsVII:
				status = OVEN_variousSettingsVII_Handler(I);
				break;
	
			case BLOWER_GlobalHighStandbyLimit:
				status = BLOWER_GlobalHighStandbyLimit_Handler(I);
				break;		
	
			case BLOWER_GlobalLowStandbyLimit:
				status = BLOWER_GlobalLowStandbyLimit_Handler(I);
				break;	
	
			case BLOWER_GlobalHighLimit:
				status = BLOWER_GlobalHighLimit_Handler(I);
				break;		
	
			case BLOWER_GlobalLowLimit:
				status = BLOWER_GlobalLowLimit_Handler(I);
				break;		
	
			case HEATZONEBLOWER_MAXIMUM:
				status = HEATZONEBLOWER_MAXIMUM_Handler(I);
				break;
	
			case MASSCONTROLLER_CONFIG:
				status = MASSCONTROLLER_CONFIG_Handler(I);
				break;
	
			case MASS_PARAM_BEGIN:
				status = MASS_PARAM_BEGIN_Handler(I);
				break;
	
			case RAILS_masterSetpoint:
				status = RAILS_masterSetpoint_Handler(I);
				break;
	
			case LOTPROC_DEVDRVCMD:
				status = BoardEventCommand_Handler(I);
				break;
	
			case NEWLOTPROC_DEVDRVCMD:
				status = LotProcessCommand_Handler(I);
				break;
	
			case XPDRIVER_IOCTL_800:
			    status = XPDRIVER_IOCTL_800_Handler(I);
				break;
	
			case XPDRIVER_IOCTL_801:
			    status = XPDRIVER_IOCTL_801_Handler(I);
				break;
	
			case ALARMQUEUE_resetAlarms:
				status = ALARMQUEUE_resetAlarms_Handler(I);
				break;
	
			case ALARMQUEUE_getStatusEvents:
				status = ALARMQUEUE_getStatusEvents_Handler(I);
				break;
	
			case ALARMQUEUE_setCooldownPreference:
				status = ALARMQUEUE_setCooldownPreference_Handler(I);
				break;
	
			case ALARMQUEUE_setAudibleBeltWarningsEnabled:
				status = ALARMQUEUE_setAudibleBeltWarningsEnabled_Handler(I);
				break;
	
			case ALARMQUEUE_setAudibleLowExhaustEnabled:
				status = ALARMQUEUE_setAudibleLowExhaustEnabled_Handler(I);
				break;
	
			case ALARMQUEUE_setAudibleDansensorWarningEnabled:
				status = ALARMQUEUE_setAudibleDansensorWarningEnabled_Handler(I);
				break;
	
			case ALARMQUEUE_getAlarmCount:
				status = ALARMQUEUE_getAlarmCount_Handler(I);
				break;
	
			case ALARMQUEUE_alarmQueueAcknowledge:
				status = ALARMQUEUE_alarmQueueAcknowledge_Handler(I);
				break;
	
			case ALARMQUEUE_clearReadFlagAll:
				status = ALARMQUEUE_clearReadFlagAll_Handler(I);
				break;
	
			case ALARMQUEUE_alarmsPresent:
				status = ALARMQUEUE_alarmsPresent_Handler(I);
				break;
	
			case ALARMQUEUE_warningsPresent:
				status = ALARMQUEUE_warningsPresent_Handler(I);
				break;
	
			case ALARMQUEUE_resetAudibleSounding:
				status = ALARMQUEUE_resetAudibleSounding_Handler(I);
				break;
	
			case ALARMQUEUE_returnInAudibleCondition:
				status = ALARMQUEUE_returnInAudibleCondition_Handler(I);
				break;
	
			case ALARMQUEUE_getAlarmMessage:
				status = ALARMQUEUE_getAlarmMessage_Handler(I);
				break;
				
			case ALARMQUEUE_addAlarm:
				status = ALARMQUEUE_addAlarm_Handler(I);
				break;
	
			case ALARMQUEUE_audibleWarnings:
				status = ALARMQUEUE_audibleWarnings_Handler(I);
				break;
				
			case ALARMQUEUE_enableAudibleBoardWarnings:
				status = ALARMQUEUE_enableAudibleBoardWarnings_Handler(I);
				break;
	
			case ALARMQUEUE_audibleBCWarnings:
				status = ALARMQUEUE_audibleBCWarnings_Handler(I);
				break;
	
			case ALARMQUEUE_vipMode:
				status = ALARMQUEUE_vipMode_Handler(I);
				break;
	
			case ALARMQUEUE_ackType:
				status = ALARMQUEUE_ackType_Handler(I);
				break;
	
			case ALARMQUEUE_warningOutput:
				status = ALARMQUEUE_warningOutput_Handler(I);		
				break;
	
			case ANALOGFAN_setEnableState:
				status = ANALOGFAN_setEnableState_Handler(I);
				break;
	
			case ANALOGFAN_setOutputPercent:
				status = ANALOGFAN_setOutputPercent_Handler(I);
				break;
	
			case ANALOGFAN_getOutputPercent:
				status = ANALOGFAN_getOutputPercent_Handler(I);
				break;
	
			case ANALOGIN_getValue:
				status = ANALOGIN_getValue_Handler(I);
				break;
	
			case ANALOGIN_readProfileOffset:
				status = ANALOGIN_readProfileOffset_Handler(I);
				break;
				
			case ANALOGIN_GetAnalogInVal:
				status = ANALOGIN_GetAnalogInVal_Handler(I);
				break;
				
			case ANALOGIN_GetStoredOffset:
				status = ANALOGIN_GetStoredOffset_Handler(I);
				break;
				
			case ANALOGIN_SetOffsetValue:		
				status = ANALOGIN_SetOffsetValue_Handler(I);			
				break;
	
			case ANALOGIN_GetInputStyle:
				status = ANALOGIN_GetInputStyle_Handler(I);
				break;
	
			case ANALOGIN_SetInputStyle:	
				status = ANALOGIN_SetInputStyle_Handler(I);	
				break;
	
			case ANALOGOUT_getValue:
				status = ANALOGOUT_getValue_Handler(I);
				break;
	
			case ANALOGOUT_setValue:
				status = ANALOGOUT_setValue_Handler(I);
				break;
	
			case BCIO_setInput:
				status =  BCIO_setInput_Handler(I);
				break;
	
			case BCIO_setOutput:
				status =  BCIO_setOutput_Handler(I);
				break;
	
	 		case BCIO_setOutputR:
	 			status =  BCIO_setOutputR_Handler(I);
				break;
	
	 		case BCIO_setOutputY:
	 			status =  BCIO_setOutputY_Handler(I);
				break;
	
	 		case BCIO_setOutputG:
	 			status =  BCIO_setOutputG_Handler(I);
				break;
	
	 		case BCIO_boardScanned:
				status =  BCIO_boardScanned_Handler(I);
				break;
	
	 		case BCIO_setModeR:
	 			status =  BCIO_setModeR_Handler(I);
				break;
	
	 		case BCIO_setModeY:
	 			status =  BCIO_setModeY_Handler(I);
				break;
	
			case BCIO_setModeG:
				status =  BCIO_setModeG_Handler(I);
				break;
	
			case BCIO_setTime:
				status =  BCIO_setTime_Handler(I);
				break;
	
			case BCIO_setEnable:
				status =  BCIO_setEnable_Handler(I);
				break;
	
			case BCIO_setECEnable:
				status =  BCIO_setECEnable_Handler(I);
				break;
			
			case BELTS_doFastPidControl:
				status = BELTS_doFastPidControl_Handler(I);
				break;   
			
			case BELTS_enableHiDevAlarm:
				status = BELTS_enableHiDevAlarm_Handler(I);
				break;   
			
			case BELTS_enableHiDevWarn:
				status = BELTS_enableHiDevWarn_Handler(I);
				break;   
			
			case BELTS_enableHiProcAlarm:
				status = BELTS_enableHiProcAlarm_Handler(I);
				break;   
			
			case BELTS_enableLoDevAlarm:
				status = BELTS_enableLoDevAlarm_Handler(I);
				break;   
			
			case BELTS_enableLoProcAlarm:
				status = BELTS_enableLoProcAlarm_Handler(I);
				break;   
			
			case BELTS_enterSlowPidValue:
				status = BELTS_enterSlowPidValue_Handler(I);
				break;   
			
			case BELTS_get4BElapsedPositionCountTics:
				status = BELTS_get4BElapsedPositionCountTics_Handler(I);
				break;   
			
			case BELTS_getAutoMode:
				status = BELTS_getAutoMode_Handler(I);
				break;   
			
			case BELTS_getBeltActive:
				status = BELTS_getBeltActive_Handler(I);
				break;   
			
			case BELTS_getCountMethod:
				status = BELTS_getCountMethod_Handler(I);
				break;   
			
			case BELTS_getCurrentState:
				status = BELTS_getCurrentState_Handler(I);
				break;   
			
			case BELTS_getHiPercentLimit:
				status = BELTS_getHiPercentLimit_Handler(I);
				break;   
			
			case BELTS_getHiSpeedRange:
				status = BELTS_getHiSpeedRange_Handler(I);
				break;   
			
			case BELTS_getInputRangeHighValue:
				status = BELTS_getInputRangeHighValue_Handler(I);
				break;   
			
			case BELTS_getInputRangeLowValue:
				status = BELTS_getInputRangeLowValue_Handler(I);
				break;   
			
			case BELTS_getLoPercentLimit:
				status = BELTS_getLoPercentLimit_Handler(I);
				break;   
			
			case BELTS_getLowSpeedLimit:
				status = BELTS_getLowSpeedLimit_Handler(I);
				break;   
			
			case BELTS_getMaxFreq:
				status = BELTS_getMaxFreq_Handler(I);
				break;   
			
			case BELTS_getPulsesPerCmCount:
				status = BELTS_getPulsesPerCmCount_Handler(I);
				break;   
			
			case BELTS_getSetPoint:
				status = BELTS_getSetPoint_Handler(I);
				break;   
			
			case BELTS_getSpeedCounts:
				status = BELTS_getSpeedCounts_Handler(I);
				break;   
			
			case BELTS_getSpeedInCMsPerMin:
				status = BELTS_getSpeedInCMsPerMin_Handler(I);
				break;   
			
			case BELTS_getSummOfSpeeds:
				status = BELTS_getSummOfSpeeds_Handler(I);
				break;   
			
			case BELTS_IsBeltInWarning:
				status = BELTS_IsBeltInWarning_Handler(I);
				break;   
			
			case BELTS_IsOpenLoop:
				status = BELTS_IsOpenLoop_Handler(I);
				break;   
			
			case BELTS_setAutoMode:
				status = BELTS_setAutoMode_Handler(I);
				break;   
			
			case BELTS_setBeltActive:
				status = BELTS_setBeltActive_Handler(I);
				break;   
			
			case BELTS_setElapsedPositionCounts:
				status = BELTS_setElapsedPositionCounts_Handler(I);
				break;   
			
			case BELTS_setHiDeadBandOffsetCounts:
				status = BELTS_setHiDeadBandOffsetCounts_Handler(I);
				break;   
			
			case BELTS_setHiDeviationCounts:
				status = BELTS_setHiDeviationCounts_Handler(I);
				break;   
			
			case BELTS_setHiPercentLimit:
				status = BELTS_setHiPercentLimit_Handler(I);
				break;   
			
			case BELTS_setHiProcessCounts:
				status = BELTS_setHiProcessCounts_Handler(I);
				break;   
			
			case BELTS_setHiSpeedLimit:
				status = BELTS_setHiSpeedLimit_Handler(I);
				break;   
			
			case BELTS_setHiWarningCounts:
				status = BELTS_setHiWarningCounts_Handler(I);
				break;   
			
			case BELTS_setInputRangeHighValue:
				status = BELTS_setInputRangeHighValue_Handler(I);
				break;   
			
			case BELTS_setLoDeadBandOffsetCounts:
				status = BELTS_setLoDeadBandOffsetCounts_Handler(I);
				break;   
			
			case BELTS_setLoDeviationCounts:
				status = BELTS_setLoDeviationCounts_Handler(I);
				break;   
			
			case BELTS_setLoPercentLimit:
				status = BELTS_setLoPercentLimit_Handler(I);
				break;   
			
			case BELTS_setLoProcessCounts:
				status = BELTS_setLoProcessCounts_Handler(I);		
				break;   
			
			case BELTS_setLoWarningCounts:
				status = BELTS_setLoWarningCounts_Handler(I);
				break;   
			
			case BELTS_setLowSpeedLimit:
				status = BELTS_setLowSpeedLimit_Handler(I);
				break;   
			
			case BELTS_setManualTPOcounts:
				status = BELTS_setManualTPOcounts_Handler(I);
				break;   
			
			case BELTS_setMaxFreq:
				status = BELTS_setMaxFreq_Handler(I);
				break;   
			
			case BELTS_setOpenLoop:
				status = BELTS_setOpenLoop_Handler(I);
				break;   
			
			case BELTS_setPb:
				status = BELTS_setPb_Handler(I);
				break;   
			
			case BELTS_setPulsesPerCmCount:
				status = BELTS_setPulsesPerCmCount_Handler(I);
				break;   
			
			case BELTS_setSpeedInCMsPerMin:
				status = BELTS_setSpeedInCMsPerMin_Handler(I);
				break;   
			
			case BELTS_setSpeedCounts:
				status = BELTS_setSpeedCounts_Handler(I);
				break;   
			
			case BELTS_setTd:
				status = BELTS_setTd_Handler(I);
				break;   
			
			case BELTS_setTi:
				status = BELTS_setTi_Handler(I);
				break; 
		
			case BELTS_enableLoDevWarn:
				status = BELTS_enableLoDevWarn_Handler(I);
				break;
	
			case BELTS_getTPOoutputCounts:
				status = BELTS_getTPOoutputCounts_Handler(I);
				break;	
	
			case BELTS_enableSequencing:
				status = BELTS_enableSequencing_Handler(I);
				break;
	
			case BELTS_setSequenceGroup:
				status = BELTS_setSequenceGroup_Handler(I);
				break;
	
			case BELTS_activateAllBelts:
				status = BELTS_activateAllBelts_Handler(I);
				break;
	
			case BELTS_deactivateAllBelts:
				status = BELTS_deactivateAllBelts_Handler(I);
				break;
	
			case BELTS_setWarningTimeVariable:
				status = BELTS_setWarningTimeVariable_Handler(I);
				break;
			
			case BELTS_setDeadbandDeviationTime:
				status = BELTS_setDeadbandDeviationTime_Handler(I);
				break;
	
			case BELTS_getConfigParam:
				status = BELTS_getConfigParam_Handler(I);
				break;

			case BELTS_setMotors:
				status = BELTS_setMotors_Handler(I);
				break;
	
			case BELTS_setDigOutput:
				status = BELTS_setDigOutput_Handler(I);
				break;
	
			case BELTS_setOutputBehavior:
				status = BELTS_setOutputBehavior_Handler(I);
				break;
	
			case BELTS_setMultipleVariables:
				status = BELTS_setMultipleVariables_Handler(I);
				break;
	
			case BELTS_InputDeviationCounts:
				status = BELTS_InputDeviationCounts_Handler(I);
				break;
		
			case BELTS_DiffMTime:
				status = BELTS_DiffMTime_Handler(I);
				break;
	
			case BELTS_autoRange:
				status = BELTS_autoRange_Handler(I);
				break;
	
			case BELTS_autoRangeOutput:
				status = BELTS_autoRangeOutput_Handler(I);
				break;
	
			case BELTS_autoRangeSwitch:
	 			status = BELTS_autoRangeSwitch_Handler(I);
				break;
	
			case BELTS_setOpenLoopStandbyCounts:
				status = BELTS_setOpenLoopStandbyCounts_Handler(I);
				break;

			case BELTS_setDigitalStopSensor:
				status = BELTS_setDigitalStopSensor_Handler(I);
				break;
	
			case BLACKBOX_GatherData:
				status = BLACKBOX_GatherData_Handler(I);
				break;
	
			case BOARDQUEUE_getNotifyBoard:
				status = BOARDQUEUE_getNotifyBoard_Handler(I);
				break;
	
			case BOARDQUEUE_setNotifyBoard:
				status = BOARDQUEUE_setNotifyBoard_Handler(I);
				break;
	
			case BOARDQUEUE_getNotifyBoardOut:
				status = BOARDQUEUE_getNotifyBoardOut_Handler(I);
				break;
	
			case BOARDQUEUE_setNotifyBoardOut:
				status = BOARDQUEUE_setNotifyBoardOut_Handler(I);
				break;
				
			case BOARDQUEUE_getBoardAnimationData:
				status = BOARDQUEUE_getBoardAnimationData_Handler(I);
				break;
	
			case BOARDQUEUE_getBoardData:
				status = BOARDQUEUE_getBoardData_Handler(I);
				break;
	
			case BOARDQUEUE_setBoardDeadBandDistance:
				status = BOARDQUEUE_setBoardDeadBandDistance_Handler(I);
				break;
	
			case BOARDQUEUE_setSensorDistance:
				status = BOARDQUEUE_setSensorDistance_Handler(I);
				break;
	
			case BOARDQUEUE_getBoardsProcessed:
				status = BOARDQUEUE_getBoardsProcessed_Handler(I);
				break;
	
			case BOARDQUEUE_clearBoardsInOven:
				status = BOARDQUEUE_clearBoardsInOven_Handler(pXpDriverDevice, I);
				break;
	
			case BOARDQUEUE_clearBoardsProcessed:
				status = BOARDQUEUE_clearBoardsProcessed_Handler(I);
				break;
			
			case BOARDQUEUE_getBoardsInOvenCount:
				status = BOARDQUEUE_getBoardsInOvenCount_Handler(I);
				break;
	
			case BOARDQUEUE_setExitBoardDeadbandCounts:
				status = BOARDQUEUE_setExitBoardDeadbandCounts_Handler(I);
			break;
	
			case BOARDQUEUE_setBoardDropTolerance:
				status = BOARDQUEUE_setBoardDropTolerance_Handler(I);
				break;
				
			case BOARDQUEUE_setBoardDropTimeTolerance:
				status = BOARDQUEUE_setBoardDropTimeTolerance_Handler(I);
				break;
	
			case BOARDQUEUE_setBoardDropToleranceNeg:
				status = BOARDQUEUE_setBoardDropToleranceNeg_Handler(I);
				break;
	
			case BOARDQUEUE_enableSprayOption:
				status = BOARDQUEUE_enableSprayOption_Handler(I);
				break;
		
			case BOARDQUEUE_setSprayDist:
				status = BOARDQUEUE_setSprayDist_Handler(I);
				break;
	
			case BOARDQUEUE_setSprayDistTime:
				status = BOARDQUEUE_setSprayDistTime_Handler(I);
				break;
	
			case BOARDQUEUE_setSprayOutput:
				status = BOARDQUEUE_setSprayOutput_Handler(I);
				break;
	
			case BOARDQUEUE_SetFCDelayDist:
				status = BOARDQUEUE_SetFCDelayDist_Handler(I);
				break;
	
			case BOARDQUEUE_getBoardsInOvenFluxcon:
				status =BOARDQUEUE_getBoardsInOvenFluxcon_Handler(I);
				break;
	
			case BOARDQUEUE_ignoreBoardLength:
				status = BOARDQUEUE_ignoreBoardLength_Handler(I);
				break;
	
			case BOARDQUEUE_enablePredefinedBoardLength:
				status = BOARDQUEUE_enablePredefinedBoardLength_Handler(I);
				break;
	
			case BOARDQUEUE_predefinedBoardLength:
				status = BOARDQUEUE_predefinedBoardLength_Handler(I);
				break;
	
			case BOARDQUEUE_entranceJamWarning:
				status = BOARDQUEUE_entranceJamWarning_Handler(I);
				break;
	
			case BOARDQUEUE_setTime:
				status = BOARDQUEUE_setTime_Handler(I);
				break;
	
			case BOARDQUEUE_clearCarrierVariables:
				status = BOARDQUEUE_clearCarrierVariables_Handler(I);
				break;
	
	
			case BOARDQUEUE_setWarningDout:
				status = BOARDQUEUE_setWarningDout_Handler(I);
				break;
	
			case BOARDQUEUE_panalIdEnable:
				status = BOARDQUEUE_panalIdEnable_Handler(I);
				break;
	
			case BOARDQUEUE_lotProcessingEnable:
				status = BOARDQUEUE_lotProcessingEnable_Handler(I);
				break;

			case COOLPIPE_enable:
				status = COOLPIPE_enable_Handler(I);
				break;
	
			case COOLPIPE_analogInputTC1:
				status = COOLPIPE_analogInputTC1_Handler(I);
				break;
	
			case COOLPIPE_analogInputTC2:
				status = COOLPIPE_analogInputTC2_Handler(I);
				break;
	
			case COOLPIPE_tempTC1:
				status = COOLPIPE_tempTC1_Handler(I);
				break;
	
			case COOLPIPE_tempDelta:
				status = COOLPIPE_tempDelta_Handler(I);
				break;
	
			case COOLPIPE_delay:
				status = COOLPIPE_delay_Handler(I);
				break;
	
			case CBS_setFeedbackTypeFlag:
				status = CBS_setFeedbackTypeFlag_Handler(I);
				break;
	
			case CBS_setState:
				status = CBS_setState_Handler(I);
				break;
	
			case CBS_getState:
				status = CBS_getState_Handler(I);
				break;
	
			case CBS_getSecondState:
				status = CBS_getSecondState_Handler(I);
				break;
	
			case CBS_enable:
				status = CBS_enable_Handler(I);
				break;
	
			case DS_enable:
				status = DS_enable_Handler(I);
				break;
	
			case DS_Input:
				status = DS_Input_Handler(I);
				break;
			case DS_Output:	
				status = DS_Output_Handler(I);
				break;
	
			case DIGITALIN_getValue:
				status = DIGITALIN_getValue_Handler(I);
				break;	
				
			case DIGITALIN_getHistBufferIndex:
				status = DIGITALIN_getHistBufferIndex_Handler(I);
				break;
				
			case DIGITALIN_getHistBuffer:
				status = DIGITALIN_getHistBuffer_Handler(I);
				break;			
				
			case DIGITALOUT_getValue:
				status = DIGITALOUT_getValue_Handler(I);
				break;
	
			case DIGITALOUT_setValue:
				status = DIGITALOUT_setValue_Handler(I);
				break;
	
			case FLUXCONDENSOR_setElapsedTime10ths:
				status = FLUXCONDENSOR_setElapsedTime10ths_Handler(I);
				break;
	
			case FLUXCONDENSOR_recipeStarted:
				status = FLUXCONDENSOR_recipeStarted_Handler(I);
				break;
	
			case FLUXCONDENSOR_getElapsedTime10ths:
				status = FLUXCONDENSOR_getElapsedTime10ths_Handler(I);
				break;
	
			case FLUXCONDENSOR_enableOption:
				status = FLUXCONDENSOR_enableOption_Handler(I);
				break;
	
			case FLUXCONDENSOR_recipeOption:
				status = FLUXCONDENSOR_recipeOption_Handler(I);
				break;
	
			case FLUXCONDENSOR_setIntervalTime:
				status = FLUXCONDENSOR_setIntervalTime_Handler(I);
				break;
	
			case FLUXCONDENSOR_setDurationTime:
				status = FLUXCONDENSOR_setDurationTime_Handler(I);
				break;
	
			case FLUXCONDENSOR_setDelayTimer:
				status = FLUXCONDENSOR_setDelayTimer_Handler(I);
				break;
	
			case FLUXCONDENSOR_setToggle:
				status = FLUXCONDENSOR_setToggle_Handler(I);
				break;
	
			case FLUXCONDENSOR_setT3Timer:
				status = FLUXCONDENSOR_setT3Timer_Handler(I);
				break;
				
			case FLUXCONDENSOR_setCycleEndNitro:
				status = FLUXCONDENSOR_setCycleEndNitro_Handler(I);
				break;
	 			
			case FLUXCONDENSOR_setJobAtEnd:
				status = FLUXCONDENSOR_setJobAtEnd_Handler(I);
				break;
	
			case FLUXCONDENSOR_recipePreStart:
				status = FLUXCONDENSOR_recipePreStart_Handler(I);
				break;
	
			case FLUXCONDENSOR_gen9Option:
				status = FLUXCONDENSOR_gen9Option_Handler(I);
				break;
	
			case FLUXCONDENSOR_genPhase1Time:
				status = FLUXCONDENSOR_genPhase1Time_Handler(I);
				break;
					
			case FLUXCONDENSOR_genPhase2Time:
				status = FLUXCONDENSOR_genPhase2Time_Handler(I);
				break;
	
			case FLUXFILTER_setElapsedTime10ths:
				status = FLUXFILTER_setElapsedTime10ths_Handler(I);
				break;
	
			case FLUXFILTER_getElapsedTime10ths:
				status = FLUXFILTER_getElapsedTime10ths_Handler(I);
				break;
	
			case FLUXFILTER_fluxFilterEnable:
				status = FLUXFILTER_fluxFilterEnable_Handler(I);
				break;
	
			case FLUXFILTER_setFluxFilterCleaningInterval10ths:
				status = FLUXFILTER_setFluxFilterCleaningInterval10ths_Handler(I);
				break;
	
			case FLUXFILTER_setDOAvailibility:
				status = FLUXFILTER_setDOAvailibility_Handler(I);
				break;
	
			case FLUXHEATER_DeActivateZones:
				status = FLUXHEATER_DeActivateZones_Handler(I);
				break;
	
			case FLUXHEATER_initializePowerUpSequencing:
				status = FLUXHEATER_initializePowerUpSequencing_Handler(I);
				break; 
	
			case FLUXHEATER_ActivateZones:
				status = FLUXHEATER_ActivateZones_Handler(I);
				break;
	
			case FLUXHEATER_setMinRiseDegreeCounts:
				status = FLUXHEATER_setMinRiseDegreeCounts_Handler(I);
				break;
	
			case FLUXHEATER_setRiseRatePeriod:
				status = FLUXHEATER_setRiseRatePeriod_Handler(I);
				break;
	
			case FLUXHEATER_startSequencingRequiresTimer:
				status = FLUXHEATER_startSequencingRequiresTimer_Handler(I);
				break;
	
			case FLUXHEATER_checkWarningState:
				status = FLUXHEATER_checkWarningState_Handler(I);
				break;
	
			case FLUXHEATER_InDeadBandOrIsNotEnabled:
				status = FLUXHEATER_InDeadBandOrIsNotEnabled_Handler(I);
				break;
	
			case FLUXHEATER_IsZoneInWarning:
				status = FLUXHEATER_IsZoneInWarning_Handler(I);
				break;
	
			case FLUXHEATER_getTPOoutput:
				status = FLUXHEATER_getTPOoutput_Handler(I);
				break;
	
			case FLUXHEATER_getSetPoint:
				status = FLUXHEATER_getSetPoint_Handler(I);
				break;
	
			case FLUXHEATER_setActive:
				status = FLUXHEATER_setActive_Handler(I);
				break;
	
			case FLUXHEATER_setSetPoint:
				status = FLUXHEATER_setSetPoint_Handler(I);
				break;
	
			case FLUXHEATER_PIDsetPb:
				status = FLUXHEATER_PIDsetPb_Handler(I);
				break;
	
			case FLUXHEATER_PIDsetTi:
				status = FLUXHEATER_PIDsetTi_Handler(I);
				break;
	
			case FLUXHEATER_PIDsetTd:
				status = FLUXHEATER_PIDsetTd_Handler(I);
				break;
	
			case FLUXHEATER_setSequenceGroup:
				status = FLUXHEATER_setSequenceGroup_Handler(I);
				break;
	
			case FLUXHEATER_setZoneAuto:
				status = FLUXHEATER_setZoneAuto_Handler(I);
				break;
	
			case FLUXHEATER_setPIDenable:
				status = FLUXHEATER_setPIDenable_Handler(I);
				break;
	
			case FLUXHEATER_setTPOoutput:
				status = FLUXHEATER_setTPOoutput_Handler(I);
				break;
	
			case FLUXHEATER_PIDsetAction:
				status = FLUXHEATER_PIDsetAction_Handler(I);
				break;
	
			case FLUXHEATER_setDeadBandHiTempOffset:
				status = FLUXHEATER_setDeadBandHiTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_SetDeadBandLoTempOffset:
				status = FLUXHEATER_SetDeadBandLoTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_enableHiProcAlarm:
				status = FLUXHEATER_enableHiProcAlarm_Handler(I);
				break;
	
			case FLUXHEATER_enableHiDeviationAlarm:
				status = FLUXHEATER_enableHiDeviationAlarm_Handler(I);
				break;
	
			case FLUXHEATER_enableHiDeviationWarn:
				status = FLUXHEATER_enableHiDeviationWarn_Handler(I);
				break;
	
			case FLUXHEATER_enableLoDeviationWarn:
				status = FLUXHEATER_enableLoDeviationWarn_Handler(I);
				break;
	
			case FLUXHEATER_enableLoDeviationAlarm:
				status = FLUXHEATER_enableLoDeviationAlarm_Handler(I);
				break;
	
			case FLUXHEATER_enableLoProcAlarm:
				status = FLUXHEATER_enableLoProcAlarm_Handler(I);
				break;
	
			case FLUXHEATER_setHiProcTemp:
				status = FLUXHEATER_setHiProcTemp_Handler(I);
				break;
	
			case FLUXHEATER_setAlarmHiTempOffset:
				status = FLUXHEATER_setAlarmHiTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_setWarnHiTempOffset:
				status = FLUXHEATER_setWarnHiTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_setWarnLoTempOffset:
				status = FLUXHEATER_setWarnLoTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_setAlarmLoTempOffset:
				status = FLUXHEATER_setAlarmLoTempOffset_Handler(I);
				break;
	
			case FLUXHEATER_setLoProcTemp:
				status = FLUXHEATER_setLoProcTemp_Handler(I);
				break;
	
			case FLUXHEATER_PIDsetPIDMode:
				status = FLUXHEATER_PIDsetPIDMode_Handler(I);
				break;
	
			case FLUXHEATER_isInDeviationAlarmZone:
				status = FLUXHEATER_isInDeviationAlarmZone_Handler(I);
				break;
	
			case FLUXHEATER_getProcVar:
				status = FLUXHEATER_getProcVar_Handler(I);
				break;
	
			case FLUXHEATER_isFluxHeaterEnabled:
				status = FLUXHEATER_isFluxHeaterEnabled_Handler(I);
				break;
	
			case FLUXHEATER_setFluxheaterDelayTime:
				status = FLUXHEATER_setFluxheaterDelayTime_Handler(I);
				break;
	
			case FLUXHEATER_setFluxHeaterEnable:
				status = FLUXHEATER_setFluxHeaterEnable_Handler(I);
				break;
	
			case FLUXHEATER_initTcInput:
				status = FLUXHEATER_initTcInput_Handler(I);
				break;
			
			case FLUXHEATER_initTPOoutput:
				status = FLUXHEATER_initTPOoutput_Handler(I);
				break;
	
			case FLUXHEATER_getConfigParam:
				status = FLUXHEATER_getConfigParam_Handler(I);
				break;
	
			case FLUXHEATER_getInputReference:
				status = FLUXHEATER_getInputReference_Handler(I);
				break;
	
			case GLOBALBLOWER_setEnableState:
				status = GLOBALBLOWER_setEnableState_Handler(I);
				break;
	
			case GLOBALBLOWER_setOutputPercent:
				status = GLOBALBLOWER_setOutputPercent_Handler(I);
				break;
	
			case GLOBALBLOWER_getOutputPercent:
				status = GLOBALBLOWER_getOutputPercent_Handler(I);
				break;
	
			case GLOBALBLOWER_setOnTime:
				status = GLOBALBLOWER_setOnTime_Handler(I);
				break;

			case MASSANALOG_setOnTime:
				status = MASSANALOG_setOnTime_Handler(I);
				break;
	
			case HEATZONEBLOWER_setEnable:
				status = HEATZONEBLOWER_setEnable_Handler(I);
				break;
	
			case HEATZONEBLOWER_setLowSetting:
				status = HEATZONEBLOWER_setLowSetting_Handler(I);
				break;
	
			case HEATZONEBLOWER_setMediumSetting:
				status = HEATZONEBLOWER_setMediumSetting_Handler(I);
				break;
	
			case HEATZONEBLOWER_setHighSetting:
				status = HEATZONEBLOWER_setHighSetting_Handler(I);
				break;
	
			case HEATZONEBLOWER_getIfHZBlowerIsEnabled:
				status = HEATZONEBLOWER_getIfHZBlowerIsEnabled_Handler(I);
				break;
	
			case HEATZONEBLOWER_getOutputPercent:
				status = HEATZONEBLOWER_getOutputPercent_Handler(I);
				break;
	
			case HEATZONEBLOWER_getLowSetting:
				status = HEATZONEBLOWER_getLowSetting_Handler(I);
				break;
	
			case HEATZONEBLOWER_getMediumSetting:
				status = HEATZONEBLOWER_getMediumSetting_Handler(I);
				break;
	
			case HEATZONEBLOWER_getHighSetting:
				status = HEATZONEBLOWER_getHighSetting_Handler(I);
				break;
	
	
			case HEATZONEBLOWER_setOutputPercent:
				status = HEATZONEBLOWER_setOutputPercent_Handler(I);
				break;
	
			case HEATZONEBLOWER_controlMap:
				status = HEATZONEBLOWER_controlMap_Handler(I);
				break;
	
			case HEATZONEBLOWER_StandbyTime:
				status = HEATZONEBLOWER_StandbyTime_Handler(I);
				break;
	
			case HEATZONEBLOWER_IEBoardLoad:
				status = HEATZONEBLOWER_IEBoardLoad_Handler(I);
				break;
	
			case HEATZONEBLOWER_100H:
				status = HEATZONEBLOWER_100H_Handler(I);
				break;
	
			case IOCTL_START_HELLER_DRIVER:
				status = IOCTL_START_HELLER_DRIVER_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_STOP_HELLER_DRIVER:
				status = IOCTL_STOP_HELLER_DRIVER_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_getTimerLoss:
				status = IOCTL_getTimerLoss_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_GET_TICK_FREQUENCY:
				status = IOCTL_GET_TICK_FREQUENCY_HANDLER(I);
				break;
			
			case IOCTL_SetMonitorMode:
				status  = IOCTL_SetMonitorMode_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_TEST_WATCHDOG:
				status = IOCTL_TEST_WATCHDOG_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_ACTIVATE_MODBUS:
				status = IOCTL_ACTIVATE_MODBUS_Handler(pXpDriverDevice,I);
				break;			
	
			case LIGHTTOWER_Enable:
				status = LIGHTTOWER_Enable_Handler(I);
				break;   
			
			case LIGHTTOWER_getStatus:
				status = LIGHTTOWER_getStatus_Handler(I);
				break; 
	
			case LIGHTTOWER_LT2_getStatus:
				status = LIGHTTOWER_LT2_getStatus_Handler(I);
				break; 
			
			case LIGHTTOWER_setSonyGreenLightOption:
				status = LIGHTTOWER_setSonyGreenLightOption_Handler(I);
				break;   
			
			case LIGHTTOWER_Disable:
				status = LIGHTTOWER_Disable_Handler(I);
				break;  
	
			case LIGHTTOWER_setDOAvailibility:
				status = LIGHTTOWER_setDOAvailibility_Handler(I);
				break;
	
			case LIGHTTOWER_setBoardDropBehavior:
				status = LIGHTTOWER_setBoardDropBehavior_Handler(I);
				break;
		
			case LIGHTTOWER_setCLBehavior:
				status = LIGHTTOWER_setCLBehavior_Handler(I);
				break;
	
			case LIGHTTOWER_SpecialInput:
				status = LIGHTTOWER_SpecialInput_Handler(I);
				break;

			case LIGHTTOWER_TimeValue:
				status = LIGHTTOWER_TimeValue_Handler(I);
				break;
	
			case LIGHTTOWER_LT2_Enable:
				status = LIGHTTOWER_LT2_Enable_Handler(I);
				break;
	
			case LIGHTTOWER_LT2_DO_Red:
				status = LIGHTTOWER_LT2_DO_Red_Handler(I);
				break;
	
			case LIGHTTOWER_LT2_DO_Yellow:
				status = LIGHTTOWER_LT2_DO_Yellow_Handler(I);
				break;
	
			case LIGHTTOWER_LT2_DO_Green:
				status = LIGHTTOWER_LT2_DO_Green_Handler(I);
				break;
	
			case LIGHTTOWER_SPChange:
				status = LIGHTTOWER_SPChange_Handler(I);
				break;

			case LIGHTTOWER_Ready:
				status = LIGHTTOWER_Ready_Handler(I);
				break;

			case LIGHTTOWER_ReadyBoards:
				status = LIGHTTOWER_ReadyBoards_Handler(I);
				break;

			case LIGHTTOWER_Warning:
				status = LIGHTTOWER_Warning_Handler(I);
				break;

			case LIGHTTOWER_Alarm_Cooldown:
				status = LIGHTTOWER_Alarm_Cooldown_Handler(I);
				break;

			case LIGHTTOWER_EStop_Cooldown:
				status = LIGHTTOWER_EStop_Cooldown_Handler(I);
				break;
			
			case LUBE_setElapsedTime10ths:
				status = LUBE_setElapsedTime10ths_Handler(I);
				break;
				
			case LUBE_getElapsedTime10ths:
				status = LUBE_getElapsedTime10ths_Handler(I);
				break;
	
			case LUBE_optionEnable:
				status = LUBE_optionEnable_Handler(I);
				break;
				
			case LUBE_setLubeIntervalTime:
				status = LUBE_setLubeIntervalTime_Handler(I);
				break;
	
			case LUBE_setLubeDurationTime:
				status = LUBE_setLubeDurationTime_Handler(I);
				break;	
				
			case NITROGEN_setNitrogenEnable:
				status = NITROGEN_setNitrogenEnable_Handler(I);
				break;   
			
			case NITROGEN_getNitrogenEnable:
				status = NITROGEN_getNitrogenEnable_Handler(I);
				break;   
			
			case NITROGEN_setAutoPurgeEnable:
				status = NITROGEN_setAutoPurgeEnable_Handler(I);
				break;   
			
			case NITROGEN_setPurgeTime10ths:
				status = NITROGEN_setPurgeTime10ths_Handler(I);
				break;   
			
			case NITROGEN_setNormalTime10ths:
				status = NITROGEN_setNormalTime10ths_Handler(I);
				break;   
			
			case NITROGEN_setActive:
				status = NITROGEN_setActive_Handler(I);
				break;
	
			case NITROGEN_getActive:
				status = NITROGEN_getActive_Handler(I);
				break;   
			
			case NITROGEN_setCoolRunTime:
				status = NITROGEN_setCoolRunTime_Handler(I);
				break;
	
			case NITROGEN_isNitroOnInCooldown:
				status  = NITROGEN_isNitroOnInCooldown_Handler(I);
				break;
	
			case NITROGEN_dsClosedLoop:
				status  = NITROGEN_dsClosedLoop_Handler(I);
				break;
	
			case NITROGEN_makeOutputsUnavailable:
				status  = NITROGEN_makeOutputsUnavailable_Handler(I);
				break;
	
			case NITROGEN_pollPpmState:
				status  = NITROGEN_pollPpmState_Handler(I);
				break;
	
			case NITROGEN_setRedundInput:
				status  = NITROGEN_setRedundInput_Handler(I);
				break;
	
			case OVEN_Pause:
				status = OVEN_Pause_Handler(pXpDriverDevice, I);
				break;   
			
			case OVEN_setJob:
				status = OVEN_setJob_Handler(I);
				break;   
			
			case OVEN_setJobStartupComplete:
				status = OVEN_setJobStartupComplete_Handler(I);
				break;   
			
			case OVEN_resume:
				status = OVEN_resume_Handler(pXpDriverDevice, I);
				break;   
			
			case OVEN_setBelts:
				status = OVEN_setBelts_Handler(I);
				break;   
			
			case OVEN_setBoardsProcessedConfig:
				status = OVEN_setBoardsProcessedConfig_Handler(I);
				break;   
			
			case OVEN_setBoardAnimationConfig:
				status = OVEN_setBoardAnimationConfig_Handler(I);
				break;   
			
			case OVEN_setBoardsInOvenConfig:
				status = OVEN_setBoardsInOvenConfig_Handler(I);
				break;   
			
			case OVEN_setBoardDropConfig:
				status = OVEN_setBoardDropConfig_Handler(I);
				break;   
			
			case OVEN_setSMEMAConfig:
				status = OVEN_setSMEMAConfig_Handler(I);
				break;   
			
			case OVEN_setModelNo:
				status = OVEN_setModelNo_Handler(I);
				break;   
			
			case OVEN_setDirection:
				status = OVEN_setDirection_Handler(I);
				break;   
			
			case OVEN_setRedundantOverTempOption:
				status = OVEN_setRedundantOverTempOption_Handler(I);
				break;   
			
			case OVEN_setLTOption:
				status = OVEN_setLTOption_Handler(I);
				break;   
			
			case OVEN_setBlowerFailureOption:
				status = OVEN_setBlowerFailureOption_Handler(I);
				break;   
			
			case OVEN_setThirdLaneEnabled:
				status = OVEN_setThirdLaneEnabled_Handler(I);
				break;   
			
			case OVEN_setLowExhaustWarningTime:
				status = OVEN_setLowExhaustWarningTime_Handler(I);
				break;   
			
			case OVEN_setLowExhaustAlarmTime:
				status = OVEN_setLowExhaustAlarmTime_Handler(I);
				break;   

			case OVEN_setAsBoardTypeA:
#if 0 // fjn -- superseded by water temp functions
				status = OVEN_setAsBoardTypeA_Handler(I);
#endif
				break;   

			case OVEN_waterTempHighEnable:
				status = OVEN_waterTempHighEnable_Handler(I);
				break;   

			case OVEN_waterTempHighAlarmTime:
				status = OVEN_waterTempHighAlarmTime_Handler(I);
				break;   

			case OVEN_waterTempHighWarningTime:
				status = OVEN_waterTempHighWarningTime_Handler(I);
				break;

			case OVEN_SetDemoMode:
				status = OVEN_SetDemoMode_Handler(I);
				break;   
			
			case OVEN_setRecipeName:
				status = OVEN_setRecipeName_Handler(I);
				break;   
			
			case OVEN_getRecipeName:
				status = OVEN_getRecipeName_Handler(I);
				break;   
			
			case OVEN_getDirection:
				status = OVEN_getDirection_Handler(I);
				break;   
			
			case OVEN_getJob:
				status = OVEN_getJob_Handler(I);
				break;   
			
			case OVEN_ExternalCheckForPowerFailure:
				status = OVEN_ExternalCheckForPowerFailure_Handler(I);
				break;   
			
			case OVEN_getModelNo:
				status = OVEN_getModelNo_Handler(I);
				break;
	
			case OVEN_setStartWithJob:
				status = OVEN_setStartWithJob_Handler(I);
				break;
	
			case OVEN_setFourthLaneEnabled:
				status = OVEN_setFourthLaneEnabled_Handler(I);
				break;
	
			case OVEN_setExhaustWarningEnable:
				status = OVEN_setExhaustWarningEnable_Handler(I);
				break;
	
			case OVEN_setExhaustAlarmEnable:
				status = OVEN_setExhaustAlarmEnable_Handler(I);
				break;
	
			case OVEN_disableAutoAcknowledge:
				status = OVEN_disableAutoAcknowledge_Handler(I);
				break;
	
			case OVEN_setPowerFailureTime:
				status = OVEN_setPowerFailureTime_Handler(I);
				break;
	
			case OVEN_setFiveSecondDisable:
				status = OVEN_setFiveSecondDisable_Handler(I);
				break;
	
			case OVEN_getFiveSecondDisable:
				status = OVEN_getFiveSecondDisable_Handler(I);
				break;
			
			case OVEN_delayCooldown:
				status = OVEN_delayCooldown_Handler(I);
				break;
	
			case OVEN_currentMonitorDelayCooldown:
				status = OVEN_currentMonitorDelayCooldown_Handler(I);
				break;

			case OVEN_heaterFailureDelayCooldown:
				status = OVEN_heaterFailureDelayCooldown_Handler(I);
				break;

			case OVEN_currentMonitorTempZoneFailureLow:
				status = OVEN_currentMonitorTempZoneFailureLow_Handler(I);
				break;

			case OVEN_currentMonitorFluxZoneFailureLow:
				status = OVEN_currentMonitorFluxZoneFailureLow_Handler(I);
				break;

			case OVEN_currentMonitorTempZoneFailureHigh:
				status = OVEN_currentMonitorTempZoneFailureHigh_Handler(I);
				break;

			case OVEN_currentMonitorFluxZoneFailureHigh:
				status = OVEN_currentMonitorFluxZoneFailureHigh_Handler(I);
				break;

			case OVEN_currentMonitorCommFailure:
				status = OVEN_currentMonitorCommFailure_Handler(I);
				break;

			case OVEN_heaterTempZoneFailure:
				status = OVEN_heaterTempZoneFailure_Handler(I);
				break;

			case OVEN_heaterFluxZoneFailure:
				status = OVEN_heaterFluxZoneFailure_Handler(I);
				break;

			case OVEN_delayCooldownTime:
				status = OVEN_delayCooldownTime_Handler(I);
				break;
	
			case OVEN_inCooldown:
				status = OVEN_inCooldown_Handler(I);
				break;
	
			case OVEN_SetBoardStop:
				status = OVEN_setBoardStop_Handler(I);
				break;
	
			case OVEN_System_Configured:
				status = OVEN_returnOvenProgrammed_Handler(I);
				break;
	
			case OVEN_Request_Cooldown:
				status = OVEN_Request_Cooldown_Handler(I);
				break;
	
			case OVEN_FanFault_Alarm:
				status = OVEN_FanFault_Alarm_Handler(I);
				break;

			case OVEN_BFAud:
				status =  OVEN_BFAud_Handler(I);
				break;

			case OVEN_BFTimeAlarm:
				status =  OVEN_BFTimeAlarm_Handler(I);
				break;

			case OVEN_BFTimeWarn:
				status =  OVEN_BFTimeWarn_Handler(I);
				break;

			case OVEN_BFWARN:
				status =  OVEN_BFWARN_Handler(I);
				break;
	
			case OVEN_ClearCooldownNotify:
				status = OVEN_ClearCooldownNotify_Handler(I);
				break;
				
			case OVEN_AllowSmemaAgain:
				status = OVEN_AllowSmemaAgain_Handler(I);
				break;
	
			case OVEN_variousSettings:
				status = OVEN_variousSettings_Handler(I);
				break;

			case OVEN_standbyRTime:
				status = OVEN_standbyRTime_Handler(I);
				break;

			case OVEN_standbyCoolTime:
				status = OVEN_standbyCoolTime_Handler(I);
				break;

			case OVEN_standbyInput:
				status = OVEN_standbyInput_Handler(I);
				break;

			case OVEN_energyRecipe:
				status = OVEN_energyRecipe_Handler(I);
				break;

			case OVEN_variousSettingsII:
				status = OVEN_variousSettingsII_Handler(I);
				break;
	
			case OVEN_variousSettingsIII:
				status = OVEN_variousSettingsIII_Handler(I);
				break;
			
			case OVEN_AlarmScannerOption:
				status = OVEN_AlarmScannerOption_Handler(I);
				break;

			case OVEN_AlarmScannerOutput:
				status =  OVEN_AlarmScannerOutput_Handler(I);
				break;

			case OVEN_AlarmScannerState:
				status =  OVEN_AlarmScannerState_Handler(I);
				break;

			case OVEN_AlarmScannerHold:
				status = OVEN_AlarmScannerHold_Handler(I);
				break;

			case OVEN_BarcodeReset:
				status = OVEN_BarcodeReset_Handler(I);
				break;

			case OVEN_disableDevAlarmInStartup:
				status = OVEN_disableDevAlarmInStartup_Handler(I);
				break;

			case OXYGEN_setEnabled:
				status = OXYGEN_setEnabled_Handler(I);
				break;
	
			case OXYGEN_getOxygenVolts:
				status = OXYGEN_getOxygenVolts_Handler(I);
				break;
	
			case PURGE_setActive:
				status = PURGE_setActive_Handler(I);
				break;
	
			case PURGE_setPurgeTime10ths:
				status = PURGE_setPurgeTime10ths_Handler(I);
				break;
	
			case PURGE_setDigitialOutput:
				status = PURGE_setDigitialOutput_Handler(I);
				break;
	
			case PURGE_forceOn:
				status = PURGE_forceOn_Handler(I);
				break;
	
			case PURGE_setRecipeOutput:
				status = PURGE_setRecipeOutput_Handler(I);
				break;

			case PURGE_setMessageDelay:
				status = PURGE_setMessageDelay_Handler(I);
				break;
	
			case PURGE_setMessageType:
				status = PURGE_setMessageType_Handler(I);
				break;
	
			case PURGE_setInput:
				status = PURGE_setInput_Handler(I);
				break;
	
			case PURGE_setOutput:
				status =PURGE_setOutput_Handler(I); 
				break;
	
			case PURGE_setLightTowerAction:
				status = PURGE_setLightTowerAction_Handler(I);
				break;
	
			case PURGE_enableCustomAlarm:
				status = PURGE_enableCustomAlarm_Handler(I);
				break;
	
			case PURGE_setLineState:
				status = PURGE_setLineState_Handler(I);
				break;
	
			case PURGE_setAudibleWarning:
				status = PURGE_setAudibleWarning_Handler(I);
				break;
	
			case PURGE_CA3Input:
				status =  PURGE_CA3Input_Handler(I);
				break;
	
			case PURGE_CA3Output:
				status =  PURGE_CA3Output_Handler(I);
				break;
	
			case PURGE_CA3WarningTime:
				status =  PURGE_CA3WarningTime_Handler(I);
				break;
	
			case PURGE_CA3AlarmTime:
				status =  PURGE_CA3AlarmTime_Handler(I);
				break;

			case PURGE_CA4Input:
				status =  PURGE_CA4Input_Handler(I);
				break;
	
			case PURGE_CA4Output:
				status =  PURGE_CA4Output_Handler(I);
				break;
	
			case PURGE_CA4WarningTime:
				status =  PURGE_CA4WarningTime_Handler(I);
				break;
	
			case PURGE_CA4AlarmTime:
				status =  PURGE_CA4AlarmTime_Handler(I);
				break;

			case PURGE_CA5Input:
				status =  PURGE_CA5Input_Handler(I);
				break;
	
			case PURGE_CA5Output:
				status =  PURGE_CA5Output_Handler(I);
				break;
	
			case PURGE_CA5WarningTime:
				status =  PURGE_CA5WarningTime_Handler(I);
				break;
	
			case PURGE_CA5AlarmTime:
				status =  PURGE_CA5AlarmTime_Handler(I);
				break;

			case PURGE_DOBCOption:
				status = PURGE_DOBCOption_Handler(I);
				break;

			case PURGE_DOBCAction:
				status = PURGE_DOBCAction_Handler(I);
				break;

			case PURGE_DOBCOutput:
				status = PURGE_DOBCOutput_Handler(I);
				break;

			case PURGE_DOBCCount:
				status = PURGE_DOBCCount_Handler(I);		
				break;

			case RAIL_resetIncDec:
				status = RAIL_resetIncDec_Handler(I);
				break;   
			
			case RAIL_increment:
				status = RAIL_increment_Handler(I);
				break;   
			
			case RAIL_isPresetStable:
				status = RAIL_isPresetStable_Handler(I);
				break;
	
			case RAIL_setHomeDirection:
				status = RAIL_setHomeDirection_Handler(I);
				break;
	
			case RAIL_setHomeDistanceCounts:
				status = RAIL_setHomeDistanceCounts_Handler(I);
				break;

			case RAILS_getHomeDistanceCounts:
				status = RAILS_getHomeDistanceCounts_Handler(I);
				break;
	
			case RAIL_setControlType:
				status = RAIL_setControlType_Handler(I);
				break;
	
			case RAIL_decrement:
				status = RAIL_decrement_Handler(I);
				break;
	
			case RAIL_isInFinalPosition:
				status = RAIL_isInFinalPosition_Handler(I);
				break;
	
			case RAIL_setFalsePositionCounts:
				status = RAIL_setFalsePositionCounts_Handler(I);
				break;
	
			case RAIL_setOutputEnableFlag:
				status = RAIL_setOutputEnableFlag_Handler(I);
				break;
	
			case RAIL_EnterInitialCorrectionFactor:
				status = RAIL_EnterInitialCorrectionFactor_Handler(I);
				break;
	
			case RAIL_setHuntPreference:
				status = RAIL_setHuntPreference_Handler(I);
				break;
	
			case RAIL_EnterMaximumHunts:
				status = RAIL_EnterMaximumHunts_Handler(I);
				break;
	
			case RAIL_EnterNegativeTolerance:
				status = RAIL_EnterNegativeTolerance_Handler(I);
				break;
	
			case RAIL_EnterPositiveTolerance:
				status = RAIL_EnterPositiveTolerance_Handler(I);
				break;
	
			case RAIL_enterBackupDistance:
				status = RAIL_enterBackupDistance_Handler(I);
				break;
	
			case RAIL_getSetpoint:
				status = RAIL_getSetpoint_Handler(I);
				break;
			
			case RAIL_PREPROCESS:
				status = RAIL_PREPROCESS_Handler(I);
				break;
	
			case RAIL_SetLaneIndex:
				status = RAIL_SetLaneIndex_Handler(I);
				break;
	
			case RAILS_setRailStateToPresetForJobLoad:
				status = RAILS_setRailStateToPresetForJobLoad_Handler(I);
				break;
	
			case RAILS_setOpFromCoolRailMovement:
				status = RAILS_setOpFromCoolRailMovement_Handler(I);
				break;
			
			case RAILS_queueSetPosition:
				status = RAILS_queueSetPosition_Handler(I);
				break;
	
			case RAILS_setConfiguration:
				status = RAILS_setConfiguration_Handler(I);
				break;   
			
			case RAILS_IntializeEdgeholdBools:
				status = RAILS_IntializeEdgeholdBools_Handler(I);
				break;   
			
			case RAILS_getPositionCounts:
				status = RAILS_getPositionCounts_Handler(I);
				break;   
			
			case RAILS_setPosition:
				status = RAILS_setPosition_Handler(I);
				break;   
			
			case RAILS_EnableTest:
				status = RAILS_EnableTest_Handler(I);
				break;   
			
			case RAILS_DisableTest:
				status = RAILS_DisableTest_Handler(I);
				break;
	
			case RAILS_arrayInitialization:
				status = RAILS_arrayInitialization_Handler(I);
				break;
	
			case RAILS_bypassHomeAndPresetRoutines:
				status = RAILS_bypassHomeAndPresetRoutines_Handler(I);
				break;
	
			case RAILS_getValue:
				status = RAILS_getValue_Handler(I);
				break;
	
			case RAILS_setHardwareOption:
				status = RAILS_setHardwareOption_Handler(I);
				break;
				
			case RAILS_readHardwareFlag:
				status = RAILS_readHardwareFlag_Handler(I);
				break;
	
			case RAILS_sendRailsHome:
				status = RAILS_sendRailsHome_Handler(I);
				break;
	
			case RAILS_readHasHomedFlag:
				status = RAILS_readHasHomedFlag_Handler(I);
				break;
	
	
			case RAILS_setHardwareInput:
				status = RAILS_setHardwareInput_Handler(I);
				//This signals the completion of recipe download
				//from now on, this system is concidered to have a
				//valid setup.
				pXpDriverDevice->m_bOvenStarted = TRUE;
				break;
	
			case RAILS_exercisePossible:
				status = RAILS_exercisePossible_Handler(I);
				break;
	
			case RAILS_setCBS2Rail:
				status = RAILS_setCBS2Rail_Handler(I);
				break;
	
			case RAILS_executeJog:
				status = RAILS_executeJog_Handler(I);
				break;
	
			case RAILS_sequenceRails:
				status = RAILS_sequenceRails_Handler(I);
				break;
	
			case RAILS_setPulseCounts:
				status = RAILS_setPulseCounts_Handler(I);
				break;	
			
			case RAILS_monitorm_bJogOn:
				status = RAILS_monitorm_bJogOn_Handler(I);
				break;
		
			case RAILS_monitorcurrentRail:
				status = RAILS_monitorcurrentRail_Handler(I);
				break;
	
			case RAILS_monitorm_bUDPhaseMonitor:
				status = RAILS_monitorm_bUDPhaseMonitor_Handler(I);	
				break;
	
			case RAILS_monitorm_uintJogPhase:
				status = RAILS_monitorm_uintJogPhase_Handler(I);
				break;
	
			case RAILS_monitorm_uintUpdownPhase:
				status = RAILS_monitorm_uintUpdownPhase_Handler(I);
				break;

			case RAILS_HardwarePause:
				status = RAILS_HardwarePause_Handler(I);
				break;

			case RAILS_HardwareResume:
				status = RAILS_HardwareResume_Handler(I);
				break;

			case RAILS_railsInHardwareMode:
				status = RAILS_railsInHardwareMode_Handler(I);
				break;
	
			case RAILS_getCountPerCM:
				status = RAILS_getCountPerCM_Handler(I);
				break;

			case OVEN_recipeLoadBoardEntryWait:
				status = OVEN_recipeLoadBoardEntryWait_Handler(I);
				break;

			case RECIPETRIGGER_IncrementInstance:
				break;
	
			case RECIPETRIGGER_getNumberComms:
				status = RECIPETRIGGER_getNumberComms_Handler(I);
				break;
	
			case RECIPETRIGGER_DecrementInstance:
				status = RECIPETRIGGER_DecrementInstance_Handler(I);
				break;
	
			case RECIPETRIGGER_setFireRecipeNotification:
				status = RECIPETRIGGER_setFireRecipeNotification_Handler(I);
				break;
	
			case RECIPETRIGGER_getNotify:
				status = RECIPETRIGGER_getNotify_Handler(I);
				break;
	
			case RECIPETRIGGER_getControlComm:
				status = RECIPETRIGGER_getControlComm_Handler(I);
				break;
				
			case RECIPETRIGGER_setNotify:
				status = RECIPETRIGGER_setNotify_Handler(I);
				break;
	
			case RECIPETRIGGER_getFireRecipeNotification:
				status = RECIPETRIGGER_getFireRecipeNotification_Handler(I);
				break;
	
			case RECIPETRIGGER_getbSaveRecipePath:
				status = RECIPETRIGGER_getbSaveRecipePath_Handler(I);
				break;
				
			case RECIPETRIGGER_setbSaveRecipePath:
				status = RECIPETRIGGER_setbSaveRecipePath_Handler(I);
				break;
	
			case RECIPETRIGGER_getrecipeSaveTransferPath:
				status = RECIPETRIGGER_getrecipeSaveTransferPath_Handler(I);
				break;
	
			case RECIPETRIGGER_getactionControl:
				status = RECIPETRIGGER_getactionControl_Handler(I);
				break;
	
			case RECIPETRIGGER_setactionControl:
				status = RECIPETRIGGER_setactionControl_Handler(I);
				break;
	
			case RECIPETRIGGER_getrecipeTransferPath:
				status = RECIPETRIGGER_getrecipeTransferPath_Handler(I);
				break;
	
			case RECIPETRIGGER_getrecipePath:
				status = RECIPETRIGGER_getrecipePath_Handler(I);
				break;
	
			case RECIPETRIGGER_setrecipeTransferPath:
				status = RECIPETRIGGER_setrecipeTransferPath_Handler(I);
				break;
	
			case RECIPETRIGGER_ExecuteLoad:
				status = RECIPETRIGGER_ExecuteLoad_Handler(I);
				break;
	
			case RECIPETRIGGER_setrecipePath:
				status = RECIPETRIGGER_setrecipePath_Handler(I);
				break;
	
			case RECIPETRIGGER_setControlComm:
				status = RECIPETRIGGER_setControlComm_Handler(I);
				break;
	
			case RECIPETRIGGER_setrecipeSaveTransferPath:
				status = RECIPETRIGGER_setrecipeSaveTransferPath_Handler(I);
				break;
	
			case RECIPETRIGGER_setHellerExitedFlag:
				status = RECIPETRIGGER_setHellerExitedFlagHandler(I);
				break;
			
			case RECIPETRIGGER_getHellerExitedFlag:
				status = RECIPETRIGGER_getHellerExitedFlagHandler(I);
				break;
				
			case RECIPETRIGGER_getHellerUp:
				status = RECIPETRIGGER_getHellerUpHandler(I);
				break;
				
			case RECIPETRIGGER_setHellerUp:
				status =  RECIPETRIGGER_setHellerUpHandler(I);
				break;
	
			case RECIPETRIGGER_setReadControl:
				status =  RECIPETRIGGER_setReadControlHandler(I);
				break;
	
			case RECIPETRIGGER_getReadControl:
				status =  RECIPETRIGGER_getReadControlHandler(I);
				break;
	
			case SMEMA_setSMEMAdeadBandCounts:
				status = SMEMA_setSMEMAdeadBandCounts_Handler(I);
				break;
	
			case SMEMA_setSMEMAtype:
				status = SMEMA_setSMEMAtype_Handler(I);
				break;
	
			case SMEMA_HoldLot:
				status = SMEMA_HoldLot_Handler(I);
				break;
	
			case SMEMA_ClearLot:
				status = SMEMA_ClearLot_Handler(I);
				break;
	
			case SMEMA_EntrHold:
				status = SMEMA_EntrHold_Handler(I);
				break;
	
			case SMEMA_clearBarcodeTimeout:
				status = SMEMA_clearBarcodeTimeout_Handler(I);
				break;
	
			case SMEMA_HoldWarning:
				status = SMEMA_HoldWarning_Handler(I);
				break;
				
			case SMEMA_Count:
				status = SMEMA_Count_Handler(I);
				break;
	
			case SMEMA_MaxBoardsPerLaneEnable:
				status = SMEMA_MaxBoardsPerLaneEnable_Handler(I);
				break;
				
			case SMEMA_MaxBoardsPerLaneCount:
				status = SMEMA_MaxBoardsPerLaneCount_Handler(I);
				break;
				
			case SMEMA_NoBoardAnimation:
				status = SMEMA_NoBoardAnimation_Handler(I);
				break;
				
			case SMEMA_MesActive:
				status = SMEMA_MesActive_Handler(I);
				break;

			case SMEMA_MesEnabled:
				status = SMEMA_MesEnabled_Handler(I);
				break;

			case SMEMA_LaneBoardSpacing:
				status = SMEMA_LaneBoardSpacing_Handler(I);
				break;
	
			case SMEMA_LaneBoardLength:
				status = SMEMA_LaneBoardLength_Handler(I);
				break;

			case SMEMA_setLaneHold:
				status = SMEMA_setLaneHold_Handler(I);
				break;
	
			case TEMPZONE_isInDeviationAlarmZone:
				status = TEMPZONE_isInDeviationAlarmZone_Handler(I);
				break;
	
			case TEMPZONE_getProcVar:
				status = TEMPZONE_getProcVar_Handler(I);
				break; 
			
			case TEMPZONE_setActive:
				status = TEMPZONE_setActive_Handler(I);
				break; 
			
			case TEMPZONE_setSetPoint:
				status = TEMPZONE_setSetPoint_Handler(I);
				break; 
			
			case TEMPZONE_setSequenceGroup:
				status = TEMPZONE_setSequenceGroup_Handler(I);
				break; 
			
			case TEMPZONE_setZoneAuto:
				status = TEMPZONE_setZoneAuto_Handler(I);
				break; 
			
			case TEMPZONE_setPIDenable:
				status = TEMPZONE_setPIDenable_Handler(I);
				break;  
			
			case TEMPZONE_setTPOoutput:
				status = TEMPZONE_setTPOoutput_Handler(I);
				break;   
			
			case TEMPZONE_setDeadBandHiTempOffset:
				status = TEMPZONE_setDeadBandHiTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_SetDeadBandLoTempOffset:
				status = TEMPZONE_SetDeadBandLoTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_enableHiProcAlarm:
				status = TEMPZONE_enableHiProcAlarm_Handler(I);
				break;   
			
			case TEMPZONE_enableHiDeviationAlarm:
				status = TEMPZONE_enableHiDeviationAlarm_Handler(I);
				break;   
			
			case TEMPZONE_enableHiDeviationWarn:
				status = TEMPZONE_enableHiDeviationWarn_Handler(I);
				break;   
			
			case TEMPZONE_enableLoDeviationWarn:
				status = TEMPZONE_enableLoDeviationWarn_Handler(I);
				break;   
			
			case TEMPZONE_enableLoDeviationAlarm:
				status = TEMPZONE_enableLoDeviationAlarm_Handler(I);
				break;   
			
			case TEMPZONE_enableLoProcAlarm:
				status = TEMPZONE_enableLoProcAlarm_Handler(I);
				break;   
			
			case TEMPZONE_setHiProcTemp:
				status = TEMPZONE_setHiProcTemp_Handler(I);
				break;   
			
			case TEMPZONE_setAlarmHiTempOffset:
				status = TEMPZONE_setAlarmHiTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_setWarnHiTempOffset:
				status = TEMPZONE_setWarnHiTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_setWarnLoTempOffset:
				status = TEMPZONE_setWarnLoTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_setAlarmLoTempOffset:
				status = TEMPZONE_setAlarmLoTempOffset_Handler(I);
				break;   
			
			case TEMPZONE_setLoProcTemp:
				status = TEMPZONE_setLoProcTemp_Handler(I);
				break;   
			
			case TEMPZONE_getTPOoutput:
				status = TEMPZONE_getTPOoutput_Handler(I);
				break;   
			
			case TEMPZONE_getSetPoint:
				status = TEMPZONE_getSetPoint_Handler(I);
				break;   
			
			case TEMPZONE_getCurrentState:
				status = TEMPZONE_getCurrentState_Handler(I);
				break;   
			
			case TEMPZONE_isActive:
				status = TEMPZONE_isActive_Handler(I);
				break;   
			
			case TEMPZONE_IsZoneInWarning:
				status = TEMPZONE_IsZoneInWarning_Handler(I);
				break;
				
			case TEMPZONE_PIDsetPb:
				status = TEMPZONE_PIDsetPb_Handler(I);
				break;
	
			case TEMPZONE_PIDsetTi:
				status = TEMPZONE_PIDsetTi_Handler(I);
				break;
	
			case TEMPZONE_PIDsetTd:
				status = TEMPZONE_PIDsetTd_Handler(I);
				break;
	
			case TEMPZONE_PIDsetAction:
				status = TEMPZONE_PIDsetAction_Handler(I);
				break;
	
			case TEMPZONE_PIDsetPIDMode:
				status = TEMPZONE_PIDsetPIDMode_Handler(I);
				break;			
	
			case TEMPZONE_getConfigParam:
				status = TEMPZONE_getConfigParam_Handler(I);
				break;
	
			case TEMPZONE_setGlobalHighProcess:
				status = TEMPZONE_setGlobalHighProcess_Handler(I);
				break;
	
			case TEMPZONE_initTcInput:
				status = TEMPZONE_initTcInput_Handler(I);
				break;
	
			case TEMPZONE_initTPOoutput:
				status = TEMPZONE_initTPOoutput_Handler(I);
				break;
	
			case TEMPZONE_getInputReference:
				status = TEMPZONE_getInputReference_Handler(I);
				break;
	
			case TEMPZONES_enableDrawWarning:
				status = TEMPZONES_enableDrawWarning_Handler(I);
				break;	
	
			case TEMPZONES_DeActivateZones:
				status = TEMPZONES_DeActivateZones_Handler(I);
				break; 
	
			case TEMPZONES_ActivateZones:
				status = TEMPZONES_ActivateZones_Handler(I);
				break; 
						
			case TEMPZONES_setStartUpPowerPercent:
				status = TEMPZONES_setStartUpPowerPercent_Handler(I);
				break; 
	
			case TEMPZONES_setDelayStartPeriod:
				status = TEMPZONES_setDelayStartPeriod_Handler(I);
				break; 
	
			case TEMPZONES_setMinRiseDegreeCounts:
				status = TEMPZONES_setMinRiseDegreeCounts_Handler(I);
				break; 
			
			case TEMPZONES_setRiseRatePeriod:
				status = TEMPZONES_setRiseRatePeriod_Handler(I);
				break; 
			
			case TEMPZONES_initializePowerUpSequencing:
				status = TEMPZONES_initializePowerUpSequencing_Handler(I);
				break; 
	
			case TEMPZONES_setTCWarnPercentage:
				status = TEMPZONES_setTCWarnPercentage_Handler(I);
				break;
	
			case TEMPZONES_configureIO:
				status = TEMPZONES_configureIO_Handler(I);
				break;
	
			case TEMPZONES_setNumberDrawWarningZones:
				status = TEMPZONES_setNumberDrawWarningZones_Handler(I);
				break;
	
			case TEMPZONES_setHiProcessDelayTime:
				status = TEMPZONES_setHiProcessDelayTime_Handler(I);
				break;
	
			case TEMPZONES_setCooldownSP:
				status = TEMPZONES_setCooldownSP_Handler(I);
				break;
	
			case TEMPZONES_CooldownCooling:
				status = TEMPZONES_CooldownCooling_Handler(I);
				break;
	
			case TEMPZONES_CooldownSequenced:
				status = TEMPZONES_CooldownSequenced_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveRailCount:
				status = INTERCOMMTRANSFER_getActiveRailCount_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveRailSetChannel:
				status = INTERCOMMTRANSFER_getActiveRailSetChannel_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveBeltCount:
				status = INTERCOMMTRANSFER_getActiveBeltCount_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveHeatCount:
				status = INTERCOMMTRANSFER_getActiveHeatCount_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveHeatChannel:
				status = INTERCOMMTRANSFER_getActiveHeatChannel_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveBeltsChannel:
				status = INTERCOMMTRANSFER_getActiveBeltsChannel_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_EnterChannel:
				status = INTERCOMMTRANSFER_EnterChannel_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveProfileCount:
				status = INTERCOMMTRANSFER_getActiveProfileCount_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getActiveProfileChannel:
				status = INTERCOMMTRANSFER_getActiveProfileChannel_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getMaxNumberChannels:
				status = INTERCOMMTRANSFER_getMaxNumberChannels_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getChannelArrayType:
				status = INTERCOMMTRANSFER_getChannelArrayType_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getChannelArrayEnabled:
				status = INTERCOMMTRANSFER_getChannelArrayEnabled_Handler(I);
				break;	
	
			case INTERCOMMTRANSFER_setDanState:
				status = INTERCOMMTRANSFER_setDanState_Handler(I);
				break;
	
			case INTERCOMMTRANSFER_getDanState:
				status = INTERCOMMTRANSFER_getDanState_Handler(I);
				break;
	
	
			case HC2XCTL_recipeLoaded:
				status = HC2XCTL_recipeLoaded_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_CONTROL_HAULTED:
				status = IOCTL_CONTROL_HAULTED_Handler(pXpDriverDevice, I);
				break;
	
			case IOCTL_REQUEST_MONITOR_MODE:
				status = IOCTL_REQUEST_MONITOR_MODE_Handler(pXpDriverDevice, I);
				break;
		
			case IOCTL_CONTROL_STARTED:
				status = IOCTL_CONTROL_STARTED_Handler(pXpDriverDevice, I);
				break;
	
			case FLUXHEATER_shutdownBlowers:
				status = FLUXHEATER_shutdownBlowers_Handler(I);
				break;
	
			case TEMPZONE_shutdownBlowers:
				status = TEMPZONE_shutdownBlowers_Handler(I);
				break;	

			case TEMPZONE_SetCoolOutput:
				status = TEMPZONE_SetCoolOutput_Handler(I);
				break;

			case TEMPZONE_SetCoolOffset:
				status = TEMPZONE_SetCoolOffset_Handler(I);
				break;

			case TEMPZONE_SetCoolOnOff:
				status = TEMPZONE_SetCoolOnOff_Handler(I);
				break;

			case TEMPZONES_setRiseRateWarning:
				status = TEMPZONES_setRiseRateWarning_Handler(I);
				break;

			case NITROGEN_enableWarning:
				status = NITROGEN_enableWarning_Handler(I);
				break;

			case NITROGEN_enableAlarm:
				status = NITROGEN_enableAlarm_Handler(I);
				break;

			case NITROGEN_setAlarmTime:
				status = NITROGEN_setAlarmTime_Handler(I);
				break;

			case NITROGEN_setWarningTime:
				status = NITROGEN_setWarningTime_Handler(I);
				break;

			case BELTS_SmemaOffRange:
				status = BELTS_SmemaOffRange_Handler(I);
				break;

			case SMEMA_CureApp:
				status = SMEMA_CureApp_Handler(I);
				break;
	
			case TEMPZONES_setCoolCycle:
				status = TEMPZONES_setCoolCycle_Handler(I);
				break;
	
			case TEMPZONE_PIDsetPbCool:
				status = TEMPZONE_PIDsetPbCool_Handler(I);
				break;

			case TEMPZONE_PIDsetTiCool:
				status = TEMPZONE_PIDsetTiCool_Handler(I);
				break;

			case TEMPZONE_PIDsetTdCool:
				status = TEMPZONE_PIDsetTdCool_Handler(I);
				break;

			case TEMPZONE_GetCoolingPercentage:
				status = TEMPZONE_GetCoolingPercentage_Handler(I);
				break;

			case GLOBALBLOWER_0_100:
				status = GLOBALBLOWER_0_100_Handler(I);
				break;

			case GLOBALBLOWER_LOW:
				status = GLOBALBLOWER_LOW_Handler(I);
				break;

			case GLOBALBLOWER_MED:
				status = GLOBALBLOWER_MED_Handler(I);
				break;

			case GLOBALBLOWER_HIGH:
				status = GLOBALBLOWER_HIGH_Handler(I);
				break;

			case ANALOGFAN_0_100:
				status = ANALOGFAN_0_100_Handler(I);
				break;

			case ANALOGFAN_LOW:
				status = ANALOGFAN_LOW_Handler(I);
				break;

			case ANALOGFAN_MED:
				status = ANALOGFAN_MED_Handler(I);
				break;

			case ANALOGFAN_HIGH:
				status = ANALOGFAN_HIGH_Handler(I);
				break;
	
			case ANALOGFAN_MINIMUM:
				status = ANALOGFAN_MINIMUM_Handler(I);
				break;
	
			case GLOBALBLOWER_MINIMUM:
				status = GLOBALBLOWER_MINIMUM_Handler(I);
				break;

			case HEATZONEBLOWER_0_100A:
				status = HEATZONEBLOWER_0_100A_Handler(I);
				break;

			case HEATZONEBLOWER_0_100B:
				status = HEATZONEBLOWER_0_100B_Handler(I);
				break;

			case HEATZONEBLOWER_0_100C:
				status = HEATZONEBLOWER_0_100C_Handler(I);
				break;

			case HEATZONEBLOWER_MINIMUM:
				status = HEATZONEBLOWER_MINIMUM_Handler(I);
				break;
	
			case HEATZONEBLOWER_IE_LEVEL:
				status = HEATZONEBLOWER_IE_LEVEL_Handler(I);
				break;

			case FLUXHEATER_PIDsetPbCool:
				status = FLUXHEATER_PIDsetPbCool_Handler(I);
				break;

			case FLUXHEATER_PIDsetTiCool:
				status = FLUXHEATER_PIDsetTiCool_Handler(I);
				break;

			case FLUXHEATER_PIDsetTdCool:
				status = FLUXHEATER_PIDsetTdCool_Handler(I);
				break;

			case FLUXHEATER_SetCoolOutput:
				status = FLUXHEATER_SetCoolOutput_Handler(I);
				break;
	
			case FLUXHEATER_GetCoolingPercentage:
				status = FLUXHEATER_GetCoolingPercentage_Handler(I);
				break;

			case FLUXHEATER_SetCoolOffset:
				status = FLUXHEATER_SetCoolOffset_Handler(I);
				break;

			case FLUXHEATER_SetCoolOnOff:
				status = FLUXHEATER_SetCoolOnOff_Handler(I);
				break;
	
			case ENERGYSAVING_IntelExhaust_Speed:
				status = ENERGYSAVING_IntelExhaust_Speed_Handler(I);
				break;
	
			case ENERGYSAVING_StandbyMode1_ExhaustSpeed:
				status = ENERGYSAVING_StandbyMode1_ExhaustSpeed_Handler(I);
				break;
	
			case ENERGYSAVING_StandbyMode1_ZoneSpeed:
				status = ENERGYSAVING_StandbyMode1_ZoneSpeed_Handler(I);
				break;
	
			case ENERGYSAVING_StandbyMode1_ConveyorSpeed:
				status = ENERGYSAVING_StandbyMode1_ConveyorSpeed_Handler(I);
				break;
	
			case ALARMQUEUE_audible_DB:
				I->m_information = 0;
				status = STATUS_SUCCESS;
				break;
				
			case TEMPZONES_setStartupGrpControlDO:
				status = TEMPZONES_setStartupGrpControlDO_Handler(I);
				break;
				
			case TEMPZONES_setStartupGrpControlGRP:
				status = TEMPZONES_setStartupGrpControlGRP_Handler(I);
				break;

			case OVEN_setStartupCompletePlusDelay:
				status = OVEN_setStartupCompletePlusDelay_Handler(I);
				break;	

			case OVEN_setBeltStopWhenRailMoving:
				status = OVEN_setBeltStopWhenRailMoving_Handler(I);
				break;
	
		case IOCTL_GATHER_TDM_EEPROM:
			status = IOCTL_GATHER_TDM_EEPROM_Handler(I);
			break;

		case IOCTL_SET_TDM_EEPROM:
			status = IOCTL_SET_TDM_EEPROM_Handler(I);
			break;

		case IOCTL_PROGRAM_TDM:
			status = IOCTL_PROGRAM_TDM_Handler(I);
			break;

		default:
			// Unrecognized IOCTL request
			printk( "XpDriverDevice_DeviceControl: Unrecognized IOCTL request %X\n", I->m_ioctlCode );
			status = STATUS_INVALID_PARAMETER;
			break;
		}
	}
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	BoardEvent_EventRequest

				requests events

	GLOBALS:
	RETURNS:   NTSTATUS
	SEE ALSO:  
------------------------------------------------------------------------*/
NTSTATUS BoardEvent_EventRequest(BoardEventHdr* pHdr, KIrp* I)
{
	NTSTATUS retval = -1;
	BoardEventResp* pResp = NULL;
	DWORD eventCnt = 0;
	UINT resp_index = 0;
	int event_index = 0;

	pResp = (BoardEventResp*)I->m_ioctlBuffer;

	memset(pResp, 0, sizeof(BoardEventResp));

	eventCnt = g_dbContainer.m_boardEvents.m_count;

	if (eventCnt > MAX_EVENTS_PER_PACKET)
	{
		eventCnt = MAX_EVENTS_PER_PACKET;
	}

	//
	// Iterate through the event queue looking for newly entered events.
	//

	for ( resp_index = 0, event_index = 0;
		(resp_index < eventCnt) && (event_index < MAX_CARRIER_EVENT_COUNT);
		resp_index++, event_index++ )
	{
		pResp->events[resp_index] = g_dbContainer.m_boardEvents.m_array[event_index];	
	}

	pResp->numValidEvents = (CHAR)eventCnt;
	pResp->hdr.subOpCode = BOARDEVENT_EVENT_RESP;
	pResp->hdr.msgSize = sizeof(BoardEventResp);

	I->m_information = pResp->hdr.msgSize;

	retval = STATUS_SUCCESS;

	return retval;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	BoardEvent_EventClear

				clears events

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BoardEvent_EventClear(BoardEventHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	BoardEventAck* pEvtAck;
	BoardEventError* pErr;
	WORD eventIt;
	WORD eventCnt;
	WORD curSeqNum;
	BOOL error;
	BOOL bResult;
	WORD errorCode;

	retval = -1;
	pEvtAck = NULL;
	pErr = NULL;
	eventIt = 0;
	eventCnt = 0;
	curSeqNum = 0;
	error = TRUE;
	bResult = FALSE;
	errorCode = BOARDEVENT_ERR_GENERR;

	if( NULL != I && NULL != pHdr )
	{
		pEvtAck = (BoardEventAck*)I->m_ioctlBuffer;
		pErr = (BoardEventError*)I->m_ioctlBuffer;

		if( NULL != pEvtAck && NULL != pErr )
		{
			eventCnt = pEvtAck->numEvents;

			if ( eventCnt < MAX_EVENTS_PER_PACKET )
			{
				error = FALSE;

				for (eventIt = 0; !error && (eventIt < eventCnt); ++eventIt)
				{
					curSeqNum = pEvtAck->eventSeqs[eventIt];

					bResult = BoardEntryEvents_eventRemove( &(g_dbContainer.m_boardEvents), curSeqNum );
					if ( bResult == FALSE )
					{
						// respond with unknown event error
						error = TRUE;
						errorCode = BOARDEVENT_ERR_UNKNOWNEVENT;
					}
				}
			}

			if (error)
			{
				// respond with the error that was detected
				pErr->subOpCode = pHdr->subOpCode;
				pErr->errorCode = errorCode;
				pErr->hdr.subOpCode = BOARDEVENT_ERROR;
				// leave msgSize the same to mimic response
			}
			else
			{
				pHdr->msgSize = sizeof(BoardEventAck);
				pHdr->subOpCode = BOARDEVENT_EVENT_CLEAR_ACK;
				retval = STATUS_SUCCESS;
			}
		}
	}
	return retval;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardEventCommand_Handler

			Validate and execute Board events

 RETURNS:   NSTATUS (-1 on error)
------------------------------------------------------------------------*/
NTSTATUS BoardEventCommand_Handler(KIrp* I)
{
	NTSTATUS retval;
	BoardEventHdr* pHdr;
	BoardEventError* pErr;
	BOOL crcRes;
	UCHAR crcHi;
	UCHAR crcLo;
	WORD svCRC;
	WORD chkCRC;
	WORD errorSize;
	BOOL generalError;

	retval = -1;
	pHdr = NULL;
	pErr = NULL;
	crcRes = FALSE;
	crcHi = 0;
	crcLo = 0;
	svCRC = 0;
	chkCRC = 0;
	errorSize = 0;
	generalError = TRUE;

	if( NULL != I )
	{
		pHdr = (BoardEventHdr*)I->m_ioctlBuffer;
		pErr = (BoardEventError*)I->m_ioctlBuffer;

		if( NULL != pHdr && NULL != pErr )
		{
			// verify message size makes sense before trying to use it for CRC calc.
			//		if it doesn't crcRes will be FALSE and drop us to generalError
			if (pHdr->msgSize <= MAX_BOARDEVENT_MSG_SIZE)
			{
				// verify CRC
				svCRC = pHdr->crc;
				pHdr->crc = 0;
				ModbCRC_calcCRC((PUCHAR)pHdr, pHdr->msgSize, &crcHi, &crcLo);
				chkCRC = ((crcHi & 0xFF) << 8);
				chkCRC |= (crcLo & 0xFF);

				crcRes = (chkCRC == svCRC);

				pHdr->crc = svCRC;
			}


			if (crcRes && (BOARDEVENT_CHECKBYTES == pHdr->checkBytes))
			{
				// assume op code will be ok (default switch will clear it if it's not)
				generalError = FALSE;

				switch (pHdr->subOpCode)
				{
					case BOARDEVENT_EVENT_REQ:
						retval = BoardEvent_EventRequest(pHdr, I);
						break;
					case BOARDEVENT_EVENT_CLEAR:
						retval = BoardEvent_EventClear(pHdr, I);
						break;
					default:
						// unknown opCode, reply with an error
						generalError = TRUE;
						break;
				}

			}


			if (generalError)
			{
				// errors should mimic the size of the successful response if possible
				switch (pHdr->subOpCode)
				{
					case BOARDEVENT_EVENT_REQ:
						break;
					case BOARDEVENT_EVENT_CLEAR:
						errorSize = sizeof(BoardEventAck);
						break;
					default:
						// no choice but respond with mirrored size
						break;
				}
				// something was off (opCode, CRC, etc) reply with general error
				pErr->subOpCode = pHdr->subOpCode;
				pErr->errorCode = BOARDEVENT_ERR_GENERR;
				pHdr->subOpCode = BOARDEVENT_ERROR;
				pHdr->msgSize = errorSize;

			}

			// set check bytes and compute CRC 
			pHdr->checkBytes = BOARDEVENT_CHECKBYTES;
			pHdr->crc = 0;
			ModbCRC_calcCRC((PUCHAR)pHdr, pHdr->msgSize, &crcHi, &crcLo);
			pHdr->crc = ((0xFF & crcHi) << 8);
			pHdr->crc |= (0xFF & crcLo);

			// make sure the size of the response is set correctly
			I->m_information = pHdr->msgSize;
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LotProc_EventRequest

				requests events

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS LotProc_EventRequest(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcEventResp* pResp;
	DWORD eventCnt;
	UINT resp_index;
	signed int event_index;

	retval = -1;
	pResp = NULL;
	eventCnt = 0;
	resp_index = 0;
	event_index = 0;

	pResp = (LotProcEventResp*)I->m_ioctlBuffer;

	memset(pResp, 0, sizeof(LotProcEventResp));

	eventCnt = g_dbContainer.m_lotProcessing.m_events.m_count;

	if (eventCnt > MAX_EVENTS_PER_PACKET)
	{
		eventCnt = MAX_EVENTS_PER_PACKET;
	}

	//
	// Iterate through the event queue, which is a circular buffer, from head to tail 
	// (and around the bend as necessary) looking for newly entered events.
	//


	event_index = g_dbContainer.m_lotProcessing.m_events.m_headIndex;
	for ( resp_index = 0; (resp_index < eventCnt) && (resp_index < MAX_CARRIER_EVENT_COUNT); resp_index++ )
	{
		pResp->events[resp_index] = g_dbContainer.m_lotProcessing.m_events.m_array[event_index];

		event_index++;
		if ( event_index >= MAX_CARRIER_EVENT_COUNT )
		{
			event_index = 0;
		}
	}

	pResp->numValidEvents = (CHAR)eventCnt;
	pResp->hdr.subOpCode = LOTPROC_EVENT_RESP;
	pResp->hdr.msgSize = sizeof(LotProcEventResp);

	I->m_information = pResp->hdr.msgSize;

	retval = STATUS_SUCCESS;

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LotProc_EventClear

				clears events

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS LotProc_EventClear(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcEventAck* pEvtAck;
	LotProcError* pErr;
	WORD eventIt;
	WORD eventCnt;
	WORD curSeqNum;
	WORD curIndex;
	BOOL error;
	WORD errorCode;

	retval = -1;
	pEvtAck = NULL;
	pErr = NULL;
	eventIt = 0;
	eventCnt = 0;
	curSeqNum = 0;
	curIndex = 0;
	error = TRUE;
	errorCode = LOTPROC_ERR_GENERR;

	if( NULL != I && NULL != pHdr )
	{

		pEvtAck = (LotProcEventAck*)I->m_ioctlBuffer;
		pErr = (LotProcError*)I->m_ioctlBuffer;

		if( NULL != pEvtAck && NULL != pErr )
		{

			eventCnt = pEvtAck->numEvents;

			if (eventCnt <= g_dbContainer.m_lotProcessing.m_events.m_count)
			{
				error = FALSE;

				for (eventIt = 0; !error && (eventIt < eventCnt); ++eventIt)
				{
					curIndex = g_dbContainer.m_lotProcessing.m_events.m_headIndex;
					curSeqNum = g_dbContainer.m_lotProcessing.m_events.m_array[curIndex].eventSeqNum;
					if (pEvtAck->eventSeqs[eventIt] == curSeqNum)
					{
						LotProcEvent_init( &(g_dbContainer.m_lotProcessing.m_events.m_array[curIndex]) );

						++g_dbContainer.m_lotProcessing.m_events.m_headIndex;
						if (g_dbContainer.m_lotProcessing.m_events.m_headIndex >= MAX_CARRIER_EVENT_COUNT)
						{
							g_dbContainer.m_lotProcessing.m_events.m_headIndex = 0;
						}
						--g_dbContainer.m_lotProcessing.m_events.m_count;
					}
					else
					{
						// respond with unknown event error
						error = TRUE;
						errorCode = LOTPROC_ERR_UNKNOWNEVENT;
					}
				}
			}

			if (error)
			{
				// respond with the error that was detected
				pErr->subOpCode = pHdr->subOpCode;
				pErr->errorCode = errorCode;
				pErr->hdr.subOpCode = LOTPROC_ERROR;
				// leave msgSize the same to mimic response
			}
			else
			{
				pHdr->msgSize = sizeof(LotProcEventAck);
				pHdr->subOpCode = LOTPROC_EVENT_CLEAR_ACK;
				retval = STATUS_SUCCESS;
			}
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LotProc_LotDef

				Defines a new Lot in the Lot Processing

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS LotProc_LotDef(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcLotDef* pLotDef;
	LotProcError* pLotErr;
	signed int addLotRet;
	LotProcessing* pLot;

	retval = -1;
	pLotDef = NULL;
	pLotErr = NULL;
	addLotRet = -1;
	pLot = NULL;
	if( NULL != I && NULL != pHdr )
	{
		pLotDef = (LotProcLotDef*)I->m_ioctlBuffer;
		pLotErr = (LotProcError*)I->m_ioctlBuffer;
		pLot = &(g_dbContainer.m_lotProcessing);

		if( NULL != pLotDef && NULL != pLotErr &&
			NULL != pLot )
		{

			addLotRet = LotProcessing_lotAdd(pLot, pLotDef->lotId, pLotDef->carrierCount);

			// if there was an error, prepare an error response.  otherwise the message mirrored back
			//		indicates success.  error can be assumed to be too many lots defined at this point.
			if (-1 == addLotRet)
			{
				pLotErr->hdr.subOpCode = LOTPROC_ERROR;
				// msgSize must mimic successful response
				pLotErr->hdr.msgSize = sizeof(LotProcLotDef);
				pLotErr->subOpCode = LOTPROC_LOTDEF;
				pLotErr->errorCode = LOTPROC_ERR_MAXLOTS;
			}
			else
			{
				pHdr->msgSize = sizeof(LotProcLotDef);
				pHdr->subOpCode = LOTPROC_LOTDEF_ACK;
				retval = STATUS_SUCCESS;
			}
		}
	}
	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	LotProc_LotAbort

				Sends Lot Abort Signal

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS LotProc_LotAbort(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcLotAbort* pLotAbort;
	LotProcError* pLotErr;
	CHAR eventIt;
	CHAR eventCnt;
	WORD curSeqNum;
	CHAR curIndex;
	BOOL abortRes;
	LotProcessing* pLot;

	retval = -1;
	pLotAbort = NULL;
	pLotErr = NULL;
	eventIt = 0;
	eventCnt = 0;
	curSeqNum = 0;
	curIndex = 0;
	abortRes = FALSE;
	pLot = NULL;

	if( NULL != I && NULL != pHdr )
	{
		pLotAbort = (LotProcLotAbort*)I->m_ioctlBuffer;
		pLotErr = (LotProcError*)I->m_ioctlBuffer;
		pLot = &(g_dbContainer.m_lotProcessing);

		if( NULL != pLotAbort && NULL != pLotErr &&
			NULL != pLot )
		{

			abortRes = LotProcessing_lotAbort(pLot, pLotAbort->lotId);

			// if there was an error, prepare an error response.  otherwise the message mirrored back
			//		indicates success.  error can be assumed to be undefined lot at this point.
			if (!abortRes)
			{
				pLotErr->hdr.subOpCode = LOTPROC_ERROR;
				// msgSize must mimic successful response
				pLotErr->hdr.msgSize = sizeof(LotProcLotDef);
				pLotErr->subOpCode = LOTPROC_LOTDEF;
				pLotErr->errorCode = LOTPROC_ERR_UNKNOWNLOT;
			}
			else
			{
				pHdr->msgSize = sizeof(LotProcLotAbort);
				pHdr->subOpCode = LOTPROC_ABORT_ACK;
				retval = STATUS_SUCCESS;
			}
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProc_LotStatusReq

			Process a lot status request which will return the number of
			carrier in oven, processed, etc.

 RETURNS:   NSTATUS (-1 on error)
------------------------------------------------------------------------*/
NTSTATUS LotProc_LotStatusReq(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcLotStatusResp* pResp;
	LotProcError* pLotErr;
	LotProcessing* pLot;
	signed int i;

	signed int resp_index;
	UINT lot_index;

	retval = -1;
	pResp = NULL;
	pLotErr = NULL;
	pLot = NULL;
	i = 0;

	resp_index = 0;
	lot_index = 0;

	if( NULL != I && NULL != pHdr )
	{

		pResp = (LotProcLotStatusResp*)I->m_ioctlBuffer;
		pLotErr = (LotProcError*)I->m_ioctlBuffer;
		pLot = &(g_dbContainer.m_lotProcessing);

		if( NULL != pResp && NULL != pLotErr &&
			NULL != pLot )
		{
			// Fill in the lot data.  Store the data in the returned
			// array in head-to-tail order.  This way the lot information
			// at index-zero of the returned lot is the current lot in progress.

			lot_index = g_dbContainer.m_lotProcessing.m_lotHeadIndex;

			for ( resp_index = 0; (resp_index < MAX_LOT_COUNT); resp_index++ )
			{
				pResp->lots[resp_index].lotId = pLot->m_lot[lot_index].m_lotId;
				pResp->lots[resp_index].inOvenCount = pLot->m_lot[lot_index].m_nInOvenCount;
				pResp->lots[resp_index].processedCount = pLot->m_lot[lot_index].m_nProcessedCount;
				pResp->lots[resp_index].expectedCount = pLot->m_lot[lot_index].m_expectedCount;
				pResp->lots[resp_index].bAborted = pLot->m_lot[lot_index].m_bAbortEarly;
				pResp->lots[resp_index].bInUse = pLot->m_lot[lot_index].m_bInUse;

				lot_index++;
				if ( lot_index >= MAX_LOT_COUNT )
				{
					lot_index = 0; 
				}
			}

			pHdr->subOpCode = LOTPROC_STATUS_RESP;
			pHdr->msgSize = sizeof(LotProcLotStatusResp);
			retval = STATUS_SUCCESS;
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:   LotProc_SMEMA1_getStatus

			Bit packs the appropriate Lot Processing SMEMA status
			values into pResp->smemaStatus for SMEMA1.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProc_SMEMA1_getStatus( LotProcSmema* pResp )
{
	BOOL din;
	BOOL bStartSmema;
	BOOL bPendSmema;

	din = FALSE;
	bStartSmema = FALSE;
	bPendSmema = FALSE;

	if( NULL != pResp )
	{
		din = *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA1_BOARD_BACKUP );

		if( din == FALSE )
		{
			pResp->smemaStatus += SMEMA1_BOARD_BACKUP_STATUS_BIT;					
		}

		if( g_dbContainer.smema1.pastDeadBandEntrance == FALSE)
		{
			pResp->smemaStatus += SMEMA1_DBPASTENTR_STATUS_BIT;					
		}
		if (g_dbContainer.smema1.uiLotFlag != 1)
		{
			pResp->smemaStatus += SMEMA1_UILOTFLAG_STATUS_BIT;					
		}
		if(g_dbContainer.smema1.m_bSmema9851HoldDueToSensor == TRUE)
		{
			pResp->smemaStatus += SMEMA1_9851HOLD_STATUS_BIT;

			if( FALSE == g_bLotProcessingEnable )
			{
				bStartSmema = g_dbContainer.boardQ0_NoLP.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ0_NoLP.m_bPendSmema;
			}
			else
			{
				bStartSmema = g_dbContainer.boardQ0.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ0.m_bPendSmema;
			}
		
			if(bStartSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA1_BOARDQSTART_STATUS_BIT;					
			} 
			if(g_dbContainer.smema1.bBoardHasEntered == TRUE)
			{
				pResp->smemaStatus += SMEMA1_BOARDENTR_STATUS_BIT;					
			}
			if(bPendSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA1_BOARDQPEND_STATUS_BIT;					
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:   LotProc_SMEMA2_getStatus

			Bit packs the appropriate Lot Processing SMEMA status
			values into pResp->smemaStatus for SMEMA2.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProc_SMEMA2_getStatus( LotProcSmema* pResp )
{
	BOOL din;
	BOOL bStartSmema;
	BOOL bPendSmema;

	din = FALSE;
	bStartSmema = FALSE;
	bPendSmema = FALSE;

	if( NULL != pResp )
	{
		if( g_dbContainer.smema2.pastDeadBandEntrance == FALSE)
		{
			pResp->smemaStatus += SMEMA2_DBPASTENTR_STATUS_BIT;					
		}
		if (g_dbContainer.smema2.uiLotFlag != 1)
		{
			pResp->smemaStatus += SMEMA2_UILOTFLAG_STATUS_BIT;					
		}
		if(g_dbContainer.smema2.m_bSmema9851HoldDueToSensor == TRUE)
		{
			pResp->smemaStatus += SMEMA2_9851HOLD_STATUS_BIT;					
		
			if( FALSE == g_bLotProcessingEnable )
			{
				bStartSmema = g_dbContainer.boardQ1_NoLP.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ1_NoLP.m_bPendSmema;
			}
			else
			{
				bStartSmema = g_dbContainer.boardQ1.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ1.m_bPendSmema;
			}

			if(bStartSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA2_BOARDQSTART_STATUS_BIT;					
			} 
			if(g_dbContainer.smema2.bBoardHasEntered == TRUE)
			{
				pResp->smemaStatus += SMEMA2_BOARDENTR_STATUS_BIT;					
			}
			if(bPendSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA2_BOARDQPEND_STATUS_BIT;					
			}
		}

		din = *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA2_BOARD_BACKUP );

		if( din == FALSE)
		{
			pResp->smemaStatus += SMEMA2_BOARD_BACKUP_STATUS_BIT;					
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:   LotProc_SMEMA3_getStatus

			Bit packs the appropriate Lot Processing SMEMA status
			values into pResp->smemaStatus for SMEMA3.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProc_SMEMA3_getStatus( LotProcSmema* pResp )
{
	BOOL din;
	BOOL bStartSmema;
	BOOL bPendSmema;

	din = FALSE;
	bStartSmema = FALSE;
	bPendSmema = FALSE;

	if( NULL != pResp )
	{
		if( g_dbContainer.smema3.pastDeadBandEntrance == FALSE)
		{
			pResp->smemaStatus += SMEMA3_DBPASTENTR_STATUS_BIT;					
		}
		if (g_dbContainer.smema3.uiLotFlag != 1)
		{
			pResp->smemaStatus += SMEMA3_UILOTFLAG_STATUS_BIT;					
		}
		if(g_dbContainer.smema3.m_bSmema9851HoldDueToSensor == TRUE)
		{
			pResp->smemaStatus += SMEMA3_9851HOLD_STATUS_BIT;					
		
			if( FALSE == g_bLotProcessingEnable )
			{
				bStartSmema = g_dbContainer.boardQ2_NoLP.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ2_NoLP.m_bPendSmema;
			}
			else
			{
				bStartSmema = g_dbContainer.boardQ2.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ2.m_bPendSmema;
			}

			if(bStartSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA3_BOARDQSTART_STATUS_BIT;					
			} 
			if(g_dbContainer.smema3.bBoardHasEntered == TRUE)
			{
				pResp->smemaStatus += SMEMA3_BOARDENTR_STATUS_BIT;					
			}
			if(bPendSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA3_BOARDQPEND_STATUS_BIT;					
			}
		}

		din  = *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA3_BOARD_BACKUP );

		if( din == FALSE)
		{
			pResp->smemaStatus += SMEMA3_BOARD_BACKUP_STATUS_BIT;					
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:   LotProc_SMEMA4_getStatus

			Bit packs the appropriate Lot Processing SMEMA status
			values into pResp->smemaStatus for SMEMA4.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProc_SMEMA4_getStatus( LotProcSmema* pResp )
{
	BOOL din;
	BOOL bStartSmema;
	BOOL bPendSmema;

	din = FALSE;
	bStartSmema = FALSE;
	bPendSmema = FALSE;

	if( NULL != pResp )
	{
		if( g_dbContainer.smema4.pastDeadBandEntrance == FALSE)
		{
			pResp->smemaStatus += SMEMA4_DBPASTENTR_STATUS_BIT;					
		}
		if (g_dbContainer.smema4.uiLotFlag != 1)
		{
			pResp->smemaStatus += SMEMA4_UILOTFLAG_STATUS_BIT;					
		}
		if(g_dbContainer.smema4.m_bSmema9851HoldDueToSensor == TRUE)
		{
			pResp->smemaStatus += SMEMA4_9851HOLD_STATUS_BIT;					
		
			if( FALSE == g_bLotProcessingEnable )
			{
				bStartSmema = g_dbContainer.boardQ3_NoLP.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ3_NoLP.m_bPendSmema;
			}
			else
			{
				bStartSmema = g_dbContainer.boardQ3.m_bStartSmema;
				bPendSmema = g_dbContainer.boardQ3.m_bPendSmema;
			}

			if(bStartSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA4_BOARDQSTART_STATUS_BIT;					
			} 
			if(g_dbContainer.smema4.bBoardHasEntered == TRUE)
			{
				pResp->smemaStatus += SMEMA4_BOARDENTR_STATUS_BIT;					
			}
			if(bPendSmema == TRUE)
			{
				pResp->smemaStatus += SMEMA4_BOARDQPEND_STATUS_BIT;					
			}
		}

		din = *DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA4_BOARD_BACKUP );

		if( din == FALSE)
		{
			pResp->smemaStatus += SMEMA4_BOARD_BACKUP_STATUS_BIT;					
		}
	}

	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:   LotProc_SMEMAReq(LotProcHdr* pHdr, KIrp* I)

			Process a lot smema request which toggles the smema state.
			will return a bitmask of smema factors cooldown, light tower,
			upstream

 RETURNS:   NSTATUS (-1 on error)
------------------------------------------------------------------------*/
NTSTATUS LotProc_SMEMAReq(LotProcHdr* pHdr, KIrp* I)
{
	NTSTATUS retval;
	LotProcSmema* pResp;
	LotProcError* pLotErr;
	signed int i;

	signed int resp_index;
	UINT lot_index;
	UINT lightTwr1Status;
	UINT lightTwr2Status;

	retval = -1;
	pResp = NULL;
	pLotErr = NULL;
	i = 0;
	resp_index = 0;
	lot_index = 0;
	lightTwr1Status = 0;
	lightTwr2Status = 0;

	if( NULL != I && NULL != pHdr )
	{
		pResp = (LotProcSmema*)I->m_ioctlBuffer;
		pLotErr = (LotProcError*)I->m_ioctlBuffer;

		if( NULL != pResp && NULL != pLotErr )
		{

			//set the smema flag
			if(pResp->uilotflagstatus)
			{
				SMEMA_LotEnable(&(g_dbContainer.smema1));
				SMEMA_LotEnable(&(g_dbContainer.smema2));
				SMEMA_LotEnable(&(g_dbContainer.smema3));
				SMEMA_LotEnable(&(g_dbContainer.smema4));
			}
			else
			{
				SMEMA_LotDisable(&(g_dbContainer.smema1));
				SMEMA_LotDisable(&(g_dbContainer.smema2));
				SMEMA_LotDisable(&(g_dbContainer.smema3));
				SMEMA_LotDisable(&(g_dbContainer.smema4));
			}

			if(g_dbContainer.smema1.uiLotFlag && g_dbContainer.smema2.uiLotFlag)
			{
				pResp->uilotflagstatus = TRUE;		// status of the lot boolean for smema processing
			}
			else
			{
				pResp->uilotflagstatus = FALSE;		// status of the lot boolean for smema processing
			}
			pResp->smemaStatus = 0;			//bit pack of current smema variables		

			lightTwr1Status = LightTower_getLT1Status(&(g_dbContainer.lightTower));
			if(	lightTwr1Status != GREEN)
			{
				pResp->smemaStatus = SMEMA_LIGHTTOWER_STATUS_BIT;					
			}

			lightTwr2Status = LightTower_getLT2Status(&(g_dbContainer.lightTower));
			/* NOTE: If Light Tower 2 is disable getLT2Status will return GREEN
			*/
			if(	lightTwr2Status != GREEN)
			{
				pResp->smemaStatus = SMEMA_LIGHTTOWER2_STATUS_BIT;					
			}

			if(LightTower_getHoldSmema(&(g_dbContainer.lightTower)))
			{
				pResp->smemaStatus += SMEMA_HOLD_STATUS_BIT;					
			}

			LotProc_SMEMA1_getStatus( pResp );
			LotProc_SMEMA2_getStatus( pResp );
			LotProc_SMEMA3_getStatus( pResp );
			LotProc_SMEMA4_getStatus( pResp );


			pHdr->subOpCode = LOTPROC_SMEMA_RESP;
			pHdr->msgSize = sizeof(LotProcSmema);
			retval = STATUS_SUCCESS;
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessCommand_Handler



 RETURNS:   NSTATUS (-1 on error)
------------------------------------------------------------------------*/
NTSTATUS LotProcessCommand_Handler(KIrp* I)
{
	NTSTATUS retval;
	LotProcHdr* pHdr;
	LotProcError* pErr;
	BOOL crcRes;
	UCHAR crcHi;
	UCHAR crcLo;
	WORD svCRC;
	WORD chkCRC;
	WORD errorSize;
	BOOL generalError;

	retval = -1;
	pHdr = NULL;
	pErr = NULL;
	crcRes = FALSE;
	crcHi = 0;
	crcLo = 0;
	svCRC = 0;
	chkCRC = 0;
	errorSize = 0;
	generalError = TRUE;
	
	if( NULL != I )
	{
		pHdr = (LotProcHdr*)I->m_ioctlBuffer;
		pErr = (LotProcError*)I->m_ioctlBuffer;

		if( NULL != pHdr && NULL != pErr )
		{

			// verify message size makes sense before trying to use it for CRC calc.
			//		if it doesn't crcRes will be FALSE and drop us to generalError
			if (pHdr->msgSize <= MAX_LOTPROC_MSG_SIZE)
			{
				// verify CRC
				svCRC = pHdr->crc;
				pHdr->crc = 0;
				ModbCRC_calcCRC((PUCHAR)pHdr, pHdr->msgSize, &crcHi, &crcLo);
				chkCRC = ((crcHi & 0xFF) << 8);
				chkCRC |= (crcLo & 0xFF);

				crcRes = (chkCRC == svCRC);

				pHdr->crc = svCRC;
			}


			if (crcRes && (LOTPROC_CHECKBYTES == pHdr->checkBytes))
			{
				// assume op code will be ok (default switch will clear it if it's not)
				generalError = FALSE;

				switch (pHdr->subOpCode)
				{
					case LOTPROC_EVENT_REQ:
						retval = LotProc_EventRequest(pHdr, I);
						break;
					case LOTPROC_EVENT_CLEAR:
						retval = LotProc_EventClear(pHdr, I);
						break;
					case LOTPROC_LOTDEF:
						retval = LotProc_LotDef(pHdr, I);
						break;
					case LOTPROC_ABORT:
						retval = LotProc_LotAbort(pHdr, I);
						break;
					case LOTPROC_STATUS_REQ:
						retval = LotProc_LotStatusReq(pHdr, I);
						break;
					case LOTPROC_SMEMA_REQ:
						retval = LotProc_SMEMAReq(pHdr, I);
						break;

					default:
						// unknown opCode, reply with an error
						generalError = TRUE;
						break;
				}

			}


			if (generalError)
			{
				// errors should mimic the size of the successful response if possible
				switch (pHdr->subOpCode)
				{
					case LOTPROC_EVENT_REQ:
						break;
					case LOTPROC_EVENT_CLEAR:
						errorSize = sizeof(LotProcEventAck);
						break;
					case LOTPROC_LOTDEF:
						errorSize = sizeof(LotProcLotDef);
						break;
					case LOTPROC_ABORT:
						errorSize = sizeof(LotProcLotAbort);
						break;
					default:
						// no choice but respond with mirrored size
						break;
				}
				// something was off (opCode, CRC, etc) reply with general error
				pErr->subOpCode = pHdr->subOpCode;
				pErr->errorCode = LOTPROC_ERR_GENERR;
				pHdr->subOpCode = LOTPROC_ERROR;
				pHdr->msgSize = errorSize;

			}

			// set check bytes and compute CRC 
			pHdr->checkBytes = LOTPROC_CHECKBYTES;
			pHdr->crc = 0;
			ModbCRC_calcCRC((PUCHAR)pHdr, pHdr->msgSize, &crcHi, &crcLo);
			pHdr->crc = ((0xFF & crcHi) << 8);
			pHdr->crc |= (0xFF & crcLo);

			// make sure the size of the response is set correctly
			I->m_information = pHdr->msgSize;
		}
	}

	return retval;
}

////////////////////////////////////////////////////////////////////////
//  XPDRIVER_IOCTL_800_Handler
//
//	Routine Description:
//		Handler for IO Control Code XPDRIVER_IOCTL_800
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//		This routine implements the XPDRIVER_IOCTL_800 function.
//		This routine runs at passive level.
//
NTSTATUS XPDRIVER_IOCTL_800_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	const char*  FIRMWARE_REV = "FW 16.33 v5";
	ULONG fwLength=0;
    fwLength = strlen(FIRMWARE_REV)+1;
	I->m_information = 0;
    if (I->m_outputBufferSize >= fwLength)
    {
		strcpy((PCHAR)I->m_ioctlBuffer,FIRMWARE_REV);
        I->m_information = fwLength;
		status= STATUS_SUCCESS;
    }
    else
    {
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
    }

	return status;
}

////////////////////////////////////////////////////////////////////////
//  XPDRIVER_IOCTL_801_Handler
//
//	Routine Description:
//		Handler for IO Control Code XPDRIVER_IOCTL_801
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//		This routine implements the XPDRIVER_IOCTL_801 function.
//		This routine runs at passive level.
//

NTSTATUS XPDRIVER_IOCTL_801_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

//	t << "Entering XPDRIVER_IOCTL_801_Handler, " << I << EOL;
// TODO:	Verify that the input parameters are correct
//			If not, return STATUS_INVALID_PARAMETER

// TODO:	Handle the the XPDRIVER_IOCTL_801 request, or 
//			defer the processing of the IRP (i.e. by queuing) and set
//			status to STATUS_PENDING.

// TODO:	Assuming that the request was handled here. Set I.Information
//			to indicate how much data to copy back to the user.
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_isPresetStable_Handler
//
//	Routine Description:
//		Returns isPresetStable for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//
//		Output Buffer:
//			BOOL - state
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_isPresetStable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RAIL_isPresetStable_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		BOOL retVal = Rail_isPresetStable(pRail);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
		t << "rails[" << (LONG)index << "].isPresetStable()" << EOL <<
				"Returning " << (retVal ? "TRUE" : "FALSE") << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_increment_Handler
//
//	Routine Description:
//		Sets increment for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_increment_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RAIL_increment_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rails_increment(&(g_dbContainer.railsDb), index);
#ifndef _BLOCK_TRACE
		t << "railsDb.increment(" << (LONG)index << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_getProcVar_Handler
			Gets the pv value of a tempzone
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_getProcVar_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	char* buff = NULL;
	UINT index = 0;
	TempZone* pTZ = NULL;
	DWORD retVal = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);
		pTZ = TempZones_GetZone( &(g_dbContainer.tempZonesDb), index);
		if(pTZ)
		{
			retVal = TempZone_getProcVar(pTZ);
		}
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setActive_Handler
//
//	Routine Description:
//		Sets setActive for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			BOOL - active
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL active = *((BOOL*)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setActive(pTZ, active);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_resetIncDec_Handler
//
//	Routine Description:
//		Sets resetIncDec for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_resetIncDec_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RAIL_resetIncDec_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rails_resetIncDec(&(g_dbContainer.railsDb), index);
#ifndef _BLOCK_TRACE
		t << "railsDb.resetIncDec(" << (LONG)index << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_DisableTest_Handler
//
//	Routine Description:
//		Sets DisableTest for the Rails Database
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_DisableTest_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_DisableTest_Handler, " << I << EOL;
#endif
	
	Rails_DisableTest(&(g_dbContainer.railsDb));
#ifndef _BLOCK_TRACE
	t << "railsDb.DisableTest()" << EOL;
#endif

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_EnableTest_Handler
//
//	Routine Description:
//		Sets EnableTest for the Rails Database
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_EnableTest_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_EnableTest_Handler, " << I << EOL;
#endif
	
	Rails_EnableTest(&(g_dbContainer.railsDb));
#ifndef _BLOCK_TRACE
	t << "railsDb.EnableTest()" << EOL;
#endif

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////////////////
//
//NTSTATUS RAILS_setHardwareOption_Handler(KIrp* I)
//
//The rails can have a hardware (actual buttons on the oven) control, when a switch
//is thrown DI15 will be true, and when this option is set the rails will read the input
//disable alarming and output and the app will disable screen elements
//
////////////////////////////////////////////////////////////////////////////////////
NTSTATUS RAILS_setHardwareOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT isHardwareAvail = *((UINT *)buff);

		Rails_setHardwareOption(&(g_dbContainer.railsDb), isHardwareAvail);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////////////////
//
//NTSTATUS RAILS_readHardwareFlag(KIrp* I)
//
//When the hardware option is present we'll poll for digital input to disable UI where 
//appropriate
//
////////////////////////////////////////////////////////////////////////////////////
NTSTATUS RAILS_readHardwareFlag_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT hardwareVal;
	char *buff = (char *)I->m_ioctlBuffer;
	
	hardwareVal = Rails_returnHardwareRunning(&(g_dbContainer.railsDb));
	
	*((UINT *)buff) = hardwareVal;

	I->m_information = (sizeof(UINT));

	return status;	
}

NTSTATUS RAILS_sendRailsHome_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT whatAction = *((UINT *)buff);
		Rails_sendRailsHome(&(g_dbContainer.railsDb), whatAction);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setSetPoint_Handler
//
//	Routine Description:
//		Sets setSetPoint for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			LONG - setpoint
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setSetPoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(LONG);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setSetPoint_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		LONG setpoint = *((LONG*)(buff + sizeof(UINT)));
		
		
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setSetPoint(pTZ, setpoint);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setSequenceGroup_Handler
//
//	Routine Description:
//		Sets setSequenceGroup for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			DWORD - groupNo
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setSequenceGroup_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setSequenceGroup_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD groupNo = *((DWORD*)(buff + sizeof(UINT)));
		
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setSequenceGroup(pTZ, groupNo);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
		t << "tempZones[" << (DWORD)index << "].setSequenceGroup(" << groupNo << 
			")" << EOL <<
			"Returning " << (retVal ? "TRUE" : "FALSE") << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_setPosition_Handler
//
//	Routine Description:
//		Sets setPosition for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - index into railsDb array.
//			DWORD - presetPosition
//			BOOL - bHomeIndicator
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_setPosition_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = (2*sizeof(DWORD)) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_setPosition_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		DWORD presetPosition = *((DWORD *)(buff + sizeof(DWORD)));
		BOOL bHomeIndicator = *((BOOL *)(buff + (2 * sizeof(DWORD))));
		
		Rails_setPosition(&(g_dbContainer.railsDb), index, presetPosition,
											bHomeIndicator);
#ifndef _BLOCK_TRACE
		t << "railsDb.setPosition(" << (LONG)index << ", " <<
			(LONG)presetPosition << ", " <<
			(LONG)bHomeIndicator << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_getPositionCounts_Handler
//
//	Routine Description:
//		Sets setPosition for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - index into railsDb array.
//
//		Output Buffer:
//			DWORD - postionCounts
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_getPositionCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_getPositionCounts_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);

		DWORD retVal = Rails_getPositionCounts(&(g_dbContainer.railsDb), index);

		*((DWORD *)buff) = retVal;
#ifndef _BLOCK_TRACE
		t << "railsDb.getPositionCounts(" << (LONG)index << ")" << 
			"Returning " << (LONG)retVal << EOL;
#endif
		I->m_information = sizeof(DWORD);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_IntializeEdgeholdBools_Handler
//
//	Routine Description:
//		function name says it all.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_IntializeEdgeholdBools_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_IntializeEdgeholdBools_Handler, " << I << EOL;
#endif

	Rails_IntializeEdgeholdBools(&(g_dbContainer.railsDb));
#ifndef _BLOCK_TRACE
	t << "railsDb.IntializeEdgeholdBools()" << EOL;
#endif

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_setConfiguration_Handler
//
//	Routine Description:
//		Sets setConfiguration for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - index into railsDb array.
//
//		Output Buffer:
//			BOOL - result
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_setConfiguration_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_setConfiguration_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);

		BOOL retVal = Rails_setConfiguration(&(g_dbContainer.railsDb), index);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") <<
			"= railsDb.setConfiguration(" << (LONG)index << ")" << EOL;
#endif
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


NTSTATUS RAILS_readHasHomedFlag_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT homedVal;
	char *buff = (char *)I->m_ioctlBuffer;
	
	homedVal = Rails_returnRailsHaveHomed(&(g_dbContainer.railsDb));
	*((UINT *)buff) = homedVal;
	I->m_information = (sizeof(UINT));

	return status;
}

NTSTATUS RAILS_setHardwareInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rails_setRailInputForHardware(&(g_dbContainer.railsDb), index);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setZoneAuto_Handler
//
//	Routine Description:
//		Sets setZoneAuto for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			ZoneTriState - state
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setZoneAuto_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(enum ZoneTriState);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setZoneAuto_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		enum ZoneTriState state = *((enum ZoneTriState *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		TempZone_setZoneAuto(pTZ, state);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].setZoneAuto(" << 
			(LONG)state << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_setPIDenable_Handler
			
			turns the pid on

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_setPIDenable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char *buff;
	DWORD index;
	BOOL state;

	TempZone* pTZ;
	DWORD dwrdSequenceGroup;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(BOOL);
	buff = NULL;
	index = 0;
	state = FALSE;

	pTZ = NULL;
	dwrdSequenceGroup = 0;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((DWORD*)buff);
			state = *((BOOL *)(buff + sizeof(UINT)));
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			if(pTZ)
			{
				if(state == TRUE)
				{
					dwrdSequenceGroup = TempZone_getSequenceGroup(pTZ);
					if ( ( dwrdSequenceGroup > g_dbContainer.tempZonesDb.startUpGroup ) || ( dwrdSequenceGroup == TH_STARTUPGROUP) )//zones that have not sequenced on cannot be set to auto mode
					{
						state = FALSE;
					}
				}
				TempZone_setPIDenable(pTZ, state);
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setTPOoutput_Handler
//
//	Routine Description:
//		Sets setTPOoutput for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			UCHAR - cTPOoutput
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(LONG);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setTPOoutput_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		LONG cTPOoutput= *((LONG *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		TempZone_set_pendTPOoutput(pTZ, cTPOoutput);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].setTPOoutput(" << 
			cTPOoutput << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  NITROGEN_setActive_Handler
//
//	Routine Description:
//		Sets setActive for the Nitrogen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - state.
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS NITROGEN_setActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setActive_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL state = *((BOOL *)buff);
		BOOL retVal = Nitrogen_setActive(&(g_dbContainer.nitrogen), state);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << "= nitrogen.setActive(" << 
			(state ? "TRUE" : "FALSE") <<
			")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS NITROGEN_getActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Nitrogen_getActive(&g_dbContainer.nitrogen);
	*((UINT*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(long);
	return status;
}

////////////////////////////////////////////////////////////////////////
//  NITROGEN_setNormalTime10ths_Handler
//
//	Routine Description:
//		Sets setNormalTime10ths for the Nitrogen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - time.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS NITROGEN_setNormalTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setNormalTime10ths_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);

		Nitrogen_setNormalTime10ths(&(g_dbContainer.nitrogen), time);
#ifndef _BLOCK_TRACE
		t << "nitrogen.setNormalTime10ths(" << (LONG)time << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  NITROGEN_setPurgeTime10ths_Handler
//
//	Routine Description:
//		Sets setPurgeTime10ths for the Nitrogen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - uiPurgeTime10ths.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS NITROGEN_setPurgeTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setPurgeTime10ths_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);

		Nitrogen_setPurgeTime10ths(&(g_dbContainer.nitrogen), time);
#ifndef _BLOCK_TRACE
		t << "nitrogen.setPurgeTime10ths(" << (LONG)time << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  NITROGEN_setAutoPurgeEnable_Handler
//
//	Routine Description:
//		Sets setAutoPurgeEnable for the Nitrogen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - autoPurgeEnabled.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS NITROGEN_setAutoPurgeEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setAutoPurgeEnable_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		Nitrogen_setAutoPurgeEnable(&(g_dbContainer.nitrogen), enable);
#ifndef _BLOCK_TRACE
		t << "nitrogen.setAutoPurgeEnable(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  NITROGEN_setNitrogenEnable_Handler
//
//	Routine Description:
//		Sets setNitrogenEnable for the Nitrogen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS NITROGEN_setNitrogenEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setNitrogenEnable_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		Nitrogen_setNitrogenEnable(&(g_dbContainer.nitrogen), enable);
#ifndef _BLOCK_TRACE
		t << "nitrogen.setNitrogenEnable(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS NITROGEN_getNitrogenEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Nitrogen_getNitrogenEnable(&g_dbContainer.nitrogen);
	*((UINT*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(long);
	return status;
}

NTSTATUS NITROGEN_setCoolRunTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering NITROGEN_setCoolRunTime_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD runTime = *((DWORD *)buff);

		Nitrogen_setCoolRunTime(&(g_dbContainer.nitrogen), runTime);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS NITROGEN_isNitroOnInCooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	BOOL retVal = Nitrogen_isNitroOnInCooldown(&(g_dbContainer.nitrogen));
	*((BOOL *)I->m_ioctlBuffer) = retVal;

	I->m_information = sizeof(BOOL);

	return status;
}
////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setDeadBandHiTempOffset_Handler
//
//	Routine Description:
//		Sets setDeadBandHiTempOffset for the selected Temperature zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT  - index
//			DWORD - offset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setDeadBandHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setDeadBandHiTempOffset_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index= *((UINT *)buff);
		DWORD offset = *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setDeadBandHiTempOffset(pTZ, offset);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << "= tempZonesDb[" << 
			(LONG)index << "].setDeadBandHiTempOffset(" << 
			(LONG)offset << ")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_SetDeadBandLoTempOffset_Handler
//
//	Routine Description:
//		Sets setDeadBandLoTempOffset for the selected Temperature zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT  - index
//			DWORD - offset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_SetDeadBandLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_SetDeadBandLoTempOffset_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index= *((UINT *)buff);
		DWORD offset = *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setDeadBandLoTempOffset(pTZ, offset);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << "= tempZonesDb[" << 
			(LONG)index << "].setDeadBandLoTempOffset(" << 
			(LONG)offset << ")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableHiProcAlarm_Handler
//
//	Routine Description:
//		Sets enableHiProcAlarm for the selected Temperature zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT  - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableHiProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableHiProcAlarm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index= *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		TempZone_enableHiProcAlarm(pTZ, enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableHiProcAlarm(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LIGHTTOWER_Disable_Handler
//
//	Routine Description:
//		Sets Disable for the Light Tower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			long - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LIGHTTOWER_Disable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering LIGHTTOWER_Disable_Handler, " << I << EOL;
#endif

	long retVal = LightTower_Disable(&(g_dbContainer.lightTower));
	*((long *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << retVal << "= lightTower.Disable()" << EOL;
#endif

	I->m_information = sizeof(long);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LIGHTTOWER_setSonyGreenLightOption_Handler
//
//	Routine Description:
//		Sets Disable for the Light Tower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - off
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LIGHTTOWER_setSonyGreenLightOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering LIGHTTOWER_setSonyGreenLightOption_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL off= *((BOOL *)buff);

		LightTower_setSonyGreenLightOption(&(g_dbContainer.lightTower), off);
#ifndef _BLOCK_TRACE
		t << "lightTower.setSonyGreenLightOption(" << 
			(off ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LIGHTTOWER_getStatus_Handler
//
//	Routine Description:
//		Return getStatus for the Light Tower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			UINT - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LIGHTTOWER_getStatus_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering LIGHTTOWER_getStatus_Handler, " << I << EOL;
#endif
	UINT retVal = LightTower_getLT1Status(&(g_dbContainer.lightTower));
	*((UINT *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (LONG)retVal << "= lightTower.getStatus()" << EOL;
#endif

	I->m_information = sizeof(long);

	return status;
}

NTSTATUS LIGHTTOWER_LT2_getStatus_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	UINT retVal = LightTower_getLT2Status(&(g_dbContainer.lightTower));
	*((UINT *)I->m_ioctlBuffer) = retVal;

	I->m_information = sizeof(long);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LIGHTTOWER_Enable_Handler
//
//	Routine Description:
//		Enable the Light Tower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			long - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LIGHTTOWER_Enable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering LIGHTTOWER_Enable_Handler, " << I << EOL;
#endif
	long retVal = LightTower_Enable(&(g_dbContainer.lightTower));
	*((long *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << retVal << "= lightTower.Enable()" << EOL;
#endif

	I->m_information = sizeof(long);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableHiDeviationAlarm_Handler
//
//	Routine Description:
//		enableHiDeviationAlarm for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableHiDeviationAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableHiDeviationAlarm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_enableHiDeviationAlarm(&(pTZ->pidCtrl), enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableHiDeviationAlarm(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableHiDeviationWarn_Handler
//
//	Routine Description:
//		enableHiDeviationWarn for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableHiDeviationWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableHiDeviationWarn_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable= *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_enableHiDeviationWarn(&(pTZ->pidCtrl), enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableHiDeviationWarn(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableLoDeviationWarn_Handler
//
//	Routine Description:
//		enableLoDeviationWarn for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableLoDeviationWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableLoDeviationWarn_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable= *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_enableLoDeviationWarn(&(pTZ->pidCtrl), enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableLoDeviationWarn(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableLoDeviationAlarm_Handler
//
//	Routine Description:
//		enableLoDeviationAlarm for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableLoDeviationAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableLoDeviationAlarm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable= *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_enableLoDeviationAlarm(&(pTZ->pidCtrl), enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableLoDeviationAlarm(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_getModelNo_Handler
//
//	Routine Description:
//		Returns the model number for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD modelNo
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_getModelNo_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_getModelNo_Handler, " << I << EOL;
#endif

	DWORD retVal = Oven_getModelNo(&(g_dbContainer.ovenDb));
	*((DWORD *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (LONG)retVal << "= ovenDb.getModelNo()" << EOL;
#endif

	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_ExternalCheckForPowerFailure_Handler
//
//	Routine Description:
//		Returns ExternalCheckForPowerFailure for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL powerFail
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_ExternalCheckForPowerFailure_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_ExternalCheckForPowerFailure_Handler, " << I << EOL;
#endif

	BOOL retVal = Oven_ExternalCheckForPowerFailure(&(g_dbContainer.ovenDb));
	*((BOOL *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (retVal ? "TRUE" : "FALSE") << 
		"= ovenDb.ExternalCheckForPowerFailure()" << EOL;
#endif

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_getJob_Handler
//
//	Routine Description:
//		Returns getJob for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			UINT jobNo
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_getJob_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_getJob_Handler, " << I << EOL;
#endif

	UINT retVal = Oven_getJob(&(g_dbContainer.ovenDb));
	*((UINT *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (LONG)retVal << 
		"= ovenDb.getJob()" << EOL;
#endif

	I->m_information = sizeof(UINT);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_getDirection_Handler
//
//	Routine Description:
//		Returns getDirection for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL leftToRight
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_getDirection_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_getDirection_Handler, " << I << EOL;
#endif

	BOOL retVal = Oven_getDirection(&(g_dbContainer.ovenDb));
	*((BOOL *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (retVal ? "TRUE" : "FALSE") << 
		"= ovenDb.getDirection()" << EOL;
#endif

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_getRecipeName_Handler
//
//	Routine Description:
//		Returns getRecipeName for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			char string - name
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_getRecipeName_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_getRecipeName_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;
	char *retVal = Oven_getRecipeName(&(g_dbContainer.ovenDb));
	if(I->m_outputBufferSize < (strlen(retVal) + 1))
	{
		*(buff) = '\0';
		buffSize = 1;
	}
	else
	{
		strcpy(buff, retVal);
		buffSize = strlen(retVal)+1;
	}

#ifndef _BLOCK_TRACE
	t << retVal << "= ovenDb.getRecipeName()" << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setRecipeName_Handler
//
//	Routine Description:
//		Sets setRecipeName for the oven.OVEN_SetBoardStopOption
//
//	Parameters:
//		I - IRP containing IOCTL request
//			char string - name
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setRecipeName_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	
	char *buff = (char *)I->m_ioctlBuffer;
	BOOL retVal = Oven_setRecipeName(&(g_dbContainer.ovenDb), buff);
	*((BOOL *)buff) = retVal;
	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_enableLoProcAlarm_Handler
//
//	Routine Description:
//		Sets enableLoProcAlarm for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_enableLoProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_enableLoProcAlarm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable= *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		TempZone_enableLoProcAlarm(pTZ, enable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb[" << (LONG)index << "].enableLoProcAlarm(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setHiProcTemp_Handler
//
//	Routine Description:
//		Sets setHiProcTemp for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - highProcTemp
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setHiProcTemp_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setHiProcTemp_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD highProcTemp= *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setHiProcTemp(pTZ, highProcTemp);

#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << " = tempZonesDb[" << 
			(LONG)index << "].setHiProcTemp(" << 
			(LONG)highProcTemp << ")" << EOL;
#endif

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setAlarmHiTempOffset_Handler
//
//	Routine Description:
//		Sets setAlarmHiTempOffset for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - aHiTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setAlarmHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD highTemp= *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setAlarmHiTempOffset(pTZ, highTemp);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_SetDemoMode_Handler
//
//	Routine Description:
//		Sets SetDemoMode for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - demoMode
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_SetDemoMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_SetDemoMode_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL mode = *((BOOL *)buff);
		
		Oven_SetDemoMode(&(g_dbContainer.ovenDb), mode);

#ifndef _BLOCK_TRACE
		t << "ovenDb.SetDemoMode(" << 
			(mode ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
#if 0
////////////////////////////////////////////////////////////////////////
//  OVEN_setAsBoardTypeA_Handler
//
//	Routine Description:
//		Sets setAsBoardTypeA for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - type
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setAsBoardTypeA_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setAsBoardTypeA_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL type = *((BOOL *)buff);
		
		Oven_setAsBoardTypeA(&(g_dbContainer.ovenDb), type);

#ifndef _BLOCK_TRACE
		t << "ovenDb.setAsBoardTypeA(" << 
			(type ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
#else
NTSTATUS OVEN_waterTempHighEnable_Handler(KIrp *I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	if (I->m_inputBufferSize >= buffSize)
	{
		Oven_waterTempHighEnable(&g_dbContainer.ovenDb, *(BOOL*)I->m_ioctlBuffer);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return(status);
}

NTSTATUS OVEN_waterTempHighAlarmTime_Handler(KIrp *I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	if (I->m_inputBufferSize >= buffSize)
	{
		Oven_waterTempHighAlarmTime(&g_dbContainer.ovenDb, *(DWORD*)I->m_ioctlBuffer);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return(status);
}

NTSTATUS OVEN_waterTempHighWarningTime_Handler(KIrp *I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	if (I->m_inputBufferSize >= buffSize)
	{
		Oven_waterTempHighWarningTime(&g_dbContainer.ovenDb, *(DWORD*)I->m_ioctlBuffer);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return(status);
}
#endif
////////////////////////////////////////////////////////////////////////
//  OVEN_setLowExhaustAlarmTime_Handler
//
//	Routine Description:
//		Sets setLowExhaustAlarmTime for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			int - LEalarm
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setLowExhaustAlarmTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setLowExhaustAlarmTime_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int LEalarm = *((int *)buff);
		
		Oven_setLowExhaustAlarmTime(&(g_dbContainer.ovenDb), LEalarm);

#ifndef _BLOCK_TRACE
		t << "ovenDb.setLowExhaustAlarmTime(" << (LONG)LEalarm <<
			")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setLowExhaustWarningTime_Handler
//
//	Routine Description:
//		Sets setLowExhaustWarningTime for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			int - LEwarn
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setLowExhaustWarningTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setLowExhaustWarningTime_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int LEwarn = *((int *)buff);
		
		Oven_setLowExhaustWarningTime(&(g_dbContainer.ovenDb), LEwarn);

#ifndef _BLOCK_TRACE
		t << "ovenDb.setLowExhaustWarningTime(" << (LONG)LEwarn <<
			")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setThirdLaneEnabled_Handler
//
//	Routine Description:
//		Sets setThirdLaneEnabled for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - laneEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setThirdLaneEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		Oven_setThirdLaneEnabled(&(g_dbContainer.ovenDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  OVEN_setStartWithJob_Handler
//
//	Routine Description:
//		Sets setStartWithJob for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - jobStatus
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setStartWithJob_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL jobState = *((BOOL *)buff);
			
		Oven_setStartWithJob(&(g_dbContainer.ovenDb), jobState);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  OVEN_setBlowerFailureOption_Handler
//
//	Routine Description:
//		Sets setBlowerFailureOption for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - option
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBlowerFailureOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL option = *((BOOL *)buff);
	
		Oven_setBlowerFailureOption(&(g_dbContainer.ovenDb), option);

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_setBoardStop_Handler

			Currently the board stop and board drop are tied to one 
			control flag, this function will allow the enduser to select 
			the stop warning seperatly from the board drop.

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS OVEN_setBoardStop_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT index;
	BOOL temp;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(BOOL);
	buff = NULL;
	index = 0;
	temp = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((UINT *)buff);
			temp = *((BOOL *)(buff+sizeof(UINT)));	
			Oven_setBoardStopOption(temp, index);
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setWarnHiTempOffset_Handler
//
//	Routine Description:
//		Sets setBlowerFailureOption for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - newWarnHighTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setWarnHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setWarnHiTempOffset_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((DWORD *)buff);
		DWORD temp = *((DWORD *)(buff+sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setWarnHiTempOffset(pTZ, temp);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << 
			" = tempZonesDb[" << (LONG)index << "].setWarnHiTempOffset(" << 
			(LONG)temp << ")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setWarnLoTempOffset_Handler
//
//	Routine Description:
//		Sets setWarnLoTempOffset for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - newWarnLoTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setWarnLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setWarnLoTempOffset_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((DWORD *)buff);
		DWORD temp = *((DWORD *)(buff+sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setWarnLoTempOffset(pTZ, temp);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << 
			" = tempZonesDb[" << (LONG)index << "].setWarnLoTempOffset(" << 
			(LONG)temp << ")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setAlarmLoTempOffset_Handler
//
//	Routine Description:
//		Sets setAlarmLoTempOffset for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - newAlarmLowTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setAlarmLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_setAlarmLoTempOffset_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((DWORD *)buff);
		DWORD temp = *((DWORD *)(buff+sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setAlarmLoTempOffset(pTZ, temp);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << 
			" = tempZonesDb[" << (LONG)index << "].setAlarmLoTempOffset(" << 
			(LONG)temp << ")" << EOL;
#endif
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setLTOption_Handler
//
//	Routine Description:
//		Sets setLTOption for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - option
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setLTOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	// this flag has been deprecated - instead use the Custom Light Tower setup in CSystemAddParamsDaoRecordset



	I->m_information = 0;

	return status;
}

//--Start Testing Here - 10/21/02 JMR
////////////////////////////////////////////////////////////////////////
//  OVEN_setRedundantOverTempOption_Handler
//
//	Routine Description:
//		Sets setRedundantOverTempOption for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - option
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setRedundantOverTempOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);



	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL option = *((BOOL *)buff);
	
		Oven_setRedundantOverTempOption(&(g_dbContainer.ovenDb), option);


	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setDirection_Handler
//
//	Routine Description:
//		Sets setDirection for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - standardDirection
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setDirection_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL direction = *((BOOL *)buff);
	
		Oven_setDirection(&(g_dbContainer.ovenDb), direction);

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return STATUS_SUCCESS;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_setModelNo_Handler
			
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_setModelNo_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	char* buff = NULL;
	DWORD modelNo = 0;	
	BOOL retVal = FALSE;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		modelNo = *((DWORD *)buff);	
		
		retVal = Oven_setModelNo(&(g_dbContainer.ovenDb), modelNo);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setSMEMAConfig_Handler
//
//	Routine Description:
//		Sets setSMEMAConfig for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setSMEMAConfig_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD config = *((DWORD *)buff);	
		
		BOOL retVal = Oven_setSMEMAConfig((&g_dbContainer.ovenDb), config);
		

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBoardDropConfig_Handler
//
//	Routine Description:
//		Sets setBoardDropConfig for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBoardDropConfig_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD config = *((DWORD *)buff);	
		
		BOOL retVal = Oven_setBoardDropConfig(&(g_dbContainer.ovenDb), config);


		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_setLoProcTemp_Handler
//
//	Routine Description:
//		Sets setLoProcTemp for the Selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_setLoProcTemp_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD temp = *((DWORD *)(buff+sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_setLoProcTemp(pTZ, temp);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_getTPOoutput_Handler
//
//	Routine Description:
//		Gets getTPOoutput for the Selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			DWORD tpoOutput
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_getTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		DWORD retVal = TempZone_getTPOoutput(pTZ);
		
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_getSetPoint_Handler
//
//	Routine Description:
//		Gets getSetPoint for the Selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			DWORD tpoOutput
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_getSetPoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_getSetPoint_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		DWORD retVal = TempZone_getSetPoint(pTZ);
#ifndef _BLOCK_TRACE
		t << (LONG)retVal << " = tempZonesDb[" <<
			(LONG)index << "].getSetPoint()" << EOL;
#endif
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBoardsInOvenConfig_Handler
//
//	Routine Description:
//		Set setBoardsInOvenConfig for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBoardsInOvenConfig_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD config = *((DWORD *)buff);
	
		BOOL retVal = Oven_setBoardsInOvenConfig(&(g_dbContainer.ovenDb), config);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBoardAnimationConfig_Handler
//
//	Routine Description:
//		Set setBoardAnimationConfig for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBoardAnimationConfig_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD config = *((DWORD *)buff);
	
		BOOL retVal = Oven_setBoardAnimationConfig(&(g_dbContainer.ovenDb), config);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBoardsProcessedConfig_Handler
//
//	Routine Description:
//		Set setBoardsProcessedConfig for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBoardsProcessedConfig_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD config = *((DWORD *)buff);
	
		BOOL retVal = Oven_setBoardsProcessedConfig(&(g_dbContainer.ovenDb), config);

		
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBelts_Handler
//
//	Routine Description:
//		Set setBelts for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - nBelts
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setBelts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setBelts_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nBelts = *((DWORD *)buff);
		
		BOOL retVal = Oven_setBelts(&(g_dbContainer.ovenDb), nBelts);

#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << 
			" = ovenDb.setBelts(" << 
			(LONG)nBelts << ")" << EOL;
#endif
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  OVEN_resume_Handler

				resume command after recipe load

	RETURNS:	STATUS_SUCCESS
--------------------------------------------------------------------*/
NTSTATUS OVEN_resume_Handler(XpDriverDevice* pXP, KIrp* I)
{
	NTSTATUS status;
	DWORD jobNo;

	jobNo = COOLDOWN;
	status = STATUS_SUCCESS;
	
	if(pXP)
	{
		pXP->m_bOvenIsPaused = FALSE;
	}
	Oven_resume(&g_dbContainer.ovenDb);
	SMEMA_MESSmemaVariable(0, MES_INDEX);

	if(pXP && I)
	{
		jobNo = Oven_getTempJobNo(&g_dbContainer.ovenDb);
		if( jobNo != COOLDOWN )
		{
			TempZones_initializePowerUpSequencing(&(g_dbContainer.tempZonesDb));
			Oven_SlaveConfiguration();
		}
	

		I->m_information = 0;
		
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BELTS_activateAllBelts_Handler

 
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BELTS_activateAllBelts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;
	UINT buffSize = sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		UINT nIndex = *((UINT *)buff);	
		Belts_doPowerUpSequencing(&(g_dbContainer.beltsDb), nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BELTS_deactivateAllBelts_Handler

 
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BELTS_deactivateAllBelts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	Belts_initializePowerUpSequencing(&(g_dbContainer.beltsDb));
	I->m_information = 0;

	return status;	
} 

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_getCurrentState_Handler
//
//	Routine Description:
//		Set getCurrentState for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT index
//
//		Output Buffer:
//			DWORD - state
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_getCurrentState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_getCurrentState_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		DWORD retVal = TempZone_getCurrentState(pTZ);
#ifndef _BLOCK_TRACE
		t << (LONG)retVal << " = tempZonesDb[" << (LONG)index << 
			"].getCurrentState()" << EOL;
#endif
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_isActive_Handler
//
//	Routine Description:
//		Set isActive for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT index
//
//		Output Buffer:
//			BOOL - zoneActive
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_isActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_isActive_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_isActive(pTZ);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << " = tempZonesDb[" << (LONG)index << 
			"].isActive()" << EOL;
#endif
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_IsZoneInWarning_Handler
//
//	Routine Description:
//		Set IsZoneInWarning for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT index
//
//		Output Buffer:
//			BOOL - zoneInWarning
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_IsZoneInWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_IsZoneInWarning_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_IsZoneInWarning(pTZ);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << " = tempZonesDb[" << (LONG)index << 
			"].IsZoneInWarning()" << EOL;
#endif
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_doFastPidControl_Handler
//
//	Routine Description:
//		Sets FastPidControl for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
//End Testing HERE - JMR
NTSTATUS BELTS_doFastPidControl_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_doFastPidControl_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= sizeof(UINT))
	{
		UINT index = *((UINT *)I->m_ioctlBuffer);
		if(index < MaxBelts)
		{
			Belt_doFastPidControl(&(g_dbContainer.belt[index]));
#ifndef _BLOCK_TRACE
			t << "Setting Belt[" << (LONG)index << "].doFastPidControl" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enableHiDevAlarm_Handler
//
//	Routine Description:
//		Sets HiDevAlarm for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableHiDevAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableHiDevAlarm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableHiDevAlarm(&(g_dbContainer.belt[index]),enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableHiDevAlarm(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enableHiDevWarn_Handler
//
//	Routine Description:
//		Sets HiDevWarn for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableHiDevWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableHiDevWarn_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableHiDevWarn(&(g_dbContainer.belt[index]), enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableHiDevWarn(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enableHiProcAlarm_Handler
//
//	Routine Description:
//		Sets HiProcAlarm for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableHiProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableHiProcAlarm_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableHiProcAlarm(&(g_dbContainer.belt[index]), enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableHiProcAlarm(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enableLoDevAlarm_Handler
//
//	Routine Description:
//		Sets LoDevAlarm for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableLoDevAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableLoDevAlarm_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableLoDevAlarm(&(g_dbContainer.belt[index]), enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableLoDevAlarm(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enableLoProcAlarm_Handler
//
//	Routine Description:
//		Sets LoProcAlarm for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableLoProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableLoProcAlarm_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableLoProcAlarm(&(g_dbContainer.belt[index]), enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableLoProcAlarm(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_enterSlowPidValue_Handler
//
//	Routine Description:
//		Sets the SlowPidValue
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			LONG - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enterSlowPidValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(LONG) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enterSlowPidValue_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		LONG value = *((LONG *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enterSlowPidValue(&(g_dbContainer.belt[index]), value);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enterSlowPidValue(" <<
				value << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_get4BElapsedPositionCountTics_Handler
//
//	Routine Description:
//		Retreives 4BElapsedPositionCountTics from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output Buffer contains:
//			DWORD - fourBillionElapsedPositionCountTics
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_get4BElapsedPositionCountTics_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_get4BElapsedPositionCountTics_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_get4BElapsedPositionCountTics(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].get4BElapsedPositionCountTics()" << EOL <<
				"Returning " << retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getAutoMode_Handler
//
//	Routine Description:
//		Retreives getAutoMode from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			BOOL - autoMode
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getAutoMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getAutoMode_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			BOOL retVal = Belt_getAutoMode(&(g_dbContainer.belt[index]));
			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getAutoMode()" << EOL <<
				"Returning " << (retVal ? "TRUE": "FALSE") << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getBeltActive_Handler
//
//	Routine Description:
//		Retreives getBeltActive from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			BOOL - beltActive
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getBeltActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getBeltActive_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			BOOL retVal = Belt_getBeltActive(&(g_dbContainer.belt[index]));
			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getBeltActive()" << EOL <<
				"Returning " << (retVal ? "TRUE": "FALSE") << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getCountMethod_Handler
//
//	Routine Description:
//		Retreives getCountMethod from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			CountMethod - countMethod
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getCountMethod_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getCountMethod_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			enum CountMethod retVal = Belt_getCountMethod(&(g_dbContainer.belt[index]));
			*((enum CountMethod *)buff) = retVal;
			buffSize = sizeof(enum CountMethod);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getCountMethod()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getCurrentState_Handler
//
//	Routine Description:
//		Retreives getCurrentState from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			DWORD - state
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getCurrentState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getCurrentState_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_getCurrentState(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getCurrentState()" << EOL <<
				"Returning " << retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getHiPercentLimit_Handler
//
//	Routine Description:
//		Retreives getHiPercentLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iRangeHiPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getHiPercentLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getHiPercentLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getHiPercentLimit(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getHiPercentLimit()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getHiSpeedRange_Handler
//
//	Routine Description:
//		Retreives getHiSpeedRange from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iRangeHiSpeed
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getHiSpeedRange_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getHiSpeedRange_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getHiSpeedRange(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getHiSpeedRange()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getInputRangeHighValue_Handler
//
//	Routine Description:
//		Retreives getInputRangeHighValue from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iInHi
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getInputRangeHighValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getInputRangeHighValue_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getInputRangeHighValue(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getInputRangeHighValue()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getInputRangeLowValue_Handler
//
//	Routine Description:
//		Retreives getInputRangeLowValue from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iInLo
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getInputRangeLowValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getInputRangeLowValue_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getInputRangeLowValue(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getInputRangeLowValue()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getLoPercentLimit_Handler
//
//	Routine Description:
//		Retreives getLoPercentLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iRangeLoPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getLoPercentLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getLoPercentLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getLoPercentLimit(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getLoPercentLimit()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getLowSpeedLimit_Handler
//
//	Routine Description:
//		Retreives getLowSpeedLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iRangeLoSpeed
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getLowSpeedLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getLowSpeedLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getLowSpeedLimit(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getLowSpeedLimit()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getMaxFreq_Handler
//
//	Routine Description:
//		Retreives getMaxFreq from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iMaxFreq
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getMaxFreq_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getMaxFreq_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getMaxFreq(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getMaxFreq()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getPulsesPerCmCount_Handler
//
//	Routine Description:
//		Retreives getPulsesPerCmCount from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - m_iPulsesPerCmBelt
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getPulsesPerCmCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getPulsesPerCmCount_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getPulsesPerCmCount(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getPulsesPerCmCount()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getSetPoint_Handler
//
//	Routine Description:
//		Retreives getSetPoint from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			DWORD - setSpeedCountsPerSec
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getSetPoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getSetPoint_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_getSetPoint(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getSetPoint()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getSpeedCounts_Handler
//
//	Routine Description:
//		Retreives getSpeedCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			UINT - actualSpeedCountsPerSec
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getSpeedCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getSpeedCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			UINT retVal = Belt_getSpeedCounts(&(g_dbContainer.belt[index]));
			*((UINT *)buff) = retVal;
			buffSize = sizeof(UINT);

		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getSpeedInCMsPerMin_Handler
//
//	Routine Description:
//		Retreives getSpeedInCMsPerMin from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			DWORD - speedInCMsPerMin
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getSpeedInCMsPerMin_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getSpeedInCMsPerMin_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_getSpeedInCMsPerMin(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getSpeedInCMsPerMin()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getSummOfSpeeds_Handler
//
//	Routine Description:
//		Retreives getSummOfSpeeds from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			DWORD - summOfSpeeds
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getSummOfSpeeds_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_getSummOfSpeeds_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_getSummOfSpeeds(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].getSummOfSpeeds()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_IsBeltInWarning_Handler
//
//	Routine Description:
//		Retreives IsBeltInWarning from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			BOOL - TRUE if belt is in warning/FALSE Otherwise
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_IsBeltInWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_IsBeltInWarning_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			BOOL retVal = Belt_IsBeltInWarning(&(g_dbContainer.belt[index]));
			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].IsBeltInWarning()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_IsOpenLoop_Handler
//
//	Routine Description:
//		Retreives IsOpenLoop from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			BOOL - openLoopSystem
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_IsOpenLoop_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_IsOpenLoop_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			BOOL retVal = Belt_isOpenLoop(&(g_dbContainer.belt[index]));
			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].isOpenLoop()" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setAutoMode_Handler
//
//	Routine Description:
//		Sets setAutoMode from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - autoMode (optional - defaults to TRUE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setAutoMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = (sizeof(UINT)*2);
	UINT uMode;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
//		BOOL autoMode = TRUE;
		
//		if(I->m_inputBufferSize >= (buffSize + sizeof(BOOL)))
//		{

		uMode = *((UINT *)(buff + sizeof(UINT)));
//		}

		if(index < MaxBelts)
		{
			Belt_setAutoMode(&(g_dbContainer.belt[index]), uMode);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setBeltActive_Handler
//
//	Routine Description:
//		Sets setBeltActive from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - beltActive
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setBeltActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setBeltActive_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL beltActive = *((BOOL *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setAutoMode(&(g_dbContainer.belt[index]), beltActive);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setAutoMode(" <<
				(beltActive ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setElapsedPositionCounts_Handler
//
//	Routine Description:
//		Sets setElapsedPositionCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - elapsedPositionCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setElapsedPositionCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setElapsedPositionCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setElapsedPositionCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setElapsedPositionCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiDeadBandOffsetCounts_Handler
//
//	Routine Description:
//		Sets setHiDeadBandOffsetCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - hiDeadBandOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiDeadBandOffsetCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiDeadBandOffsetCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiDeadBandOffsetCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiDeadBandOffsetCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiDeviationCounts_Handler
//
//	Routine Description:
//		Sets setHiDeviationCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - hiDeviationOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiDeviationCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiDeviationCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiDeviationCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiDeviationCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiPercentLimit_Handler
//
//	Routine Description:
//		Sets setHiPercentLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UNIT - m_iRangeHiPercent
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiPercentLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiPercentLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT limit = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiPercentLimit(&(g_dbContainer.belt[index]), limit);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiPercentLimit(" <<
				(LONG)limit << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiProcessCounts_Handler
//
//	Routine Description:
//		Sets setHiProcessCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - hiProcessOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiProcessCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiProcessCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiProcessCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiProcessCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiSpeedLimit_Handler
//
//	Routine Description:
//		Sets setHiSpeedLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UNIT - m_iRangeHiSpeed
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiSpeedLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiSpeedLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT limit = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiSpeedLimit(&(g_dbContainer.belt[index]), limit);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiSpeedLimit(" <<
				(LONG)limit << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setHiWarningCounts_Handler
//
//	Routine Description:
//		Sets setHiWarningCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - hiWarningOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setHiWarningCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setHiWarningCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setHiWarningCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setHiWarningCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setInputRangeHighValue_Handler
//
//	Routine Description:
//		Sets setInputRangeHighValue from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UINT - m_iInHi
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setInputRangeHighValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setInputRangeHighValue_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT value = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setInputRangeHighValue(&(g_dbContainer.belt[index]), value);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setInputRangeHighValue(" <<
				(LONG)value << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLoDeadBandOffsetCounts_Handler
//
//	Routine Description:
//		Sets setLoDeadBandOffsetCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - loDeadBandOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLoDeadBandOffsetCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLoDeadBandOffsetCounts(&(g_dbContainer.belt[index]), count);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLoDeviationCounts_Handler
//
//	Routine Description:
//		Sets setLoDeviationCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - loDeviationOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLoDeviationCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setLoDeviationCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLoDeviationCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setLoDeviationCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLoPercentLimit_Handler
//
//	Routine Description:
//		Sets setLoPercentLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UINT - m_iRangeLoPercent
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLoPercentLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setLoPercentLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT value = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLoPercentLimit(&(g_dbContainer.belt[index]), value);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setLoPercentLimit(" <<
				(LONG)value << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLoProcessCounts_Handler
//
//	Routine Description:
//		Sets setLoProcessCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - loProcessOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLoProcessCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setLoProcessCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLoProcessCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setLoProcessCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLoWarningCounts_Handler
//
//	Routine Description:
//		Sets setLoWarningCounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - loWarningOffsetCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLoWarningCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setLoWarningCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD count = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLoWarningCounts(&(g_dbContainer.belt[index]), count);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setLoWarningCounts(" <<
				count << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setLowSpeedLimit_Handler
//
//	Routine Description:
//		Sets setLowSpeedLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UINT - m_iRangeLoSpeed
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setLowSpeedLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setLowSpeedLimit_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT limit = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setLowSpeedLimit(&(g_dbContainer.belt[index]), limit);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setLowSpeedLimit(" <<
				(LONG)limit << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS BELTS_setWarningTimeVariable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD devTime = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setWarningTimeVariable(&(g_dbContainer.belt[index]), devTime);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}	
NTSTATUS BELTS_setDeadbandDeviationTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD devTime = *((DWORD *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setDeadbandDeviationTime(&(g_dbContainer.belt[index]), devTime);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  BELTS_setManualTPOcounts_Handler
//
//	Routine Description:
//		Sets setManualTPOcounts from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - manualTPOcounts
//
//		Output buffer contains:
//			BOOL  - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setManualTPOcounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);
	BOOL retVal= FALSE;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setManualTPOcounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		DWORD index = *((DWORD *)buff);
		DWORD limit = *((DWORD *)(buff + sizeof(DWORD)));
		
		if(index < MaxBelts)
		{
			retVal = 
				Belt_setManualTPOcounts(&(g_dbContainer.belt[index]), limit);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setManualTPOcounts(" <<
				(LONG)limit << ")" << EOL <<
				"Returning " << (retVal ? "TRUE" : "FALSE")<< EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	*((BOOL *)buff) = retVal;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setMaxFreq_Handler
//
//	Routine Description:
//		Sets setMaxFreq for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UINT - m_iMaxFreq
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setMaxFreq_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setMaxFreq_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT maxFreq = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setMaxFreq(&(g_dbContainer.belt[index]), maxFreq);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setMaxFreq(" <<
				(LONG)maxFreq << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setOpenLoop_Handler
//
//	Routine Description:
//		Sets setOpenLoop for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - openLoopSystem
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setOpenLoop_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setOpenLoop_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL openLoop = *((BOOL *)(buff + sizeof(BOOL)));
		
		if(index < MaxBelts)
		{
			Belt_setOpenLoop(&(g_dbContainer.belt[index]), openLoop);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setOpenLoop(" <<
				(LONG)openLoop << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setPb_Handler
//
//	Routine Description:
//		Sets setPb for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - pid.setPb( pb )
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setPb_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setPb_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD pidPb = *((DWORD *)(buff + sizeof(DWORD)));
		
		if(index < MaxBelts)
		{
			Belt_setPb(&(g_dbContainer.belt[index]), pidPb);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setPb(" <<
				(LONG)pidPb << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setPulsesPerCmCount_Handler
//
//	Routine Description:
//		Sets setPulsesPerCmCount for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			UINT - m_iPulsesPerCmBelt
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setPulsesPerCmCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setPulsesPerCmCount_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT pulses = *((UINT *)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setPulsesPerCmCount(&(g_dbContainer.belt[index]), pulses);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setPulsesPerCmCount(" <<
				(LONG)pulses << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BELTS_setSpeedInCMsPerMin_Handler
			
			SP for belts

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/

NTSTATUS BELTS_setSpeedInCMsPerMin_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);
	char* buff = NULL;
	UINT index = 0;
	DWORD speed = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);
		speed = *((DWORD*)(buff + sizeof(UINT)));
		if(index < MaxBelts)
		{
			Belt_setSpeedInCMsPerMin(&(g_dbContainer.belt[index]), speed);

		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setSpeedCounts_Handler
//
//	Routine Description:
//		Sets setSpeedCounts for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			WORD - setSpeedInCounts
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setSpeedCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(WORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setSpeedCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		WORD speed = *((WORD*)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setSpeedCounts(&(g_dbContainer.belt[index]), speed);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setSpeedCounts(" <<
				(LONG)speed << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setTd_Handler
//
//	Routine Description:
//		Sets setTd for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - pid.setTd( td )
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setTd_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setTd_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD pidTd = *((DWORD*)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setTd(&(g_dbContainer.belt[index]), pidTd);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setTd(" <<
				(LONG)pidTd << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_setTi_Handler
//
//	Routine Description:
//		Sets setTd for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			DWORD - pid.setTi( td * 40 )
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_setTi_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_setTi_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD pidTi = *((DWORD*)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setTi(&(g_dbContainer.belt[index]), pidTi);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].setTi(" <<
				(LONG)pidTi << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS BELTS_enableSequencing_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL beltSeq = *((BOOL*)buff);
	
		Belts_BeltsAreSequenced(&(g_dbContainer.beltsDb), beltSeq);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS BELTS_setSequenceGroup_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT iGroup = *((UINT*)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			Belt_setSequenceGroup(&(g_dbContainer.belt[index]), iGroup);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS BELTS_getConfigParam_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT) ;
	DWORD retVal;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT param = *((UINT *)buff);
		UINT index = *((UINT*)(buff + sizeof(UINT)));
		
		if(index < MaxBelts)
		{
			switch(param)
			{

			case PROP_PARAM:
			 retVal = Belt_getPb(&(g_dbContainer.belt[index]));
			break;

			case INT_PARAM:
				retVal = Belt_getTi(&(g_dbContainer.belt[index]));
			break;

			case DERIV_PARAM:
				retVal = Belt_getTd(&(g_dbContainer.belt[index]));
			break;


			case ALARM_DEADBAND_PARAM:
			 retVal =Belt_getHiDeadBandOffsetCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_HI_PROC_OFFSET_PARAM:
			 retVal = Belt_getHiProcessCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_HI_DEV_OFFSET_PARAM:
			 retVal = Belt_getHiDeviationCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_HI_WARN_OFFSET_PARAM:
			 retVal = Belt_getHiWarningCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_LO_WARN_OFFSET_PARAM:
			 retVal = Belt_getLoWarningCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_LO_DEV_OFFSET_PARAM:
			 retVal = Belt_getLoDeviationCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_LO_PROC_OFFSET_PARAM:
			 retVal = Belt_getLoProcessCounts(&(g_dbContainer.belt[index]));
			break;

			case ALARM_HI_PROC_ENABLE_PARAM:
			retVal = Belt_returnHiProcAlarm(&(g_dbContainer.belt[index]));		
			break;
		
			case ALARM_HI_DEV_ENABLE_PARAM:
			retVal = Belt_returnHiDevAlarm(&(g_dbContainer.belt[index]));
			break;
	
			case ALARM_HI_WARN_ENABLE_PARAM:
			retVal = Belt_returnHiDevWarn(&(g_dbContainer.belt[index]));
			break;
		
			case ALARM_LO_WARN_ENABLE_PARAM:
			retVal = Belt_returnLoDevWarn(&(g_dbContainer.belt[index]));
			break;
		
			case ALARM_LO_DEV_ENABLE_PARAM:
			retVal = Belt_returnLoDevAlarm(&(g_dbContainer.belt[index]));
			break;	

			case ALARM_LO_PROC_ENABLE_PARAM:
			retVal = Belt_returnLoProcAlarm(&(g_dbContainer.belt[index]));
			break;

			case OUTPUT_TYPE_PARAM:
				
				retVal = 0;
			break;
		
			case INPUT_TYPE_PARAM:
				retVal = 0;
			break;

			default:
				break;

			}		

			*((DWORD *)buff) = retVal;
			I->m_information = sizeof(DWORD);

		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
			I->m_information = 0;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
		I->m_information = 0;
	}
	return status;
}


////////////////////////////////////////////////////////////////////////
//  OVEN_Pause_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_Pause_Handler(XpDriverDevice* pXP, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	
	pXP->m_bOvenIsPaused = TRUE;
	Oven_pause(&(g_dbContainer.ovenDb));
	TempZones_enableDrawWarning(&(g_dbContainer.tempZonesDb), FALSE);

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setJob_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - Job number.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setJob_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setJob_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT jobNo = *((UINT *)buff);
		

		Oven_setJob(&(g_dbContainer.ovenDb), jobNo);

#ifndef _BLOCK_TRACE
		t << "ovenDb.setJob(" <<
			(LONG)jobNo << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setJobStartupComplete_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - jobStartupComplete.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setJobStartupComplete_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_setJobStartupComplete_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL jobComp = *((BOOL*)buff);
				
		Oven_setJobStartupComplete(&(g_dbContainer.ovenDb), jobComp);
		
#ifndef _BLOCK_TRACE
		t << "ovenDb.setJobStartupComplete(" <<
			(LONG)jobComp << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


NTSTATUS TEMPZONES_DeActivateZones_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

//	t << "Entering TEMPZONES_DeActivateZones_Handler, " << I << EOL;
// TODO:	Verify that the input parameters are correct
//			If not, return STATUS_INVALID_PARAMETER

// TODO:	Handle the the XPDRIVER_IOCTL_801 request, or 
//			defer the processing of the IRP (i.e. by queuing) and set
//			status to STATUS_PENDING.

// TODO:	Assuming that the request was handled here. Set I.Information
//			to indicate how much data to copy back to the user.
	I->m_information = 0;

	return status;
}
NTSTATUS TEMPZONES_ActivateZones_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

//	t << "Entering TEMPZONES_ActivateZones_Handler, " << I << EOL;
// TODO:	Verify that the input parameters are correct
//			If not, return STATUS_INVALID_PARAMETER

// TODO:	Handle the the XPDRIVER_IOCTL_801 request, or 
//			defer the processing of the IRP (i.e. by queuing) and set
//			status to STATUS_PENDING.

// TODO:	Assuming that the request was handled here. Set I.Information
//			to indicate how much data to copy back to the user.
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONES_setStartUpPowerPercent_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - dStartUpPowerPercent.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_setStartUpPowerPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONES_setStartUpPowerPercent_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD percent = *((DWORD*)buff);
//		InterCommTransferClass_InitMap(&(g_dbContainer.CommTransferClass));
		TempZones_setStartUpPowerPercent(&(g_dbContainer.tempZonesDb), percent);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb.setStartUpPowerPercent(" <<
			(LONG)percent << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONES_setDelayStartPeriod_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - delayStartPeriod10ths.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_setDelayStartPeriod_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONES_setDelayStartPeriod_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT period = *((UINT*)buff);
		
		TempZones_setDelayStartPeriod(&(g_dbContainer.tempZonesDb), period);

#ifndef _BLOCK_TRACE
		t << "tempZonesDb.setDelayStartPeriod(" <<
			(LONG)period << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  TEMPZONES_setMinRiseDegreeCounts_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - minimumRiseDegrees.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_setMinRiseDegreeCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONES_setMinRiseDegreeCounts_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD rise = *((DWORD *)buff);

		TempZones_setMinRiseDegreeCounts(&(g_dbContainer.tempZonesDb), rise);
		
#ifndef _BLOCK_TRACE
		t << "tempZonesDb.setMinRiseDegreeCounts(" <<
			(LONG)rise << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}



////////////////////////////////////////////////////////////////////////
//  TEMPZONES_setRiseRatePeriod_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - heaterRiseRatePeriod10ths.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_setRiseRatePeriod_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONES_setRiseRatePeriod_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD rise = *((DWORD *)buff);

		TempZones_setRiseRatePeriod(&(g_dbContainer.tempZonesDb), rise);

#ifndef _BLOCK_TRACE
		t << "tempZonesDb.setRiseRatePeriod(" <<
			(LONG)rise << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  TEMPZONES_initializePowerUpSequencing_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_initializePowerUpSequencing_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	TempZones_initializePowerUpSequencing(&(g_dbContainer.tempZonesDb));
	I->m_information = 0;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_START_HELLER_DRIVER_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_START_HELLER_DRIVER_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	
	Timer_timerOn(&(g_dbContainer.elapseTimer));
	Scheduler_reset(&(pXp->m_Scheduler));

	AlarmQueue_setProcessLoopStarted(&(g_dbContainer.alarmQueueDb), FALSE);
	Scheduler_start(&(pXp->m_Scheduler));
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_STOP_HELLER_DRIVER_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_STOP_HELLER_DRIVER_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	Timer_timerOn(&(g_dbContainer.elapseTimer));
	Scheduler_stop(&(pXp->m_Scheduler));
	deactivateIO((IODOUT*)&(g_dbContainer.digitalOutDb), (IOANALOGOUT*)&(g_dbContainer.analogOutDb));

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_GET_TICK_FREQUENCY_HANDLER

 
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_GET_TICK_FREQUENCY_HANDLER(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	I->m_information = sizeof(ULONG);

	return status;
}
////////////////////////////////////////////////////////////////////////
//  FLUXFILTER_setElapsedTime10ths_Handler
//
//	Routine Description:
//		Sets setElapsedTime10ths for the FluxFilter
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - time.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXFILTER_setElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering FLUXFILTER_setElapsedTime10ths_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);

		FluxFilter_setElapsedTime10ths(&(g_dbContainer.fluxFilter), time);
#ifndef _BLOCK_TRACE
		t << "fluxFilter.setElapsedTime10ths(" << (LONG)time << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  CHellerCommCtrl::FLUXCONDENSOR_recipePreStart_Handler
			
			
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXCONDENSOR_recipePreStart_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	FluxHeater* ptrFlux = NULL;
	int i = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		BOOL bAutoclean = *((BOOL *)buff);
		FluxCondensor_recipePreStart(&(g_dbContainer.fluxCondensor), bAutoclean);

		for( i = 0; i < POSSIBLE_FLUXHEATERS; i++)
		{
			ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, i);
			FluxHeater_startSequencingRequiresTimer(ptrFlux,bAutoclean);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
/////////////////////////////////////////////////////////////////////////////////////
//NTSTATUS FLUXCONDENSOR_gen9Option_Handler(KIrp* I)
//
//
//We use different timers for Gen 9, and the behavior of outputs is slightly different
//When compared to Gen 5.1 recipe mode
//
//////////////////////////////////////////////////////////////////////////////////////
NTSTATUS FLUXCONDENSOR_gen9Option_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	BOOL bGen9;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		bGen9 = *((BOOL *)buff);
		FluxCondensor_gen9Option(&(g_dbContainer.fluxCondensor), bGen9);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/////////////////////////////////////////////////////////////////////////////////////
//NTSTATUS FLUXCONDENSOR_genPhase1Time_Handler(KIrp* I)
//
//
//Phase 1 time, output 24 & 25 off, oven in ok state
//
//////////////////////////////////////////////////////////////////////////////////////
NTSTATUS FLUXCONDENSOR_genPhase1Time_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);
	int iPhase1Time = 0;


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		iPhase1Time = *((int *)buff);
		FluxCondensor_setPhase1Time(&(g_dbContainer.fluxCondensor), iPhase1Time);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS FLUXCONDENSOR_genPhase2Time_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);
	int iPhase2Time = 0;


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		iPhase2Time = *((int *)buff);
		FluxCondensor_setPhase2Time(&(g_dbContainer.fluxCondensor), iPhase2Time);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  LUBE_setElapsedTime10ths_Handler
//
//	Routine Description:
//		Sets setElapsedTime10ths for the Lube
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index: specifies lube 1 or 2
//			DWORD - time.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LUBE_setElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering LUBE_setElapsedTime10ths_Handler, " << I << EOL;
#endif
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD time = *((DWORD *)(buff + sizeof(UINT)));
		
		switch(index)
		{
		case 1:
			Lube_setElapsedTime10ths(&(g_dbContainer.lube1), time);
#ifndef _BLOCK_TRACE
			t << "lube1.setElapsedTime10ths(" << (LONG)time << ")" << EOL;
#endif
			break;
		case 2:
			Lube_setElapsedTime10ths(&(g_dbContainer.lube2), time);
#ifndef _BLOCK_TRACE
			t << "lube2.setElapsedTime10ths(" << (LONG)time << ")" << EOL;
#endif
			break;
#ifndef _BLOCK_TRACE
		default:
			t << "Invalid Index!" << EOL;
#endif
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSER_setElapsedTime10ths_Handler
//
//	Routine Description:
//		Sets setElapsedTime10ths for the fluxCondenser
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - time.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering FLUXCONDENSER_setElapsedTime10ths_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);

		FluxCondensor_setElapsedTime10ths(&(g_dbContainer.fluxCondensor), time);
#ifndef _BLOCK_TRACE
		t << "fluxCondensor.setElapsedTime10ths(" << (LONG)time << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_resetAlarms_Handler
//
//	Routine Description:
//		Resets the alarmsqueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_resetAlarms_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT index;

	AlarmQueue_resetAlarms(&(g_dbContainer.alarmQueueDb));
	for(index=0; index < MaxBelts; index++)
	{
		Belt_clearSelfAck(&(g_dbContainer.belt[index]));
	}
	

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RECIPETRIGGER_IncrementInstance_Handler
			
			Increments the connection counter for the recipetrigger

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RECIPETRIGGER_IncrementInstance_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	recipeTrigger_IncrementInstance(&(g_dbContainer.recipetrigger));
	I->m_information = 0;
	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getNumberComms_Handler
//
//	Routine Description:
//		returns m_numberComms from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			UINT  - m_numberComms
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getNumberComms_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getNumberComms_Handler, " << I << EOL;
#endif

	*((UINT *)buff) = g_dbContainer.recipetrigger.m_numberComms;

	I->m_information = sizeof(UINT);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_DecrementInstance_Handler
//
//	Routine Description:
//		Decrements the connection counter for the recipetrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_DecrementInstance_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	recipeTrigger_DecrementInstance(&(g_dbContainer.recipetrigger));

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_DeActivateZones_Handler
//
//	Routine Description:
//		Deactivates the fluxHeater zones.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_DeActivateZones_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	FluxHeater* ptrFlux;
	UINT buffSize = sizeof(UINT); 
	UINT nIndex;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		nIndex = *((UINT*)buff);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_DeActivateZones(ptrFlux);
	}
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_setRailStateToPresetForJobLoad_Handler
//
//	Routine Description:
//		see name.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_setRailStateToPresetForJobLoad_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	Rails_setRailStateToPresetForJobLoad(&(g_dbContainer.railsDb));
	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_initializePowerUpSequencing_Handler
//
//	Routine Description:
//		Inits power up sequence for the flux heaters
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_initializePowerUpSequencing_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 
	UINT nIndex;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		nIndex = *((UINT*)buff);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_initializePowerUpSequencing(ptrFlux);
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXCONDENSOR_recipeStarted_Handler
			
			sets autoclean variables

 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXCONDENSOR_recipeStarted_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	FluxHeater* ptrFlux = NULL;
	char* buff = NULL;
	int i = 0;
	UINT autoClean = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		autoClean = *((UINT*)buff);
		if( (g_dbContainer.ovenDb.modelNo == e1913_OVENMODELS) || (g_dbContainer.ovenDb.modelNo == e1914_OVENMODELS))
		{
			for( i = FLUX0; i < FLUX2; i++)
			{
				ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, i);
				if(ptrFlux != NULL)
				{
					FluxHeater_startSequencingRequiresTimer(ptrFlux, 0);
				}
			}
			for( i = FLUX2; i < MAX_FLUXHEATERS; i++)
			{
				ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, i);
				if(ptrFlux != NULL)
				{
					FluxHeater_startSequencingRequiresTimer(ptrFlux, autoClean);
				}
			}
		}
		else
		{
			for( i = FLUX0; i <= FLUX2; i++)
			{
				ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, i);
				if(ptrFlux != NULL)
				{
					FluxHeater_startSequencingRequiresTimer(ptrFlux, autoClean);
				}
			}
		}	
		g_dbContainer.fluxCondensor.m_uintAutoClean = autoClean;
		g_dbContainer.heatZoneBlowers.m_uintAutoClean = autoClean;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONES_enableDrawWarning_Handler
//
//	Routine Description:
//		Enables draw warning for all tempzone(s)
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_enableDrawWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONES_enableDrawWarning_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL*)buff);


		TempZones_enableDrawWarning(&(g_dbContainer.tempZonesDb), bEnable);
#ifndef _BLOCK_TRACE
		t << "tempZonesDb.enableDrawWarning(" <<
			(LONG)bEnable << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setFireRecipeNotification_Handler
//
//	Routine Description:
//		Sets bFireRecipeNotification for the recipeTrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setFireRecipeNotification_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setFireRecipeNotification_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL*)buff);
		
		g_dbContainer.recipetrigger.bFireRecipeNotification = bEnable;
#ifndef _BLOCK_TRACE
		t << "recipetrigger.bFireRecipeNotification = " <<
			(LONG)bEnable << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getNotify_Handler
//
//	Routine Description:
//		returns bNotify from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - bNotify
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getNotify_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getNotify_Handler, " << I << EOL;
#endif

	*((BOOL *)buff) = g_dbContainer.recipetrigger.bNotify;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getControlComm_Handler
//
//	Routine Description:
//		returns m_ControlComm from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			UINT  - m_ControComm
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getControlComm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getControlComm_Handler, " << I << EOL;
#endif

	*((UINT *)buff) = g_dbContainer.recipetrigger.m_ControlComm;

	I->m_information = sizeof(UINT);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setNotify_Handler
//
//	Routine Description:
//		Sets bNotify for the recipeTrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bNotify.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setNotify_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setNotify_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bNotify = *((BOOL*)buff);
		
		g_dbContainer.recipetrigger.bNotify = bNotify;
#ifndef _BLOCK_TRACE
		t << "recipetrigger.bNotify = " <<
			(LONG)bNotify << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getFireRecipeNotification_Handler
//
//	Routine Description:
//		returns bFireRecipeNotification from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - bFireRecipeNotification
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getFireRecipeNotification_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getFireRecipeNotification_Handler, " << I << EOL;
#endif

	*((BOOL *)buff) = g_dbContainer.recipetrigger.bFireRecipeNotification;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getbSaveRecipePath_Handler
//
//	Routine Description:
//		returns bSaveRecipePath from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - bSaveRecipePath
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getbSaveRecipePath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getbSaveRecipePath_Handler, " << I << EOL;
#endif

	*((BOOL *)buff) = g_dbContainer.recipetrigger.bSaveRecipePath;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setbSaveRecipePath_Handler
//
//	Routine Description:
//		Sets bSaveRecipePath for the recipeTrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setbSaveRecipePath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setbSaveRecipePath_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL*)buff);
		
		g_dbContainer.recipetrigger.bSaveRecipePath= bEnable;
#ifndef _BLOCK_TRACE
		t << "recipetrigger.bSaveRecipePath = " <<
			(LONG)bEnable << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getrecipeSaveTransferPath_Handler
//
//	Routine Description:
//		Returns recipeSaveTransferPath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			char string - path
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getrecipeSaveTransferPath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT stringSize, i;
	char *buff = (char *)(I->m_ioctlBuffer);
	char *retVal = recipeTrigger_getRecipeSaveTransferPath(&(g_dbContainer.recipetrigger));
	stringSize = strlen(retVal);


	if(stringSize > MAX_RECIPE_NAME_LENGTH -1)
	{
		stringSize = MAX_RECIPE_NAME_LENGTH -1;
	}

	for(i = 0; i<stringSize; i++)
	{
		buff[i]=retVal[i];
	}
	buff[stringSize +1] = '\0';

	I->m_information = stringSize + 1;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getactionControl_Handler
//
//	Routine Description:
//		returns actionControl from recipetrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - actionControl
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getactionControl_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_getactionControl_Handler, " << I << EOL;
#endif

	*((BOOL *)buff) = g_dbContainer.recipetrigger.m_actionControl;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setactionControl_Handler
//
//	Routine Description:
//		Sets actionControl for the recipeTrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setactionControl_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setactionControl_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL*)buff);
		
		g_dbContainer.recipetrigger.m_actionControl= bEnable;
#ifndef _BLOCK_TRACE
		t << "recipetrigger.m_actionControl = " <<
			(LONG)bEnable << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getrecipeTransferPath_Handler
//
//	Routine Description:
//		Returns recipeTransferPath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			char string - path
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getrecipeTransferPath_Handler(KIrp* I)
{
                                                              
   NTSTATUS status = STATUS_SUCCESS;
   UINT stringSize, i;
                                                                                                                                                                      
   char *buff = (char *)I->m_ioctlBuffer;
   char *retVal = recipeTrigger_getRecipeSavePath(&(g_dbContainer.recipetrigger));
   stringSize = strlen(retVal);
 
                                                                                       
  	if(stringSize > MAX_RECIPE_NAME_LENGTH - 1)
  	{
		stringSize = MAX_RECIPE_NAME_LENGTH-1;
  	}
  	for(i = 0; i<stringSize; i++)
  	{
		buff[i]=retVal[i];
	}
                                                                                                   
	I->m_information = stringSize + 1;
	return status;                                                       
                                                                          
                                                                                       
                                                                   
                                                                             
                                         
                                                                                                
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_ActivateZones_Handler
//
//	Routine Description:
//		Deactivates the fluxHeater zones.
//
//	Parameters:
//		I - IRP containing IOCTL request
//		short - zone
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_ActivateZones_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;
	UINT buffSize = sizeof(short); 
	FluxHeater* ptrFlux = NULL;
	short nZoneGroup = 0;
	int i = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		nZoneGroup = *((short *)buff);	
		for( i = 0; i < POSSIBLE_FLUXHEATERS; i++)
		{
			ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, i);
			FluxHeater_ActivateZones(ptrFlux, nZoneGroup, TRUE);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setNotifyBoard_Handler

			Sets notifyBoard for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					int - nValue
			
				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setNotifyBoard_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;
	int nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(int); 
	buff = NULL;
	nIndex = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);
			nValue = *((int *)(buff+sizeof(UINT)));

			switch(nIndex)
			{
				case 0:
					g_dbContainer.boardQ0_NoLP.notifyBoard = nValue;
					g_dbContainer.boardQ0.notifyBoard = nValue;
					break;
				case 1:
					g_dbContainer.boardQ1_NoLP.notifyBoard = nValue;
					g_dbContainer.boardQ1.notifyBoard = nValue;
					break;
				case 2:
					g_dbContainer.boardQ2_NoLP.notifyBoard = nValue;
					g_dbContainer.boardQ2.notifyBoard = nValue;
					break;
				case 3:
					g_dbContainer.boardQ3_NoLP.notifyBoard = nValue;
					g_dbContainer.boardQ3.notifyBoard = nValue;
					break;
				default:
					break;
			}
		
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getNotifyBoard_Handler

			returns the notifyBoard from the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

			Output buffer contains:
					int  - nValue

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getNotifyBoard_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	UINT buffSize;
	UINT nIndex;

	status = STATUS_SUCCESS;
	buff = NULL;
	buffSize = sizeof(UINT); 
	nIndex = 0;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nIndex = *((UINT*)buff);	

			switch(nIndex)
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ0_NoLP.notifyBoard;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ0.notifyBoard;
					}
					break;
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ1_NoLP.notifyBoard;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ1.notifyBoard;
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ2_NoLP.notifyBoard;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ2.notifyBoard;
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ3_NoLP.notifyBoard;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ3.notifyBoard;
					}
					break;
				default:
					break;
			}

			I->m_information = sizeof(int);
		}
		else
		{
			I->m_information = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Sets notifyBoardOut for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					int - nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setNotifyBoardOut_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;
	signed int nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(int); 
	buff = NULL;
	nIndex = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);
			nValue = *((int *)(buff+sizeof(UINT)));

			switch(nIndex)
			{
				case 0:
					g_dbContainer.boardQ0_NoLP.notifyBoardOut = nValue;
					g_dbContainer.boardQ0.notifyBoardOut = nValue;
					break;
				case 1:
					g_dbContainer.boardQ1_NoLP.notifyBoardOut = nValue;
					g_dbContainer.boardQ1.notifyBoardOut = nValue;
					break;
				case 2:
					g_dbContainer.boardQ2_NoLP.notifyBoardOut = nValue;
					g_dbContainer.boardQ2.notifyBoardOut = nValue;
					break;
				case 3:
					g_dbContainer.boardQ3_NoLP.notifyBoardOut = nValue;
					g_dbContainer.boardQ3.notifyBoardOut = nValue;
					break;
				default:
					break;
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getNotifyBoardOut_Handler

			returns the notifyBoardOut from the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:
					int  - nValue

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getNotifyBoardOut_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	UINT buffSize;
	UINT nIndex;

	status = STATUS_SUCCESS;
	buff = NULL;
	buffSize = 0; 
	nIndex = 0;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;
		buffSize = sizeof(UINT); 

		if(I->m_inputBufferSize >= buffSize)
		{
			nIndex = *((UINT*)buff);

			switch(nIndex)
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ0_NoLP.notifyBoardOut;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ0.notifyBoardOut;
					}
					break;
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ1_NoLP.notifyBoardOut;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ1.notifyBoardOut;
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ2_NoLP.notifyBoardOut;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ2.notifyBoardOut;
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((int *)buff) = g_dbContainer.boardQ3_NoLP.notifyBoardOut;
					}
					else
					{
						*((int *)buff) = g_dbContainer.boardQ3.notifyBoardOut;
					}
					break;
				default:
					break;
			}

			I->m_information = sizeof(int);
		}
		else
		{
			I->m_information = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LUBE_getElapsedTime10ths_Handler
//
//	Routine Description:
//		Returns getElapsedTime10ths for the referenced Lube
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index: specifies lube 1 or 2
//
//		Output Buffer:
//			DWORD - time.
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LUBE_getElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		
		switch(index)
		{
		case 1:
			*((DWORD *)buff) = Lube_getElapsedTime10ths(&(g_dbContainer.lube1));

			break;
		case 2:
			*((DWORD *)buff) = Lube_getElapsedTime10ths(&(g_dbContainer.lube2));

			break;

		}
		I->m_information = sizeof(DWORD);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
		I->m_information = 0;
	}


	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXFILTER_getElapsedTime10ths_Handler
//
//	Routine Description:
//		returns elapsedTimeLastClean10ths from the fluxFilter.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			DWORD  - elapsedTimeLastClean10ths
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXFILTER_getElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering FLUXFILTER_getElapsedTime10ths_Handler, " << I << EOL;
#endif

	*((DWORD *)buff) = FluxFilter_getElapsedTime10ths(&(g_dbContainer.fluxFilter));

	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_getElapsedTime10ths_Handler
//
//	Routine Description:
//		returns elapsedTimeLastClean10ths from the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			DWORD  - elapsedTimeLastClean10ths
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_getElapsedTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

	*((DWORD *)buff) = FluxCondensor_getElapsedTime10ths(&(g_dbContainer.fluxCondensor));

	I->m_information = sizeof(DWORD);

	return status;
}


////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setMinRiseDegreeCounts_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - minimumRiseDegrees.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setMinRiseDegreeCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;
	UINT nIndex;
	DWORD rise;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		rise = *((DWORD *)buff);
		nIndex = *((UINT *)(buff+sizeof(DWORD)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setMinRiseDegreeCounts(ptrFlux, rise);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setRiseRatePeriod_Handler
//
//	Routine Description:
//		Sets Pause for the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - heaterRiseRatePeriod10ths.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setRiseRatePeriod_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD rise = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setRiseRatePeriod(ptrFlux, rise);	
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OXYGEN_setEnabled_Handler
//
//	Routine Description:
//		Sets setEnabled for the Oxygen
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OXYGEN_setEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering OXYGEN_setEnabled_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		Oxygen_setEnabled(&(g_dbContainer.oxygen), enable);
#ifndef _BLOCK_TRACE
		t << "oxygen.setEnabled(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS PURGE_setActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		Purge_setActive(&(g_dbContainer.purge), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS PURGE_setPurgeTime10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);

		Purge_setPurgeTime10ths(&(g_dbContainer.purge), time);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  PURGE_setDigitialOutput_Handler
//
//	Routine Description:
//		sets the output to be lite when the purge is on
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: WT
NTSTATUS PURGE_setDigitialOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iOutput = *((int *)buff);

		Purge_setDigitialOutput(&(g_dbContainer.purge), iOutput);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;

}
////////////////////////////////////////////////////////////////////////
//  PURGE_forceOn_Handler
//
//	Routine Description:
//		Enables the purge output, overrules other classes call to output
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: WT
NTSTATUS PURGE_forceOn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	Purge_forceOn(&(g_dbContainer.purge));

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  PURGE_setRecipeOutput_Handler
//
//	Routine Description:
//		Sets the output to be enabled during an autoclean recipe run
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: WT
NTSTATUS PURGE_setRecipeOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iOutput = *((int *)buff);

		Purge_setRecipeOutput(&(g_dbContainer.purge), iOutput);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;

}


NTSTATUS PURGE_setMessageDelay_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	UINT iIndex = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);
		iIndex = *((UINT *)(buff+sizeof(DWORD)));
		Purge_setMessageDelay(&(g_dbContainer.purge), time, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}

NTSTATUS PURGE_setMessageType_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);
	UINT iIndex = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iType = *((int *)buff);
      iIndex = *((UINT *)(buff+sizeof(int)));
 		Purge_setMessageType(&(g_dbContainer.purge), iType, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS PURGE_setInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);
	UINT iIndex = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iInput = *((int *)buff);
		iIndex = *((UINT*)(buff+sizeof(int)));
		Purge_setInput(&(g_dbContainer.purge), iInput, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return status;	
}
NTSTATUS PURGE_setOutput_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);
	UINT iIndex = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iOutput = *((int *)buff);
		iIndex = *((UINT*)( buff+sizeof(int)));
		Purge_setOutput(&(g_dbContainer.purge), iOutput, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS PURGE_setLightTowerAction_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int) + sizeof(UINT);
	UINT iIndex = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iAction = *((int *)buff);
		iIndex = *((UINT*)(buff+sizeof(int)));
		Purge_setLightTowerAction(&(g_dbContainer.purge), iAction, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS PURGE_enableCustomAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	UINT iIndex = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		iIndex = *((UINT*)(buff+sizeof(BOOL)));
		Purge_enableCustomAlarm(&(g_dbContainer.purge), enable, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return status;
}

NTSTATUS PURGE_setLineState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	UINT iIndex = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bHigh = *((BOOL *)buff);
		iIndex = *((UINT*)(buff+sizeof(BOOL)));
		Purge_SetLineState(&(g_dbContainer.purge), bHigh, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS PURGE_setAudibleWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	UINT iIndex = 0;	

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudible = *((BOOL *)buff);
		iIndex = *((UINT *)(buff+sizeof(BOOL)));
		Purge_setAudibleWarning(&(g_dbContainer.purge), bAudible, iIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  LUBE_optionEnable_Handler
//
//	Routine Description:
//		Sets optionEnabled for the referenced Lube
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - enable.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LUBE_optionEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		switch(nIndex)
		{
		case 1:
			Lube_optionEnable(&(g_dbContainer.lube1), enable);
			break;
		case 2:
			Lube_optionEnable(&(g_dbContainer.lube2), enable);
			break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LUBE_setLubeIntervalTime_Handler
//
//	Routine Description:
//		Sets optionEnabled for the referenced Lube
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			DWORD - lubeIntervalInMinutes.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LUBE_setLubeIntervalTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);
		DWORD nInterval = *((DWORD *)(buff + sizeof(UINT)));

		switch(nIndex)
		{
		case 1:
			Lube_setLubeIntervalTime(&(g_dbContainer.lube1), nInterval);
			break;
		case 2:
			Lube_setLubeIntervalTime(&(g_dbContainer.lube2), nInterval);
			break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LUBE_setLubeDurationTime_Handler
//
//	Routine Description:
//		Sets optionEnabled for the referenced Lube
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			DWORD - lubeDurationTime10thsOfSec.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LUBE_setLubeDurationTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);
		DWORD nInterval = *((DWORD *)(buff + sizeof(UINT)));

		switch(nIndex)
		{
		case 1:
			Lube_setLubeDurationTime(&(g_dbContainer.lube1), nInterval);
			break;
		case 2:
			Lube_setLubeDurationTime(&(g_dbContainer.lube2), nInterval);
			break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXFILTER_fluxFilterEnable_Handler
//
//	Routine Description:
//		Sets setEnabled for the fluxFilter
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - fluxFilterEnabled.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXFILTER_fluxFilterEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		FluxFilter_fluxFilterEnable(&(g_dbContainer.fluxFilter), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXFILTER_setFluxFilterCleaningInterval10ths_Handler
//
//	Routine Description:
//		Sets intervalBetweenCleaning10ths for the fluxFilter.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - intervalBetweenCleaning10ths.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXFILTER_setFluxFilterCleaningInterval10ths_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nInterval = *((DWORD *)buff);

		FluxFilter_setFluxFilterCleaningInterval10ths(&(g_dbContainer.fluxFilter), nInterval);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  GLOBALBLOWER_setEnableState_Handler
//
//	Routine Description:
//		Sets setEnableState for the GlobalBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enabled.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS GLOBALBLOWER_setEnableState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		GlobalBlower_setEnableState(&(g_dbContainer.globalBlower), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGFAN_setEnableState_Handler
//
//	Routine Description:
//		Sets setEnableState for the AnalogFan.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enabled.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGFAN_setEnableState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering ANALOGFAN_setEnableState_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		AnalogFan_setEnableState(&(g_dbContainer.analogFan), enable);
#ifndef _BLOCK_TRACE
		t << "analogFan.setEnableState(" << 
			(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_arrayInitialization_Handler
//
//	Routine Description:
//		Initializes the rail arrays.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_arrayInitialization_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_arrayInitialization_Handler, " << I << EOL;
#endif
	
	Rails_arrayInitialization(&(g_dbContainer.railsDb));
#ifndef _BLOCK_TRACE
	t << "railsDb.arrayInitialization()" << EOL;
#endif

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_setHomeDirection_Handler
//
//	Routine Description:
//		Sets the homeDirection for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//			UINT - direction (casted to HomeDirection)
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_setHomeDirection_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT nDir = *((UINT *)(buff+sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		Rail_setHomeDirection(pRail, (enum HomeDirection) nDir);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_setHomeDistanceCounts_Handler
//
//	Routine Description:
//		Sets the homeDirection for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//			DWORD - counts
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_setHomeDistanceCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD nCounts = *((DWORD *)(buff+sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		Rail_setHomeDistanceCounts(pRail, nCounts);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RAILS_getHomeDistanceCounts_Handler
			
			returns home distance encoder pulses for home in rails

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RAILS_getHomeDistanceCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(DWORD);
	DWORD retVal = 0;
	char* buff = NULL;
	UINT index = 0;
	Rail* pRail = NULL;
	BOOL bHomeIn = FALSE;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);

		pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		bHomeIn = Rail_isHomeInType(pRail);
		if(bHomeIn)//home out position counts are not adjusted
		{
			retVal = pRail->homeOffsetCounts;
		}
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
		buffSize = 0;
	}

	return status;
}
////////////////////////////////////////////////////////////////////////
//  RAIL_setControlType_Handler
//
//	Routine Description:
//		Sets the ControlType for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//			UINT - controlType (casted to ControlType)
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_setControlType_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(UINT);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		UINT nType = *((UINT *)(buff+sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		Rail_setControlType(pRail, (enum ControlType) nType);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setBoardDeadBandDistance_Handler

			Sets boardDeadbandCounts for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					DWORD - nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setBoardDeadBandDistance_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(DWORD); 
	buff = NULL;
	nIndex = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);
			nValue = *((DWORD *)(buff+sizeof(UINT)));

			switch(nIndex)
			{
				case 0:
					newBoardQueue_setBoardDeadBandDistance_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
					newBoardQueue_setBoardDeadBandDistance(&(g_dbContainer.boardQ0), nValue);
					break;
				case 1:
					newBoardQueue_setBoardDeadBandDistance_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
					newBoardQueue_setBoardDeadBandDistance(&(g_dbContainer.boardQ1), nValue);
					break;
				case 2:
					newBoardQueue_setBoardDeadBandDistance_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
					newBoardQueue_setBoardDeadBandDistance(&(g_dbContainer.boardQ2), nValue);
					break;
				case 3:
					newBoardQueue_setBoardDeadBandDistance_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);
					newBoardQueue_setBoardDeadBandDistance(&(g_dbContainer.boardQ3), nValue);
					break;
				default:
					break;
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

////////////////////////////////////////////////////////////////////////
//  SMEMA_setSMEMAdeadBandCounts_Handler
//
//	Routine Description:
//		Sets SMEMADeadBandCounts for the referenced SMEMA.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex
//			DWORD - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS SMEMA_setSMEMAdeadBandCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		DWORD nValue = *((DWORD *)(buff+sizeof(UINT)));

		switch(nIndex)
		{
		case 1:
			SMEMA_setDeadBandCounts(&(g_dbContainer.smema1), nValue);
			break;
		case 2:
			SMEMA_setDeadBandCounts(&(g_dbContainer.smema2), nValue);
			break;
		case 3:
			SMEMA_setDeadBandCounts(&(g_dbContainer.smema3), nValue);
			break;
		case 4:
			SMEMA_setDeadBandCounts(&(g_dbContainer.smema4), nValue);
			break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BOARDQUEUE_setSensorDistance_Handler
//
//	Routine Description:
//		Sets sensorDistance for the referenced BoardQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex
//			DWORD - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setSensorDistance_Handler

			Sets sensorDistance for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					DWORD - nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setSensorDistance_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(DWORD); 
	buff = NULL;
	nIndex = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char*)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);
			nValue = *((DWORD*)(buff+sizeof(UINT)));

			switch(nIndex)
			{
				case 0:
					newBoardQueue_setSensorDistance_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
					newBoardQueue_setSensorDistance(&(g_dbContainer.boardQ0), nValue);
					break;
				case 1:
					newBoardQueue_setSensorDistance_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
					newBoardQueue_setSensorDistance(&(g_dbContainer.boardQ1), nValue);
					break;
				case 2:
					newBoardQueue_setSensorDistance_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
					newBoardQueue_setSensorDistance(&(g_dbContainer.boardQ2), nValue);
					break;
				case 3:
					newBoardQueue_setSensorDistance_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);
					newBoardQueue_setSensorDistance(&(g_dbContainer.boardQ3), nValue);
					break;
				default:
					break;
			}

		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_setEnable_Handler
//
//	Routine Description:
//		Enables the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//			BOOL - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_setEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		BOOL nValue = *((BOOL *)(buff+sizeof(UINT)));

		HeatZoneBlowers_setEnable(&(g_dbContainer.heatZoneBlowers), nIndex, nValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_enableOption_Handler
//
//	Routine Description:
//		Sets optionEnabled for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_enableOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		FluxCondensor_enableOption(&(g_dbContainer.fluxCondensor), enable);
		Purge_isFluxCondensationEnabled(&(g_dbContainer.purge), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_recipeOption_Handler
//
//	Routine Description:
//		Sets recipeOptionEnabled for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_recipeOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering FLUXCONDENSOR_recipeOption_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);

		FluxCondensor_recipeOption(&(g_dbContainer.fluxCondensor), enable);
		Purge_isFluxCondensationRecipeEnabled(&(g_dbContainer.purge), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setFourthLaneEnabled_Handler
//
//	Routine Description:
//		Sets setFourthLaneEnabled for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - laneEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setFourthLaneEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		Oven_setFourthLaneEnabled(&(g_dbContainer.ovenDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_setIntervalTime_Handler
//
//	Routine Description:
//		Sets intervalTime for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - intervalTime
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setIntervalTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nTime = *((DWORD *)buff);

		FluxCondensor_setIntervalTime(&(g_dbContainer.fluxCondensor), nTime);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_setDurationTime_Handler
//
//	Routine Description:
//		Sets durationTime for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - durationTime
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setDurationTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nTime = *((DWORD *)buff);

		FluxCondensor_setDurationTime(&(g_dbContainer.fluxCondensor), nTime);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_setLowSetting_Handler
//
//	Routine Description:
//		Sets lowSetting the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex (1 - 3)
//			UINT - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_setLowSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		UINT nValue = *((UINT *)(buff+sizeof(UINT)));

		HeatZoneBlowers_setLowSetting(&(g_dbContainer.heatZoneBlowers), nIndex, nValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_setMediumSetting_Handler
//
//	Routine Description:
//		Sets mediumSetting the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex (1 - 3)
//			UINT - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_setMediumSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		UINT nValue = *((UINT *)(buff+sizeof(UINT)));

		HeatZoneBlowers_setMediumSetting(&(g_dbContainer.heatZoneBlowers), nIndex, nValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_setHighSetting_Handler
//
//	Routine Description:
//		Sets highSetting the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex (1 - 3)
//			UINT - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_setHighSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		UINT nValue = *((UINT *)(buff+sizeof(UINT)));

		HeatZoneBlowers_setHighSetting(&(g_dbContainer.heatZoneBlowers), nIndex, nValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  SMEMA_setSMEMAtype_Handler
//
//	Routine Description:
//		Sets SMEMAtype for the referenced SMEMA.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex
//			SMEMA_Interface - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS SMEMA_setSMEMAtype_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
//		DWORD dwrdValue = *((DWORD*)(buff+sizeof(UINT)));
		enum SMEMA_Interface nValue = *((enum SMEMA_Interface *)(buff+sizeof(UINT)));
		switch(nIndex)
		{
		case 1:
			SMEMA_setType(&(g_dbContainer.smema1), nValue);
			break;
		case 2:
			SMEMA_setType(&(g_dbContainer.smema2), nValue);
			break;
		case 3:
			SMEMA_setType(&(g_dbContainer.smema3), nValue);
			break;
		case 4:
			SMEMA_setType(&(g_dbContainer.smema4), nValue);
			break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  CBS_setFeedbackTypeFlag_Handler
//
//	Routine Description:
//		Sets referenced CBSActiveFeedback for CBS.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - nValue
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS CBS_setFeedbackTypeFlag_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		BOOL nValue = *((BOOL *)(buff+sizeof(UINT)));

		CBS_setFeedbackType(&(g_dbContainer.cbs), nValue, nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_setT3Timer_Handler
//
//	Routine Description:
//		Sets T3Timer for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - T3Timer
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setT3Timer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nTime = *((DWORD *)buff);

		FluxCondensor_setT3Timer(&(g_dbContainer.fluxCondensor), nTime);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setExhaustWarningEnable_Handler
//
//	Routine Description:
//		Sets ExhaustWarningEnable for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setExhaustWarningEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);
	
		Oven_setExhaustWarningEnable(&(g_dbContainer.ovenDb), bEnable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return STATUS_SUCCESS;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setExhaustAlarmEnable_Handler
//
//	Routine Description:
//		Sets ExhaustAlarmEnable for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setExhaustAlarmEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);



	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);	
		Oven_setExhaustAlarmEnable(&(g_dbContainer.ovenDb), bEnable);


	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return STATUS_SUCCESS;

}

////////////////////////////////////////////////////////////////////////
//  TEMPZONES_setTCWarnPercentage_Handler
//
//	Routine Description:
//		Sets TCWarnPercentage for all tempzone(s)
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nPercent.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONES_setTCWarnPercentage_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nPercent = *((UINT *)buff);
		
		TempZones_setTCWarnPercentage(&(g_dbContainer.tempZonesDb), nPercent);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_disableAutoAcknowledge_Handler
//
//	Routine Description:
//		Disables AutoAcknowledge for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bDisable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_disableAutoAcknowledge_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bDisable = *((BOOL*)buff);
		Oven_disableAutoAcknowledge(&(g_dbContainer.ovenDb), bDisable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  OVEN_disableDevAlarmInStartup_Handler
//
//	Routine Description:
//		Disables AutoAcknowledge for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bDisable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Tushar Patel

NTSTATUS OVEN_disableDevAlarmInStartup_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bDisable = *((BOOL*)buff);
		Oven_disableDevAlarmInStartup(&(g_dbContainer.ovenDb), bDisable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setStartupCompletePlusDelay_Handler
//
//	Routine Description:
//		sets additional time delay for Startup Complete 
//
//	Parameters:
//		I - IRP containing IOCTL request
//		int - iTimeInSec
//
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Tushar Patel
NTSTATUS OVEN_setStartupCompletePlusDelay_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iTimeInSec = *((int *)buff);

		Oven_setStartupCompletePlusDelay(&(g_dbContainer.ovenDb), iTimeInSec);
	}

	return status;
}


////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_getProcVar_Handler
//
//	Routine Description:
//		Returns getProcVar for the referenced fluxHeater
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD - pv
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_getProcVar_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize =  sizeof(UINT);
	DWORD retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)(buff));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_getProcVar(ptrFlux);
	}

	char *buff = (char *)I->m_ioctlBuffer;

	*((DWORD *)buff) = retVal;
	buffSize = sizeof(DWORD);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OXYGEN_getOxygenVolts_Handler
//
//	Routine Description:
//		Returns getProcVar for the referenced fluxHeater
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			LONG - nVolts
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OXYGEN_getOxygenVolts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

	char *buff = (char *)I->m_ioctlBuffer;
	LONG retVal = Oxygen_getOxygenVolts(&(g_dbContainer.oxygen));
	*((LONG *)buff) = retVal;
	buffSize = sizeof(LONG);

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardsInOvenCount_Handler

			returns the BoardsInOvenCount from the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:
					DWORD - nValue

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardsInOvenCount_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	UINT buffSize;
	UINT nIndex;	
	UINT nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT);
	buff = NULL;
	nIndex = 0;
	nValue = 1;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nIndex = *((UINT*)buff);	

			switch(nIndex)
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), nValue);
					}
					break;
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), nValue);
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), nValue);
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), nValue);
					}
					break;
				default:
					break;
			}

			I->m_information = sizeof(DWORD);
		}
		else
		{
			I->m_information = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardsProcessed_Handler

			returns the BoardsProcessed from the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:
					DWORD - nValue

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardsProcessed_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	UINT buffSize; 
	UINT nIndex;

	status = STATUS_SUCCESS;
	buff = NULL;
	buffSize = sizeof(UINT); 
	nIndex = 0;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nIndex = *((UINT*)buff);

			switch(nIndex)
			{
				case 0:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed_NoLP(&(g_dbContainer.boardQ0_NoLP));
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed(&(g_dbContainer.boardQ0));
					}
					break;
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed_NoLP(&(g_dbContainer.boardQ1_NoLP));		
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed(&(g_dbContainer.boardQ1));		
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed_NoLP(&(g_dbContainer.boardQ2_NoLP));		
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed(&(g_dbContainer.boardQ2));		
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed_NoLP(&(g_dbContainer.boardQ3_NoLP));		
					}
					else
					{
						*((DWORD *)buff) = newBoardQueue_getBoardsProcessed(&(g_dbContainer.boardQ3));		
					}
					break;
				default:
					break;
			}

			I->m_information = sizeof(DWORD);
		}
		else
		{
			I->m_information = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GLOBALBLOWER_setOutputPercent_Handler
			
			sets the output percentage for a blower D (global blower)

 RETURNS:   NTSTATUS,STATUS_SUCCESS OR STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS GLOBALBLOWER_setOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	char* buff = NULL;
	DWORD nPercent = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		nPercent = *((DWORD *)buff);
		Fans_setOutputPercent(GLOBAL_BLOWER_INDEX, nPercent);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS GLOBALBLOWER_setOnTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nTime = *((DWORD *)buff);

		GlobalBlower_setFlushTime(&(g_dbContainer.globalBlower), nTime);
		HeatZoneBlowers_setFlushTime(&(g_dbContainer.heatZoneBlowers), nTime);
		AnalogFan_setFlushTime(&(g_dbContainer.analogFan), nTime);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGFAN_setOutputPercent_Handler
			
			sets the output percentage for a blower D (analog fan)

 RETURNS:   NTSTATUS,STATUS_SUCCESS OR STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGFAN_setOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	char* buff = NULL;
	DWORD nPercent = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		nPercent = *((DWORD *)buff);
		Fans_setOutputPercent(ANALOG_FAN_INDEX, nPercent);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  CBS_setState_Handler
//
//	Routine Description:
//		Sets referenced CBSActiveFeedback for CBS.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			CBS::CBS_State - nState - pack up as UINT
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS CBS_setState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		enum CBS_State nState = (enum CBS_State)(*((UINT *)(buff+sizeof(UINT))));

		CBS_setStates(&(g_dbContainer.cbs), nState, nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_setFalsePositionCounts_Handler
//
//	Routine Description:
//		Sets the homeDirection for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//			DWORD - counts
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_setFalsePositionCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD nCounts = *((DWORD *)(buff+sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		Rail_setFalsePositionCounts(pRail, nCounts);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_setOpFromCoolRailMovement_Handler
//
//	Routine Description:
//		Sets setConfiguration for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - m_bPreventMoveFromCooldown
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_setOpFromCoolRailMovement_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bMove = *((BOOL *)buff);

		Rails_setOpFromCoolRailMovement(&(g_dbContainer.railsDb), bMove);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_setOutputEnableFlag_Handler
//
//	Routine Description:
//		Sets setConfiguration for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nIndex
//			BOOL - bEnable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_setOutputEnableFlag_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);
		BOOL bEnable = *((BOOL *)(buff+sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), nIndex);
		Rail_setOutputEnableFlag(pRail, bEnable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAILS_queueSetPosition_Handler
//
//	Routine Description:
//		Sets setPosition for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - index into railsDb array.
//			DWORD - presetPosition
//			BOOL - bHomeIndicator
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_queueSetPosition_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = (2*sizeof(DWORD)) + sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		DWORD presetPosition = *((DWORD *)(buff + sizeof(DWORD)));
		BOOL bHomeIndicator = *((BOOL *)(buff + (2 * sizeof(DWORD))));

		Rails_queueSetPosition(&(g_dbContainer.railsDb), index, presetPosition,
											bHomeIndicator);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_clearBoardsInOven_Handler

			Clears BoardsInOven for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_clearBoardsInOven_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT); 
	buff = NULL;
	nIndex = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char*)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);

			switch(nIndex)
			{
				case 0:
					pXpDriverDevice->m_Scheduler.m_bResetTrackingLane0 = TRUE;
					newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ0_NoLP));
					newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ0));
					break;
				case 1:
					pXpDriverDevice->m_Scheduler.m_bResetTrackingLane1 = TRUE;
					newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ1_NoLP));
					newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ1));
					break;
				case 2:
					pXpDriverDevice->m_Scheduler.m_bResetTrackingLane2 = TRUE;
					newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ2_NoLP));
					newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ2));
					break;
				case 3:
					pXpDriverDevice->m_Scheduler.m_bResetTrackingLane3 = TRUE;
					newBoardQueue_clearBoardsInOven_NoLP(&(g_dbContainer.boardQ3_NoLP));
					newBoardQueue_clearBoardsInOven(&(g_dbContainer.boardQ3));
					break;
				default:
					break;
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_clearBoardsProcessed_Handler

			Clears BoardsProcessed for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_clearBoardsProcessed_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT); 
	buff = NULL;
	nIndex = 0;

	if( NULL != I )
	{

		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);

			switch(nIndex)
			{
				case 0:
					newBoardQueue_clearBoardsProcessed_NoLP(&(g_dbContainer.boardQ0_NoLP));
					newBoardQueue_clearBoardsProcessed(&(g_dbContainer.boardQ0));
					break;
				case 1:
					newBoardQueue_clearBoardsProcessed_NoLP(&(g_dbContainer.boardQ1_NoLP));
					newBoardQueue_clearBoardsProcessed(&(g_dbContainer.boardQ1));
					break;
				case 2:
					newBoardQueue_clearBoardsProcessed_NoLP(&(g_dbContainer.boardQ2_NoLP));
					newBoardQueue_clearBoardsProcessed(&(g_dbContainer.boardQ2));
					break;
				case 3:
					newBoardQueue_clearBoardsProcessed_NoLP(&(g_dbContainer.boardQ3_NoLP));
					newBoardQueue_clearBoardsProcessed(&(g_dbContainer.boardQ3));
					break;
				default:
					break;
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_setOutputPercent_Handler
			
			
 GLOBALS:	g_dbContainer
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_setOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+ sizeof(DWORD);
	char* buff = NULL;
	UINT nIndex = 0;
	DWORD nPercent = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		nIndex = *((UINT *)buff);
		nPercent = *((DWORD *)(buff+sizeof(UINT)));
		if(nIndex < MAX_HEAT_ZONE_BLOWERS)
		{
			Fans_setOutputPercent(nIndex, nPercent);
		}
		else if(nIndex <= (MAX_HEAT_ZONE_BLOWERS + MAX_MASS_CONTROLLERS))
		{
			nIndex = nIndex - MAX_HEAT_ZONE_BLOWERS;//Normalize to mass controller
			MassController_setOutputPercent(&(g_dbContainer.masscontroller), nIndex, nPercent);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  GLOBALBLOWER_getOutputPercent_Handler
//
//	Routine Description:
//		Sets setEnableState for the GlobalBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD - outputPercent.
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS GLOBALBLOWER_getOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	char *buff = (char *)I->m_ioctlBuffer;
	DWORD nPercent = GlobalBlower_getOutputPercent(&(g_dbContainer.globalBlower));

	*((DWORD *)buff) = nPercent;
	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGFAN_getOutputPercent_Handler
//
//	Routine Description:
//		Sets setEnableState for the GlobalBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD - outputPercent.
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGFAN_getOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	char *buff = (char *)I->m_ioctlBuffer;
	DWORD nPercent = AnalogFan_getOutputPercent(&(g_dbContainer.analogFan));

	*((DWORD *)buff) = nPercent;
	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  CBS_gsetState_Handler
//
//	Routine Description:
//		Gets state for CBS.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			CBS::CBS_State - nState - pack up as UINT
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS CBS_getState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	char *buff = (char *)I->m_ioctlBuffer;
	enum CBS_State nState = CBS_GetState(&(g_dbContainer.cbs));

	*((UINT *)buff) = (UINT)nState;

	I->m_information = sizeof(UINT);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  CBS_getSecondState_Handler
//
//	Routine Description:
//		Gets secondState for CBS.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			CBS::CBS_State - nState - pack up as UINT
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS CBS_getSecondState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	char *buff = (char *)I->m_ioctlBuffer;
	enum CBS_State nState = CBS_GetSecondState(&(g_dbContainer.cbs));

	*((UINT *)buff) = (UINT)nState;

	I->m_information = sizeof(UINT);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_PIDsetPb_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			DWORD - pb
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_PIDsetPb_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		DWORD pb = *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_pidSetPb(&(pTZ->pidCtrl), pb);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_PIDsetTi_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			DWORD - ti
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_PIDsetTi_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		DWORD ti = *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_pidSetTi(&(pTZ->pidCtrl), ti);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_PIDsetTd_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			DWORD - td
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_PIDsetTd_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		DWORD td = *((DWORD *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_pidSetTd(&(pTZ->pidCtrl), td);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_PIDsetAction_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			PID::Action - eAction - Cast from DWORD
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_PIDsetAction_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		enum Action eAction = (enum Action)(*((DWORD *)(buff + sizeof(UINT))));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_pidSetAction(&(pTZ->pidCtrl), eAction);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_PIDsetPIDMode_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into tempZonesDb array.
//			BOOL - PIDMode
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_PIDsetPIDMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		BOOL bMode = *((BOOL *)(buff + sizeof(UINT)));

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		PIDController_pidSetMode(&(pTZ->pidCtrl), bMode);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_getTPOoutput_Handler
//
//	Routine Description:
//		Gets getTPOoutput for the Selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD tpoOutput
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_getTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	UINT buffSize =  sizeof(UINT);
	char *buff = (char *)I->m_ioctlBuffer;
	DWORD retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		UINT nIndex = *((UINT *)(buff));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_getTPOoutput(ptrFlux);
	}

	*((DWORD *)buff) = retVal;
	
	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_getSetPoint_Handler
//
//	Routine Description:
//		Gets getSetPoint for the Selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			DWORD tpoOutput
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_getSetPoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	UINT buffSize = sizeof(UINT);
	DWORD retVal;
	char *buff;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		 buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_getSetPoint(ptrFlux);
	}
	else
	{
	status = STATUS_BUFFER_TOO_SMALL;

	}

	*((DWORD *)buff) = retVal;

	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setActive_Handler
//
//	Routine Description:
//		Sets setActive for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - active
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setActive_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL active = *((BOOL*)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		BOOL retVal;
		FluxHeater* ptrFlux;
	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setActive(ptrFlux, active);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setSetPoint_Handler
//
//	Routine Description:
//		Sets setActive for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			LONG - setpoint
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setSetPoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(LONG) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		LONG nSetpoint = *((LONG *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(LONG)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setSetPoint(ptrFlux, nSetpoint);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_PIDsetPb_Handler
//
//	Routine Description:
//		Sets setPIDPb for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - pb
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_PIDsetPb_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD pb  = *((DWORD*)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		PID_setPb(&(ptrFlux->pid), pb);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_PIDsetTi_Handler
//
//	Routine Description:
//		Sets setPIDTi for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - Ti
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_PIDsetTi_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD Ti = *((DWORD*)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		PID_setTi(&(ptrFlux->pid), Ti);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_PIDsetTd_Handler
//
//	Routine Description:
//		Sets setPIDTd for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - Td
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_PIDsetTd_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD Td = *((DWORD*)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		PID_setTd(&(ptrFlux->pid), Td);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setSequenceGroup_Handler
//
//	Routine Description:
//		Sets setActive for the referenced TempZone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - sequenceGroup
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setSequenceGroup_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	FluxHeater* ptrFlux = NULL;

	UINT buffSize = sizeof(UINT) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nGroup = *((UINT *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(UINT)));
	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setSequenceGroup(ptrFlux, nGroup);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setZoneAuto_Handler
//
//	Routine Description:
//		Sets setZoneAuto for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			ZoneTriState - state
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setZoneAuto_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(enum ZoneTriState) + sizeof(UINT);
	FluxHeater* ptrFlux;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		enum ZoneTriState state = *((enum ZoneTriState *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(enum ZoneTriState)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setZoneAuto(ptrFlux, state);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setPIDenable_Handler
//
//	Routine Description:
//		Sets setPIDenable for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - state
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setPIDenable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL state = *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setPIDenable(ptrFlux, state);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setTPOoutput_Handler
//
//	Routine Description:
//		Sets setTPOoutput for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UCHAR - cTPOoutput
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(LONG)+ sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		LONG cTPOoutput= *((LONG *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(LONG)));
			
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_set_pendTPOoutput(ptrFlux, cTPOoutput);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_PIDsetAction_Handler
//
//	Routine Description:
//		Sets setPIDenable for the referenced Temp Zone
//
//	Parameters:
//		I - IRP containing IOCTL request
//			PID::Action - eAction - Cast from DWORD
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_PIDsetAction_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		enum Action eAction = (enum Action)(*((DWORD *)buff));
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));
	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		PID_setAction(&(ptrFlux->pid), eAction);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setDeadBandHiTempOffset_Handler
//
//	Routine Description:
//		Sets setDeadBandHiTempOffset for the selected Temperature zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - offset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setDeadBandHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD offset = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));
		
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setDeadBandHiTempOffset(ptrFlux, offset);

		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_SetDeadBandLoTempOffset_Handler
//
//	Routine Description:
//		Sets setDeadBandLoTempOffset for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - offset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_SetDeadBandLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+ sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD offset = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setDeadBandLoTempOffset(ptrFlux, offset);

		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableHiProcAlarm_Handler
//
//	Routine Description:
//		Sets enableHiProcAlarm for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableHiProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL)+ sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableHiProcAlarm(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableHiDeviationAlarm_Handler
//
//	Routine Description:
//		enableHiDeviationAlarm for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableHiDeviationAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL)+ sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable= *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));
	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableHiDeviationAlarm(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableHiDeviationWarn_Handler
//
//	Routine Description:
//		enableHiDeviationWarn for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableHiDeviationWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable= *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));
	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableHiDeviationWarn(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableLoDeviationWarn_Handler
//
//	Routine Description:
//		enableLoDeviationWarn for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableLoDeviationWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable= *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableLoDeviationWarn(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableLoDeviationAlarm_Handler
//
//	Routine Description:
//		enableLoDeviationAlarm for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableLoDeviationAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable= *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableLoDeviationAlarm(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_enableLoProcAlarm_Handler
//
//	Routine Description:
//		Sets enableLoProcAlarm for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - enable
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_enableLoProcAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable= *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_enableLoProcAlarm(ptrFlux, enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setHiProcTemp_Handler
//
//	Routine Description:
//		Sets setHiProcTemp for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - highProcTemp
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setHiProcTemp_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD highProcTemp= *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setHiProcTemp(ptrFlux, highProcTemp);
		
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setAlarmHiTempOffset_Handler
//
//	Routine Description:
//		Sets setAlarmHiTempOffset for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - aHiTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setAlarmHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD highTemp= *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setAlarmHiTempOffset(ptrFlux, highTemp);
	
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setWarnHiTempOffset_Handler
//
//	Routine Description:
//		Sets setBlowerFailureOption for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - newWarnHighTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setWarnHiTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD temp = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setWarnHiTempOffset(ptrFlux, temp);
		
		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setWarnLoTempOffset_Handler
//
//	Routine Description:
//		Sets setWarnLoTempOffset for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - newWarnLoTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setWarnLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD temp = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setWarnLoTempOffset(ptrFlux, temp);

		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setAlarmLoTempOffset_Handler
//
//	Routine Description:
//		Sets setAlarmLoTempOffset for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - newAlarmLowTempOffset
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setAlarmLoTempOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD temp = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setAlarmLoTempOffset(ptrFlux, temp);

		buffSize = sizeof(BOOL);
		*((BOOL *)buff) = retVal;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_setLoProcTemp_Handler
//
//	Routine Description:
//		Sets setLoProcTemp for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - config
//
//		Output Buffer:
//			BOOL status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_setLoProcTemp_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD temp = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_setLoProcTemp(ptrFlux, temp);
		
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_PIDsetPIDMode_Handler
//
//	Routine Description:
//		Sets setPIDenable for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - PIDMode
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_PIDsetPIDMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bMode = *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		PID_setPIDMode(&(ptrFlux->pid), bMode);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS FLUXHEATER_getConfigParam_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT) ;
	DWORD retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT param = *((UINT *)buff);
		UINT index = *((UINT*)(buff + sizeof(UINT)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);
		
		switch(param)
		{

		case MANUAL_CTRL_PARAM:
			retVal = FluxHeater_getZoneState(ptrFlux);
			break;

		case OUTPUT_ACTION_PARAM:			
				retVal = PID_getAction(&(ptrFlux->pid));
			break;

			case PROP_PARAM:
				retVal = PID_getPb(&(ptrFlux->pid));
			break;

			case INT_PARAM:				
				retVal = PID_getTi(&(ptrFlux->pid));
			break;

			case DERIV_PARAM:				
				retVal = PID_getTd(&(ptrFlux->pid));
			break;

			case ALARM_DEADBAND_PARAM:
				retVal = FluxHeater_getDeadBandHiTempOffset(ptrFlux); 
			break;		

			case ALARM_HI_PROC_OFFSET_PARAM:
				retVal = FluxHeater_getHiProcTemp(ptrFlux); 
			break;

			case ALARM_HI_DEV_OFFSET_PARAM:
				retVal = FluxHeater_getAlarmHiTempOffset(ptrFlux); 
			break;

			case ALARM_HI_WARN_OFFSET_PARAM:
				retVal = FluxHeater_getWarnHiTempOffset(ptrFlux); 			
			break;

			case ALARM_LO_WARN_OFFSET_PARAM:
				retVal = FluxHeater_getWarnLoTempOffset(ptrFlux); 			
			break;

			case ALARM_LO_DEV_OFFSET_PARAM:
				retVal = FluxHeater_getAlarmLoTempOffset(ptrFlux); 			
			break;

			case ALARM_LO_PROC_OFFSET_PARAM:
			 retVal = FluxHeater_getLoProcTemp(ptrFlux); 
			break;

			case ALARM_HI_PROC_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isHiProcAlarmEnabled(ptrFlux);		
			break;
		
			case ALARM_HI_DEV_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isHiDeviationAlarmEnabled(ptrFlux);		
			break;
	
			case ALARM_HI_WARN_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isHiDeviationWarningEnabled(ptrFlux);		
			break;
		
			case ALARM_LO_WARN_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isLoDeviationWarningEnabled(ptrFlux);		
			break;
		
			case ALARM_LO_DEV_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isLoDeviationAlarmEnabled(ptrFlux);		
			break;	

			case ALARM_LO_PROC_ENABLE_PARAM:
			retVal = (DWORD)FluxHeater_isLohProcAlarmEnabled(ptrFlux);		
			break;
		
		case OUTPUT_TYPE_PARAM:
				retVal = (DWORD)PID_getMode(&(ptrFlux->pid));
				if(retVal)
					retVal = 0;
				else
					retVal = 1;
				break;

		case INPUT_TYPE_PARAM:
				retVal = 0;
			break;

			default:
				break;

		}		
		buffSize = sizeof(DWORD);
		*((DWORD *)buff) = retVal;
		I->m_information = sizeof(DWORD);
		

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
		I->m_information = 0;
	}
	return status;
}
////////////////////////////////////////////////////////////////////////
//  BELTS_enableLoDevWarn_Handler
//
//	Routine Description:
//		Sets LoDevWarn for the referenced Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//			BOOL - enable value (TRUE/FALSE)
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_enableLoDevWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering BELTS_enableLoDevWarn_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL enable = *((BOOL *)(buff + sizeof(UINT)));

		if(index < MaxBelts)
		{
			Belt_enableLoDevWarn(&(g_dbContainer.belt[index]), enable);
#ifndef _BLOCK_TRACE
			t << "belt[" << (LONG)index << "].enableLoDevWarn(" <<
				(enable ? "TRUE" : "FALSE") << ")" << EOL;
#endif
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  BELTS_getTPOoutputCounts_Handler
//
//	Routine Description:
//		Retreives getLoPercentLimit from the selected Belt
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into beltsDb array.
//
//		Output buffer contains:
//			DWORD - beltTPOoutput
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS BELTS_getTPOoutputCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < MaxBelts)
		{
			DWORD retVal = Belt_getTPOoutputCounts(&(g_dbContainer.belt[index]));
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
		}
		else
		{
			buffSize = 0;
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_getValue_Handler
			
			This returns analog in values in the following order:
			0-(MAX_ANALOG_INPUTS-1_ primary hc2 tdm readings
			MAX_ANALOG_INPUTS - (MAX_ANALOG_INPUTS*2-1) serially read values from primary hc2's slave tdm
			(MAX_ANALOG_INPUTS * 2) - (MAX_ANALOG_INPUTS*3-1) secondary hc2 tdm readings
			(MAX_ANALOG_INPUTS * 3) - (MAX_ANALOG_INPUTS*4-1) serially read values from secondary hc2's slave tdm
			If you change the above review usage of ANALOGIN_getValue in heller comm control for consistency
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	WORD retVal;
	char* buff = NULL;
	UINT index = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);

		if(index<MAX_ANALOG_INPUTS)	
		{
			retVal = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);
		}
		else if(index<(MAX_ANALOG_INPUTS*2))//ANALOGIN_GetAtHigh
		{
			retVal = *ANALOGIN_GetAtHigh(&(g_dbContainer.analogInDb), index);
		}
		else if(index<(MAX_ANALOG_INPUTS*3))
		{
			index = index - MAX_ANALOG_INPUTS;//secondary tdm inputs are stored in high bank of getat
			retVal = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);//from MAX_ANALOG_INPUTS to MAX_ANALOG_INPUTS -1
		}
		else if(index<(MAX_ANALOG_INPUTS*4))
		{
			retVal = *ANALOGIN_GetAtHigh(&(g_dbContainer.analogInDb), index);//from MAX_ANALOG_INPUTS to MAX_ANALOG_INPUTS -1
		}
		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGIN_readProfileOffset_Handler
//
//	Routine Description:
//		Retreives the profileOffset of the Analogin(s)
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			WORD - profileOffset
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGIN_readProfileOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering ANALOGIN_readProfileOffset_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	WORD retVal = ANALOGIN_ReadProfileOffset(&(g_dbContainer.analogInDb));
	*((WORD *)buff) = retVal;
	I->m_information = sizeof(WORD);
#ifndef _BLOCK_TRACE
	t << "analogInDb.readProfileOffset()" << EOL <<
		"Returning " << (LONG)retVal << EOL;
#endif

	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALIN_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//
//		Output buffer contains:
//			BOOL - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALIN_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering ANALOGIN_getValue_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

			BOOL retVal = *DIN_GetAt(&(g_dbContainer.digitalInDb), index);
			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
			t << "digitalInDb[" << (LONG)index << "]" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_setToggle_Handler
//
//	Routine Description:
//		Sets toggle for the fluxCondensor.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setToggle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering FLUXCONDENSOR_setToggle_Handler, " << I << EOL;
#endif

	FluxCondensor_setToggle(&(g_dbContainer.fluxCondensor));
#ifndef _BLOCK_TRACE
	t << "fluxCondensor.setIntervalTime()" << EOL;
#endif
	I->m_information = 0;

	return status;
}

NTSTATUS FLUXCONDENSOR_setCycleEndNitro_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		BOOL enable = *((BOOL *)buff);

		FluxCondensor_setCycleEndNitro(&(g_dbContainer.fluxCondensor), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
 			
NTSTATUS  FLUXCONDENSOR_setJobAtEnd_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
	
		BOOL enable = *((BOOL *)buff);

		FluxCondensor_setJobAtEnd(&(g_dbContainer.fluxCondensor), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_checkWarningState_Handler
//
//	Routine Description:
//		Gets checkWarningState for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			DWORD warningState
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_checkWarningState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	UINT buffSize = sizeof(UINT);
	DWORD retVal;
	FluxHeater* ptrFlux;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_checkWarningState(ptrFlux);
		
		*((DWORD *)buff) = retVal;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = sizeof(DWORD);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_InDeadBandOrIsNotEnabled_Handler
//
//	Routine Description:
//		Returns getProcVar for the referenced fluxHeater
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_InDeadBandOrIsNotEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize=sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_InDeadBandOrIsNotEnabled(ptrFlux);

		*((BOOL *)buff) = retVal;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALOUT_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into digitalOutDb array.
//
//		Output buffer contains:
//			BOOL - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALOUT_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering DIGITALOUT_getValue_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		BOOL retVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), index);
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
		t << "digitalOutDb[" << (LONG)index << "]" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_decrement_Handler
//
//	Routine Description:
//		Sets decrement for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_decrement_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RAIL_decrement_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rails_decrement(&(g_dbContainer.railsDb), index);
#ifndef _BLOCK_TRACE
		t << "railsDb.decrement(" << (LONG)index << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RAIL_isInFinalPosition_Handler
//
//	Routine Description:
//		Returns isPresetStable for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into railsDb array.
//
//		Output Buffer:
//			DWORD - isInFinalPosition
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAIL_isInFinalPosition_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RAIL_isInFinalPosition_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		DWORD retVal = Rail_isInFinalPosition(pRail);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
#ifndef _BLOCK_TRACE
		t << "rails[" << (LONG)index << "].isInFinalPosition()" << EOL <<
				"Returning " << (retVal ? "TRUE" : "FALSE") << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_IsZoneInWarning_Handler
//
//	Routine Description:
//		Returns IsZoneInWarning for the fluxHeater
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_IsZoneInWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_IsZoneInWarning(ptrFlux);

		*((BOOL *)buff) = retVal;
	}
	else 
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getrecipePath_Handler
//
//	Routine Description:
//		Returns recipePath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			char string - path
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_getrecipePath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	UINT stringSize, i = 0;

	char *buff = (char *)I->m_ioctlBuffer;
	char *retVal = recipeTrigger_getRecipePath(&(g_dbContainer.recipetrigger));
	stringSize = strlen(retVal);

	if(stringSize > MAX_RECIPE_NAME_LENGTH - 1)
	{
		stringSize = MAX_RECIPE_NAME_LENGTH-1;
	}
	for(i = 0; i<stringSize; i++)
	{
		buff[i]=retVal[i];
	}
	buff[stringSize +1] = '\0';

	I->m_information = stringSize + 1;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveRailCount_Handler
//
//	Routine Description:
//		Returns activeRailCount for the testOct.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			short - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveRailCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveRailCount_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	short retVal =
		g_dbContainer.CommTransferClass.activeRailCount;
	*((short *)buff) = retVal;
	buffSize = sizeof(short);
#ifndef _BLOCK_TRACE
	t << "CommTransferClass.activeRailCount" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  INTERCOMMTRANSFER_getActiveRailSetChannel_Handler
			
			gets the active rail value

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS INTERCOMMTRANSFER_getActiveRailSetChannel_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	char* buff = NULL;
	Rail* pRail = NULL;
	UINT index = 0;
	long retVal = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);
		retVal = 0;
	
		if( (index + 1) <= g_dbContainer.CommTransferClass.activeRailCount)
		{
			retVal = -1;
			 pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
			 if(pRail)
			 {

				if(pRail->m_hasHomed)//if the rail did not home the position is garbage
				{
					retVal = g_dbContainer.CommTransferClass.activeRailSets[index]->channel;
				}
			}
		}
		*((long *)buff) = retVal;
		buffSize = sizeof(long);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveBeltCount_Handler
//
//	Routine Description:
//		Returns activeBeltCount for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			short - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveBeltCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveBeltCount_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	short retVal =
		g_dbContainer.CommTransferClass.activeBeltCount;
	*((short *)buff) = retVal;
	buffSize = sizeof(short);
#ifndef _BLOCK_TRACE
	t << "CommTransferClass.activeBeltCount" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveHeatCount_Handler
//
//	Routine Description:
//		Returns activeHeatCount for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			short - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveHeatCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;
#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveHeatCount_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	short retVal =
		g_dbContainer.CommTransferClass.activeHeatCount;
	*((short *)buff) = retVal;
	buffSize = sizeof(short);
#ifndef _BLOCK_TRACE
	t << "CommTransferClass.activeHeatCount" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveHeatChannel_Handler
//
//	Routine Description:
//		Returns activeHeatChannels[index]->channel for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			long - nChannel
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveHeatChannel_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveHeatChannel_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		if(index < g_dbContainer.CommTransferClass.activeHeatCount)//must validate to prevent null pointer call
		{
			long retVal =
			g_dbContainer.CommTransferClass.activeHeatChannels[index]->channel;
		*((long *)buff) = retVal;
		buffSize = sizeof(long);
	}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveBeltsChannel_Handler
//
//	Routine Description:
//		Returns activeBelts[index]->channel for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			long - nChannel
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveBeltsChannel_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveBeltsChannel_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		if(index < g_dbContainer.CommTransferClass.activeBeltCount)
		{
			long retVal =
				g_dbContainer.CommTransferClass.activeBelts[index]->channel;
			*((long *)buff) = retVal;
			buffSize = sizeof(long);
#ifndef _BLOCK_TRACE
		t << "CommTransferClass.activeBelts[" << (LONG)index << "]->channel" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_EnterChannel_Handler
//
//	Routine Description:
//		Executes EnterChannel for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			long - channel
//			short - type
//			BOOL - state
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_EnterChannel_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(long)+sizeof(short)+sizeof(BOOL);
#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_EnterChannel_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		long channel = *((long *)buff);
		short type = *((short *)(buff+sizeof(long)));
		BOOL state = *((BOOL *)(buff+sizeof(long)+sizeof(short)));


		InterCommTransferClass_EnterChannel(&(g_dbContainer.CommTransferClass), channel, type, state);
		g_dbContainer.CommTransferClass.totalChannelsEntered++;
		buffSize = 0;
#ifndef _BLOCK_TRACE
		t << "CommTransferClass.EnterChannel(" << (LONG)channel << ", " <<
			(LONG)type << " ," << (LONG)state << ")" << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setrecipeTransferPath_Handler
//
//	Routine Description:
//		Sets recipeTransferPath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			char string - path
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setrecipeTransferPath_Handler(KIrp* I)
{
/*	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = I->m_inputBufferSize;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setrecipeTransferPath_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	strncpy(g_dbContainer.recipetrigger.recipeTransferPath, buff, MAX_RECIPE_NAME_LENGTH );
	g_dbContainer.recipetrigger.recipeTransferPath[MAX_RECIPE_NAME_LENGTH] = '\0';

	I->m_information = 0;

	return status;
*/
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = I->m_inputBufferSize;
   UINT i;
   char tempCharBuffer[MAX_RECIPE_NAME_LENGTH];
   for( i=0; i < MAX_RECIPE_NAME_LENGTH; i++)
      tempCharBuffer[i] = ' ';
                                                                                              
      char *temp_str = tempCharBuffer;
                                                                         
                                                                                             
   char *buff = (char *)I->m_ioctlBuffer;
                                                                                             
   if(buffSize > MAX_RECIPE_NAME_LENGTH)
   {
      buffSize = MAX_RECIPE_NAME_LENGTH;
   }
   for(i = 0; i<buffSize; i++)
      tempCharBuffer[i]=buff[i];
                                                                                              
   BOOL retVal = recipeTrigger_setRecipePath(&(g_dbContainer.recipetrigger), temp_str);
                                                                                             
                                                                                            
   *((BOOL *)buff) = retVal;
                                                                                              
   I->m_information = sizeof(BOOL);
                                                                                              
   return status;


}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_ExecuteLoad_Handler
//
//	Routine Description:
//		Sets recipeTransferPath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_ExecuteLoad_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	recipeTrigger_ExecuteLoad(&(g_dbContainer.recipetrigger));
	I->m_information = 0;

	return status;
}
////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setHellerExitedFlagHandler
//
//	Routine Description:
//		Sets a flag to alert secondary monitoring to terminate
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		


NTSTATUS RECIPETRIGGER_setHellerExitedFlagHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bExited = *((BOOL *)buff);
		g_dbContainer.recipetrigger.bHellerProgramExited = bExited;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_getHellerExitedFlagHandler
//
//	Routine Description:
//		reads a flag alerting secondary monitoring to terminate
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//
NTSTATUS RECIPETRIGGER_getHellerExitedFlagHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	char *buff = (char *)I->m_ioctlBuffer;

	BOOL retVal =
		g_dbContainer.recipetrigger.bHellerProgramExited;
	*((BOOL *)buff) = retVal;
	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;	
}
////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveProfileCount_Handler
//
//	Routine Description:
//		Returns activeRailCount for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			short - bValue
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveProfileCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveProfileCount_Handler, " << I << EOL;
#endif
	char *buff = (char *)I->m_ioctlBuffer;

	short retVal =
		(short)(g_dbContainer.CommTransferClass.activeProfileCount);
	*((short *)buff) = retVal;
	buffSize = sizeof(short);
#ifndef _BLOCK_TRACE
	t << "CommTransferClass.activeProfileCount" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getActiveProfileChannel_Handler
//
//	Routine Description:
//		Returns activeProfileChannels[index]->channel for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			long - nChannel
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getActiveProfileChannel_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getActiveProfileChannel_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		if(index < g_dbContainer.CommTransferClass.activeProfileCount)
		{
			long retVal =
				g_dbContainer.CommTransferClass.activeProfileChannels[index]->channel;
			*((long *)buff) = retVal;
			buffSize = sizeof(long);
#ifndef _BLOCK_TRACE
		t << "CommTransferClass.activeProfileChannels[" << (LONG)index << "]->channel" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setrecipePath_Handler
//
//	Routine Description:
//		Sets recipePath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			char string - path
//
//		Output Buffer:
//			BOOL - status
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setrecipePath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = I->m_inputBufferSize;
	UINT i;
	char tempCharBuffer[MAX_RECIPE_NAME_LENGTH];
	for( i=0; i < MAX_RECIPE_NAME_LENGTH; i++)
		tempCharBuffer[i] = ' ';

		char *temp_str = tempCharBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setrecipePath_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;
//	char *temp_str = new char[buffSize];
//	strcpy(temp_str, buff);

	if(buffSize > MAX_RECIPE_NAME_LENGTH)
	{
//		temp_str[MAX_RECIPE_NAME_LENGTH] = '\0';
		buffSize = MAX_RECIPE_NAME_LENGTH;
	}
	for(i = 0; i<buffSize; i++)
		tempCharBuffer[i]=buff[i];

	BOOL retVal = recipeTrigger_setRecipePath(&(g_dbContainer.recipetrigger), temp_str);

#ifndef _BLOCK_TRACE
	t << "Setting recipetrigger.recipePath = " << temp_str << EOL;
#endif

	*((BOOL *)buff) = retVal;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getMaxNumberChannels_Handler
//
//	Routine Description:
//		Returns MaxNumberChannels for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			short - nMaxNumberChannels
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getMaxNumberChannels_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getMaxNumberChannels_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	short retVal =	(short)(ICTC_MaxNumberChannels);
	*((short *)buff) = retVal;
	buffSize = sizeof(short);
#ifndef _BLOCK_TRACE
	t << "CommTransferClass.MaxNumberChannels" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getChannelArrayType_Handler
//
//	Routine Description:
//		Returns channelArray[index]->type for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			short - nType
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getChannelArrayType_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getChannelArrayType_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		short retVal =
			g_dbContainer.CommTransferClass.channelArray[index].type;
		*((short *)buff) = retVal;
		buffSize = sizeof(short);
	#ifndef _BLOCK_TRACE
		t << "CommTransferClass.channelArray[" << (LONG)index << "].type" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  INTERCOMMTRANSFER_getChannelArrayEnabled_Handler
//
//	Routine Description:
//		Returns channelArray[index]->enabled for the INTERCOMMTRANSFER.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index
//
//		Output Buffer:
//			BOOL - nType
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS INTERCOMMTRANSFER_getChannelArrayEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering INTERCOMMTRANSFER_getChannelArrayEnabled_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		BOOL retVal =
			g_dbContainer.CommTransferClass.channelArray[index].enabled;
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
#ifndef _BLOCK_TRACE
		t << "CommTransferClass.channelArray[" << (LONG)index << "].enabled" << EOL <<
				"Returning " << (LONG)retVal << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setControlComm_Handler
//
//	Routine Description:
//		Sets ControlComm for the recipeTrigger
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nControlComm.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setControlComm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering RECIPETRIGGER_setControlComm_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nControlComm = *((UINT *)buff);
		
		g_dbContainer.recipetrigger.m_ControlComm= nControlComm;
#ifndef _BLOCK_TRACE
		t << "recipetrigger.m_ControlComm = " <<
			(LONG)nControlComm << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  RECIPETRIGGER_setrecipeSaveTransferPath_Handler
//
//	Routine Description:
//		Sets recipeSaveTransferPath for the recipeTrigger.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			char string - path
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RECIPETRIGGER_setrecipeSaveTransferPath_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char* buff = (char *)I->m_ioctlBuffer;
	buff[MAX_RECIPE_NAME_LENGTH] = '\0';
	recipeTrigger_setRecipeTransferPath(&(g_dbContainer.recipetrigger), buff);
	I->m_information = 0;
	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_getIfHZBlowerIsEnabled_Handler
//
//	Routine Description:
//		Enables the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//
//		Output buffer contains:
//			BOOL - bEnable
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_getIfHZBlowerIsEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 

#ifndef _BLOCK_TRACE
	t << "Entering HEATZONEBLOWER_getIfHZBlowerIsEnabled_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);

		BOOL bEnable = HeatZoneBlowers_getIfHZBlowerIsEnabled(&(g_dbContainer.heatZoneBlowers), nIndex);
		*((BOOL *)buff) = bEnable;
		buffSize = sizeof(BOOL);
		
#ifndef _BLOCK_TRACE
		t << "heatZoneBlowers" << (LONG)nIndex << ".getIfHZBlowerIsEnabled= " <<
			(LONG)bEnable << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_getOutputPercent_Handler
//
//	Routine Description:
//		Returns the outputPercent for the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//
//		Output buffer contains:
//			UINT - nPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_getOutputPercent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 

#ifndef _BLOCK_TRACE
	t << "Entering HEATZONEBLOWER_getOutputPercent_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);

		UINT nPercent = HeatZoneBlowers_getOutputPercent(&(g_dbContainer.heatZoneBlowers), nIndex);
		*((UINT *)buff) = nPercent;
		buffSize = sizeof(UINT);
		
#ifndef _BLOCK_TRACE
		t << "heatZoneBlowers" << (LONG)nIndex << ".getOutputPercent= " <<
			(LONG)nPercent << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_getLowSetting_Handler
//
//	Routine Description:
//		Returns the lowSetting for the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//
//		Output buffer contains:
//			UINT - nPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_getLowSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 

#ifndef _BLOCK_TRACE
	t << "Entering HEATZONEBLOWER_getLowSetting_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);

		UINT nPercent = HeatZoneBlowers_getLowSetting(&(g_dbContainer.heatZoneBlowers), nIndex);
		*((UINT *)buff) = nPercent;
		buffSize = sizeof(UINT);
		
#ifndef _BLOCK_TRACE
		t << "heatZoneBlowers" << (LONG)nIndex << ".getLowSetting= " <<
			(LONG)nPercent << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_getLowMedium_Handler
//
//	Routine Description:
//		Returns the mediumSetting for the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//
//		Output buffer contains:
//			UINT - nPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_getMediumSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 

#ifndef _BLOCK_TRACE
	t << "Entering HEATZONEBLOWER_getMediumSetting_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);

		UINT nPercent = HeatZoneBlowers_getMediumSetting(&(g_dbContainer.heatZoneBlowers), nIndex);
		*((UINT *)buff) = nPercent;
		buffSize = sizeof(UINT);
		
#ifndef _BLOCK_TRACE
		t << "heatZoneBlowers" << (LONG)nIndex << ".getMediumSetting= " <<
			(LONG)nPercent << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  HEATZONEBLOWER_getLowHigh_Handler
//
//	Routine Description:
//		Returns the highSetting for the referenced HeatZoneBlower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT nIndex (1 - 3)
//
//		Output buffer contains:
//			UINT - nPercent
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS HEATZONEBLOWER_getHighSetting_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT); 

#ifndef _BLOCK_TRACE
	t << "Entering HEATZONEBLOWER_getHighSetting_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);

		UINT nPercent = HeatZoneBlowers_getHighSetting(&(g_dbContainer.heatZoneBlowers), nIndex);
		*((UINT *)buff) = nPercent;
		buffSize = sizeof(UINT);
		
#ifndef _BLOCK_TRACE
		t << "heatZoneBlowers" << (LONG)nIndex << ".getHighSetting= " <<
			(LONG)nPercent << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}



////////////////////////////////////////////////////////////////////////
//  RAILS_bypassHomeAndPresetRoutines_Handler
//
//	Routine Description:
//		Executes bypassHomeAndPresetRoutines the rails.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_bypassHomeAndPresetRoutines_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering RAILS_bypassHomeAndPresetRoutines_Handler, " << I << EOL;
#endif
	
	Rails_bypassHomeAndPresetRoutines(&(g_dbContainer.railsDb));
#ifndef _BLOCK_TRACE
	t << "railsDb.bypassHomeAndPresetRoutines()" << EOL;
#endif

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  TEMPZONE_isInDeviationAlarmZone_Handler
//
//	Routine Description:
//		Returns isInDeviationAlarmZone for the selected Temperature Zone.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT index
//
//		Output Buffer:
//			BOOL - isInDeviationAlarmZone
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS TEMPZONE_isInDeviationAlarmZone_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

#ifndef _BLOCK_TRACE
	t << "Entering TEMPZONE_isInDeviationAlarmZone_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		BOOL retVal = TempZone_isInDeviationAlarmZone(pTZ);
#ifndef _BLOCK_TRACE
		t << (retVal ? "TRUE" : "FALSE") << " = tempZonesDb[" << (LONG)index << 
			"].isInDeviationAlarmZone()" << EOL;
#endif
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_isInDeviationAlarmZone_Handler
//
//	Routine Description:
//		Returns isInDeviationAlarmZone for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - isInDeviationAlarmZone
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_isInDeviationAlarmZone_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	BOOL retVal;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT *)buff);

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		retVal = FluxHeater_isInDeviationAlarmZone(ptrFlux);

		*((BOOL *)buff) = retVal;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_getStatusEvents_Handler
//
//	Routine Description:
//		Returns getStatusEvents for the alarmQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			UINT - alarmCount
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_getStatusEvents_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_getStatusEvents_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	UINT retVal = AlarmQueue_getStatusEvents(&(g_dbContainer.alarmQueueDb));
#ifndef _BLOCK_TRACE
	t << (LONG)retVal << " = alarmQueueDb.getStatusEvents()" << EOL;
#endif
	*((UINT *)buff) = retVal;
	buffSize = sizeof(UINT);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_setCooldownPreference_Handler
//
//	Routine Description:
//		Sets m_AlarmLight for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAlarmLight
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_setCooldownPreference_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_setCooldownPreference_Handler, " << I << EOL;
#endif
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAlarmLight = *((BOOL *)buff);

		AlarmQueue_setCooldownPreference(&(g_dbContainer.alarmQueueDb), bAlarmLight);
	
#ifndef _BLOCK_TRACE
		t << "alarmQueueDb.setCooldownPreference = " << (bAlarmLight ? "TRUE" : "FALSE") << EOL;
#endif
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_setAudibleBeltWarningsEnabled_Handler
//
//	Routine Description:
//		Sets m_bAudibleBeltWarningsEnabled for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAudibleBeltWarningsEnabled 
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_setAudibleBeltWarningsEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_setAudibleBeltWarningsEnabled_Handler, " << I << EOL;
#endif
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleBeltWarningsEnabled = *((BOOL *)buff);

		g_dbContainer.alarmQueueDb.m_bAudibleBeltWarningsEnabled = bAudibleBeltWarningsEnabled;

#ifndef _BLOCK_TRACE
		t << "alarmQueueDb.m_bAudibleBeltWarningsEnabled = " << (bAudibleBeltWarningsEnabled ? "TRUE" : "FALSE") << EOL;
#endif
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_setAudibleLowExhaustEnabled_Handler
//
//	Routine Description:
//		Sets bAudibleLowExhaustEnabled for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAudibleLowExhaustEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_setAudibleLowExhaustEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_setAudibleLowExhaustEnabled_Handler, " << I << EOL;
#endif
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleLowExhaustEnabled = *((BOOL *)buff);

		g_dbContainer.alarmQueueDb.m_bAudibleLowExhaustEnabled = bAudibleLowExhaustEnabled;
	
#ifndef _BLOCK_TRACE
		t << "alarmQueueDb.m_bAudibleLowExhaustEnabled = " << (bAudibleLowExhaustEnabled ? "TRUE" : "FALSE") << EOL;
#endif
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_setAudibleDansensorWarningEnabled_Handler
//
//	Routine Description:
//		Sets bAudibleDansensorWarningEnabled for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAudibleDansensorWarningEnabled
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_setAudibleDansensorWarningEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_setAudibleDansensorWarningEnabled_Handler, " << I << EOL;
#endif
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleDansensorWarningEnabled = *((BOOL *)buff);

		g_dbContainer.alarmQueueDb.m_bAudibleDansensorWarningEnabled = bAudibleDansensorWarningEnabled;
	
#ifndef _BLOCK_TRACE
		t << "alarmQueueDb.m_bAudibleDansensorWarningEnabled = " << (bAudibleDansensorWarningEnabled ? "TRUE" : "FALSE") << EOL;
#endif
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_getAlarmCount_Handler
//
//	Routine Description:
//		Returns getAlarmCount for the alarmQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			UINT - openAlarms
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_getAlarmCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_getAlarmCount_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	UINT retVal = AlarmQueue_getAlarmCount(&(g_dbContainer.alarmQueueDb));
#ifndef _BLOCK_TRACE
	t << (LONG)retVal << " = alarmQueueDb.getAlarmCount()" << EOL;
#endif
	*((UINT *)buff) = retVal;
	buffSize = sizeof(UINT);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_alarmQueueAcknowledge_Handler
//
//	Routine Description:
//		Acknowledges the alarm alarmIDsearch for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - alarmIDsearch
//
//		Output Buffer:
//			BOOL - found
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_alarmQueueAcknowledge_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD n_Id = *((DWORD *)buff);

		BOOL retVal = AlarmQueue_alarmQueueAcknowledge(&(g_dbContainer.alarmQueueDb), n_Id );
		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_clearReadFlagAll_Handler
//
//	Routine Description:
//		Resets the alarmsqueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_clearReadFlagAll_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	AlarmQueue_clearReadFlagAll(&(g_dbContainer.alarmQueueDb));
	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_alarmsPresent_Handler
//
//	Routine Description:
//		Returns alarmsPresent for the alarmQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - openAlarms
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_alarmsPresent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_alarmsPresent_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	BOOL retVal = AlarmQueue_alarmsPresent(&(g_dbContainer.alarmQueueDb));
#ifndef _BLOCK_TRACE
	t << (LONG)retVal << " = alarmQueueDb.alarmsPresent()" << EOL;
#endif
	*((BOOL *)buff) = retVal;
	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_warningsPresent_Handler
//
//	Routine Description:
//		Returns warningsPresent for the alarmQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - openWarnings
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_warningsPresent_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_warningsPresent_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	BOOL retVal = AlarmQueue_warningsPresent(&(g_dbContainer.alarmQueueDb));
#ifndef _BLOCK_TRACE
	t << (LONG)retVal << " = alarmQueueDb.warningsPresent()" << EOL;
#endif
	*((BOOL *)buff) = retVal;
	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_resetAudibleSounding_Handler
//
//	Routine Description:
//		Resets AudibleSounding for the alarmsqueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_resetAudibleSounding_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	I->m_information = 0;
	AlarmQueue_resetAudibleSounding(&(g_dbContainer.alarmQueueDb));

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_returnInAudibleCondition_Handler
//
//	Routine Description:
//		returnInAudibleCondition for the alarmQueue.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL - bCondition
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_returnInAudibleCondition_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_returnInAudibleCondition_Handler, " << I << EOL;
#endif

	char *buff = (char *)I->m_ioctlBuffer;

	//BOOL bAlarmQ_audible = AlarmQueue_returnInAudibleCondition(&(g_dbContainer.alarmQueueDb));
	BOOL bLT_audible = LightTower_isAudibleAlarmSet( &(g_dbContainer.lightTower) );

	BOOL retVal = bLT_audible;

	*((BOOL *)buff) = retVal;
	buffSize = sizeof(BOOL);

	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_getAlarmMessage_Handler
//
//	Routine Description:
//		Returns the TransferAlarmData for the indexed alarm for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - messageIndex
//			BOOL - win_hdac
//
//		Output Buffer:
//			BOOL - return status
//			DWORD - TransferAlarmData.alarmID
//			UINT - TransferAlarmData.moduleCode
//			DWORD - TransferAlarmData.alarmType (Cast from enum)
//			UINT - TransferAlarmData.messageNo
//			UCHAR - TransferAlarmData.tStamp.cc (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.dd (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.hh (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.min (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.mm (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.ss (Cast from BYTE)
//			UCHAR - TransferAlarmData.tStamp.yy (Cast from BYTE)
//			DWORD - TransferAlarmData.status (Cast from enum)
//			BOOL - TransferAlarmData.read
//			BOOL - TransferAlarmData.notify;
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_getAlarmMessage_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(BOOL); 

#ifndef _BLOCK_TRACE
	t << "Entering ALARMQUEUE_getAlarmMessage_Handler, " << I << EOL;
#endif
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT n_Id = *((UINT *)buff);
		BOOL win_hdac = *((BOOL *)(buff+sizeof(UINT)));
		TransferAlarmData tad;

		BOOL retVal = AlarmQueue_getAlarmMessage(&(g_dbContainer.alarmQueueDb), n_Id, &tad, win_hdac );


		*((BOOL *)buff) = retVal;
		buff += sizeof(BOOL);
		*((DWORD *)buff) = tad.alarmID;
		buff += sizeof(DWORD);
		*((UINT *)buff) = tad.moduleCode;
		buff += sizeof(UINT);
		*((DWORD *)buff) = (DWORD)tad.alarmType;
		buff += sizeof(DWORD);
		*((UINT *)buff) = tad.messageNo;
		buff += sizeof(UINT);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.cc;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.dd;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.hh;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.min;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.mm;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.ss;
		buff += sizeof(UCHAR);
		*((UCHAR *)buff) = (UCHAR)tad.tStamp.yy;
		buff += sizeof(UCHAR);
		*((DWORD *)buff) = (DWORD)tad.status;
		buff += sizeof(DWORD);
		*((BOOL *)buff) = tad.read;
		buff += sizeof(BOOL);
		*((BOOL *)buff) = tad.notify;

		buffSize = 4*sizeof(BOOL)+3*sizeof(DWORD)+2*sizeof(UINT)+7*sizeof(UCHAR);
	
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardData_Handler_NoLP
			
			Returns the current board data from the newboardq structure
			with Lot Processing disabled.

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardData_Handler_NoLP(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	UINT returnSize;
	signed int i;
	signed int iter;
	signed int j;
	DWORD nCount;
	DWORD count;
	DWORD boardCount;
	newBoardQueue_NoLP* pNBQ;
	char* buff;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	returnSize = 0;
	i = 0;
	iter = 0;
	j = 0;
	nCount = 0;
	count = 0;
	boardCount = 0;
	pNBQ = NULL;
	buff = NULL;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nCount = *((DWORD *)buff);
			count = 0;
			boardCount = 0;
			pNBQ = NULL;
			for(i = 0; i < NUM_QUEUES; i++)
			{
				boardCount = 0;
				switch (i)
				{
					case 0:
						pNBQ = &(g_dbContainer.boardQ0_NoLP);
						break;

					case 1:
						pNBQ = &(g_dbContainer.boardQ1_NoLP);
						break;

					case 2:
						pNBQ = &(g_dbContainer.boardQ2_NoLP);
						break;

					case 3:
						pNBQ = &(g_dbContainer.boardQ3_NoLP);
						break;

					default:
						break;
				}

				if(pNBQ != NULL)
				{
					boardCount = pNBQ->boardCount;			
					iter =  pNBQ->headIndex;
					if(iter >= MaxBoards)
					{
						iter = 0;
					}
					j=0;
					for(j = 0; (j <  boardCount); j++)
					{	
						*((unsigned short *)buff) = (unsigned short)pNBQ->boards[iter].boardLengthCounts;
						buff += sizeof(unsigned short);
						returnSize += sizeof(unsigned short);
					
						*((DWORD *)buff) = pNBQ->boards[iter].elapsedPositionCounts;
						buff += sizeof(DWORD);
						returnSize += sizeof(DWORD);
						iter++;
						count++;
						if(iter == MaxBoards)
						{
							iter = 0;
						}

					}
				}

			}
			if(nCount!= count)//less/more animation than expected
			{
				returnSize = 0;
			}	
		}
		else
		{
			returnSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
		I->m_information = returnSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardData_Handler_LP
			
			Returns the current board data from the newboardq structure
			with Lot Processing enabled.

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardData_Handler_LP(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	UINT returnSize;
	signed int i;
	signed int iter;
	signed int j;
	DWORD nCount;
	DWORD count;
	DWORD boardCount;
	newBoardQueue* pNBQ;
	char* buff;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	returnSize = 0;
	i = 0;
	iter = 0;
	j = 0;
	nCount = 0;
	count = 0;
	boardCount = 0;
	pNBQ = NULL;
	buff = NULL;

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nCount = *((DWORD *)buff);
			count = 0;
			boardCount = 0;
			pNBQ = NULL;
			for(i = 0; i < NUM_QUEUES; i++)
			{
				boardCount = 0;
				switch (i)
				{
					case 0:
						pNBQ = &(g_dbContainer.boardQ0);
						break;

					case 1:
						pNBQ = &(g_dbContainer.boardQ1);
						break;

					case 2:
						pNBQ = &(g_dbContainer.boardQ2);
						break;

					case 3:
						pNBQ = &(g_dbContainer.boardQ3);
						break;

					default:
						break;
				}

				if(pNBQ != NULL)
				{
					boardCount = pNBQ->m_boardCount;			
					iter =  pNBQ->headIndex;
					if(iter >= MaxBoards)
					{
						iter = 0;
					}
					j=0;
					for(j = 0; (j <  boardCount); j++)
					{	
						*((unsigned short *)buff) = (unsigned short)pNBQ->boards[iter].boardLengthCounts;
						buff += sizeof(unsigned short);
						returnSize += sizeof(unsigned short);
					
						*((DWORD *)buff) = pNBQ->boards[iter].elapsedPositionCounts;
						buff += sizeof(DWORD);
						returnSize += sizeof(DWORD);
						iter++;
						count++;
						if(iter == MaxBoards)
						{
							iter = 0;
						}

					}
				}

			}
			if(nCount!= count)//less/more animation than expected
			{
				returnSize = 0;
			}	
		}
		else
		{
			returnSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
		I->m_information = returnSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardData_Handler
			
			Returns the current board data

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardData_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	if( FALSE == g_bLotProcessingEnable )
	{
		status = BOARDQUEUE_getBoardData_Handler_NoLP(I);
	}
	else
	{
		status = BOARDQUEUE_getBoardData_Handler_LP(I);
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardAnimationData_Handler

			Returns the TransferAlarmData for the indexed alarm for the alarmQueueDB.

			Parameters:
				I - IRP containing IOCTL request
					UINT - BoardQueueIndex
					UINT - BoardIndex

				Output Buffer:
					DWORD - g_dbContainer.boardQ(N).boardCount

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardAnimationData_Handler(KIrp* I)
{

	NTSTATUS status;
	UINT buffSize;
	UINT returnSize;
	int i;
	char *buff;
	DWORD size;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT);
	returnSize = 0;
	i = 0;
	buff = NULL;
	size = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;

			for(i = 0; i < NUM_QUEUES; i++)
			{
				switch (i)
				{
					case 0:
						if( FALSE == g_bLotProcessingEnable )
						{
							size = g_dbContainer.boardQ0_NoLP.boardCount;
						}
						else
						{
							size = g_dbContainer.boardQ0.m_boardCount;
						}

						break;
					case 1:
						if( FALSE == g_bLotProcessingEnable )
						{
							size = g_dbContainer.boardQ1_NoLP.boardCount;
						}
						else
						{
							size = g_dbContainer.boardQ1.m_boardCount;
						}
						break;
					case 2:
						if( FALSE == g_bLotProcessingEnable )
						{
							size = g_dbContainer.boardQ2_NoLP.boardCount;
						}
						else
						{
							size = g_dbContainer.boardQ2.m_boardCount;
						}
						break;
					case 3:
						if( FALSE == g_bLotProcessingEnable )
						{
							size = g_dbContainer.boardQ3_NoLP.boardCount;
						}
						else
						{
							size = g_dbContainer.boardQ3.m_boardCount;
						}
						break;
					default:
						break;
				}

				*((DWORD *)buff) = size;
				buff += sizeof(DWORD);
				returnSize += sizeof(DWORD);
			}	
		}
		else
		{
			returnSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = returnSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  ALARMQUEUE_addAlarm_Handler

				Adds an alarm to the alarmQueueDB.

				I - IRP containing IOCTL request
				DWORD - alarmType (cast from enum)
				UINT - messNo
				UINT - mCode

				Output Buffer:
				DWORD - alarmID


	RETURNS:	NTSTATUS - Status code indicating success or failure
--------------------------------------------------------------------*/
NTSTATUS ALARMQUEUE_addAlarm_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize; 
	DWORD dwrdFoundWarning;
	BOOL bEnabled;

	char* buff;
	DWORD nAlarmType;
	UINT nMessNo;
	UINT nCode;
	DWORD retVal;

	nMessNo = 0;
	nCode = 0;
	nAlarmType = 0;	
	buff = NULL;
	retVal = 0;
			
	bEnabled = FALSE;
	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD)+2*sizeof(UINT); 
	dwrdFoundWarning = 0;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nAlarmType = *((DWORD *)buff);
			nMessNo = *((UINT *)(buff + sizeof(DWORD)));
			nCode = *((UINT *)(buff + sizeof(DWORD) + sizeof(UINT)));
			switch(nMessNo)
			{
				case BARCODE_APP_INIT:
					if( nAlarmType == LOGGED_EVENT )
					{
						g_dbContainer.smema1.m_bBarcodeControlled = TRUE;
						g_dbContainer.smema2.m_bBarcodeControlled = TRUE;
						g_dbContainer.smema3.m_bBarcodeControlled = TRUE;
						g_dbContainer.smema4.m_bBarcodeControlled = TRUE;
					}
					else
					{
						g_dbContainer.smema1.m_bBarcodeControlled = FALSE;
						g_dbContainer.smema2.m_bBarcodeControlled = FALSE;
						g_dbContainer.smema3.m_bBarcodeControlled = FALSE;
						g_dbContainer.smema4.m_bBarcodeControlled = FALSE;
					}
					break;

				case BARCODE_SMEMA_FREED:
					SMEMA_bcScanned(&(g_dbContainer.smema1));
					bEnabled = SMEMA_bSmemaEnabled(&(g_dbContainer.smema1));
					if(bEnabled)
					{
						if( ( g_dbContainer.smema1.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema1.pastDeadBandEntrance == FALSE ) )
						{
							g_dbContainer.smema1.m_bBarcodeAllowAgain = TRUE;
						}
						g_dbContainer.smema1.m_bBarcodeAllow = TRUE;
					}
					bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema2) );
					if(bEnabled)
					{
						if( ( g_dbContainer.smema2.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema2.pastDeadBandEntrance == FALSE ) )
						{
							g_dbContainer.smema2.m_bBarcodeAllowAgain = TRUE;
						}
						g_dbContainer.smema2.m_bBarcodeAllow = TRUE;
					}
					bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema3) );
					if(bEnabled)
					{
						if( ( g_dbContainer.smema3.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema3.pastDeadBandEntrance == FALSE ) )
						{
							g_dbContainer.smema3.m_bBarcodeAllowAgain = TRUE;
						}
						g_dbContainer.smema3.m_bBarcodeAllow = TRUE;
					}
					bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema4) );
					if(bEnabled)
					{
						if( ( g_dbContainer.smema4.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema4.pastDeadBandEntrance == FALSE ) )
						{
							g_dbContainer.smema4.m_bBarcodeAllowAgain = TRUE;
						}
						g_dbContainer.smema4.m_bBarcodeAllow = TRUE;
					}
					break;

				case DUALBC_RECMISMATCH_LANE1:
					g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema1.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema1.m_bBarcodeAllowAgain=FALSE;
					break;

				case DUALBC_RECMISMATCH_LANE2:
					g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema2.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema2.m_bBarcodeAllowAgain=FALSE;
					break;

				case DUALBC_RECMISMATCH_LANE3:
					g_dbContainer.smema3.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema3.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema3.m_bBarcodeAllowAgain=FALSE;
					break;

				case DUALBC_RECMISMATCH_LANE4:
					g_dbContainer.smema4.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema4.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema4.m_bBarcodeAllowAgain=FALSE;
					break;

				case BARCODE_SMEMA_FREED_LANE:
					switch ( nCode )
					{
						case 0:
							bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema1) );
							if(bEnabled)
							{
								if( ( g_dbContainer.smema1.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema1.pastDeadBandEntrance == FALSE ) )
								{
									g_dbContainer.smema1.m_bBarcodeAllowAgain = TRUE;
								}
								g_dbContainer.smema1.m_bBarcodeAllow = TRUE;
								g_dbContainer.smema1.m_bIsIndividualFree = TRUE;
							}
							break;
	
						case 1:
							bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema2) );
							if(bEnabled)
							{
								if( ( g_dbContainer.smema2.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema2.pastDeadBandEntrance == FALSE ) )
								{
									g_dbContainer.smema2.m_bBarcodeAllowAgain = TRUE;
								}
								g_dbContainer.smema2.m_bBarcodeAllow = TRUE;
								g_dbContainer.smema2.m_bIsIndividualFree = TRUE;
							}
							break;
	
						case 2:
							bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema3) );
							if(bEnabled)
							{
								if( ( g_dbContainer.smema3.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema3.pastDeadBandEntrance == FALSE ) )
								{
									g_dbContainer.smema3.m_bBarcodeAllowAgain = TRUE;
								}
								g_dbContainer.smema3.m_bBarcodeAllow = TRUE;
								g_dbContainer.smema3.m_bIsIndividualFree = TRUE;
							}
							break;
	
						case 3:
							bEnabled = SMEMA_bSmemaEnabled( &(g_dbContainer.smema4) );
							if(bEnabled)
							{
								if( ( g_dbContainer.smema4.m_bBarcodeAllow == TRUE ) && ( g_dbContainer.smema4.pastDeadBandEntrance == FALSE ) )
								{
									g_dbContainer.smema4.m_bBarcodeAllowAgain = TRUE;
								}
								g_dbContainer.smema4.m_bBarcodeAllow = TRUE;
								g_dbContainer.smema4.m_bIsIndividualFree = TRUE;
							}
							break;
	
						default:
							buffSize = 0;
							status = STATUS_INVALID_PARAMETER;
							break;
					}
					break;

				case BARCODE_ERROR_MISMATCH:		
					SMEMA_holdAllow();
					g_dbContainer.ovenDb.skipClear=0;
					SMEMA_clearBarcode();
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );		
					break;

				case DUALBC_HOLD_SMEMA_LANE1:
					g_dbContainer.smema1.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema1.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema1.m_bBarcodeAllowAgain=FALSE;
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;

				case DUALBC_HOLD_SMEMA_LANE2:
					g_dbContainer.smema2.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema2.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema2.m_bBarcodeAllowAgain=FALSE;
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;

				case DUALBC_HOLD_SMEMA_LANE3:
					g_dbContainer.smema3.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema3.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema3.m_bBarcodeAllowAgain=FALSE;
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;

				case DUALBC_HOLD_SMEMA_LANE4:
					g_dbContainer.smema4.m_bBarcodeAllow=FALSE;
					g_dbContainer.smema4.m_bIsIndividualFree=FALSE;
					g_dbContainer.smema4.m_bBarcodeAllowAgain=FALSE;
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;
	
				case MES_VALID_SCAN:
					SMEMA_MESSmemaVariable(1, MES_INDEX);
					dwrdFoundWarning = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), nMessNo);
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;
	
				case MES_WRONG_JOB:
					SMEMA_MESSmemaVariable(0, MES_INDEX);
					dwrdFoundWarning = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), nMessNo);
					if(dwrdFoundWarning == 0)//add as warning
					{
						retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					}
					else //already in warning, add as logged event
					{
						retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, nMessNo, nCode );
					}
					break;

				case MES_FILE_READONLY: //Fall through
				case MULTIPLE_MES_FILES:
				case MES_FILE_ERROR:
				case MES_ERROR_CODE:
					SMEMA_MESSmemaVariable(0, MES_INDEX);
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;
	
				default:
					retVal = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), (enum AlarmType)nAlarmType, nMessNo, nCode );
					break;
			}
			*((DWORD *)buff) = retVal;
			buffSize = sizeof(DWORD);
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;
}

NTSTATUS ALARMQUEUE_audibleWarnings_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	// this flag has been deprecated - instead use the Custom Light Tower setup in CSystemAddParamsDaoRecordset
#if 0
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleWarningEnabled = *((BOOL *)buff);

		AlarmQueue_setAudibleWarnings(&(g_dbContainer.alarmQueueDb), bAudibleWarningEnabled);
	}
#endif

	I->m_information = 0;

	return status;	
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setPowerFailureTime_Handler
//
//	Routine Description:
//		Sets setPowerFailureTime for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nTime
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setPowerFailureTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nTime = *((int *)buff);	
		Oven_setPowerFailureTime(&(g_dbContainer.ovenDb), nTime);


	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setFiveSecondDisable_Handler
//
//	Routine Description:
//		Sets setFiveSecondDisable for the Oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - nTime
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_setFiveSecondDisable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nTime = *((int *)buff);			
		Oven_setFiveSecondDisable(&(g_dbContainer.ovenDb), nTime);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXHEATER_startSequencingRequiresTimer_Handler
//
//	Routine Description:
//		Sets startSequencingRequiresTimer for the fluxHeater.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - active
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXHEATER_startSequencingRequiresTimer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bTime = *((BOOL*)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_startSequencingRequiresTimer(ptrFlux, bTime);
	
		buffSize = 0;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXHEATER_setFluxheaterDelayTime_Handler
			
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXHEATER_setFluxheaterDelayTime_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_DRIVER_INTERNAL_ERROR;
	UINT buffSize = sizeof(DWORD)+ sizeof(UINT);
	FluxHeater* ptrFlux = NULL;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD dTime = *((DWORD *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(DWORD)));

		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setFluxheaterDelayTime(ptrFlux, dTime);

		status = STATUS_SUCCESS;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXHEATER_setFluxHeaterEnable_Handler
			
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXHEATER_setFluxHeaterEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_DRIVER_INTERNAL_ERROR;
	UINT buffSize = sizeof(BOOL)+ sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(BOOL)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		FluxHeater_setFluxHeaterEnable(ptrFlux, bEnable);
		status = STATUS_SUCCESS;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXHEATER_initTcInput_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXHEATER_initTcInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_DRIVER_INTERNAL_ERROR;
	UINT buffSize = sizeof(UINT)+ sizeof(UINT);
	FluxHeater* ptrFlux = NULL;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT iTcInput = *((UINT *)buff);
		UINT nIndex = *((UINT *)(buff+sizeof(UINT)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);

		if(nIndex==0 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
//Assign to top 2 on 1914, or heat zone 2(i.e. reflect l-r top zone 13)
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 2);
			TempZone_initTcInput(pTZ, iTcInput);
		}
		else if(nIndex==1 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 3);
			TempZone_initTcInput(pTZ, iTcInput);
		}
		else
		{
			FluxHeater_initTcInput(ptrFlux, iTcInput);
			status = STATUS_SUCCESS;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXHEATER_initTPOoutput_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXHEATER_initTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_DRIVER_INTERNAL_ERROR;
	UINT buffSize = sizeof(UINT)+ sizeof(UINT);
	FluxHeater* ptrFlux = NULL;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT iTPOOutput = *((UINT *)buff);
		UINT nIndex = *((UINT *)(buff + sizeof(UINT)));
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);

		if(nIndex==0 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
//Assign to top 2 on 1914, or heat zone 2(i.e. reflect l-r top zone 13)
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 2);
			TempZone_initTPOoutput(pTZ, iTPOOutput);
		}
		else if(nIndex==1 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 3);
			TempZone_initTPOoutput(pTZ, iTPOOutput);
		}
		else
		{
			FluxHeater_initTPOoutput(ptrFlux, iTPOOutput);
		}
		status = STATUS_SUCCESS;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS FLUXHEATER_isFluxHeaterEnabled_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_DRIVER_INTERNAL_ERROR;
	UINT buffSize = sizeof(UINT); 
	UINT nIndex;
	BOOL bResult = FALSE;
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		nIndex = *((UINT*)buff);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, nIndex);
		bResult = FluxHeater_isFluxHeaterEnabled(ptrFlux);	
		*((BOOL *)buff) = bResult;

		status = STATUS_SUCCESS;
		buffSize = sizeof(BOOL);	
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = sizeof(BOOL);

	return status;
}


////////////////////////////////////////////////////////////////////////
//  OVEN_getFiveSecondDisable_Handler
//
//	Routine Description:
//		Returns getFiveSecondDisable for the oven.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output Buffer:
//			BOOL bEnable
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS OVEN_getFiveSecondDisable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

#ifndef _BLOCK_TRACE
	t << "Entering OVEN_getFiveSecondDisable_Handler, " << I << EOL;
#endif

	BOOL retVal = Oven_getFiveSecondDisable(&(g_dbContainer.ovenDb));
	*((BOOL *)I->m_ioctlBuffer) = retVal;

#ifndef _BLOCK_TRACE
	t << (retVal ? "TRUE" : "FALSE") << 
		"= ovenDb.getFiveSecondDisable()" << EOL;
#endif

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  LIGHTTOWER_setDOAvailibility_Handler
//
//	Routine Description:
//		Sets setDOAvailibility for the Light Tower.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAvail
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS LIGHTTOWER_setDOAvailibility_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAvail= *((BOOL *)buff);

		LightTower_setDOAvailibility(&(g_dbContainer.lightTower), bAvail);

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXFILTER_setDOAvailibility_Handler
//
//	Routine Description:
//		Sets setDOAvailibility for the fluxFilter.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAvail
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXFILTER_setDOAvailibility_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

#ifndef _BLOCK_TRACE
	t << "Entering FLUXFILTER_setDOAvailibility_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAvail= *((BOOL *)buff);

		FluxFilter_setDOAvailibility(&(g_dbContainer.fluxFilter), bAvail);
#ifndef _BLOCK_TRACE
		t << "fluxFilter.setDOAvailibility(" << 
			(bAvail ? "TRUE" : "FALSE") << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  FLUXCONDENSOR_setDelayTimer_Handler
//
//	Routine Description:
//		Sets setDelayTimer for the fluxFilter.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - nDelay
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS FLUXCONDENSOR_setDelayTimer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

#ifndef _BLOCK_TRACE
	t << "Entering FLUXCONDENSOR_setDelayTimer_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nDelay= *((DWORD *)buff);

		FluxCondensor_setDelayTimer(&(g_dbContainer.fluxCondensor), nDelay);
#ifndef _BLOCK_TRACE
		t << "fluxFilter.setDelayTimer(" << 
			(LONG)nDelay << ")" << EOL;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


////////////////////////////////////////////////////////////////////////
//  IOCTL_getTimerLoss_Handler
//
//	Routine Description:
//		returns TimerLoss from driver.
//
//	Parameters:
//		I - IRP containing IOCTL request
//
//		Output buffer contains:
//			BOOL  - Timer Loss
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS IOCTL_getTimerLoss_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

#ifndef _BLOCK_TRACE
	t << "Entering IOCTL_getTimerLoss_Handler, " << I << EOL;
#endif
	BOOL bTimerLoss = FALSE;

//	if(m_alarm_id !=(-1))
//		bTimerLoss = TRUE;

	bTimerLoss = pXp->m_bTimerFailWarningSent;

	*((BOOL *)buff) = bTimerLoss;

	I->m_information = sizeof(BOOL);

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGOUT_getValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected Analogout
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//
//		Output buffer contains:
//			WORD - value
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGOUT_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	WORD retVal;

#ifndef _BLOCK_TRACE
	t << "Entering ANALOGOUT_getValue_Handler, " << I << EOL;
#endif

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

//		WORD retVal =
//			g_dbContainer.analogOutDb[index];
		retVal = ANALOGOUT_get(&(g_dbContainer.analogOutDb), index);
		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);
#ifndef _BLOCK_TRACE
		t << "analogOutDb[" << (LONG)index << "]" << EOL <<
			"Returning " << (LONG)retVal << EOL;
#endif
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS TEMPZONES_configureIO_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize =  sizeof(LONG);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		LONG activeZones = *((LONG*)buff );

		TempZones_configureIO(&(g_dbContainer.tempZonesDb), (SHORT)activeZones);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS TEMPZONES_setNumberDrawWarningZones_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize =  sizeof(LONG);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		LONG numZones = *((LONG*)buff );

		TempZones_setNumberDrawWarningZones(&(g_dbContainer.tempZonesDb), (SHORT)numZones);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_EnterInitialCorrectionFactor_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(LONG);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		LONG correctionFactor = *((LONG*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		pRail->eInitialCorrectionFactor = correctionFactor;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_setHuntPreference_Handler(KIrp* I)
{
	
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL huntElection = *((BOOL*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		Rail_setHuntPreference(pRail, huntElection);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_EnterMaximumHunts_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(LONG);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		LONG enteredHunts = *((LONG*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		pRail->maxHunt = ((SHORT)enteredHunts);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_EnterNegativeTolerance_Handler(KIrp* I)
{	
	
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD nTol = *((DWORD*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		pRail->nTolerance = nTol;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_EnterPositiveTolerance_Handler(KIrp* I)
{	
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD pTol = *((DWORD*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		pRail->pTolerance = pTol;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS RAIL_enterBackupDistance_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD bDist = *((DWORD*)(buff + sizeof(UINT)));

		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		pRail->backDistance = bDist;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}



////////////////////////////////////////////////////////////////////////
//  RAILS_getValue_Handler
//
//	Routine Description:
//		Gets the specified value for the referenced Rail
//
//	Parameters:
//		I - IRP containing IOCTL request
//			DWORD - index into railsDb array.
//			UINT - value specifier
//
//		Output Buffer:
//			Depends on Requested parameter
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS RAILS_getValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		UINT specifier = *((DWORD*)(buff + sizeof(DWORD)));
		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);

		switch(specifier)
		{
		case RAIL_ACTUALPOSITION:
			*((LONG *)buff) = pRail->actualPosition;
			I->m_information = sizeof(LONG);
			break;
		case RAIL_PRESETPOSITION:
			*((LONG *)buff) = pRail->presetPosition;
			I->m_information = sizeof(LONG);
			break;
		case RAIL_STOPFACTOR:
			*((LONG *)buff) = pRail->lStopFactor;
			I->m_information = sizeof(LONG);
			break;
		case RAIL_PRESETACHIEVED:
			*((BOOL *)buff) = pRail->presetAchieved;
			I->m_information = sizeof(BOOL);
			break;
		case RAIL_BACKUPFORFIRSTRUN:
			*((BOOL *)buff) = pRail->backupForFirstRun;
			I->m_information = sizeof(BOOL);
			break;
		case RAIL_BACKINGUP:
			*((BOOL *)buff) = pRail->backingUp;
			I->m_information = sizeof(BOOL);
			break;
		case RAIL_LASTRAILSTATE:
			*((UINT *)buff) = pRail->lastRailState;
			I->m_information = sizeof(UINT);
			break;
		case RAIL_DIRECTIONALFLAG:
			//This one is a enum cast to a UINT
			*((UINT *)buff) = (UINT)pRail->directionFlag;
			I->m_information = sizeof(UINT);
			break;
		case RAIL_TOLERANCEATTEMPTS:
			*((LONG *)buff) = pRail->toleranceAttempts;
			I->m_information = sizeof(LONG);
			break;
		case RAIL_GETHOMEHUNTUSED:
			*((BOOL *)buff) = Rail_getHomeHuntUsed(pRail);
			I->m_information = sizeof(BOOL);
			break;
		case RAIL_NTOLERANCE:
			*((DWORD *)buff) = pRail->nTolerance;
			I->m_information = sizeof(DWORD);
			break;
		case RAIL_PTOLERANCE:
			*((DWORD *)buff) = pRail->pTolerance;
			I->m_information = sizeof(DWORD);
			break;
		case RAIL_BACKDISTANCE:
			*((DWORD *)buff) = pRail->backDistance;
			I->m_information = sizeof(DWORD);
			break;
		case RAIL_MAXHUNT:
			*((SHORT *)buff) = pRail->maxHunt;
			I->m_information = sizeof(SHORT);
			break;
		case RAIL_DONTALLOWNEWSTOPFACTOR:
			*((BOOL *)buff) = pRail->bDontAllowNewStopFactor;
			I->m_information = sizeof(BOOL);
			break;
		default:
			status = STATUS_DATA_ERROR;
			I->m_information = 0;
			break;
		}

/*		DWORD retVal = g_dbContainer.railsDb.getPositionCounts(index);

		*((DWORD *)buff) = retVal;
		I->m_information = sizeof(DWORD);*/
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}


	return status;
}

////////////////////////////////////////////////////////////////////////
//  DIGITALOUT_setValue_Handler
//
//	Routine Description:
//		Retreives the value of the selected DigitalIn
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into digitalOutDb array.
//			BOOL - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS DIGITALOUT_setValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT)+sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		BOOL bValue = *((BOOL *)(buff+sizeof(UINT)));

		*DOUT_GetAt(&(g_dbContainer.digitalOutDb), index) = bValue;

		if (index >= MaxDout)
			g_dbContainer.slaveConfig.bSecondaryActive = TRUE;
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = 0;
	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  IOCTL_SetMonitorMode_Handler
//
//	Routine Description:
//		Puts the driver into Monitor Mode for ioMonitor input.
//
//Note I have modified the behavior of this function so that it will no longer
//set monitor mode.  Old versions of the ioMonitor will not work by design.  Thi
//function will now return a value indicating if the mode switch is possible
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS IOCTL_SetMonitorMode_Handler(XpDriverDevice* pXp, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bValue = *((BOOL *)buff);
	//if the oven has started we are not allowing monitor mode so outputs will not be set manually by the monitor
		bValue = pXp->m_bOvenStarted;
		*((BOOL*)buff) = bValue;
//		pXp->m_bMonitorMode = bValue;
//		Scheduler_switchLoops(&(pXp->m_Scheduler), bValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	buffSize = sizeof(BOOL);
	I->m_information = buffSize;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ANALOGOUT_setValue_Handler
//
//	Routine Description:
//		Sets the value of the selected Analogout
//
//	Parameters:
//		I - IRP containing IOCTL request
//			UINT - index into analogInDb array.
//			WORD - value
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ANALOGOUT_setValue_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(WORD);


	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		WORD wValue =*((WORD *)(buff + sizeof(UINT)));

		*ANALOGOUT_GetAt(&(g_dbContainer.analogOutDb), index) = wValue;
		ANALOGOUT_set(&(g_dbContainer.analogOutDb), index, wValue);
		buffSize = 0;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS INTERCOMMTRANSFER_setDanState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	ULONG buffSize = sizeof(int);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int dState = *((int *)buff);

		InterCommTransferClass_setDanState(&(g_dbContainer.CommTransferClass), dState);
		buffSize = 0;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


NTSTATUS INTERCOMMTRANSFER_getDanState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize;

	char *buff = (char *)I->m_ioctlBuffer;

	int retVal = InterCommTransferClass_getDanState(&(g_dbContainer.CommTransferClass));

	*((int *)buff) = retVal;
	buffSize = sizeof(int);

	I->m_information = buffSize;

	return status;	
}


NTSTATUS OVEN_delayCooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bDelayedCooldown = *((BOOL *)buff);
		
		Oven_setDelayedCooldown(&(g_dbContainer.ovenDb), bDelayedCooldown);
	}
	I->m_information = 0;
	return status;
}

NTSTATUS OVEN_currentMonitorDelayCooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bCurrentMonitorDelayedCooldown = *((BOOL *)buff);
		
		Oven_setCurrentMonitorDelayedCooldown(&(g_dbContainer.ovenDb), bCurrentMonitorDelayedCooldown);
	}
	I->m_information = 0;
	return status;
}

NTSTATUS OVEN_heaterFailureDelayCooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bHeaterFailureDelayedCooldown = *((BOOL *)buff);
		
		Oven_setHeaterFailureDelayedCooldown(&(g_dbContainer.ovenDb), bHeaterFailureDelayedCooldown);
	}
	I->m_information = 0;
	return status;
}

NTSTATUS OVEN_currentMonitorTempZoneFailureLow_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	TempZone* pTZ = NULL;
	UINT index = 0;

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		// load temperature zone index from buffer
		index = *(UINT*)I->m_ioctlBuffer;
		// if temperature zone index valid
		if (index < MaxTempZones)
		{
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			if (pTZ)
				TempZone_currentMonitorFailureLow(pTZ, TRUE);
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		// if temperature zone index not valid
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_currentMonitorFluxZoneFailureLow_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	FluxHeater* pFLUX = NULL;
	UINT index = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		index = *(UINT*)I->m_ioctlBuffer;
		if (index < MaxTempZones)
		{
			pFLUX = DbContainer_getCorrectFluxheater(&(g_dbContainer), index);
			if (pFLUX)
				FluxHeater_currentMonitorFailureLow(pFLUX, TRUE);
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_currentMonitorTempZoneFailureHigh_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	TempZone* pTZ = NULL;
	UINT index = 0;

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		// load temperature zone index from buffer
		index = *(UINT*)I->m_ioctlBuffer;
		// if temperature zone index valid
		if (index < MaxTempZones)
		{
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			if (pTZ)
				TempZone_currentMonitorFailureHigh(pTZ, TRUE);
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		// if temperature zone index not valid
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_currentMonitorFluxZoneFailureHigh_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	FluxHeater* pFLUX = NULL;
	UINT index = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		index = *(UINT*)I->m_ioctlBuffer;
		if (index < MaxTempZones)
		{
			pFLUX = DbContainer_getCorrectFluxheater(&(g_dbContainer), index);
			if (pFLUX)
				FluxHeater_currentMonitorFailureHigh(pFLUX, TRUE);
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_currentMonitorCommFailure_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, WARNING, MODBUSCURRENT_COMM_FAILURE, 0);
	I->m_information = buffSize;
	return status;
}

NTSTATUS OVEN_heaterTempZoneFailure_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	TempZone* pTZ = NULL;
	UINT index = 0;

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		// load temperature zone index from buffer
		index = *(UINT*)I->m_ioctlBuffer;
		// if temperature zone index valid
		if (index < MaxTempZones)
		{
			// get pointer to temperature zone object
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			// if temperature zone object exists
			if (pTZ)
				TempZone_heaterFailure(pTZ, TRUE);
			// if temperature zone object does not exist
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		// if temperature zone index not valid
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_heaterFluxZoneFailure_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	FluxHeater* pFLUX = NULL;
	UINT index = 0;

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		// load flux zone index from buffer
		index = *(UINT*)I->m_ioctlBuffer;
		// if flux zone index valid
		if (index < MaxTempZones)
		{
			// get pointer to flux zone object
			pFLUX = DbContainer_getCorrectFluxheater(&(g_dbContainer), index);
			// if flux zone object exists
			if (pFLUX)
				FluxHeater_heaterFailure(pFLUX, TRUE);
			// if flux zone object does not exist
			else
			{
				buffSize = 0;
				status = STATUS_INVALID_PARAMETER;
			}
		}
		// if flux zone index not valid
		else
		{
			buffSize = 0;
			status = STATUS_INVALID_PARAMETER;
		}
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

NTSTATUS COOLPIPE_enable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.enable = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

NTSTATUS COOLPIPE_analogInputTC1_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.analogInputTC1 = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

NTSTATUS COOLPIPE_analogInputTC2_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.analogInputTC2 = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

NTSTATUS COOLPIPE_tempTC1_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.tempTC1 = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

NTSTATUS COOLPIPE_tempDelta_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.tempDelta = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

NTSTATUS COOLPIPE_delay_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	// if buffer big enough
	if (I->m_inputBufferSize >= buffSize)
	{
		g_dbContainer.coolPipeDb.delay = *(UINT*)I->m_ioctlBuffer;
	}
	// if buffer not big enough
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return(status);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_delayCooldownTime_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_delayCooldownTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iOvenDelay = *((int *)buff);
				
		Oven_setDelayedCooldownTime(&(g_dbContainer.ovenDb), iOvenDelay);
	}
	I->m_information = 0;
	return status;
}

NTSTATUS TEMPZONES_setHiProcessDelayTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iHiProcDelay = *((int *)buff);

		TempZones_setHiProcDelay(&(g_dbContainer.tempZonesDb), iHiProcDelay);
	}
	I->m_information = 0;
	return status;
}


NTSTATUS OVEN_inCooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	BOOL retVal = Oven_getAppCoolFlag(&(g_dbContainer.ovenDb));
	*((BOOL *)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(BOOL);

	return status;	
}



NTSTATUS HC2XCTL_recipeLoaded_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	BOOL retVal = pXpDriverDevice->m_bOvenStarted;
	*((BOOL *)I->m_ioctlBuffer) = retVal;

	I->m_information = sizeof(BOOL);

	return status;	
}


NTSTATUS TEMPZONE_getConfigParam_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT) ;
	DWORD retVal;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT param = *((UINT *)buff);
		UINT index = *((UINT*)(buff + sizeof(UINT)));
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);

		switch(param)
		{
			case PROP_PARAM:
				retVal = PID_getPb(&(pTZ->pidCtrl.pid));
			break;

			case INT_PARAM:
				retVal = PID_getTi(&(pTZ->pidCtrl.pid));
				break;

			case DERIV_PARAM:
				retVal = PID_getTd(&(pTZ->pidCtrl.pid));
				break;
	
			case MANUAL_CTRL_PARAM:				
				retVal = TempZone_getZoneState(pTZ);
				break;

			case OUTPUT_ACTION_PARAM:
				retVal = PID_getAction(&(pTZ->pidCtrl.pid));
				break;

			case ALARM_DEADBAND_PARAM:
				retVal = TempZone_getDeadBandHiTempOffset(pTZ);
			break;		

			case ALARM_HI_PROC_OFFSET_PARAM:
				retVal = TempZone_getHiProcTemp(pTZ);
			break;

			case ALARM_HI_DEV_OFFSET_PARAM:
				retVal = TempZone_getAlarmHiTempOffset(pTZ);
			break;
			case ALARM_HI_WARN_OFFSET_PARAM:
				retVal = TempZone_getWarnHiTempOffset(pTZ);
			break;

			case ALARM_LO_WARN_OFFSET_PARAM:
				retVal = TempZone_getWarnLoTempOffset(pTZ);
			break;

			case ALARM_LO_DEV_OFFSET_PARAM:
				retVal = TempZone_getAlarmLoTempOffset(pTZ);
			break;

			case ALARM_LO_PROC_OFFSET_PARAM:
				retVal = TempZone_getLoProcTemp(pTZ);
			break;
		
			case ALARM_HI_PROC_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isHiProcAlarmEnabled(pTZ);
			break;
		
			case ALARM_HI_DEV_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isHiDeviationAlarmEnabled(pTZ);
			break;

			case ALARM_HI_WARN_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isHiDeviationWarningEnabled(pTZ);
			break;
		
			case ALARM_LO_WARN_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isLoDeviationWarningEnabled(pTZ);
			break;
		
			case ALARM_LO_DEV_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isLoDeviationAlarmEnabled(pTZ);
			break;	

			case ALARM_LO_PROC_ENABLE_PARAM:
				retVal = (DWORD)TempZone_isLohProcAlarmEnabled(pTZ);
			break;
		
		case OUTPUT_TYPE_PARAM:
				retVal = (DWORD)PID_getMode(&(pTZ->pidCtrl.pid));
				if(retVal)
					retVal = 0;
				else
					retVal = 1;
		break;
		case INPUT_TYPE_PARAM:
			retVal = 0;
		break;
//wdt missing must add
		default:
			break;

		}		
		buffSize = sizeof(DWORD);
		*((DWORD *)buff) = retVal;
		I->m_information = sizeof(DWORD);
		

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
		I->m_information = 0;
	}
	return status;
}
NTSTATUS OVEN_returnOvenProgrammed_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	DWORD retVal = Oven_returnOvenProgrammed(&(g_dbContainer.ovenDb));
	*((DWORD *)I->m_ioctlBuffer) = retVal;

	I->m_information = sizeof(DWORD);

	return status;	
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setExitBoardDeadbandCounts_Handler

			Sets the Exit Deadband for the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					DWORD - nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setExitBoardDeadbandCounts_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT nIndex;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(DWORD); 
	buff = NULL;
	nIndex = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char*)I->m_ioctlBuffer;
			nIndex = *((UINT*)buff);
			nValue = *((DWORD *)(buff+sizeof(UINT)));

			switch(nIndex)
			{
				case 0:
					newBoardQueue_setExitBoardDeadbandCounts_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
					newBoardQueue_setExitBoardDeadbandCounts(&(g_dbContainer.boardQ0), nValue);

					SMEMA_setSmemaExitLength(&(g_dbContainer.smema1), nValue);
					break;
				case 1:
					newBoardQueue_setExitBoardDeadbandCounts_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
					newBoardQueue_setExitBoardDeadbandCounts(&(g_dbContainer.boardQ1), nValue);

					SMEMA_setSmemaExitLength(&(g_dbContainer.smema2), nValue);
					break;
				case 2:
					newBoardQueue_setExitBoardDeadbandCounts_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
					newBoardQueue_setExitBoardDeadbandCounts(&(g_dbContainer.boardQ2), nValue);

					SMEMA_setSmemaExitLength(&(g_dbContainer.smema3), nValue);
					break;
				case 3:
					newBoardQueue_setExitBoardDeadbandCounts_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);
					newBoardQueue_setExitBoardDeadbandCounts(&(g_dbContainer.boardQ3), nValue);

					SMEMA_setSmemaExitLength(&(g_dbContainer.smema4), nValue);
					break;
				default:
					break;
			}

		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS ALARMQUEUE_enableAudibleBoardWarnings_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleWarning = *((BOOL *)buff);
		UINT index = *((UINT *)(buff+sizeof(BOOL)));
		AlarmQueue_setLaneWarnings(&(g_dbContainer.alarmQueueDb), bAudibleWarning, index);		
	}

	I->m_information = 0;

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setBoardDropTolerance_Handler

			Sets the board drop tolerance for all of the BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD - nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setBoardDropTolerance_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;;
			nValue = *((DWORD *)buff);

			newBoardQueue_setBoardDropTolerance_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_setBoardDropTolerance_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_setBoardDropTolerance_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_setBoardDropTolerance_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);

			newBoardQueue_setBoardDropTolerance(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_setBoardDropTolerance(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_setBoardDropTolerance(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_setBoardDropTolerance(&(g_dbContainer.boardQ3), nValue);
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS NITROGEN_dsClosedLoop_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bClosedLoop = *((BOOL *)buff);

		Nitrogen_setDSState(&(g_dbContainer.nitrogen), bClosedLoop);		
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}
NTSTATUS NITROGEN_makeOutputsUnavailable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bOff = *((BOOL *)buff);

		Nitrogen_setOutputAvail(&(g_dbContainer.nitrogen),bOff);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}
NTSTATUS NITROGEN_pollPpmState_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;

	*((UINT *)buff) = Nitrogen_readFlowControl(&(g_dbContainer.nitrogen));
	I->m_information = sizeof(UINT);

	return status;
}

NTSTATUS NITROGEN_setRedundInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iInput = *((int *)buff);
		UINT uiInput = (UINT)iInput;

		Nitrogen_setInputForRedundant(&(g_dbContainer.nitrogen), uiInput);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}

NTSTATUS RAIL_getSetpoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT*)buff);
		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		DWORD retVal = Rail_getPresetPosition(pRail);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS ANALOGIN_GetAnalogInVal_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);

		WORD retVal = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);
		*((WORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetStoredOffset_Handler
			
			

 GLOBALS:	g_dbContainer
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_GetStoredOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	char* buff = NULL;
	UINT index = 0;
	DWORD retVal = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);
		if(index < MAX_ANALOG_INPUTS) //local tdm
		{
			retVal = ANALOGIN_GetOffsetAt(index);
		}
		else if(index < (MAX_ANALOG_INPUTS * 2)) //second hc2 tdm
		{
			retVal = ANALOGIN_GetOffsetFromSecondBoard(&(g_dbContainer.analogInDb), index);
		}
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(WORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_SetOffsetValue_Handler

			This function sets an analog offset.  When the final offset is set
			they are committed to eeprom memory.  These are used to shift thermocouple
			input to correct small errors for a few of Heller customers.
			The function is mainly used by the offset entry program

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_SetOffsetValue_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT index;
	UINT offsetValue;
	BOOL retVal;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT) + sizeof(DWORD);
	buff = NULL;
	index = 0;
	offsetValue = 0;
	retVal = FALSE;

	if(NULL != I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((UINT *)buff);
			offsetValue = *((UINT *)(buff + sizeof(UINT)));

			retVal = ANALOGIN_SetOffsetAt( index, offsetValue);

			*((BOOL *)buff) = retVal;
			buffSize = sizeof(BOOL);
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	return status;
}	
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_GetInputStyle_Handler
			
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_GetInputStyle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	char* buff = NULL;
	UINT index = 0;
	DWORD retVal = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);

		retVal = ANALOGIN_GetInputStyleAt(index);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGIN_SetInputStyle_Handler
			
		
 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGIN_SetInputStyle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT);
	char* buff = NULL;
	UINT index = 0;
	UINT iType = 0;
	BOOL retVal = FALSE;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		index = *((UINT *)buff);
		iType= *((UINT *)(buff + sizeof(UINT)));

		retVal = ANALOGIN_SetInputStyleAt(index, iType);

		*((BOOL *)buff) = retVal;
		buffSize = sizeof(BOOL);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}	

NTSTATUS BELTS_setMotors_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		BOOL enable = *((BOOL *)buff);
		Belts_setDualMotors(&(g_dbContainer.beltsDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS BELTS_setDigOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		UINT enable = *(( UINT*)buff);
		Belts_setDigOutput(&(g_dbContainer.beltsDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}

NTSTATUS BELTS_setOutputBehavior_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		UINT enable = *(( UINT*)buff);
		Belts_setDigOutputBehavior(&(g_dbContainer.beltsDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}

NTSTATUS BELTS_setMultipleVariables_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		UINT variables = *((UINT *)buff);
		if(variables & 0x01)
		 	Belts_setHybridBehavior(&(g_dbContainer.beltsDb), TRUE);
		else
		 	Belts_setHybridBehavior(&(g_dbContainer.beltsDb), FALSE);
//			m_Container.beltsDb.setHybridBehavior(FALSE);

		if(variables & 0x02)
		 	Belts_setLowDevBehavior(&(g_dbContainer.beltsDb), TRUE);
		else
		 	Belts_setLowDevBehavior(&(g_dbContainer.beltsDb), FALSE);
	
		if(variables & 0x04)
			Belts_setHiDevBehavior(&(g_dbContainer.beltsDb), TRUE);
		else
			Belts_setHiDevBehavior(&(g_dbContainer.beltsDb), FALSE);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS BELTS_InputDeviationCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		UINT counts = *((UINT *)buff);
		Belts_setDifferentialCounts(&(g_dbContainer.beltsDb), counts);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}
				
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BELTS_DiffMTime_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BELTS_DiffMTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		Belt_setProcMode(&(g_dbContainer.belt[0]), 1);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setBoardDropTimeTolerance_Handler

			Sets the Board drop time tolerence for the board queues
			associated with the specified belt.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					UINT uTime

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setBoardDropTimeTolerance_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	UINT index;
	UINT uTime;

	status = STATUS_SUCCESS;
	buffSize = (sizeof(UINT)*2);
	buff = NULL;
	index = 0;
	uTime = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((UINT *)buff);

			uTime = *((UINT *)(buff + sizeof(UINT)));

			if(index != 0 && index != 1)
			{
				I->m_information = 0;
				status =  STATUS_DRIVER_INTERNAL_ERROR;
			}
			else
			{
				switch(index)
				{
					case 0:
						newBoardQueue_setBoardDropTime_NoLP(&(g_dbContainer.boardQ0_NoLP), uTime);
						newBoardQueue_setBoardDropTime_NoLP(&(g_dbContainer.boardQ2_NoLP), uTime);
						break;

					case 1:
						newBoardQueue_setBoardDropTime_NoLP(&(g_dbContainer.boardQ1_NoLP), uTime);
						newBoardQueue_setBoardDropTime_NoLP(&(g_dbContainer.boardQ3_NoLP), uTime);
						break;

					default:
						break;
				}

				switch(index)
				{
					case 0:
						newBoardQueue_setBoardDropTime(&(g_dbContainer.boardQ0), uTime);
						newBoardQueue_setBoardDropTime(&(g_dbContainer.boardQ2), uTime);
						break;

					case 1:
						newBoardQueue_setBoardDropTime(&(g_dbContainer.boardQ1), uTime);
						newBoardQueue_setBoardDropTime(&(g_dbContainer.boardQ3), uTime);
						break;

					default:
						break;
				}
			}
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS LIGHTTOWER_setBoardDropBehavior_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		BOOL ltRedOnbs = *((BOOL *)buff);
		LightTower_setRedOnBoardError(&(g_dbContainer.lightTower), ltRedOnbs);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DIGITALIN_getHistBufferIndex_Handler
			

 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS DIGITALIN_getHistBufferIndex_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UCHAR *buff = (UCHAR *)I->m_ioctlBuffer;

	UINT retVal = 0;

	IODIN* pDin = getIODIN();	
	if ( pDin )
	{
		retVal = IODIN_GetBuffPoint(pDin);
	}

	*((UINT *)buff) = retVal;
	I->m_information = sizeof(UINT);

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DIGITALIN_getHistBuffer_Handler
			

 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS DIGITALIN_getHistBuffer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	UINT i = 0;
	UCHAR *buff = (UCHAR *)I->m_ioctlBuffer;
	if(I->m_inputBufferSize < (NUM_HISTORICAL_IO + 1))
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	else
	{
		for( i=0; i<NUM_HISTORICAL_IO; i++)
		{
			UCHAR retVal = 2;
			*((UCHAR *)buff) = retVal;
			buff++;
		}
		*buff=' ';

		buffSize = (NUM_HISTORICAL_IO + 1);
	}


	I->m_information = buffSize;

	return status;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RECIPETRIGGER_getHellerUpHandler
			

 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RECIPETRIGGER_getHellerUpHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	BOOL retVal = recipeTrigger_getHellerUp(&(g_dbContainer.recipetrigger));	
	*((BOOL *)I->m_ioctlBuffer) = retVal;	
	I->m_information = sizeof(BOOL);
	return status;
}

NTSTATUS RECIPETRIGGER_setHellerUpHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bIsUP = *((BOOL*)buff);
	
		recipeTrigger_setHellerUp(&(g_dbContainer.recipetrigger), bIsUP);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setBoardDropToleranceNeg_Handler

			Sets the Negative Board drop tolerence for all of the BoardQueues

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setBoardDropToleranceNeg_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)buff);

			newBoardQueue_setBoardDropToleranceNeg_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_setBoardDropToleranceNeg_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_setBoardDropToleranceNeg_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_setBoardDropToleranceNeg_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue); 

			newBoardQueue_setBoardDropToleranceNeg(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_setBoardDropToleranceNeg(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_setBoardDropToleranceNeg(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_setBoardDropToleranceNeg(&(g_dbContainer.boardQ3), nValue); 
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_enableSprayOption_Handler

			Sets the spray sensor enable for all of the BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					BOOL nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_enableSprayOption_Handler(KIrp* I)
{
    NTSTATUS status;
    UINT buffSize;
	char* buff;
	BOOL nValue;

    status = STATUS_SUCCESS;
    buffSize = sizeof(BOOL); 
	buff = NULL;
	nValue = FALSE;

	if( NULL != I)
    {
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((BOOL *)buff);

			newBoardQueue_enableSpraySensor_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_enableSpraySensor_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_enableSpraySensor_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_enableSpraySensor_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue); 

			newBoardQueue_enableSpraySensor(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_enableSpraySensor(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_enableSpraySensor(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_enableSpraySensor(&(g_dbContainer.boardQ3), nValue); 
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
    }
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setSprayDist_Handler

			Sets the spray sensor distance for all of the BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setSprayDist_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)buff);

			newBoardQueue_setSprayDist_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_setSprayDist_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_setSprayDist_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_setSprayDist_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);

			newBoardQueue_setSprayDist(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_setSprayDist(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_setSprayDist(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_setSprayDist(&(g_dbContainer.boardQ3), nValue);
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

   return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_setSprayDistTime_Handler

			Sets the spray sensor distance time for all of the BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setSprayDistTime_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)buff);
                                                                                                       
			newBoardQueue_addSprayLength_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_addSprayLength_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_addSprayLength_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_addSprayLength_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue); 

			newBoardQueue_addSprayLength(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_addSprayLength(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_addSprayLength(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_addSprayLength(&(g_dbContainer.boardQ3), nValue); 
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS BOARDQUEUE_setSprayOutput_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      Purge_setSprayOutput(&(g_dbContainer.purge), nValue);
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS TEMPZONE_setGlobalHighProcess_Handler(KIrp * I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(LONG);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		LONG nValue = *((LONG *)buff);

		TempZones_setGlobalHighProcess(&(g_dbContainer.tempZonesDb), nValue);
	}

   I->m_information = 0;
   return status;
}


NTSTATUS IOCTL_CONTROL_HAULTED_Handler(XpDriverDevice * xpDriver, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	xpDriver->m_bOvenStarted = 0;
	g_dbContainer.heatZoneBlowers.bInStartupMode=TRUE;
	g_dbContainer.analogFan.bInStartupMode=TRUE;
	g_dbContainer.globalBlower.bInStartupMode=TRUE;
	g_dbContainer.heatZoneBlowers.jobNo=0;
	g_dbContainer.analogFan.jobNo=0;
	g_dbContainer.globalBlower.jobNo=0;
//	g_dbContainer.ovenDb.mbOvenActive=0;
	Oven_setTerminal(&(g_dbContainer.ovenDb),0);
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_REQUEST_MONITOR_MODE_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_REQUEST_MONITOR_MODE_Handler(XpDriverDevice *pXp, KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	WORD retVal;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char*)I->m_ioctlBuffer;
		UINT iMonitor = *((UINT* )buff);
		if(pXp->m_bOvenStarted != 0)//oven is running, cannot switch to monitor control
		{
			if(!iMonitor)//we can deactivate monitor mode, although the case should not happen
			{
				Scheduler_switchLoops(&(pXp->m_Scheduler), iMonitor);
			}
			retVal = 0;
			*((WORD*)buff)= retVal;
		}
		else
		{
			Scheduler_switchLoops(&(pXp->m_Scheduler), iMonitor);
			retVal = 1;
			*((WORD*)buff) = retVal;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS IOCTL_CONTROL_STARTED_Handler(XpDriverDevice * xpDriver, KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
	xpDriver->m_bOvenStarted =1;
//	g_dbContainer.ovenDb.mbOvenActive=1;
	Oven_setTerminal(&(g_dbContainer.ovenDb),1);

	return status;
}

NTSTATUS IOCTL_TEST_WATCHDOG_Handler(XpDriverDevice* xpDriver, KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(DWORD);
	int iFluxheater;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char*) I->m_ioctlBuffer;
		DWORD index = *((DWORD*)buff);
		
		UINT action = *((UINT*)(buff + sizeof(DWORD)));
//the index indicates which watchdog we are testing
		switch(index)
		{
		//The scheduler watchdog
			case 0:
				Scheduler_testDog(&(xpDriver->m_Scheduler));
				break;
		
			//io dog	
			case 1:
			//tdm dog
			case 2:
			//tpo dog
			case 3:
				testIOWatchDogs(index);
				break;

			//application dog
			case 4:
				break;
//tpo path validation tests
	//input check		
			case 5:
				TempZones_testCriticalPath(&(g_dbContainer.tempZonesDb), action);
				AnalogFan_testCriticalPath(action);
				Belts_testCriticalPath(action);
				HeatZoneBlowers_testTPOPath(action);
				for(iFluxheater = 0; iFluxheater < POSSIBLE_FLUXHEATERS; iFluxheater++)
				{
					FluxHeater_testTPOPath(DbContainer_getCorrectFluxheater(&g_dbContainer, iFluxheater), action);	
				}
				break;
	//control write
			case 6:
				ANALOGOUT_testMPath(1, action);	
			break;
	//memory request
			case 7:
				ANALOGOUT_testMPath(2, action);
				break;
	//buffer copy 
			case 8:
				TPO_testPath(1, action);
				break;

	//output level set
			case 9:
				TPO_testPath(2, action);
				break;
			
			default:
				break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS RAILS_exercisePossible_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bMove =*((BOOL*)buff);
		Rails_railJogOptionPossible(&(g_dbContainer.railsDb), bMove);
	}
 	else
	{	
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return status;
}
NTSTATUS RAILS_setCBS2Rail_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD wrdCbsRail = *((DWORD *)buff);
		Rails_ExerciseCBS2onRail(&(g_dbContainer.railsDb), wrdCbsRail);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = 0;
	return status;
}

NTSTATUS RAILS_executeJog_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char *) I->m_ioctlBuffer;
		UINT isHardwareAvail = *((UINT *)buff);
		Rails_SetJogOn(&(g_dbContainer.railsDb), isHardwareAvail);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS RAILS_sequenceRails_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char *) I->m_ioctlBuffer;
		DWORD iGroup = *((DWORD*)buff);
		Rails_SetStartupGroup(&(g_dbContainer.railsDb), iGroup);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS RAILS_setPulseCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char *) I->m_ioctlBuffer;
		DWORD index = *((DWORD*) buff);
		DWORD count = *((DWORD*) (buff + sizeof(DWORD)));
		if(index < MaxRails)
		{
			Rails_SetPulseCounts(&(g_dbContainer.railsDb), count, index);
		}
		else
		{
			status = STATUS_DRIVER_INTERNAL_ERROR;
		}
	}
	else
	{	
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS RAILS_monitorm_bJogOn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Rails_monitorm_bJogOn(&(g_dbContainer.railsDb));
	*((UINT*)I->m_ioctlBuffer)=retVal;
	I->m_information = sizeof(UINT);
	return status;
}

NTSTATUS RAILS_monitorm_bUDPhaseMonitor_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	BOOL retVal = Rails_monitorm_bUDPhaseMonitor(&(g_dbContainer.railsDb));
	*((BOOL*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(BOOL);
	return status;
}

NTSTATUS RAILS_monitorm_uintJogPhase_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Rails_monitorm_uintJogPhase(&(g_dbContainer.railsDb));
	*((UINT*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(UINT);
	return status;
}

NTSTATUS RAILS_monitorm_uintUpdownPhase_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Rails_monitorm_uintUpdownPhase(&(g_dbContainer.railsDb));
	*((UINT*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(UINT);
	return status;
}
NTSTATUS RAILS_monitorudPhaseTimer_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	DWORD retVal = Rails_monitorudPhaseTimer(&(g_dbContainer.railsDb));
	*((DWORD*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(DWORD);
	return status;
}

NTSTATUS TEMPZONES_setCooldownSP_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT bufferSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= bufferSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		DWORD setting = *((DWORD*)buff);
		TempZones_setCooldownSP(&(g_dbContainer.tempZonesDb), setting);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RAILS_monitorcurrentRail_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RAILS_monitorcurrentRail_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT retVal = Rails_monitorcurrentRail(&(g_dbContainer.railsDb));
	*((UINT*)I->m_ioctlBuffer) = retVal;
	I->m_information = sizeof(UINT);
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BLACKBOX_GatherData_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS  BLACKBOX_GatherData_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
   return status;
}

NTSTATUS OVEN_Request_Cooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	Oven_requestCooldown(&(g_dbContainer.ovenDb)); 
	I->m_information = 0;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_FanFault_Alarm_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_FanFault_Alarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char *) I->m_ioctlBuffer;
		BOOL  bAlarm = *((BOOL *)buff);
		
		Oven_alarmOnFF(&(g_dbContainer.ovenDb), bAlarm);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS LIGHTTOWER_setCLBehavior_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		DWORD setting = *((DWORD*)buff);
		if(setting & 0x01)
		{
			LightTower_setCommLoss(&(g_dbContainer.lightTower), 1);
		}
		else
		{
			LightTower_setCommLoss(&(g_dbContainer.lightTower), 0);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_SetFCDelayDist_Handler

			Sets the Board drop time tolerence for the board queues
			associated with the specified belt.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex
					UINT uTime

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_SetFCDelayDist_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD  nValue;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)buff);
			
			newBoardQueue_setBoardFCExtraTravel_NoLP(&(g_dbContainer.boardQ0_NoLP), nValue);
			newBoardQueue_setBoardFCExtraTravel_NoLP(&(g_dbContainer.boardQ1_NoLP), nValue);
			newBoardQueue_setBoardFCExtraTravel_NoLP(&(g_dbContainer.boardQ2_NoLP), nValue);
			newBoardQueue_setBoardFCExtraTravel_NoLP(&(g_dbContainer.boardQ3_NoLP), nValue);

			newBoardQueue_setBoardFCExtraTravel(&(g_dbContainer.boardQ0), nValue);
			newBoardQueue_setBoardFCExtraTravel(&(g_dbContainer.boardQ1), nValue);
			newBoardQueue_setBoardFCExtraTravel(&(g_dbContainer.boardQ2), nValue);
			newBoardQueue_setBoardFCExtraTravel(&(g_dbContainer.boardQ3), nValue);
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_getBoardsInOvenFluxcon_Handler

			returns the BoardsInOvenCount from the referenced BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					UINT nIndex

				Output buffer contains:
					DWORD - nValue

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_getBoardsInOvenFluxcon_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	UINT buffSize;
	UINT nIndex;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT); 
	buff = NULL;
	nIndex = 0;	

	if( NULL != I )
	{
		buff = (char *)I->m_ioctlBuffer;

		if(I->m_inputBufferSize >= buffSize)
		{
			nIndex = *((UINT*)buff);	

			if( FALSE == g_bLotProcessingEnable )
			{
				switch(nIndex)
				{
					case 0:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), 1);
						break;
					case 1:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), 1);
						break;
					case 2:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), 1);
						break;
					case 3:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), 1);
						break;
					default:
						break;
				}
			}
			else
			{
				switch(nIndex)
				{
					case 0:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), 1);
						break;
					case 1:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), 1);
						break;
					case 2:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), 1);
						break;
					case 3:
						*((DWORD *)buff) = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), 1);
						break;
					default:
						break;
				}
			}

			I->m_information = sizeof(DWORD);
		}
		else
		{
			I->m_information = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_initTcInput_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_initTcInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;
	UINT buffSize = sizeof(UINT) + sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		UINT nIndex = *((UINT*)buff);
		UINT input = (UINT)(*((UINT*)(buff + sizeof(UINT))));
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), nIndex);
		if(nIndex==24 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
//Assign to top 2 on 1914, or heat zone 2(i.e. reflect l-r top zone 13)
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 0);
		}
		else if(nIndex==25 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 1);
		}
		TempZone_initTcInput(pTZ, input);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_initTPOoutput_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_initTPOoutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;
	UINT buffSize = sizeof(UINT)*2; 

	if(I->m_inputBufferSize >= buffSize)
	{
		UINT nIndex = *((UINT*)buff);
		UINT input = (UINT)(*((UINT*)(buff + sizeof(UINT))));
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), nIndex);

		if(nIndex==24 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
//Assign to top 2 on 1914, or heat zone 2(i.e. reflect l-r top zone 13)
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 0);
		}
		else if(nIndex==25 && (Oven_getDirection(&(g_dbContainer.ovenDb)) == TRUE) && (Oven_getModelNo(&(g_dbContainer.ovenDb)) == e1914_OVENMODELS))
		{
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), 1);
		}
		TempZone_initTPOoutput(pTZ, input);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_BFAud_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_BFAud_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	char *buff = (char *)I->m_ioctlBuffer;
	if(I->m_inputBufferSize >= buffSize)
	{
		BOOL bAud = *((BOOL*)buff);				
		Oven_BFAudible(&(g_dbContainer.ovenDb), bAud);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_BFTimeAlarm_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_BFTimeAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);
	char *buff = (char *)I->m_ioctlBuffer;
	if(I->m_inputBufferSize >= buffSize)
	{
		int iBFA=*((int*)buff);
		Oven_setBFATime(&(g_dbContainer.ovenDb), iBFA);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_BFTimeWarn_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_BFTimeWarn_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);
	char *buff = (char *)I->m_ioctlBuffer;
	if(I->m_inputBufferSize >= buffSize)
	{
		int iBFW=*((int*)buff);
		Oven_setBFWTime(&(g_dbContainer.ovenDb), iBFW);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_BFWARN_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_BFWARN_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAud = *((BOOL*)buff);
		Oven_BFWarn(&(g_dbContainer.ovenDb), bAud);
	}
	else
	{
		I->m_information = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

NTSTATUS RAIL_PREPROCESS_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	Rails_preTest(&(g_dbContainer.railsDb));
	return status;
}

NTSTATUS RAIL_SetLaneIndex_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(UINT); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT rail_index = *((UINT*)buff);
		BOOL lane_index = (*((UINT *)(buff+sizeof(UINT))));

		Rail* pRail = Rails_GetRail( &(g_dbContainer.railsDb), rail_index );
		Rail_SetLaneIndex( pRail, lane_index );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS BELTS_autoRange_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL enable = *((BOOL *)buff);
		Belts_enableAutoRange(&(g_dbContainer.beltsDb), enable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS BELTS_autoRangeOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT output = *((UINT *)buff);
		Belts_enableAutoRangeOutput(&(g_dbContainer.beltsDb), output);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS BELTS_autoRangeSwitch_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT bufferSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= bufferSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		DWORD setting = *((DWORD*)buff);
		Belts_setAutoRangeSwitch(&(g_dbContainer.beltsDb), setting);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  IOCTL_ACTIVATE_MODBUS_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS IOCTL_ACTIVATE_MODBUS_Handler(XpDriverDevice* xpDriver, KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT bufferSize = sizeof(BOOL);
	if(I->m_inputBufferSize >= bufferSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		BOOL bOn = *((BOOL*)buff);
		Scheduler_setModbus(bOn);
		g_dbContainer.analogInDb.iSlaveDataTimeout = 150;	
		if(bOn)
		{
			g_dbContainer.slaveConfig.config.byte1 |= CONFIGURATION_BYTE1_MODBUS_MASTER;
		}
		else
		{
			g_dbContainer.slaveConfig.config.byte1 &=~(CONFIGURATION_BYTE1_MODBUS_MASTER);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	return status;	
}

NTSTATUS FLUXHEATER_getInputReference_Handler(KIrp* I)
{
	DWORD retVal =0;
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	FluxHeater* ptrFlux;

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);
		retVal = FluxHeater_getTcInputIndex(ptrFlux);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS TEMPZONE_getInputReference_Handler(KIrp* I)
{

	DWORD retVal =0;
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
		retVal = TempZone_getInputVal(pTZ);
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS SMEMA_HoldLot_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	SMEMA_LotDisable(&(g_dbContainer.smema1));
	SMEMA_LotDisable(&(g_dbContainer.smema2));
	SMEMA_LotDisable(&(g_dbContainer.smema3));
	SMEMA_LotDisable(&(g_dbContainer.smema4));
	I->m_information = 0;
	return status;

}

NTSTATUS  SMEMA_ClearLot_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	SMEMA_LotEnable(&(g_dbContainer.smema1));
	SMEMA_LotEnable(&(g_dbContainer.smema2));
	SMEMA_LotEnable(&(g_dbContainer.smema3));
	SMEMA_LotEnable(&(g_dbContainer.smema4));
	I->m_information = 0;
	return status;
}
NTSTATUS OVEN_ClearCooldownNotify_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	OVEN_ClearCN(&(g_dbContainer.ovenDb));
	return status;
}

NTSTATUS DS_enable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		BOOL bEnable = (*((BOOL *)(buff+sizeof(UINT))));

		CBS_setEnable(&(g_dbContainer.cbs), bEnable, nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS DS_Input_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(int); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		int iInput = (*((int *)(buff+sizeof(UINT))));

		CBS_setInput(&(g_dbContainer.cbs), iInput, nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS DS_Output_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT) + sizeof(int); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT nIndex = *((UINT*)buff);
		int iOutput = (*((int *)(buff+sizeof(UINT))));

		CBS_setOutput(&(g_dbContainer.cbs), iOutput, nIndex);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_shutdownBlowers_Handler
			calls the shutdown blower routine which deactivates tpo for
			the heater zone, also results in cooldown once the oven is empty

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_shutdownBlowers_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL)+sizeof(UINT);
	TempZone* pTZ = NULL;
	UINT index = 0;
	char* buff = NULL;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;

		index = (UINT)(*((UINT*)(buff + sizeof(BOOL))));
		if( ( index < MaxTempZones ) && ( index >= 0 ) )
		{
			pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			TempZone_blowerFailure(pTZ, TRUE);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_setRiseRateWarning_Handler::CloseEventLog


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONES_setRiseRateWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bWarn= *((BOOL *)buff);
		TempZones_setRiseRateWarning(&(g_dbContainer.tempZonesDb), bWarn);
		
		g_dbContainer.fluxHeater.m_bRiseRateEnabled = bWarn;
		g_dbContainer.fluxHeater1.m_bRiseRateEnabled = bWarn;
		g_dbContainer.fluxHeater2.m_bRiseRateEnabled = bWarn;
		g_dbContainer.fluxHeater3.m_bRiseRateEnabled = bWarn;
		g_dbContainer.fluxHeater4.m_bRiseRateEnabled = bWarn;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS NITROGEN_enableWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bWarn= *((BOOL *)buff);

		Nitrogen_enableWarning(&(g_dbContainer.nitrogen), bWarn);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS NITROGEN_enableAlarm_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAlarm= *((BOOL *)buff);

		Nitrogen_enableAlarm(&(g_dbContainer.nitrogen), bAlarm);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS NITROGEN_setAlarmTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD AlarmTime= *((DWORD *)buff);

		Nitrogen_setAlarmTime(&(g_dbContainer.nitrogen), AlarmTime);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS NITROGEN_setWarningTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD AlarmTime= *((DWORD *)buff);

		Nitrogen_setWarningTime(&(g_dbContainer.nitrogen), AlarmTime);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS BELTS_SmemaOffRange_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT bufferSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= bufferSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		DWORD setting = *((DWORD*)buff);
		Belts_SmemaOffDist(&(g_dbContainer.beltsDb), setting);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_CureApp_Handler

			Sets the Exit Cure setting for all of the SMEMA and 
			BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS SMEMA_CureApp_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize =sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)(buff));

			SMEMA_exitCureSetting(&(g_dbContainer.smema1), nValue);
			SMEMA_exitCureSetting(&(g_dbContainer.smema2), nValue);
			SMEMA_exitCureSetting(&(g_dbContainer.smema3), nValue);
			SMEMA_exitCureSetting(&(g_dbContainer.smema4), nValue);

			g_dbContainer.boardQ0_NoLP.cureOven = nValue;
			g_dbContainer.boardQ1_NoLP.cureOven = nValue;
			g_dbContainer.boardQ2_NoLP.cureOven = nValue;
			g_dbContainer.boardQ3_NoLP.cureOven = nValue;

			/* cureOven does not exist in Lot Processing
			   newBoardQueue structure.  
			*/
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS SMEMA_EntrHold_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize =sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nValue = *((DWORD *)(buff));
#if 0 // fjn -- superseded by SMEMA_LaneBoardSpacing
		g_dbContainer.smema1.m_smemaOnMinDist = nValue;
		g_dbContainer.smema2.m_smemaOnMinDist = nValue;
		g_dbContainer.smema3.m_smemaOnMinDist = nValue;
		g_dbContainer.smema4.m_smemaOnMinDist = nValue;
#endif
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_ignoreBoardLength_Handler

			Sets Board Length Ignore Enable Flag for all BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_ignoreBoardLength_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize =sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)(buff));

			g_dbContainer.boardQ0_NoLP.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ1_NoLP.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ2_NoLP.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ3_NoLP.m_bIgnoreBoardLength = nValue;

			g_dbContainer.boardQ0.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ1.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ2.m_bIgnoreBoardLength = nValue;
			g_dbContainer.boardQ3.m_bIgnoreBoardLength = nValue;
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_enablePredefinedBoardLength_Handler

			Sets the pre-defined board length enable flag for all of the
			BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_enablePredefinedBoardLength_Handler(KIrp * I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize =sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)(buff));

			g_dbContainer.boardQ0_NoLP.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ2_NoLP.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ1_NoLP.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ3_NoLP.m_bEnablePredefinedBoardLength = nValue;

			g_dbContainer.boardQ0.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ2.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ1.m_bEnablePredefinedBoardLength = nValue;
			g_dbContainer.boardQ3.m_bEnablePredefinedBoardLength = nValue;
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_predefinedBoardLength_Handler

			Sets the pre-defined board length for the specified BoardQueue.

			Parameters:
				I - IRP containing IOCTL request
					DWORD index
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_predefinedBoardLength_Handler(KIrp * I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD index;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize =sizeof(DWORD)*2; 
	buff = NULL;
	index = 0;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((DWORD *)(buff));
			nValue = *((DWORD *)(buff + sizeof(DWORD)));
#if 0 // fjn -- superseded by SMEMA_LaneBoardLength
			switch(index)
			{
				case 0:
					g_dbContainer.boardQ0_NoLP.m_PredefinedBoardLength = nValue;
					g_dbContainer.boardQ0.m_PredefinedBoardLength = nValue;
					break;
				case 1:
					g_dbContainer.boardQ1_NoLP.m_PredefinedBoardLength = nValue;
					g_dbContainer.boardQ1.m_PredefinedBoardLength = nValue;
					break;
				case 2:
					g_dbContainer.boardQ2_NoLP.m_PredefinedBoardLength = nValue;
					g_dbContainer.boardQ2.m_PredefinedBoardLength = nValue;
					break;
				case 3:
					g_dbContainer.boardQ3_NoLP.m_PredefinedBoardLength = nValue;
					g_dbContainer.boardQ3.m_PredefinedBoardLength = nValue;
					break;
				default:
					break;
			}
#endif
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_entranceJamWarning_Handler

			Sets the entrance jam warning enable flag for all of the
			BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD nValue

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_entranceJamWarning_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD nValue;

	status = STATUS_SUCCESS;
	buffSize =sizeof(DWORD); 
	buff = NULL;
	nValue = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			nValue = *((DWORD *)(buff));

			g_dbContainer.boardQ0_NoLP.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ1_NoLP.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ2_NoLP.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ3_NoLP.m_bEntranceJamWarning = nValue;

			g_dbContainer.boardQ0.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ1.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ2.m_bEntranceJamWarning = nValue;
			g_dbContainer.boardQ3.m_bEntranceJamWarning = nValue;
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS MASS_COLLECT_AI_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	WORD retVal[120]={0};
	char *buff = (char *)I->m_ioctlBuffer;
	UINT index = 0;
	
	for(index=0; index < 120; index++)
	{
		if(index<MAX_ANALOG_INPUTS)	
		{
			retVal[index] = *ANALOGIN_GetAt(&(g_dbContainer.analogInDb), index);
		}
		else
		{
			retVal[index] = *ANALOGIN_GetAtHigh(&(g_dbContainer.analogInDb), index);
		}
		*((WORD *)(buff+buffSize)) = retVal[index];
		buffSize += sizeof(WORD);
	}
	I->m_information = buffSize;

	return status;
}





NTSTATUS RECIPETRIGGER_setReadControlHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(int);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		int iControl = *((int*)buff);
	
		recipeTrigger_setReadControl(&(g_dbContainer.recipetrigger), iControl);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;

}
NTSTATUS RECIPETRIGGER_getReadControlHandler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	int retVal = recipeTrigger_getReadControl(&(g_dbContainer.recipetrigger));
	
	*((int *)I->m_ioctlBuffer) = retVal;
	
	I->m_information = sizeof(int);
	return status;
}
NTSTATUS  SMEMA_clearBarcodeTimeout_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	LightTower_barcodePing(&(g_dbContainer.lightTower));

	I->m_information = 0;

	return status;
}

NTSTATUS  SMEMA_HoldWarning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);
	if(I->m_inputBufferSize >= buffSize)
	{
		char* buff = (char*) I->m_ioctlBuffer;
		BOOL setting = *((BOOL*)buff);
		LightTower_barcodeOption(&(g_dbContainer.lightTower),setting);	
		g_dbContainer.ovenDb.skipClear=0;
	
		SMEMA_clearBarcode();	
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;
}
NTSTATUS ALARMQUEUE_audibleBCWarnings_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAudibleWarningEnabled = *((BOOL *)buff);

		AlarmQueue_setAudibleBCWarnings(&(g_dbContainer.alarmQueueDb), bAudibleWarningEnabled);
	}

	I->m_information = 0;

	return status;	
}
////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_ackType_Handler
//
//	Routine Description:
//		Sets m_AlarmLight for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAlarmLight
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_ackType_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 
	
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD dwrdAlarm = *((DWORD *)buff);

		AlarmQueue_alarmQueueAcknowledgeByType(&(g_dbContainer.alarmQueueDb), dwrdAlarm);
	}

	I->m_information = 0;

	return status;
}

////////////////////////////////////////////////////////////////////////
//  ALARMQUEUE_vipMode_Handler
//
//	Routine Description:
//		Sets m_AlarmLight for the alarmQueueDB.
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bAlarmLight
//
//		Output Buffer:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments:
//
//		
// Author: Joe Rogers
NTSTATUS ALARMQUEUE_vipMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bVIP = *((BOOL *)buff);

		AlarmQueue_setVIPMode(&(g_dbContainer.alarmQueueDb), bVIP);
		LightTower_setVIPMode(&(g_dbContainer.lightTower), bVIP);
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_Count_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS  SMEMA_Count_Handler(KIrp*I)
{
	NTSTATUS	status = STATUS_SUCCESS;
	char *buff = (char *)I->m_ioctlBuffer;
	DWORD dwrd = *((DWORD *)buff);
	SMEMA_setLaneCount(&(g_dbContainer.smema1), dwrd);
	I->m_information = 0;

	return status;
}

NTSTATUS SMEMA_MaxBoardsPerLaneEnable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		SMEMA_SetMaxBoardsPerLaneEnable( &(g_dbContainer.smema1), bEnable );
		SMEMA_SetMaxBoardsPerLaneEnable( &(g_dbContainer.smema2), bEnable );
		SMEMA_SetMaxBoardsPerLaneEnable( &(g_dbContainer.smema3), bEnable );
		SMEMA_SetMaxBoardsPerLaneEnable( &(g_dbContainer.smema4), bEnable );
	}

	I->m_information = 0;

	return status;
}

NTSTATUS SMEMA_MaxBoardsPerLaneCount_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD dwCount = *((DWORD *)buff);

		SMEMA_SetMaxBoardsPerLaneSetCount( &(g_dbContainer.smema1), dwCount );
		SMEMA_SetMaxBoardsPerLaneSetCount( &(g_dbContainer.smema2), dwCount );
		SMEMA_SetMaxBoardsPerLaneSetCount( &(g_dbContainer.smema3), dwCount );
		SMEMA_SetMaxBoardsPerLaneSetCount( &(g_dbContainer.smema4), dwCount );
	}

	I->m_information = 0;

	return status;
}

NTSTATUS SMEMA_LaneBoardLength_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) * 2;

	if (I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD lane = *(DWORD *)buff;
		DWORD length = *(DWORD*)(buff + sizeof(DWORD));
		switch (lane)
		{
		case 0:
			g_dbContainer.boardQ0_NoLP.m_PredefinedBoardLength = length;
			g_dbContainer.boardQ0.m_PredefinedBoardLength = length;
			break;
		case 1:
			g_dbContainer.boardQ1_NoLP.m_PredefinedBoardLength = length;
			g_dbContainer.boardQ1.m_PredefinedBoardLength = length;
			break;
		case 2:
			g_dbContainer.boardQ2_NoLP.m_PredefinedBoardLength = length;
			g_dbContainer.boardQ2.m_PredefinedBoardLength = length;
			break;
		case 3:
			g_dbContainer.boardQ3_NoLP.m_PredefinedBoardLength = length;
			g_dbContainer.boardQ3.m_PredefinedBoardLength = length;
			break;
		default:
			status = STATUS_INVALID_PARAMETER;
			break;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

NTSTATUS SMEMA_LaneBoardSpacing_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) * 2;

	if (I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD lane = *(DWORD *)buff;
		DWORD spacing  = *(DWORD*)(buff + sizeof(DWORD));
		switch (lane)
		{
		case 0 :
			g_dbContainer.smema1.m_smemaOnMinDist = spacing;
			break;
		case 1 :
			g_dbContainer.smema2.m_smemaOnMinDist = spacing;
			break;
		case 2 :
			g_dbContainer.smema3.m_smemaOnMinDist = spacing;
			break;
		case 3 :
			g_dbContainer.smema4.m_smemaOnMinDist = spacing;
			break;
		default :
			status = STATUS_INVALID_PARAMETER;
			break;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_MesActive_Handler

			sets the setup wizard MES setting

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS SMEMA_MesActive_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize; 
	char* buff;
	int iEnable;

	status = STATUS_SUCCESS;
	buffSize = sizeof(int); 
	buff = NULL;
	iEnable = 0;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			iEnable = *((int *)buff);

			SMEMA_MESActivate( iEnable, MES_INDEX );
		}

		I->m_information = 0;
	}
	return status;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_MesEnabled_Handler

			sets the runtime MES setting, allow/disallow entry on smema
			lane for file control protocol

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS SMEMA_MesEnabled_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize; 
	char* buff;
	int iEnable;
	int iIndex;

	iIndex = 0;
	buff = NULL;
	iEnable = 0;
	status = STATUS_SUCCESS;
	buffSize = sizeof(int); 

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			iEnable = *((int *)buff);
	
			SMEMA_MESAllowed(  iEnable, 0 );
		}
	
		I->m_information = 0;
	}
	return status;
}

NTSTATUS SMEMA_NoBoardAnimation_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		SMEMA_SetNoBoardAnimationEnable( &(g_dbContainer.smema1), bEnable );
		SMEMA_SetNoBoardAnimationEnable( &(g_dbContainer.smema2), bEnable );
		SMEMA_SetNoBoardAnimationEnable( &(g_dbContainer.smema3), bEnable );
		SMEMA_SetNoBoardAnimationEnable( &(g_dbContainer.smema4), bEnable );
	}

	I->m_information = 0;

	return status;
}

NTSTATUS SMEMA_setLaneHold_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	if (I->m_inputBufferSize >= sizeof(DWORD) + sizeof(BOOL))
	{
		char *buff = (char*)I->m_ioctlBuffer;
		DWORD lane = *(DWORD*)buff;
		BOOL bHold = *(BOOL*)(buff + sizeof(DWORD));
		switch (lane)
		{
		case 0 :
			SMEMA_SetLaneHold(&g_dbContainer.smema1, bHold);
			break;
		case 1 :
			SMEMA_SetLaneHold(&g_dbContainer.smema2, bHold);
			break;
		case 2 :
			SMEMA_SetLaneHold(&g_dbContainer.smema3, bHold);
			break;
		case 3 :
			SMEMA_SetLaneHold(&g_dbContainer.smema4, bHold);
			break;
		default :
			status = STATUS_INVALID_PARAMETER;
			break;
		}
	}
	else
		status = STATUS_BUFFER_TOO_SMALL;

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_AllowSmemaAgain_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_AllowSmemaAgain_Handler(KIrp*I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;

	g_dbContainer.ovenDb.m_uAllowBarcodeAgain = 2;

	I->m_information = buffSize;

	return status;
}


NTSTATUS ALARMQUEUE_warningOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		AlarmQueue_setAWOutput(&(g_dbContainer.alarmQueueDb), set);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS HEATZONEBLOWER_controlMap_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		if(set&0x01)
		{
			g_dbContainer.heatZoneBlowers.controlType[0] = INTELLIGENT_EXHAUST;
		}
		else if(set&0x20)
		{
			g_dbContainer.heatZoneBlowers.controlType[0] = STANDBY_BLOWERS;
		}
		else
		{
			g_dbContainer.heatZoneBlowers.controlType[0] = CLASSIC_BLOWERS;
		}
		if(set&0x02)
		{
			g_dbContainer.heatZoneBlowers.controlType[1] = INTELLIGENT_EXHAUST;
		}
		else if(set&0x40)
		{
			g_dbContainer.heatZoneBlowers.controlType[1] = STANDBY_BLOWERS;
		}
		else
		{
			g_dbContainer.heatZoneBlowers.controlType[1] = CLASSIC_BLOWERS;
		}
		if(set&0x04)
		{
			g_dbContainer.heatZoneBlowers.controlType[2] = INTELLIGENT_EXHAUST;
		}
		else if(set&0x80)
		{
			g_dbContainer.heatZoneBlowers.controlType[2] = STANDBY_BLOWERS;
		}
		else
		{
			g_dbContainer.heatZoneBlowers.controlType[2] = CLASSIC_BLOWERS;
		}
		if(set&0x08)
		{
			g_dbContainer.analogFan.controlType = INTELLIGENT_EXHAUST;
		}
		else if(set&0x100)
		{
			g_dbContainer.analogFan.controlType = STANDBY_BLOWERS;
		}
		else
		{
			g_dbContainer.analogFan.controlType = CLASSIC_BLOWERS;
		}
		if(set&0x10)
		{
			g_dbContainer.globalBlower.controlType = INTELLIGENT_EXHAUST;
		}
		else if(set&0x200)
		{
			g_dbContainer.globalBlower.controlType = STANDBY_BLOWERS;
		}
		else
		{
			g_dbContainer.globalBlower.controlType = CLASSIC_BLOWERS;
		}

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS HEATZONEBLOWER_StandbyTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.heatZoneBlowers.standbyTime[0]=set;
		g_dbContainer.heatZoneBlowers.standbyTime[1]=set;
		g_dbContainer.heatZoneBlowers.standbyTime[2]=set;
		g_dbContainer.heatZoneBlowers.standbyTime[3]=set;
		g_dbContainer.analogFan.standbyTime=set;
		g_dbContainer.globalBlower.standbyTime=set;
		g_dbContainer.ovenDb.standbyMode1Time=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_IEBoardLoad_Handler

			Sets the blower Board Load for all of the BoardQueues.

			Parameters:
				I - IRP containing IOCTL request
					DWORD set

				Output buffer contains:

 RETURNS:   NTSTATUS - Status code indicating success or failure
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_IEBoardLoad_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD set;

	status = STATUS_SUCCESS;
	buffSize = 0;
	buff = NULL;
	set = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			set = *((DWORD *)buff);

			g_dbContainer.boardQ0_NoLP.blowerBoardLoad=set;
			g_dbContainer.boardQ1_NoLP.blowerBoardLoad=set;
			g_dbContainer.boardQ2_NoLP.blowerBoardLoad=set;
			g_dbContainer.boardQ3_NoLP.blowerBoardLoad=set;

			//NOTE: This option is not currently supported
			//by the Lot Tracking
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_100H_Handler
			
			0-100 handler

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_100H_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char *buff;
	DWORD set;

	status = STATUS_SUCCESS;
	buffSize = 0;
	buff = NULL;
	set = 0;

	if(I != NULL)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			set = *((DWORD *)buff);
			g_dbContainer.heatZoneBlowers.bFlush2 = FALSE;//Clear the flush 2 cycle, if shutdown mid cycle and the system parameter changes it can reenter the flush2
			g_dbContainer.analogFan.bFlush2 = FALSE;
			g_dbContainer.globalBlower.bFlush2 = FALSE;
			g_dbContainer.heatZoneBlowers.startupAlg=set;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	return status;
}

NTSTATUS GLOBALBLOWER_0_100_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL set = *((BOOL *)buff);
		g_dbContainer.globalBlower.b0100=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS GLOBALBLOWER_LOW_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.globalBlower.LowSetting=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS GLOBALBLOWER_MED_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.globalBlower.MediumSetting=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS GLOBALBLOWER_HIGH_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.globalBlower.HighSetting=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS ANALOGFAN_0_100_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL set = *((BOOL *)buff);
		g_dbContainer.analogFan.b0100=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS HEATZONEBLOWER_0_100A_Handler(KIrp* I)

{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL set = *((BOOL *)buff);
		g_dbContainer.heatZoneBlowers.b0100[0]=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS HEATZONEBLOWER_0_100B_Handler(KIrp* I)

{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL set = *((BOOL *)buff);
		g_dbContainer.heatZoneBlowers.b0100[1]=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS HEATZONEBLOWER_0_100C_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL set = *((BOOL *)buff);
		g_dbContainer.heatZoneBlowers.b0100[2]=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS ANALOGFAN_LOW_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.analogFan.LowSetting=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS ANALOGFAN_MED_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.analogFan.mediumSetting=set;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS ANALOGFAN_HIGH_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD set = *((DWORD *)buff);
		g_dbContainer.analogFan.HighSetting=set;
	}
	else
	{
		buffSize = 0;

		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ANALOGFAN_MINIMUM_Handler
			
			assigns minimum value for the analog fan output, 0-100
 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ANALOGFAN_MINIMUM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	char* buff = NULL;
	DWORD set = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		set = *((DWORD *)buff);
		Fans_setMinimum(ANALOG_FAN_INDEX, set);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GLOBALBLOWER_MINIMUM_Handler
			
			assigns minimum value for the global blower output, 0-100
 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS GLOBALBLOWER_MINIMUM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	char* buff = NULL;
	DWORD set = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		set = *((DWORD *)buff);
		Fans_setMinimum(GLOBAL_BLOWER_INDEX, set);
	}
	else
	{
		buffSize = 0;

		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_MINIMUM_Handler
			
			assigns minimum value for the first blower, 0-100
 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_MINIMUM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) * 2;
	char *buff = NULL;
	BOOL set = 0;
	unsigned int index = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		set = *((BOOL* )buff);
		index = *( (DWORD* ) ( buff + sizeof( DWORD ) ) );
		Fans_setMinimum(index, set);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_IE_LEVEL_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_IE_LEVEL_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	DWORD retVal=3;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD get = *((DWORD *)buff);
		switch(get)
		{
			case 0:
			retVal = g_dbContainer.heatZoneBlowers.currentIELevel[0];
			break;
			case 1:
			retVal = g_dbContainer.heatZoneBlowers.currentIELevel[1];
			break;
			case 2:
			retVal = g_dbContainer.heatZoneBlowers.currentIELevel[2];
			break;
			case 3:
			retVal = g_dbContainer.analogFan.currentIELevel;
			break;
			case 4:
			retVal = g_dbContainer.globalBlower.currentIELevel;
			break;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	*((DWORD *)I->m_ioctlBuffer) = retVal;
	
	I->m_information = sizeof(DWORD);
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	BOARDQUEUE_setTime_Handler(KIrp* I)

				Sets the Board Queue Timestamp
		
	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_setTime_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize; 
	char* buff;
	DWORD dMilli;
	DWORD dLow;
	DWORD dHigh;

	status = STATUS_SUCCESS;
	buffSize =(sizeof(DWORD)*3); 
	buff = NULL;
	dMilli = 0;
	dLow = 0;
	dHigh = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			dMilli = *((DWORD *)(buff));
			dLow = *((DWORD *)(buff + sizeof(DWORD)));
			dHigh = *((DWORD *)(buff + (2*sizeof(DWORD))));

			//First Set Non-Lot Processing Board Queue
			LocalTime_setTime( &(g_dbContainer.boardQ0_NoLP.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ1_NoLP.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ2_NoLP.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ3_NoLP.m_currentTime), dHigh, dLow, dMilli );

			g_dbContainer.boardQ0_NoLP.m_dMilli = dMilli;
			g_dbContainer.boardQ0_NoLP.m_dHigh = dHigh;
			g_dbContainer.boardQ0_NoLP.m_dLow = dLow;
			g_dbContainer.boardQ0_NoLP.m_jiffies = jiffies;
			g_dbContainer.boardQ1_NoLP.m_dMilli = dMilli;
			g_dbContainer.boardQ1_NoLP.m_dHigh = dHigh;
			g_dbContainer.boardQ1_NoLP.m_dLow = dLow;
			g_dbContainer.boardQ1_NoLP.m_jiffies = jiffies;
			g_dbContainer.boardQ2_NoLP.m_dMilli = dMilli;
			g_dbContainer.boardQ2_NoLP.m_dHigh = dHigh;
			g_dbContainer.boardQ2_NoLP.m_dLow = dLow;
			g_dbContainer.boardQ2_NoLP.m_jiffies = jiffies;
			g_dbContainer.boardQ3_NoLP.m_dMilli = dMilli;
			g_dbContainer.boardQ3_NoLP.m_dHigh = dHigh;
			g_dbContainer.boardQ3_NoLP.m_dLow = dLow;
			g_dbContainer.boardQ3_NoLP.m_jiffies = jiffies;

			//Now Set Lot Processing Board Queue
			LocalTime_setTime( &(g_dbContainer.boardQ0.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ1.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ2.m_currentTime), dHigh, dLow, dMilli );
			LocalTime_setTime( &(g_dbContainer.boardQ3.m_currentTime), dHigh, dLow, dMilli );

			g_dbContainer.boardQ0.m_jiffies = jiffies;
			g_dbContainer.boardQ1.m_jiffies = jiffies;
			g_dbContainer.boardQ2.m_jiffies = jiffies;
			g_dbContainer.boardQ3.m_jiffies = jiffies;
		}
		else
		{
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = 0;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	BOARDQUEUE_clearCarrierVariables_Handler(KIrp* I)
	
				Re-initializes the lot processing, and in turn
				clears all of the current lot processing data.

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_clearCarrierVariables_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;

	status = STATUS_SUCCESS;
	buffSize = 0;

	LotProcessing_init( &(g_dbContainer.m_lotProcessing) );
	BoardEntryEvents_init(&(g_dbContainer.m_boardEvents));

	if( NULL != I )
	{
		I->m_information = buffSize;
	}

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	OVEN_variousSettings_Handler(KIrp* I)
	
				Configures the oven with the setup parameters stored
				in the BOOLEANMEMBERS_IV database member.

	RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS OVEN_variousSettings_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD settings;
	DWORD mask;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	settings = 0;
	mask = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;

			settings = (DWORD)*((DWORD *)buff);
			
			mask = settings & ENERGY_STANDBY;
			if( 0 != mask )
			{
				g_dbContainer.ovenDb.mbEnergyStandy = TRUE;
			}
			else
			{
				g_dbContainer.ovenDb.mbEnergyStandy = FALSE;
			}

			mask = settings & ENERGY_COOLDOWN;
			if( 0 != mask )
			{
				g_dbContainer.ovenDb.mbEnergyCooldown = TRUE;
			}
			else
			{
				g_dbContainer.ovenDb.mbEnergyCooldown = FALSE;
			}

			mask = settings & CA3_WARNING_PARAM;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3Warning=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3Warning=FALSE;
			}

			mask = settings & CA3_ALARM_PARAM;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3Alarm=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3Alarm=FALSE;
			}

			mask = settings & CA3_AUDIBLE;
			if( 0 != mask )
			{
				g_dbContainer.alarmQueueDb.m_bAudibleCA3=TRUE;
			}
			else
			{
				g_dbContainer.alarmQueueDb.m_bAudibleCA3=FALSE;
			}

			mask = settings & CA3_DIST;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3Dist=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3Dist=FALSE;
			}

			mask = settings & CA3_CHECKED;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3Enabled = TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3Enabled = FALSE;
			}

			mask = settings & CA3_ACTIVE_HIGH;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3High=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3High=FALSE;
			}

			mask = settings & CA3_OUTPUT_WARN;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3WarningOutputs=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3WarningOutputs=FALSE;
			}

			mask = settings & CA3_OUTPUT_ALARM;
			if( 0 != mask )
			{
				g_dbContainer.purge.m_bCA3AlarmOutput=TRUE;
			}
			else
			{
				g_dbContainer.purge.m_bCA3AlarmOutput=FALSE;
			}

			mask = settings & LT_ACTIVE_HIGH;
			if( 0 != mask )
			{
				g_dbContainer.lightTower.bLTSpecialHigh = TRUE;	
			}
			else
			{
				g_dbContainer.lightTower.bLTSpecialHigh = FALSE;	
			}

			mask = settings & LT_L1;
			if( 0 != mask )
			{
				g_dbContainer.lightTower.bLT1 = TRUE;	
			}
			else
			{
				g_dbContainer.lightTower.bLT1 = FALSE;	
			}

			mask = settings & LT_L2;
			if( 0 != mask )
			{
				g_dbContainer.lightTower.bLT2=TRUE;
			}
			else
			{
				g_dbContainer.lightTower.bLT2=FALSE;
			}

			mask = settings & LT_L3;
			if( 0 != mask )
			{
				g_dbContainer.lightTower.bLT3=TRUE;
			}
			else
			{
				g_dbContainer.lightTower.bLT3=FALSE;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

NTSTATUS OVEN_standbyRTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = (DWORD)*((DWORD *)buff);
		g_dbContainer.ovenDb.mDenergyTime=time;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_standbyCoolTime_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = (DWORD)*((DWORD *)buff);
		g_dbContainer.ovenDb.mDenergyCoolTime=time;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_standbyInput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD input = (DWORD)*((DWORD *)buff);
		g_dbContainer.ovenDb.mDwrdEnergyInput=input;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS OVEN_energyRecipe_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL energy = (BOOL)*((BOOL *)buff);
		g_dbContainer.ovenDb.mbEnergyRecipe=energy;
		if(energy==FALSE)
			Oven_EnergyClearTime(&(g_dbContainer.ovenDb));
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS PURGE_CA3Input_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA3Input = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA3Output_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA3Output = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}	

NTSTATUS PURGE_CA3WarningTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA3WarningTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA3AlarmTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA3AlarmTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS PURGE_CA4Input_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA4Input = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA4Output_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA4Output = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}	

NTSTATUS PURGE_CA4WarningTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA4WarningTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA4AlarmTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA4AlarmTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS PURGE_CA5Input_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA5Input = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA5Output_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA5Output = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}	

NTSTATUS PURGE_CA5WarningTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA5WarningTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS PURGE_CA5AlarmTime_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.purge.m_dwrdCA5AlarmTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS OVEN_variousSettingsII_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		const DWORD settings = (DWORD)*((DWORD *)buff);

		if(settings & LT_L4)
		{
			g_dbContainer.lightTower.bLT4 = TRUE;
		}
		else
		{
			g_dbContainer.lightTower.bLT4 = FALSE;
		}

		if(settings & LT_ALL_LAMPS_OFF)
		{
			g_dbContainer.lightTower.bLampsOff=TRUE;
			LightTower_GreenLampOFF(&(g_dbContainer.lightTower));
			LightTower_AmberLampOFF(&(g_dbContainer.lightTower));
			LightTower_RedLampOFF(&(g_dbContainer.lightTower));

			LightTower_LT2_GreenLampOFF(&(g_dbContainer.lightTower));
			LightTower_LT2_AmberLampOFF(&(g_dbContainer.lightTower));
			LightTower_LT2_RedLampOFF(&(g_dbContainer.lightTower));
		}
		else
		{
			g_dbContainer.lightTower.bLampsOff=FALSE;
		}

		if(settings & LT_LAMP_MODE_AUTO)
		{
			g_dbContainer.lightTower.dwrdInputTimeStart=Timer_getCurrentTime10ths( &( g_dbContainer.elapseTimer ));
			g_dbContainer.lightTower.bLTSpecialMode=TRUE;
		}
		else
		{
			g_dbContainer.lightTower.bLTSpecialMode=FALSE;
		}

		if(settings & LT_LAMP_SOLID)
		{
			g_dbContainer.lightTower.bLTSpecialSolid=TRUE;
		}
		else
		{
			g_dbContainer.lightTower.bLTSpecialSolid=FALSE;
		}

		if(settings & ENERGY_GLOBAL_INTELEXHAUST)
		{
			g_dbContainer.ovenDb.m_EnergySaving_IntelExhaust_Enabled = TRUE;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_IntelExhaust_Enabled = FALSE;
		}

		if(settings & ENERGY_STDBY_MODE1)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_Enabled = TRUE;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_Enabled = FALSE;
		}

		if(settings & ENERGY_N2_OFF)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_N2Off = TRUE;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_N2Off = FALSE;
		}

		if(settings & ENERGY_N2_LOW)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_N2Low = TRUE;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_N2Low = FALSE;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_variousSettingsIII_Handler

			

 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_variousSettingsIII_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		const DWORD settings = (DWORD)*((DWORD *)buff);

		if(settings & ENERGY_STDBY_MODE1_CONVEYOR)
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_Conveyor_Enabled = TRUE;
		}
		else
		{
			g_dbContainer.ovenDb.m_EnergySaving_StandbyMode1_Conveyor_Enabled = FALSE;
		}

		if(settings & ENERGY_STDBY_MODE1_START)
		{
			Fans_toggleSMOne(&(g_dbContainer.globalBlower),&(g_dbContainer.analogFan),TRUE);
			HeatZoneBlower_toggleSMOne(&(g_dbContainer.heatZoneBlowers),TRUE);
		}

		if(settings & ENERGY_STDBY_MODE1_STOP)
		{
			Fans_toggleSMOne(&(g_dbContainer.globalBlower),&(g_dbContainer.analogFan),FALSE);
			HeatZoneBlower_toggleSMOne(&(g_dbContainer.heatZoneBlowers),FALSE);
		}

		if(settings & ENERGY_STDBY_LOAD_RECIPE)
		{
			g_dbContainer.ovenDb.m_EnergySaving_eStandbyMode2_LoadRecipe = TRUE;
		}

		if(settings & NO_COOLDOWN_ON_RISE_RATE)
		{
			TempZones_setRiseRateWarning(&(g_dbContainer.tempZonesDb), TRUE);
			g_dbContainer.fluxHeater.m_bRiseRateEnabled = TRUE;
			g_dbContainer.fluxHeater1.m_bRiseRateEnabled = TRUE;
			g_dbContainer.fluxHeater2.m_bRiseRateEnabled = TRUE;
			g_dbContainer.fluxHeater3.m_bRiseRateEnabled = TRUE;
			g_dbContainer.fluxHeater4.m_bRiseRateEnabled = TRUE;
		}
		else
		{
			TempZones_setRiseRateWarning(&(g_dbContainer.tempZonesDb), FALSE);
			g_dbContainer.fluxHeater.m_bRiseRateEnabled = FALSE;
			g_dbContainer.fluxHeater1.m_bRiseRateEnabled = FALSE;
			g_dbContainer.fluxHeater2.m_bRiseRateEnabled = FALSE;
			g_dbContainer.fluxHeater3.m_bRiseRateEnabled = FALSE;
			g_dbContainer.fluxHeater4.m_bRiseRateEnabled = FALSE;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS LIGHTTOWER_SpecialInput_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.lightTower.dwrdLTInput = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;
}

NTSTATUS LIGHTTOWER_TimeValue_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      int  nValue = *((int *)buff);

      g_dbContainer.lightTower.dwrdLTTime = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS LIGHTTOWER_LT2_Enable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		LightTower_LT2_SetEnable( &(g_dbContainer.lightTower), bEnable );
	}

	I->m_information = 0;

	return status;
}

NTSTATUS LIGHTTOWER_LT2_DO_Red_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT output = *((UINT *)buff);

		LightTower_LT2_SetDigitalOutput( &(g_dbContainer.lightTower), RED, output );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS LIGHTTOWER_LT2_DO_Yellow_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT output = *((UINT *)buff);

		LightTower_LT2_SetDigitalOutput( &(g_dbContainer.lightTower), AMBER, output );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS LIGHTTOWER_LT2_DO_Green_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT output = *((UINT *)buff);

		LightTower_LT2_SetDigitalOutput( &(g_dbContainer.lightTower), GREEN, output );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MASSANALOG_setOnTime_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS MASSANALOG_setOnTime_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD time = *((DWORD *)buff);
		MassController_setFlushTime(&(g_dbContainer.masscontroller), time);
	
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS BOARDQUEUE_setWarningDout_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(int); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
	DWORD index = *((DWORD *)(buff));
	DWORD nValue = *((DWORD *)(buff + sizeof(DWORD)));
	if(index<MAX_SMEMA_LANES)
	{
	      	g_dbContainer.purge.m_dwrdBoardWarningOutput[index] = nValue;
		if(nValue!=ODO_NULL)
	     		g_dbContainer.alarmQueueDb.m_bAudibleBoardWarnings[index] = TRUE;
		else
	     		g_dbContainer.alarmQueueDb.m_bAudibleBoardWarnings[index] = FALSE;
	}
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;  
   }

   I->m_information = 0;
   return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_panalIdEnable_Handler

			Enables/Disables the PANELID Board Event Handling.
			(Pegatron).

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_panalIdEnable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	BOOL bVal;
	char* buff;

	status = STATUS_SUCCESS;
	buffSize = sizeof(BOOL);
	bVal = FALSE;
	buff = NULL;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char*)I->m_ioctlBuffer;
			if(buff != NULL)
			{
				bVal = *( ( BOOL* )( buff ) );
				g_bPanelIDEnable = bVal;
			}
			else
			{
				buffSize = 0;
				status = STATUS_DATA_ERROR;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BOARDQUEUE_lotProcessingEnable_Handler

			Enables/Disables the Lot Tracking facilities.

 RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BOARDQUEUE_lotProcessingEnable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	BOOL bVal;
	char* buff;
	BOOL bChangeState;

	status = STATUS_SUCCESS;
	buffSize = sizeof(BOOL);
	bVal = FALSE;
	buff = NULL;
	bChangeState = FALSE;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char*)I->m_ioctlBuffer;
			if(buff != NULL)
			{
				bVal = *( ( BOOL* )( buff ) );

				if( bVal != g_bLotProcessingEnable )
				{
					bChangeState = TRUE;
				}

				g_bLotProcessingEnable = bVal;

				if( TRUE == bChangeState )
				{
					/* Lot Tracking is changing state, so make any
					   previously Active board queue Inactive
					*/
					if( FALSE == g_bLotProcessingEnable)
					{
						g_dbContainer.boardQ0.boardQueueActive = FALSE;
						g_dbContainer.boardQ1.boardQueueActive = FALSE;
						g_dbContainer.boardQ2.boardQueueActive = FALSE;
						g_dbContainer.boardQ3.boardQueueActive = FALSE;
					}
					else
					{
						g_dbContainer.boardQ0_NoLP.boardQueueActive = FALSE;
						g_dbContainer.boardQ1_NoLP.boardQueueActive = FALSE;
						g_dbContainer.boardQ2_NoLP.boardQueueActive = FALSE;
						g_dbContainer.boardQ3_NoLP.boardQueueActive = FALSE;
					}
				}
			}
			else
			{
				buffSize = 0;
				status = STATUS_DATA_ERROR;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RAILS_HardwarePause_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RAILS_HardwarePause_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS; 
   g_dbContainer.railsDb.bHardwarePause = TRUE;

   I->m_information = 0;
   return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RAILS_HardwareResume_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RAILS_HardwareResume_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   g_dbContainer.railsDb.bHardwarePause = FALSE;

   I->m_information = 0;
   return status;

}
NTSTATUS RAILS_railsInHardwareMode_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	DWORD retVal = (DWORD)Rails_railsInHardwareMode(&(g_dbContainer.railsDb));
	
	*((DWORD *)I->m_ioctlBuffer) = retVal;
	
	I->m_information = sizeof(DWORD);
	return status;
}
NTSTATUS TEMPZONE_PIDsetPbCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD index = (DWORD)*((DWORD *)buff);
		DWORD P = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);

			PIDController_pidSetPbCool(&(pTZ->pidCtrl), P);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;


}
NTSTATUS TEMPZONE_PIDsetTiCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD index = (DWORD)*((DWORD *)buff);
		DWORD I = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);

			PIDController_pidSetTiCool(&(pTZ->pidCtrl), I);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS TEMPZONE_PIDsetTdCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD index = (DWORD)*((DWORD *)buff);
		DWORD D = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			PIDController_pidSetTdCool(&(pTZ->pidCtrl), D);

		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;


}
NTSTATUS TEMPZONES_setCoolCycle_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD per= *((BOOL *)buff);
		TempZones_setCoolPeriod(&(g_dbContainer.tempZonesDb), per);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


NTSTATUS TEMPZONE_SetCoolOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);
		DWORD output = *((DWORD*)(buff + sizeof(DWORD)));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			TempZone_setCoolOutput(pTZ, output);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONE_GetCoolingPercentage_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONE_GetCoolingPercentage_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			DWORD nPercent = pTZ->pidCtrl.mCoolingOutputPercentX100;
			*((DWORD *)buff) = nPercent;
			buffSize = sizeof(DWORD);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


NTSTATUS TEMPZONE_SetCoolOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD SP0 = (DWORD)*((DWORD *)buff);
		DWORD index = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			PIDController_setCoolSPOffset(&(pTZ->pidCtrl), SP0);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS TEMPZONE_SetCoolOnOff_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD SP0 = (DWORD)*((DWORD *)buff);
		DWORD index = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		if(index<MaxTempZones&&index>=0)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			PIDController_setCoolOnOff(&(pTZ->pidCtrl), SP0);
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}


NTSTATUS RAILS_getCountPerCM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(UINT);
	DWORD retVal = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		if(index <MaxRails)
		{
			retVal=g_dbContainer.railsDb.pulseCounts[index];
		}
		*((DWORD *)buff) = retVal;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS CBS_enable_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		UINT index = *((UINT *)buff);
		DWORD enabled = *((DWORD *)(buff + sizeof(UINT)));
		
		switch(index)
		{
		case 0:
			g_dbContainer.cbs.cbs1Enabled=enabled;
		break;
		case 1:
			g_dbContainer.cbs.cbs2Enabled=enabled;		
		break;
		default:
			status = STATUS_DRIVER_INTERNAL_ERROR;
		break;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_CooldownSequenced_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONES_CooldownSequenced_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD off = *((DWORD *)buff);
		DWORD index = 0;
		for(index=0; index<MaxTempZones; index++)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			PIDController_CooldownSequenced(&(pTZ->pidCtrl), off);
		}
		FluxHeater* ptrFlux;
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 0);
		FluxHeater_CooldownSequenced(ptrFlux, off);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 1);
		FluxHeater_CooldownSequenced(ptrFlux, off);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 2);
		FluxHeater_CooldownSequenced(ptrFlux, off);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 3);
		FluxHeater_CooldownSequenced(ptrFlux, off);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 4);
		FluxHeater_CooldownSequenced(ptrFlux, off);

	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TEMPZONES_CooldownCooling_Handler


 GLOBALS:
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS TEMPZONES_CooldownCooling_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD on = *((DWORD *)buff);
		DWORD index = 0;
		for(index=0; index<MaxTempZones; index++)
		{
			TempZone* pTZ = TempZones_GetZone(&(g_dbContainer.tempZonesDb), index);
			PIDController_coolingInCooldown(&(pTZ->pidCtrl), on);
		}
		FluxHeater* ptrFlux;
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 0);
		FluxHeater_coolingInCooldown(ptrFlux, on);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 1);
		FluxHeater_coolingInCooldown(ptrFlux, on);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 2);
		FluxHeater_coolingInCooldown(ptrFlux, on);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 3);
		FluxHeater_coolingInCooldown(ptrFlux, on);
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 4);
		FluxHeater_coolingInCooldown(ptrFlux, on);

//		TempZones_coolingInCooldown(&(g_dbContainer.tempZonesDb), on);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

NTSTATUS FLUXHEATER_PIDsetPbCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD proband = *((DWORD *)buff);
		DWORD index = *((DWORD*)(buff + sizeof(DWORD)));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);

		FluxHeater_pidSetPbCool(ptrFlux, proband);
		buffSize = sizeof(DWORD);
		*((DWORD *)buff) = 1;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;


}
NTSTATUS FLUXHEATER_PIDsetTiCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD ti= *((DWORD *)buff);
		DWORD index = *((DWORD*)(buff + sizeof(DWORD)));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);

		FluxHeater_pidSetTiCool(ptrFlux, ti);
		buffSize = sizeof(DWORD);
		*((DWORD *)buff) = 1;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS FLUXHEATER_PIDsetTdCool_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD td= *((DWORD *)buff);
		DWORD index = *((DWORD*)(buff + sizeof(DWORD)));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);
		FluxHeater_pidSetTdCool(ptrFlux, td);
		buffSize = sizeof(DWORD);
		*((DWORD *)buff) = 1;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS FLUXHEATER_SetCoolOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD output = *((DWORD *)buff);
		DWORD index = *((DWORD*)(buff + sizeof(DWORD)));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);
		FluxHeater_setCoolOutput(ptrFlux, output);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}
NTSTATUS FLUXHEATER_GetCoolingPercentage_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);

		DWORD nPercent = ptrFlux->mCoolingOutputPercentX100;
		*((DWORD *)buff) = nPercent;
		buffSize = sizeof(DWORD);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS FLUXHEATER_SetCoolOffset_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD SP0 = (DWORD)*((DWORD *)buff);
		DWORD index = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);
		FluxHeater_setCoolSPOffset(ptrFlux, SP0);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
NTSTATUS FLUXHEATER_SetCoolOnOff_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD)+sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;

		DWORD SP0 = (DWORD)*((DWORD *)buff);
		DWORD index = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));
		FluxHeater* ptrFlux;	
		ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, index);

		FluxHeater_setCoolOnOff(ptrFlux, SP0);
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}

NTSTATUS PURGE_DOBCOption_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(DWORD); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      DWORD  nValue = *((DWORD *)buff);

      g_dbContainer.purge.mbBoardCountOption = nValue;
   }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS PURGE_DOBCAction_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(DWORD); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      DWORD  nValue = *((DWORD *)buff);

      g_dbContainer.purge.mbBoardCountAction = nValue;
    }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}
NTSTATUS PURGE_DOBCOutput_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(DWORD) * 2; 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
	  DWORD index = (DWORD)*((DWORD *)buff);
	  DWORD nValue = (DWORD)(*((DWORD*)(buff + sizeof(DWORD))));

	  if(index >= 0 && index <= MAX_SMEMA_LANES)
	  {
		g_dbContainer.purge.mbBoardCountOutput[index] = nValue;
	
	  }
   }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}

NTSTATUS PURGE_DOBCCount_Handler(KIrp* I)
{
   NTSTATUS status = STATUS_SUCCESS;
   UINT buffSize = sizeof(DWORD); 

   if(I->m_inputBufferSize >= buffSize)
   {
      char *buff = (char *)I->m_ioctlBuffer;
      DWORD  nValue = *((DWORD *)buff);

      g_dbContainer.purge.mbBoardCountCount = nValue;
   }
   else
   {
      status = STATUS_BUFFER_TOO_SMALL;
   }

   I->m_information = 0;
   return status;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ENERGYSAVING_IntelExhaust_Speed_Handler
			
			Sets  blower output for ie

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ENERGYSAVING_IntelExhaust_Speed_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 
	char *buff = NULL;
	DWORD  nValue = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		nValue = *((DWORD *)buff);
		Oven_SetStandbyModeIESpeed(nValue);

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ENERGYSAVING_StandbyMode1_ExhaustSpeed_Handler
			
			Sets blower speed for standby mode 1

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ENERGYSAVING_StandbyMode1_ExhaustSpeed_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 
	char* buff = NULL;
	DWORD  nValue = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		 nValue = *((DWORD *)buff);
		Oven_SetStandbyModeExhaustSpeed(nValue);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ENERGYSAVING_StandbyMode1_ZoneSpeed_Handler
			
			Sets zone speed for oven

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS ENERGYSAVING_StandbyMode1_ZoneSpeed_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 
	char* buff = NULL;
	DWORD  nValue = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		nValue = *((DWORD *)buff);
		Oven_SetStandbyModeZoneSpeed(nValue);

	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS ENERGYSAVING_StandbyMode1_ConveyorSpeed_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD  nValue = *((DWORD *)buff);
		DWORD index = *((DWORD*) (buff + sizeof(DWORD)));
		if(index < MaxBelts)
		{
			Belt_setStandbyCounts(&(g_dbContainer.belt[index]),nValue);
		}
		else if(index <(MaxBelts*2))//open loop
		{
			g_dbContainer.belt[(index-MaxBelts)].StandbySpeedInCMsPerMin=nValue;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS BELTS_setOpenLoopStandbyCounts_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) + sizeof(DWORD);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD nValue = *((DWORD*)buff);
		DWORD index = *((DWORD*)(buff + sizeof(DWORD)));
		if(index < MaxBelts)
		{
			Belt_standbyCountsOpenLoop(&(g_dbContainer.belt[index]),nValue);
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS BELTS_setDigitalStopSensor_Handler(KIrp *I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) * 2;

	if (I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD sensor = *(DWORD*)buff;
		DWORD index = *(DWORD*)(buff + sizeof(DWORD));
		if (index < MaxBelts)
		{
			Belt_setDigitalStopSensor(&(g_dbContainer.belt[index]), sensor);
		}
		else
		{
			status = STATUS_INVALID_PARAMETER;
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS LIGHTTOWER_SPChange_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherSPChange), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherSPChange), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherSPChange), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS LIGHTTOWER_Ready_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherReady), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherReady), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherReady), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS LIGHTTOWER_ReadyBoards_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherReadyBoards), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherReadyBoards), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherReadyBoards), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}


NTSTATUS LIGHTTOWER_Warning_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherWarning), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherWarning), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherWarning), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS LIGHTTOWER_Alarm_Cooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherAlarmCooldown), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherAlarmCooldown), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherAlarmCooldown), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}

NTSTATUS LIGHTTOWER_EStop_Cooldown_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(short);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		short  nValue = *((short *)buff);

		enum Light_States color = (enum Light_States) (nValue & 0x000F);
		BOOL bFlashing = (BOOL) ((nValue & 0x0030) >> 4);	// bottom two bits of nibble 1
		BOOL bAudible = (BOOL) ((nValue & 0x00C0) >> 6);	// top two bits of nibble 1

		Flasher_setFlasherColor( &(g_dbContainer.flasherEstopCooldown), color );
		Flasher_enableFlasher( &(g_dbContainer.flasherEstopCooldown), bFlashing );
		Flasher_setAudibleAlarm( &(g_dbContainer.flasherEstopCooldown), bAudible );
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_AlarmScannerOption_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS OVEN_AlarmScannerOption_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		g_dbContainer.ovenDb.mbAlarmScanner = bEnable;
		if(bEnable==TRUE)
		{
			g_dbContainer.analogInDb.miAlarmScanner=1;
		}
		else
		{
			g_dbContainer.analogInDb.miAlarmScanner=0;
		}
	
	}

	I->m_information = 0;

	return status;
}
NTSTATUS OVEN_AlarmScannerOutput_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD output = *((DWORD *)buff);

		g_dbContainer.ovenDb.miAlarmOutput = output;
	}

	I->m_information = 0;

	return status;

}
NTSTATUS OVEN_AlarmScannerState_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		g_dbContainer.ovenDb.mbAlarmState = bEnable;
	}

	I->m_information = 0;

	return status;

}
NTSTATUS OVEN_BarcodeReset_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD lane = *((DWORD *)buff);
		SMEMA_clearBarcode(&(g_dbContainer.smema1));

		switch(lane)
		{
			case 0:
			g_dbContainer.smema1.m_bIndvAllow=TRUE;
			g_dbContainer.ovenDb.skipClear=2;
			g_dbContainer.smema1.m_bBarcodeAllow=TRUE;
			break;
			case 1:
			g_dbContainer.smema2.m_bIndvAllow=TRUE;
			g_dbContainer.ovenDb.skipClear=2;
			g_dbContainer.smema2.m_bBarcodeAllow=TRUE;
			break;
			case 2:
			g_dbContainer.smema3.m_bIndvAllow=TRUE;
			g_dbContainer.ovenDb.skipClear=2;
			g_dbContainer.smema3.m_bBarcodeAllow=TRUE;
			break;
			case 3:
			g_dbContainer.smema4.m_bIndvAllow=TRUE;
			g_dbContainer.ovenDb.skipClear=2;
			g_dbContainer.smema4.m_bBarcodeAllow=TRUE;
			break;
		}
			

//		g_dbContainer.ovenDb. = lane;
	}

	I->m_information = 0;

	return status;
}
NTSTATUS OVEN_AlarmScannerHold_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL); 

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL *)buff);

		g_dbContainer.lightTower.mbScannerHold = bEnable;
	}

	I->m_information = 0;

	return status;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RAILS_masterSetpoint_Handler
			
			this encasulates several control messages sent when a rail setpoint
			is modified.  data is variable length depending on movement lock

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS RAILS_masterSetpoint_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL) + sizeof(UINT);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bAction = *((BOOL *)buff);
		UINT index = *((UINT *)(buff + sizeof(BOOL)));
		Rail* pRail = Rails_GetRail(&(g_dbContainer.railsDb), index);
		if(bAction == TRUE) //m_bRailLockout==true
		{
			buffSize = (sizeof(BOOL)*2)+sizeof(UINT)+sizeof(DWORD);
			if(I->m_inputBufferSize >= buffSize)
			{
				BOOL bMove = *((BOOL *)(buff + sizeof(BOOL)+sizeof(UINT)));
				DWORD nCounts = *((DWORD *)buff + (sizeof(BOOL)*2)+sizeof(UINT));

				Rail_setFalsePositionCounts(pRail, nCounts);
				Rails_setOpFromCoolRailMovement(&(g_dbContainer.railsDb), bMove);
			}
			else
			{
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
		else//m_bRailLockout==FALSE
		{
			buffSize = (sizeof(BOOL)*4)+sizeof(UINT)+sizeof(DWORD);
			if(I->m_inputBufferSize >= buffSize)
			{
				BOOL bMove = *((BOOL *)(buff + sizeof(BOOL)+sizeof(UINT)));
				DWORD presetPosition =  *((DWORD *)(buff + (sizeof(BOOL)*2)+sizeof(UINT)));
				BOOL bHomeIndicator = *((BOOL *)(buff + (sizeof(BOOL)*2)+sizeof(UINT)+sizeof(DWORD)));
				BOOL bSetOutputEnable = *((BOOL *)(buff + (sizeof(BOOL)*3)+sizeof(UINT)+sizeof(DWORD)));

				Rail_setOutputEnableFlag(pRail, bSetOutputEnable);
				Rails_queueSetPosition(&(g_dbContainer.railsDb), index, presetPosition,
											bHomeIndicator);
				Rail_setFalsePositionCounts(pRail, presetPosition);
				Rails_setOpFromCoolRailMovement(&(g_dbContainer.railsDb), bMove);
			}
			else
			{
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}
	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setInput_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setInput_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.barcodeInput=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setOutput_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setOutput_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.barcodeOutput=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setOutputR_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setOutputR_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doOutputs[0]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setOutputY_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setOutputY_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doOutputs[1]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setOutputG_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setOutputG_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doOutputs[2]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_boardScanned_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_boardScanned_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	BCIO_activateOutput(&(g_dbContainer.barcodeDio));
	UINT buffSize = 0;
	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setModeR_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setModeR_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doStates[0]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setModeY_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setModeY_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doStates[1]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setModeG_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setModeG_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);

		g_dbContainer.barcodeDio.doStates[2]=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setEnable_Handler

			Enables the Barcode Secs/Gem Option
			
 RETURNS:   void
------------------------------------------------------------------------*/
NTSTATUS BCIO_setEnable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD index;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	index = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((DWORD *)buff);

			g_dbContainer.barcodeDio.enabled=(BOOL)index;
		
			newBoardQueue_setBarcodeEvents_NoLP((BOOL)index);

			/* NOTE: Lot BCIO "Barcode Secs/Gem" is not supported
			   with Lot Tracking Enabled.
			*/

			buffSize = 0;
			I->m_information = buffSize;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setECEnable_Handler
		
			gemsec can write 3 digital outputs
			these are used to drive a second light tower setup

RETURNS:   NTSTATUS
------------------------------------------------------------------------*/
NTSTATUS BCIO_setECEnable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD index;
	BOOL bIndex;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	index = 0;
	bIndex = FALSE;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((DWORD *)buff);
			bIndex = (BOOL)index;
			BCIO_setLTOption(&(g_dbContainer.barcodeDio),bIndex);
			buffSize = 0;
			I->m_information = buffSize;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_setTime_Handler
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BCIO_setTime_Handler(KIrp* I)
{

	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD index = *((DWORD *)buff);
		g_dbContainer.barcodeDio.allowTime=index;
		buffSize = 0;
		I->m_information = buffSize;
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}




	
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MASS_PARAM_BEGIN_Handler
			
			system parameters and recipe parameters will be batch sent
			to the second hc2, this function flags beginning and end of sequence


 RETURNS:   void
------------------------------------------------------------------------*/
NTSTATUS MASS_PARAM_BEGIN_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;
	DWORD begin;
	UINT buffSize;
	DWORD dwrdInLaneCount[NUM_QUEUES] = {0};  //Leave this Init.

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	begin = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			begin = *((DWORD *)buff);
	
			if(begin)
			{
				if( FALSE == g_bLotProcessingEnable )
				{
					dwrdInLaneCount[0] = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP), 0); 
					dwrdInLaneCount[1] = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP), 0);
					dwrdInLaneCount[2] = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP), 0);
					dwrdInLaneCount[3] = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP), 0);
				}
				else
				{
					dwrdInLaneCount[0] = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0), 0); 
					dwrdInLaneCount[1] = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1), 0);
					dwrdInLaneCount[2] = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2), 0);
					dwrdInLaneCount[3] = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3), 0);
				}

				if(!dwrdInLaneCount[0] && !dwrdInLaneCount[1] && 
					!dwrdInLaneCount[2] && !dwrdInLaneCount[3]) //per Tushar continue hot job if there are boards in the oven, this prevents rail repositioning
				{
					Oven_setJob(&(g_dbContainer.ovenDb), COOLDOWN);//if the board was disconnected, it is possible a hot job was loaded
					//send to cooldown before programming
				}
				BoardEntryEvents_init(&(g_dbContainer.m_boardEvents));
			}
			else
			{
				DbContainer_slaveConfigure(&g_dbContainer, TRUE);
			}
			buffSize = 0;
			I->m_information = buffSize;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	else
	{
		status = STATUS_DRIVER_INTERNAL_ERROR;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MASSCONTROLLER_CONFIG_Handler
			
			configuration for the mass controllers, which are hz blowers on the
			secondary board
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS MASSCONTROLLER_CONFIG_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		DWORD settings = *((DWORD *)buff);
		DWORD dwOn = FALSE;
		if ( ( settings & MASS_UINT_A ) || ( settings & MASS_A ))
		{
			dwOn = TRUE;
		}
		else
		{
			dwOn = FALSE;
		}
		MassController_setEnable(&(g_dbContainer.masscontroller),0, dwOn);

		if ( ( settings & MASS_UINT_B ) || ( settings & MASS_B ))
		{
			dwOn = TRUE;
		}
		else
		{
			dwOn = FALSE;
		}
		MassController_setEnable(&(g_dbContainer.masscontroller),1, dwOn);


		if ( ( settings & MASS_UINT_C ) || ( settings & MASS_C ))
		{
			dwOn = TRUE;
		}
		else
		{
			dwOn = FALSE;
		}
		MassController_setEnable(&(g_dbContainer.masscontroller),2, dwOn);

		if ( ( settings & MASS_UINT_D ) || ( settings & MASS_D ))
		{
			dwOn = TRUE;
		}
		else
		{
			dwOn = FALSE;
		}
		MassController_setEnable(&(g_dbContainer.masscontroller),3, dwOn);

		if ( ( settings & MASS_UINT_E ) || ( settings & MASS_E ))
		{
			dwOn = TRUE;
		}
		else
		{
			dwOn = FALSE;
		}
		MassController_setEnable(&(g_dbContainer.masscontroller),4, dwOn);
	
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HEATZONEBLOWER_MAXIMUM_Handler
			
			assigns maximum values for blowers

 RETURNS:   NTSTATUS-sucess or too small
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS HEATZONEBLOWER_MAXIMUM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD) * 2;
	char* buff = NULL;
	DWORD max = 0;
	DWORD blowerGroup = 0;
	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		max = *((DWORD *)buff);
		blowerGroup = *((DWORD *)(buff + sizeof(DWORD)));
		if(blowerGroup < MAX_BLOWERS_INCLUDING_FANS)
		{
			Fans_setMaximumOutput(blowerGroup, max);
		}	
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BLOWER_GlobalHighLimit_Handler
			
			assigns maximum values for energy savings, used to set all blowers
 
 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BLOWER_GlobalHighLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	char* buff = NULL;
	DWORD max = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		max = *((DWORD *)buff);
		if(max <= MAXIMUM_PERCENTAGE)
		{
			g_dbContainer.ovenDb.m_EnergySaving_MaxBlower = max;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BLOWER_GlobalLowLimit_Handler
			
			assigns minimum values for energy savings, used to set all blowers

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS BLOWER_GlobalLowLimit_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	char* buff = NULL;
	DWORD min = 0;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		min = *((DWORD *)buff);
		if(min < MAXIMUM_PERCENTAGE)
		{
			g_dbContainer.ovenDb.m_EnergySaving_MinBlower = min;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BLOWER_GlobalLowStandbyLimit_Handler
			
			assigns minimum values for standby, used to set all blowers

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS BLOWER_GlobalLowStandbyLimit_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD min;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	min = 0;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			min = *((DWORD *)buff);
			if(min < MAXIMUM_PERCENTAGE)
			{
				g_dbContainer.ovenDb.m_Standby_MinBlower = min;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	return status;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BLOWER_GlobalHighStandbyLimit_Handler
			
			assigns maximum values for standby, used to set all blowers

 RETURNS:   NTSTATUS STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS BLOWER_GlobalHighStandbyLimit_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	char* buff;
	DWORD max;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	buff = NULL;
	max = 0;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			max = *((DWORD *)buff);
			if(max <= MAXIMUM_PERCENTAGE)
			{
				g_dbContainer.ovenDb.m_Standby_MaxBlower = max;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}

		I->m_information = buffSize;
	}
	return status;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FLUXHEATER_shutdownBlowers_Handler
			calls the shutdown blower routine which deactivates tpo for
			the fluxheater, also results in cooldown once the oven is empty

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
 SEE ALSO:
------------------------------------------------------------------------*/
NTSTATUS FLUXHEATER_shutdownBlowers_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL)+sizeof(UINT);
	FluxHeater* pFLUX = NULL;
	UINT index = 0;
	char* buff = NULL;

	if(I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;

		index = (UINT)(*((UINT*)(buff + sizeof(BOOL))));
		if( ( index < MaxTempZones ) && ( index >= 0 ) )
		{
			pFLUX = DbContainer_getCorrectFluxheater(&(g_dbContainer), index);
			if(pFLUX)
			{
				FluxHeater_blowerFailure(pFLUX, TRUE);
			}
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = buffSize;

	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_variousSettingsVII_Handler

			bundled boolean settings, used for APCO so far

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS OVEN_variousSettingsVII_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	FluxHeater* pFLUX;
	DWORD* ptrDword;
	DWORD dwrdBundle;
	DWORD enable;
	char* buff;
	DWORD dMask;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	pFLUX = NULL;
	enable = 0;
	ptrDword = NULL;
	dwrdBundle = 0;
	buff = NULL;
	dMask = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			
			if( buff != NULL )
			{
	
				ptrDword = (DWORD*)buff;
				
				dwrdBundle = (DWORD)(*(DWORD*)( buff ));
				dMask = dwrdBundle & APCO_OPTION;
				if( 0 != dMask )
				{
					enable = 1;
				}
				
				SMEMA_MESActivate(  enable, APCO_INDEX );
				
				if(!enable)
				{
					SMEMA_MESAllowed(1, APCO_INDEX);
				}
				else
				{
					dMask = dwrdBundle & APCO_RUNTIME_SETTING;
					if( 0 != dMask )
					{
						enable = 1;
					}
					else
					{
						enable = 0;
					}
	
					SMEMA_MESAllowed(enable, APCO_INDEX);
				}
				
				dMask = dwrdBundle & CONTROL_OUTPUT_RELAY_ENABLE;
				if( 0 != dMask )
				{
					enable = 1;
				}
				else
				{
					enable = 0;
				}
				
				TEMPZONES_setSGCEnable( enable );
				dMask = dwrdBundle & SECSGEM_ENTRY_CONTROL;
				if( 0 != dMask )
				{
					enable = 1;
				}
				else
				{
					enable = 0;
				}
				SMEMA_SecsGemEntryOption(&(g_dbContainer.smema1), enable);
				SMEMA_SecsGemEntryOption(&(g_dbContainer.smema2), enable);
				SMEMA_SecsGemEntryOption(&(g_dbContainer.smema3), enable);
				SMEMA_SecsGemEntryOption(&(g_dbContainer.smema4), enable);
				dMask = dwrdBundle & SECSGEM_WARN_RLT1;
				if( 0 != dMask )
				{
					ucLane1Secsgem = 1;
				}
				else
				{
					ucLane1Secsgem = 0;
				}	
				dMask = dwrdBundle & SECSGEM_WARN_RLT2;
				if( 0 != dMask )
				{
					ucLane2Secsgem = 1;
				}
				else
				{
					ucLane2Secsgem = 0;
				}	
			}
			else
			{
				buffSize = 0;
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  APCO_ValidScan_Handler

			Called when a file indicates the smema should go "on"

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS APCO_ValidScan_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	SMEMA_MESSmemaVariable(APCO_INDEX, APCO_INDEX);
	if(I)
	{
		I->m_information = 0;
	}
	return status;


}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  APCO_InvalidateScan_Handler

			Called when a job is changed or cooldown is loaded to disable smema seting

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS APCO_InvalidateScan_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	SMEMA_MESSmemaVariable(0, APCO_INDEX);
	
	if(I)
	{
		I->m_information = 0;
	}
	return status;


}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_APCORuntimeEnable_Handler

			setting in the main program that turns the option on/off

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS OVEN_APCORuntimeEnable_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	FluxHeater* pFLUX;
	DWORD enable;
	char* buff;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	pFLUX = NULL;
	enable = 0;
	buff = NULL;

	if(I)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			enable = (DWORD)(*(DWORD*)( buff ));
			SMEMA_MESAllowed(enable, APCO_INDEX);
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  TEMPZONES_setStartupGrpControlDO_Handler

				Set the Startup Group Controlled Digital Output

	RETURNS:	STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
--------------------------------------------------------------------*/
NTSTATUS TEMPZONES_setStartupGrpControlDO_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	DWORD* ptrDword;
	DWORD digitalOutput;
	char* buff;
	
	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	ptrDword = NULL;
	digitalOutput = ODO_NULL;
	buff = NULL;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			if( NULL != buff )
			{
				ptrDword = (DWORD*)buff;
				digitalOutput = *ptrDword;
				TEMPZONES_setSGCOutput(digitalOutput);
			}
			else
			{
				buffSize = 0;
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	
	return status;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  TEMPZONES_setStartupGrpControlGRP_Handler

				Set the Startup Group Controlled Ouput Startup Group

	RETURNS:	STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
--------------------------------------------------------------------*/
NTSTATUS TEMPZONES_setStartupGrpControlGRP_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	DWORD* ptrDword;
	DWORD group;
	char* buff;
	
	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	ptrDword = NULL;
	group = ODO_NULL;
	buff = NULL;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			if( NULL != buff )
			{
				ptrDword = (DWORD*)buff;
				group = *ptrDword;
				TEMPZONES_setSGCGroup(group);
			}
			else
			{
				buffSize = 0;
				status = STATUS_BUFFER_TOO_SMALL;
			}
				
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SMEMA_SecsGemControl_Handler

			turns entrance smema on/off per lane due to equipment constant

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS SMEMA_SecsGemControl_Handler(KIrp* I)
{
	NTSTATUS status;
	char* buff;

	UINT buffSize;
	DWORD* ptrDword;
	DWORD dIndex;
	DWORD dSetting;
	char cSetting;

	buff = NULL;
	status = STATUS_SUCCESS;

	buffSize = sizeof(DWORD) * 2;
	ptrDword = NULL;
	dIndex = 0;
	dSetting = 0;
	cSetting = 0;


	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			ptrDword = (DWORD*)buff;
			dIndex = ptrDword[0];
			dSetting = ptrDword[1];
			cSetting = (char)dSetting;
			switch(dIndex)
			{
				case 0:
					SMEMA_SecsGemSetting(&(g_dbContainer.smema1), cSetting);
					break;

				case 1:
					SMEMA_SecsGemSetting(&(g_dbContainer.smema2), cSetting);
					break;

				case 2:
					SMEMA_SecsGemSetting(&(g_dbContainer.smema3), cSetting);
					break;

				case 3:
					SMEMA_SecsGemSetting(&(g_dbContainer.smema4), cSetting);
					break;

				default:
					printk("error in secsgem control, wrong index\n");
					break;			
			}
			I->m_information = 0;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	return status;


}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GetBitPackedData_Handler

			routine to return boolean bit packs used for
			bit pos 0 conveyor blower output
			bit pos 1 - 4 entrance smema 1-4
			bit pos 8- 11 gemsec variable for entrance smema

			can be added to, will reduce packet size back to PC


 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS GetBitPackedData_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	BOOL readVal;
	char* buff;
	UINT index;
	DWORD dwrdReturn;

	status = STATUS_SUCCESS;
	buffSize = sizeof(UINT);
	buff = (char *)I->m_ioctlBuffer;
	index = *((UINT *)buff);	
	readVal = 0;
	dwrdReturn = 0;
	if(I!=NULL)
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			index = *((UINT *)buff);
			readVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_CONVEYOR_BLOWER);
			if(readVal)
			{
				dwrdReturn = BIT_CONVEYOR_BLOWER;
			}
			readVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_SMEMA1_ENTRANCE);
			if(readVal)
			{
				dwrdReturn |= BIT_SMEMA1_OUT;
			}
			readVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_SMEMA2_ENTRANCE);
			if(readVal)
			{
				dwrdReturn |= BIT_SMEMA2_OUT;
			}
			readVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_SMEMA3_ENTRANCE);
			if(readVal)
			{
				dwrdReturn |= BIT_SMEMA3_OUT;
			}
			readVal = *DOUT_GetAt(&(g_dbContainer.digitalOutDb), ODO_SMEMA4_ENTRANCE);
			if(readVal)
			{
				dwrdReturn |= BIT_SMEMA4_OUT;
			}
			if(g_dbContainer.smema1.cSecgemEntry || uc9851Lock1)
			{
				dwrdReturn |= BIT_SECSGEML1;
			}
			if(g_dbContainer.smema2.cSecgemEntry || uc9851Lock2)
			{
				dwrdReturn |= BIT_SECSGEML2;
			}
			if(g_dbContainer.smema3.cSecgemEntry || uc9851Lock3)
			{
				dwrdReturn |= BIT_SECSGEML3;
			}
			if(g_dbContainer.smema4.cSecgemEntry || uc9851Lock4)
			{
				dwrdReturn |= BIT_SECSGEML4;
			}
			*((DWORD *)buff) = dwrdReturn;
			buffSize = sizeof(DWORD);
	
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  OVEN_variousSettingsVIII_Handler

			bit packed settings
			bit pos 0 light tower setting secsgem warning 3
			bit pos 1 light tower setting secsgem warning 4


 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/

NTSTATUS OVEN_variousSettingsVIII_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	FluxHeater* pFLUX;
	DWORD* ptrDword;
	DWORD dwrdBundle;
	DWORD enable;
	char* buff;
	DWORD dMask;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	pFLUX = NULL;
	enable = 0;
	ptrDword = NULL;
	dwrdBundle = 0;
	buff = NULL;
	dMask = 0;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			
			if( buff != NULL )
			{
	
				ptrDword = (DWORD*)buff;
				
				dwrdBundle = (DWORD)(*(DWORD*)( buff ));
				dMask = dwrdBundle & SECSGEM_WARN_RLT3;
				if( 0 != dMask )
				{
					ucLane3Secsgem = 1;
				}
				else
				{
					ucLane3Secsgem = 0;
				}

				dMask = dwrdBundle & SECSGEM_WARN_RLT4;
				if( 0 != dMask )
				{
					ucLane4Secsgem = 1;
				}
				else
				{
					ucLane4Secsgem = 0;
				}

				dMask = dwrdBundle & SECSGEM_AUDIBLE1;
				if( 0 != dMask )
				{
					ucLane1Audible = 1;
				}
				else
				{
					ucLane1Audible = 0;
				}

				dMask = dwrdBundle & SECSGEM_AUDIBLE2;
				if( 0 != dMask )
				{
					ucLane2Audible = 1;
				}
				else
				{
					ucLane2Audible = 0;
				}

				dMask = dwrdBundle & SECSGEM_AUDIBLE3;
				if( 0 != dMask )
				{
					ucLane3Audible = 1;
				}
				else
				{
					ucLane3Audible = 0;
				}

				dMask = dwrdBundle & SECSGEM_AUDIBLE4;
				if( 0 != dMask )
				{
					ucLane4Audible = 1;
				}
				else
				{
					ucLane4Audible = 0;
				}

			}
			else
			{
				buffSize = 0;
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;
}

NTSTATUS OVEN_variousSettingsX_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(DWORD);
	DWORD dwrdBundle = 0;
	char* buff = NULL;

	if (I->m_inputBufferSize >= buffSize)
	{
		buff = (char *)I->m_ioctlBuffer;
		if (buff != NULL)
		{
			dwrdBundle = *(DWORD*)buff;

			if (dwrdBundle & X_CA4_WARNING)
				g_dbContainer.purge.m_bCA4Warning = TRUE;
			else
				g_dbContainer.purge.m_bCA4Warning = FALSE;
			if (dwrdBundle & X_CA4_ALARM)
				g_dbContainer.purge.m_bCA4Alarm = TRUE;
			else
				g_dbContainer.purge.m_bCA4Alarm = FALSE;
			if (dwrdBundle & X_CA4_AUDIBLE_WARN)
				g_dbContainer.alarmQueueDb.m_bAudibleCA4 = TRUE;
			else
				g_dbContainer.alarmQueueDb.m_bAudibleCA4 = FALSE;
			if (dwrdBundle & X_CA4_DISTANCE_BASED)
				g_dbContainer.purge.m_bCA4Dist = TRUE;
			else
				g_dbContainer.purge.m_bCA4Dist = FALSE;
			if (dwrdBundle & X_CA4_CHECKED)
				g_dbContainer.purge.m_bCA4Enabled = TRUE;
			else
				g_dbContainer.purge.m_bCA4Enabled = FALSE;
			if (dwrdBundle & X_CA4_ACTIVE_HIGH)
				g_dbContainer.purge.m_bCA4High = TRUE;
			else
				g_dbContainer.purge.m_bCA4High = FALSE;
			if (dwrdBundle & X_CA4_OUTPUT_WARN)
				g_dbContainer.purge.m_bCA4WarningOutputs = TRUE;
			else
				g_dbContainer.purge.m_bCA4WarningOutputs = FALSE;
			if (dwrdBundle & X_CA4_OUTPUT_ALARM)
				g_dbContainer.purge.m_bCA4AlarmOutput = TRUE;
			else
				g_dbContainer.purge.m_bCA4AlarmOutput = FALSE;

			if (dwrdBundle & X_CA5_WARNING)
				g_dbContainer.purge.m_bCA5Warning = TRUE;
			else
				g_dbContainer.purge.m_bCA5Warning = FALSE;
			if (dwrdBundle & X_CA5_ALARM)
				g_dbContainer.purge.m_bCA5Alarm = TRUE;
			else
				g_dbContainer.purge.m_bCA5Alarm = FALSE;
			if (dwrdBundle & X_CA5_AUDIBLE_WARN)
				g_dbContainer.alarmQueueDb.m_bAudibleCA5 = TRUE;
			else
				g_dbContainer.alarmQueueDb.m_bAudibleCA5 = FALSE;
			if (dwrdBundle & X_CA5_DISTANCE_BASED)
				g_dbContainer.purge.m_bCA5Dist = TRUE;
			else
				g_dbContainer.purge.m_bCA5Dist = FALSE;
			if (dwrdBundle & X_CA5_CHECKED)
				g_dbContainer.purge.m_bCA5Enabled = TRUE;
			else
				g_dbContainer.purge.m_bCA5Enabled = FALSE;
			if (dwrdBundle & X_CA5_ACTIVE_HIGH)
				g_dbContainer.purge.m_bCA5High = TRUE;
			else
				g_dbContainer.purge.m_bCA5High = FALSE;
			if (dwrdBundle & X_CA5_OUTPUT_WARN)
				g_dbContainer.purge.m_bCA5WarningOutputs = TRUE;
			else
				g_dbContainer.purge.m_bCA5WarningOutputs = FALSE;
			if (dwrdBundle & X_CA5_OUTPUT_ALARM)
				g_dbContainer.purge.m_bCA5AlarmOutput = TRUE;
			else
				g_dbContainer.purge.m_bCA5AlarmOutput = FALSE;
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	}
	else
	{
		buffSize = 0;
		status = STATUS_BUFFER_TOO_SMALL;
	}
	
	I->m_information = buffSize;
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  SECSGEM_Entry_option_Handler

			bundled boolean settings, used for APCO so far

 RETURNS:   NTSTATUS-STATUS_SUCCESS or STATUS_BUFFER_TOO_SMALL
------------------------------------------------------------------------*/
NTSTATUS SECSGEM_Entry_option_Handler(KIrp* I)
{
	NTSTATUS status;
	UINT buffSize;
	DWORD* ptrDword;
	DWORD dwrdBundle;
	char* buff;

	status = STATUS_SUCCESS;
	buffSize = sizeof(DWORD);
	ptrDword = NULL;
	dwrdBundle = 0;
	buff = NULL;

	if( NULL != I )
	{
		if(I->m_inputBufferSize >= buffSize)
		{
			buff = (char *)I->m_ioctlBuffer;
			
			if( buff != NULL )
			{
				ptrDword = (DWORD*)buff;		
				dwrdBundle = (DWORD)(*(DWORD*)( buff ));
				if(dwrdBundle)
				{
					g_ucSecsgemOptionSetTo = 1;
					g_ucSetSecsgemOption = 1;
				}
				else
				{
					g_ucSecsgemOptionSetTo = 0;
					g_ucSetSecsgemOption = 1;
				}
			}
			else
			{
				buffSize = 0;
				status = STATUS_BUFFER_TOO_SMALL;
			}
		}
		else
		{
			buffSize = 0;
			status = STATUS_BUFFER_TOO_SMALL;
		}
	
		I->m_information = buffSize;
	}
	return status;
}

NTSTATUS IOCTL_GATHER_TDM_EEPROM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = 0;
	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
	UINT index = 0;
	UINT inBuffSize =(sizeof(DWORD)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
		DWORD tdm = *((DWORD *)(buff));
		for(index=0; index<EEPROM_SIZE; index++)
		{
			if(tdm<2)	
			{
				retVal[index] = IOANALOGIN_GetMem(&analogInDb, index, tdm);
			}

			*((DWORD *)(buff+buffSize)) = retVal[index];
			buffSize += sizeof(DWORD);
		}
	}
	I->m_information = buffSize;
	return status;
}

NTSTATUS IOCTL_SET_TDM_EEPROM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
//	UINT buffSize = 0;
//	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
//	UINT index = 0;
	UINT inBuffSize =((sizeof(DWORD)*2)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
		DWORD loc = *((DWORD *)(buff));
		DWORD val = *((DWORD *)(buff + sizeof(DWORD)));
		Tdm_writeEEPromBuffer(val, loc);
	}
	I->m_information = 0;
	return status;
}

NTSTATUS IOCTL_PROGRAM_TDM_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
//	UINT buffSize = 0;
//	DWORD retVal[EEPROM_SIZE]={0};
	char *buff = (char *)I->m_ioctlBuffer;
//	UINT index = 0;
	UINT inBuffSize =(sizeof(DWORD)); 

	if(I->m_inputBufferSize >= inBuffSize)
	{	
		DWORD tdm = *((DWORD *)(buff));
		IOANALOGIN_ProgramTDM((IOANALOGIN*)tdm, 0); // fjn -- v5.5.0.18 source does not show second argument, total mismatch with prototype
//		TDM_commitMapToEEPROM(tdm);
	}
	I->m_information = 0;
//	ANALOGIN_SetOffsetAt(&(g_dbContainer.analogInDb), AI_FREE_L2SR, 0);
	return status;
}

////////////////////////////////////////////////////////////////////////
//  OVEN_setBeltStopWhenRailMoving_Handler
//
//	Routine Description:
//		Enables m_bBeltStopWhenRailMoving for the Oven
//
//	Parameters:
//		I - IRP containing IOCTL request
//			BOOL - bEnable.
//
//		Output buffer contains:
//
//	Return Value:
//		NTSTATUS - Status code indicating success or failure
//
//	Comments: ver8.0.0.18
//
//  Author: Tushar Patel

NTSTATUS OVEN_setBeltStopWhenRailMoving_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;
	UINT buffSize = sizeof(BOOL);

	if(I->m_inputBufferSize >= buffSize)
	{
		char *buff = (char *)I->m_ioctlBuffer;
		BOOL bEnable = *((BOOL*)buff);
		Oven_setBeltStopWhenRailMoving(&(g_dbContainer.ovenDb), bEnable);
	}
	else
	{
		status = STATUS_BUFFER_TOO_SMALL;
	}

	I->m_information = 0;

	return status;
}

NTSTATUS OVEN_recipeLoadBoardEntryWait_Handler(KIrp* I)
{
	NTSTATUS status = STATUS_SUCCESS;

	if (I->m_inputBufferSize >= sizeof(DWORD))
		Oven_recipeLoadBoardEntryWait(&(g_dbContainer.ovenDb), *(DWORD*)I->m_ioctlBuffer);
	else
		status = STATUS_BUFFER_TOO_SMALL;

	I->m_information = 0;

	return status;
}
