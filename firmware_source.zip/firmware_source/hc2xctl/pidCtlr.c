/****************************************************************************
	Heller industries, Inc.
	imagic, Inc.    Copyright (C) 2006 - 2016, All Rights Reserved
                   Company Confidential

	File:			pidCtlr.c

	Description:	pid master, moved to tempzones
                                                                                                                 
   This is a trade secret of imagic, inc. and Heller Industries, Inc
   and is protected by copyright.All unauthorized uses prohibited.
// 12-Sep-16 TP   Update PIDController_checkAlarmBands() to include disableDevAlarmInStartup
// 08-Feb-18 TP   Update PIDController_checkSelfAcknowledgeAlarms() to address zone color issue for heat zones on secondary HC2, ver8.0.0.28
***************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "pidCtlr.h"
#include "xpdriverdevice.h"
#include "contain.h"
#include "typedefdefine.h"
#include "hellerenumerations.h"
#include "xpdriverioctl.h"
#include "pid.h"
#include "timer.h"
#include "oven.h"
#include "digitio.h"
#include "tpo.h"
#include "hc2xio_exports.h"

extern DbContainer g_dbContainer;
AlarmQueue        * alarmQueueDb;
ANALOGIN          * analogInDb;
ANALOGOUT         * analogOutDb;
Timer          	* timerDb;
Oven           * ovenDb;
DOUT		* digOutDb;
TempZones			* tempZonesDb;	// reference to container ie parent.


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_init
			
			main init routine for pid controller
 RETURNS:   void
------------------------------------------------------------------------*/
void PIDController_init(PIDController* pPID, int zoneNo, BOOL bLocalZone)
{
	if(pPID)
	{
		analogInDb = &( g_dbContainer.analogInDb );
		analogOutDb = &( g_dbContainer.analogOutDb );
		timerDb = &( g_dbContainer.elapseTimer );
		ovenDb = &( g_dbContainer.ovenDb );
		alarmQueueDb = &( g_dbContainer.alarmQueueDb );
		tempZonesDb = &( g_dbContainer.tempZonesDb );
		digOutDb = &(g_dbContainer.digitalOutDb);
		pPID->coolOutput		= (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);// 1 higher than allowable range
		pPID->pidEnabled		= FALSE;
		pPID->zoneAuto			= eOFF;
		pPID->bZoneActive		= FALSE;
		pPID->zoneNo 			= zoneNo;
		pPID->groupNo 			= 0;
		pPID->sp					= 0;
		pPID->pv					= 0;
		pPID->tpoOutput		= 0;
		pPID->m_nTPOoutput 	= NULL_OUTPUT_POINTER;
		pPID->pTcInput 		= &(pPID->dummyValue);
		pPID->pTPOoutput 		= &(pPID->dummyValue);
		pPID->m_nTcInput 		= 0;
		pPID->dwrdOurOutput 	= 0;
		pPID->previousJobNo	= COOLDOWN;
		pPID->bLocalZone = bLocalZone;
	
		pPID->printkDelay = 0;
		pPID->coolSP=0;
		pPID->coolSPOffset=0;

		PID_init(&(pPID->pid), &(pPID->sp), 
			&(pPID->pv), 
			&(pPID->tpoOutput), Reverse);
		PID_init(&(pPID->coolPID), &(pPID->coolSP), &(pPID->pv), &(pPID->tpoOutputCooling), Direct);
		pPID->m_bOff=TRUE;
		pPID->m_bSuspended=FALSE;
		pPID->m_bSetpointSendFailed=FALSE;
		pPID->bRetry = 1;

		pPID->htAlarmEnable	= TRUE;
		pPID->ltAlarmEnable	= TRUE;
		pPID->htWarnEnable	= TRUE;
		pPID->ltWarnEnable	= TRUE;

		pPID->globalhp 		= DEFAULT_GLOBAL_HIGH_PROCESS;

		pPID->dwrdTPOWithoutPID=0;
		pPID->bTPOTimeStampTaken=FALSE;
		pPID->bTPOOffDueToLackOfPID=FALSE;

		pPID->alarmBandsEnabled = FALSE;

		pPID->inDeadBand = FALSE;
		pPID->m_bDoRiseRateCheck = FALSE;

		pPID->currentTime = 0;

		pPID->m_bPowerUpDelayElapsed = FALSE;

		pPID->hiProcAlarmEnable	= TRUE;
		pPID->loProcAlarmEnable	= TRUE;
		pPID->highProcess			= DEFAULT_HIGH_PROCESS;
		pPID->lowProcess			= 0;
		pPID->alarmHighTempOffset	= (DWORD)DEFAULT_ALARM_BAND;
		pPID->alarmLowTempOffset	= (DWORD)DEFAULT_ALARM_BAND;
		pPID->warnHighTempOffset	= (DWORD)DEFAULT_WARN_BAND;
		pPID->warnLowTempOffset	= (DWORD)DEFAULT_WARN_BAND;
		pPID->deadBandHighTempOffset	= (DWORD)DEFAULT_DEAD_BAND;
		pPID->deadBandLowTempOffset	= (DWORD)DEFAULT_DEAD_BAND;

		pPID->selfAckAlarmNo		 = 0;

		pPID->m_dwrdHiProcDelay = 0;
		pPID->m_bHiProcCountdownOn = FALSE;
		pPID->m_dwrdHiProcBeginTime = 0;
		pPID->m_bInternalTestForDrawWarning = TRUE;

		pPID->deadBandEnableStatus = FALSE;
		pPID->m_bOpenThermocouple = FALSE;
		pPID->saFromSlave=0;

		pPID->riseRateSetPointChange = FALSE;
		pPID->riseRateDelayStartTime = 0;
		pPID->zoneInactiveToActiveTransition = FALSE;
		pPID->currentTooth=1;
		pPID->tpoOutputCooling=0;  
		pPID->coolOnOff=0;
		pPID->period=DEFAULT_COOLING_PERIOD;
		pPID->mDwrdOutput=0;
		pPID->mCoolingOutputPercentX100=0;
		pPID->mCoolingOnInCooldown=0;
		pPID->mbSequence=TRUE;
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_configureSlaveIO
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void PIDController_configureSlaveIO(PIDController* pPID)
{
	const DWORD ovenModel = Oven_getModelNo(ovenDb);
	DWORD index = PIDController_getSecondBoardIndex(pPID);
	UINT aiIndex = 0;
	UINT aoIndex = 0;

	if ( pPID )
	{
		if ( ovenModel == e2060_OVENMODELS )
		{
			switch (index )
			{
				case 0:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 13;
					break;
	
				case 1:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 13;
					break;
	
				case 2:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 14;
					break;
	
				case 3:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 14;
					break;
	
				case 4:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ3);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 15;
					break;
	
				case 5:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ3);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 15;
					break;
	
				case 6:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 16;
					break;
	
				case 7:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 16;
					break;
	
				case 8:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 17;
					break;
	
				case 9:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 17;
					break;
	
				case 10:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ6);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ6);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 18;
					break;
	
				case 11:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ6);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ6);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 18;
					break;
	
				case 12:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ7);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ7);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 19;
					break;
	
				case 13:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ7);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ7);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 19;
					break;
	
				case 14:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ8);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ8);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 20;
					break;
	
				case 15:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ8);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ8);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 20;
					break;
	
				case 16:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ9);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ9);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 21;
					break;
	
				case 17:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ9);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ9);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 21;
					break;
	
				case 18:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ10);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ10);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 22;
					break;
	
				case 19:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ10);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ10);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 22;
					break;
	
				case 20:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ11);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ11);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 23;
					break;
	
				case 21:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ11);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ11);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 23;
					break;
	
				case 22:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ12);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ12);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 24;
					break;
	
				case 23:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ12);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ12);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 24;
					break;
	
	
				case 24:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_FREE_L1SR);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_FREECL1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 25;
					break;
	
				case 25:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_FREE_L2SR);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_FREECL2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 25;
					break;
	
				case 26:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT4);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_CONVBELT2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 26;
					break;
	
				case 27:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT5);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_AVAILABLE);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 26;
					break;
	
				case 28:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT3);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_ANALOG_FAN);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 27;
					break;
	
				case 29:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_EXHAUST_FLUX_HEATER);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_EXHAUST_FLUX_HEATER);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 27;
					break;
	
				case 30:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT1);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_CONVBELT1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 28;
					break;
	
				case 31:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT2);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_GLOBAL_BLOWER_CONTROL);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 28;
					break;
	
				default:
					pPID->tpoOutput     = 0;
					pPID->m_nTPOoutput  = NULL_OUTPUT_POINTER;
					pPID->pTcInput      = &(pPID->dummyValue);
					pPID->pTPOoutput    = &(pPID->dummyValue);
					pPID->m_nTcInput    = 0;
					pPID->dwrdOurOutput = 0;
					break;
			}
		}
		else
		{
			switch ( index )
			{
				case 0:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 13;
					break;
	
				case 1:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 13;
					break;
	
				case 2:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 14;
					break;
	
				case 3:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 14;
					break;
	
				case 4:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ3);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 15;
					break;
	
				case 5:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ3);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 15;
					break;
	
				case 6:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 16;
					break;
	
				case 7:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 16;
					break;
	
				case 8:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 17;
					break;
	
				case 9:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 17;
					break;
	
				case 10:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ6);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ6);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 18;
					break;
	
				case 11:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ6);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ6);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 18;
					break;
	
				case 12:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ7);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ7);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 19;
					break;
	
				case 13:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ7);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ7);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 19;
					break;
	
				case 14:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ8);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ8);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 20;
					break;
	
				case 15:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ8);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ8);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 20;
					break;
	
				case 16:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ9);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ9);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 21;
					break;
	
				case 17:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ9);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ9);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 21;
					break;
	
				case 18:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ10);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ10);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 22;
					break;
	
				case 19:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ10);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ10);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 22;
					break;
	
				case 20:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ11);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ11);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 23;
					break;
	
				case 21:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ11);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ11);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 23;
					break;
	
				case 22:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ12);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ12);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 24;
					break;
	
				case 23:
					aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ12);
					aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ12);
					pPID->pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
					pPID->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
					pPID->m_nTPOoutput = aoIndex;
					pPID->groupNo = 24;
					break;
	
				default:
					pPID->tpoOutput     = 0;
					pPID->m_nTPOoutput  = NULL_OUTPUT_POINTER;
					pPID->pTcInput      = &(pPID->dummyValue);
					pPID->pTPOoutput    = &(pPID->dummyValue);
					pPID->m_nTcInput    = 0;
					pPID->dwrdOurOutput = 0;
					break;
			}
		}

		pPID->m_nTcInput = aiIndex;
		pPID->dwrdOurOutput = aoIndex;
	}
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_calcPid
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void PIDController_calcPid(PIDController* pPID)
{
	PID_calcPID(&(pPID->pid));

	if( pPID->coolOutput< (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		if(pPID->coolOnOff==0)
		{
			PID_calcPID(&(pPID->coolPID));
		}
		else  //on off direct for now
		{
			if(pPID->coolSP<pPID->pv)
			{
				pPID->tpoOutputCooling=256;
			}
			else
			{
				pPID->tpoOutputCooling=0;
			}
		}
	}		
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setStartState

				This will enable the controller and set the output to 100%, used when sequencing
				on

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setStartState(PIDController* pPID, BOOL bOn)
{
	pPID->m_bOff = bOn;
	
	if(bOn==TRUE)
	{
		pPID->tpoOutput = MAX_TPO_COUNTS;
		PIDController_setPidEnable(pPID, TRUE);
	}
	else
	{
		pPID->tpoOutput = 0;
		PIDController_setPidEnable(pPID, FALSE);
	}

}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setZoneMode



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setZoneMode(PIDController* pPID, enum ZoneTriState mode)
{	
	if ( pPID->zoneAuto != eAUTO && mode == eAUTO )
	{
		pPID->zoneInactiveToActiveTransition = TRUE;
	}

	pPID->zoneAuto = mode;



}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setTpo



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setTpo(PIDController* pPID, DWORD tpoOut)
{
	pPID->tpoOutput = tpoOut;

}



/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_writeCalculatedTpo



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_writeCalculatedTpo(PIDController* pPID)
{
	if ( pPID == 0 )
	{
		printk("ERROR: PIDController_writeCalculatedTpo() pPID is NULL\n");
	}
	else
	{

		if(pPID->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
		{
			PIDController_TPOToDigitalTime(pPID);
		}		
		if ( pPID->pTPOoutput )
		{
			if(pPID->m_bSuspended == TRUE)
			{
				*(pPID->pTPOoutput) = 0;				
			}
			else
			{
				*(pPID->pTPOoutput) = pPID->tpoOutput;
			
			}
		}
	

	}
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetPbCool



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetPbCool(PIDController* pidControl, DWORD proportionalBand)
{
	PARAM_CHECK( pidControl, "PIDController_pidSetTdCool");

	if ( pidControl )
	{
		PID_setPb( &(pidControl->coolPID), proportionalBand );
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetTiCool



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetTiCool(PIDController* pidControl, DWORD dwTi)
{
	PARAM_CHECK( pidControl, "PIDController_pidSetTdCool");
	if ( pidControl )
	{
		PID_setTi( &(pidControl->coolPID), dwTi );	

	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetTdCool



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetTdCool(PIDController* pidControl, DWORD dwTd)
{
	PARAM_CHECK( pidControl, "PIDController_pidSetTdCool");
	if ( pidControl )
	{
		PID_setTd( &(pidControl->coolPID), dwTd );
	}
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setCoolOnOff



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setCoolOnOff(PIDController* pPID, DWORD nOff)
{
	PARAM_CHECK( pPID, "PIDController_setCoolOnOff");
	pPID->coolOnOff = nOff;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setCoolOutput



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setCoolOutput(PIDController* pidControl, DWORD output)
{
	PARAM_CHECK( pidControl, "PIDController_setCoolOutput");
	pidControl->coolOutput = RealToNominalOutput(output);
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_cooling



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_cooling(PIDController* pPID)
{
	PARAM_CHECK( pPID, "PIDController_cooling");
	if( pPID->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		if(pPID->mDwrdOutput>=pPID->currentTooth)
		{
			*DOUT_GetAt(digOutDb, pPID->coolOutput) = TRUE;
		}
		else
		{
			*DOUT_GetAt(digOutDb, pPID->coolOutput) = FALSE;
		}
		pPID->currentTooth++;
		if(pPID->currentTooth > pPID->period)
		{
			pPID->currentTooth = 1;
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_TPOToDigitalTime



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_TPOToDigitalTime(PIDController* pPID)
{
	PARAM_CHECK( pPID, "PIDController_TPOToDigitalTime");
	pPID->mDwrdOutput = 0;
	if(pPID->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		if(pPID->period == 0)
		{
			printk("error pPID->period\n");
		}
		else
		{
			pPID->mDwrdOutput = (pPID->tpoOutputCooling*10000*pPID->period)/256;
			pPID->mCoolingOutputPercentX100=(pPID->mDwrdOutput/pPID->period)/100;
			pPID->mDwrdOutput=pPID->mDwrdOutput/10000;
		}	
	}
}		          

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setCoolPeriod



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setCoolPeriod(PIDController* pPID, DWORD period)
{
	PARAM_CHECK( pPID, "PIDController_setCoolPeriod");
	pPID->period = period;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_writeTpo



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_writeTpo(PIDController* pPID, WORD tpoOut)
{
	if ( pPID->bLocalZone )
	{			
		if(pPID->m_bSuspended==TRUE)	
		{
			*(pPID->pTPOoutput) = 0;
		}
		else
		{
			*(pPID->pTPOoutput) = tpoOut;
		}	
	}
}



/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setPreviousJob



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setPreviousJob(PIDController* pPID, DWORD job)
{
	pPID->previousJobNo = job;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setActive



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setActive(PIDController* pPID, BOOL bActive)
{
	if ( pPID->bZoneActive != bActive )
	{
		pPID->zoneInactiveToActiveTransition = TRUE;
	}

	pPID->bZoneActive = bActive; 
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setPidEnable



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setPidEnable(PIDController* pPID, BOOL bEnable)
{
	pPID->pidEnabled = bEnable;

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setGroupNo


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setGroupNo(PIDController* pPID, int nGroupNo)
{
	pPID->groupNo = nGroupNo;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setSP


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setSP(PIDController* pPID, LONG nSP)
{
	if(nSP!=pPID->sp)
	{
		pPID->bRetry = 1;
	}
	pPID->sp = nSP;
	pPID->coolSP=pPID->sp + pPID->coolSPOffset;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_updatePV
			
 GLOBALS:
 RETURNS:   char
 SEE ALSO:
------------------------------------------------------------------------*/
char PIDController_updatePV(PIDController* pPID)
{
	char bReturn = 1;
	pPID->pv = *(pPID->pTcInput);
#ifdef BAD_FRANK
	if (pPID->pv == 32767)
		pPID->pv = 1;
#endif
	return bReturn;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setPV


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setPV(PIDController* pPID, LONG nPV)
{
	pPID->pv = nPV;
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setAction



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setAction(PIDController* pPID, enum Action iAction)
{
	PID_setAction(&(pPID->pid), iAction);
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_configureIO



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_configureIO(PIDController* pPID, UINT ai, UINT tpo)
{
	pPID->pTcInput = ANALOGIN_GetAt(analogInDb, ai);
	pPID->m_nTcInput = ai;

	pPID->dwrdOurOutput = tpo;
	pPID->pTPOoutput	= ANALOGOUT_GetAt(analogOutDb, tpo);
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_AddSafeSegment



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_AddSafeSegment(PIDController* pPID, unsigned int channel, unsigned int weight)
{
	unsigned int use_this_channel = channel;
	
	if ( pPID->bLocalZone )
	{		
		use_this_channel = channel;		
		TPO_AddSafeSegment( use_this_channel, weight );
	}

}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_getPV



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
DWORD PIDController_getPV(PIDController* pPID)
{	
	return pPID->pv;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_getTPO
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD PIDController_getTPO(PIDController* pPID)
{
	return pPID->tpoOutput;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_suspendSecondaryWrite



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_suspendSecondaryWrite(PIDController* pidControl, BOOL bSuspend)
{
	pidControl->m_bSuspended=bSuspend;

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetPb



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetPb(PIDController* pidControl, DWORD propotionalBand)
{
	if ( pidControl )
	{
		PID_setPb( &(pidControl->pid), propotionalBand );
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetTi



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetTi(PIDController* pidControl, DWORD dwTi)
{
	if ( pidControl )
	{
		PID_setTi( &(pidControl->pid), dwTi );
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetTd



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetTd(PIDController* pidControl, DWORD dwTd)
{
	if ( pidControl )
	{
		PID_setTd( &(pidControl->pid), dwTd );
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetAction



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetAction(PIDController* pidControl, enum Action pidResponseAction)
{
	if ( pidControl )
	{
		PID_setAction( &(pidControl->pid), pidResponseAction);

	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_pidSetMode



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_pidSetMode(PIDController* pidControl, BOOL bModeEnabled)
{
	if ( pidControl )
	{
		PID_setPIDMode( &(pidControl->pid), bModeEnabled);
 
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableHiDeviationAlarm



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableHiDeviationAlarm(PIDController* pidControl, BOOL enable ) 
{
	PARAM_CHECK( pidControl, "PIDController_enableHiDeviationAlarm");
	pidControl->htAlarmEnable = enable;

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableLoDeviationAlarm



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableLoDeviationAlarm(PIDController* pidControl, BOOL enable )
{
	PARAM_CHECK( pidControl, "PIDController_enableLoDeviationAlarm");
	pidControl->ltAlarmEnable = enable; 
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableHiDeviationWarn



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableHiDeviationWarn(PIDController* pidControl, BOOL enable )             
{
	PARAM_CHECK( pidControl, "PIDController_enableHiDeviationWarn");
	pidControl->htWarnEnable = enable; 	
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableLoDeviationWarn



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableLoDeviationWarn(PIDController* pidControl, BOOL enable ) 			
{
	PARAM_CHECK( pidControl, "PIDController_enableLoDeviationWarn");
	pidControl->ltWarnEnable = enable;  
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setDeadBandState



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void  PIDController_setDeadBandState(PIDController* pidControl, BOOL dbState )    
{ 
	PARAM_CHECK( pidControl, "PIDController_setDeadBandState");

	pidControl->inDeadBand = dbState;	

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setAlarmsEnabled



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setAlarmsEnabled(PIDController* pidControl, BOOL state ) 				
{
	PARAM_CHECK( pidControl, "PIDController_setAlarmsEnabled");
	pidControl->alarmBandsEnabled = state;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setRiseRateCheck



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setRiseRateCheck(PIDController* pidControl, BOOL state ) 				
{
	PARAM_CHECK( pidControl, "PIDController_setRiseRateCheck");
	pidControl->m_bDoRiseRateCheck = state;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_timeoutOutput

				if we are not in pid control mode or manually setting tpo by the user, we must timeout on any output
				to avoid runaway conditions

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_timeoutOutput(PIDController* pidControl)
{
	if(pidControl->bTPOTimeStampTaken==FALSE)
	{
		pidControl->dwrdTPOWithoutPID=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
		pidControl->bTPOTimeStampTaken=TRUE;
	}
	if(differenceWithRollover(Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)),pidControl->dwrdTPOWithoutPID )>=100)
	{
		pidControl->bTPOOffDueToLackOfPID=TRUE;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDCOntroller_clearTimeout



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDCOntroller_clearTimeout(PIDController* pidControl)
{
	pidControl->dwrdTPOWithoutPID=Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	pidControl->bTPOTimeStampTaken=FALSE;
	pidControl->bTPOOffDueToLackOfPID=FALSE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setGlobalHighProcess



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setGlobalHighProcess(PIDController* pidControl, LONG newHP)
{
	if ( pidControl )
	{
		pidControl->globalhp = newHP;
	}
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_checkGlobalHighProcess

				This function will  alarm the hc2 if the global high process is exceeded.
				the function will return 1 if exceeded, 0 if not
				This test will be performed on every enabled zone in operate and cooldown.
				Disabled zones are not tested since they do not have thermocouples or outputs

	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
int PIDController_checkGlobalHighProcess(PIDController* pidControl)
{
	int nReturn = 0;

	if ( pidControl )
	{
 		if( (pidControl->pv >= pidControl->globalhp))
		{
			nReturn = 1;

			AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_GLB_OVERTEMP, pidControl->zoneNo);
		}
	}

	return nReturn;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setHiProcTemp

				The absolute high temperature for this job. All data validity checking is
				done in the user interface.

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setHiProcTemp(PIDController* pidControl, DWORD newHighProcess )
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setHiProcTemp", 0);
	pidControl->highProcess = newHighProcess;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setLoProcTemp

	The absolute low temperature for this job. All data validity checking is
	done in the user interface.

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setLoProcTemp(PIDController* pidControl, DWORD newLowProcess )
{
	PARAM_CHECK_RETURN( pidControl, "TempZone_setLoProcTemp", 0);
	pidControl->lowProcess = newLowProcess;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableHiProcAlarm



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableHiProcAlarm(PIDController* pidControl, BOOL enable )				
{
	PARAM_CHECK( pidControl, "PIDController_enableHiProcAlarm");
	pidControl->hiProcAlarmEnable = enable; 
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableLoProcAlarm



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableLoProcAlarm(PIDController* pidControl, BOOL enable )   	        
{
	PARAM_CHECK( pidControl, "PIDController_enableLoProcAlarm");
	pidControl->loProcAlarmEnable = enable; 	
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setAlarmHiTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setAlarmHiTempOffset(PIDController* pidControl, DWORD newAlarmHighTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setAlarmHiTempOffset", 0);
	pidControl->alarmHighTempOffset = newAlarmHighTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setAlarmLoTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setAlarmLoTempOffset(PIDController* pidControl, DWORD newAlarmLowTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setAlarmLoTempOffset", 0);
	pidControl->alarmLowTempOffset = newAlarmLowTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setWarnHiTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setWarnHiTempOffset(PIDController* pidControl, DWORD newWarnHighTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setWarnHiTempOffset", 0);

	pidControl->warnHighTempOffset = newWarnHighTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setWarnLoTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setWarnLoTempOffset(PIDController* pidControl, DWORD newWarnLowTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setWarnLoTempOffset", 0);	
	pidControl->warnLowTempOffset = newWarnLowTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setDeadBandHiTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setDeadBandHiTempOffset(PIDController* pidControl, DWORD newDeadBandHighTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setDeadBandHiTempOffset", 0);

	pidControl->deadBandHighTempOffset = newDeadBandHighTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setDeadBandLoTempOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_setDeadBandLoTempOffset(PIDController* pidControl, DWORD newDeadBandLowTempOffset)
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_setDeadBandLoTempOffset", 0);

	pidControl->deadBandLowTempOffset = newDeadBandLowTempOffset;
	return TRUE;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setPowerUpComplete



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setPowerUpComplete(PIDController* pidControl, BOOL bSetTo )
{
	PARAM_CHECK( pidControl, "PIDController_setPowerUpComplete");

	pidControl->m_bPowerUpDelayElapsed = bSetTo;

	if(!bSetTo) // if turning cycle off deactivate rise rate check
	{
		PIDController_setStartState(pidControl, bSetTo);
		PIDController_setRiseRateCheck( pidControl, FALSE );
	}
	else
	{
		PIDController_setStartState(pidControl, bSetTo);
	}


}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setHiProcDelay



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setHiProcDelay(PIDController* pidControl, int iDelay)
{
	PARAM_CHECK( pidControl, "PIDController_setHiProcDelay");
	pidControl->m_dwrdHiProcDelay = (DWORD) iDelay;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_enableDeadBandRangeCheck



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_enableDeadBandRangeCheck(PIDController* pidControl, BOOL dbFlag /*= TRUE*/ )
{
	PARAM_CHECK( pidControl, "PIDController_enableDeadBandRangeCheck");
	pidControl->deadBandEnableStatus = dbFlag; 


}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_isInDeadBandRangeCheckEnabled



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL PIDController_isInDeadBandRangeCheckEnabled(PIDController* pidControl) 
{
	PARAM_CHECK_RETURN( pidControl, "PIDController_isInDeadBandRangeCheckEnabled", 0);
	return pidControl->deadBandEnableStatus; 
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setHiProcCountdownOn



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setHiProcCountdownOn(PIDController* pidControl, BOOL bSetTo)
{
	PARAM_CHECK( pidControl, "PIDController_setHiProcDelay");
	pidControl->m_bHiProcCountdownOn = bSetTo; 	

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setInternalTestForDrawWarning



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setInternalTestForDrawWarning(PIDController* pidControl, BOOL bSetTo)
{
	PARAM_CHECK( pidControl, "PIDController_setHiProcDelay");
	pidControl->m_bInternalTestForDrawWarning = bSetTo;

}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_checkAlarmBands



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_checkAlarmBands(PIDController* pidCtrl)
{
	long hdbOffset;
	long ldbOffset;

	BOOL bOpenThermocouple = FALSE;
	BOOL bDisableDevAlarmInStartup = FALSE;
	BOOL bStartupComplete = FALSE;

	DWORD drwdTZ = PIDController_getAbsoluteTempZoneNumber( pidCtrl );

    if ( Oven_getJob(ovenDb) != CoolDown )
	{
    	// need to check for low and high process alarms regardless of 
	// state of state of deviation alarms.

		if ( Oven_isJobLoadInProgress(ovenDb) == FALSE )
		{
			//ver8.0.0.11
			bDisableDevAlarmInStartup = Oven_getIsDevAlarmInStartupDisabled(ovenDb);
			if(Oven_isJobStartupComplete(ovenDb))
			{
				if(tempZonesDb->m_bTimerStartupEventFired == TRUE)
					bStartupComplete = TRUE;
			}
			////

			if ( pidCtrl->pv <= pidCtrl->lowProcess && pidCtrl->loProcAlarmEnable == TRUE )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_LO_PROCESS_ALARM, drwdTZ );
	            pidCtrl->selfAckAlarmNo = 0;               
			}
			if ( pidCtrl->highProcess <= pidCtrl->pv && pidCtrl->hiProcAlarmEnable == TRUE )
			{
				if(!pidCtrl->m_dwrdHiProcDelay)
				{
					AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_HI_PROCESS_ALARM, drwdTZ );	
		            pidCtrl->selfAckAlarmNo = 0;
				}
				else
				{
					if(pidCtrl->m_bHiProcCountdownOn)
					{
						if(pidCtrl->pv > 0x7ffc && 	pidCtrl->pv< 0x7fff)
						{
							bOpenThermocouple = TRUE;
						}

						if(Timer_getCurrentTime10ths(timerDb) > (pidCtrl->m_dwrdHiProcDelay + pidCtrl->m_dwrdHiProcBeginTime))
						{
							if(bOpenThermocouple==TRUE)
							{
								AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_OPEN_THERMO, drwdTZ);
					            pidCtrl->selfAckAlarmNo = 0;
							}
							else
							{
								AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_HI_PROCESS_ALARM, drwdTZ);
					            pidCtrl->selfAckAlarmNo = 0;
						
							}
						}
					}
					else
					{
						AlarmQueue_addAlarm(alarmQueueDb, INFORMATION,TZ_HI_PROC_INFO_EVENT, drwdTZ);
						pidCtrl->m_bHiProcCountdownOn = TRUE;
						pidCtrl->m_dwrdHiProcBeginTime = Timer_getCurrentTime10ths(timerDb);
					}
				}
			}
			else
			{
				pidCtrl->m_bOpenThermocouple = FALSE;
				pidCtrl->m_bHiProcCountdownOn = FALSE;
			}
		}
	
		if ( pidCtrl->alarmBandsEnabled == FALSE )
		{
			if ( pidCtrl->htWarnEnable )
			{
				hdbOffset = pidCtrl->sp + pidCtrl->warnHighTempOffset - pidCtrl->deadBandHighTempOffset;
			}
			else
			{
				hdbOffset = pidCtrl->warnHighTempOffset + pidCtrl->sp;
			}

			if ( pidCtrl->ltWarnEnable )
			{
				ldbOffset = pidCtrl->sp - pidCtrl->warnLowTempOffset + pidCtrl->deadBandLowTempOffset;
				if ( (long)ldbOffset < 0 )
				{
					ldbOffset = 0;
				}
			}
			else
			{
				ldbOffset = pidCtrl->sp - pidCtrl->warnLowTempOffset;
			}

			if ( PIDController_isInDeadBandRangeCheckEnabled(pidCtrl) == TRUE )
			{

				if ( (pidCtrl->pv >= ldbOffset) && (pidCtrl->pv <= hdbOffset) )
				{
					PIDController_setAlarmsEnabled(pidCtrl, TRUE);
					PIDController_setDeadBandState(pidCtrl, TRUE);

					pidCtrl->m_bInternalTestForDrawWarning = TRUE;
				}
			}
		}
		else	// alarmbands enabled == TRUE	
		{
			if( pidCtrl->pv <= (long)( pidCtrl->sp + pidCtrl->warnHighTempOffset) && 
				pidCtrl->pv >= (long)(pidCtrl->sp - pidCtrl->warnLowTempOffset))
			{
				pidCtrl->m_bInternalTestForDrawWarning = TRUE;
			}

			if ( pidCtrl->pv <= (long)( pidCtrl->sp - pidCtrl->alarmLowTempOffset ) && 
				pidCtrl->ltAlarmEnable == TRUE )
			{
				if( bDisableDevAlarmInStartup == TRUE )
				{
					if( bStartupComplete == TRUE )
					{
						AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_LO_DEVIATION_ALARM, drwdTZ);
						pidCtrl->selfAckAlarmNo = 0;
					}
				}
				else
				{
					AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_LO_DEVIATION_ALARM, drwdTZ);
					pidCtrl->selfAckAlarmNo = 0;
				}
			}
			else
			{ 
				if ( pidCtrl->pv <= (long)( pidCtrl->sp - pidCtrl->warnLowTempOffset ) && 
					pidCtrl->ltWarnEnable == TRUE )
				{
					 pidCtrl->selfAckAlarmNo = 
						AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_LO_DEVIATION_WARNING, drwdTZ);
				}
			}

			if ( pidCtrl->pv >= (long)( pidCtrl->sp + pidCtrl->alarmHighTempOffset ) && pidCtrl->htAlarmEnable == TRUE )
			{
				if( bDisableDevAlarmInStartup == TRUE )
				{
					if( bStartupComplete == TRUE )
					{
						AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_HI_DEVIATION_ALARM, drwdTZ);
	            				pidCtrl->selfAckAlarmNo = 0;
					}
				}
				else
				{
					AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_HI_DEVIATION_ALARM, drwdTZ);
					pidCtrl->selfAckAlarmNo = 0;
				}
					
			}
			else 
			{ 
				if ( pidCtrl->pv >= (long)( pidCtrl->sp + pidCtrl->warnHighTempOffset ) && pidCtrl->htWarnEnable == TRUE )
				{
					pidCtrl->selfAckAlarmNo =  AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_HI_DEVIATION_WARNING, drwdTZ);
		
				}
			}
		}
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_checkSelfAcknowledgeAlarms

					Tests the provided PIDController's PV for High Temp
					and Low Temp conditions that have corrected.  If the 
					condition has correct and Auto Acknowledge is enableds,
					then the warning (if set) will be auto acknowledged.

	RETURNS:	void.
------------------------------------------------------------------------*/
void PIDController_checkSelfAcknowledgeAlarms(PIDController* pidCtrl)
{
	BOOL bDisableAutoAck;
	BOOL bStartupComplete;			
	long high_temp_offset;
	long low_temp_offset;
		
	bDisableAutoAck = FALSE;
	bStartupComplete = FALSE;			
	high_temp_offset = 0;
	low_temp_offset = 0;

	if( NULL != pidCtrl )
	{
		//if(pidCtrl->bLocalZone == TRUE)	//ver8.0.0.28 2018-Feb-08, comment out to address issue of channel color for zones on secondary HC2
		{
			if ( pidCtrl->selfAckAlarmNo != 0 )
			{
				// The deadband offset is calculated as the warning from the respective warning band.
				// If the oven is in cooldown then autoacknowledge the warnings.
				// SDY - 08/21/2000
			
				bDisableAutoAck = Oven_getIsAutoAcknowledgedDisabled(ovenDb);
				bStartupComplete = Oven_isJobStartupComplete(ovenDb);			
	
				high_temp_offset = (long)(pidCtrl->sp + pidCtrl->warnHighTempOffset - pidCtrl->deadBandHighTempOffset);
				low_temp_offset = (long)(pidCtrl->sp - pidCtrl->warnLowTempOffset + pidCtrl->deadBandLowTempOffset);
			
				if ( ((pidCtrl->pv <= high_temp_offset) &&  
					(pidCtrl->pv >= low_temp_offset)) || 
					pidCtrl->alarmBandsEnabled == FALSE )
				{			
					if ( bDisableAutoAck )
					{
						// ack the alarm if we are still in the startup sequence or 
						// if the startup sequence timer hasn't been fired yet.
						if ( (bStartupComplete == FALSE) ||
							(tempZonesDb->m_bTimerStartupEventFired == FALSE) )
						{
							AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pidCtrl->selfAckAlarmNo );

						}
					}
					else
					{
						AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pidCtrl->selfAckAlarmNo );
					}
	
					pidCtrl->selfAckAlarmNo = 0;
				}
			}
		}
	}
	
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  PIDController_getSelfAckAlarmNo
			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD PIDController_getSelfAckAlarmNo( PIDController* pidControl)
{
	DWORD val = 0;
	val=pidControl->saFromSlave = pidControl->selfAckAlarmNo;


	return val;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_getClearLocal



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
int PIDController_getClearLocal( PIDController* pidControl)
{
	int iReturn = 0;
	if(pidControl->bLocalZone == FALSE)
		iReturn = 1;
	return iReturn;
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_getAbsoluteTempZoneNumber



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
DWORD PIDController_getAbsoluteTempZoneNumber(PIDController* pidControl)
{
	DWORD dwZoneNo = pidControl->zoneNo;

	return dwZoneNo;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_getRelativeTempZoneNumber



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
DWORD PIDController_getRelativeTempZoneNumber(PIDController* pidControl)
{
	DWORD dwZoneNo = pidControl->zoneNo;
	return dwZoneNo;
}



/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_getSecondBoardIndex



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
int PIDController_getSecondBoardIndex(PIDController* pidControl)
{
	int i = 0;

	BOOL bSlaveZone = FALSE;
	if ( (pidControl->zoneNo >= SLAVE_ZONE_START) &&
		(pidControl->zoneNo < SLAVE_ZONE_END) )
	{
		bSlaveZone = TRUE;
	}

	if ( bSlaveZone )
	{
		i = pidControl->zoneNo - SLAVE_ZONE_START;
	}
	else
	{
		i = pidControl->zoneNo;
	}

	return i;
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setIO



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setIO(PIDController* pidControl, DWORD in, DWORD out)
{
	pidControl->pTcInput = ANALOGIN_GetAt(analogInDb, (UINT)in);
   	pidControl->pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, (UINT)out);
	pidControl->m_nTPOoutput = (UINT)out;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_setCoolSPOffset



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_setCoolSPOffset(PIDController* pPID, LONG nSP)
{
	pPID->coolSPOffset=nSP;
	pPID->coolSP=pPID->sp+pPID->coolSPOffset;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_coolingInCooldown



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_coolingInCooldown(PIDController* pPID, DWORD on)
{
	pPID->mCoolingOnInCooldown=on;	
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	PIDController_CooldownSequenced



	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void PIDController_CooldownSequenced(PIDController* pPID, DWORD nOff)
{
	if(nOff)
	{
		pPID->mbSequence=FALSE;
	}
	else
	{
		pPID->mbSequence=TRUE;
	}
}

