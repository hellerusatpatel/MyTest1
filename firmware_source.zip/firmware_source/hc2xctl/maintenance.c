/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//maintenance.cpp
#include "contain.h"
#include "maintenance.h"
#include "timer.h"
#include "alarm.h"

extern DbContainer g_dbContainer;

Timer *elapseTimer;
AlarmQueue *alarmQueueDb;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Maintenance_init
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Maintenance_init(Maintenance* pMaintenance)
{	
	PARAM_CHECK( pMaintenance, "Maintenance_init");
	pMaintenance->sendAlarm = FALSE;

	alarmQueueDb = &( g_dbContainer.alarmQueueDb);
	elapseTimer	= &( g_dbContainer.elapseTimer);
}

void Maintenance_setMaintenanceDue(Maintenance* pMaintenance)
{
	PARAM_CHECK( pMaintenance, "Maintenance_setMaintenanceDue");
	pMaintenance->sendAlarm = TRUE;
}

void Maintenance_process(Maintenance* pMaintenance)
{
	DWORD alarmID = 0;
	PARAM_CHECK( pMaintenance, "Maintenance_process");

	if ( pMaintenance->sendAlarm == TRUE )
	{
		if ( pMaintenance->messageSent == FALSE )
		{
			alarmID = AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, OVEN_MAINTENANCE_REQUIRED, 0 );
			pMaintenance->messageSent = TRUE;
			pMaintenance->sendTime = Timer_getCurrentTime10ths(elapseTimer); 
		}
		else
		{
			pMaintenance->currentTime = Timer_getCurrentTime10ths(elapseTimer);
			if ( (pMaintenance->currentTime - pMaintenance->sendTime) >= THREE_MINUTE_DELAY )
			{
				AlarmQueue_getAlarmMessage(alarmQueueDb, alarmID, &(pMaintenance->alarmData), TRUE );
				if ( pMaintenance->alarmData.alarmID == OVEN_MAINTENANCE_REQUIRED )
				{
					AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pMaintenance->alarmData.alarmID );
					alarmID = AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, OVEN_MAINTENANCE_REQUIRED, 0);
					pMaintenance->sendTime = Timer_getCurrentTime10ths(elapseTimer); 
				}
				else
				{
					pMaintenance->sendAlarm = FALSE;
				}
			}
		}
	}
}
	
