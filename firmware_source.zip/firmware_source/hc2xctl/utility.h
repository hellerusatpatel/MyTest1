/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

#ifndef UTILITY_H
#define UTILITY_H

#include "typedefdefine.h"

/*========================================================================
 *
 * struct Definition: TimeStamp
 *
 *=======================================================================*/   

typedef struct _LocalTime_
{
	DWORD 	dwHigh;
	DWORD	dwLow;
	DWORD	dwMilli;
} LocalTime;

void LocalTime_resetTime( LocalTime* pLocalTime );
void LocalTime_setTime( LocalTime* pLocalTime, DWORD dwHigh, DWORD dwLow, DWORD dwMilli );
void LocalTime_copy( LocalTime* pLocalTimeSource, LocalTime* pLocalTimeDestination );

DWORD differenceWithRollover( DWORD  newValue, DWORD prevValue );

#endif
