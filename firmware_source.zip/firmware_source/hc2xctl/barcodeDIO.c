/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2009, All Rights Reserved
                    Company Confidential

	File:			hellercommctl.cpp

	Description:	main interface for the activex control

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "barcodeDIO.h"
#include "contain.h"
#include "alarm.h"
#include "oven.h"
#include "digitio.h"
#include "timer.h"
#include "flasher.h"

extern DbContainer g_dbContainer;

Oven 				* ovenDb;
AlarmQueue			* alarmQueueDb;			
Timer				* elapseTimer;
DOUT 				* digitalOutDb;
DIN				* digitalInDb;
Flasher		*flasher;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_init
		
			sets up variables used by bcio	

RETURNS:   void
------------------------------------------------------------------------*/
void BCIO_init(BCIO* pBCIO)
{
	int i;
	i = 0;

	elapseTimer = &( g_dbContainer.elapseTimer);
	pBCIO->barcodeInput = IDI_AV14;;
	pBCIO->barcodeOutput = ODO_SMEMA4_ENTRANCE;
	pBCIO->boardEntered = 0;
	pBCIO->timestampInputOn = 0;
	pBCIO->bPreviousInputState = FALSE;
	pBCIO->allowTime = DEFAULT_ALLOW_TIME_BARCODE;
	pBCIO->enabled = FALSE;
	pBCIO->scannedTime = 0;
	pBCIO->LTEnabled = FALSE;


	for(i = 0; i < NUM_DO; i++)
	{
		pBCIO->doStates[i] = 0;
		pBCIO->doOutputs[i] = NULL_OUTPUT;
		pBCIO->doEnabled[i] = FALSE;
	}							
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BCIO_process
		
			main loop for barcode processing

RETURNS:   void
------------------------------------------------------------------------*/
void BCIO_process(BCIO* pBCIO)
{	
	int i;
	DWORD tim;
	BOOL bInput;
	DWORD dwrdDiff;

	dwrdDiff = 0;
	bInput = FALSE;
	tim = 0;
	i = 0;

	tim = Timer_getCurrentTime10ths(elapseTimer);
	if(pBCIO)
	{
		if(pBCIO->enabled==TRUE)
		{
			if(pBCIO->barcodeOutput!=NULL_OUTPUT)
			{
				*DOUT_GetAt(digitalOutDb, pBCIO->barcodeOutput) = FALSE;
			}
			bInput = *(DIN_GetAt(digitalInDb, pBCIO->barcodeInput));
			if( ( bInput == TRUE ) && ( pBCIO->bPreviousInputState == FALSE ) )
			{
				pBCIO->timestampInputOn = tim;
				AlarmQueue_addAlarm(alarmQueueDb, INFORMATION, BCIO_SCANNED, 0);
			} 
			if(bInput == TRUE)
			{
				pBCIO->bPreviousInputState=TRUE;
			}
			else
			{
				pBCIO->bPreviousInputState=FALSE;
			}
			dwrdDiff = differenceWithRollover(tim,pBCIO->scannedTime);
			if( ( pBCIO->boardEntered > 0 ) && (dwrdDiff < BCIO_DETECT_TIME ) )
			{
		
				if(pBCIO->barcodeOutput!=NULL_OUTPUT)
				{
					*DOUT_GetAt(digitalOutDb, pBCIO->barcodeOutput) = TRUE;
				}
			}
			else if(pBCIO->boardEntered == 1)
			{
				pBCIO->boardEntered = 0;
			}
		}
		if (pBCIO->LTEnabled == TRUE )
		{
			for(i = 0; i < NUM_DO; i++)
			{
				if( pBCIO->doOutputs[i] != NULL_OUTPUT )
				{
					switch(pBCIO->doStates[i])
					{
						case ECOFF:// 0
							*DOUT_GetAt(digitalOutDb, pBCIO->doOutputs[i]) = FALSE;
							break;

						case ECON:// 1
							*DOUT_GetAt(digitalOutDb, pBCIO->doOutputs[i]) = TRUE;
							break;

						default:
							break;
					}
				}
			}
		}	
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION: BCIO_activateOutput 
		
			activates output

RETURNS:   void
------------------------------------------------------------------------*/
void BCIO_activateOutput(BCIO* pBCIO)
{
	DWORD tim;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	if(pBCIO)
	{
		pBCIO->scannedTime = tim;
		pBCIO->boardEntered = 1;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION: BCIO_setLTOption
		
			enables the settable outputs

RETURNS:   void
------------------------------------------------------------------------*/
void BCIO_setLTOption(BCIO* pBCIO, BOOL bEnable)
{
	int i;
	i = 0;
	if(pBCIO)
	{
		pBCIO->LTEnabled = bEnable;

		for( i = 0; i < NUM_DO; i++)//secsgem defaults to off.  if the heller software is turned off/on we need to turn them off, or the gemsec is stuck
		{
			pBCIO->doStates[i] = ECOFF;
		}
	}
	return;
}
