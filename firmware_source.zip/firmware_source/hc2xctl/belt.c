//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: belt.c
//
// Description: file for belt(s) processing
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 09-Feb-16  FJN  Implement digital belt stop
//*****************************************************************************
#include "contain.h"
#include "pid.h"
#include "belt.h"
#include "hellerconversions.h"
#include "rails.h"
#include "contain.h"
#include "oven.h"
#include "alarm.h"
#include "digitio.h"
#include "timer.h"
#include "tempzs.h"	
#include "hc2xio_exports.h"

//#define DEBUG_DIGITAL_STOP
//#define DIGITAL_STOP_WARNING_ENABLE

extern DbContainer g_dbContainer;

AlarmQueue		* alarmQueueDb;
ANALOGIN 		* analogInDb;
ANALOGOUT 		* analogOutDb;
DIN 			* digInDb;
DOUT 			* digOutDb;
Timer			* elapseTimer;
Oven 			* ovenDb;
Belts			* beltsDb;			// the container for belts - required for static like variables.
Rails			* railsDb;
TempZones		* tempZonesDb;
Purge			* purgeControl;
int iTestBeltTPO;
static int tenthsSecondPerMinute = 600;
//******************************************************************************
// class Belt_Belt
//
// Abstract:
// To default constructor to be used when setting up an array.
//
// Programmer: Steven Young
// Date: 04/02/1998
//******************************************************************************
void Belt_init(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_init");
	int i = 0;
	int j = 0;
	pBelt->beltActive = FALSE;
	pBelt->setSpeedCountsPerSec = 0;
	pBelt->actualSpeedCountsPerSec = 0;
	pBelt->pidEnabled = FALSE;
	pBelt->autoMode	= FALSE;
	pBelt->maxOutputPercent	= 100;
	pBelt->minOutputPercent	= 0;
	pBelt->beltInitialized	= FALSE;
	pBelt->hiProcessOffsetCounts = 0;
	pBelt->loProcessOffsetCounts = 0;
	pBelt->hiDeviationOffsetCounts = 0;
	pBelt->loDeviationOffsetCounts = 0;
	pBelt->hiWarningOffsetCounts = 0;
	pBelt->loWarningOffsetCounts = 0;
	pBelt->hiDeadBandOffsetCounts = 0;
	pBelt->loDeadBandOffsetCounts = 0;
	pBelt->hiProcessAlarmEnabled = FALSE;
	pBelt->loProcessAlarmEnabled = FALSE;
	pBelt->hiDeviationAlarmEnabled = FALSE;
	pBelt->loDeviationAlarmEnabled = FALSE;
	pBelt->hiDeviationWarningEnabled = FALSE;
	pBelt->loDeviationWarningEnabled = FALSE;
	pBelt->inDeadBand = FALSE;
	pBelt->beltIOConfigured	= FALSE;
	pBelt->currentTimePosition	= 0;
	pBelt->fourBillionElapsedPositionCountTics = 0;
	pBelt->elapsedPositionCounts = 0;
	pBelt->simulatedEncoderPulses = 0;
	pBelt->m_dwrdRemainder = 0;
	pBelt->startOverTime = 0;
	pBelt->startUnderTime = 0;
	pBelt->diffTimeOver	= 0;
	pBelt->diffTimeUnder = 0;
	pBelt->overFlag	= FALSE;
	pBelt->underFlag = FALSE;
	pBelt->selfAckAlarmNo = 0;
	PID_init(&(pBelt->pid), &(pBelt->setSpeedCounts_x_100), 
		&(pBelt->actualSpeedCounts_x_100), &(pBelt->beltTPOoutput), Reverse);
	pBelt->m_bDoFourRailCalc = FALSE;
	pBelt->m_iInLo = 0;
	pBelt->m_iInHi	= 0;
	pBelt->m_iPulsesPerCmBelt = 0;
	pBelt->m_iMaxFreq			= 0;
	pBelt->m_iRangeHiSpeed		= 0;
	pBelt->m_iRangeLoSpeed		= 0;
	pBelt->m_iRangeHiPercent	= 0;
	pBelt->m_iRangeLoPercent	= 0;
	pBelt->m_lSchedulerLoopCounter = 0;
	pBelt->m_lSlowPidRange	= 0;
	pBelt->m_bDoFastCalculation = 0;
	pBelt->m_bswitchToFastControl = FALSE;
	pBelt->ovenJobNo  = 0;
	pBelt->m_bBeltMustStop  = FALSE;
	pBelt->m_iNumberofContinousTimesWithinDeadband = 0;
	pBelt->iStartupGroup = 1;
	pBelt->bBeltSequenced =	FALSE;
	pBelt->beltHasSequenced = TRUE;
	pBelt->hiDeviationTimer = 0;
	pBelt->loDeviationTimer = 0;
	pBelt->m_dwrdWarnTime = 0;
	pBelt->m_dwrdDbDevTime = 0;
	pBelt->m_bSuspendProcessing = FALSE;
	pBelt->manualTPOcounts = 0;
	pBelt->m_bHighDevInput = FALSE;
	pBelt->m_bLowDevInput = FALSE;
	pBelt->m_bHybridOn = FALSE;
	pBelt->m_bDualMotors = FALSE;
	pBelt->m_iDeviationCOunt = 4;
	pBelt->m_iMotorFailCount = 5;
	pBelt->m_iOutputBehave =0;
	pBelt->m_iWhichOutput =99;
	pBelt->indexA = 0;
	pBelt->indexB = 0;
	pBelt->procMode = 1;
	pBelt->secondaryMotor = FALSE;
	pBelt->m_iMotorTestTime = 4;
	pBelt->m_iTestTime = 6;
	pBelt->m_iTimesSinceMotorFailed = 0;
	pBelt->m_iTimesSinceInputDeviated = 0;
	pBelt->uintPtrALocation = 0;
	pBelt->uintPtrBLocation = 0;
	pBelt->bTempzonesSequenced = FALSE;
	pBelt->m_iDualMotorFailTime = 0;
	pBelt->m_iDeviationCOuntL = 4;
	pBelt->m_iMotorFailCountL = 5;
	pBelt->m_bDualStartTest = TRUE;
	pBelt->m_iNumberOfSlowLoops = 0;
	pBelt->dualBeltTimer10ths = 300;
	pBelt->dummyTPODual = 0;
	pBelt->pBeltTPOoutB = &(pBelt->dummyTPODual);
	pBelt->pBeltPosMSW_B = &(pBelt->dummyTPODual);
	pBelt->pBeltPosLSW_B = &(pBelt->dummyTPODual); 

	iTestBeltTPO = 0;
	alarmQueueDb = &( g_dbContainer.alarmQueueDb );
	digInDb = &( g_dbContainer.digitalInDb );
	digOutDb = &( g_dbContainer.digitalOutDb );
	analogInDb = &( g_dbContainer.analogInDb	);
	analogOutDb = &( g_dbContainer.analogOutDb );
	elapseTimer = &( g_dbContainer.elapseTimer	);
	ovenDb = &( g_dbContainer.ovenDb );
	beltsDb = &( g_dbContainer.beltsDb );
	railsDb = &( g_dbContainer.railsDb );
	tempZonesDb = &( g_dbContainer.tempZonesDb );
	purgeControl = &( g_dbContainer.purge);

	pBelt->beltID = (unsigned char)Belts_addBelt(beltsDb);

	pBelt->deadBandDelay = Timer_getCurrentTime10ths(elapseTimer);
	pBelt->speedSimTime = Timer_getCurrentTime10ths(elapseTimer);
	pBelt->m_dwrdTemp = Timer_getCurrentTime10ths(elapseTimer);
	pBelt->wrdBeltOutput = 0;
	pBelt->wrdBeltOutput2 = 0;
	pBelt->m_bUseHighOutput = FALSE;
	pBelt->switchSpeed = 0;
	pBelt->m_bStoppedForSmema=FALSE;
	pBelt->m_dwrdOffDist = 0;
	pBelt->m_bWantStopForSmema=FALSE;
	for(j=0; j < MaxBelts; j++)
	{
		for(i=0; i < MAX_SMEMA_LANES; i++)
		{
			pBelt->m_bSmemaRequest[i][j]=FALSE;
			pBelt->m_dwrdCureStart[i][j]=0;
			pBelt->m_bSmemaRequestHistory[i][j]=FALSE;
			pBelt->m_bSmemaOff[i][j]=FALSE;
		}
	}
	pBelt->m_smemaLanes[0]=&( g_dbContainer.smema1 );
	pBelt->m_smemaLanes[1]=&( g_dbContainer.smema2 );
	pBelt->m_smemaLanes[2]=&( g_dbContainer.smema3 );
	pBelt->m_smemaLanes[3]=&( g_dbContainer.smema4 );
	pBelt->m_dwrdCureOffTPO=0;
	pBelt->nonStandbyCounts_x_100=0;
	pBelt->mTPOStandbyOLCounts=0;
	pBelt->openLoopCounts=0;
	pBelt->nominalSpeedCount=0;
	pBelt->m_mvFractionalRemainder=0;
	// digital stop elements
	pBelt->m_digitalStopSensor = 0xFFFFFFFF;
	pBelt->m_digitalStopAsserted = FALSE;
	pBelt->m_digitalStopSpeedCounts_x_100 = 0;
	pBelt->m_digitalStopSpeedInCMsPerMin = 0;
	pBelt->m_digitalStopSelfAckAlarmNo = 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setOpenLoop

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setOpenLoop(Belt* pBelt, BOOL openLoopState )
{
	PARAM_CHECK( pBelt, "Belt_setOpenLoop");
	pBelt->openLoopSystem = openLoopState;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_isOpenLoop

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_isOpenLoop(Belt* pBelt )
{
	PARAM_CHECK_RETURN( pBelt, "Belt_isOpenLoop", FALSE);
	return pBelt->openLoopSystem;
}

//*****************************************************************************
// Class Belt_configureBeltIO
// 
// Abstract:
// The IO that the belt interfaces to is contingent upon knowing the number of
// Rails that are on the oven.
// Belt ID 0 must always be active, Belt ID 0 can be active or inactive.
// If the number of rails changes then a call to reconfigure the belt will be 
// required.
//
// Programmer: Steven Young
// Date: 5/14/1998
//
//*****************************************************************************
BOOL Belt_configureBeltIO(Belt* pBelt)
{
	BOOL status = TRUE;

	DWORD noOfActiveRails = Rails_getNoOfActiveRails(railsDb); 
	DWORD noOfActiveBelts = Belts_getNoOfActiveBelts(beltsDb);

	PARAM_CHECK_RETURN( pBelt, "Belt_configureBeltIO", FALSE);

	switch( noOfActiveBelts )
	{
		case 0: 
			break;

		case 1: 
			switch ( pBelt->beltID)
			{
				case 0: // belt ID 0 
					pBelt->wrdBeltOutput = TPO_CONVBELT1;
					pBelt->pBeltTPOout = (WORD*) ANALOGOUT_GetAt(analogOutDb, TPO_CONVBELT1);
					switch ( noOfActiveRails )
					{
						case 0: 
						case 1:
							pBelt->countMethod = PULSE_COUNT;			// 0 or 1 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_SPEED);
							break;
						case 2:
							pBelt->countMethod = PULSE_COUNT;			// 2 or 3 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_SPEED);
							break;
						case 3:
							pBelt->countMethod = PULSE_COUNT;			// 2 or 3 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_SPEED);
							break;
						case 4:
							//	countMethod = FREQ_TO_ANALOG;		// 4 rails
							pBelt->countMethod = PULSE_COUNT;			// 2 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_3_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_3_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, AI_FREE_L1SR);
							pBelt->m_bDoFourRailCalc = TRUE;
							break;
					}
			}
			break;
				
		case 2:
			switch ( pBelt->beltID )
			{
//Why did we switch inputs on a multi rail system?
				case 0: // belt ID 0 
					pBelt->wrdBeltOutput = TPO_CONVBELT1;
					pBelt->pBeltTPOout = (WORD*) ANALOGOUT_GetAt(analogOutDb, TPO_CONVBELT1);	
					switch ( noOfActiveRails )
					{
						case 0: 
						case 1: 
							pBelt->countMethod = PULSE_COUNT;			// 0 or 1 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_SPEED);
							break;
						case 2:								// 2 rails
							pBelt->countMethod = PULSE_COUNT;			// 2 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_3_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_3_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_3_SPEED);
							break;
						case 3:									// 3  rails
							pBelt->countMethod = PULSE_COUNT;		
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, AI_FREE_L1SR);
							pBelt->m_bDoFourRailCalc = TRUE;
							break;
						case 4:
							pBelt->countMethod = PULSE_COUNT;			// 4 rails
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_MSW);
							pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_LSW);
							pBelt->pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, AI_FREE_L1SR);
							pBelt->m_bDoFourRailCalc = TRUE;
							break;
					}
				break;
				case 1: // belt ID 1
					pBelt->wrdBeltOutput = TPO_CONVBELT2;
					pBelt->pBeltTPOout = (WORD*) ANALOGOUT_GetAt(analogOutDb, TPO_CONVBELT2);
					switch ( noOfActiveRails )
					{
						case 0:
							pBelt->countMethod = PULSE_COUNT;
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_MSW);
				            pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_LSW);  // jwf changed 9/21/00
							pBelt->pBeltSpeed = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_SPEED);
							break;

						case 1: 
							pBelt->countMethod = PULSE_COUNT;
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
		                    pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW);  // jwf changed 9/21/00
							pBelt->pBeltSpeed = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_SPEED);
							break;

						case 2:	
							pBelt->countMethod = PULSE_COUNT;
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
		                    pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW);  // jwf changed 9/21/00
							pBelt->pBeltSpeed = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_SPEED);
							break;
 
						case 3:	
							pBelt->countMethod = PULSE_COUNT;
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
                            pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW);  // jwf changed 9/21/00
							pBelt->pBeltSpeed = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_SPEED);
							break;
						case 4:
							pBelt->countMethod = PULSE_COUNT;
							pBelt->pBeltPosMSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_MSW);
                            pBelt->pBeltPosLSW = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_4_LSW); // jwf changed 9/21/00
							pBelt->pBeltSpeed = (WORD*) ANALOGIN_GetAt(analogInDb, AI_FREE_L2SR);
							pBelt->m_bDoFourRailCalc = TRUE;
							break;

					}
				break;	
			}
		
	}
	return status;
}

//*****************************************************************************
// Belt_checkSelfAcknowledgeAlarms()
//
// Abstract:
// Warnings for temperature deviation need to be selfacknowledging in order to
// allow the SMEMA interface to continue board feed without operator intervention.
//
// Programmer: Steven Young
// Date: 08/24/2000
//*****************************************************************************
void Belt_checkSelfAcknowledgement(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_checkSelfAcknowledgement");

	if ( pBelt->selfAckAlarmNo != 0 )
	{
		long pv = (long)pBelt->actualSpeedCountsPerSec;
		long sp = (long)pBelt->setSpeedCountsPerSec;
		
		const BOOL bDisableAutoAck = Oven_getIsAutoAcknowledgedDisabled(ovenDb);
		const BOOL bStartupComplete = Oven_isJobStartupComplete(ovenDb);

		if( (( pv <= ( sp + pBelt->hiWarningOffsetCounts  ) ) && ( pv >= ( sp - pBelt->loWarningOffsetCounts ) )) ||
			pBelt->inDeadBand == FALSE )
		{
			if ( bDisableAutoAck )
			{
				if ( bStartupComplete == FALSE )
				{
					AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pBelt->selfAckAlarmNo );
				}
			}
			else
			{
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pBelt->selfAckAlarmNo );
			}
 				
			pBelt->selfAckAlarmNo = 0;	
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_process

	The function to call all functions perform the updating that the belt needs
  	such as speed, PID calculations, Board processing.
	When a lube cycle occurs reset the elapsedDistanceLubeVariable.
	Max Belt Speed = 188cm/minute = 3.133cm/sec.
	Pulses Per cm = 12,76
  	Max Pulse Per sec = 12.76pulses/cm * 3.133cm/sec = 40 pulses/sec.
  	Max Time Running before Rollover Occurs = 
					4294967296pulses/4_process0 pulses/sec * 1min/60sec * 1 hr/60min * 1 day/24hr 
					= 1242 days of continuous running.
			

 GLOBALS:	ovenDb
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_process(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_process");
	BOOL bWriteTpo = TRUE;
	UINT jobNo = Oven_getJob(ovenDb);
	BOOL bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
	BOOL bLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
	BOOL bSpeedTrigger = Belts_GetBeltSpeedPIDTrig(beltsDb);

 	if ( !pBelt->beltActive || pBelt->m_bSuspendProcessing )
	{
		pBelt->inDeadBand = TRUE;
		if(pBelt->m_bSuspendProcessing) //user has turned control off, output must be forced to 0
		{
			if ( bWriteTpo )
			{
				pBelt->beltTPOoutput = 0;
				*(pBelt->pBeltTPOout) = 0;
				*(pBelt->pBeltTPOoutB) = *(pBelt->pBeltTPOout);
			}
		}
	}
	else
	{
		// if digital belt stop enabled
		if (pBelt->m_digitalStopSensor != 0xFFFFFFFF)
		{
			// sample digital stop sensor
#ifdef DEBUG_DIGITAL_STOP
			static DWORD lastPrint = 0;
#endif
			BOOL digitalStopAsserted = *DIN_GetAt(&g_dbContainer.digitalInDb, (UINT)pBelt->m_digitalStopSensor);
#ifdef DEBUG_DIGITAL_STOP
			if (Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint >= 10)
			{
				DWORD mask;
				UINT val;
				lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
				printk("Digital stop belt %d sensor %ld state %d", pBelt->beltID, pBelt->m_digitalStopSensor, digitalStopAsserted);
				for (val = 0; val < 64; val++)
				{
					mask <<= 1;
					if (*DIN_GetAt(&g_dbContainer.digitalInDb, val))
						mask |= 1;
					if ((val % 32) == 31)
						printk(" %08lX", mask);
				}
				printk("\n");
			}
#endif
			// if software belt stop asserted
			if (pBelt->m_digitalStopAsserted)
			{
				// if hardware belt stop not asserted then undo software belt stop
				if (!digitalStopAsserted)
				{
					pBelt->m_digitalStopAsserted = FALSE; // do before calling Belt_setSpeedCounts and Belt_setSpeedInCMsPerMin
					Belt_setSpeedCounts(pBelt, pBelt->m_digitalStopSpeedCounts_x_100);
					pBelt->m_digitalStopSpeedCounts_x_100 = 0;
					Belt_setSpeedInCMsPerMin(pBelt, pBelt->m_digitalStopSpeedInCMsPerMin);
					pBelt->m_digitalStopSpeedInCMsPerMin = 0;
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_DIGITAL_STOP_OFF, pBelt->beltID);
#ifdef DIGITAL_STOP_WARNING_ENABLE
					AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pBelt->m_digitalStopSelfAckAlarmNo);
#endif
#ifdef DEBUG_DIGITAL_STOP
					printk("Digital belt stop reset beltID=%d\n", pBelt->beltID);
#endif
				}
			}
			// if software belt stop not asserted
			else
			{
				// if hardware belt stop asserted then impose software belt stop
				if (digitalStopAsserted)
				{
					pBelt->m_digitalStopSpeedCounts_x_100 = pBelt->setSpeedCounts_x_100;
					pBelt->m_digitalStopSpeedInCMsPerMin = pBelt->speedInCMsPerMin;
					Belt_setSpeedCounts(pBelt, 0);
					Belt_setSpeedInCMsPerMin(pBelt, 0);
					pBelt->m_digitalStopAsserted = TRUE; // do after calling Belt_setSpeedCounts and Belt_setSpeedInCMsPerMin
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_DIGITAL_STOP_ON, pBelt->beltID);
#ifdef DIGITAL_STOP_WARNING_ENABLE
					pBelt->m_digitalStopSelfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, BELT_DIGITAL_STOP_WARNING, pBelt->beltID);
#endif
#ifdef DEBUG_DIGITAL_STOP
					printk("Digital belt stop asserted beltID=%d\n", pBelt->beltID);
#endif
				}
			}
		}
		//Tushar wants open loop to always be indeadband
		if(pBelt->openLoopSystem)
		{
			pBelt->inDeadBand = TRUE;
		}
		//set a flag on a recipe change to trigger the fast control on a recipe load
		if (jobNo != pBelt->ovenJobNo)
		{
			pBelt->m_bswitchToFastControl = TRUE;			
			pBelt->m_bBeltMustStop = TRUE;
			pBelt->m_bDualStartTest = TRUE;
			if(jobNo != COOLDOWN)
			{
				Belt_CureInit(pBelt); //Tushar wants the belt suspend to not be cleared by cooldown however type 2 should be cleared by a transition to a new job
				//CLEAR TYPE 2 VARIABLES IN SMEMA LANES
				pBelt->m_smemaLanes[0]->m_bAllowNext=TRUE;
				pBelt->m_smemaLanes[0]->m_bAllowNextPend=TRUE;
				pBelt->m_smemaLanes[0]->squareTimeTaken=FALSE;
				pBelt->m_smemaLanes[1]->m_bAllowNext=TRUE;
				pBelt->m_smemaLanes[1]->m_bAllowNextPend=TRUE;
				pBelt->m_smemaLanes[1]->squareTimeTaken=FALSE;
				pBelt->m_smemaLanes[2]->m_bAllowNext=TRUE;
				pBelt->m_smemaLanes[2]->m_bAllowNextPend=TRUE;
				pBelt->m_smemaLanes[2]->squareTimeTaken=FALSE;
				pBelt->m_smemaLanes[3]->m_bAllowNext=TRUE;
				pBelt->m_smemaLanes[3]->m_bAllowNextPend=TRUE;
				pBelt->m_smemaLanes[3]->squareTimeTaken=FALSE;
			}
		}
		else
		{
			//now that we're not in cooldown switch to the fast control
			if(pBelt->m_bswitchToFastControl)
			{
				pBelt->m_bDoFastCalculation = TRUE;
				pBelt->m_bswitchToFastControl = FALSE;
			}
		}
		pBelt->ovenJobNo = jobNo;

		if ( pBelt->beltIOConfigured == FALSE )
		{
			Belt_configureBeltIO(pBelt);
			pBelt->beltIOConfigured = TRUE;
		}
		 
		if ( pBelt->beltInitialized == FALSE )
		{	// the number returned from the analogic board on startup.
			// need to concern ourselves about rollover in a negative 
			// direction.
			if ( pBelt->openLoopSystem == TRUE )
			{
				pBelt->startPositionCounts = 0;
			}
			else
			{
				pBelt->startPositionCounts = *(pBelt->pBeltPosMSW) << (16 + *(pBelt->pBeltPosLSW));
				if(pBelt->m_bDualMotors )
				{
					pBelt->startPositionCountsB = *(pBelt->pBeltPosMSW_B) << (16 + *(pBelt->pBeltPosLSW_B));
				}
			}
			pBelt->beltInitialized = TRUE;
		}

		Belt_beltPositionCalculation(pBelt);
		Belt_CureExitTest(pBelt);
		// per Doug Smith, 11/24/98 IBM has a requirement that the belt remain at
		// a constant speed during COOLDOWN. So this now becomes the standard.
		// modified by SDY 11/30/98.
     	Belt_checkSelfAcknowledgement(pBelt);
		if ( jobNo != COOLDOWN || bCooldownComplete == FALSE )
		{

			if ( pBelt->autoMode == TRUE && pBelt->openLoopSystem == FALSE)
			{
				if(pBelt->m_bBeltMustStop)
				{
					if(!pBelt->actualSpeedCountsPerSec)
					{
						pBelt->m_bBeltMustStop = FALSE;
					}
				}
				if(pBelt->m_bDualMotors)
				{
					if( !Belt_processDualMotor(pBelt))
					{
						Belt_calculateBeltSpeed(pBelt);
					}
				}
				else
				{
					Belt_calculateBeltSpeed(pBelt);
				}
				if(pBelt->m_bDoFourRailCalc)
				{
					pBelt->actualSpeedCountsPerSec = (pBelt->actualSpeedCounts_x_100 + 50) / 100;
				}
				else
				{
					pBelt->actualSpeedCounts_x_100 = pBelt->actualSpeedCountsPerSec * 100; // The number of counts is also multiplied by 100.
				}
				if (bSpeedTrigger)
				{
					pBelt->m_lSchedulerLoopCounter++;
					//if the belt is in deadband then we will calculated the pid loop normally if it outside of the deadband
					//region we need a more aggressive pid calculation due to a very slow ramp up time WDT 07.18.01
					if(pBelt->m_bDoFastCalculation)
					{
						if(pBelt->beltHasSequenced || pBelt->openLoopSystem)
						{
							if(pBelt->m_bStoppedForSmema==FALSE)
							{
								PID_calcBeltPID(&(pBelt->pid), 10);
							}
						}
						else
						{
							pBelt->beltTPOoutput = 0;
						}
						pBelt->m_lSchedulerLoopCounter = 0;
						//if switching from one recipe to another with the same belt speed the fast calc will turn off right away lets test against
						//pv
						if ( (pBelt->actualSpeedCountsPerSec <= (pBelt->setSpeedCountsPerSec + pBelt->m_lSlowPidRange)) 
						&& (pBelt->actualSpeedCountsPerSec >= (pBelt->setSpeedCountsPerSec - pBelt->m_lSlowPidRange))
						&& bLoadInProgress == FALSE )
						{
							pBelt->m_iNumberofContinousTimesWithinDeadband++;
							if(!pBelt->m_bBeltMustStop && pBelt->m_iNumberofContinousTimesWithinDeadband > 24)
							{
								pBelt->m_bDoFastCalculation = FALSE;
							}
						}
						else
						{
							pBelt->m_iNumberofContinousTimesWithinDeadband = 0;
						}
					}
					else									
					{
						if(pBelt->m_lSchedulerLoopCounter >= 10 )
						{
							if(pBelt->beltHasSequenced || pBelt->openLoopSystem)
							{
								if(pBelt->m_bStoppedForSmema==FALSE)
								{
									PID_calcBeltPID(&(pBelt->pid), 10);
								}
							}
							else
							{
								pBelt->beltTPOoutput = 0;
							}
							pBelt->m_lSchedulerLoopCounter = 0;
						}
					}				 
				}

				if ( bWriteTpo )
				{
					if(!iTestBeltTPO)
					{
						TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
					}
	
					if(pBelt->m_bStoppedForSmema==FALSE)
					{
						*(pBelt->pBeltTPOout) = (unsigned short)pBelt->beltTPOoutput;
					}
					else
					{
						*(pBelt->pBeltTPOout) = (unsigned short)pBelt->m_dwrdCureOffTPO;
					}
				}
				if(pBelt->m_bDualMotors)
				{
					switch(pBelt->m_iOutputBehave)
					{
					case 0:
						break;
						
					case 1:	
						if(!iTestBeltTPO)
						{
							TPO_AddSafeSegment(pBelt->wrdBeltOutput2, 0x01);
						}
						*(pBelt->pBeltTPOoutB) = (unsigned short)pBelt->beltTPOoutput;
						break;
					
					case 2:
						if(!pBelt->secondaryMotor)
						{
							if(!iTestBeltTPO)
							{
								TPO_AddSafeSegment(pBelt->wrdBeltOutput2, 0x01);
							}
							*(pBelt->pBeltTPOoutB) = (unsigned short)pBelt->beltTPOoutput;
						}
						else
						{
							if(!iTestBeltTPO)
							{
								TPO_AddSafeSegment(pBelt->wrdBeltOutput2, 0x01);
							}
							*(pBelt->pBeltTPOoutB) = 0;
						}
						break;
					
					default:
						break;
					}
				}
				Belt_SetpointDeviationDelayFilter(pBelt);
			}
			else	// manual mode
			{
				//stop due to not ready for next board
				if ( bWriteTpo )
				{
					if(!iTestBeltTPO)
					{
						TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
					}
					if( (pBelt->openLoopSystem == TRUE) && pBelt->m_bStoppedForSmema &&
						(pBelt->autoMode == TRUE) )
					{
	
						*(pBelt->pBeltTPOout) = (unsigned short)pBelt->m_dwrdCureOffTPO;
					}
					else
					{
						*(pBelt->pBeltTPOout) = (unsigned short)(pBelt->beltTPOoutput = ( unsigned short )	pBelt->openLoopCounts);
					}
				}
				if(pBelt->m_bDualMotors)
				{
					switch(pBelt->m_iOutputBehave)
					{
					case 0:
						break;
						
					case 1:
						if(!iTestBeltTPO)
						{
							TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
						}
						*(pBelt->pBeltTPOoutB) = (unsigned short)pBelt->beltTPOoutput;
						break;
					
					case 2:
						if(!pBelt->secondaryMotor)
						{
							if(!iTestBeltTPO)
							{
								TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
							}
							*(pBelt->pBeltTPOoutB) = (unsigned short)pBelt->beltTPOoutput;
						}
						else
						{
							if(!iTestBeltTPO)
							{
								TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
							}
							*(pBelt->pBeltTPOoutB) = 0;
						}
						break;

					default:
						break;
					}

				}
				// jwf 1/21/01 actualSpeedCountsPerSec = setSpeedCountsPerSec = speedInCMsPerMin;
				Belt_calculateBeltSpeed(pBelt);
				pBelt->actualSpeedCounts_x_100 = pBelt->actualSpeedCountsPerSec * 100; // The number of counts is also multiplied by 100.
			}
			Belt_checkAlarms(pBelt);
		}
		else
		{
			// COOLDOWN takes overriding precedence on all processes.
			// During initial stages of COOLDOWN ( any or all temp zones above 95C ) the
			// belt is set to max speed. Upon COOLDOWN being complete the belt is to be
			// set to 0% output
			if ( bCooldownComplete == TRUE )
			{
				if(!iTestBeltTPO)
				{	
					TPO_AddSafeSegment(pBelt->wrdBeltOutput, 0x01);
				}
				pBelt->beltTPOoutput = *(pBelt->pBeltTPOoutB)  = *(pBelt->pBeltTPOout) = 0;
			}
		}
	}
	return;		
}

//******************************************************************************
// Belt_SetpointDeviationDelayFilter()
//
// Abstract:
// Once the belt is in deadband and if over sp for two consecutive seconds or
// under sp for two consecutive seconds display the actual speed. Per Heller
// 01/25/2000
//
// Programmer: Steven Young
// Date: 01/25/2000
//
//******************************************************************************
void Belt_SetpointDeviationDelayFilter(Belt* pBelt)
{
	DWORD currentTime = Timer_getCurrentTime10ths(elapseTimer);
	PARAM_CHECK( pBelt, "Belt_SetpointDeviationDelayFilter");

	if (!pBelt->inDeadBand )
	{
		pBelt->overFlag = FALSE;
		pBelt->underFlag = FALSE;
		pBelt->startOverTime = pBelt->startUnderTime = currentTime;
	}
	else
	{
		if ( pBelt->actualSpeedCountsPerSec > pBelt->setSpeedCountsPerSec )
		{
			pBelt->overFlag = TRUE;
		}
		else
		{
			pBelt->overFlag = FALSE;
		}
		if ( pBelt->actualSpeedCountsPerSec < pBelt->setSpeedCountsPerSec )
		{
			pBelt->underFlag = TRUE;
		}
		else
		{
			pBelt->underFlag = FALSE;
		}

		if ( pBelt->overFlag == FALSE )
		{
			pBelt->startOverTime = currentTime;
			pBelt->diffTimeOver = 0;
		}
		else	// overFlag == TRUE
		{
			if ( pBelt->startOverTime == 0 )
			{ 
				pBelt->startOverTime = Timer_getCurrentTime10ths(elapseTimer);
			}
			pBelt->diffTimeOver = differenceWithRollover(currentTime, pBelt->startOverTime );		
		}

		if ( pBelt->underFlag == FALSE )
		{
			pBelt->startUnderTime = currentTime;
			pBelt->diffTimeUnder = 0;
		}
		else  // underFlag == TRUE
		{
			if (pBelt->startUnderTime == 0 )
			{ 
				pBelt->startUnderTime = Timer_getCurrentTime10ths(elapseTimer);
			}
			pBelt->diffTimeUnder = differenceWithRollover( currentTime, pBelt->startUnderTime );		
		}

		if ( pBelt->diffTimeUnder < pBelt->m_dwrdDbDevTime && pBelt->diffTimeOver < pBelt->m_dwrdDbDevTime ) 
		{
			pBelt->actualSpeedCountsPerSec = pBelt->setSpeedCountsPerSec;
		}
	}
}
//******************************************************************************
// Belt_checkAlarms()
//
// Abstract:
// Alarm processing for belt.
//
// Programmer: Steven Young
// Date: 07/02/1998
//
//******************************************************************************
void Belt_checkAlarms(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_checkAlarms");
	if ( pBelt->previousSetSpeedCountsPerSec != pBelt->setSpeedCountsPerSec || Oven_isJobLoadInProgress(ovenDb) == TRUE
		|| pBelt->jobNo != Oven_getJob(ovenDb)) // belts set has changed
	{

		pBelt->jobNo = Oven_getJob(ovenDb);
//Tushar wants open loop to always be indeadband
		if(!pBelt->openLoopSystem)
		{
			pBelt->inDeadBand = FALSE;
 		
			}
		pBelt->deadBandDelay = Timer_getCurrentTime10ths(elapseTimer);
		pBelt->previousSetSpeedCountsPerSec = ( unsigned short) pBelt->nominalSpeedCount;
	}
	BOOL bJobLoad = Oven_isJobLoadInProgress(ovenDb);
	// now check and see if the speed falls within deadband.
	if ( (pBelt->nominalSpeedCount <= (pBelt->setSpeedCountsPerSec + pBelt->hiDeadBandOffsetCounts )) 
			&& (pBelt->nominalSpeedCount >= (pBelt->setSpeedCountsPerSec - pBelt->loDeadBandOffsetCounts))
			&& bJobLoad == FALSE )
	{
		// do not monitor belt speed alarms until the power up sequencing is complete.
		if ( differenceWithRollover( Timer_getCurrentTime10ths(elapseTimer), pBelt->deadBandDelay ) > 300 )
		{
//Tushar wants open loop to always be indeadband
			if(!pBelt->openLoopSystem)
			{
				pBelt->inDeadBand = Oven_isJobStartupComplete(ovenDb) || TempZones_isAllZonesInDeadBand(tempZonesDb);
			}
		}
	}

	if ( Oven_isJobStartupComplete(ovenDb)== TRUE || TempZones_isAllZonesInDeadBand(tempZonesDb) == TRUE )
	{
		if ( pBelt->hiProcessAlarmEnabled )
		{
			if ( pBelt->actualSpeedCountsPerSec > (pBelt->setSpeedCountsPerSec + pBelt->hiProcessOffsetCounts) )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, BELT_HI_PROCESS_ALARM, pBelt->beltID );
                pBelt->selfAckAlarmNo = 0;
			}
		}

		if ( pBelt->loProcessAlarmEnabled )
		{
			if ( pBelt->actualSpeedCountsPerSec < (pBelt->setSpeedCountsPerSec - pBelt->loProcessOffsetCounts ))
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, BELT_LO_PROCESS_ALARM, pBelt->beltID );
                pBelt->selfAckAlarmNo = 0;
			}
		}
	}

	if ( pBelt->inDeadBand == TRUE )
	{
	
		if ( pBelt->hiDeviationAlarmEnabled )
		{
			if ( pBelt->actualSpeedCountsPerSec > (pBelt->setSpeedCountsPerSec + pBelt->hiDeviationOffsetCounts) )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, BELT_HI_DEVIATION_ALARM, pBelt->beltID );
                pBelt->selfAckAlarmNo = 0;
			}
		}
		if ( pBelt->loDeviationAlarmEnabled )
		{
			if ( pBelt->actualSpeedCountsPerSec < (pBelt->setSpeedCountsPerSec - pBelt->loDeviationOffsetCounts) )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, BELT_LO_DEVIATION_ALARM, pBelt->beltID );
                pBelt->selfAckAlarmNo = 0;
			}
		}
		if ( pBelt->hiDeviationWarningEnabled )
		{
			if ( pBelt->actualSpeedCountsPerSec > (pBelt->setSpeedCountsPerSec + pBelt->hiWarningOffsetCounts) )
			{
				if(!pBelt->hiDeviationTimer)
					pBelt->hiDeviationTimer = Timer_getCurrentTime10ths(elapseTimer);
				if( Timer_getCurrentTime10ths(elapseTimer) > pBelt->hiDeviationTimer + pBelt->m_dwrdWarnTime)
				{
					pBelt->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, BELT_HI_DEVIATION_WARNING, pBelt->beltID );
			    }
		    }
			else
			{			
				pBelt->hiDeviationTimer = Timer_getCurrentTime10ths(elapseTimer);
			}
		}
		
		if ( pBelt->loDeviationWarningEnabled )
		{
			if ( (long)pBelt->actualSpeedCountsPerSec < (long)(pBelt->setSpeedCountsPerSec - pBelt->loWarningOffsetCounts) )
			{
				if(!pBelt->loDeviationTimer)
					pBelt->loDeviationTimer = Timer_getCurrentTime10ths(elapseTimer);

				if(Timer_getCurrentTime10ths(elapseTimer) > pBelt->loDeviationTimer + pBelt->m_dwrdWarnTime)
				{
					pBelt->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, BELT_LO_DEVIATION_WARNING, pBelt->beltID );
		        	}
		    	}
			else
			{
				pBelt->loDeviationTimer = Timer_getCurrentTime10ths(elapseTimer);
			}

		}
	}
}

//*****************************************************************************
// BOOL Belt_IsBeltInWarning()
// 
// Abstract:
// As part of the the autoacknowledging mechanism the application has to be able 
// to determine the state of the belt. Since only wargings are self acknowledging
// for both the temp zones and belt(s), the warning state is all that is monitored.
// The addalarm function returns a unique identifier each time an alarm is added to 
// to the queue. By using this return value when the warnings are generated it is 
// possible to track the state of the warning condition. Since warnings can be acknowledged
// by the operator before returning the result based on the unique alarm identfier 
// the function must check the alarm queue for verifying the acknowledgement state.
//
// Programmer: Steven Young
// Date: 08/11/2000
//*****************************************************************************
BOOL Belt_IsBeltInWarning(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_IsBeltInWarning", FALSE);
	BOOL bReturn = TRUE;
    if ( pBelt->selfAckAlarmNo > 0 )
    {
        if ( AlarmQueue_findAcknowledgedAlarm(alarmQueueDb, pBelt->selfAckAlarmNo) == TRUE )
        {
            bReturn = FALSE;
        }
    }
    else
    {
        bReturn = FALSE;
    }
	return bReturn;
}
    
//******************************************************************************
// Belt_setSpeedCounts( WORD setSpeedInCounts )
//
// Abstract:
// For the belt to maintain an accurate speed feedback from an encoder or other
// device must be utilized. Belt speed is entered in the application in cm/min 
// or in/min which is converted to cm/min. The system parameters are entered in
// the setup wizard: Max Speed cm/min, Max Freq Pulses/Sec and pulses/cm.
// Given Max Speed and Max Freq the pulses/cm can be calculated from:
// Pulses/cm = (1/Max Speed cm/min) * 60sec/1min * pulses/sec 
// Modifications were required to the OCX to give a more accurate number of pulses
// for the speed was not accurate enough for customer requirements. The number
// of pulses per second was multiplied by 100 and a new variable introduced 
// setSpeedCounts_x_100 to hold this value. To minimize the massive changes and
// unpredictable results that would occur this value and the corresponding 
// actualSpeedCounts_x_100 are used for the PID calculation. The theory is the 
// integration with respect to time would better approximate the set point even
// though the actual encoder pulses is 1/100th of the PID value.
//
// Programmer: Steven Young
// Date: 11/30/99
//******************************************************************************
void Belt_setSpeedCounts(Belt* pBelt, WORD setSpeedInCounts )
{
	PARAM_CHECK( pBelt, "Belt_setSpeedCounts");
	Belt_resetDigitalStop(pBelt);
	if(setSpeedInCounts!=pBelt->nonStandbyCounts_x_100)
	{
		pBelt->m_bDoFastCalculation = TRUE;
		pBelt->m_iNumberofContinousTimesWithinDeadband = 0;
	//allows 30 seconds before dual motor/input testing	
		pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
		pBelt->m_iTimesSinceMotorFailed = 0;
		pBelt->m_iNumberOfSlowLoops = 0;
		pBelt->m_iTimesSinceInputDeviated = 0;

		pBelt->nonStandbyCounts_x_100=setSpeedInCounts;
		if(pBelt->mbStandbyMode!=TRUE)
		{
			pBelt->setSpeedCounts_x_100 = setSpeedInCounts;
			pBelt->setSpeedCountsPerSec = pBelt->setSpeedCounts_x_100/100;
			if( (pBelt->setSpeedCounts_x_100%100) >= 50 )
			{
				pBelt->setSpeedCountsPerSec++;
			}
		}
		pBelt->nominalSpeedCount = pBelt->nonStandbyCounts_x_100/100;
		if( (pBelt->nonStandbyCounts_x_100%100) >= 50 )
		{
			pBelt->nominalSpeedCount++;
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_standbyCountsOpenLoop
	
			Run speed for standby option(low usage situation).  Belt will maintain deadband during this period to 
			allow product entry			

 RETURNS:   void
------------------------------------------------------------------------*/
void Belt_setStandbyCounts(Belt* pBelt, WORD setStandbyInCounts )
{
	if( pBelt )
	{
		if(setStandbyInCounts!=pBelt->setStandbyCounts_x_100)
		{
	
			pBelt->setStandbyCounts_x_100 = setStandbyInCounts;
		}
	}
	return;
}
//******************************************************************************
// Belt_calculateBeltSpeed()
//
// Abstract:
// In the event a frequency to analog converter is being used then belt speed 
// needs to be calculated using the followin formula.
//
// Speed In Counts = dCounts/dMv * inputmv - mvOffset * Max Counts/Max mv
//
// example:
// Max Counts = 40 pulses per sec.
// Max mv     = 60
// Min Counts = 0
// Min mv	  = 12
// dMv = Max mv - Min mv
// dCounts = Max Counts - Min Counts
// inputmv = input from analogic HC1X = 12mv to 60mv
// mvOffset = 12mv
//
// Speed In Counts = (40-0)/(60-12) *[12..60] - 12 * (40-0)/(60-12) 
// Speed In Counts = dCounts(inputMv - mvOffset)/dMv 
// If < 0 set to zero.
//
// Programmer: Steven Young
// Date: 07/01/1998
//******************************************************************************
void Belt_calculateBeltSpeed(Belt* pBelt)
{
	DWORD dwrdMV = 0;			
	PARAM_CHECK( pBelt, "Belt_calculateBeltSpeed");
	DWORD calculatedCount = 0;
	DWORD dwrdRemainder = 0;
	if ( pBelt->countMethod == FREQ_TO_ANALOG )
	{
		LONG dCounts = pBelt->maxCounts - pBelt->minCounts;
		LONG dMv	 = (pBelt->maxMv - pBelt->minMv) * 100; // this is the conversion factor 
												 // for the 0 to 100mv scale on 
												 // the Analogic HC1X board.
		pBelt->actualSpeedCountsPerSec = (dCounts * (*pBelt->pBeltSpeed - (pBelt->minMv * 100))) / dMv;
	}
	else 
	{
		//convert from 295-8104 to 0-82
		if(pBelt->m_bDoFourRailCalc)
		{
/* Four rail calculation is done when the belt is a voltage style input through the tdm module.
Input is 4-20 milli amps run through a 3 ohm resistor resulting in an input of 12 - 60 milli volts.
The actual input is 1200 - 6000.  Since in real life we can have a value below the theoritical floor 
I assign a minimum value of 1200.  After this I convert the scale into a 0 to 4800, multiply by the
maximum frequency x 100 and divide by the range 4800.  WDT 08/31/01 */

			pBelt->actualSpeedCounts_x_100 = *(pBelt->pBeltSpeed);
			if(pBelt->actualSpeedCounts_x_100 < 1200)
			{
				pBelt->actualSpeedCounts_x_100 = 1200;
			}
		
			pBelt->actualSpeedCounts_x_100 = pBelt->actualSpeedCounts_x_100 - 1200;
			dwrdMV = pBelt->actualSpeedCounts_x_100;
			pBelt->actualSpeedCounts_x_100 = ((pBelt->actualSpeedCounts_x_100 * pBelt->m_iMaxFreq) /4800 );
		
			/* note	voltage style input is 1200 to 6000.  Representing 0-100% of speed
			elapsed position count is pulses per cm per second
			The calculation is as follows assuming one execution every 100 ms (see scheduler::sequencer)
			voltage input * max freqenuency (actually frequecy * 100 or 8200 in default) / 4800 = 0 to max frequencyX100 per second
			i.e. counts per second X 100
			max frequency per second X100 /1000 = max frequency per 100 ms (x100/100(to counts per second)/10(to counts per 100ms))
			record fractional remainder in accumulator, once accumulator exceeds 1000 add in an extra count		
			*/
			calculatedCount = (dwrdMV * pBelt->m_iMaxFreq) / 4800;//0-max frequencyX100 per second
			dwrdRemainder = calculatedCount % 1000;//save fraction to accumulated
			calculatedCount = calculatedCount / 1000;

			pBelt->m_mvFractionalRemainder += dwrdRemainder;
			if(pBelt->m_mvFractionalRemainder >= 1000)//if we have accumulated a whole, add back
			{
				pBelt->m_mvFractionalRemainder = pBelt->m_mvFractionalRemainder - 1000;
				calculatedCount++;
			}

			pBelt->elapsedPositionCounts += calculatedCount;

		}
		else
		{
			pBelt->actualSpeedCountsPerSec = *(pBelt->pBeltSpeed);
		}
	}
}
//******************************************************************************
//  Belt_beltPositionCalculation( ) 
//
// Abstract:
//	Need to calculate the relative position of the belt from startup for board
//  processing and lube calculations.
//	It must be assumed that due to vibration or other factors such as the manual
//	movement of the belt that backwards movement can occur, with that backwards 
//	movement can also cause the current counts to be greater than last counts.
//	Remember this algorithm is using unsigned words and unsigned longs.
//	if currentCounts > lastCounts then 
//	
//
//OPEN LOOP CALCULATION
//speedInCMsPerMin is cmperminX100 , position calculation is updated 100 ms 1/600 of a minute
//simulated encoder by adding speedInCMsPerMin/(60 * 10)
//carrying remainder over
// Programmer: Steven Young
// Date: 5/14/1998
//******************************************************************************
void Belt_beltPositionCalculation(Belt* pBelt ) 
{
 	DWORD currentCountsMSW_B;
	DWORD currentCountsLSW_B;
	DWORD additionPositionCounts = 0;
	PARAM_CHECK( pBelt, "Belt_beltPositionCalculation");

	switch ( pBelt->openLoopSystem )
	{
		case TRUE:	
			if(pBelt->m_bStoppedForSmema==FALSE)
			{
				pBelt->simulatedEncoderPulses += pBelt->speedInCMsPerMin / tenthsSecondPerMinute;
				pBelt->m_dwrdRemainder += (pBelt->speedInCMsPerMin % tenthsSecondPerMinute);
				if(pBelt->m_dwrdRemainder>tenthsSecondPerMinute)
				{
					pBelt->simulatedEncoderPulses += pBelt->m_dwrdRemainder/tenthsSecondPerMinute;
					pBelt->m_dwrdRemainder = pBelt->m_dwrdRemainder - tenthsSecondPerMinute;
				}
			}
			pBelt->elapsedPositionCounts = pBelt->currentPositionCounts = pBelt->simulatedEncoderPulses;
			break;
		
		case FALSE:
			switch ( pBelt->countMethod )
			{
				case PULSE_COUNT:
					if(pBelt->m_bDoFourRailCalc)
					{					
						//calculated in calculatebeltspeed function
					}
					else
					{
						pBelt->currentCountsLSW = *(pBelt->pBeltPosLSW);
						pBelt->currentCountsMSW = *(pBelt->pBeltPosMSW);
						pBelt->currentPositionCounts = (pBelt->currentCountsMSW << 16) + pBelt->currentCountsLSW;
						if(pBelt->m_bDualMotors)//track the second input position
						{
							currentCountsLSW_B = *(pBelt->pBeltPosLSW_B);
							currentCountsMSW_B = *(pBelt->pBeltPosMSW_B);
							pBelt->currentPositionCountsB = (currentCountsMSW_B << 16) + currentCountsLSW_B;
						}

						// the belt position is always increasing, but due to backwards
						// encoder hookups or other events the count may increment in
						// the wrong direction. In this case it must be compensated for
						// by taking the complements of the numbers.
						
						if ( pBelt->currentPositionCounts < pBelt->startPositionCounts )
						{
							pBelt->currentPositionCounts = ~pBelt->currentPositionCounts;
							pBelt->startPositionCounts = ~pBelt->startPositionCounts;
						}
								
						if(pBelt->m_bDualMotors)
						{
							if ( pBelt->currentPositionCountsB < pBelt->startPositionCountsB )
							{
								pBelt->currentPositionCountsB = ~pBelt->currentPositionCountsB;
								pBelt->startPositionCountsB = ~pBelt->startPositionCountsB;
							}
						}												
						if ( pBelt->currentPositionCounts >= pBelt->startPositionCounts )
						{ 
							// if there is a significant change in the belt position one
							// of two events has occurred:
							// 1. Rollover 
							// 2. The system was shut down/lost communication and the
							//	  Analogic board kept the belt running.
							// The system currently uses 26 counts per cm of travel.
							// One thousand counts equals 40 seconds of running. 
							// At this point no system knows what is going on anymore.
							if ( (pBelt->currentPositionCounts - pBelt->startPositionCounts ) > 1000 )
							{
								pBelt->startPositionCounts = pBelt->currentPositionCounts;
							}							
							additionPositionCounts += (pBelt->currentPositionCounts - pBelt->startPositionCounts);
							pBelt->startPositionCounts = (pBelt->currentCountsMSW << 16) + pBelt->currentCountsLSW;
						}
						if(pBelt->m_bDualMotors)
						{
							if ( pBelt->currentPositionCountsB >= pBelt->startPositionCountsB )
							{ 
								if ( (pBelt->currentPositionCountsB - pBelt->startPositionCountsB ) > 1000 )
								{
									pBelt->startPositionCountsB = pBelt->currentPositionCountsB;
								}
								if(pBelt->procMode == PROC_MODE_B)
								{
									additionPositionCounts = (pBelt->currentPositionCountsB -pBelt->startPositionCountsB);
 								}
								pBelt->startPositionCountsB = (currentCountsMSW_B << 16) + currentCountsLSW_B;
							}							
						}						
						pBelt->elapsedPositionCounts += additionPositionCounts;
							
					}
					break;
			
					case FREQ_TO_ANALOG:
					default:
						pBelt->elapsedPositionCounts = 0;
					break;
			}
			break;//break for false in switch
	}
}
//******************************************************************************
//  Belt_getCurrentState( ) 
//
// Abstract:
// Auto-Acknowledge requires the state of the belt. The states are as follows:
// 0 - Deadband not achieved - White
// 1 - DeadBand achieved, within Warning bands - Green
// 2 - Warning - Yellow
//
// Programmer: Steven Young
// Date: 08/22/2000
//******************************************************************************
DWORD Belt_getCurrentState(Belt* pBelt ) 
{
    DWORD state = 1;    // green
	PARAM_CHECK_RETURN( pBelt, "Belt_getCurrentState", 0);

    if ( !pBelt->inDeadBand )  // new job and deadband not achieved yet
    {
        state = 0;      // white
    }
    else
    {
        if ( pBelt->selfAckAlarmNo != 0 )
        {
            state = 2;  // yellow
        }
    }
    if(pBelt->speedInCMsPerMin==0 && pBelt->beltActive!=FALSE)
	{
		state = 0;
	}  
	if(!pBelt->beltActive)  
	{
		state=1;
	}
    return state;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setManualTPOcounts

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_setManualTPOcounts(Belt* pBelt, DWORD tpoCounts ) 
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pBelt, "Belt_setManualTPOcounts", FALSE);

	if ( tpoCounts <= MAX_TPO_COUNTS )
	{ 
		pBelt->manualTPOcounts = (WORD)tpoCounts;
		if(pBelt->mbStandbyMode!=TRUE)
		{
			pBelt->openLoopCounts=pBelt->manualTPOcounts;
		}
		status = TRUE;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setPb

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setPb(Belt* pBelt, DWORD pb )
{
	PARAM_CHECK( pBelt, "Belt_setPb");
	PID_setPb(&(pBelt->pid), pb );
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setTi

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setTi(Belt* pBelt, DWORD ti )
{
	PARAM_CHECK( pBelt, "Belt_setTi");
	PID_setTi(&(pBelt->pid), ti * 40 );
}
	
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setTd

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	
void Belt_setTd(Belt* pBelt, DWORD	td )
{		
	PARAM_CHECK( pBelt, "Belt_setTd");
	PID_setTd(&(pBelt->pid), td );
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getPb

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
DWORD Belt_getPb(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getPd",0);
	return PID_getPb(&(pBelt->pid));
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getTi

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
DWORD Belt_getTi(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getTi",0);
	return (PID_getTi(&(pBelt->pid))/40);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getTd

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
DWORD Belt_getTd(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getTd",0);
	return PID_getTd(&(pBelt->pid));	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setAutoMode

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	
void Belt_setAutoMode(Belt* pBelt, UINT automode )
{
	PARAM_CHECK( pBelt, "Belt_setAutoMode");
	switch (automode)
	{
		case 0: //manual
			pBelt->autoMode = FALSE;
			pBelt->m_bSuspendProcessing = FALSE;
			break;
		case 1:
			pBelt->autoMode = TRUE;
			pBelt->m_bSuspendProcessing = FALSE;
			break;

		case 2:
			pBelt->m_bSuspendProcessing = TRUE;
			break;
	}		
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getCountMethod

			

 GLOBALS:
 RETURNS:   enum CountMethod
 SEE ALSO:
------------------------------------------------------------------------*/	
enum CountMethod Belt_getCountMethod( Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getCountMethod", 0);
	return pBelt->countMethod;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSummOfSpeeds

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
DWORD Belt_getSummOfSpeeds( Belt* pBelt )
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getSummOfSpeeds", 0);
	return pBelt->summOfSpeeds;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_get4BElapsedPositionCountTics

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
DWORD Belt_get4BElapsedPositionCountTics(Belt* pBelt )
{
	PARAM_CHECK_RETURN( pBelt, "Belt_get4BElapsedPositionCountTics", 0);
	return pBelt->fourBillionElapsedPositionCountTics;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setElapsedPositionCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	
void Belt_setElapsedPositionCounts(Belt* pBelt, DWORD elapsedPosCounts )
{
	PARAM_CHECK( pBelt, "Belt_setElapsedPositionCounts");
	pBelt->elapsedPositionCounts = elapsedPosCounts;
}

/******************************************************************************
	Belt_beltSpeedFilterCalc( ) 
	
	Abstract:
	The analogic controller counts the pulses from the quadrature encoder connected 
	to the conveyor. The summation of these counts on defined intervals is used to
	determine position. Because there is some apparent timing skew due to higher priority
	interrupts
.
		
	
	Programmer: Steven Young
	Date: 5/14/1998
******************************************************************************/
void Belt_beltSpeedFilterCalc(Belt* pBelt)
{
	LONG XInput, Youtput;
	PARAM_CHECK( pBelt, "Belt_beltSpeedFilterCalc");

	XInput = (pBelt->actualSpeedCounts_x_100) * 1000;
	Youtput = (XInput * ACOEFF / COEFFDENOM) + ( pBelt->YLastOutput * ONEMINUSACOEFF / COEFFDENOM);
	pBelt->YLastOutput = Youtput;
	pBelt->actualSpeedCounts_x_100 = Youtput / 1000;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_doPowerUpSequencing

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	
void Belt_doPowerUpSequencing(Belt* pBelt,UINT iActivatedGroup)
{
	PARAM_CHECK( pBelt, "Belt_doPowerUpSequencing");
	if(pBelt->bBeltSequenced) 
	{
		if(pBelt->iStartupGroup == iActivatedGroup)
		{
			pBelt->beltHasSequenced = TRUE;
		}
	}
	else
	{
		pBelt->beltHasSequenced = TRUE; //if not in the power up sequence it should always be active
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_initPowerUpSequencing

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	
void Belt_initPowerUpSequencing(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_initPowerUpSequencing");

	if(pBelt->bBeltSequenced)
	{
		pBelt->beltHasSequenced = FALSE;
	}
	else
	{
		pBelt->beltHasSequenced = TRUE; //if not in the power up sequence it should always be active
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getPosition

			

 GLOBALS:
 RETURNS:   const DWORD
 SEE ALSO:
------------------------------------------------------------------------*/	
const DWORD Belt_getPosition(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getPosition", 0);

	return pBelt->elapsedPositionCounts;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setBeltActive

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/	                                                                                
void  Belt_setBeltActive(Belt* pBelt, BOOL state)
{
	PARAM_CHECK( pBelt, "Belt_setBeltActive");
	pBelt->beltActive = state;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getBeltActive

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                
BOOL  Belt_getBeltActive(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getBeltActive", FALSE);
	return pBelt->beltActive;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getAutoMode

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
BOOL  Belt_getAutoMode(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getAutoMode", FALSE);
	return pBelt->autoMode; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getTPOoutputCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                
DWORD Belt_getTPOoutputCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getTPOoutputCounts", 0);
	return pBelt->beltTPOoutput; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getBeltId

			

 GLOBALS:
 RETURNS:   UCHAR
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                
UCHAR Belt_getBeltId(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getBeltId", 0);
	return pBelt->beltID; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setSpeedInCMsPerMin

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                     
void Belt_setSpeedInCMsPerMin(Belt* pBelt, DWORD setSpeedInCMsPerMin)
{
	PARAM_CHECK( pBelt, "Belt_setSpeedInCMsPerMin");
	Belt_resetDigitalStop(pBelt);
	pBelt->nonStandbySpeedInCMsPerMin = setSpeedInCMsPerMin;
	if(pBelt->mbStandbyMode!=TRUE)
		pBelt->speedInCMsPerMin = setSpeedInCMsPerMin; 

	if(setSpeedInCMsPerMin>=pBelt->switchSpeed)
	{
		pBelt->m_bUseHighOutput = TRUE;
	}
	else
	{
		pBelt->m_bUseHighOutput = FALSE;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSpeedInCMsPerMin

			used by the UI for speed display			

 RETURNS:   DWORD
------------------------------------------------------------------------*/                                                                                  
DWORD Belt_getSpeedInCMsPerMin(Belt* pBelt)
{
	DWORD dwrdReturn;
	dwrdReturn = 0;
	if(pBelt)
	{
		if((pBelt->m_bStoppedForSmema==TRUE) && (pBelt->autoMode == TRUE) && (pBelt->openLoopSystem == TRUE))
		{
			dwrdReturn = 0;
		}
		else
		{
			dwrdReturn = pBelt->speedInCMsPerMin;
		}
	}
	return dwrdReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSetPoint

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
DWORD Belt_getSetPoint(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getSetPoint", 0);
	return pBelt->setSpeedCountsPerSec; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSpeedCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                      
DWORD Belt_getSpeedCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getSpeedCounts", 0);
	return pBelt->actualSpeedCountsPerSec; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiDeadBandOffsetCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                    
void  Belt_setHiDeadBandOffsetCounts(Belt* pBelt, DWORD hiDeadBandInCounts )
{
	PARAM_CHECK( pBelt, "Belt_setHiDeadBandOffsetCounts");
	pBelt->hiDeadBandOffsetCounts = hiDeadBandInCounts; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLoDeadBandOffsetCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
void  Belt_setLoDeadBandOffsetCounts(Belt* pBelt, DWORD loDeadBandInCounts )
{
	PARAM_CHECK( pBelt, "Belt_setLoDeadBandOffsetCounts");
	pBelt->loDeadBandOffsetCounts = loDeadBandInCounts; 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiProcessCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
void  Belt_setHiProcessCounts(Belt* pBelt, DWORD hiProcCountsOffset )
{
	PARAM_CHECK( pBelt, "Belt_setHiProcessCounts");
	pBelt->hiProcessOffsetCounts = hiProcCountsOffset; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLoProcessCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
void  Belt_setLoProcessCounts(Belt* pBelt, DWORD loProcCountsOffset )
{
	PARAM_CHECK( pBelt, "Belt_setLoProcessCounts");
	pBelt->loProcessOffsetCounts = loProcCountsOffset; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiDeviationCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                 
void  Belt_setHiDeviationCounts(Belt* pBelt, DWORD hiDevCountsOffset )
{
	PARAM_CHECK( pBelt, "Belt_setHiDeviationCounts");
	pBelt->hiDeviationOffsetCounts = hiDevCountsOffset; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLoDeviationCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_setLoDeviationCounts(Belt* pBelt, DWORD loDevCountsOffset )
{
	PARAM_CHECK( pBelt, "Belt_setLoDeviationCounts");
	pBelt->loDeviationOffsetCounts = loDevCountsOffset; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiWarningCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_setHiWarningCounts(Belt* pBelt, DWORD hiWarnCountsOffset)
{
	PARAM_CHECK( pBelt, "Belt_setHiWarningCounts");
	pBelt->hiWarningOffsetCounts = hiWarnCountsOffset; 
	pBelt->m_iMotorFailCount = hiWarnCountsOffset;
	pBelt->m_iDeviationCOunt = hiWarnCountsOffset;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLoWarningCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_setLoWarningCounts(Belt* pBelt, DWORD loWarnCountsOffset)
{
	PARAM_CHECK( pBelt, "Belt_setLoWarningCounts");
	pBelt->loWarningOffsetCounts = loWarnCountsOffset; 
	pBelt->m_iDeviationCOuntL = loWarnCountsOffset;
	pBelt->m_iMotorFailCountL = loWarnCountsOffset;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableHiProcAlarm

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableHiProcAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableHiProcAlarm");
	pBelt->hiProcessAlarmEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableLoProcAlarm

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableLoProcAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableLoProcAlarm");
	pBelt->loProcessAlarmEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableHiDevAlarm

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableHiDevAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableHiDevAlarm");
	pBelt->hiDeviationAlarmEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableLoDevAlarm

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableLoDevAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableLoDevAlarm");
	pBelt->loDeviationAlarmEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableHiDevWarn

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableHiDevWarn(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableHiDevWarn");
	pBelt->hiDeviationWarningEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enableLoDevWarn

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enableLoDevWarn(Belt* pBelt, BOOL enable /*= TRUE*/ )
{
	PARAM_CHECK( pBelt, "Belt_enableLoDevWarn");
	pBelt->loDeviationWarningEnabled = enable; 
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_enterSlowPidValue

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_enterSlowPidValue(Belt* pBelt, LONG slowPidOffset)
{
	PARAM_CHECK( pBelt, "Belt_enterSlowPidValue");
	pBelt->m_lSlowPidRange = slowPidOffset;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setInputRangeLowValue

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
void  Belt_setInputRangeLowValue(Belt* pBelt, UINT low)
{
	PARAM_CHECK( pBelt, "Belt_setInputRangeLowValue");
	pBelt->m_iInLo = low;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getInputRangeLowValue

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/                                                                                                                                                               
UINT  Belt_getInputRangeLowValue(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getInputRangeLowValue", 0);
	return pBelt->m_iInLo;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setInputRangeHighValue

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setInputRangeHighValue(Belt* pBelt, UINT high)
{
	PARAM_CHECK( pBelt, "Belt_setInputRangeHighValue");
	pBelt->m_iInHi = high;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getInputRangeHighValue

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getInputRangeHighValue(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getInputRangeHighValue", 0);
	return pBelt->m_iInHi;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setPulsesPerCmCount

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setPulsesPerCmCount(Belt* pBelt, UINT pulses)
{
	PARAM_CHECK( pBelt, "Belt_setPulsesPerCmCount");
	pBelt->m_iPulsesPerCmBelt = pulses;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getPulsesPerCmCount

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getPulsesPerCmCount(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getPulsesPerCmCount", 0);
	return pBelt->m_iPulsesPerCmBelt;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setMaxFreq

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setMaxFreq(Belt* pBelt, UINT freq)
{
	PARAM_CHECK( pBelt, "Belt_setMaxFreq");
	pBelt->m_iMaxFreq = freq;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getMaxFreq

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getMaxFreq(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getMaxFreq", 0);
	return pBelt->m_iMaxFreq;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiSpeedLimit

			valid for open loop controler type only

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setHiSpeedLimit(Belt* pBelt, UINT speed)
{
	PARAM_CHECK( pBelt, "Belt_setHiSpeedLimit");
	pBelt->m_iRangeHiSpeed = speed;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiSpeedRange

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getHiSpeedRange(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiSpeedRange", 0);
	return pBelt->m_iRangeHiSpeed;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLowSpeedLimit

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setLowSpeedLimit(Belt* pBelt, UINT speed)
{
	PARAM_CHECK( pBelt, "Belt_setLowSpeedLimit");
	pBelt->m_iRangeLoSpeed = speed;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getLowSpeedLimit

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getLowSpeedLimit(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getLowSpeedLimit", 0);
	return pBelt->m_iRangeLoSpeed;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHiPercentLimit

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setHiPercentLimit(Belt* pBelt, UINT percent)
{
	PARAM_CHECK( pBelt, "Belt_setHiPercentLimit");
	pBelt->m_iRangeHiPercent = percent;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiPercentLimit

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getHiPercentLimit(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiPercentLimit", 0);
	return pBelt->m_iRangeHiPercent;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLoPercentLimit

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setLoPercentLimit(Belt* pBelt, UINT percent)
{
	PARAM_CHECK( pBelt, "Belt_setLoPercentLimit");
	pBelt->m_iRangeLoPercent = percent;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getLoPercentLimit

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getLoPercentLimit(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getLoPercentLimit", 0);
	return pBelt->m_iRangeLoPercent;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_doFastPidControl

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_doFastPidControl(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_doFastPidControl");
	pBelt->m_bDoFastCalculation = TRUE;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setSequenceGroup

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setSequenceGroup(Belt* pBelt, UINT sGroup )
{
	PARAM_CHECK( pBelt, "Belt_setSequenceGroup");
	pBelt->iStartupGroup = sGroup;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSequenceGroup

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT  Belt_getSequenceGroup(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getSequenceGroup", 0);
	return pBelt->iStartupGroup;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setIfSequenced

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setIfSequenced(Belt* pBelt, BOOL bSequenced)
{
	PARAM_CHECK( pBelt, "Belt_setIfSequenced");
	pBelt->bBeltSequenced = bSequenced;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setWarningTimeVariable

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void  Belt_setWarningTimeVariable(Belt* pBelt, DWORD d10thSec)
{
	PARAM_CHECK( pBelt, "Belt_setWarningTimeVariable");
	pBelt->m_dwrdWarnTime = d10thSec;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setProcMode

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setProcMode(Belt* pBelt,UINT pMode)
{ 
	PARAM_CHECK( pBelt, "Belt_setProcMode");
	pBelt->procMode = pMode;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_processDualMotor

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_processDualMotor(Belt* pBelt)
{
	int bAHigh = TRUE;
	int bBHigh = TRUE;
	int bALow = TRUE;
	int bBLow = TRUE;
	int bAInBand = FALSE;
	int bBInBand = FALSE;
	int bReturn = FALSE;
	int bBNotZero = FALSE;
	int bANotZero = FALSE;
	UINT currentIndexA = 0;
	UINT currentIndexB = 0;
//These variables are assigned from the class variables and adjusted for the current control rate
//10x for fast control, 1x for normal control
	DWORD localMotorTestTime = 0;
	DWORD localTestTime = 0;
	int i = 0;

	PARAM_CHECK_RETURN( pBelt, "Belt_processDualMotor", 0);

	if(pBelt->indexA >= DUAL_BUFFER_SIZE)
	{
		pBelt->indexA = (DUAL_BUFFER_SIZE - 1);
	}
	if(pBelt->indexB >= DUAL_BUFFER_SIZE)
	{
		pBelt->indexB = (DUAL_BUFFER_SIZE - 1);
	}
	Belt_MoveTo(pBelt, BELT_INDEX_A, pBelt->indexA);
	Belt_MoveTo(pBelt, BELT_INDEX_B, pBelt->indexB);
	currentIndexA = pBelt->indexA;
	currentIndexB = pBelt->indexB;
	pBelt->inputABuffer[pBelt->indexA--] = *(pBelt->pBeltSpeed);
	pBelt->inputBBuffer[pBelt->indexB--] = *(pBelt->pBeltSpeedB);

	if((Timer_getCurrentTime10ths(elapseTimer) > (pBelt->m_iDualMotorFailTime + pBelt->dualBeltTimer10ths)) ||
		!pBelt->beltHasSequenced)
	{
		pBelt->m_iTimesSinceMotorFailed++;												
		pBelt->m_iTimesSinceInputDeviated++;
	}
	if(!pBelt->beltHasSequenced)
	{
		pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
	}
	if(pBelt->m_bHybridOn && (pBelt->procMode == PROC_MODE_HYBRID))
	{
		pBelt->actualSpeedCountsPerSec = (*(pBelt->pBeltSpeed) + *(pBelt->pBeltSpeedB))/2;
	}
	else if (pBelt->procMode == PROC_MODE_A)
	{
		pBelt->actualSpeedCountsPerSec = *(pBelt->pBeltSpeed);
	}
	else if (pBelt->procMode == PROC_MODE_B)
	{
		pBelt->actualSpeedCountsPerSec = *(pBelt->pBeltSpeedB);
		bReturn = TRUE;
	}

	localMotorTestTime = pBelt->m_iMotorTestTime * 10;
	localTestTime = pBelt->m_iTestTime * 10;
	if(pBelt->m_iMotorTestTime == 0) //do not allow instant switching
	{
		localMotorTestTime = 10;
	}
	if(pBelt->m_iTestTime == 0)
	{
		localTestTime = 10;
	}
	pBelt->m_iNumberOfSlowLoops = 0;

	bReturn = TRUE;
				
	for(i = 0; i < localMotorTestTime; i++)
	{
		if(*(pBelt->ptrCurrentInputA) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iMotorFailCount))
		{
			bAHigh = FALSE;
		}
		if(*(pBelt->ptrCurrentInputB) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iMotorFailCount))
		{
			bBHigh = FALSE;
		}
		if((*(pBelt->ptrCurrentInputA) >= MOTOR_FAILURE_COUNTS) || (pBelt->setSpeedCountsPerSec <= MOTOR_FAILURE_COUNTS))
		{
			bALow = FALSE;
		}
		if((*(pBelt->ptrCurrentInputB) >= MOTOR_FAILURE_COUNTS) || (pBelt->setSpeedCountsPerSec <= MOTOR_FAILURE_COUNTS))
		{
			bBLow = FALSE;
		}
		Belt_AdvanceWordPoint(pBelt, BELT_INDEX_A);
		Belt_AdvanceWordPoint(pBelt, BELT_INDEX_B);
	}

	Belt_MoveTo(pBelt, BELT_INDEX_A, currentIndexA);
	Belt_MoveTo(pBelt, BELT_INDEX_B, currentIndexB);

	if((bALow && bBLow) && pBelt->m_iTimesSinceMotorFailed >= localMotorTestTime)
	{
		pBelt->secondaryMotor = !pBelt->secondaryMotor;
		if(pBelt->secondaryMotor)//motorb
		{
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_MOTOR_SWITCHB, pBelt->beltID );
		}
		else
		{
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_MOTOR_SWITCH, pBelt->beltID );
		}
		pBelt->m_iTimesSinceMotorFailed = 0;											
		pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
	}

	bAHigh = bBHigh = bALow = bBLow = TRUE;	
	bBInBand = bAInBand = FALSE;
	for(i = 0; i < localTestTime; i++)
	{
		if(*(pBelt->ptrCurrentInputA) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iDeviationCOunt))
		{
			bAHigh = FALSE;
		}

		if(*(pBelt->ptrCurrentInputB) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iDeviationCOunt))
		{
			bBHigh = FALSE;
		}

		if(*(pBelt->ptrCurrentInputB) > MOTOR_FAILURE_COUNTS)
		{
			bBNotZero = TRUE;
		}

		if(*(pBelt->ptrCurrentInputA) > MOTOR_FAILURE_COUNTS)
		{
			bANotZero = TRUE;
		}
//If the inputs are within two counts either way we will assume that they are reading correctly and the difference
// is not due to a generalized input failure
		if((*(pBelt->ptrCurrentInputA) <= (*(pBelt->ptrCurrentInputB) + INPUT_DIFF_TOLERANCE)) && 
			(*(pBelt->ptrCurrentInputA) >= (*(pBelt->ptrCurrentInputB) - INPUT_DIFF_TOLERANCE)))
		{
			bAHigh = FALSE;
			bALow = FALSE;
		}
		else if((*(pBelt->ptrCurrentInputB) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iDeviationCOunt))  &&
			(*(pBelt->ptrCurrentInputB) >= (pBelt->setSpeedCountsPerSec - pBelt->m_iDeviationCOuntL)))
		{
			bBInBand = TRUE;
		}
//if they are not within two counts test to see if the other is in deadband
		
		if((*(pBelt->ptrCurrentInputB) <= (*(pBelt->ptrCurrentInputA) + INPUT_DIFF_TOLERANCE)) && 
			(*(pBelt->ptrCurrentInputB) >= (*(pBelt->ptrCurrentInputA) - INPUT_DIFF_TOLERANCE)))
		{
			bBHigh = FALSE;
			bBLow = FALSE;
		}		
		else if((*(pBelt->ptrCurrentInputA) <= (pBelt->setSpeedCountsPerSec + pBelt->m_iDeviationCOunt))  && 
			(*(pBelt->ptrCurrentInputA) >= (pBelt->setSpeedCountsPerSec - pBelt->m_iDeviationCOuntL)))
		{
			bAInBand = TRUE;
		}

		if(*(pBelt->ptrCurrentInputA) >= (pBelt->setSpeedCountsPerSec - pBelt->m_iDeviationCOuntL))
		{
			bALow = FALSE;
		}

		if(*(pBelt->ptrCurrentInputB) >= (pBelt->setSpeedCountsPerSec - pBelt->m_iDeviationCOuntL))
		{
			bBLow = FALSE;
		}

		Belt_AdvanceWordPoint(pBelt, BELT_INDEX_A);
		Belt_AdvanceWordPoint(pBelt, BELT_INDEX_B);
	}
	Belt_MoveTo(pBelt, BELT_INDEX_A, currentIndexA);
	Belt_MoveTo(pBelt, BELT_INDEX_B, currentIndexB);

	if((bAHigh && !bBHigh && bBNotZero) && pBelt->procMode == PROC_MODE_A)//testing proc mode so only the current output is declared bad
	{
		if(pBelt->m_iTimesSinceInputDeviated > localTestTime)
		{
			pBelt->m_iTimesSinceInputDeviated = 0;
			pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, TM_OUTPUT_ON, pBelt->beltID );
			pBelt->procMode = PROC_MODE_B;
		}
	}

	if((bALow && !bBLow) && pBelt->procMode == PROC_MODE_A)//testing proc mode so only the current output is declared bad
	{
		if(pBelt->m_iTimesSinceInputDeviated > localTestTime)
		{
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, TM_OUTPUT_ON, pBelt->beltID );
			pBelt->m_iTimesSinceInputDeviated = 0;
			pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
			pBelt->procMode = PROC_MODE_B;
		}
	}
	if((!bAHigh && bBHigh && bANotZero) && (pBelt->procMode == PROC_MODE_B))
	{
		if(pBelt->m_iTimesSinceInputDeviated > localTestTime)
		{
			pBelt->m_iTimesSinceInputDeviated = 0;
			pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, TM_OUTPUT_OFF, pBelt->beltID );
			pBelt->procMode = PROC_MODE_A;
		}
	}

	if((!bALow && bBLow) && (pBelt->procMode == PROC_MODE_B))
	{
		if(pBelt->m_iTimesSinceInputDeviated > localTestTime)
		{
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, TM_OUTPUT_OFF, pBelt->beltID );
			pBelt->m_iTimesSinceInputDeviated = 0;
			pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
			pBelt->procMode = PROC_MODE_A;
		}
	}


	switch(pBelt->m_iOutputBehave)
	{
	case 0:
		break;
	case 1:
		if(pBelt->m_iWhichOutput !=99)
		{
			if(!pBelt->secondaryMotor)
			{
				Purge_setTwoMotorOutputValue(purgeControl, FALSE);
			}
			else
			{
				Purge_setTwoMotorOutputValue(purgeControl, TRUE);
			}
		}
		break;
	case 2:
		if(pBelt->m_iWhichOutput !=99)
		{
			if(!pBelt->secondaryMotor)
			{
				Purge_setTwoMotorOutputValue(purgeControl, TRUE);

			}
			else
			{
				Purge_setTwoMotorOutputValue(purgeControl, FALSE);
			}
		}
	default:
		break;
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_AdvanceWordPoint

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_AdvanceWordPoint(Belt* pBelt, UINT whichPointer)
{
	PARAM_CHECK( pBelt, "Belt_AdvanceWordPoint");

// 100 position buffer, if at tail advance to head
	switch(whichPointer)
	{
	case BELT_INDEX_A:
		if(pBelt->uintPtrALocation != (DUAL_BUFFER_SIZE-1))
		{
			pBelt->uintPtrALocation++;
			pBelt->ptrCurrentInputA++;
		}
		else
		{
			pBelt->uintPtrALocation = 0;
			pBelt->ptrCurrentInputA = pBelt->inputABuffer;
		}
		break;

	case BELT_INDEX_B:
		if(pBelt->uintPtrBLocation != (DUAL_BUFFER_SIZE - 1))
		{
			pBelt->uintPtrBLocation++;
			pBelt->ptrCurrentInputB++;
		}
		else
		{
			pBelt->uintPtrALocation = 0;
			pBelt->ptrCurrentInputB = pBelt->inputABuffer;
		}
		break;

	default:
		break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_MoveTo

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_MoveTo(Belt* pBelt, UINT whichInput, UINT moveTo)
{
	UINT moveAmount = 0;
	PARAM_CHECK_RETURN( pBelt, "Belt_MoveTo",0);
	BOOL bReturn = TRUE;
	if(moveTo < DUAL_BUFFER_SIZE)
	{
		switch(whichInput)
		{
		case BELT_INDEX_A:
			moveAmount = pBelt->uintPtrALocation = moveTo;
			pBelt->ptrCurrentInputA = pBelt->inputABuffer;
			while(moveAmount > 0)
			{
				pBelt->ptrCurrentInputA++;
				moveAmount--;
			};
			break;

		case BELT_INDEX_B:
			moveAmount = pBelt->uintPtrBLocation = moveTo;
			pBelt->ptrCurrentInputB = pBelt->inputBBuffer;
			while(moveAmount > 0)
			{
				pBelt->ptrCurrentInputB++;
				moveAmount--;
			};
			break;

		default:
			bReturn = FALSE;
			break;
		}
	}
	else
	{
		bReturn = FALSE;
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_configureBeltOutputB

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_configureBeltOutputB(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_configureBeltOutputB");
	pBelt->wrdBeltOutput2 = TPO_CONVBELT2;
	pBelt->pBeltTPOoutB = (WORD*) ANALOGOUT_GetAt(analogOutDb, TPO_CONVBELT2);//&(*(analogOutDb))[TPO_CONVBELT2];				
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDeadbandDeviationTime

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setDeadbandDeviationTime(Belt* pBelt, DWORD dwrd10thSec)
{
	DWORD dwrdLocalWarnTime = 0;
	PARAM_CHECK( pBelt, "Belt_setDeadbandDeviationTime");

	dwrdLocalWarnTime = pBelt->m_dwrdWarnTime;

	//The times used in dual control are not timer comparisions but variables to extract
	//data from the historical buffer (updated once a second).  We must convert from 10ths
	//of seconds to seconds.  If the call frequency of process dual motors is changed then they should
	//be adjusted appropriately

	if(dwrdLocalWarnTime > 9)
	{
		dwrdLocalWarnTime = dwrdLocalWarnTime / 10;
	}
	pBelt->m_dwrdDbDevTime = dwrd10thSec;
	if(dwrd10thSec > 9)
	{
		dwrd10thSec = dwrd10thSec/10;
	}
	pBelt->m_iMotorTestTime = dwrd10thSec;
	pBelt->m_iTestTime = dwrd10thSec;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setBeltIOConfigured

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setBeltIOConfigured(Belt* pBelt, BOOL bIOCon)
{
	PARAM_CHECK( pBelt, "Belt_setBeltIOConfigured");
	pBelt->beltIOConfigured = bIOCon;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_init
			
			

 GLOBALS:	g_dbContainer
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_init(Belts* pBelts)
{
	int i = 0;
	PARAM_CHECK( pBelts, "Belts_init");

	pBelts->noOfActiveBelts = 0;
	pBelts->BeltSpeedPIDTrig = FALSE;
	pBelts->beltsLoaded	= 0;
	pBelts->m_bOutputActive = FALSE;

	pBelts->m_bAutoRange = FALSE;
	pBelts->m_iOutput = 100;
	for(i=0; i < MaxBelts; i++)
	{
		Belt_init( &(g_dbContainer.belt[i]));
	}
	alarmQueueDb = &(g_dbContainer.alarmQueueDb );
	railsDb = &(g_dbContainer.railsDb );
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setNoOfActiveBelts

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belts_setNoOfActiveBelts(Belts* pBelts, DWORD activeBelts )
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pBelts, "Belts_setNoOfActiveBelts", FALSE);
	switch ( activeBelts )
	{
		case 0:			// no belts configured
			pBelts->noOfActiveBelts = 0;
			Belt_setBeltActive(&(g_dbContainer.belt[0]), FALSE);
			Belt_setBeltActive(&(g_dbContainer.belt[1]), FALSE);
			break;
		case 1:			// 1 belt active the second belt is inactive
			pBelts->noOfActiveBelts = 1;
			Belt_setBeltActive(&(g_dbContainer.belt[0]), TRUE);	
			Belt_setBeltActive(&(g_dbContainer.belt[1]), FALSE);
			Belt_configureBeltIO(&(g_dbContainer.belt[0]));										
			break;
		case 2:			// 2 belts active
			pBelts->noOfActiveBelts = 2;
			Belt_setBeltActive(&(g_dbContainer.belt[0]), TRUE);
			Belt_setBeltActive(&(g_dbContainer.belt[1]), TRUE);
			Belt_configureBeltIO(&(g_dbContainer.belt[0]));
			Belt_configureBeltIO(&(g_dbContainer.belt[1]));
			break;
		default:		// an invalid number of active belts is set.
			pBelts->noOfActiveBelts = 0;
			Belt_setBeltActive(&(g_dbContainer.belt[0]), FALSE);
			Belt_setBeltActive(&(g_dbContainer.belt[1]), FALSE);
	}

	Belt_setBeltIOConfigured(&(g_dbContainer.belt[0]), FALSE);
	Belt_setBeltIOConfigured(&(g_dbContainer.belt[1]), FALSE);
	
	return status;
}

//******************************************************************************
// Belts_process
//
// Abstract:
// 	The container function that calls the individual belts to process themselves.
//
// Programmer: Steven Young
// Date: 04/16/1998
//
//******************************************************************************
void Belts_process(Belts* pBelts)
{
	unsigned int lcv = 0;
	BOOL bSetHigh = FALSE;
	PARAM_CHECK( pBelts, "Belts_process");

	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		Belt_process(&(g_dbContainer.belt[lcv]));
	}
	if(pBelts->m_bAutoRange == TRUE)
	{
		for(lcv=0; lcv<MaxBelts; lcv++)
		{
			if(Belt_getBeltActive(&(g_dbContainer.belt[lcv]))==TRUE)
			{
				if (g_dbContainer.belt[lcv].m_bUseHighOutput==TRUE) 						
				{
					bSetHigh = TRUE;
				}
			}
		}
		if(bSetHigh)
		{
			if(!pBelts->m_bOutputActive &&(pBelts->m_iOutput < MAX_DIGITAL_OUTPUTS))
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_HI_ACTIVE_OUTPUT, 0);
			}
		}
		else
		{
			if(pBelts->m_bOutputActive && (pBelts->m_iOutput < MAX_DIGITAL_OUTPUTS))
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, BELT_LO_ACTIVE_INPUT, 0);
			}
		}
		pBelts->m_bOutputActive = bSetHigh;
		if(pBelts->m_iOutput < MAX_DIGITAL_OUTPUTS)
		{
			*DOUT_GetAt(digOutDb, pBelts->m_iOutput) = pBelts->m_bOutputActive;
		}
	}

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_IsWarningConditionPresent

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belts_IsWarningConditionPresent(Belts* pBelts, short beltNo)
{
	PARAM_CHECK_RETURN( pBelts, "Belts_IsWarningConditionPresent", FALSE);
    return Belt_IsBeltInWarning(&(g_dbContainer.belt[beltNo]));
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_getNoOfActiveBelts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belts_getNoOfActiveBelts(Belts* pBelts)
{
	PARAM_CHECK_RETURN( pBelts, "Belts_getNoOfActiveBelts", 0);
	return pBelts->noOfActiveBelts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_doPowerUpSequencing

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_doPowerUpSequencing(Belts* pBelts, UINT iGroup)
{
	unsigned int lcv = 0;
	PARAM_CHECK( pBelts, "Belts_doPowerUpSequencing");

	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		Belt_doPowerUpSequencing(&(g_dbContainer.belt[lcv]), iGroup);
	}
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_initializePowerUpSequencing

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_initializePowerUpSequencing(Belts* pBelts)
{
	unsigned int lcv = 0;
	PARAM_CHECK( pBelts, "Belts_initializePowerUpSequencing");

	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		Belt_initPowerUpSequencing(&(g_dbContainer.belt[lcv]));
	}
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_standbyMode

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_standbyMode(Belts* pBelts, BOOL bOn)
{
	unsigned int lcv = 0;
	PARAM_CHECK( pBelts, "Belts_standbyMode");
	
	if(bOn!=g_dbContainer.belt[lcv].mbStandbyMode)
	{
		for ( lcv = 0; lcv < MaxBelts; lcv++ )
		{
			Belt_standbyMode(&(g_dbContainer.belt[lcv]), bOn);
	
		}
	}
}
//////////////////////////////////////////////////////////////////////
//void Belts_BeltsAreSequenced(BOOL bSequenced)
//
//
//
//Passes the sequence belt flag to individual belt.  If the belt is not
//sequenced(false) it will behave in the default manner, if it is sequenced
//the belt will not move in cooldown and will start when the tempzones class
//sequence the appropriate group.
///////////////////////////////////////////////////////////////////////		
void Belts_BeltsAreSequenced(Belts* pBelts, BOOL bSequenced)
{
	unsigned int lcv = 0;
	PARAM_CHECK( pBelts, "Belts_BeltsAreSequenced");

	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		Belt_setIfSequenced(&(g_dbContainer.belt[lcv]), bSequenced);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_returnNumberOfBeltsInStartUpSequence

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Belts_returnNumberOfBeltsInStartUpSequence(Belts* pBelts, UINT iSequence)
{
	unsigned int lcv = 0;
	UINT beltsInStartupSequence = 0;
	PARAM_CHECK_RETURN( pBelts, "Belts_returnNumberOfBeltsInStartUpSequence", 0);

	for ( lcv = 0; lcv < pBelts->noOfActiveBelts; lcv++ )
	{
		if(Belt_getSequenceGroup(&(g_dbContainer.belt[lcv])) == iSequence)
		{
			beltsInStartupSequence++;
		}
	}
	return beltsInStartupSequence;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_addBelt

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belts_addBelt(Belts* pBelts)
{
	PARAM_CHECK_RETURN( pBelts, "Belts_addBelt", 0);
	return pBelts->beltsLoaded++;
}  // increment for belt id
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_getBeltsLoaded

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Belts_getBeltsLoaded(Belts* pBelts)
{
	PARAM_CHECK_RETURN( pBelts, "Belts_getBeltsLoaded", 0);
	return pBelts->beltsLoaded; 
}  // need this for parent Id
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_SetBeltSpeedPIDTrig

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_SetBeltSpeedPIDTrig(Belts* pBelts, BOOL state)
{
	PARAM_CHECK( pBelts, "Belts_SetBeltSpeedPIDTrig");
	pBelts->BeltSpeedPIDTrig = state;
}
                                                                                
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_GetBeltSpeedPIDTrig

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belts_GetBeltSpeedPIDTrig(Belts* pBelts)
{
	PARAM_CHECK_RETURN( pBelts, "Belts_GetBeltSpeedPIDTrig", FALSE);
	return pBelts->BeltSpeedPIDTrig; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiDeadBandOffsetCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getHiDeadBandOffsetCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiDeadBandOffsetCounts", FALSE);
	return pBelt->hiDeadBandOffsetCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiProcessCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getHiProcessCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiProcessCounts", FALSE);
	return pBelt->hiProcessOffsetCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiDeviationCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getHiDeviationCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiDeviationCounts", FALSE);
	return pBelt->hiDeviationOffsetCounts;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getHiWarningCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getHiWarningCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getHiWarningCounts", FALSE);
	return pBelt->hiWarningOffsetCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getLoWarningCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getLoWarningCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getLoWarningCounts", FALSE);
	return pBelt->loWarningOffsetCounts;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getLoDeviationCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getLoDeviationCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getLoDeviationCounts", FALSE);
	return pBelt->loDeviationOffsetCounts;

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getLoProcessCounts

			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Belt_getLoProcessCounts(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_getLoProcessCounts", FALSE);
	return pBelt->loProcessOffsetCounts;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnHiProcAlarm

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnHiProcAlarm(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnHiProcAlarm", FALSE);
	return pBelt->hiProcessAlarmEnabled;

}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnHiDevAlarm

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnHiDevAlarm(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnHiDevAlarm", FALSE);
	return pBelt->hiDeviationAlarmEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnHiDevWarn

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnHiDevWarn(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnHiDevWarn", FALSE);
	return pBelt->hiDeviationWarningEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnLoDevWarn

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnLoDevWarn(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnLoDevWarn", FALSE);
	return pBelt->loDeviationWarningEnabled;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnLoDevAlarm

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnLoDevAlarm(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnLoDevAlarm", FALSE);
	return pBelt->loDeviationAlarmEnabled;

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_returnLoProcAlarm

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belt_returnLoProcAlarm(Belt* pBelt)
{
	PARAM_CHECK_RETURN( pBelt, "Belt_returnLoProcAlarm", FALSE);
	return pBelt->loProcessAlarmEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setdualBeltTimer10ths

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setdualBeltTimer10ths(Belt* pBelt, UINT iDevCount)
{
	PARAM_CHECK( pBelt, "Belt_setdualBeltTimer10ths");
	pBelt->dualBeltTimer10ths = (DWORD) iDevCount;}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setDifferentialCounts

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setDifferentialCounts(Belts* pBelts, UINT iDeviationCOunt)
{
	Belt_setdualBeltTimer10ths(&(g_dbContainer.belt[0]), iDeviationCOunt);	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHighDevInput

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setHighDevInput(Belt* pBelt, BOOL bHighDevInput)
{
	PARAM_CHECK( pBelt, "Belt_setHighDevInput");
	pBelt->m_bHighDevInput = bHighDevInput;}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setHiDevBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setHiDevBehavior(Belts* pBelts, BOOL bHighDevInput)
{
	Belt_setHighDevInput(&(g_dbContainer.belt[0]), bHighDevInput);	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setLowDevBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setLowDevBehavior(Belt* pBelt, BOOL bLowDevInput)
{
	PARAM_CHECK( pBelt, "Belt_setLowDevBehavior");
	pBelt->m_bLowDevInput = bLowDevInput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setLowDevBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setLowDevBehavior(Belts* pBelts, BOOL bLowDevInput)
{
//	ptrParentContainer->belt[0].m_bLowDevInput = bLowDevInput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setHybridBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setHybridBehavior(Belt* pBelt, BOOL bHybridOn)
{
	PARAM_CHECK( pBelt, "Belt_setHybridBehavior");
	pBelt->m_bHybridOn = bHybridOn;
	if(bHybridOn)
	{
		pBelt->procMode = 0;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setHybridBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setHybridBehavior(Belts* pBelts, BOOL bHybridOn)
{
	Belt_setHybridBehavior(&(g_dbContainer.belt[0]), bHybridOn);	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDigOutputBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setDigOutputBehavior(Belt* pBelt, UINT iOutputBehave)
{
	PARAM_CHECK( pBelt, "Belt_setDigOutputBehavior");
	pBelt->m_iOutputBehave = iOutputBehave;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setDigOutputBehavior

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setDigOutputBehavior(Belts* pBelts, UINT iOutputBehave)
{
	Belt_setDigOutputBehavior(&(g_dbContainer.belt[0]), iOutputBehave);	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDigOutput

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setDigOutput(Belt* pBelt, UINT iWhichOutput)
{
	PARAM_CHECK( pBelt, "Belt_setDigOutput");
	pBelt->m_iWhichOutput = iWhichOutput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setDigOutput

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setDigOutput(Belts* pBelts, UINT iWhichOutput)
{
	Belt_setDigOutput(&(g_dbContainer.belt[0]), iWhichOutput);	
	if(iWhichOutput != 99)
	{
		*DOUT_GetAt(&(g_dbContainer.digitalOutDb), iWhichOutput) = FALSE;
	}
	Purge_setTwoMotorOutputValue(&(g_dbContainer.purge), FALSE);
	Purge_setTwoMotorOutput(&(g_dbContainer.purge), iWhichOutput);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDualMotors

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setDualMotors(Belt* pBelt, BOOL bDualMotors)
{
	PARAM_CHECK( pBelt, "Belt_setDualMotors");
	pBelt->m_bDualMotors = bDualMotors;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setsecondaryMotor

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setsecondaryMotor(Belt* pBelt, BOOL bSec)
{
	PARAM_CHECK( pBelt, "Belt_setsecondaryMotor");
	pBelt->secondaryMotor = bSec;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDualMotorFailTime

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_setDualMotorFailTime(Belt* pBelt, DWORD dwrdFailTime)
{
	PARAM_CHECK( pBelt, "Belt_setDualMotorFailTime");
	pBelt->secondaryMotor = dwrdFailTime;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setDualMotors

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setDualMotors(Belts* pBelts, BOOL bDualMotors)
{

	Belt_setDualMotors(&(g_dbContainer.belt[0]), bDualMotors);
	Belt_setsecondaryMotor(&(g_dbContainer.belt[0]), FALSE);
	Belt_setDualMotorFailTime(&(g_dbContainer.belt[0]), 0);
	DWORD noOfActiveRails = Rails_getNoOfActiveRails(railsDb);  
	if(bDualMotors)
	{
		Belt_setBeltActive(&(g_dbContainer.belt[1]), FALSE);
		Belt_configureBeltOutputB(&(g_dbContainer.belt[0]));
		switch(noOfActiveRails)
		{
			case 0:
				g_dbContainer.belt[0].pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_2_SPEED);

				g_dbContainer.belt[0].pBeltSpeedB  = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_SPEED);
				g_dbContainer.belt[0].pBeltPosMSW_B = (WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_MSW);
				g_dbContainer.belt[0].pBeltPosLSW_B =(WORD*) ANALOGIN_GetAt(analogInDb, PULSE_COUNTER_1_LSW); 
			break;
			case 1:
				g_dbContainer.belt[0].pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_2_SPEED);
				g_dbContainer.belt[0].pBeltSpeedB  = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_SPEED);
				g_dbContainer.belt[0].pBeltPosMSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_MSW);
            	g_dbContainer.belt[0].pBeltPosLSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_LSW);  
				break;
			case 2:
				g_dbContainer.belt[0].pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_3_SPEED);
				g_dbContainer.belt[0].pBeltSpeedB  = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_SPEED);
				g_dbContainer.belt[0].pBeltPosMSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_MSW);
            	g_dbContainer.belt[0].pBeltPosLSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_LSW);  
				break;

			case 3:
				g_dbContainer.belt[0].pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb, AI_FREE_L1SR);
				g_dbContainer.belt[0].pBeltSpeedB  = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_SPEED);
				g_dbContainer.belt[0].pBeltPosMSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_MSW);
            	g_dbContainer.belt[0].pBeltPosLSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_LSW);
				break;

			case 4:
				g_dbContainer.belt[0].pBeltSpeed  = (WORD*) ANALOGIN_GetAt(analogInDb,AI_FREE_L1SR);
				g_dbContainer.belt[0].pBeltSpeedB  = (WORD*) ANALOGIN_GetAt(analogInDb,AI_FREE_L2SR);
				g_dbContainer.belt[0].pBeltPosMSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_MSW);
            	g_dbContainer.belt[0].pBeltPosLSW_B = (WORD*) ANALOGIN_GetAt(analogInDb,PULSE_COUNTER_4_LSW);
				break;
		}
		//default control should be motor A
		Purge_setTwoMotorOutputValue(purgeControl, FALSE);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_TempzonesAreSequenced

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Belts_TempzonesAreSequenced(Belts* pBelts, BOOL bSequence)
{
	g_dbContainer.belt[0].bTempzonesSequenced = bSequence;
	return bSequence;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_testCriticalPath

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_testCriticalPath(int iTest)
{
	iTestBeltTPO = iTest;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_enableAutoRange

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_enableAutoRange(Belts* pBelts, BOOL enable)
{
	pBelts->m_bAutoRange=enable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_enableAutoRangeOutput

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_enableAutoRangeOutput(Belts* pBelts, UINT output)
{
	pBelts->m_iOutput = output;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_setAutoRangeSwitch

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_setAutoRangeSwitch(Belts* pBelts, DWORD setting)
{
	unsigned int lcv;
	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		g_dbContainer.belt[lcv].switchSpeed = (LONG)setting;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_positionOnlyProcess

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_positionOnlyProcess(Belt* pBelt)
{
	if(pBelt->beltActive)
	{
		Belt_beltPositionCalculation(pBelt); 
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_smemaAllow

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Belt_smemaAllow(Belt* pBelt)
{
	UINT iReturn = 0;
	if(pBelt->openLoopSystem && (pBelt->speedInCMsPerMin > 0))
	{
		iReturn= 1;
	}
	else if((pBelt->speedInCMsPerMin > 0)&&(pBelt->actualSpeedCountsPerSec > 0))
	{
		iReturn= 1;
	}
	if(pBelt->beltActive==FALSE)
	{
		iReturn = 1;
	}
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belts_SmemaOffDist

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belts_SmemaOffDist(Belts* pBelts, DWORD delayCounts)
{
	unsigned int lcv = 0;

	for ( lcv = 0; lcv < MaxBelts; lcv++ )
	{
		Belt_SmemaOffDist(&(g_dbContainer.belt[lcv]), delayCounts);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_SmemaOffDist

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_SmemaOffDist(Belt* pBelt, DWORD delayCounts)
{
	pBelt->m_dwrdOffDist = delayCounts;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_SuspendForSmema

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_SuspendForSmema(Belt* pBelt, UINT smemaIndex, BOOL bSuspend, UINT type)
{
	BOOL bClear = TRUE;
	int i = 0;
	int j = 0;
	if(smemaIndex >= MAX_SMEMA_LANES||type>=2)
	{
	}
	else
	{
		if((bSuspend==TRUE) && (pBelt->m_bSmemaRequest[smemaIndex][type]==FALSE))
		{
			if(pBelt->m_dwrdOffDist!=0)
			{
				pBelt->m_dwrdCureStart[smemaIndex][type]=Timer_getCurrentTime10ths(elapseTimer);
			}
				
			if((pBelt->m_bStoppedForSmema==FALSE))
			{
				if((pBelt->m_dwrdOffDist==0)&&(pBelt->m_bSmemaRequestHistory[smemaIndex][type]==FALSE) )//log immediately
				{
					SMEMA_informGUIofBeltStop(pBelt->m_smemaLanes[smemaIndex]);	
				}
			}

			pBelt->m_bWantStopForSmema=TRUE;
			pBelt->m_bSmemaRequestHistory[smemaIndex][type]=TRUE;
			pBelt->m_bSmemaRequest[smemaIndex][type]=TRUE;
		}
		else if((bSuspend==FALSE) && ((pBelt->m_bStoppedForSmema==TRUE) ||
			(pBelt->m_bSmemaRequest[smemaIndex][type] == TRUE)))
		{
		
			pBelt->m_bSmemaRequestHistory[smemaIndex][type]=FALSE;
			pBelt->m_bSmemaRequest[smemaIndex][type]=FALSE;
			pBelt->m_bSmemaOff[smemaIndex][type]=FALSE;
			for(i=0; i<MAX_SMEMA_LANES; i++)
			{
				for(j=0; j < MaxBelts; j++)
				{ 	
					if((pBelt->m_bSmemaRequest[i][j])==TRUE)
					{
						bClear = FALSE;
					}
					
				}
				if((type==0)&&((pBelt->m_bSmemaRequestHistory[i][1])==TRUE))
				{
					bClear=FALSE;
				}
				if((type!=0) && (i!=smemaIndex)&&((pBelt->m_bSmemaRequestHistory[i][1])==TRUE))
				{
					bClear=FALSE;					
				}
				if((type==1)&&((pBelt->m_bSmemaRequestHistory[i][0])==TRUE))
				{
					bClear=FALSE;
				}
				if((type!=1) && (i!=smemaIndex)&&((pBelt->m_bSmemaRequestHistory[i][0])==TRUE))
				{
					bClear=FALSE;					
				}
			}

			if(bClear==TRUE)
			{
				pBelt->m_bStoppedForSmema=FALSE;
				pBelt->m_bWantStopForSmema=FALSE;
			}

		}

		pBelt->m_bSmemaRequestHistory[smemaIndex][type] = bSuspend;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_CureExitTest

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_CureExitTest(Belt* pBelt)
{
	int i = 0;
	int j = 0;
	DWORD curTime = 0;
	if(pBelt->m_bWantStopForSmema==TRUE)
	{
		curTime = Timer_getCurrentTime10ths(elapseTimer);
		for(j = 0; j < MaxBelts; j++)
		{
			for(i=0; i<MAX_SMEMA_LANES; i++)
			{
				if((pBelt->m_bSmemaRequest[i][j] == TRUE) && (pBelt->m_dwrdOffDist < (differenceWithRollover(curTime,pBelt->m_dwrdCureStart[i][j]))))
				{
					pBelt->m_bSmemaRequest[i][j]=FALSE;
					if(pBelt->m_bStoppedForSmema==FALSE)
					{
						SMEMA_informGUIofBeltStop(pBelt->m_smemaLanes[i]);
					}
					pBelt->m_bStoppedForSmema=TRUE;
					pBelt->m_bSmemaRequestHistory[i][j]=TRUE;
				}
			}
		}
		pBelt->m_bWantStopForSmema = FALSE;
		for(j = 0; j < MaxBelts; j++)
		{
			for(i = 0; i<MAX_SMEMA_LANES; i++)
			{
				if(pBelt->m_bSmemaRequest[i][j]==TRUE)
				{
					pBelt->m_bWantStopForSmema = TRUE;
				}
			}
		}
	}
}
///////////////////////////////////////////////////////////////////
//Will clear belt shutdown during recipe transition
//only for the second bank which is controlled by external smema
//we also now need to record who requested the shutdown, as type 1 is not
//recovered on recipe transition
/////////////////////////////////////////////////////////////////
void Belt_CureInit(Belt* pBelt)
{
	int i = 0;
	int j = 1;
	BOOL bStopped = pBelt->m_bStoppedForSmema;
	BOOL bWantsStop = pBelt->m_bWantStopForSmema;
	pBelt->m_bStoppedForSmema=FALSE;
	pBelt->m_bWantStopForSmema=FALSE;

	for(i=0; i<MAX_SMEMA_LANES; i++)
	{
		pBelt->m_bSmemaRequest[i][j]=FALSE;
		pBelt->m_dwrdCureStart[i][j]=0;
		pBelt->m_bSmemaRequestHistory[i][j]=FALSE;
	}
	for(i=0; i<MAX_SMEMA_LANES; i++)
	{
		if(pBelt->m_bSmemaRequestHistory[i][0]==TRUE)
		{
	 		pBelt->m_bStoppedForSmema=bStopped;
	  		pBelt->m_bWantStopForSmema=bWantsStop;
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_getSMEMASuspend

			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Belt_getSMEMASuspend(Belt* pBelt)
{
	UINT iReturn = 0;
	if(pBelt->beltActive==FALSE)
	{
		iReturn = 0;
	}
	else if(pBelt->m_bStoppedForSmema==TRUE)
	{
		iReturn = 1;
	}
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_clearSelfAck

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Belt_clearSelfAck(Belt* pBelt)
{
	PARAM_CHECK( pBelt, "Belt_clearSelfAck");
	if(Oven_getIsAutoAcknowledgedDisabled(ovenDb))
	{
		pBelt->selfAckAlarmNo = 0;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_standbyMode

			//Switches belt between normal operations and standby mode speed.
			//leaves the default sp as is so channel status is correct
			

 RETURNS:   void
------------------------------------------------------------------------*/
void Belt_standbyMode(Belt* pBelt, BOOL bOn)
{
	if(pBelt)
	{
		if(ovenDb->m_EnergySaving_StandbyMode1_Conveyor_Enabled ==FALSE )
		{
			if(pBelt->mbStandbyMode==TRUE)
			{
				pBelt->mbStandbyMode=FALSE;
				pBelt->setSpeedCounts_x_100=pBelt->nonStandbyCounts_x_100;
				if( pBelt->openLoopSystem )
				{
					pBelt->speedInCMsPerMin = pBelt->nonStandbySpeedInCMsPerMin;
				}
			}
		}
		else
		{
			if(pBelt->mbStandbyMode!=bOn)
			{
				pBelt->mbStandbyMode=bOn;
				if(bOn)
				{
					pBelt->setSpeedCounts_x_100=pBelt->setStandbyCounts_x_100;
					pBelt->speedInCMsPerMin = pBelt->StandbySpeedInCMsPerMin;
					if( pBelt->openLoopSystem )
					{
						pBelt->openLoopCounts=pBelt->mTPOStandbyOLCounts;
					}
				}
				else
				{
					pBelt->setSpeedCounts_x_100=pBelt->nonStandbyCounts_x_100;
					pBelt->speedInCMsPerMin = pBelt->nonStandbySpeedInCMsPerMin;
					if( pBelt->openLoopSystem )
					{
						pBelt->openLoopCounts=pBelt->manualTPOcounts;
					}
				}
				pBelt->m_bDoFastCalculation = TRUE;
				pBelt->m_iNumberofContinousTimesWithinDeadband = 0;
				//allows 30 seconds before dual motor/input testing	
				pBelt->m_iDualMotorFailTime = Timer_getCurrentTime10ths(elapseTimer);
				pBelt->m_iTimesSinceMotorFailed = 0;
				pBelt->m_iNumberOfSlowLoops = 0;
				pBelt->m_iTimesSinceInputDeviated = 0;
				if(!pBelt->openLoopSystem)
				{
					pBelt->setSpeedCountsPerSec = pBelt->setSpeedCounts_x_100/100;
					if( (pBelt->setSpeedCounts_x_100 % 100) >= 50 )//50 rounding factor
					{
						pBelt->setSpeedCountsPerSec++;
					}
				}
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_standbyCountsOpenLoop
	
			sets standby open loop counts			

 RETURNS:   void
------------------------------------------------------------------------*/
void Belt_standbyCountsOpenLoop(Belt* pBelt, DWORD counts)
{
	if(pBelt)
	{
		pBelt->mTPOStandbyOLCounts=counts;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Belt_setDigitalStopSensor
	
			sets digital stop sensor, 0xFFFFFFFF=disabled, 0..31=digital input

 RETURNS:   void
------------------------------------------------------------------------*/
void Belt_setDigitalStopSensor(Belt* pBelt, DWORD sensor)
{
	pBelt->m_digitalStopSensor = sensor;
	Belt_resetDigitalStop(pBelt);
#ifdef DEBUG_DIGITAL_STOP
	printk("Belt_setDigitalStopSensor beltID=%d sensor=%ld\n", pBelt->beltID, sensor);
#endif
}

void Belt_resetDigitalStop(Belt *pBelt)
{
	if (pBelt->m_digitalStopAsserted)
	{
		pBelt->m_digitalStopAsserted = FALSE; // do before calling Belt_setSpeedCounts and Belt_setSpeedInCMsPerMin
		Belt_setSpeedCounts(pBelt, pBelt->m_digitalStopSpeedCounts_x_100);
		Belt_setSpeedInCMsPerMin(pBelt, pBelt->m_digitalStopSpeedInCMsPerMin);
		pBelt->m_digitalStopSpeedCounts_x_100 = 0;
		pBelt->m_digitalStopSpeedInCMsPerMin = 0;
		pBelt->m_digitalStopSelfAckAlarmNo = 0;
	}
}
