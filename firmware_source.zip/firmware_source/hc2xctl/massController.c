/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2013, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "massController.h"
#include "oven.h"
#include "digitio.h"
#include "xpdriverdevice.h"
#include "xpdriverioctl.h"
#include "hc2xio_exports.h"

extern DbContainer g_dbContainer;

ANALOGOUT 		* analogOutDb;
Oven 			* ovenDb;
Timer			*elapseTimer;
int iTestFanPath;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_init
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_init(MassController* pMassController )
{
	int lcv = 0;
	PARAM_CHECK( pMassController, "MassController_init");



	iTestFanPath = 0;

	pMassController->flushTime = 150;
	pMassController->jobNo = 0;
	pMassController->startTime = 0;

	for ( lcv = 0; lcv < MAX_MASS_CONTROLLERS; lcv++ )
	{
		pMassController->enabled[lcv] = FALSE;
		pMassController->TPOBlowerPercentX10[lcv] = 0;
	}
	pMassController->uintOutputIndex[0] = (TPO_AVAILABLE + MAX_ANALOG_OUTPUTS);
	pMassController->uintOutputIndex[1] = (TPO_FREECL1 + MAX_ANALOG_OUTPUTS);
	pMassController->uintOutputIndex[2] = (TPO_FREECL2 + MAX_ANALOG_OUTPUTS);
	pMassController->uintOutputIndex[3] = (TPO_ANALOG_FAN + MAX_ANALOG_OUTPUTS);
	pMassController->uintOutputIndex[4] = (TPO_GLOBAL_BLOWER_CONTROL + MAX_ANALOG_OUTPUTS);
	
	analogOutDb	 = &( g_dbContainer.analogOutDb	);
	ovenDb	 = &( g_dbContainer.ovenDb	);
	elapseTimer	= &( g_dbContainer.elapseTimer	);
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_process
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_process(MassController* pMassController)
{	
	PARAM_CHECK( pMassController, "MassController_process");
	BOOL bFlush = FALSE;
	WORD wrdOutput = 0;
	int i = 0;
	BOOL bCooldownComplete = FALSE;
	UINT ovJob = Oven_getJob(ovenDb);
	if ( ovJob != COOLDOWN )
	{
		if( ovJob != pMassController->jobNo)
		{
			pMassController->jobNo = ovJob;
			pMassController->startTime =  Timer_getCurrentTime10ths(elapseTimer);
			bFlush = TRUE;
		}
		else
		{
			if ( (Timer_getCurrentTime10ths(elapseTimer) - pMassController->startTime) < pMassController->flushTime )
			{
				bFlush = TRUE;
			}
		}
	}
	else
	{
		pMassController->jobNo = COOLDOWN;
	}


	for(i = 0; i < MAX_MASS_CONTROLLERS; i++)
	{
		if ( pMassController->enabled[i] )
		{
			bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
			if((pMassController->jobNo == COOLDOWN) && bCooldownComplete)//Per tushar turn off output when cooldown is below target temp for analogs
			{
				TPO_AddSafeSegment(pMassController->uintOutputIndex[i], 0x01);
				if(!iTestFanPath)
				{
					ANALOGOUT_set(analogOutDb, pMassController->uintOutputIndex[i], 0);
				}
			}
			else if(!bFlush)
			{
				TPO_AddSafeSegment(pMassController->uintOutputIndex[i], 0x01);
				if(!iTestFanPath)
				{
					wrdOutput = (pMassController->TPOBlowerPercentX10[i]*MAX_TPO_COUNTS+5)/1000;
					ANALOGOUT_set(analogOutDb, pMassController->uintOutputIndex[i],wrdOutput);
				}
			}
			else
			{
				TPO_AddSafeSegment(pMassController->uintOutputIndex[i], 0x01);
				if(!iTestFanPath)
				{
					ANALOGOUT_set(analogOutDb, pMassController->uintOutputIndex[i], MAX_TPO_COUNTS);
				}
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setOutputPercent
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL MassController_setOutputPercent(MassController* pMassController, unsigned int ZoneNo, int outputPercent )
{
	PARAM_CHECK_RETURN( pMassController, "MassController_setOutputPercent", 0);
	BOOL status = TRUE;
	if ( outputPercent < MIN_OUT_PERCENTAGE )
	{
		outputPercent = MIN_OUT_PERCENTAGE;
		status = FALSE;
	}

	if ( outputPercent > (MAX_OUT_PERCENTAGE * 10) )
	{
		outputPercent = (MAX_OUT_PERCENTAGE * 10);
		status = FALSE;
	}

	if ( (ZoneNo < MAX_MASS_CONTROLLERS) )
	{
		pMassController->TPOBlowerPercentX10[ZoneNo] = outputPercent;
	}
	else
	{
		status = FALSE;
	}
	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_getOutputPercent
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
unsigned int MassController_getOutputPercent(MassController* pMassController, unsigned int ZoneNo )
{
	BOOL status = TRUE;
	int outputPercent;
	PARAM_CHECK_RETURN( pMassController, "MassController_getOutputPercent", 0);

	if ( ZoneNo-1 < MAX_MASS_CONTROLLERS )
	{
		outputPercent = pMassController->TPOBlowerPercentX10[ZoneNo-1]/10;
	}
	else
	{
		outputPercent = 0;
		status = FALSE;
	}

	return outputPercent;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setEnable
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_setEnable(MassController* pMassController, int blowerID, BOOL enable )
{
	PARAM_CHECK( pMassController, "MassController_setEnable");
	if(blowerID < MAX_MASS_CONTROLLERS)
	{
		pMassController->enabled[blowerID] = enable;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_getIfMassControllerIsEnabled
			
			configuration for the mass controllers, which are hz blowers on the
			secondary board
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL MassController_getIfMassControllerIsEnabled(MassController* pMassController, int blowerID)
{
	PARAM_CHECK_RETURN( pMassController, "MassController_getIfHZBlowerIsEnabled", 0);
	BOOL bEnabled = 0;
	int zeroBasedID = blowerID -1;
	if(zeroBasedID < MAX_MASS_CONTROLLERS)
	{
		bEnabled = pMassController->enabled[zeroBasedID];
	}
	return bEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setFlushTime
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_setFlushTime(MassController* pMassController, DWORD flshTime)
{
	PARAM_CHECK( pMassController, "MassController_setFlushTime");
	pMassController->flushTime = flshTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setLowSetting
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_setLowSetting(MassController* pMassController, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pMassController, "MassController_setLowSetting");
	pMassController->LowSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setMediumSetting
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_setMediumSetting(MassController* pMassController, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pMassController, "MassController_setMediumSetting");
	pMassController->MediumSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_setHighSetting
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_setHighSetting(MassController* pMassController, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pMassController, "MassController_setHighSetting");
	pMassController->HighSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_getLowSetting
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
UINT MassController_getLowSetting(MassController* pMassController, int blowerID)
{
	PARAM_CHECK_RETURN( pMassController, "MassController_getLowSetting", 0);
	return pMassController->LowSetting[blowerID-1];
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_getMediumSetting
			
GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
UINT MassController_getMediumSetting(MassController* pMassController, int blowerID)
{
	PARAM_CHECK_RETURN( pMassController, "MassController_getMediumSetting", 0);
	return pMassController->MediumSetting[blowerID-1];
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_getHighSetting
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
UINT MassController_getHighSetting(MassController* pMassController, int blowerID)
{
	PARAM_CHECK_RETURN( pMassController, "MassController_getHighSetting", 0);
	return pMassController->HighSetting[blowerID-1];
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  MassController_testTPOPath
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void MassController_testTPOPath(int iTest)
{
	iTestFanPath = iTest;
}
