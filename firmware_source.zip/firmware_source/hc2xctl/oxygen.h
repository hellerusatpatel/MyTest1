/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//Oxygen.h
#ifndef __OXYGEN1_H__
#define __OXYGEN1_H__

#include "typedefdefine.h"

typedef struct _Oxygen_
{
//private:
	UINT oxygenInputVoltage;
	BOOL enabled;

} Oxygen;

void Oxygen_init(Oxygen* pOxygen);
long Oxygen_getOxygenVolts(Oxygen* pOxygen);
void Oxygen_setEnabled(Oxygen* pOxygen, BOOL enableState /*= TRUE*/ );
void Oxygen_process(Oxygen* pOxygen);

#endif
