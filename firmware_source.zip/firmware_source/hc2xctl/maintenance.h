/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// Maintenance

#ifndef __MAINTENANCE_H__
#define __MAINTENANCE_H__

#include "typedefdefine.h"

typedef struct _Maintenance_
{
//private:
	BOOL sendAlarm;
	BOOL messageSent;
	DWORD sendTime;
	DWORD currentTime;
	TransferAlarmData alarmData;
} Maintenance;

void Maintenance_init(Maintenance* pMaintenance );
void Maintenance_process(Maintenance* pMaintenance);
void Maintenance_setMaintenanceDue(Maintenance* pMaintenance);

#endif

