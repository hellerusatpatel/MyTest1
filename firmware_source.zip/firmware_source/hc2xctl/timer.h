/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// Timer.h
#ifndef __TIMER_H__
#define __TIMER_H__
#include "typedefdefine.h"

#define		TIMER_20MS_CNTS	2

//******************************************************************************
// class Timer
//
// Abstract:
// The Timer class is for returning a system time in millisecond intervals
// using the VTD_Get_Real_Time function from the VtoolsD software. It will
// return a number of milliseconds that have elapsed since the system is
// powered up.
// 4294967296tics/unsigned long /(24hrs/day*3600secs/hr*1000msecs/sec)
// = 49 days of being able to run continuously. By resetting the rollOverCount
// when a new job is loaded will allow an indefinite run provided the job does
// not last longer than 49 days.
//
// Programmer: Steven Young
// Date: 03/20/1998
//
//******************************************************************************
typedef struct _Timer_
{
//private:
	BOOL		countOn;
	DWORD		tenthsOfSecondsCount;
	DWORD		scanPeriod;  // the scan period from scheduler 
} Timer;

void Timer_setScanPeriod(Timer* pTimer, DWORD scanPeriodFromScheduler );
void  Timer_timerOff(Timer* pTimer);
void  Timer_timerOn(Timer* ptimer);
DWORD Timer_getCurrentTime10ths(Timer* pTimer);
void Timer_init(Timer* pTimer); //  = "Elapsed Timer" );
DWORD Timer_getScanPeriod(Timer* pTimer);
void Timer_add10thSecond(Timer* pTimer);

#endif
