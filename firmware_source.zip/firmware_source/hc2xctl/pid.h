/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __PID_H__
#define __PID_H__

#include "typedefdefine.h"


//******************************************************************************
// Class PID
//
// Abstract:
//	A generic PID algorithm with clamping and windup control.
//
// Programmer: Steven Young
// Date: 3/13/1998
//******************************************************************************

enum Action { Reverse = 0, Direct = 1 };

typedef struct _PID_
{	
//private:
	BOOL m_bAdjustSumOfErrorsToSlowControl;
	LONG*				sp;				
	LONG*				pv;				
	LONG*				tpoOutput;			

	LONG				pb;					
	LONG				ti;					
	LONG				td;					

	enum Action			outputAction;		//  Direct or Reverse	
	
	LONG				pTerm;				
	LONG				iTerm;				
	LONG				dTerm;				
	LONG				maxIterm;

	USHORT			dt;					

	LONG 				sumErrors;			
	
	LONG				error;				
	LONG				lastError;			
	LONG				lastSetPoint;
	
	BOOL				PIDMode;
} PID;

void PID_init(PID* pid, LONG* setPoint, LONG* procVariable,
				LONG* lTPOoutput, enum Action directReverse		);

void PID_calcPID  (PID* pid);
void PID_calcBeltPID(PID* pid, UINT enterDT );
void PID_reset      (PID* pid);
void PID_setMaxPb	(PID* pid, DWORD maxProportionalBand );
void PID_setPb		(PID* pid, DWORD propotionalBand);
void PID_setTi		(PID* pid, DWORD dwTi);
void PID_setTd		(PID* pid, DWORD uTd);

DWORD  PID_getPb	(PID* pid);
DWORD  PID_getTi	(PID* pid);
DWORD  PID_getTd	(PID* pid);
LONG   PID_getPterm (PID* pid);
LONG   PID_getIterm (PID* pid);
LONG   PID_getDterm	(PID* pid);
void   PID_setPIDMode(PID* pid, BOOL pidModeEnabled );
BOOL 	 PID_getMode(PID* pPID);
void   PID_setAction(PID* pid, enum Action pidResponseAction );
enum Action PID_getAction(PID* pid);
void   PID_recalcGainConstants(PID* pid);	// whenever pb/ti/td change the constants must be recalced
void PID_reduceSumOfErrorsByFactor10(PID* pid);

#endif

