//*****************************************************************************
// Copyright (c) 1999-2014 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2014 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: oven.h
//
// Description: oven logic processing
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Declare m_bCurrentDelayedCooldown
// 03-Dec-14  FJN  Rename m_bCurrentDelayedCooldown to m_bCurrentMonitorDelayedCooldown
// 03-Dec-14  FJN  Declare m_bHeaterFailureDelayedCooldown
// 21-Feb-17  TP   Declare m_bBeltStopWhenRailMoving, Oven_setBeltStopWhenRailMoving() ver8.0.0.18
//*****************************************************************************
#ifndef __OVEN_H__
#define __OVEN_H__

#include "typedefdefine.h"
#include "hellerenumerations.h"

/**************************************************************************
 *
 *	DEFINITIONS
 *
 **************************************************************************/
#define SMEMACONFIG_LOWER_NIBBLE_MASK	0x000f
#define SMEMACONFIG_UPPER_NIBBLE_MASK	0x01f0
#define SMEMA3_LOWER_BIT				0x0200
#define SMEMA3_UPPER_BIT				0x0400

#define SMEMA_NOSMEMA_BELT1_BIT	0
#define SMEMA_NOSMEMA_BELT2_BIT	16
#define SMEMA_SMEMAII_BELT1_BIT	1
#define SMEMA_SMEMAII_BELT2_BIT	32
#define SMEMA_TDK_BELT1_BIT	2
#define SMEMA_TDK_BELT2_BIT	64
#define SMEMA_FUJI_BELT1_BIT	4
#define SMEMA_FUJI_BELT2_BIT	128
#define SMEMA_SEAGATE_BELT1_BIT	8
#define SMEMA_SEAGATE_BELT2_BIT	256
#define SMEMA_9851_BELT1_BIT	16
#define SMEMA_9851_BELT2_BIT	512

#define OVEN_ONE_MINUTE			600

extern unsigned char g_ucSetSecsgemOption;
extern unsigned char g_ucSecsgemOptionSetTo;

// Board Drop Config Options
//		LANE1	LANE2	
// 0.	NONE	NONE	4.	TIMED	NONE	8.	BEAM	NONE	12.	BOTH	NONE
// 1.   NONE	TIMED	5.	TIMED	TIMED	9.	BEAM	TIMED	13. BOTH	TIMED
// 2.	NONE	BEAM	6.	TIMED	BEAM	10.	BEAM	BEAM	14.	BOTH	BEAM	
// 3.	NONE	BOTH	7.	TIMED	BOTH	11.	BEAM	BOTH	15.	BOTH	BOTH
// 
// Boards Processed Options
//		LANE1	LANE2
// 0.     0		  0
// 1.	  1       0
// 2.	  0       1
// 3.     1       1
//
// Boards In Oven Options:
//		LANE1	LANE2
// 0.	  0		  0
// 1.	  1		  0
// 2.	  0	      1
// 3.     1       1		
// 
// SMEMA Interface Types			// OR THESE TOGETHER FOR THE TYPE
//		LANE 1		LANE 2
// 0.	NONE		16.  NONE
// 1.	SMEMAII		32.  SMEMAII
// 2.	TDK			64.	 TDK
// 4.	FUJI		128. FUJI
// 8.	SEAGATE		256. SEAGATE
// 
// Animation
//		LANE 1		LANE 2
// 0.	0			0
// 1.   1			0
// 2.	0			1
// 3.	1			1

enum { COOLDOWN = 0 };		// cooldown is always job 0.
enum { NONE=0, BEAM=1, TIMED=2, TIMEDBEAM=3};

typedef struct _Oven_
{
//private:
	char recipeName[MAX_RECIPE_NAME_LENGTH];
	BOOL					mbDoReset;
	DWORD					standbyMode1Time;
	DWORD					mEnergyCooldownTimer;
	DWORD					scanPeriod;
	DWORD					scanCounts;
	DWORD					tempJobNo;		        // the new job before jobloadcomplete is set.
	DWORD					jobNo;			        // default to 0 cooldown
	DWORD					noBelts;   		        // 1 or 2 - default 1
	DWORD					noHeatZones;	        // depending on the model the zones can range from 4 to 24
	DWORD					noRails;  		        // 0 to 3 rails may be used. Per IO table if 3 rails only 2 belts.
	DWORD					cdAmbientTemp;          // in degrees c - must be > than MinTemp and < MaxTemp
	DWORD					startPowFailTime;
	DWORD					startPowCooldownFailTime;
    DWORD					currentPowFailTime;
    DWORD					currentPowFailCooldownTime;
	DWORD					startLowExhaustTime;
	DWORD					startBlowerFailTime;
	DWORD					startOverTempTime;
	DWORD					startHighWaterTempTime;
	DWORD					boardDropConfig;		    // see above		
	DWORD					boardsProcessedConfig;	    // see above 
	DWORD					boardsInOvenConfig;			// see above
	DWORD					smemaConfig;				// see above
	DWORD					animationConfig;			// see above
	DWORD					modelNo;					// 1088=0,1500,1700,1800,1800z,1900,788
	DWORD					FiveSecondStartTime;        // the start time for the job loading output
	DWORD					FiveSecondCurrentTime;      // the current time for the job loading output
	DWORD					FiveSecondPreviousTime;     // the current time for the job loading output
	DWORD					m_dwrdCooldownStartTime;

	UINT					bdrop;						// board drop detection method.
	BOOL					jobStartupComplete;  		// default to TRUE to turn off contactor
	BOOL					jobLoadInProgress;			// the user interface is loading a new job, when done it sets this to false.
	BOOL					digitalCoolingFan;			// on or off only.
	BOOL					calibration;
	BOOL					autoLube;
	BOOL					coolDown;                   // coolDown enabled!!
	BOOL					eStopSet;
	BOOL					lowExhaustWarningSent;
	BOOL					COOLDOWNachievedFlag;
	BOOL					wantResume;
	BOOL					startUpWithJob;
	BOOL					leftToRight;
	BOOL					redundantOverTempOptionEnabled;
	BOOL					lto;
	BOOL					demoMode;
	BOOL					blowerFailureCheckEnabled;
	BOOL					autoCleanFluxMode;
    BOOL                    lane3Enabled;
    BOOL                    lane4Enabled;
	BOOL					FiveSecondTimerIsRunning;
	BOOL					m_bCooldownCountOn;

	//WDT 1.31.1 added to allow dynamic timing for low exhaust warnings and alarms
	int						m_iLowExhWarning;
	int						m_iLowExhAlarm;
	DWORD					m_dwrdDelayedCooldownTime;
#if 0
	//WDT 3.20.01 added to disable high h2o alarm for board type a
	BOOL					m_bTypeA;
#else
	BOOL					m_bWaterTempHighEnable;
	DWORD					m_dwrdWaterTempHighAlarmTime;
	DWORD					m_dwrdWaterTempHighWarningTime;
#endif
	//WDT 4.27.01 added to indicate if the power failure information message has already been sent
	BOOL					m_bFailureNotified;

	//WDT 07.30.01
	BOOL					m_bIsPowerOKForWarningTime;
	
	BOOL					m_bExhaustWarningsEnabled;
	BOOL					m_bExhaustAlarmsEnabled;

	BOOL					m_bSelfAcknowledgeDisabled;
	BOOL					m_bDisableDevAlarmInStartup;
	DWORD					m_StartupCompletePlusDelayTime;
	UINT					m_iPowerfailureTime;

	BOOL					m_bFiveSecondDisabled;
	BOOL					m_bDelayedCooldown;
	BOOL					m_bCurrentMonitorDelayedCooldown;
	BOOL					m_bHeaterFailureDelayedCooldown;
	BOOL					m_bRequestCooldown;
	BOOL					m_bStarted;
	DWORD					m_dwrCurrentGroup;
	DWORD					m_dwrdLoadTime;
	BOOL					m_bPendingCooldown;
	BOOL					m_bFanFaultAlarm;
	BOOL					m_bAudibleBlowFail;
	BOOL					m_bBFWarn;
	int					m_iBFATime;
	int					m_iBFWTime;
	UINT					m_uAllowBarcodeAgain;	
	BOOL					mbEnergyStandy;
	BOOL					mbEnergyCooldown;
	DWORD					mDenergyCoolTime;
	DWORD					mDenergyTime;
	DWORD					mStartEnergyCountdown;
	DWORD					mDwrdEnergyInput;
	BOOL					mbEnergyRecipe;
	BOOL					mbEnergyNoteSent;
	BOOL					mbEnergyInputHasLowed;
	DWORD					mbOvenActive;

	BOOL	m_EnergySaving_IntelExhaust_Enabled;
	UINT	m_EnergySaving_IntelExhaust_Speed;

	BOOL	m_EnergySaving_StandbyMode1_Enabled;
	UINT	m_EnergySaving_StandbyMode1_ExhaustSpeed;
	UINT	m_EnergySaving_StandbyMode1_ZoneSpeed;
	BOOL	m_EnergySaving_StandbyMode1_Conveyor_Enabled;
	UINT	m_EnergySaving_StandbyMode1_ConveyorSpeed;
	BOOL	m_EnergySaving_StandbyMode1_N2Off;
	BOOL	m_EnergySaving_StandbyMode1_N2Low;
	UINT	m_EnergySaving_MaxBlower;
	UINT	m_EnergySaving_MinBlower;
	UINT	m_Standby_MaxBlower;
	UINT	m_Standby_MinBlower;
	enum eSTANDBY_MODE1	m_EnergySaving_eStandbyMode1;
	BOOL	m_EnergySaving_eStandbyMode2_LoadRecipe;
	DWORD	m_dwrdStartUpElapse;
	BOOL mbAlarmScanner;
	int miAlarmOutput;
	BOOL mbAlarmState;
	int skipClear;
	BOOL m_bBeltStopWhenRailMoving;	//ver8.0.0.18
	UINT loadTime;	//ver8.0.0.24
	UINT boardEntryWait;	//ver8.0.0.24
} Oven;

void	Oven_EnergyProcessing(Oven* pOven);
void	Oven_EnergyClearTime(Oven* pOven);
void	Oven_checkE_Stop(Oven* pOven);
void	Oven_checkForPowerFail(Oven* pOven);
void	Oven_checkForLowExhaust(Oven* pOven);
void	Oven_checkJobLoad(Oven* pOven);
void	Oven_checkForHighWaterTemp(Oven* pOven);
void	Oven_checkForOverTemp(Oven* pOven);
void	Oven_checkBlowerFailure(Oven* pOven);
void	Oven_SetJobNewJobLoadedOutput(Oven* pOven);
void Oven_SetSys(Oven* pOven, int iStarted);
void Oven_init(Oven* pOven);
void OVEN_ClearCN(Oven* pOven);
BOOL Oven_returnOvenProgrammed(Oven * pOven);

//added to test if the oven is in powerfailure prior to new recipe load
BOOL Oven_ExternalCheckForPowerFailure(Oven* pOven);	
BOOL Oven_isEStopSet(Oven* pOven);
BOOL Oven_setBelts(Oven* pOven, DWORD nBelts );
UINT Oven_getNoBelts(Oven* pOven);

BOOL Oven_setBoardDropConfig(Oven* pOven, DWORD bdConfigSetting );
BOOL Oven_setBoardsProcessedConfig(Oven* pOven, DWORD bpConfigSetting );
BOOL Oven_setBoardsInOvenConfig(Oven* pOven, DWORD boConfigSetting );
BOOL Oven_setSMEMAConfig(Oven* pOven, DWORD smemaConfigOption );
BOOL Oven_setBoardAnimationConfig(Oven* pOven, DWORD boardAnimationConfigOption );
BOOL Oven_setBoardProcessConfigOptions(Oven* pOven);
void Oven_SetDemoMode(Oven* pOven, BOOL demoModeState);
BOOL Oven_getDemoMode(Oven* pOven);

UINT Oven_getJob(Oven* pOven);
void Oven_setJob(Oven* pOven, UINT nJobNo );
void Oven_setSecondaryJob(Oven* pOven, UINT nJobNo );

BOOL Oven_isJobStartupComplete(Oven* pOven);
void Oven_setJobStartupComplete(Oven* pOven, BOOL jobStartupState /*= TRUE*/ );
void Oven_pause(Oven* pOven);		
void Oven_resume(Oven* pOven);		
BOOL Oven_isJobLoadInProgress(Oven* pOven);
void Oven_setCOOLDOWNachieved (Oven* pOven, BOOL atCoolDown );
BOOL Oven_isCOOLDOWNcomplete(Oven* pOven);
void Oven_setScanPeriod(Oven* pOven, DWORD scanTime );
DWORD Oven_getScanTime(Oven* pOven);
void Oven_setStartWithJob(Oven* pOven, BOOL jobState /*= FALSE*/ );
BOOL Oven_setRecipeName(Oven* pOven, char *recipe_name );
BOOL Oven_setModelNo(Oven* pOven, DWORD model_no );
DWORD Oven_getModelNo(Oven* pOven);
void Oven_setDirection(Oven* pOven, BOOL standardDirection );
BOOL Oven_getDirection(Oven* pOven);
char* Oven_getRecipeName(Oven* pOven);
void Oven_setRedundantOverTempOption(Oven* pOven, BOOL option /*= TRUE*/ );
void Oven_setLTOption(Oven* pOven, BOOL option /*= TRUE*/ );
BOOL Oven_getLTOption(Oven* pOven);
void Oven_setBlowerFailureOption(Oven* pOven, BOOL option /*= TRUE*/);
BOOL Oven_getBlowerFailureOption(Oven* pOven);
void Oven_setAutoCleanFlux(Oven* pOven, BOOL autoCleanMode /*= TRUE*/);
BOOL Oven_getAutoCleanFlux(Oven* pOven);
void Oven_setThirdLaneEnabled(Oven* pOven, BOOL laneEnabled );
void Oven_setFourthLaneEnabled(Oven* pOven, BOOL laneEnabled );
void Oven_process(Oven* pOven);

//The following two member functions use to take a float, 
//and apply the following calculation:
//
//		x = ((int)(float_num*10));
//
//This calculation will need to be done at the application level
//for now on.
void Oven_setLowExhaustWarningTime(Oven* pOven, int LEwarn);
void Oven_setLowExhaustAlarmTime(Oven* pOven, int LEalarm);
//End of note////
#if 0
void Oven_setAsBoardTypeA(Oven* pOven, BOOL bType);
BOOL Oven_getIsBoardTypeA(Oven* pOven);
#else
void Oven_waterTempHighEnable(Oven *pOven, BOOL bEnable);
void Oven_waterTempHighAlarmTime(Oven *pOven, DWORD dwrdAlarmTime);
void Oven_waterTempHighWarningTime(Oven *pOven, DWORD dwrdWarningTime);
#endif
void Oven_setExhaustWarningEnable(Oven* pOven, BOOL bDisabled);
void Oven_setExhaustAlarmEnable(Oven* pOven, BOOL bDisabled);
void Oven_disableAutoAcknowledge(Oven* pOven, BOOL bEntered);
void Oven_disableDevAlarmInStartup(Oven* pOven, BOOL bDisabled);
BOOL Oven_getIsAutoAcknowledgedDisabled(Oven* pOven);
BOOL Oven_getIsDevAlarmInStartupDisabled(Oven* pOven);
void Oven_setStartupCompletePlusDelay(Oven* pOven, int iTimeInSec);
DWORD Oven_getStartupCompletePlusDelayTime(Oven* pOven);
void Oven_setPowerFailureTime(Oven* pOven, UINT fTime);
void Oven_setFiveSecondDisable(Oven* pOven, BOOL bDisabled);
BOOL Oven_getFiveSecondDisable(Oven* pOven);
DWORD Oven_getTempJobNo(Oven* pOven);
void Oven_initiateCooldownCountdown(Oven* pOven, BOOL bInit);
void Oven_setDelayedCooldown(Oven* pOven, BOOL cooldownDelayed);
BOOL Oven_getDelayedCooldown(Oven* pOven);
void Oven_setCurrentMonitorDelayedCooldown(Oven* pOven, BOOL currentMonitorCooldownDelayed);
BOOL Oven_getCurrentMonitorDelayedCooldown(Oven* pOven);
void Oven_setHeaterFailureDelayedCooldown(Oven* pOven, BOOL heaterFailureCooldownDelayed);
BOOL Oven_getHeaterFailureDelayedCooldown(Oven* pOven);
void Oven_setDelayedCooldownTime(Oven* pOven, int iTime);
BOOL Oven_getAppCoolFlag(Oven* pOven);
void Oven_setAppFlag(Oven* pOven, BOOL bWeNeedCooldown);
BOOL Oven_cooldownModePending(Oven* pOven);
void Oven_setBoardStopOption(BOOL bEnabled, int iMainLane);
void Oven_setStartupGroup(Oven* pOven, DWORD dwrdGroup);
DWORD Oven_getStartupGroup(Oven* pOven);
BOOL Oven_LaunchCooldown(Oven* pOven);
void Oven_requestCooldown(Oven* pOven);
void Oven_alarmOnFF(Oven* pOven, BOOL bOn);
void Oven_BFAudible(Oven* pOven, BOOL bAud);
void Oven_setBFATime(Oven* pOven, int iTime);
void Oven_setBFWTime(Oven* pOven, int iTime);
void Oven_BFWarn(Oven* pOven, BOOL bOn);
void Oven_setTerminal(Oven* pOven, DWORD on);
DWORD Oven_getTerminal(Oven* pOven);
BOOL Oven_inIE(Oven* pOven);
BOOL Oven_sm1(Oven* pOven);
BOOL Oven_sm2(Oven* pOven);
BOOL Oven_esCooldown(Oven* pOven);

int  Oven_GetBoardCount(Oven* pOven);
void Oven_SlaveConfiguration();

void Oven_SetStandbyModeExhaustSpeed(UINT speed);
void Oven_SetStandbyModeZoneSpeed(UINT speed);
void Oven_SetStandbyModeIESpeed(UINT speed);
void OVEN_allowPowerLossWarning();
void Oven_set_globals();
void Oven_setBeltStopWhenRailMoving(Oven* pOven, BOOL bEnabled);	//ver8.0.0.18
BOOL Oven_getBeltStopWhenRailMoving(Oven* pOven);	//ver8.0.0.18

void Oven_recipeLoadBoardEntryWait(Oven* pOven, DWORD seconds);	//ver8.0.0.24
BOOL Oven_checkRecipeLoadBoardEntryWait(Oven* pOven);	//ver8.0.0.24
#endif

