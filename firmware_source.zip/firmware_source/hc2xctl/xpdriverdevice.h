//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: xpdriverdevice.h
//
// Description: source code for interface object
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Declare OVEN_currentDelayCooldown_Handler
// 14-Nov-14  FJN  Declare OVEN_currentMonitorFailure_Handler
// 03-Dec-14  FJN  Rename OVEN_currentDelayCooldown_Handler to OVEN_currentMonitorDelayCooldown_Handler
// 03-Dec-14  FJN  Declare OVEN_heaterFailureDelayCooldown_Handler and OVEN_heaterFailure_Handler
// 05-Jan-15  FJN  Declare OVEN_currentMonitorTempZoneFailure_Handler and OVEN_currentMonitorFluxZoneFailure_Handler
// 05-Jan-15  FJN  Declare OVEN_heaterTempZoneFailure_Handler and OVEN_heaterFluxZoneFailure_Handler
// 05-Jan-15  FJN  Declare IOCTL_GATHER_TDM_EEPROM_Handler, IOCTL_SET_TDM_EEPROM_Handler and IOCTL_PROGRAM_TDM_HANDLER
// 13-Mar-15  FJN  Declare OVEN_currentMonitorTempZoneFailureHigh_Handler and OVEN_currentMonitorFluxZoneFailureHigh_Handler
// 24-Jun-16  FJN  Declare SMEMA_setLaneHold
//*****************************************************************************
#ifndef __XpDriverDevice_h__
#define __XpDriverDevice_h__

#include "contain.h"
#include "schedule.h"
#include "typedefdefine.h"	// Added by ClassView
#include "LotProcessingCmds.h"

//10 ms timeout for backup schedule production, note that the dpc will not be this granular on some systems
#define EMERGENCY_TIME -100000
//1 second timeout value in 100 NANO second units (1 second = 1,000,000,000 nanoSeconds
#define COMM_TIMEOUT -10000000

#define IRP_MJ_SHUTDOWN		0x10

#define NUM_HISTORICAL_IO 400
/////////////////////////////////////////////////////////////
//
// KIrp
//
/////////////////////////////////////////////////////////////

typedef struct _KIrp_
{
	unsigned int m_ioctlCode;

	int m_inputBufferSize;
	int m_outputBufferSize;
	unsigned int m_information;

	char m_ioctlBuffer[KIRP_IOCTL_BUFFER_SIZE];
} KIrp;

/////////////////////////////////////////////////////////////
//
// XpDriverDevice
//
/////////////////////////////////////////////////////////////

typedef struct _XpDriverDevice_
{
	BOOL	m_bTimerFailWarningSent;
	BOOL	m_bMonitorMode;
	DWORD	m_alarm_id;
	ULONG	m_Unit;
	BOOL	m_bOvenIsPaused;
	BOOL	m_bOvenStarted;

	DbContainer	m_Container;
	Scheduler	m_Scheduler;
	int			m_bOvenControlled;
} XpDriverDevice;

void XpDriverDevice_init(XpDriverDevice* pXpDriverDevice, ULONG Unit);

NTSTATUS ALARMQUEUE_getStatusEvents_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_setCooldownPreference_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_setAudibleBeltWarningsEnabled_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_setAudibleLowExhaustEnabled_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_setAudibleDansensorWarningEnabled_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_getAlarmCount_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_alarmQueueAcknowledge_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_clearReadFlagAll_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_alarmsPresent_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_warningsPresent_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_resetAudibleSounding_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_returnInAudibleCondition_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_getAlarmMessage_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_resetAlarms_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_addAlarm_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_audibleWarnings_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_enableAudibleBoardWarnings_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_audibleBCWarnings_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_vipMode_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_ackType_Handler(KIrp* I);
NTSTATUS ALARMQUEUE_warningOutput_Handler(KIrp* I);

NTSTATUS ANALOGFAN_setOutputPercent_Handler(KIrp* I);
NTSTATUS ANALOGFAN_getOutputPercent_Handler(KIrp* I);
NTSTATUS ANALOGFAN_setEnableState_Handler(KIrp* I);
NTSTATUS ANALOGFAN_0_100_Handler(KIrp* I);
NTSTATUS ANALOGFAN_LOW_Handler(KIrp* I);
NTSTATUS ANALOGFAN_MED_Handler(KIrp* I);
NTSTATUS ANALOGFAN_HIGH_Handler(KIrp* I);
NTSTATUS ANALOGFAN_MINIMUM_Handler(KIrp* I);

NTSTATUS ANALOGIN_getValue_Handler(KIrp* I);
NTSTATUS ANALOGIN_readProfileOffset_Handler(KIrp* I);
NTSTATUS ANALOGIN_GetAnalogInVal_Handler(KIrp* I);
NTSTATUS ANALOGIN_GetStoredOffset_Handler(KIrp* I);
NTSTATUS ANALOGIN_SetOffsetValue_Handler(KIrp* I);			
NTSTATUS ANALOGIN_GetInputStyle_Handler(KIrp* I);
NTSTATUS ANALOGIN_SetInputStyle_Handler(KIrp* I);	

NTSTATUS ANALOGOUT_getValue_Handler(KIrp* I);
NTSTATUS ANALOGOUT_setValue_Handler(KIrp* I);

NTSTATUS BCIO_setInput_Handler(KIrp* I);
NTSTATUS BCIO_setOutput_Handler(KIrp* I);
NTSTATUS BCIO_setOutputR_Handler(KIrp* I);
NTSTATUS BCIO_setOutputY_Handler(KIrp* I);
NTSTATUS BCIO_setOutputG_Handler(KIrp* I);
NTSTATUS BCIO_boardScanned_Handler(KIrp* I);
NTSTATUS BCIO_setModeR_Handler(KIrp* I);
NTSTATUS BCIO_setModeY_Handler(KIrp* I);
NTSTATUS BCIO_setModeG_Handler(KIrp* I);
NTSTATUS BCIO_setTime_Handler(KIrp* I);
NTSTATUS BCIO_setEnable_Handler(KIrp* I);
NTSTATUS BCIO_setECEnable_Handler(KIrp* I);

NTSTATUS BELTS_doFastPidControl_Handler(KIrp* I);
NTSTATUS BELTS_enableHiDevAlarm_Handler(KIrp* I);
NTSTATUS BELTS_enableHiDevWarn_Handler(KIrp* I);
NTSTATUS BELTS_enableHiProcAlarm_Handler(KIrp* I);
NTSTATUS BELTS_enableLoDevAlarm_Handler(KIrp* I);
NTSTATUS BELTS_enableLoProcAlarm_Handler(KIrp* I);
NTSTATUS BELTS_enterSlowPidValue_Handler(KIrp* I);
NTSTATUS BELTS_get4BElapsedPositionCountTics_Handler(KIrp* I);
NTSTATUS BELTS_getAutoMode_Handler(KIrp* I);
NTSTATUS BELTS_getBeltActive_Handler(KIrp* I);
NTSTATUS BELTS_getCountMethod_Handler(KIrp* I);
NTSTATUS BELTS_getCurrentState_Handler(KIrp* I);
NTSTATUS BELTS_getHiPercentLimit_Handler(KIrp* I);
NTSTATUS BELTS_getHiSpeedRange_Handler(KIrp* I);
NTSTATUS BELTS_getInputRangeHighValue_Handler(KIrp* I);
NTSTATUS BELTS_getInputRangeLowValue_Handler(KIrp* I);
NTSTATUS BELTS_getLoPercentLimit_Handler(KIrp* I);
NTSTATUS BELTS_getLowSpeedLimit_Handler(KIrp* I);
NTSTATUS BELTS_getMaxFreq_Handler(KIrp* I);
NTSTATUS BELTS_getPulsesPerCmCount_Handler(KIrp* I);
NTSTATUS BELTS_getSetPoint_Handler(KIrp* I);
NTSTATUS BELTS_getSpeedCounts_Handler(KIrp* I);
NTSTATUS BELTS_getSpeedInCMsPerMin_Handler(KIrp* I);
NTSTATUS BELTS_getSummOfSpeeds_Handler(KIrp* I);
NTSTATUS BELTS_IsBeltInWarning_Handler(KIrp* I);
NTSTATUS BELTS_IsOpenLoop_Handler(KIrp* I);
NTSTATUS BELTS_setAutoMode_Handler(KIrp* I);
NTSTATUS BELTS_setBeltActive_Handler(KIrp* I);
NTSTATUS BELTS_setElapsedPositionCounts_Handler(KIrp* I);
NTSTATUS BELTS_setHiDeadBandOffsetCounts_Handler(KIrp* I);
NTSTATUS BELTS_setHiDeviationCounts_Handler(KIrp* I);
NTSTATUS BELTS_setHiPercentLimit_Handler(KIrp* I);
NTSTATUS BELTS_setHiProcessCounts_Handler(KIrp* I);
NTSTATUS BELTS_setHiSpeedLimit_Handler(KIrp* I);
NTSTATUS BELTS_setHiWarningCounts_Handler(KIrp* I);
NTSTATUS BELTS_setInputRangeHighValue_Handler(KIrp* I);
NTSTATUS BELTS_setLoDeadBandOffsetCounts_Handler(KIrp* I);
NTSTATUS BELTS_setLoDeviationCounts_Handler(KIrp* I);
NTSTATUS BELTS_setLoPercentLimit_Handler(KIrp* I);
NTSTATUS BELTS_setLoProcessCounts_Handler(KIrp* I);
NTSTATUS BELTS_setLoWarningCounts_Handler(KIrp* I);
NTSTATUS BELTS_setLowSpeedLimit_Handler(KIrp* I);
NTSTATUS BELTS_setManualTPOcounts_Handler(KIrp* I);
NTSTATUS BELTS_setMaxFreq_Handler(KIrp* I);
NTSTATUS BELTS_setOpenLoop_Handler(KIrp* I);
NTSTATUS BELTS_setPb_Handler(KIrp* I);
NTSTATUS BELTS_setPulsesPerCmCount_Handler(KIrp* I);
NTSTATUS BELTS_setSpeedInCMsPerMin_Handler(KIrp* I);
NTSTATUS BELTS_setSpeedCounts_Handler(KIrp* I);
NTSTATUS BELTS_setTd_Handler(KIrp* I);
NTSTATUS BELTS_setTi_Handler(KIrp* I);
NTSTATUS BELTS_enableLoDevWarn_Handler(KIrp* I);
NTSTATUS BELTS_getTPOoutputCounts_Handler(KIrp* I);
NTSTATUS BELTS_enableSequencing_Handler(KIrp* I);
NTSTATUS BELTS_setSequenceGroup_Handler(KIrp* I);
NTSTATUS BELTS_activateAllBelts_Handler(KIrp* I);
NTSTATUS BELTS_deactivateAllBelts_Handler(KIrp* I); 
NTSTATUS BELTS_setWarningTimeVariable_Handler(KIrp* I);
NTSTATUS BELTS_setDeadbandDeviationTime_Handler(KIrp* I);
NTSTATUS BELTS_getConfigParam_Handler(KIrp* I);
NTSTATUS BELTS_setMotors_Handler(KIrp* I);
NTSTATUS BELTS_setDigOutput_Handler(KIrp* I);
NTSTATUS BELTS_setOutputBehavior_Handler(KIrp* I);
NTSTATUS BELTS_setMultipleVariables_Handler(KIrp* I);
NTSTATUS BELTS_InputDeviationCounts_Handler(KIrp* I);	
NTSTATUS BELTS_DiffMTime_Handler(KIrp* I);
NTSTATUS BELTS_autoRange_Handler(KIrp* I);
NTSTATUS BELTS_autoRangeOutput_Handler(KIrp* I);
NTSTATUS BELTS_autoRangeSwitch_Handler(KIrp* I);
NTSTATUS BELTS_SmemaOffRange_Handler(KIrp* I);
NTSTATUS BELTS_setOpenLoopStandbyCounts_Handler(KIrp* I);
NTSTATUS BELTS_setDigitalStopSensor_Handler(KIrp* I);
NTSTATUS BLACKBOX_GatherData_Handler(KIrp* I);

NTSTATUS BoardEventCommand_Handler(KIrp* I);
NTSTATUS LotProc_SMEMAReq(LotProcHdr* pHdr, KIrp* I);
NTSTATUS LotProcessCommand_Handler(KIrp* I);
NTSTATUS BoardEvent_EventRequest(BoardEventHdr* pHdr, KIrp* I);
NTSTATUS BoardEvent_EventClear(BoardEventHdr* pHdr, KIrp* I);

/* LotProc_SMEMAReq Helper Functions */
void LotProc_SMEMA1_getStatus( LotProcSmema* pResp );
void LotProc_SMEMA2_getStatus( LotProcSmema* pResp );
void LotProc_SMEMA3_getStatus( LotProcSmema* pResp );
void LotProc_SMEMA4_getStatus( LotProcSmema* pResp );

NTSTATUS BOARDQUEUE_getNotifyBoard_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setNotifyBoard_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getNotifyBoardOut_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setNotifyBoardOut_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setBoardDeadBandDistance_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setSensorDistance_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardsInOvenCount_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardsProcessed_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_clearBoardsInOven_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS BOARDQUEUE_clearBoardsProcessed_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardAnimationData_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardData_Handler_NoLP(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardData_Handler_LP(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardData_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setExitBoardDeadbandCounts_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setBoardDropTolerance_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setBoardDropTimeTolerance_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setBoardDropToleranceNeg_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_enableSprayOption_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setSprayDist_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setSprayDistTime_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setSprayOutput_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_SetFCDelayDist_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_getBoardsInOvenFluxcon_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setHeatMidPoint_Handler(KIrp * I);
NTSTATUS BOARDQUEUE_ignoreBoardLength_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_enablePredefinedBoardLength_Handler(KIrp * I);
NTSTATUS BOARDQUEUE_predefinedBoardLength_Handler(KIrp * I);
NTSTATUS BOARDQUEUE_entranceJamWarning_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setTime_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_clearCarrierVariables_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_setWarningDout_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_panalIdEnable_Handler(KIrp* I);
NTSTATUS BOARDQUEUE_lotProcessingEnable_Handler(KIrp* I);

NTSTATUS BLOWER_GlobalLowStandbyLimit_Handler(KIrp* I);
NTSTATUS BLOWER_GlobalHighStandbyLimit_Handler(KIrp* I);
NTSTATUS BLOWER_GlobalHighLimit_Handler(KIrp* I);
NTSTATUS BLOWER_GlobalLowLimit_Handler(KIrp* I);

NTSTATUS COOLPIPE_enable_Handler(KIrp* I);
NTSTATUS COOLPIPE_analogInputTC1_Handler(KIrp* I);
NTSTATUS COOLPIPE_analogInputTC2_Handler(KIrp* I);
NTSTATUS COOLPIPE_tempTC1_Handler(KIrp* I);
NTSTATUS COOLPIPE_tempDelta_Handler(KIrp* I);
NTSTATUS COOLPIPE_delay_Handler(KIrp* I);

NTSTATUS CBS_setFeedbackTypeFlag_Handler(KIrp* I);
NTSTATUS CBS_getState_Handler(KIrp* I);
NTSTATUS CBS_getSecondState_Handler(KIrp* I);
NTSTATUS CBS_setState_Handler(KIrp* I);
NTSTATUS CBS_enable_Handler(KIrp* I);
NTSTATUS DS_enable_Handler(KIrp* I);
NTSTATUS DS_Input_Handler(KIrp* I);
NTSTATUS DS_Output_Handler(KIrp* I);

NTSTATUS DIGITALIN_getValue_Handler(KIrp* I);
NTSTATUS DIGITALIN_getHistBufferIndex_Handler(KIrp* I);
NTSTATUS DIGITALIN_getHistBuffer_Handler(KIrp* I);

NTSTATUS DIGITALOUT_getValue_Handler(KIrp* I);
NTSTATUS DIGITALOUT_setValue_Handler(KIrp* I);

NTSTATUS ENERGYSAVING_IntelExhaust_Speed_Handler(KIrp* I);
NTSTATUS ENERGYSAVING_StandbyMode1_ExhaustSpeed_Handler(KIrp* I);
NTSTATUS ENERGYSAVING_StandbyMode1_ZoneSpeed_Handler(KIrp* I);
NTSTATUS ENERGYSAVING_StandbyMode1_ConveyorSpeed_Handler(KIrp* I);

NTSTATUS FLUXCONDENSOR_setElapsedTime10ths_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_recipeStarted_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_getElapsedTime10ths_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_enableOption_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_recipeOption_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setIntervalTime_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setDurationTime_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setT3Timer_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setToggle_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setDelayTimer_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setCycleEndNitro_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_setJobAtEnd_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_recipePreStart_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_gen9Option_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_genPhase1Time_Handler(KIrp* I);
NTSTATUS FLUXCONDENSOR_genPhase2Time_Handler(KIrp* I);

NTSTATUS FLUXFILTER_fluxFilterEnable_Handler(KIrp* I);
NTSTATUS FLUXFILTER_setFluxFilterCleaningInterval10ths_Handler(KIrp* I);
NTSTATUS FLUXFILTER_getElapsedTime10ths_Handler(KIrp* I);
NTSTATUS FLUXFILTER_setElapsedTime10ths_Handler(KIrp* I);
NTSTATUS FLUXFILTER_setDOAvailibility_Handler(KIrp* I);

NTSTATUS FLUXHEATER_getTPOoutput_Handler(KIrp* I);
NTSTATUS FLUXHEATER_getSetPoint_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setActive_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setSetPoint_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetPb_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetTi_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetTd_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setSequenceGroup_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setZoneAuto_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setPIDenable_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setTPOoutput_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetAction_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setDeadBandHiTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_SetDeadBandLoTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableHiProcAlarm_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableHiDeviationAlarm_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableHiDeviationWarn_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableLoDeviationWarn_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableLoDeviationAlarm_Handler(KIrp* I);
NTSTATUS FLUXHEATER_enableLoProcAlarm_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setHiProcTemp_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setAlarmHiTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setWarnHiTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setWarnLoTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setAlarmLoTempOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setLoProcTemp_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetPIDMode_Handler(KIrp* I);
NTSTATUS FLUXHEATER_DeActivateZones_Handler(KIrp* I);
NTSTATUS FLUXHEATER_initializePowerUpSequencing_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setMinRiseDegreeCounts_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setRiseRatePeriod_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setSecondPIDDirection_Handler(KIrp* I);
NTSTATUS FLUXHEATER_ActivateZones_Handler(KIrp* I);
NTSTATUS FLUXHEATER_getProcVar_Handler(KIrp* I);
NTSTATUS FLUXHEATER_checkWarningState_Handler(KIrp* I);
NTSTATUS FLUXHEATER_InDeadBandOrIsNotEnabled_Handler(KIrp* I);
NTSTATUS FLUXHEATER_IsZoneInWarning_Handler(KIrp* I);
NTSTATUS FLUXHEATER_isInDeviationAlarmZone_Handler(KIrp* I);
NTSTATUS FLUXHEATER_startSequencingRequiresTimer_Handler(KIrp* I);
NTSTATUS FLUXHEATER_isFluxHeaterEnabled_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setFluxheaterDelayTime_Handler(KIrp* I);
NTSTATUS FLUXHEATER_setFluxHeaterEnable_Handler(KIrp* I);
NTSTATUS FLUXHEATER_initTcInput_Handler(KIrp* I);
NTSTATUS FLUXHEATER_initTPOoutput_Handler(KIrp* I);
NTSTATUS FLUXHEATER_getSecondaryData_Handler(KIrp* I);
NTSTATUS FLUXHEATER_getConfigParam_Handler(KIrp* I);
NTSTATUS FLUXHEATER_getInputReference_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetPbCool_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetTiCool_Handler(KIrp* I);
NTSTATUS FLUXHEATER_PIDsetTdCool_Handler(KIrp* I);
NTSTATUS FLUXHEATER_SetCoolOutput_Handler(KIrp* I);
NTSTATUS FLUXHEATER_GetCoolingPercentage_Handler(KIrp* I);
NTSTATUS FLUXHEATER_SetCoolOffset_Handler(KIrp* I);
NTSTATUS FLUXHEATER_SetCoolOnOff_Handler(KIrp* I);
NTSTATUS FLUXHEATER_shutdownBlowers_Handler(KIrp* I);

NTSTATUS GLOBALBLOWER_0_100_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_LOW_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_MED_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_HIGH_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_MINIMUM_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_setEnableState_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_setOutputPercent_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_getOutputPercent_Handler(KIrp* I);
NTSTATUS GLOBALBLOWER_setOnTime_Handler(KIrp* I);

NTSTATUS HC2XCTL_recipeLoaded_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);

NTSTATUS HEATZONEBLOWER_100H_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_setEnable_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_setLowSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_setMediumSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_setHighSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_setOutputPercent_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_getIfHZBlowerIsEnabled_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_getOutputPercent_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_getLowSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_getMediumSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_getHighSetting_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_controlMap_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_StandbyTime_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_IEBoardLoad_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_0_100A_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_0_100B_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_0_100C_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_MINIMUM_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_IE_LEVEL_Handler(KIrp* I);
NTSTATUS HEATZONEBLOWER_MAXIMUM_Handler(KIrp* I);

NTSTATUS IOCTL_START_HELLER_DRIVER_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_STOP_HELLER_DRIVER_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_getTimerLoss_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_SetMonitorMode_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_GET_TICK_FREQUENCY_HANDLER(KIrp* I);
NTSTATUS IOCTL_CONTROL_HAULTED_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_REQUEST_MONITOR_MODE_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_CONTROL_STARTED_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_TEST_WATCHDOG_Handler(XpDriverDevice* pXp, KIrp* I);
NTSTATUS IOCTL_ACTIVATE_MODBUS_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS IOCTL_GATHER_TDM_EEPROM_Handler(KIrp* I);
NTSTATUS IOCTL_SET_TDM_EEPROM_Handler(KIrp* I);
NTSTATUS IOCTL_PROGRAM_TDM_Handler(KIrp* I);

NTSTATUS LIGHTTOWER_Enable_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_getStatus_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_setSonyGreenLightOption_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_Disable_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_setDOAvailibility_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_setBoardDropBehavior_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_setCLBehavior_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_SpecialInput_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_TimeValue_Handler(KIrp* I);

NTSTATUS LIGHTTOWER_LT2_Enable_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_LT2_DO_Red_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_LT2_DO_Yellow_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_LT2_DO_Green_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_LT2_getStatus_Handler(KIrp* I);

NTSTATUS LIGHTTOWER_SPChange_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_Ready_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_ReadyBoards_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_Warning_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_Alarm_Cooldown_Handler(KIrp* I);
NTSTATUS LIGHTTOWER_EStop_Cooldown_Handler(KIrp* I);

NTSTATUS LUBE_getElapsedTime10ths_Handler(KIrp* I);
NTSTATUS LUBE_optionEnable_Handler(KIrp* I);
NTSTATUS LUBE_setLubeIntervalTime_Handler(KIrp* I);
NTSTATUS LUBE_setLubeDurationTime_Handler(KIrp* I);
NTSTATUS LUBE_setElapsedTime10ths_Handler(KIrp* I);

NTSTATUS MASSANALOG_setOnTime_Handler(KIrp* I);
NTSTATUS MASS_PARAM_BEGIN_Handler(KIrp* I);

NTSTATUS NITROGEN_getNitrogenEnable_Handler(KIrp* I);
NTSTATUS NITROGEN_setNitrogenEnable_Handler(KIrp* I);
NTSTATUS NITROGEN_setAutoPurgeEnable_Handler(KIrp* I);
NTSTATUS NITROGEN_setPurgeTime10ths_Handler(KIrp* I);
NTSTATUS NITROGEN_setNormalTime10ths_Handler(KIrp* I);
NTSTATUS NITROGEN_setActive_Handler(KIrp* I);
NTSTATUS NITROGEN_getActive_Handler(KIrp* I);
NTSTATUS NITROGEN_setCoolRunTime_Handler(KIrp* I);
NTSTATUS NITROGEN_isNitroOnInCooldown_Handler(KIrp* I);
NTSTATUS NITROGEN_dsClosedLoop_Handler(KIrp* I);
NTSTATUS NITROGEN_makeOutputsUnavailable_Handler(KIrp* I);
NTSTATUS NITROGEN_pollPpmState_Handler(KIrp* I);
NTSTATUS NITROGEN_setRedundInput_Handler(KIrp* I);
NTSTATUS NITROGEN_enableWarning_Handler(KIrp* I);
NTSTATUS NITROGEN_enableAlarm_Handler(KIrp* I);
NTSTATUS NITROGEN_setAlarmTime_Handler(KIrp* I);
NTSTATUS NITROGEN_setWarningTime_Handler(KIrp* I);

NTSTATUS OVEN_setStartWithJob_Handler(KIrp* I);
NTSTATUS OVEN_Pause_Handler(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS OVEN_setJob_Handler(KIrp* I);
NTSTATUS OVEN_setJobStartupComplete_Handler(KIrp* I);
NTSTATUS OVEN_resume_Handler(XpDriverDevice* pXP, KIrp* I);
NTSTATUS OVEN_setBelts_Handler(KIrp* I);
NTSTATUS OVEN_setBoardsProcessedConfig_Handler(KIrp* I);
NTSTATUS OVEN_setBoardAnimationConfig_Handler(KIrp* I);
NTSTATUS OVEN_setBoardsInOvenConfig_Handler(KIrp* I);
NTSTATUS OVEN_setBoardDropConfig_Handler(KIrp* I);
NTSTATUS OVEN_setSMEMAConfig_Handler(KIrp* I);
NTSTATUS OVEN_setModelNo_Handler(KIrp* I);
NTSTATUS OVEN_setDirection_Handler(KIrp* I);
NTSTATUS OVEN_setRedundantOverTempOption_Handler(KIrp* I);
NTSTATUS OVEN_setLTOption_Handler(KIrp* I);
NTSTATUS OVEN_setBlowerFailureOption_Handler(KIrp* I);
NTSTATUS OVEN_setThirdLaneEnabled_Handler(KIrp* I);
NTSTATUS OVEN_setLowExhaustWarningTime_Handler(KIrp* I);
NTSTATUS OVEN_setLowExhaustAlarmTime_Handler(KIrp* I);
#if 0
NTSTATUS OVEN_setAsBoardTypeA_Handler(KIrp* I);
#else
NTSTATUS OVEN_waterTempHighEnable_Handler(KIrp* I);
NTSTATUS OVEN_waterTempHighAlarmTime_Handler(KIrp* I);
NTSTATUS OVEN_waterTempHighWarningTime_Handler(KIrp* I);
#endif
NTSTATUS OVEN_SetDemoMode_Handler(KIrp* I);
NTSTATUS OVEN_setRecipeName_Handler(KIrp* I);
NTSTATUS OVEN_getRecipeName_Handler(KIrp* I);
NTSTATUS OVEN_getDirection_Handler(KIrp* I);
NTSTATUS OVEN_getJob_Handler(KIrp* I);
NTSTATUS OVEN_ExternalCheckForPowerFailure_Handler(KIrp* I);
NTSTATUS OVEN_getModelNo_Handler(KIrp* I);
NTSTATUS OVEN_setFourthLaneEnabled_Handler(KIrp* I);
NTSTATUS OVEN_setExhaustWarningEnable_Handler(KIrp* I);
NTSTATUS OVEN_setExhaustAlarmEnable_Handler(KIrp* I);
NTSTATUS OVEN_disableAutoAcknowledge_Handler(KIrp* I);
NTSTATUS OVEN_setPowerFailureTime_Handler(KIrp* I);
NTSTATUS OVEN_setFiveSecondDisable_Handler(KIrp* I);
NTSTATUS OVEN_getFiveSecondDisable_Handler(KIrp* I);
NTSTATUS OVEN_delayCooldown_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorDelayCooldown_Handler(KIrp* I);
NTSTATUS OVEN_heaterFailureDelayCooldown_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorTempZoneFailureLow_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorFluxZoneFailureLow_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorTempZoneFailureHigh_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorFluxZoneFailureHigh_Handler(KIrp* I);
NTSTATUS OVEN_currentMonitorCommFailure_Handler(KIrp* I);
NTSTATUS OVEN_heaterTempZoneFailure_Handler(KIrp* I);
NTSTATUS OVEN_heaterFluxZoneFailure_Handler(KIrp* I);
NTSTATUS OVEN_coolPipeBlockage_Handler(KIrp* I);
NTSTATUS OVEN_delayCooldownTime_Handler(KIrp* I);
NTSTATUS OVEN_inCooldown_Handler(KIrp* I);
NTSTATUS OVEN_returnOvenProgrammed_Handler(KIrp* I);
NTSTATUS OVEN_setBoardStop_Handler(KIrp* I);
NTSTATUS OVEN_Request_Cooldown_Handler(KIrp* I);
NTSTATUS OVEN_FanFault_Alarm_Handler(KIrp* I);
NTSTATUS OVEN_BFAud_Handler(KIrp* I);
NTSTATUS OVEN_BFTimeAlarm_Handler(KIrp* I);
NTSTATUS OVEN_BFTimeWarn_Handler(KIrp* I);
NTSTATUS OVEN_BFWARN_Handler(KIrp* I);
NTSTATUS OVEN_ClearCooldownNotify_Handler(KIrp* I);
NTSTATUS OVEN_AllowSmemaAgain_Handler(KIrp* I);
NTSTATUS OVEN_variousSettings_Handler(KIrp* I);
NTSTATUS OVEN_standbyRTime_Handler(KIrp* I);
NTSTATUS OVEN_standbyCoolTime_Handler(KIrp* I);
NTSTATUS OVEN_standbyInput_Handler(KIrp* I);
NTSTATUS OVEN_energyRecipe_Handler(KIrp* I);
NTSTATUS OVEN_variousSettingsII_Handler(KIrp* I);
NTSTATUS OVEN_AlarmScannerOption_Handler(KIrp* I);
NTSTATUS OVEN_AlarmScannerOutput_Handler(KIrp* I);
NTSTATUS OVEN_AlarmScannerState_Handler(KIrp* I);
NTSTATUS OVEN_AlarmScannerHold_Handler(KIrp* I);
NTSTATUS OVEN_BarcodeReset_Handler(KIrp* I);
NTSTATUS OVEN_disableDevAlarmInStartup_Handler(KIrp* I);
NTSTATUS OVEN_setStartupCompletePlusDelay_Handler(KIrp* I);
NTSTATUS OVEN_variousSettingsIII_Handler(KIrp* I);

NTSTATUS OXYGEN_setEnabled_Handler(KIrp* I);	
NTSTATUS OXYGEN_getOxygenVolts_Handler(KIrp* I);

NTSTATUS PIDCONTROLLER_setTpo_Handler(KIrp* I);
NTSTATUS PIDCONTROLLER_setIO_Handler(KIrp* I);

NTSTATUS MASSCONTROLLER_CONFIG_Handler(KIrp* I);
NTSTATUS PURGE_setActive_Handler(KIrp* I);
NTSTATUS PURGE_setPurgeTime10ths_Handler(KIrp* I);
NTSTATUS PURGE_setDigitialOutput_Handler(KIrp* I);
NTSTATUS PURGE_forceOn_Handler(KIrp* I);
NTSTATUS PURGE_setRecipeOutput_Handler(KIrp* I);
NTSTATUS PURGE_setMessageDelay_Handler(KIrp* I);
NTSTATUS PURGE_setMessageType_Handler(KIrp* I);
NTSTATUS PURGE_setInput_Handler(KIrp* I);
NTSTATUS PURGE_setOutput_Handler(KIrp* I); 
NTSTATUS PURGE_setLightTowerAction_Handler(KIrp* I);
NTSTATUS PURGE_enableCustomAlarm_Handler(KIrp* I);
NTSTATUS PURGE_setLineState_Handler(KIrp* I);
NTSTATUS PURGE_setAudibleWarning_Handler(KIrp* I);
NTSTATUS PURGE_CA3Input_Handler(KIrp* I);
NTSTATUS PURGE_CA3Output_Handler(KIrp* I);
NTSTATUS PURGE_CA3WarningTime_Handler(KIrp* I);
NTSTATUS PURGE_CA3AlarmTime_Handler(KIrp* I);
NTSTATUS PURGE_CA4Input_Handler(KIrp* I);
NTSTATUS PURGE_CA4Output_Handler(KIrp* I);
NTSTATUS PURGE_CA4WarningTime_Handler(KIrp* I);
NTSTATUS PURGE_CA4AlarmTime_Handler(KIrp* I);
NTSTATUS PURGE_CA5Input_Handler(KIrp* I);
NTSTATUS PURGE_CA5Output_Handler(KIrp* I);
NTSTATUS PURGE_CA5WarningTime_Handler(KIrp* I);
NTSTATUS PURGE_CA5AlarmTime_Handler(KIrp* I);
NTSTATUS PURGE_DOBCOption_Handler(KIrp* I);
NTSTATUS PURGE_DOBCAction_Handler(KIrp* I);
NTSTATUS PURGE_DOBCOutput_Handler(KIrp* I);
NTSTATUS PURGE_DOBCCount_Handler(KIrp* I);

NTSTATUS RAIL_resetIncDec_Handler(KIrp* I);
NTSTATUS RAIL_increment_Handler(KIrp* I);
NTSTATUS RAIL_isPresetStable_Handler(KIrp* I);
NTSTATUS RAIL_setHomeDirection_Handler(KIrp* I);
NTSTATUS RAIL_setHomeDistanceCounts_Handler(KIrp* I);
NTSTATUS RAIL_setControlType_Handler(KIrp* I);
NTSTATUS RAIL_setFalsePositionCounts_Handler(KIrp* I);
NTSTATUS RAIL_setOutputEnableFlag_Handler(KIrp* I);
NTSTATUS RAIL_decrement_Handler(KIrp* I);
NTSTATUS RAIL_isInFinalPosition_Handler(KIrp* I);
NTSTATUS RAIL_EnterInitialCorrectionFactor_Handler(KIrp* I);
NTSTATUS RAIL_setHuntPreference_Handler(KIrp* I);
NTSTATUS RAIL_EnterMaximumHunts_Handler(KIrp* I);
NTSTATUS RAIL_EnterNegativeTolerance_Handler(KIrp* I);
NTSTATUS RAIL_EnterPositiveTolerance_Handler(KIrp* I);
NTSTATUS RAIL_enterBackupDistance_Handler(KIrp* I);
NTSTATUS RAIL_getSetpoint(KIrp* I);
NTSTATUS RAIL_getSetpoint_Handler(KIrp* I);
NTSTATUS RAIL_PREPROCESS_Handler(KIrp* I);
NTSTATUS RAIL_SetLaneIndex_Handler(KIrp* I);
NTSTATUS RAILS_masterSetpoint_Handler(KIrp* I);
NTSTATUS RAILS_getHomeDistanceCounts_Handler(KIrp* I);

NTSTATUS RAILS_setConfiguration_Handler(KIrp* I);
NTSTATUS RAILS_IntializeEdgeholdBools_Handler(KIrp* I);
NTSTATUS RAILS_getPositionCounts_Handler(KIrp* I);
NTSTATUS RAILS_setPosition_Handler(KIrp* I);
NTSTATUS RAILS_EnableTest_Handler(KIrp* I);
NTSTATUS RAILS_DisableTest_Handler(KIrp* I);
NTSTATUS RAILS_arrayInitialization_Handler(KIrp* I);
NTSTATUS RAILS_setOpFromCoolRailMovement_Handler(KIrp* I);
NTSTATUS RAILS_queueSetPosition_Handler(KIrp* I);
NTSTATUS RAILS_setRailStateToPresetForJobLoad_Handler(KIrp* I);
NTSTATUS RAILS_bypassHomeAndPresetRoutines_Handler(KIrp* I);
NTSTATUS RAILS_getValue_Handler(KIrp* I);
NTSTATUS RAILS_setHardwareOption_Handler(KIrp* I);
NTSTATUS RAILS_readHardwareFlag_Handler(KIrp* I);
NTSTATUS RAILS_sendRailsHome_Handler(KIrp* I);
NTSTATUS RAILS_readHasHomedFlag_Handler(KIrp* I);
NTSTATUS RAILS_setHardwareInput_Handler(KIrp* I);
NTSTATUS RAILS_setCBS2Rail_Handler(KIrp* I);
NTSTATUS RAILS_executeJog_Handler(KIrp* I);
NTSTATUS RAILS_sequenceRails_Handler(KIrp* I);
NTSTATUS RAILS_setPulseCounts_Handler(KIrp* I);
NTSTATUS RAILS_monitorm_bJogOn_Handler(KIrp* I);
NTSTATUS RAILS_monitorcurrentRail_Handler(KIrp* I);
NTSTATUS RAILS_monitorm_bUDPhaseMonitor_Handler(KIrp* I);
NTSTATUS RAILS_monitorm_uintJogPhase_Handler(KIrp* I);
NTSTATUS RAILS_monitorm_uintUpdownPhase_Handler(KIrp* I);
NTSTATUS RAILS_monitorudPhaseTimer_Handler(KIrp* I);
NTSTATUS RAILS_exercisePossible_Handler(KIrp* I);
NTSTATUS RAILS_HardwarePause_Handler(KIrp* I);
NTSTATUS RAILS_HardwareResume_Handler(KIrp* I);
NTSTATUS RAILS_railsInHardwareMode_Handler(KIrp* I);
NTSTATUS RAILS_getCountPerCM_Handler(KIrp* I);

//NTSTATUS RAILS_
NTSTATUS RECIPETRIGGER_IncrementInstance_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getNumberComms_Handler(KIrp* I);	
NTSTATUS RECIPETRIGGER_DecrementInstance_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setFireRecipeNotification_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getNotify_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getControlComm_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setNotify_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getFireRecipeNotification_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getbSaveRecipePath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setbSaveRecipePath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getrecipeSaveTransferPath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getactionControl_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setactionControl_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getrecipeTransferPath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_getrecipePath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setrecipeTransferPath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_ExecuteLoad_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setrecipePath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setControlComm_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setrecipeSaveTransferPath_Handler(KIrp* I);
NTSTATUS RECIPETRIGGER_setHellerExitedFlagHandler(KIrp* I);
NTSTATUS RECIPETRIGGER_getHellerExitedFlagHandler(KIrp* I);
NTSTATUS RECIPETRIGGER_getHellerUpHandler(KIrp* I);
NTSTATUS RECIPETRIGGER_setHellerUpHandler(KIrp* I);
NTSTATUS RECIPETRIGGER_setReadControlHandler(KIrp* I);
NTSTATUS RECIPETRIGGER_getReadControlHandler(KIrp* I);

NTSTATUS SETPOINTS_assignRail_Handler(KIrp* I);

NTSTATUS SMEMA_setSMEMAtype_Handler(KIrp* I);
NTSTATUS SMEMA_setSMEMAdeadBandCounts_Handler(KIrp* I);
NTSTATUS SMEMA_HoldLot_Handler(KIrp* I);
NTSTATUS SMEMA_ClearLot_Handler(KIrp* I);
NTSTATUS SMEMA_CureApp_Handler(KIrp* I);
NTSTATUS SMEMA_EntrHold_Handler(KIrp* I);
NTSTATUS SMEMA_clearBarcodeTimeout_Handler(KIrp * I);
NTSTATUS SMEMA_HoldWarning_Handler(KIrp *I);
NTSTATUS SMEMA_Count_Handler(KIrp*I);
NTSTATUS SMEMA_MaxBoardsPerLaneEnable_Handler(KIrp* I);
NTSTATUS SMEMA_MaxBoardsPerLaneCount_Handler(KIrp* I);
NTSTATUS SMEMA_NoBoardAnimation_Handler(KIrp* I);
NTSTATUS SMEMA_MesActive_Handler(KIrp* I);
NTSTATUS SMEMA_MesEnabled_Handler(KIrp* I);
NTSTATUS SMEMA_LaneBoardSpacing_Handler(KIrp* I);
NTSTATUS SMEMA_LaneBoardLength_Handler(KIrp* I);
NTSTATUS SMEMA_setLaneHold_Handler(KIrp* I);

NTSTATUS TEMPZONE_getProcVar_Handler(KIrp* I);
NTSTATUS TEMPZONE_setActive_Handler(KIrp* I);
NTSTATUS TEMPZONE_setSetPoint_Handler(KIrp* I);
NTSTATUS TEMPZONE_setSequenceGroup_Handler(KIrp* I);
NTSTATUS TEMPZONE_setZoneAuto_Handler(KIrp* I);
NTSTATUS TEMPZONE_setPIDenable_Handler(KIrp* I);
NTSTATUS TEMPZONE_setTPOoutput_Handler(KIrp* I);
NTSTATUS TEMPZONE_setDeadBandHiTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_SetDeadBandLoTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableHiProcAlarm_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableHiDeviationAlarm_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableHiDeviationWarn_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableLoDeviationWarn_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableLoDeviationAlarm_Handler(KIrp* I);
NTSTATUS TEMPZONE_enableLoProcAlarm_Handler(KIrp* I);
NTSTATUS TEMPZONE_setHiProcTemp_Handler(KIrp* I);
NTSTATUS TEMPZONE_setAlarmHiTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_setWarnHiTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_setWarnLoTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_setAlarmLoTempOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_setLoProcTemp_Handler(KIrp* I);
NTSTATUS TEMPZONE_getTPOoutput_Handler(KIrp* I);
NTSTATUS TEMPZONE_getSetPoint_Handler(KIrp* I);
NTSTATUS TEMPZONE_getCurrentState_Handler(KIrp* I);
NTSTATUS TEMPZONE_isActive_Handler(KIrp* I);
NTSTATUS TEMPZONE_IsZoneInWarning_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetPb_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetTi_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetTd_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetAction_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetPIDMode_Handler(KIrp* I);
NTSTATUS TEMPZONE_isInDeviationAlarmZone_Handler(KIrp* I);
NTSTATUS TEMPZONE_getSecondaryData_Handler(KIrp* I);
NTSTATUS TEMPZONE_getConfigParam_Handler(KIrp* I);
NTSTATUS TEMPZONE_setGlobalHighProcess_Handler(KIrp* I);
NTSTATUS TEMPZONE_initTcInput_Handler(KIrp* I);
NTSTATUS TEMPZONE_initTPOoutput_Handler(KIrp* I);
NTSTATUS TEMPZONE_getInputReference_Handler(KIrp* I);
NTSTATUS TEMPZONE_shutdownBlowers_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetPbCool_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetTiCool_Handler(KIrp* I);
NTSTATUS TEMPZONE_PIDsetTdCool_Handler(KIrp* I);
NTSTATUS TEMPZONE_SetCoolOutput_Handler(KIrp* I);
NTSTATUS TEMPZONE_GetCoolingPercentage_Handler(KIrp* I);
NTSTATUS TEMPZONE_SetCoolOffset_Handler(KIrp* I);
NTSTATUS TEMPZONE_SetCoolOnOff_Handler(KIrp* I);

NTSTATUS TEMPZONES_DeActivateZones_Handler(KIrp* I);				
NTSTATUS TEMPZONES_ActivateZones_Handler(KIrp* I);				
NTSTATUS TEMPZONES_setStartUpPowerPercent_Handler(KIrp* I);	
NTSTATUS TEMPZONES_setDelayStartPeriod_Handler(KIrp* I);			
NTSTATUS TEMPZONES_setMinRiseDegreeCounts_Handler(KIrp* I);	
NTSTATUS TEMPZONES_setRiseRatePeriod_Handler(KIrp* I);			
NTSTATUS TEMPZONES_initializePowerUpSequencing_Handler(KIrp* I);	
NTSTATUS TEMPZONES_setSecondaryBoardDirection_Handler(KIrp* I);
NTSTATUS TEMPZONES_setTCWarnPercentage_Handler(KIrp* I);
NTSTATUS TEMPZONES_enableDrawWarning_Handler(KIrp* I);
NTSTATUS TEMPZONES_configureIO_Handler(KIrp* I);
NTSTATUS TEMPZONES_setNumberDrawWarningZones_Handler(KIrp* I);
NTSTATUS TEMPZONES_setHiProcessDelayTime_Handler(KIrp* I);
NTSTATUS TEMPZONES_setCooldownSP_Handler(KIrp* I);
NTSTATUS TEMPZONES_setRiseRateWarning_Handler(KIrp* I);
NTSTATUS TEMPZONES_setCoolCycle_Handler(KIrp* I);
NTSTATUS TEMPZONES_CooldownCooling_Handler(KIrp* I);
NTSTATUS TEMPZONES_CooldownSequenced_Handler(KIrp* I);

NTSTATUS INTERCOMMTRANSFER_getActiveRailCount_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveRailSetChannel_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveBeltCount_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveHeatCount_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveHeatChannel_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveBeltsChannel_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_EnterChannel_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveProfileCount_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getActiveProfileChannel_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getMaxNumberChannels_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getChannelArrayType_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getChannelArrayEnabled_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_setDanState_Handler(KIrp* I);
NTSTATUS INTERCOMMTRANSFER_getDanState_Handler(KIrp* I);

NTSTATUS XpDriverDevice_DeviceControl(XpDriverDevice* pXpDriverDevice, KIrp* I);
NTSTATUS XPDRIVER_IOCTL_800_Handler(KIrp* I);
NTSTATUS XPDRIVER_IOCTL_801_Handler(KIrp* I);
NTSTATUS SECSGEM_Entry_option_Handler(KIrp* I);
NTSTATUS OVEN_variousSettingsVII_Handler(KIrp* I);
NTSTATUS APCO_ValidScan_Handler(KIrp* I);
NTSTATUS OVEN_APCORuntimeEnable_Handler(KIrp* I);
NTSTATUS APCO_InvalidateScan_Handler(KIrp* I);

NTSTATUS TEMPZONES_setStartupGrpControlGRP_Handler(KIrp* I);
NTSTATUS TEMPZONES_setStartupGrpControlDO_Handler(KIrp* I);
NTSTATUS SMEMA_SecsGemControl_Handler(KIrp* I);
NTSTATUS GetBitPackedData_Handler(KIrp* I);
NTSTATUS OVEN_variousSettingsVIII_Handler(KIrp* I);
NTSTATUS OVEN_variousSettingsX_Handler(KIrp* I);

NTSTATUS OVEN_setBeltStopWhenRailMoving_Handler(KIrp* I);

NTSTATUS OVEN_recipeLoadBoardEntryWait_Handler(KIrp* I);
#endif		// __XpDriverDevice_h__
