//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: tempzone.h
//
// Description: define file for heater zones
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 07-Jan-15  FJN  Declare TempZone_currentMonitorFailure and TempZone_heaterFailure
// 13-Mar-15  FJN  Declare TempZone_currentMonitorFailureHigh
//*****************************************************************************
#ifndef __TEMPZONE_H__
#define __TEMPZONE_H__
#include "typedefdefine.h"
#include "hellerenumerations.h"
#include "pidCtlr.h"

// There are three states that the oven can be in,
// CoolDown - An Alarm condition may have caused or the operator may have set.
// PowerUpSequencing - Whenever a new job is set power up sequencing must cycle
// 	through the zones of the current power up group. When the start up power
// 	level has been reached go to the next group.
// Operational - A job other than cooldown is loaded and power up sequencing is
// 	complete.

// Rules:
//	HiProc > HiDeviation > HiWarning > hiDeadband > pv
// pv >loDeadBand > loWarning > LoDeviation > HiProc

// any change of SP is a new job
// changing to manual for TPO's the alarms are still monitored.


#define NULL_TEMP_IO 99

typedef struct 	_TempZone_
{
//private:

	char	name[MaxNameLength+1];

	PIDController pidCtrl;

	int wallyCount;	
	BOOL				m_bOff;	
	BOOL				riseRateSetPointChange;

	DWORD				selfAckAlarmNo;			// the self acknowledging alarm number for warnings.

	// Alarms and Warnings

	// the high and low process alarms being absolute values, vs a relative offset from setpoint
	// needed to be changed from unsigned long (DWORD) to type long. Heller's requirements are 
	// that they need to be able to load negative numbers into the high and low process alarms.

	BOOL				directionalIOset;


	DWORD				selfAckAlarmSecondNo;	// the self acknowledging alarm number for secondary warnings.(differing reset logic)
	DWORD				selfAckAlarmNoComm;     //the self acknowledging comm loss

	LONG				onInitTPO;
	BOOL				bSecondaryTPODirect;

	BOOL				m_bSecondaryHiProcCountdownOn;
	BOOL				m_bSecondaryOpenThermocouple;
	BOOL				m_bGroupStarted;

	WORD		dummyValue;			// in the event of trying to access the wrong zone
									// this will help to prevent a null pointer error.
	BOOL		m_bEnableOverDrawWarning; //disable on new recipe enable when lighttower is green
	int		m_iOverdrawPercentage;
	DWORD		overdrawTime;
	DWORD		m_dwrdHiProcSecBeginTime;

	// Default constructor for array initialization, remember to initialize a
	// single tempzone object first using the above constructor to initialize
	// the static pointers that are required.

	int m_iTestPath;
	UINT readDelay;
	UINT commLossAttemptsII;
	DWORD  		lastCheckTime; 		// a time in milliseconds at the beginning of the check
	LONG  		lastCheckTemp; 		

} TempZone;

void TempZone_init(TempZone* pTempZone, BOOL bLocal);
void TempZone_blowerFailure(TempZone* pTempZone, BOOL bOFF);
void TempZone_currentMonitorFailureLow(TempZone* pTempZone, BOOL bOFF);
void TempZone_currentMonitorFailureHigh(TempZone* pTempZone, BOOL bOFF);
void TempZone_heaterFailure(TempZone* pTempZone, BOOL bOFF);

void	TempZone_configureIO(TempZone* pTempZone);
void	TempZone_configureIO1088(TempZone* pTempZone);
void	TempZone_configureIO1500(TempZone* pTempZone);
void	TempZone_configureIO1700(TempZone* pTempZone);
void	TempZone_configureIO1800(TempZone* pTempZone);
void	TempZone_configureIO1800Z(TempZone* pTempZone);
void	TempZone_configureIO1910(TempZone* pTempZone);
void	TempZone_configureIO1911(TempZone* pTempZone);
void	TempZone_configureIO1912(TempZone* pTempZone);
void	TempZone_configureIO1913(TempZone* pTempZone);
void	TempZone_configureIO1707(TempZone* pTempZone);
void	TempZone_configureIO1914(TempZone* pTempZone);
void	TempZone_configureIORL1917(TempZone* pTempZone);
void	TempZone_configureIORL2024(TempZone* pTempZone);
void	TempZone_configureIORL2060(TempZone* pTempZone);
void	TempZone_configureIORL2018(TempZone* pTempZone);
void	TempZone_configureIORLDual1707(TempZone* pTempZone);
void	TempZone_configureIORL1913(TempZone* pTempZone);
void	TempZone_configureIORL1914(TempZone* pTempZone);
void	TempZone_enableDeadBandRangeCheck(TempZone* pTempZone, BOOL dbFlag /*= TRUE*/ );
BOOL	TempZone_isInDeadBandRangeCheckEnabled(TempZone* pTempZone);
void    TempZone_checkSelfAcknowledgeAlarms(TempZone* pTempZone);
void    TempZone_setDeadBandState(TempZone* pTempZone, BOOL dbState );
void	TempZone_setPowerUpComplete(TempZone* pTempZone, BOOL bSetTo );
void	TempZone_checkAlarmBands(TempZone* pTempZone);

BOOL	TempZone_isPIDenabled(TempZone* pTempZone);
BOOL	TempZone_isActive(TempZone* pTempZone);
BOOL	TempZone_isHiProcAlarmEnabled(TempZone* pTempZone);
BOOL	TempZone_isLohProcAlarmEnabled(TempZone* pTempZone);
BOOL	TempZone_isHiDeviationAlarmEnabled(TempZone* pTempZone);
BOOL	TempZone_isLoDeviationAlarmEnabled(TempZone* pTempZone);
BOOL	TempZone_isHiDeviationWarningEnabled(TempZone* pTempZone);
BOOL	TempZone_isLoDeviationWarningEnabled(TempZone* pTempZone);
// The following line is no longer correct due to the fact that zoneAuto has 
// three states - manual,auto or off which is different from the original 
// specifications of manual or auto.
// SDY - 10/07/98
//	BOOL	isZoneAuto					(TempZone* pTempZone)				{ return zoneAuto; }
// jwf 9/05/00 trying to get back
BOOL	TempZone_isInDeadBandZone		(TempZone* pTempZone);
DWORD	TempZone_getCurrentState 		(TempZone* pTempZone);				
SHORT	TempZone_getZoneState			(TempZone* pTempZone);

DWORD	TempZone_getHiProcTemp(TempZone* pTempZone);
DWORD	TempZone_getLoProcTemp(TempZone* pTempZone);
DWORD	TempZone_getAlarmHiTempOffset(TempZone* pTempZone);
DWORD	TempZone_getAlarmLoTempOffset(TempZone* pTempZone);
DWORD	TempZone_getWarnHiTempOffset(TempZone* pTempZone);
DWORD	TempZone_getWarnLoTempOffset(TempZone* pTempZone);
DWORD	TempZone_getDeadBandHiTempOffset(TempZone* pTempZone);
DWORD	TempZone_getDeadBandLoTempOffset(TempZone* pTempZone);

DWORD TempZone_getSequenceGroup	(TempZone* pTempZone);
DWORD TempZone_getTPOoutput		(TempZone* pTempZone);
DWORD TempZone_getZoneNo		(TempZone* pTempZone);
DWORD TempZone_getSetPoint		(TempZone* pTempZone);
DWORD TempZone_getProcVar		(TempZone* pTempZone);
DWORD TempZone_getInputVal(TempZone* pTempZone);
const char * const TempZone_getName	(TempZone* pTempZone);

BOOL TempZone_setActive			(TempZone* pTempZone, BOOL active );
BOOL TempZone_setPresent		(TempZone* pTempZone, BOOL present );
void TempZone_setZoneAuto		(TempZone* pTempZone, enum ZoneTriState autoState );

void TempZone_setPIDenable		(TempZone* pTempZone, BOOL pe );
void TempZone_setAlarmsEnabled	(TempZone* pTempZone, BOOL state );
BOOL TempZone_setSequenceGroup	(TempZone* pTempZone, DWORD  groupNo );
void TempZone_setGroupStarted	(TempZone* pTZone, BOOL bSet);


BOOL TempZone_setSetPoint		(TempZone* pTempZone, LONG  newSetPoint );
void TempZone_setUpDatePeriod	(TempZone* pTempZone, DWORD  newUpdatePeriod );
void TempZone_setMinTpoOut		(TempZone* pTempZone, DWORD  newMinTpoOut );
void TempZone_setMaxTpoOut		(TempZone* pTempZone, DWORD  newMaxTpoOut );
void TempZone_setTPOoutput		(TempZone* pTempZone, LONG   cTPOoutput );
void TempZone_set_pendTPOoutput		(TempZone* pTempZone, LONG   cTPOoutput );
void TempZone_enableHiProcAlarm	(TempZone* pTempZone, BOOL enable );
void TempZone_enableLoProcAlarm	(TempZone* pTempZone, BOOL enable );

BOOL TempZone_setHiProcTemp(TempZone* pTempZone, DWORD  highProcTemp );	// the absolute high alarm
BOOL TempZone_setLoProcTemp(TempZone* pTempZone, DWORD  lowProcTemp );

BOOL TempZone_setAlarmHiTempOffset(TempZone* pTempZone, DWORD  aHiTempOffset );
BOOL TempZone_setAlarmLoTempOffset(TempZone* pTempZone, DWORD  aLoTempOffset );

BOOL TempZone_setWarnHiTempOffset(TempZone* pTempZone, DWORD  wHiTempOffset );
BOOL TempZone_setWarnLoTempOffset(TempZone* pTempZone, DWORD  wLoTempOffset );

BOOL TempZone_setDeadBandHiTempOffset(TempZone* pTempZone, DWORD dbHiTempOffset );
BOOL TempZone_setDeadBandLoTempOffset(TempZone* pTempZone, DWORD dbLoTempOffset );

void TempZone_calcPid(TempZone* pTempZone);
void TempZone_process(TempZone* pTempZone);

void TempZone_setGlobalHighProcess(TempZone* pTempZone, LONG nhp);
void TempZone_setCoolPeriod(TempZone* pTempZone, DWORD period);
void TempZone_setCoolOutput(TempZone* pTempZone, DWORD output);
//function below  are called by the prp3 program
BOOL TempZone_setProcVariable		(TempZone* pTempZone, DWORD   newProcVar );
BOOL    TempZone_IsZoneInWarning(TempZone* pTempZone);
void    TempZone_resetPID(TempZone* pTempZone);    
void	TempZone_setDrawWarningPercentage(TempZone* pTempZone, int drawPercent);
void	TempZone_EnableDrawWarning(TempZone* pTempZone, BOOL bEnable);
SHORT	TempZone_isInDeviationAlarmZone(TempZone* pTempZone);
void	TempZone_setHiProcDelay(TempZone* pTempZone, int iDelay);
void TempZone_testTPOPath(TempZone* pTempZone, int iTest);
void TempZone_manualZoneSequencedOn(TempZone* pTempZone);
void	TempZone_initTcInput(TempZone* pTempZone, UINT nIndex);
void	TempZone_initTPOoutput(TempZone* pTempZone, UINT nIndex);
void TempZone_sampleRiseRate( TempZone* pTempZone );
BOOL TempZone_checkRiseRate( TempZone* pTempZone );//	If temperature rise rate not achieved set alarm
void TempZone_checkDelayPeriod(TempZone* pTempZone);

DWORD RealToNominalOutput(DWORD real);
#endif

