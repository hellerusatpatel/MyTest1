//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: fluxheater.h
//
// Description: define file for fluxheaters
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 07-Jan-15  FJN  Declare FluxHeater_currentMonitorFailure and FluxHeater_heaterFailure
// 13-Mar-15  FJN  Declare FluxHeater_currentMonitorFailureHigh
//*****************************************************************************
#ifndef __EXHAUST_FLUX_HEATER_H__
#define __EXHAUST_FLUX_HEATER_H__

#include  "typedefdefine.h"
#include "tempzone.h"


typedef struct _FluxHeater_
{
	BOOL				output25Flag;	
	BOOL 				pidEnabled;  		// Auto or Manual mode - PID's active or not.
	BOOL 				alarmBandsEnabled;	// The pv is within deadband.
	BOOL				zoneActive;       	// Has the zone been turned off by the operator.
	BOOL				riseRateSetPointChange;
	BOOL				zoneInactiveToActiveTransition; 
	BOOL				deadBandEnableStatus;
	BOOL				m_bFluxHeaterEnabled;

	// Alarms and Warnings
	BOOL 				hiProcAlarmEnable;	// default to TRUE for all actives
	BOOL 				loProcAlarmEnable;	//	if alarm is not active do not process.
	BOOL				htAlarmEnable;
	BOOL 				ltAlarmEnable;
	BOOL 				htWarnEnable;
	BOOL				ltWarnEnable;
	int					m_iWarnings;
	DWORD				selfAckAlarmNo;			// the self acknowledging alarm number for warnings.
	DWORD				selfAckAlarmSecondNo;	// the self acknowledging alarm number for secondary warnings.(differing reset logic)
	DWORD				flxStartTime;


	// Alarms and Warnings values
	BOOL				inDeadBand;	
	// the high and low process alarms being absolute values, vs a relative offset from setpoint
	// needed to be changed from unsigned long (DWORD) to type long. Heller's requirements are 
	// that they need to be able to load negative numbers into the high and low process alarms.

	BOOL				directionalIOset;
	enum ZoneTriState		zoneAuto;

	LONG 				highProcess;			// The absolute high temp alarm
	LONG 				lowProcess;    			// The absoluter low temp alarm
	
	DWORD 				alarmHighTempOffset;    // setpoint + = high deviation alarm
	DWORD 				alarmLowTempOffset;     // setpoint - = low deviation alarm
	DWORD  				warnHighTempOffset;		// setpoint + = high deviation warning
	DWORD 				warnLowTempOffset;      // setpoint - = low deviation warning
	DWORD 				deadBandHighTempOffset; // setpoint + = high dboffset should be within warnings and alarms
	DWORD 				deadBandLowTempOffset;	// setpoint - = high dboffset should be within warnings and alarms
	
	LONG 				sp;	 					// setpoint
	LONG				coolSP;
	LONG				coolSPOffset;
	LONG 				pv;	            		// process variable
	
	const WORD		 	*pTcInput;				// a pointer to the value in the io tables.
	WORD		 		*pTPOoutput;   			// a pointer to the TPO output table.
	LONG				tpoOutput;
	LONG				tpoOutputCooling;
	LONG				onInitTPO;
	LONG				scTpoOutput;
	WORD 				minTpoOut;				// in the event of cooldown this will be overridden to 0
	WORD 				maxTpoOut;
	//boolean to lock out process loop until group delay period has elapsed
	//current logic for power up delay AFU WDT 04.26.01
	BOOL		m_bPowerUpDelayElapsed;
	BOOL		m_bDoRiseRateCheck;
	UINT		m_iFluxHeaterIndex;
	//The powerup group the fluxheater is associated with
	short		m_iGroupNo;
	//The last called powerup group
	short		m_iCurrentStartedGroup;
	BOOL		m_bAutocleanRecipeRunning;

	BOOL		m_bPowerUpSequencingCalled;
	DWORD		fluxheaterDelayTimer;
	BOOL		m_bStartupGroupHasFired;//Currently set to true only for autoclean job
	// alarm related variables
	DWORD		riseRateDelayStartTime;	// the time the rise rate period on a job change. 
	DWORD  		lastCheckTime; 		// a time in milliseconds at the beginning of the check
	DWORD  		currentTime;   		// for calculatin the elapsed time  - in milliseconds.
	DWORD  		dTime;		   		// the number of seconds have elapsed.
	LONG  		lastCheckTemp; 		// to determine the delta temp must know last time checked.

	WORD		dummyValue;			// in the event of trying to access the wrong zone
									// this will help to prevent a null pointer error.
	DWORD		currentJobNo;
	DWORD		previousJobNo;
	DWORD		heaterRiseRatePeriod10ths;
	UINT		minimumRiseDegrees;
	BOOL		m_bGen9;
	BOOL		m_bType2;
	BOOL		m_bRiseRateEnabled;
	UINT m_nScTPOOutput;
	PID pid;
	PID coolPID;					
	UINT m_nScInput;
	UINT m_nTPOoutput;
	UINT m_nTcInput;
	int m_iTestTPOPath;
	LONG coolOutput;
	DWORD period;
	DWORD mDwrdOutput;
	DWORD mCoolingOutputPercentX100;
	DWORD mCoolingOnInCooldown;
	DWORD coolOnOff;
	BOOL mbSequence;
	DWORD currentTooth;
	BOOL m_bSuspended;
} FluxHeater;

void FluxHeater_init(FluxHeater* pFluxHeater, UINT nIUDe);
void FluxHeater_currentMonitorFailureLow(FluxHeater* pFluxHeater, BOOL bOff);
void FluxHeater_currentMonitorFailureHigh(FluxHeater* pFluxHeater, BOOL bOff);
void FluxHeater_heaterFailure(FluxHeater* pFluxHeater, BOOL bOff);

void	FluxHeater_configureIO(FluxHeater* pFluxHeater);
void	FluxHeater_enableDeadBandRange(FluxHeater* pFluxHeater, BOOL dbFlag /*= TRUE*/ );
void	FluxHeater_processFluxheaterTime(FluxHeater* pFluxHeater);
void	FluxHeater_checkDelayPeriod(FluxHeater* pFluxHeater);
BOOL 	FluxHeater_checkRiseRate(FluxHeater* pFluxHeater);//	If temperature rise rate not achieved set alarm
void	FluxHeater_checkAlarmBands(FluxHeater* pFluxHeater);
void	FluxHeater_secondaryCheckAlarmBands(FluxHeater* pFluxHeater); //WDT 02.13.02		
void FluxHeater_setFluxHeaterEnable(FluxHeater* pFluxHeater, BOOL bEnable);
void FluxHeater_initTPOoutput(FluxHeater* pFluxHeater, UINT nIndex);
void FluxHeater_initTcInput(FluxHeater* pFluxHeater, UINT nIndex);
UINT FluxHeater_getTcInputIndex(FluxHeater* pFluxHeater);
UINT FluxHeater_getTPOoutputIndex(FluxHeater* pFluxHeater);
UINT FluxHeater_getScInputIndex(FluxHeater* pFluxHeater);
UINT FluxHeater_getScTOPOutputIndex(FluxHeater* pFluxHeater);
BOOL FluxHeater_isInDeadBand(FluxHeater* pFluxHeater);
void FluxHeater_sampleRiseRate( FluxHeater* pFluxHeater );

BOOL	FluxHeater_getOutput25Flag(FluxHeater* pFluxHeater);
int		FluxHeater_checkWarningState(FluxHeater* pFluxHeater);  //Used to check warning state for qui display
BOOL	FluxHeater_isPIDenabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isActive(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isHiProcAlarmEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isLohProcAlarmEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isHiDeviationAlarmEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isLoDeviationAlarmEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isHiDeviationWarningEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isLoDeviationWarningEnabled(FluxHeater* pFluxHeater);
BOOL	FluxHeater_isFluxHeaterEnabled(FluxHeater* pFluxHeater);
//allows the flux condensor to explicelty
void    FluxHeater_setIfInDeadBand(FluxHeater* pFluxHeater, BOOL bDBState);		
SHORT	FluxHeater_getZoneState(FluxHeater* pFluxHeater);

DWORD	FluxHeater_getHiProcTemp(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getLoProcTemp(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getAlarmHiTempOffset(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getAlarmLoTempOffset(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getWarnHiTempOffset(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getWarnLoTempOffset(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getDeadBandHiTempOffset(FluxHeater* pFluxHeater);
DWORD	FluxHeater_getDeadBandLoTempOffset	(FluxHeater* pFluxHeater);

DWORD FluxHeater_getTPOoutput(FluxHeater* pFluxHeater);
DWORD FluxHeater_getSetPoint(FluxHeater* pFluxHeater);
DWORD FluxHeater_getProcVar(FluxHeater* pFluxHeater);
const char * const FluxHeater_getName(FluxHeater* pFluxHeater);

BOOL FluxHeater_setActive(FluxHeater* pFluxHeater,  BOOL active );
BOOL FluxHeater_setPresent(FluxHeater* pFluxHeater, BOOL present );
void FluxHeater_setZoneAuto(FluxHeater* pFluxHeater, enum ZoneTriState autoState );

void FluxHeater_setPIDenable(FluxHeater* pFluxHeater, BOOL pe );
void FluxHeater_setAlarmsEnabled		(FluxHeater* pFluxHeater, BOOL state );
		
BOOL FluxHeater_setSetPoint			(FluxHeater* pFluxHeater, LONG  newSetPoint );
void FluxHeater_setUpDatePeriod		(FluxHeater* pFluxHeater, DWORD  newUpdatePeriod );
void FluxHeater_setMinTpoOut			(FluxHeater* pFluxHeater, DWORD  newMinTpoOut );
void FluxHeater_setMaxTpoOut			(FluxHeater* pFluxHeater, DWORD  newMaxTpoOut );
void FluxHeater_setTPOoutput			(FluxHeater* pFluxHeater, LONG   cTPOoutput );
void FluxHeater_set_pendTPOoutput			(FluxHeater* pFluxHeater, LONG   cTPOoutput );
void FluxHeater_setRiseRatePeriod		(FluxHeater* pFluxHeater, DWORD riseRatePeriodIn10ths );
void FluxHeater_setMinRiseDegreeCounts (FluxHeater* pFluxHeater, DWORD minRiseDegrees );
void FluxHeater_enableHiProcAlarm		(FluxHeater* pFluxHeater, BOOL enable );
void FluxHeater_enableLoProcAlarm		(FluxHeater* pFluxHeater, BOOL enable );
void FluxHeater_enableHiDeviationAlarm	(FluxHeater* pFluxHeater, BOOL enable );
void FluxHeater_enableLoDeviationAlarm	(FluxHeater* pFluxHeater, BOOL enable );
void FluxHeater_enableHiDeviationWarn	(FluxHeater* pFluxHeater, BOOL enable );
void FluxHeater_enableLoDeviationWarn	(FluxHeater* pFluxHeater, BOOL enable );

BOOL FluxHeater_setHiProcTemp			(FluxHeater* pFluxHeater, DWORD  highProcTemp );	// the absolute high alarm
BOOL FluxHeater_setLoProcTemp			(FluxHeater* pFluxHeater, DWORD  lowProcTemp );

BOOL FluxHeater_setAlarmHiTempOffset	(FluxHeater* pFluxHeater, DWORD  aHiTempOffset );
BOOL FluxHeater_setAlarmLoTempOffset	(FluxHeater* pFluxHeater, DWORD  aLoTempOffset );

BOOL FluxHeater_setWarnHiTempOffset	(FluxHeater* pFluxHeater, DWORD  wHiTempOffset );
BOOL FluxHeater_setWarnLoTempOffset	(FluxHeater* pFluxHeater, DWORD  wLoTempOffset );

BOOL FluxHeater_setDeadBandHiTempOffset(FluxHeater* pFluxHeater, DWORD  dbHiTempOffset );
BOOL FluxHeater_setDeadBandLoTempOffset(FluxHeater* pFluxHeater, DWORD  dbLoTempOffset );

void FluxHeater_calcPid(FluxHeater* pFluxHeater);
void FluxHeater_process(FluxHeater* pFluxHeater);
void FluxHeater_setPowerUpDelayFlag (FluxHeater* pFluxHeater, BOOL bPowerState);/*{m_bPowerUpDelayElapsed =bPowerState;}*/

// remove this 
BOOL FluxHeater_setProcVariable	(FluxHeater* pFluxHeater, DWORD newProcVar );

BOOL        FluxHeater_IsZoneInWarning(FluxHeater* pFluxHeater);
void        FluxHeater_checkSelfAcknowledgeAlarms(FluxHeater* pFluxHeater);
void		FluxHeater_setSequenceGroup(FluxHeater* pFluxHeater, UINT group);
UINT			FluxHeater_getSequenceGroup(FluxHeater* pFluxHeater);
void		FluxHeater_ActivateZones(FluxHeater* pFluxHeater, short groupNum, BOOL bIncrementGroupcount);
void		FluxHeater_DeActivateZones(FluxHeater* pFluxHeater);
void		FluxHeater_initializePowerUpSequencing(FluxHeater* pFluxHeater);
BOOL		FluxHeater_InDeadBandOrIsNotEnabled(FluxHeater* pFluxHeater);
BOOL		FluxHeater_IsFluxHeaterInAutoManualMode(FluxHeater* pFluxHeater);
SHORT		FluxHeater_isInDeviationAlarmZone(FluxHeater* pFluxHeater);
void		FluxHeater_startSequencingRequiresTimer(FluxHeater* pFluxHeater, BOOL bFluxCRecipe);
BOOL		FluxHeater_isInDeadBandRangeEnabled(FluxHeater* pFluxHeater); 
void		FluxHeater_setFluxheaterDelayTime(FluxHeater* pFluxHeater, DWORD dTime);
DWORD		FluxHeater_getSecProcVar(FluxHeater* pFluxHeater);
void		FluxHeater_setGen9(FluxHeater* pFluxHeater, BOOL bGen9);
void		FluxHeater_setType2(FluxHeater* pFluxHeater, BOOL bType2);
void		FluxHeater_testTPOPath(FluxHeater* pFluxHeater, int iTest);
void 		FluxHeater_setCoolSPOffset(FluxHeater* pFluxHeater, LONG nSP);
void 		FluxHeater_setCoolOnOff(FluxHeater* pFluxHeater, DWORD nOff);
void 		FluxHeater_CooldownSequenced(FluxHeater* pFluxHeater, DWORD nOff);
void 		FluxHeater_setCoolOutput(FluxHeater* pFluxHeater, DWORD output);
void 		FluxHeater_setCoolPeriod(FluxHeater* pFluxHeater, DWORD period);
void 		FluxHeater_coolingInCooldown(FluxHeater* pFluxHeater, DWORD on);
void 		FluxHeater_TPOToDigitalTime(FluxHeater* pFluxHeater);
void 		FluxHeater_pidSetPbCool(FluxHeater* pFluxHeater, DWORD proportionalBand);
void 		FluxHeater_pidSetTiCool(FluxHeater* pFluxHeater, DWORD dwTi);
void 		FluxHeater_pidSetTdCool(FluxHeater* pFluxHeater, DWORD dwTd);
void		FluxHeater_cooling(FluxHeater* pFluxHeater);
void		FluxHeater_blowerFailure(FluxHeater* pFluxHeater, BOOL bOFF);

#endif

