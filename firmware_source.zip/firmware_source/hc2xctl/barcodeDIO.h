/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2009, All Rights Reserved
                    Company Confidential

	File:			hellercommctl.cpp

	Description:	main interface for the activex control

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __BARCODE_H__
#define __BARCODE_H__

#include "typedefdefine.h"

#define NUM_DO 3
#define ECOFF 0
#define ECON 1
#define ECFLASH 2
typedef struct _bcio_
{
//private:

	char name[MaxNameLength+1];
	int	barcodeInput;
	BOOL bPreviousInputState;
	BOOL enabled;
	BOOL LTEnabled;
	int barcodeOutput;
	int boardEntered;
	DWORD timestampInputOn;
	DWORD allowTime;
	int doStates[NUM_DO];
	int doOutputs[NUM_DO];
	BOOL doEnabled[NUM_DO];
	DWORD scannedTime;

}BCIO;

void		BCIO_process	(BCIO* pBCIO);	
void		BCIO_init(BCIO* pBCIO);
void		BCIO_activateOutput(BCIO* pBCIO);
void		BCIO_setLTOption(BCIO* pBCIO, BOOL bEnable);

#endif
