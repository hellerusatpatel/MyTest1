//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: coolpipe.c
//
// Description: cool pipe logic processing
//
// This is a trade secret of Heller Industries, Inc. and is protected by copyright.
// All unauthorized uses prohibited.
//
// Edit History:
//
// 27-May-15  FJN  Created
//*****************************************************************************
#include <string.h>

#include "contain.h"

extern DbContainer g_dbContainer;

//------------------------------------------------------------------------------
// Function CoolPipe_init
//------------------------------------------------------------------------------
void CoolPipe_init(CoolPipe* pCoolPipe)
{
	pCoolPipe->enable = FALSE;
	pCoolPipe->analogInputTC1 = -1;
	pCoolPipe->analogInputTC2 = -1;
	pCoolPipe->tempTC1 = -1;
	pCoolPipe->tempDelta = -1;
	pCoolPipe->delay = -1;
	pCoolPipe->onsetTime = 0;
	printk("CoolPipe_init complete\n");
}

//------------------------------------------------------------------------------
// Function CoolPipe_process
//------------------------------------------------------------------------------
void CoolPipe_process(CoolPipe* pCoolPipe)
{
	WORD tempTC1;
	WORD tempTC2;
	int delta;
#ifdef DEBUG_COOLPIPE
	static DWORD lastPrint = 0;
#endif
	// if not enabled or missing parameters then return
	if (!pCoolPipe->enable ||
		pCoolPipe->analogInputTC1 == -1 ||
		pCoolPipe->analogInputTC2 == -1 ||
		pCoolPipe->tempTC1 == -1 ||
		pCoolPipe->tempDelta == -1 ||
		pCoolPipe->delay == -1)
	{
#ifdef DEBUG_COOLPIPE
		if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint) / 10 > 1)
		{
			lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("CoolPipe_process not enabled\n");
		}
#endif
		return;
	}

	// load TC1 temperature
	tempTC1 = *ANALOGIN_GetAt(&g_dbContainer.analogInDb, pCoolPipe->analogInputTC1);

	// if TC1 temperature less than threshold TC1 temperature then return
	if (tempTC1 < pCoolPipe->tempTC1)
	{
		pCoolPipe->onsetTime = 0;
#ifdef DEBUG_COOLPIPE
		if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint) / 10 > 1)
		{
			lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("CoolPipe_process tempTC1=%d threshold=%d not reached\n", tempTC1, pCoolPipe->tempTC1);
		}
#endif
		return;
	}

	// load TC2 temperature
	tempTC2 = *ANALOGIN_GetAt(&g_dbContainer.analogInDb, pCoolPipe->analogInputTC2);

	// compute TC1 - TC2 delta
	delta = tempTC1 - tempTC2;

	// if delta temperature greater than or equal to threshold delta temperature then return
	if (delta >= pCoolPipe->tempDelta)
	{
		pCoolPipe->onsetTime = 0;
#ifdef DEBUG_COOLPIPE
		if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint) / 10 > 1)
		{
			lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("CoolPipe_process tempTC1=%d tempTC2=%d delta=%d not reached\n", tempTC1, tempTC2, pCoolPipe->tempDelta);
		}
#endif
		return;
	}

	// here when warning conditions exists
	// if onset of warning condition then remember current time
	if (pCoolPipe->onsetTime == 0)
	{
		pCoolPipe->onsetTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
		return;
	}

	// if warning condition has persisted long enough to declare warning
	if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - pCoolPipe->onsetTime) / 10 >= pCoolPipe->delay)
	{
		AlarmQueue_addAlarm(&g_dbContainer.alarmQueueDb, WARNING, COOLPIPE_BLOCKAGE, 0);
#ifdef DEBUG_COOLPIPE
		if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint) / 10 > 1)
		{
			lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
			printk("CoolPipe_process tempTC1=%d tempTC2=%d delta=%d reached and warning issued\n", tempTC1, tempTC2, delta);
		}
#endif
	}
#ifdef DEBUG_COOLPIPE
	else if ((Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - lastPrint) / 10 > 1)
	{
		lastPrint = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
		printk("CoolPipe_process tempTC1=%d tempTC2=%d delta=%d reached and warning timing %d\n",
			tempTC1, tempTC2, delta, pCoolPipe->delay - (Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer) - pCoolPipe->onsetTime) / 10);
	}
#endif
}
