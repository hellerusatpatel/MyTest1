/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// contain.h
#ifndef __DBCONTAINER_H__
#define __DBCONTAINER_H__

#include "hc1xcomm.h"
#include "digitio.h"
#include "intercommtransferclass.h"
#include "recipetrigger.h"
#include "alarm.h"
#include "belt.h"
#include "oven.h"
#include "tempzone.h"
#include "tempzs.h"
#include "timer.h"
#include "rails.h"
#include "nitrogen.h"
#include "litetowr.h"
#include "belt.h"
#include "lube.h"
#include "maintenance.h"
#include "boards.h"
#include "bdrop.h"
#include "error.h"
#include "fluxfilt.h"
#include "cbs.h"
#include "oxygen.h"
#include "smema.h"
#include "hzblower.h"
#include "flasher.h"
#include "fluxheater.h"
#include "fluxcondensor.h"
#include "newboardq.h"	// added by classview
#include "newboardqNoLP.h"
#include "purge.h"
#include "boardEvents.h"
#include "barcodeDIO.h"
#include "transferTable.h"
#include "massController.h"
#include "carrierEvents.h"
#include "coolpipe.h"

//----------------------------------------------------
//
//	struct SECONDARY_CONFIGURATION - configuration and control parameters to send/manage secondary controller
//
//----------------------------------------------------
struct SECONDARY_CONFIGURATION 
{
	struct CONFIGURATION config;
	BOOL bWaitingForOffset;
	BOOL bConfigure;
	BOOL bSecondaryActive;
};

typedef struct _DbContainer_
{

//public:
	Belt belt[MaxBelts];
	struct SECONDARY_CONFIGURATION	slaveConfig;
	Timer					elapseTimer;
	Hc1xComm				hc1xComm;
	InterCommTransferClass	CommTransferClass;
	recipeTrigger			recipetrigger;
	AlarmQueue 				alarmQueueDb;
	Oven 					ovenDb;
	DIN 					digitalInDb;
	DOUT 					digitalOutDb;
	ANALOGIN 	    		analogInDb;
	ANALOGOUT 				analogOutDb;
	Rails					railsDb;
	Belts 	    			beltsDb;
	CoolPipe				coolPipeDb;
	newBoardQueue_NoLP			boardQ0_NoLP;
	newBoardQueue_NoLP			boardQ1_NoLP;
	newBoardQueue_NoLP			boardQ2_NoLP;
	newBoardQueue_NoLP			boardQ3_NoLP;

	newBoardQueue			boardQ0;
	newBoardQueue			boardQ1;
	newBoardQueue			boardQ2;
	newBoardQueue			boardQ3;

	BoardDropLB				boardDropLB0;
	BoardDropLB				boardDropLB1;
	TempZones 				tempZonesDb;
	Nitrogen				nitrogen;
	LightTower				lightTower;
	Lube					lube1;
    Lube                    lube2;
	FluxFilter				fluxFilter;
	Maintenance				maintenance;
	MassController			masscontroller;
	CBS						cbs;
	GlobalBlower			globalBlower;
	HeatZoneBlowers		    heatZoneBlowers;
	AnalogFan				analogFan;
	Oxygen					oxygen;

	SMEMA					smema1;
	SMEMA					smema2;
	SMEMA					smema3;
	SMEMA					smema4;

	Flasher					flasherSPChange;
	Flasher					flasherReady;			// empty oven
	Flasher					flasherReadyBoards;		// oven has boards running through it
	Flasher					flasherWarning;
	Flasher					flasherAlarmCooldown;
	Flasher					flasherEstopCooldown;

	FluxHeater				fluxHeater;
	FluxHeater				fluxHeater1;
	FluxHeater				fluxHeater2;
	FluxHeater				fluxHeater3;
	FluxHeater				fluxHeater4;

	FluxCondensor			fluxCondensor;
	ErrorContainer		    error;
	Purge					purge;
	unsigned   long			m_jiffies;
	BCIO					barcodeDio;
	BoardEntryEvents		m_boardEvents;

	LotProcessing			m_lotProcessing;

} DbContainer;

void DbContainer_slaveConfigure( DbContainer* pDbContainer, BOOL bStart );
void DbContainer_init(DbContainer* pDbc );
void DbContainer_configureIO( DbContainer* pDbContainer );

FluxHeater* DbContainer_getCorrectFluxheater(DbContainer* pDbc, UINT iWhichFluxheater);


#endif

