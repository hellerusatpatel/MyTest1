/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999-2014, All Rights Reserved
                    Company Confidential

	File:			smema.c

	Description:	processing logic for setting smema outputs

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __SMEMA_H__
#define __SMEMA_H__

#include "typedefdefine.h"

extern unsigned char uc9851Lock1;
extern unsigned char uc9851Lock2;
extern unsigned char uc9851Lock3;
extern unsigned char uc9851Lock4;
/***************************************************************************
 *
 *	GLOBAL DEFINES
 *
 **************************************************************************/

/* DEFINES FOR SMEMA STATUS BIT PACKING */
#define SMEMA_LIGHTTOWER_STATUS_BIT		0x00000001
#define SMEMA_HOLD_STATUS_BIT			0x00000002
#define SMEMA1_BOARD_BACKUP_STATUS_BIT	0x00000004
#define SMEMA1_DBPASTENTR_STATUS_BIT	0x00000008
#define SMEMA1_UILOTFLAG_STATUS_BIT		0x00000010
#define SMEMA1_9851HOLD_STATUS_BIT		0x00000020
#define SMEMA1_BOARDQSTART_STATUS_BIT	0x00000040
#define SMEMA1_BOARDENTR_STATUS_BIT		0x00000080
#define SMEMA1_BOARDQPEND_STATUS_BIT	0x00000100

#define SMEMA2_DBPASTENTR_STATUS_BIT	0x00000200
#define SMEMA2_UILOTFLAG_STATUS_BIT		0x00000400
#define SMEMA2_9851HOLD_STATUS_BIT		0x00000800
#define SMEMA2_BOARDQSTART_STATUS_BIT	0x00001000
#define SMEMA2_BOARDENTR_STATUS_BIT		0x00002000
#define SMEMA2_BOARDQPEND_STATUS_BIT	0x00004000
#define SMEMA2_BOARD_BACKUP_STATUS_BIT	0x00008000

#define SMEMA3_DBPASTENTR_STATUS_BIT	0x00010000
#define SMEMA3_UILOTFLAG_STATUS_BIT		0x00020000
#define SMEMA3_9851HOLD_STATUS_BIT		0x00040000
#define SMEMA3_BOARDQSTART_STATUS_BIT	0x00080000
#define SMEMA3_BOARDENTR_STATUS_BIT		0x00100000
#define SMEMA3_BOARDQPEND_STATUS_BIT	0x00200000
#define SMEMA3_BOARD_BACKUP_STATUS_BIT	0x00400000

#define SMEMA4_DBPASTENTR_STATUS_BIT	0x00800000
#define SMEMA4_UILOTFLAG_STATUS_BIT		0x01000000
#define SMEMA4_9851HOLD_STATUS_BIT		0x02000000
#define SMEMA4_BOARDQSTART_STATUS_BIT	0x04000000
#define SMEMA4_BOARDENTR_STATUS_BIT		0x08000000
#define SMEMA4_BOARDQPEND_STATUS_BIT	0x10000000
#define SMEMA4_BOARD_BACKUP_STATUS_BIT	0x20000000
//Second Light Tower Support	
#define SMEMA_LIGHTTOWER2_STATUS_BIT	0x40000000

#define SMEMA_DEADBAND_CNT				5
#define SMEMA_300MS						3
#define SMEMA_100MS						1
#define SMEMA_200MS						2


enum SMEMA_Interface { NO_SMEMA = 0, SMEMA_II, TDK, FUJI, SEAGATE, SMEMA_9851 };

typedef struct _SMEMA_
{
//private:
	char	name[MaxNameLength+1];
	
	enum SMEMA_Interface SMEMA_Type;
	UINT noOfBelts;
	UINT smemaID; // lane number, 0..3
	DWORD deadBandCounts;
	DWORD boardDetectTimeEntrance;
	DWORD boardDetectTimeExit;
	DWORD boardLastDetectPositionEntrance;
	DWORD boardLastDetectPositionExit;
	DWORD currentBeltPositionEntrance;
	DWORD currentBeltPositionExit;
	DWORD elapsedPositionEntrance;
	DWORD elapsedPositionExit;
	BOOL pastDeadBandEntrance;
	BOOL pastDeadBandExit;
	BOOL ioConfigComplete;
	BOOL *pBoardEnteringOven;
	BOOL *pBoardLeavingOven;
	DWORD exitDeadBandCounts;
	UINT uiLotFlag;
	BOOL bBoardHasEntered;
	BOOL m_bSmema9851HoldDueToSensor;
	DWORD m_CureOption;
	BOOL beltOffTimeRead;
	DWORD beltOffTime;
	BOOL m_bCureSuspend;
	DWORD m_ExitAvailTime;
	BOOL m_bExitOn;
	int m_iMachineBStatus;
	BOOL m_bTestForB;
	BOOL m_bAllowNext;
	BOOL m_bBoardLeft;
	DWORD dwdSquareTime;
	BOOL squareTimeTaken;
	BOOL m_bAllowNextPend;
	DWORD m_smemaOnInputDist;
	DWORD m_smemaOnMinDist;
	BOOL m_bBarcodeControlled;
	BOOL m_bBarcodeAllow;
	BOOL m_bBarcodeAllowAgain;
	DWORD dwrdNewRecipeTime;
	BOOL m_bLaneHold;

	// For the BostonScientific SMEMA modifications
	BOOL	m_bMaxBoardsPerLaneEnable;
	DWORD	m_nMaxBoardsPerLaneCount;
	DWORD	m_bNoBoardAnimation;

	//For the Mult-Lane Barcode Application modifications
	BOOL	m_bIsIndividualFree;
	BOOL	m_bIndvAllow;

	//MES 9851 to allow the smema to remain on after the board leading edge is recorded
	BOOL m_imesBoardEntering;
	char cSecgemEntry;
	char cSecgemControl;
} SMEMA;

void SMEMA_init(SMEMA* pSMEMA, UCHAR smemaIDNo);

enum SMEMA_Interface SMEMA_getSMEMAtype( SMEMA* pSMEMA );
void SMEMA_setType( SMEMA* pSMEMA, enum SMEMA_Interface newType );
void SMEMA_setDeadBandCounts(SMEMA* pSMEMA, DWORD SMEMAdeadBandCounts );
void SMEMA_process(SMEMA* pSMEMA);
void SMEMA_SMEMA_II_process(SMEMA* pSMEMA);
void SMEMA_SMEMA_9851_LightTower1_process(SMEMA* pSMEMA);
void SMEMA_SMEMA_9851_LightTower2_process(SMEMA* pSMEMA);
void SMEMA_SMEMA_9851_process(SMEMA* pSMEMA);
void SMEMA_TDK_process(SMEMA* pSMEMA);
void SMEMA_FUJI_process(SMEMA* pSMEMA);
void SMEMA_SEAGATE_process(SMEMA* pSMEMA);
void SMEMA_checkForPastDeadBandEntrance(SMEMA* pSMEMA);
void SMEMA_checkForPastDeadBandExit(SMEMA* pSMEMA);
void SMEMA_setIOConfig(SMEMA* pSMEMA);
void SMEMA_setSmemaExitLength(SMEMA* pSMEMA, DWORD exitDeadbandCounts);
void SMEMA_LotDisable(SMEMA* pSMEMA);
void SMEMA_LotEnable(SMEMA* pSMEMA);
void SMEMA_exitCureSetting(SMEMA* pSMEMA, DWORD setting);
void SMEMA_informGUIofBeltStop(SMEMA* pSMEMA);
void SMEMA_squareWave(SMEMA* pSMEMA);
int SMEMA_bSmemaEnabled(SMEMA* pSMEMA);
void SMEMA_bcScanned(SMEMA* pSMEMA);
void SMEMA_setLaneCount(SMEMA* pSMEMA, DWORD dwrdLC);
void SMEMA_clearBarcode();
void SMEMA_entry(SMEMA* pSMEMA);

BOOL SMEMA_ProcessMaxBoardsPerLane(SMEMA* pSMEMA);
void SMEMA_SetMaxBoardsPerLaneEnable(SMEMA* pSMEMA, BOOL bEnable);
void SMEMA_SetMaxBoardsPerLaneSetCount(SMEMA* pSMEMA, DWORD dwCount);
void SMEMA_SetNoBoardAnimationEnable(SMEMA* pSMEMA, BOOL bEnable);
void SMEMA_SetLaneHold(SMEMA* pSMEMA, BOOL bHold);

void SMEMA_GetLightTowerStatus(BOOL* pbLT1Green, BOOL* pbLT2Green);
void SMEMA_MESSmemaVariable(int iEntry, int iIndex);
void SMEMA_MESActivate(int iActive, int iIndex);
void SMEMA_MESAllowed(int iAllowed, int iIndex);

void SMEMA_holdAllow();
int SMEMA_EntryAllowed(SMEMA* pSMEMA);
void Break9851Lock(UINT smemaID);
void SMEMA_SecsGemEntryOption(SMEMA* pSMEMA,char iSetting);
void SMEMA_SecsGemSetting(SMEMA* pSMEMA, char onOff);
char SMEMA_SecsgemEntryAllowed(SMEMA* pSMEMA);

#endif
