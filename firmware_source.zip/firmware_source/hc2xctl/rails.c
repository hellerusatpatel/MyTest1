//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: rails.c
//
// Description: master class for the rails
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 06-Apr-15  FJN  Correct Rails_Process_JogCycle for rail 3 homing sensing
// 06-Apr-15  FJN  Correct Rails_Process_JogCycle for rails 2 and 3 timeout
// 08-Apr-15  FJN  Zero m_uintUpdownPhase for each JOG_RAILxPRESET complete
//*****************************************************************************
#include "contain.h"
#include "typedefdefine.h"
#include "rails.h"
#include "belt.h"
#include "newboardq.h"
#include "newboardqNoLP.h"
#include "digitio.h"
#include "oven.h"
#include "rail.h"
#include "alarm.h"
#include "timer.h"
#include "digitio.h"
#include "cbs.h"

#define CBS0 0
#define CBS1 1

extern DbContainer g_dbContainer;

AlarmQueue * alarmQueueDb;
Timer				* timer;
DIN					* digitalInputs;
DOUT				* digitalOutputs;
ANALOGIN		    * analogInputs;
Oven				* ovenDb;
Belts				* beltsDb;
newBoardQueue_NoLP	    * boardQ0_NoLP;
newBoardQueue_NoLP	    * boardQ1_NoLP;
newBoardQueue_NoLP	    * boardQ2_NoLP;
newBoardQueue_NoLP	    * boardQ3_NoLP;

newBoardQueue	    * boardQ0;
newBoardQueue	    * boardQ1;
newBoardQueue	    * boardQ2;
newBoardQueue	    * boardQ3;

CBS					 * cbs;

#define JOG_PHASE_RAIL0HOME 0
#define JOG_PHASE_RAIL0HOMING 1
#define JOG_PHASE_RAIL1HOME 2
#define JOG_PHASE_RAIL1HOMING 3
#define JOG_PHASE_RAIL2HOME 4
#define JOG_PHASE_RAIL2HOMING 5
#define JOG_PHASE_RAIL3HOME 6
#define JOG_PHASE_RAIL3HOMING 7
#define JOG_PHASE_RAIL0PRESET 8
#define JOG_PHASE_RAIL0HOME2 9
#define JOG_PHASE_RAIL0HOMING2 10
#define JOG_PHASE_RAIL1PRESET 11
#define JOG_PHASE_RAIL1HOME2 12
#define JOG_PHASE_RAIL1HOMING2 13
#define JOG_PHASE_RAIL2PRESET 14
#define JOG_PHASE_RAIL2HOME2 15
#define JOG_PHASE_RAIL2HOMING2 16
#define JOG_PHASE_RAIL3PRESET 17
#define JOG_PHASE_RAIL3HOME2 18
#define JOG_PHASE_RAIL3HOMING2 19
#define JOG_PHASE_DONE 20

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_init
			
			initialized the rail variables

 RETURNS:   void
------------------------------------------------------------------------*/
void Rails_init(Rails* pRails)
{
	int i;

	i = 0;

	if( NULL != pRails )
	{
		pRails->configurationOption	= 0;
		pRails->allRailsAtPreset = FALSE;
	
		Rail_init(&(pRails->rail0), RAIL0);
		Rail_init(&(pRails->rail1), RAIL1);
		Rail_init(&(pRails->rail2), RAIL2);
		Rail_init(&(pRails->rail3), RAIL3);
		Rail_init(&(pRails->badRail), BADRAIL);
		pRails->m_bFourRails = FALSE;
		pRails->m_bPreventMoveFromCooldown  = FALSE;
		pRails->newRailPositions = FALSE;
		pRails->mTimerCount  = 0;
		pRails->bAllowMovement = FALSE;
		pRails->currentRail = 0;
		pRails->m_bSkipJobStartupRoutine = FALSE;
		pRails->m_bSoftwareDisengaged = FALSE;
		pRails->m_bRailsHaveHomed = FALSE;
		pRails->m_bForceHome = FALSE;
		pRails->railControlVector = SOFTWARE_CON;

		timer = &( g_dbContainer.elapseTimer );
		digitalInputs = &( g_dbContainer.digitalInDb );
		digitalOutputs = &( g_dbContainer.digitalOutDb	);
		analogInputs = &( g_dbContainer.analogInDb );
		ovenDb = &( g_dbContainer.ovenDb );
		beltsDb = &( g_dbContainer.beltsDb );
		boardQ0_NoLP = &( g_dbContainer.boardQ0_NoLP );
		boardQ1_NoLP = &( g_dbContainer.boardQ1_NoLP );
		boardQ2_NoLP = &( g_dbContainer.boardQ2_NoLP );
		boardQ3_NoLP = &( g_dbContainer.boardQ3_NoLP );

		boardQ0 = &( g_dbContainer.boardQ0 );
		boardQ1 = &( g_dbContainer.boardQ1 );
		boardQ2 = &( g_dbContainer.boardQ2 );
		boardQ3 = &( g_dbContainer.boardQ3 );

		alarmQueueDb = &( g_dbContainer.alarmQueueDb);
		cbs = &(g_dbContainer.cbs);
		pRails->m_bRailsHaveHomed = FALSE;
		pRails->m_iInputForHardware = IDI_FLUX_FILTER_DOOR_CLOSED; 
		Rails_resetTimeDelay(pRails);
		for(i = 0; i < MaxRails; i++)
		{
			pRails->m_bRailNotPreseting[i] = FALSE;
			pRails->pulseCounts[i] = 0;
			pRails->controledUD[i] = 10;
			pRails->indRailState[i] = E_STOP_STATE;
		}
		pRails->m_dwrdOurStartupGroup = 1;
		pRails->controledUD[RAIL0] = 0; //the first ud is always keyed to the first rail
		pRails->m_bJogPossible = FALSE;
		pRails->m_bJogOn = FALSE;
		pRails->m_bJobSwitchover = FALSE;
		pRails->m_uintUpdownPhase = 0;
		pRails->udPhaseTimer = 0;
		pRails->m_bSwitchJogFlag = FALSE;
		pRails->selfAckAlarmNo = 0;
		pRails->selfAckAlarmNo2 = 0;
		pRails->jobNoForEx = 0;
		pRails->startJogTime = 0;
		pRails->m_bNeedsHome = FALSE;
		pRails->m_bStartupDisabled = FALSE;
		pRails->m_dwrdTheCurrentGroup = 1;
		pRails->railSuspended = FALSE;
		pRails->m_bRailHardwarePreProcess = FALSE;
		pRails->noActiveRails = 0;
		pRails->mbTestReturn = FALSE;
		pRails->bHardwarePause = FALSE;
	}

	return;
}


//*****************************************************************************
// Rail & Rails_operator[]( DWORD railNo )
//
// Abstract:
// Array access operator used by Comm Control.
// 
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
Rail* Rails_GetRail(Rails* pRails, DWORD railNo )
{
	Rail *pRail = &(pRails->badRail);
	PARAM_CHECK_RETURN( pRails, "Rails_GetRail", 0);

	switch ( railNo )
	{
		case 0:
			pRail = &(pRails->rail0);
			break;
		case 1:
			pRail = &(pRails->rail1);
			break;
		case 2:
			pRail = &(pRails->rail2);
			break;
		case 3:
			pRail = &(pRails->rail3);
			break;
		default: 
			pRail = &(pRails->badRail);
			break;
	}
	return pRail;
}

//*****************************************************************************
// BOOL Rails_timeDelay()
//
// Abstract:
// A time delay of two seconds is required when sequencing the rails home or
// moving the rails into position. 
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
BOOL Rails_timeDelay(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_timeDelay", 0);
	if ( pRails->timeDelayElapsed == FALSE )
	{										 
		if ( (Timer_getCurrentTime10ths(timer) - pRails->startDelayTime10ths ) >= RAIL_SEQUENCE_DELAY_10THS )
		{
			pRails->timeDelayElapsed = TRUE;
		}
	}

	return pRails->timeDelayElapsed;
}
//*****************************************************************************
// void Rails_resetTimeDelay()
// 
// Abstract:
// Reset the time delay so that sequencing of rails cannot occur above the
// two second rate requested by Heller.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rails_resetTimeDelay(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_resetTimeDelay");
	pRails->timeDelayElapsed = FALSE;
	pRails->startDelayTime10ths = Timer_getCurrentTime10ths(timer);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_setPosition
			
	 		The number of encoder pulses from the home offset that the rail is to be
			positioned. Assuming the current configuration observed at Heller 8/23/1998
			a lead screw with a pitch of 10 threads per inch and an encoder with a 
			resolution of 400 pulses/rev. As observed the encoder was off the gear motor
			with a 1.7 rotational increase resulting in 400 pulses/1.7 rev or 235 pulses
			per rev. To move 5 inches would result in a preset position of 5 * 235 or
			1175 counts.
 
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_setPosition(Rails* pRails, DWORD railNo, DWORD presetPosition, BOOL bHomeIndicator  )
{
	PARAM_CHECK( pRails, "Rails_setPosition");
	Rail* pRail = NULL;
	DWORD dwrdTempJob = Oven_getTempJobNo(ovenDb);
	Rails_testJobTime(pRails);
	pRails->m_bStartupDisabled = FALSE;
	
	if ( railNo < MaxRails )
	{
		if(pRails->bRWC&&!bHomeIndicator)
		{
			if(!pRails->firstRecipeLoad[railNo])
			{
				pRails->railWidthChanged[railNo] = TRUE;
			}
			else
			{
				pRails->firstRecipeLoad[railNo] = FALSE;
		}
		}

		if( pRails->jobNo == dwrdTempJob)
		{
			pRail = Rails_GetRail(pRails, railNo);
			Rail_setPositionCounts(pRail, presetPosition, FALSE, FALSE );
		}
		else
		{
			pRail = Rails_GetRail(pRails, railNo);
			Rail_setPositionCounts(pRail, presetPosition, TRUE, FALSE);
		}

		Rails_GetRail(pRails, railNo);
		pRail->bUsingRealPosition = TRUE;
	}

	pRails->bAllowMovement = TRUE;
	pRails->mTimerCount = 0;
	if(!bHomeIndicator)
	{
		if(!pRails->m_bJogOn)
		{
			pRails->currentRail = MaxRails - 1;
		}
		pRails->railState = PRESET_STATE;	
	}
	return;
}

//*****************************************************************************
// DWORD Rails_getPositionCounts( DWORD railNo )
// 
// Abstract:
// Returns the relative position from the home position in counts.
//
// Programmer: Steven Young
// Date: 09/01/1998 											    
//*****************************************************************************
DWORD Rails_getPositionCounts(Rails* pRails, DWORD railNo )
{
	Rail* pRail = Rails_GetRail(pRails, railNo);
	PARAM_CHECK_RETURN( pRails, "Rails_getPositionCounts", 0);
	return Rail_getPositionCounts(pRail);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_setPosition
			
			Move the specified rail in an increasing encoder count 
			direction.
 
 RETURNS:   void
------------------------------------------------------------------------*/
void Rails_increment(Rails* pRails, DWORD railNo )
{
	Rail* pRail;
	DWORD nBoardsInOven0;
	DWORD nBoardsInOven1;
	DWORD nBoardsInOven2;
	DWORD nBoardsInOven3;

	pRail = NULL;
	nBoardsInOven0 = 0;
	nBoardsInOven1 = 0;
	nBoardsInOven2 = 0;
	nBoardsInOven3 = 0;

	if( NULL != pRails )
	{
		pRails->railState = MANUAL_STATE;
		if( FALSE == g_bLotProcessingEnable )
		{
			nBoardsInOven0 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ0_NoLP, 0);
			nBoardsInOven1 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ1_NoLP, 0);
			nBoardsInOven2 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ2_NoLP, 0);
			nBoardsInOven3 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ3_NoLP, 0);
		}
		else
		{
			nBoardsInOven0 = newBoardQueue_getBoardsInOvenCount(boardQ0, 0);
			nBoardsInOven1 = newBoardQueue_getBoardsInOvenCount(boardQ1, 0);
			nBoardsInOven2 = newBoardQueue_getBoardsInOvenCount(boardQ2, 0);
			nBoardsInOven3 = newBoardQueue_getBoardsInOvenCount(boardQ3, 0);
		}

		if ( !nBoardsInOven0 && !nBoardsInOven1 &&
			 !nBoardsInOven2 && !nBoardsInOven3 )
		{
		
			pRails->indRailState[railNo] = MANUAL_STATE;
			pRail = Rails_GetRail(pRails, railNo);
			Rail_increment(pRail);
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_decrement

			Move the specified rail in an decreasing encoder count 
			direction.

 RETURNS:   void
------------------------------------------------------------------------*/
void Rails_decrement(Rails* pRails, DWORD railNo )
{
	Rail* pRail;
	DWORD nBoardsInOven0;
	DWORD nBoardsInOven1;
	DWORD nBoardsInOven2;
	DWORD nBoardsInOven3;

	pRail = NULL;
	nBoardsInOven0 = 0;
	nBoardsInOven1 = 0;
	nBoardsInOven2 = 0;
	nBoardsInOven3 = 0;

	if( NULL != pRails )
	{
		pRails->railState = MANUAL_STATE;
		if( FALSE == g_bLotProcessingEnable )
		{
			nBoardsInOven0 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ0_NoLP, 0);
			nBoardsInOven1 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ1_NoLP, 0);
			nBoardsInOven2 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ2_NoLP, 0);
			nBoardsInOven3 = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ3_NoLP, 0);
		}
		else
		{
			nBoardsInOven0 = newBoardQueue_getBoardsInOvenCount(boardQ0, 0);
			nBoardsInOven1 = newBoardQueue_getBoardsInOvenCount(boardQ1, 0);
			nBoardsInOven2 = newBoardQueue_getBoardsInOvenCount(boardQ2, 0);
			nBoardsInOven3 = newBoardQueue_getBoardsInOvenCount(boardQ3, 0);
		}

		if ( !nBoardsInOven0 && !nBoardsInOven1 &&
			 !nBoardsInOven2 && !nBoardsInOven3 )
		{
			pRails->indRailState[railNo] = MANUAL_STATE;
			pRail = Rails_GetRail(pRails, railNo);
			Rail_decrement(pRail);
		}
	}

	return;
}

//*****************************************************************************
// void Rails_resetIncDec( DWORD railNo )
// 
// Abstract:
// Stop the rail from moving in manual by disabling the flags that allow the
// motors to run.
//
// Programmer: Steven Young
// Date: 02/25/2000
//*****************************************************************************
void Rails_resetIncDec(Rails* pRails, DWORD railNo )
{
	Rail* pRail = Rails_GetRail(pRails, railNo);
	PARAM_CHECK( pRails, "Rails_resetIncDec");
	Rail_resetIncDec(pRail);
}

//*****************************************************************************
// void Rails_allRailsHome()
//
// Abstract:
// When a new job is loaded the rails need to be sequenced home prior to setting
// to the preset position. Start by sequencing the low number rails in order
// that are defined as being home in. Upon completion do the home out rails 
// starting with the highest numbered rails first. There is a two second delay
// between the sequencing of successive rails whether going home or to the 
// preset position.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_allRailsHome
			
			When a new job is loaded the rails need to be sequenced home prior to setting
			to the preset position. Start by sequencing the low number rails in order
			that are defined as being home in. Upon completion do the home out rails 
			starting with the highest numbered rails first. There is a two second delay
			between the sequencing of successive rails whether going home or to the 
			preset position.

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_allRailsHome(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_allRailsHome");
  
	UINT LocalCurrentRail = 0;
	UINT iRailTimerLoop = 0;
    enum HomeDirection LocalCurrentHomedir;
	Rail* pRail = NULL;
	BOOL bHomeAchieved = FALSE;

    LocalCurrentRail = pRails->currentRail;
    LocalCurrentHomedir = pRails->currentHomeDirection;

    pRails->bAllowMovement = TRUE;
    pRails->mTimerCount = 0;

    for(iRailTimerLoop = 0; iRailTimerLoop < MaxRails; iRailTimerLoop++)
    {
		pRails->indRailState[iRailTimerLoop] = HOME_STATE;
		pRail = Rails_GetRail(pRails, iRailTimerLoop);
	
		pRail->bUsingRealPosition = TRUE;
		Rail_resetPresetStableTimer(pRail);
		pRail->presetShouldBeStable = FALSE;
		pRail->presetAchieved = FALSE;
		pRail->bDontAllowNewStopFactor = FALSE;
		pRail->backOffHomeFlag = FALSE;
		Rail_setOvershootFactor(pRail, pRail->eInitialCorrectionFactor);
		if(iRailTimerLoop != LocalCurrentRail)
		{
			Rail_addSlowRailWarning(pRail, TRUE);			
		}
    }

	if ( pRails->currentRail < MaxRails )
	{
		pRail = Rails_GetRail(pRails, pRails->currentRail);
		if ( Rail_getHomeDirection(pRail) != pRails->currentHomeDirection)
		{
			pRails->currentHomeDirection = Rail_getHomeDirection(pRail);
			Rails_resetTimeDelay(pRails);
		}
		Rail_goHome(pRail);
		bHomeAchieved = Rail_getHomeAchieved(pRail);
		if ( bHomeAchieved )
		{
			pRail->backupForFirstRun = TRUE;
			pRails->currentRail++;
		}
	}
	return;
}


//*****************************************************************************
// void Rails_checkAllRailsHome()
//
// Abstract:
// A rail is considered home when it has been designated to go home and has
// reached the limit switch. If the rail is not configured in then it will
// indicate that it is in a home state. 
// 
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rails_checkAllRailsHome(Rails* pRails)
{
	UINT lcv;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_checkAllRailsHome");

	pRails->allRailsAtHome = TRUE;
	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( Rail_getHomeAchieved(pRail) == FALSE )
		{
			Rails_resetTimeDelay(pRails);
			pRails->allRailsAtHome = FALSE;
			//printk("all home false num %d\n", pRail->railIdNo);	
		}
	}

	// at this point if all the rails are home therefore it is now time to preset.
	if ( pRails->allRailsAtHome == TRUE && Rails_timeDelay(pRails) == TRUE)
	{
//Explitely disable all rails at this point so they hunt from high to low
		for ( lcv = 0; lcv < MaxRails; lcv++ )
		{
			pRail = Rails_GetRail(pRails, lcv);
			Rail_stop(pRail);
		}
		//printk("line 475/n");
		pRails->currentRail = MaxRails - 1;
		pRails->railState = PRESET_STATE;
		// when presetting rails always sequence from the highest numbered rails 
		// to the lowest. This is independent of home direction.

		//Initialize preset timer
		lcv = pRails->currentRail;
		pRail = Rails_GetRail(pRails, lcv);
		while(!Rail_getActive(pRail) && lcv > 0)
		{
			lcv--;
			pRail = Rails_GetRail(pRails, lcv);
		};
		pRail = Rails_GetRail(pRails, lcv);
		Rail_addSlowRailWarning(pRail, TRUE);

		Rails_resetTimeDelay(pRails);
	}

	if(pRails->allRailsAtHome)
		pRails->m_bRailsHaveHomed = TRUE;
}

//*****************************************************************************
// void Rails_presetRails()
//
// Abstract:
// A rail is considered preset when it has achieved the preset position.
// If the rail is not configured in then it will indicate that it is in a home state. 
// 
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rails_presetRails(Rails* pRails)
{
	// loop through the rails that are inactive otherwise it could be 6 seconds 
	// before the single rail system will actually start moving.

	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_presetRails");
//	printk("preset rails");
	pRail = Rails_GetRail(pRails, pRails->currentRail);
//	printk("current rail %d\n", pRails->currentRail);
	while ( Rail_getActive(pRail) == FALSE && pRails->currentRail < MaxRails)
	{
		(pRails->currentRail)--;
//	printk("current rail dec %d\n", pRails->currentRail);
		pRail = Rails_GetRail(pRails, pRails->currentRail);
	}

	if ( !pRails->m_bRailNotPreseting[pRails->currentRail] )
	{
		if ( pRails->currentRail < MaxRails )
		{
			pRail = Rails_GetRail(pRails, pRails->currentRail);
//testtesttest
	//		printk("preset line 518\n");
			Rail_preset(pRail);

			if ( Rail_getPresetAchieved(pRail) )
			{
			// when presetting, independent of home direction, always preset
			// from highest numbered to lowest numbered rails. 
				(pRails->currentRail)--;
				pRail = Rails_GetRail(pRails, pRails->currentRail);
				Rail_addSlowRailWarning(pRail, TRUE);
			}
		}
	}
	else
	{
		(pRails->currentRail)--;
	}
}

//*****************************************************************************
// void Rails_checkAllRailsAtPreset()
// 
// Abstract:
// Check that all of the rails have achieved preset. An individual rail knows 
// if it has reached preset condition and will reply with TRUE if the preset
// has been reached, otherwise FALSE will be returned. Upon all rails reaching
// the preset state the rail state now goes to MANUAL mode for control by the
// buttons only.
// 
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rails_checkAllRailsAtPreset(Rails* pRails)
{
	UINT lcv;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_checkAllRailsAtPreset");

	pRails->allRailsAtPreset = TRUE;

	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( Rail_getPresetAchieved(pRail) == FALSE )
		{
			pRails->allRailsAtPreset = FALSE;
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_process
			
			main execution loop for the rail master class

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_process(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_process");
	// whenever there is a job change and the job is not COOLDOWN send
	// the rails to the home position.
	UINT lcv = 0;
	BOOL doFlag = TRUE;
	unsigned int i = 0;
	unsigned int k = 0;
	pRails->m_bRailHardwarePreProcess = FALSE;
	Rail* pRail = NULL;
	int iReturn = 100;
	DWORD dwrdOvenJob = Oven_getJob(ovenDb);
	BOOL bEstop = Oven_isEStopSet(ovenDb);
	UINT uintJogCycle = 0;

	pRails->m_dwrdTheCurrentGroup = Oven_getStartupGroup(ovenDb);
	if( ( pRails->railControlVector == HARDWARE_CON ) || ( pRails->bHardwarePause==TRUE ) )  //hardware mode, acknowledge any pending alarms/warnings
	{
		iReturn = Rails_process_hardware(pRails);

	}
	if(iReturn)
	{
		if( (pRails->m_dwrdTheCurrentGroup < pRails->m_dwrdOurStartupGroup) ||
			pRails->m_bStartupDisabled)
		{
			for(k = 0; k < MaxRails; k++)
			{
				pRail = Rails_GetRail(pRails, k);
				pRail->m_bNotSequenced = TRUE;
				if( ( pRails->indRailState[k] == MANUAL_STATE ) && dwrdOvenJob && 
					(bEstop == FALSE ) )
				{
					 Rail_manual(pRail);
					 Rail_process(pRail);
				}
				else
				{
					Rail_resetIncDec(pRail);
					Rail_disableOutput(pRail);
				}
				pRails->railSuspended = TRUE;
				Rail_addSlowRailWarning(pRail, TRUE);//reset warning timer during sequencing	
			}
		}
		else
		{
			for(k = 0; k < MaxRails; k++)
			{
				pRail = Rails_GetRail(pRails, k);
				pRail->m_bNotSequenced = FALSE;
			}
			if(dwrdOvenJob != pRails->jobNoForEx)
			{
				pRails->m_bJogOn = FALSE;
				Rails_setRailHuntValues(pRails, FALSE);
				if(pRails->m_bSwitchJogFlag)
				{
					pRails->currentRail = 0;
					pRails->m_bJogOn = TRUE;
					Rails_SetJogOn(pRails, FALSE);
					if(pRails->m_bJogOn && pRails->m_bJogPossible)
					{
						pRails->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAILS_JOG_INIT, 0); 
					}
				}
					pRails->jobNoForEx = dwrdOvenJob;	
			}
			uintJogCycle = Rails_Process_JogCycle(pRails);
			if(!uintJogCycle)
			{
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRails->selfAckAlarmNo);

				pRails->m_uintJogPhase = 0;

				if( ( dwrdOvenJob != pRails->jobNo ) && pRails->m_bSkipJobStartupRoutine )
				{
					pRails->m_bSkipJobStartupRoutine = FALSE;
					doFlag = FALSE;
				}
				if ( ( dwrdOvenJob != pRails->jobNo ) && doFlag)
				{
					//if not moving to/from cooldown and the rails width have not changed do not go home
					if( (dwrdOvenJob != COOLDOWN) && (pRails->jobNo != COOLDOWN) )
					{
						doFlag = FALSE;
						for(i = 0; i < MaxRails; i++) 
						{
							if(pRails->railWidthChanged[i] == TRUE)
							{
								doFlag = TRUE;
								pRails->railWidthChanged[i] = FALSE;
							}
						}
					}
					if(!pRails->jobNo)//when moving from cooldown the above code will not be executed and the
					//rail width changed flag will be incorrect.  This causes a problem with the second recipe load
					{
						for(i = 0; i < MaxRails; i++) 
						{			
							pRails->railWidthChanged[i] = FALSE;
							pRails->m_bRailNotPreseting[i] = FALSE;
						}
					}
				}
				if( (pRails->jobNo != COOLDOWN) && 
					( (pRails->jobNo != dwrdOvenJob) && (dwrdOvenJob != COOLDOWN) ) )
				{
				if(pRails->m_bNeedsHome == TRUE)
				{
					doFlag = TRUE;
				}
			}
			if(pRails->m_bPreventMoveFromCooldown && !pRails->jobNo)//if we do not want to move rails when emerging from cooldown
			{
				doFlag = FALSE;
			}
				if(pRails->jobNo != dwrdOvenJob)
				{
					pRails->m_bNeedsHome = FALSE;
				}
				if ( ( (dwrdOvenJob != pRails->jobNo) && doFlag) || pRails->m_bForceHome )//m_bForceHome, application flagged us to go home
				{
					pRails->m_bForceHome = FALSE;
					pRails->jobNo = dwrdOvenJob;
					Rails_resetTimeDelay(pRails);	
					pRails->railState = HOME_STATE;
					pRails->railSuspended = FALSE;
					pRails->currentHomeDirection = HomeIN;
					pRails->currentRail = 0;
					for ( lcv = 0; lcv < MaxRails; lcv++ )
					{
						pRail = Rails_GetRail(pRails, lcv);
						Rail_setHomeAchieved(pRail, FALSE);
						Rail_stop(pRail);
						Rail_setNewJob(pRail);
						//we have disabled rail movement except for setpoint changes, reenabling here to allow home execution
						Rail_setOutputEnableFlag(pRail, TRUE);
						Rail_addSlowRailWarning(pRail, TRUE);
						Rail_clearMovementWarning(pRail);
						Rail_addSlowRailWarning(pRail, TRUE);
					}
				}
				else if(dwrdOvenJob != pRails->jobNo)
				{
						pRails->jobNo = dwrdOvenJob;
				}
	
				// send the rails to their respective home positions, sequencing from low to high
				// on home in rails and high to low on home out rails.
				if ( ( pRails->railState == HOME_STATE ) && ( dwrdOvenJob != COOLDOWN ) )
				{			
					Rails_allRailsHome(pRails);
					Rails_checkAllRailsHome(pRails);
				}
				//if homestate has been achieved test to see if any setpoint changes are queued and make them
				if(pRails->newRailPositions && pRails->railState != HOME_STATE)
				{
					for (lcv = 0; lcv < pRails->noActiveRails; lcv++ )
					{
						if(pRails->moveThisRail[lcv] )
						{
							Rails_setPosition(pRails, lcv, pRails->presetPositionBuffer[lcv], pRails->homeIndicatorBuffer[lcv]);
							pRails->moveThisRail[lcv] = FALSE;
						}
					}
					pRails->newRailPositions = FALSE;
				}
				// preset all rails to position starting with the highest numbered rails and working towards
				// the lowest with out any regard to home in or home out classification. 
				if ( pRails->railState == PRESET_STATE && dwrdOvenJob != COOLDOWN )
				{
					if(pRails->currentRail >= MaxRails)
					{
						pRails->currentRail = MaxRails - 1;
					}
					if(pRails->bAllowMovement)
					{
						if(!pRails->m_bRailsHaveHomed)
						{
							pRails->railState = HOME_STATE;
							pRails->m_bForceHome = TRUE;
							for(i = 0; i < MaxRails; i++)
							{
								pRails->m_bRailNotPreseting[i] = FALSE;
							}
						}
						else
						{
							Rails_presetRails(pRails);
							pRails->railSuspended = FALSE;
						}
					}
					Rails_checkAllRailsAtPreset(pRails);
					if(Rails_checkForMadePresetAndHuntFailure(pRails))
					{
						Rails_timeOutMovementCheck(pRails);
					}
					else
					{
						pRails->mTimerCount = 0;
					}
				}

				//added new routine, manual mode rails do not home or go preset so here
				//we will implicitely set them to manual mode.  WDT 09/17/2
				if( pRails->railState == MANUAL_STATE && dwrdOvenJob != COOLDOWN)
				{
					Rails_manualRails(pRails);
				}
		
				for ( lcv = 0; lcv < MaxRails; lcv++ )
				{
					pRail = Rails_GetRail(pRails, lcv);
					Rail_process(pRail);
				}
			}
		}
	}
	// This is the most important check so do it last to make sure outputs do not get turned on.
	// If an E-STOP or any other alarm occurs stop the movement of the rails. 
	if ( ( bEstop == TRUE ) || ( dwrdOvenJob == COOLDOWN ) )
	{
		pRails->railState = E_STOP_STATE;
		for ( lcv = 0; lcv < MaxRails; lcv++ )
		{
			pRails->indRailState[lcv] = E_STOP_STATE;
			pRail = Rails_GetRail(pRails, lcv);
			Rail_disableOutput(pRail);
		}
	}
	return;
}

//*****************************************************************************
// BOOL Rails_setConfiguration( DWORD configOption )
//
// Abstract:
// The rail configuration as described in the header file. By applying varying
// wiring methods of the rails the configurations become less crucial, especially
// since the rails are allowed to collide.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
BOOL Rails_setConfiguration(Rails* pRails, DWORD configOption )
{	
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pRails, "Rails_setConfiguration", 0);
	
	if ( configOption < RailCombinations )
	{
		pRails->configurationOption = configOption;
		switch ( pRails->configurationOption )
		{
			case 0:
				pRails->noActiveRails = 0;
				break;
			case 1:
				pRails->noActiveRails = 1;
				break;
			case 2:
				pRails->noActiveRails = 2;
				break;
			case 3:
				pRails->noActiveRails = 2;
				break;
			case 4:
				pRails->noActiveRails = 3;
				break;
			case 5:
				pRails->noActiveRails = 4;
				break;
			case 6:
				pRails->noActiveRails = 3;
				break;
			case 7:
				pRails->noActiveRails = 2;
				break;
			case 8:
				pRails->noActiveRails = 3;
				break;
			case 9:
				pRails->noActiveRails = 4;
				break;
			case 10:
				pRails->noActiveRails = 3;
				break;
			case 11:
				pRails->noActiveRails = 2;
				break;
			case 12:
				pRails->noActiveRails = 3;
				break;
			case 13:
				pRails->noActiveRails = 4;
				break;
			case 14:
				pRails->noActiveRails = 3;
				break;

			case 15:
				pRails->noActiveRails = 3;
				break;
		}
		status = TRUE;
	}
	switch ( pRails->noActiveRails )
	{
		case 0:
			Rail_setActive(Rails_GetRail(pRails, 0), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 1), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 2), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 3), FALSE);
			break;

		case 1:
			Rail_setActive(Rails_GetRail(pRails, 0), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 1), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 2), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 3), FALSE);
			break;

		case 2:
			Rail_setActive(Rails_GetRail(pRails, 0), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 1), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 2), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 3), FALSE);
			break;

		case 3:
			Rail_setActive(Rails_GetRail(pRails, 0), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 1), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 2), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 3), FALSE);
			break;

		case 4:
			Rail_setActive(Rails_GetRail(pRails, 0), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 1), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 2), TRUE);
			Rail_setActive(Rails_GetRail(pRails, 3), TRUE);
			pRails->m_bFourRails = TRUE;
			break;

		default:
			Rail_setActive(Rails_GetRail(pRails, 0), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 1), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 2), FALSE);
			Rail_setActive(Rails_GetRail(pRails, 3), FALSE);
	}
	g_dbContainer.belt[0].beltIOConfigured = FALSE;
	g_dbContainer.belt[1].beltIOConfigured = FALSE;	
	return status;
}

//*****************************************************************************
// BOOL Rails_allRailsPreset( void )
//
// Abstract:
// Programmer: Steven Young
// Date: 08/25/1999
//*****************************************************************************
BOOL Rails_allRailsPreset(Rails* pRails, int lane_index)
{
	PARAM_CHECK_RETURN( pRails, "Rails_allRailsPreset", 0);

	BOOL state = TRUE;
	int lcv;
	Rail* pRail = NULL;

	//WDT 12/11/01 changed the variable int lcv< portion of for statement from maxrails
	//Tushar reported a similiar problem to Vicor, it is possible that an oven could test
	//inactive rails.  The system should not test anything that is not present physically on the 
	//machine.
	for ( lcv = 0; lcv < (int) pRails->noActiveRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( pRail && 
			((pRail->m_laneIndex == lane_index)||(lane_index==0) ))//lane index 0 indicate shared test, should always test all 4 lanes
		{

			if( Rail_isPresetStable(pRail) == FALSE )
			{
				pRails->indRailState[lcv] = PRESET_STATE;
				state = FALSE;
			}
		}
	}

	//wdt 09/18/01 to correct lighttower warning state Vicor trip 
	if ( pRails->noActiveRails == 0 )
	{
		state = TRUE;
	}
	else
	{
		if ( pRails->m_bStartupDisabled )
		{
			state = FALSE;
		}
	}

	if ( (pRails->railState == HOME_STATE) ||
		(pRails->railSuspended && pRails->m_bJogPossible) )
	{
		state = FALSE;
	}

	return state;
}
//*****************************************************************************
// BOOL Rails_allRailsPresetSharedDual( void )
//
// Abstract:
// Programmer: Steven Young
// Date: 08/25/1999
//*****************************************************************************
BOOL Rails_allRailsPresetSharedDual(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_allRailsPresetSharedDual", 0);

	BOOL state = TRUE;
	int lcv;
	Rail* pRail = NULL;

	//WDT 12/11/01 changed the variable int lcv< portion of for statement from maxrails
	//Tushar reported a similiar problem to Vicor, it is possible that an oven could test
	//inactive rails.  The system should not test anything that is not present physically on the 
	//machine.
	for ( lcv = 0; lcv < (int) pRails->noActiveRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( pRail && 
			((pRail->m_laneIndex == 0) ))//lane index 0 indicate shared test
		{

			if( Rail_isPresetStable(pRail) == FALSE )
			{
				pRails->indRailState[lcv] = PRESET_STATE;
				state = FALSE;
			}
		}
	}

	//wdt 09/18/01 to correct lighttower warning state Vicor trip 
	if ( pRails->noActiveRails == 0 )
	{
		state = TRUE;
	}
	else
	{
		if ( pRails->m_bStartupDisabled )
		{
			state = FALSE;
		}
	}

	if ( (pRails->railState == HOME_STATE) ||
		(pRails->railSuspended && pRails->m_bJogPossible) )
	{
		state = FALSE;
	}

	return state;
}
////////////////////////////////////////////////////////////////////////////////////
//*****************************************************************************
// BOOL Rails_inWarningRailsPreset( void )
//
//wraps the out of position in a has sp changed.  to light the warning outputs
// Abstract:
// Programmer: W Tree
// Date: 08/25/2011
//*****************************************************************************
BOOL Rails_inWarningRailsPreset(Rails* pRails, int lane_index)
{
	PARAM_CHECK_RETURN( pRails, "Rails_inWarningRailsPreset", 0);

	BOOL state = TRUE;
	int lcv = 0;
	Rail* pRail = NULL;
	BOOL bRailPresetStable = FALSE;
	BOOL bRailSPChanged = FALSE;
	//WDT 12/11/01 changed the variable int lcv< portion of for statement from maxrails
	//Tushar reported a similiar problem to Vicor, it is possible that an oven could test
	//inactive rails.  The system should not test anything that is not present physically on the 
	//machine.
	for ( lcv = 0; lcv < (int) pRails->noActiveRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( pRail && 
			((pRail->m_laneIndex == lane_index)||(lane_index==0) ))//lane index 0 indicate shared test, should always test all 4 lanes
		{
			bRailPresetStable = Rail_isPresetStable(pRail);
			bRailSPChanged = Rail_getSPChanged(pRail);

			if( (bRailPresetStable == FALSE)  && (bRailSPChanged == FALSE))
			{
				pRails->indRailState[lcv] = PRESET_STATE;
				state = FALSE;
			}
		}
	}

	BOOL bRailsInHardwareControl =  Rails_railsInHardwareMode(pRails);//Hardware mode should allow smema/light tower green

	if ( pRails->noActiveRails == 0 || bRailsInHardwareControl == TRUE)
	{
		state = TRUE;
	}
	else
	{
		if ( pRails->m_bStartupDisabled )
		{
			state = FALSE;
		}
		if ( (pRails->railState == HOME_STATE) ||
			(pRails->railSuspended && pRails->m_bJogPossible) )
		{
			state = FALSE;
		}	
	}


	
	return state;
}
//*****************************************************************************
// BOOL Rails_inWarningRailsPresetSharedDual( void )
//
// Abstract:
//wraps the out of position in a has sp changed.  to light the warning outputs
// Programmer: W Tree
// Date: 08/25/2011
//*****************************************************************************
BOOL Rails_inWarningRailsPresetSharedDual(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_allRailsPresetSharedDual", 0);

	BOOL state = TRUE;
	int lcv = 0;
	Rail* pRail = NULL;
	BOOL bRailPresetStable = FALSE;
	BOOL bRailSPChanged = FALSE;

	//WDT 12/11/01 changed the variable int lcv< portion of for statement from maxrails
	//Tushar reported a similiar problem to Vicor, it is possible that an oven could test
	//inactive rails.  The system should not test anything that is not present physically on the 
	//machine.
	for ( lcv = 0; lcv < (int) pRails->noActiveRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if ( pRail && 
			((pRail->m_laneIndex == 0) ))//lane index 0 indicate shared test
		{
			bRailPresetStable = Rail_isPresetStable(pRail);
			bRailSPChanged = Rail_getSPChanged(pRail);
			if( (bRailPresetStable == FALSE) && (bRailSPChanged == FALSE))
			{
				pRails->indRailState[lcv] = PRESET_STATE;
				state = FALSE;
			}
		}
	}

	//wdt 09/18/01 to correct lighttower warning state Vicor trip 
	if ( pRails->noActiveRails == 0 )
	{
		state = TRUE;
	}
	else
	{
		if ( pRails->m_bStartupDisabled )
		{
			state = FALSE;
		}
	}

	if ( (pRails->railState == HOME_STATE) ||
		(pRails->railSuspended && pRails->m_bJogPossible) )
	{
		state = FALSE;
	}
	return state;
}

//////////////////////////////////////////////////////////////////////////////////////
//sets a boolean array to false this cannot be done in the constructor do to
//the nature of the vxd
void Rails_IntializeEdgeholdBools(Rails* pRails)
{
	int i;
	PARAM_CHECK( pRails, "Rails_IntializeEdgeholdBools");

	for( i = 0; i < MaxRails; i++)
	{
		pRails->railWidthChanged[i] = FALSE;
		pRails->firstRecipeLoad[i] = TRUE; //Currently the rails function ok with one exception
//when the first recipe is loaded the railWidthChangedFlag will be set to true.  When
//another recipe is loaded the rails will position regardless of user input.  By adding a
//secondary flag the railWidthChangedFlag will not be set on the first pass  wdt 05.20.02
	}
}

//a control variable is needed so the railwidthchanged flags are not set when
//a setpoint change is made while a recipe is running in the unlikely event that
//the user then loads a recipe with the equivlent rail setpoints
void Rails_EnableTest(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_EnableTest");
	pRails->bRWC = TRUE;
}

void Rails_DisableTest(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_DisableTest");
	pRails->bRWC = FALSE;
}

void Rails_setOpFromCoolRailMovement(Rails* pRails, BOOL bMove)
{
	PARAM_CHECK( pRails, "Rails_setOpFromCoolRailMovement");
	pRails->m_bPreventMoveFromCooldown = bMove;
}

//*****************************************************************************
// BOOL Rails_queueSetPosition(DWORD railNo, Dword presetPosition, BOOL bHomeIndicator)
//
// Abstract:  Currently if the rails are homing a setpoint will abort the home,
// or if the first rail is set rail 2 will not home.  To prevent this I'm adding this
// function to move setpoints to an intermediate variable.  A process loop modification 
// will then call setPosition once all rails are home or all rails report that they should
// be at preset.
// Programmer: Wallace Tree
// Date: 05/24/02

//This should allow the rails to move to SP after homing without introducing any instability
//*****************************************************************************

void Rails_queueSetPosition(Rails* pRails, DWORD railNo, DWORD presetPosition, BOOL bHomeIndicator)
{
	PARAM_CHECK( pRails, "Rails_queueSetPosition");
	Rail* pRail;
	//printk("railNo %d, presetPosition %d home state %d\n", railNo, presetPosition,pRails->railState);
	if(pRails->m_bJogOn)
	{
		bHomeIndicator = FALSE;
		Rails_setPosition(pRails, railNo, presetPosition, bHomeIndicator);
	}
	if(pRails->railState == HOME_STATE)
	{
		pRail = Rails_GetRail(pRails, railNo);
		pRail->presetPosition = presetPosition;
		//pRails->newRailPositions = TRUE;
		//pRails->moveThisRail[railNo] = TRUE;
		//Rail_addSlowRailWarning(pRail, TRUE);
		//Rail_clearMovementWarning(pRail);
		//pRails->presetPositionBuffer[railNo] = presetPosition;
		//pRails->homeIndicatorBuffer[railNo]=bHomeIndicator;
	}
	else
	{
		pRails->moveThisRail[railNo] = FALSE; //if a move is pending cancel
		Rails_setPosition(pRails, railNo, presetPosition, bHomeIndicator);
	}
}

//*****************************************************************************
// BOOL Rails_arrayInitialization( )
//
// Abstract:  Initializing arrays in the constructor using the : method is not 
// allowed, adding the function to set any arrays or variables at the point of
// system file variable 		pRails->m_bNeedsHome = FALSE;initialization
// Programmer: Wallace Tree
// Date: 05/24/02
//*****************************************************************************

void Rails_arrayInitialization(Rails* pRails)
{
	int lcv = 0;
	PARAM_CHECK( pRails, "Rails_arrayInitialization");

	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRails->moveThisRail[lcv] = FALSE; //no stored setpoint
		pRails->presetPositionBuffer[lcv] = 0; 
		pRails->homeIndicatorBuffer[lcv] = FALSE;
	}	
}

void Rails_timeOutMovementCheck(Rails* pRails)
{
	UINT lcv;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_timeOutMovementCheck");

	if(pRails->mTimerCount < 51)
		pRails->mTimerCount++;
	if(pRails->mTimerCount > 50)
	{
		pRails->bAllowMovement = FALSE;
		for ( lcv = 0; lcv < MaxRails; lcv++ )
		{
			pRail = Rails_GetRail(pRails, lcv);
			pRail->presetShouldBeStable = TRUE;
		}		
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_bypassHomeAndPresetRoutines
			
			set rails to terminal condition, set flag to skip normal job startup routine

  RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_bypassHomeAndPresetRoutines(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_bypassHomeAndPresetRoutines");

	UINT lcv = 0;
	Rail* pRail = NULL;

	pRails->railState = PRESET_STATE;
	pRails->railSuspended = FALSE;

	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		Rail_stop(pRail);
		pRail->presetShouldBeStable = TRUE;
		pRail->bUsingRealPosition = FALSE;
	}
	pRails->bAllowMovement = FALSE;
	pRails->m_bSkipJobStartupRoutine = TRUE;
	return;
}

BOOL Rails_checkForMadePresetAndHuntFailure(Rails* pRails)
{
	UINT lcv;
	Rail* pRail;
	PARAM_CHECK_RETURN( pRails, "Rails_checkForMadePresetAndHuntFailure", 0);

	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		if(!pRails->m_bRailNotPreseting[lcv])
			if(!Rail_isPresetStable(pRail) && !pRail->presetAttemptFailed)
				return FALSE;		 
	}
	return TRUE;
}

void Rails_manualRails(Rails* pRails)
{
	UINT lcv;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_manualRails");

	for ( lcv = 0; lcv < MaxRails; lcv++ )
	{
		pRail = Rails_GetRail(pRails, lcv);
		Rail_manual(pRail);
	}
}

void Rails_setHardwareOption(Rails* pRails, UINT railControlType)
{
	PARAM_CHECK( pRails, "Rails_setHardwareOption");

	if(railControlType) //hardware mode available
	{
		pRails->railControlVector = HARDWARE_CON;
	}
	else
	{
		pRails->railControlVector = SOFTWARE_CON;
	}
}

/////////////////////////////////////////////////////////////////////////////////////
//
//process_hardware()
//
//Will return true if default processing should occur, false otherwise
//The function disables alarms, clears warnings, and sets enable/disable of individual rails
/////////////////////////////////////////////////////////////////////////////////////
BOOL Rails_process_hardware(Rails* pRails)
{
	int lcv;
	Rail* pRail;
	PARAM_CHECK_RETURN( pRails, "Rails_process_hardware", 0);

	if( *DIN_GetAt(digitalInputs, pRails->m_iInputForHardware) || pRails->bHardwarePause==TRUE)  //Hardware mode engaged
	{
		if(!pRails->m_bSoftwareDisengaged) //we don't need to continously execute this code
		{
			Rails_clearWarnings(pRails);
			pRails->m_bSoftwareDisengaged = TRUE;
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, MANUAL_RAIL_MODE_STARTED, 0 );
		}
//we may need to continually suspend operations
		Rails_suspendRailOps(pRails, TRUE);
		for ( lcv = 0; lcv < MaxRails; lcv++ )//allow the rails to monitor position
		{
			pRail = Rails_GetRail(pRails, lcv);
			Rail_process_hardware(pRail);

//we'll clear all pending moves
			if(pRails->moveThisRail[lcv] )
			{
				Rails_setPosition(pRails, lcv, pRails->presetPositionBuffer[lcv], pRails->homeIndicatorBuffer[lcv]);
				pRails->moveThisRail[lcv] = FALSE;
			}

			pRails->m_bRailNotPreseting[lcv] = TRUE;
			pRails->newRailPositions = FALSE;
		}
		
		pRails->jobNo = Oven_getJob(ovenDb); //no additional process, we need to track if the job changes
		return FALSE;
	}
	else
	{
		if(pRails->m_bSoftwareDisengaged)//we are transitioning to software mode, homeword bound!
		{
			pRails->m_bSoftwareDisengaged = FALSE;
			Rails_suspendRailOps(pRails, FALSE);
			AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, MANUAL_RAIL_MODE_EXITED, 0);
		}
		return TRUE;
	}
	return FALSE;
}

void Rails_suspendRailOps(Rails* pRails, BOOL bSuspendRails)
{
	int iRails;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_suspendRailOps");

	pRails->railState =	E_STOP_STATE;
	for(iRails =0; iRails < (MaxRails - 1); iRails++)
	{
		//printk("indRailState stop ln 1264\n");
		pRails->indRailState[iRails] = E_STOP_STATE;
		pRail = Rails_GetRail(pRails, iRails);
		pRail->bHardwareMode = bSuspendRails;
		if(pRail->railActive==TRUE)
		{
			Rail_setDirectionFlag(pRail, pRail->storedDirection);
			if(bSuspendRails)
				Rail_stop(pRail);
		}
	}
}

void Rails_clearWarnings(Rails* pRails)
{
	int iRails;
	Rail* pRail;
	PARAM_CHECK( pRails, "Rails_clearWarnings");

	for(iRails =0; iRails < (MaxRails - 1); iRails++)
	{
		pRail = Rails_GetRail(pRails, iRails);
		Rail_clearWarnings(pRail);
	}
}

UINT Rails_returnHardwareRunning(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_returnHardwareRunning", 0);
	if(pRails->m_bRailHardwarePreProcess||pRails->m_bSoftwareDisengaged)
		return (UINT)TRUE;
	else
		return (UINT)FALSE;	
//	return (UINT)pRails->m_bSoftwareDisengaged;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_sendRailsHome
			
			Control function for rails when switched from manual to software (auto)
			mode.  A 0 will send them home, 1 will send all to preset, 2 will flag all to not move, 3-6 will preset
			that rail
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_sendRailsHome(Rails* pRails, UINT presetOption)
{
	PARAM_CHECK( pRails, "Rails_sendRailsHome");

	int iRails = 0;
	int iIndex = 0;
	int i = 0;
	Rail* pRail = NULL;
	Rail* pRailLoop = NULL; //used to iterate through rails without having to change the active rail
	BOOL bActive = FALSE;

	switch(presetOption)
	{
	case 0:
	
		pRails->railState = HOME_STATE;
		pRails->m_bForceHome = TRUE;
		for( i = 0; i < MaxRails; i++)
		{
			pRails->moveThisRail[i] = FALSE;//we may need to clear queued moves at this point
			pRail = Rails_GetRail(pRails, iRails);
			Rail_addSlowRailWarning(pRail, TRUE);
			pRails->m_bRailNotPreseting[i] = FALSE;
		}
		break;
	
	case 1:
		pRails->m_bNeedsHome = TRUE;
		for(iRails = 0; iRails < MaxRails; iRails++)
		{
			pRails->m_bRailNotPreseting[iRails] = FALSE;
		}
		if(pRails->railState == HOME_STATE)
		{
			pRails->railState = PRESET_STATE;
		}
		for(iRails =0; iRails < (MaxRails - 1); iRails++)
		{
			pRails->moveThisRail[iRails] = FALSE;//we may need to clear queued moves at this point
			pRail = Rails_GetRail(pRails, iRails);
	
			Rail_setPositionCounts(pRail,  Rail_getPresetPosition(pRail), FALSE, TRUE );
			pRail->bUsingRealPosition = TRUE;
		}
		break;

	case 2:
		for(iRails = 0; iRails < MaxRails; iRails++)
		{
			pRail = Rails_GetRail(pRails, iRails);
				bActive = Rail_getActive(pRail); 
				if ( (bActive == TRUE) && (pRail->controlType != 0) )
			{
				pRail = Rails_GetRail(pRails, iRails);
				pRail->railState = Rail_STOP;
				pRails->moveThisRail[iRails] = FALSE;//we may need to clear queued moves at this point
				pRails->m_bRailNotPreseting[iRails] = TRUE;
				pRails->newRailPositions = FALSE;
			}
		}
		break;

	case 3:
	case 4:
	case 5:
	case 6:
		iIndex = presetOption - 3;
		pRail = Rails_GetRail(pRails, iIndex);
			bActive = Rail_getActive(pRail); 
			if( (bActive == TRUE) && (pRail->controlType != 0) )
		{
			if(!pRails->m_bRailsHaveHomed)
			{
	

				pRails->railState =	HOME_STATE;
				pRails->m_bForceHome = TRUE;
				for(i = 0; i < MaxRails; i++)
				{
					pRailLoop = Rails_GetRail(pRails, i);
						if(pRailLoop)
						{
							bActive = Rail_getActive(pRailLoop); 
	
							if ( bActive )
							{
								pRails->m_bRailNotPreseting[i] = FALSE;
								Rail_addSlowRailWarning(pRailLoop, TRUE);
							}
						}
					}
				}
			else
			{
				pRails->m_bRailNotPreseting[iIndex] = FALSE;
				Rail_setPositionCounts(pRail, Rail_getPresetPosition(pRail), FALSE, TRUE );
				pRails->railState = PRESET_STATE;
			}
		}
		break;
	case 7:
	case 8:
	case 9:
	case 10:
		iIndex = presetOption - 7;
		pRail = Rails_GetRail(pRails, iIndex);
			bActive = Rail_getActive(pRail); 
	
			if( (bActive == TRUE) && (pRail->controlType != 0) )
		{
			pRail->AssignSP = TRUE;
		}
		break;
	case 11:
		pRails->m_bStartupDisabled = TRUE;
		break;
	
	case 12:
		pRails->m_bStartupDisabled = FALSE;
		break;

	case 13:
		pRails->m_bRailsHaveHomed = FALSE;
		break;
	default:
		break;
	}
	return;
}

UINT Rails_returnRailsHaveHomed(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_returnRailsHaveHomed", 0);
	return (UINT)pRails->m_bRailsHaveHomed;
}

UINT Rails_getNoOfActiveRails(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_getNoOfActiveRails", 0);
	return pRails->noActiveRails; 
}

void Rails_setRailStateToPresetForJobLoad(Rails* pRails)
{
	PARAM_CHECK( pRails, "Rails_setRailStateToPresetForJobLoad");
	pRails->railState = PRESET_STATE;
}

BOOL Rails_returnRailTerminalPosition(Rails* pRails)
{
	PARAM_CHECK_RETURN( pRails, "Rails_returnRailTerminalPosition", 0);
	return !pRails->bAllowMovement;
}

void Rails_setRailInputForHardware(Rails* pRails, UINT uintIndex)
{
	PARAM_CHECK( pRails, "Rails_setRailInputForHardware");
	pRails->m_iInputForHardware = uintIndex;
}
void Rails_SetStartupGroup(Rails* pRails, DWORD nGroup)
{
	PARAM_CHECK(pRails, "Rails_SetStartupGroup");
	pRails->m_dwrdOurStartupGroup = nGroup;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_GetSequenceGroup


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD Rails_GetSequenceGroup(Rails* pRails)
{
	DWORD dwrdReturn = 0;
	PARAM_CHECK_RETURN(pRails, "Rails_GetSequenceGroup",0); 
	if(pRails->noActiveRails)
	{
		dwrdReturn = pRails->m_dwrdOurStartupGroup;
	}
	return dwrdReturn;
}

void Rails_SetJogOn(Rails* pRails, UINT bOn)
{
	PARAM_CHECK(pRails, "Rails_SetJobOn");
	DWORD lcv;
	Rail* pRail;
//	printk("switching jog flag %d\n", pRails->m_bSwitchJogFlag); 
	pRails->m_bSwitchJogFlag = bOn;
	if(bOn==TRUE)
	{
		pRails->startJogTime = Timer_getCurrentTime10ths(timer); 
		for(lcv = 0; lcv < MaxRails; lcv++)
		{			
			pRail = Rails_GetRail(pRails, lcv);
			Rail_addSlowRailWarning(pRail, TRUE);
		}
	}
//	printk("after switching jog flag %d\n", pRails->m_bSwitchJogFlag); 
}

void Rails_ExerciseCBS2onRail(Rails* pRails, DWORD dwrdRailN)
{
	PARAM_CHECK(pRails, "Rails_ExerciseCBS2onRail");
	if(dwrdRailN < MaxRails)
	{
		pRails->controledUD[dwrdRailN] = 1;
	}
}

void Rails_railJogOptionPossible(Rails* pRails, UINT bPossible)
{
	PARAM_CHECK(pRails, "Rails_railJogOptionPossible");
	pRails->m_bJogPossible = bPossible;
//	printk("jog option poss %d:\n", pRails->m_bJogPossible);
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_Process_JogCycle

			jog moves the rails to home and out repeatively to break the accumulated
			flux
			Rev-4

			Finalized approach:

			Setup Wizard:

				- Add check box for "Rail Exercise Option"
				- Add drop down box to select rail# for 2nd CBS
				- Generate default "Rail-Exercise.job" when option is selected
				- Rail startup group

			Operation:
				Display a message to load "Rail-Exercise.job" Yes / No
				- When loading new recipe
				- When loading a cooldown mode.

			Do not display message when cooldown is because of alarm condition.
			Add security item "Always Yes to Rail-Exercise.job" to not display "No" when that user is logged on.
				If clicked Yes "Rail-Exercise.job" will get loaded
				Rail-Exercise.job should be set as
			- Set rail set-points at maximum allowable distance away from home switch
				Rail-Exercise.job will work as
			-CBS (Rail-1) will home (In) and EH (Rail-2) will home (Out)
			-CBS will move to its SP and come back to home
			-During CBS out movement CBS will switch position Up-Down-Up or Down-Up-Down depending on previous position
			-After CBS comes home EH will move to its SP and back to home
				Once both rails are home continue with new recipe or cooldown
				During this light tower should not turn green. 
 RETURNS:   UINT -true if in jog, 0 otherwise
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Rails_Process_JogCycle(Rails* pRails)
{
	PARAM_CHECK_RETURN(pRails, "Rails_Process_JogCycle", 0);
	UINT nReturn = FALSE;
	BOOL bCompleted = FALSE;
	UINT jogRail = 0;
	UINT lcv = 0;
	DWORD dwrdOvenJob = Oven_getJob(ovenDb);
	DWORD dwrdPosCount = 0;
	DWORD dwrdResult = 0;
	BOOL bHomeAchieved = FALSE;
	BOOL bActive = FALSE;
	long lInFinal = 0;
	Rail* rail = NULL;
	rail = NULL;
	
	if(!pRails->m_bJogPossible || !pRails->m_bJogOn
		|| (dwrdOvenJob == COOLDOWN) )
	{
		nReturn = 0;
		pRails->m_uintJogPhase = 0;
	}
	else
	{
		pRails->timeDelayElapsed = FALSE;
		switch(pRails->m_uintJogPhase)
		{
			case JOG_PHASE_RAIL0HOME2://rail0 send home
			case JOG_PHASE_RAIL0HOME:
				pRails->currentRail = RAIL0;
				pRails->currentHomeDirection = HomeIN;
				for(lcv = 0; lcv < MaxRails; lcv++)
				{
					rail = Rails_GetRail(pRails, lcv);
					Rail_stop(rail);
					rail->presetAchieved = FALSE;
					rail->presetShouldBeStable = FALSE;	
				}
				rail = Rails_GetRail(pRails, RAIL0);
				Rail_goHome(rail);
				Rail_setHomeAchieved(rail, FALSE);
				Rail_setOutputEnableFlag(rail, TRUE);		
				Rails_setRailHuntValues(pRails, TRUE);
				Rail_addSlowRailWarning(rail, TRUE);
				pRails->startJogTime = Timer_getCurrentTime10ths(timer); 
				pRails->m_uintJogPhase++;
				pRails->m_bSwitchJogFlag = FALSE;
				rail->bUsingRealPosition = TRUE;
				rail->presetAchieved = FALSE;
				Rail_process(rail);
				break;

			case JOG_PHASE_RAIL0HOMING://rail0 homing
			case JOG_PHASE_RAIL0HOMING2:
				rail = Rails_GetRail(pRails, RAIL0);
				Rail_process(rail);
				Rail_checkHomeStatus(rail);
				bHomeAchieved = Rail_getHomeAchieved(rail);
				Rail_addSlowRailWarning(rail, TRUE);
				if ( bHomeAchieved == TRUE )
				{
					pRails->m_uintJogPhase++;
					rail->backOffHomeFlag = TRUE;

				}
				rail = Rails_GetRail(pRails, RAIL1);
				Rail_addSlowRailWarning(rail, TRUE);
				break;

			case JOG_PHASE_RAIL1HOME: //rail1 go home
			case JOG_PHASE_RAIL1HOME2:
				rail = Rails_GetRail(pRails, RAIL1);
				bActive = Rail_getActive(rail);
				if( bActive == FALSE )
				{
					pRails->m_uintJogPhase++;
					pRails->m_uintJogPhase++;
					rail = Rails_GetRail(pRails, RAIL2);
					Rail_addSlowRailWarning(rail,TRUE);
				}
				else
				{
					pRails->currentRail = RAIL1;
					pRails->currentHomeDirection = HomeIN;
					for(lcv = 0; lcv < MaxRails; lcv++)
					{
						rail = Rails_GetRail(pRails, lcv);
						Rail_stop(rail);
					}
					rail = Rails_GetRail(pRails, RAIL1);
					Rail_goHome(rail);
					Rail_setHomeAchieved(rail, FALSE);
					Rail_setOutputEnableFlag(rail, TRUE);		
					Rails_setRailHuntValues(pRails, TRUE);
					Rail_addSlowRailWarning(rail, TRUE);
					pRails->startJogTime = Timer_getCurrentTime10ths(timer); 
					pRails->m_uintJogPhase++;
					pRails->m_bSwitchJogFlag = FALSE;
					rail->bUsingRealPosition = TRUE;
					rail->presetAchieved = FALSE;
					Rail_process(rail);
				}
				break;

			case JOG_PHASE_RAIL1HOMING: //rail1 homing
			case JOG_PHASE_RAIL1HOMING2:
				rail = Rails_GetRail(pRails, RAIL1);
				Rail_process(rail);
				Rail_checkHomeStatus(rail);
				bHomeAchieved = Rail_getHomeAchieved(rail);
				Rail_addSlowRailWarning(rail, TRUE);
				if ( bHomeAchieved == TRUE )
				{
					pRails->m_uintJogPhase++;
					rail->backOffHomeFlag = TRUE;
				}
				rail = Rails_GetRail(pRails, RAIL2);
				Rail_addSlowRailWarning(rail, TRUE);
				break;

			case JOG_PHASE_RAIL2HOME: //rail1 homing
			case JOG_PHASE_RAIL2HOME2:
				rail = Rails_GetRail(pRails, RAIL2);				
				bActive = Rail_getActive(rail);
				if(bActive == FALSE)
				{
					pRails->m_uintJogPhase++;
					pRails->m_uintJogPhase++;
					rail = Rails_GetRail(pRails, RAIL3);
					Rail_addSlowRailWarning(rail,TRUE);
				}
				else
				{
					pRails->currentRail = RAIL2;
					pRails->currentHomeDirection = HomeIN;
					for(lcv = 0; lcv < MaxRails; lcv++)
					{
						rail = Rails_GetRail(pRails, lcv);
						Rail_stop(rail);
					}
					rail = Rails_GetRail(pRails, RAIL2);
					Rail_goHome(rail);
					Rail_setHomeAchieved(rail, FALSE);
					Rail_setOutputEnableFlag(rail, TRUE);		
					Rails_setRailHuntValues(pRails, TRUE);
					Rail_addSlowRailWarning(rail, TRUE);
					pRails->startJogTime = Timer_getCurrentTime10ths(timer); 
					pRails->m_uintJogPhase++;
					pRails->m_bSwitchJogFlag = FALSE;
					rail->bUsingRealPosition = TRUE;
					rail->presetAchieved = FALSE;
					Rail_process(rail);
				}
				break;

			case JOG_PHASE_RAIL2HOMING: //rail2 going home
			case JOG_PHASE_RAIL2HOMING2:
				rail = Rails_GetRail(pRails, RAIL2);
				Rail_process(rail);
				Rail_checkHomeStatus(rail);
				bHomeAchieved = Rail_getHomeAchieved(rail);
				Rail_addSlowRailWarning(rail, TRUE);
				if ( bHomeAchieved == TRUE )
				{
					pRails->m_uintJogPhase++;
					rail->backOffHomeFlag=TRUE;
				}
				rail = Rails_GetRail(pRails, RAIL3);
				Rail_addSlowRailWarning(rail, TRUE);
				break;

			case JOG_PHASE_RAIL3HOME://fall through
				pRails->m_uintUpdownPhase = 0;
			case JOG_PHASE_RAIL3HOME2:
				rail = Rails_GetRail(pRails, RAIL3);
				bActive = Rail_getActive(rail);
				if( bActive == FALSE )
				{
					pRails->m_uintJogPhase++;
					pRails->m_uintJogPhase++;
					rail = Rails_GetRail(pRails, RAIL0);
					Rail_addSlowRailWarning(rail,TRUE);
				}
				else
				{
					pRails->currentRail = RAIL3;
					pRails->currentHomeDirection = HomeIN;
					for(lcv=0; lcv < MaxRails; lcv++)
					{
						rail = Rails_GetRail(pRails, lcv);
						Rail_stop(rail);
					}
					rail = Rails_GetRail(pRails, RAIL3);	
					Rail_goHome(rail);
					Rail_setHomeAchieved(rail, FALSE);
					Rail_setOutputEnableFlag(rail, TRUE);		
					Rails_setRailHuntValues(pRails, TRUE);
					Rail_addSlowRailWarning(rail, TRUE);
					pRails->startJogTime = Timer_getCurrentTime10ths(timer); 
					pRails->m_uintJogPhase++;
					pRails->m_bSwitchJogFlag = FALSE;
					rail->bUsingRealPosition = TRUE;
					rail->presetAchieved = FALSE;
					Rail_process(rail);
				}
				break;

			case JOG_PHASE_RAIL3HOMING:
			case JOG_PHASE_RAIL3HOMING2:
				rail = Rails_GetRail(pRails, RAIL3);
				Rail_process(rail);
				Rail_checkHomeStatus(rail);
				bHomeAchieved = Rail_getHomeAchieved(rail);
				Rail_addSlowRailWarning(rail, TRUE);
				if ( bHomeAchieved == TRUE )
				{
					pRails->m_uintJogPhase++;
					rail->backOffHomeFlag = TRUE;
					pRails->currentRail = 0;
				}
				rail = Rails_GetRail(pRails, RAIL0);
				Rail_addSlowRailWarning(rail, TRUE);
				break;			

			case JOG_PHASE_RAIL0PRESET:
				jogRail = RAIL0;
				rail = Rails_GetRail(pRails, jogRail);
				Rail_preset(rail);
				Rail_process(rail);
				bCompleted = Rails_phaseUpDown(pRails, pRails->controledUD[jogRail]);
				if(pRails->m_uintUpdownPhase == 0 && !bCompleted)
				{
					dwrdPosCount = Rail_getPositionCounts(rail);
					dwrdResult = dwrdPosCount / pRails->pulseCounts[jogRail];
					if( dwrdResult >= 5)
					{
						pRails->m_uintUpdownPhase++;
					}
				}
				bActive = Rail_getActive(rail);
				//can't test for final position, overshoot can occur and we don't hunt in jog(exercise)
				lInFinal = Rail_JoggedOut(rail);
				if( (lInFinal == TRUE || !bActive) && bCompleted)
				{
					pRails->m_uintJogPhase++;
					Rail_stop(rail);
					pRails->m_uintUpdownPhase = 0;
				}
				Rails_testJobTime(pRails);
				break;

			case JOG_PHASE_RAIL1PRESET:
				jogRail = RAIL1;
				rail = Rails_GetRail(pRails, jogRail);
				Rail_preset(rail);
				Rail_process(rail);
				bCompleted = Rails_phaseUpDown(pRails, pRails->controledUD[jogRail]);
				if( (pRails->m_uintUpdownPhase == 0) && !bCompleted)
				{
					dwrdPosCount = Rail_getPositionCounts(rail);
					dwrdResult = dwrdPosCount / pRails->pulseCounts[jogRail];
					if( dwrdResult >= 5)
					{
						pRails->m_uintUpdownPhase++;
					}
				}
				lInFinal = Rail_JoggedOut(rail);
				bActive = Rail_getActive(rail);
				if( ( (lInFinal == TRUE ) || !bActive ) && bCompleted)
				{
					pRails->m_uintJogPhase++;
					Rail_stop(rail);
					pRails->m_uintUpdownPhase = 0;
				}
				Rails_testJobTime(pRails);
				break;

			case JOG_PHASE_RAIL2PRESET:
				jogRail = RAIL2;
				rail = Rails_GetRail(pRails, jogRail);
				Rail_preset(rail);
				Rail_process(rail);
				bCompleted = Rails_phaseUpDown(pRails, pRails->controledUD[jogRail]);
				if( (pRails->m_uintUpdownPhase == 0) && !bCompleted)
				{
					dwrdPosCount = Rail_getPositionCounts(rail);
					dwrdResult = dwrdPosCount / pRails->pulseCounts[jogRail];
					if( dwrdResult >= 5)
					{
						pRails->m_uintUpdownPhase++;
					}
				}
				lInFinal = Rail_JoggedOut(rail);
				bActive = Rail_getActive(rail);
				if( ( lInFinal == TRUE || !bActive ) &&
					bCompleted )
				{
					pRails->m_uintJogPhase++;
					Rail_stop(rail);
					pRails->m_uintUpdownPhase = 0;
				}
				Rails_testJobTime(pRails);
				break;

			case JOG_PHASE_RAIL3PRESET:		
				jogRail = RAIL3;
				rail = Rails_GetRail(pRails, jogRail);
				Rail_preset(rail);
				Rail_process(rail);
				bCompleted = Rails_phaseUpDown(pRails, pRails->controledUD[jogRail]);
				if(pRails->m_uintUpdownPhase == 0 && !bCompleted)
				{
					dwrdPosCount = Rail_getPositionCounts(rail);
					dwrdResult = dwrdPosCount / pRails->pulseCounts[jogRail];
					if( dwrdResult >= 5)
					{
						pRails->m_uintUpdownPhase++;
					}
				}
				lInFinal = Rail_JoggedOut(rail);
				bActive = Rail_getActive(rail);
				if( (lInFinal == TRUE || !bActive) && bCompleted)
				{
					pRails->m_uintJogPhase++;
					Rail_stop(rail);
					pRails->m_uintUpdownPhase = 0;
				}
				Rails_testJobTime(pRails);
				break;

			case JOG_PHASE_DONE:
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, RAILS_JOG_COMPLETE, 0);	
				pRails->railState = E_STOP_STATE;
				for(lcv = 0; lcv < MaxRails; lcv++)
				{
					pRails->indRailState[lcv] = E_STOP_STATE;
					rail = Rails_GetRail(pRails, lcv);
					rail->presetShouldBeStable = TRUE;
					Rail_stop(rail);				
				}						
				pRails->m_bJogOn = FALSE;
				break;			
		}
		pRails->jobNo = Oven_getJob(ovenDb);
		nReturn = TRUE; 
	}
	return nReturn;
}
		
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_phaseUpDown
			
			sequences through up/down...


 RETURNS:   UINT, true or false
 SEE ALSO:
------------------------------------------------------------------------*/
UINT Rails_phaseUpDown(Rails *pRails, UINT iWhichUD)
{
	UINT uReturn = FALSE;
	UINT cState = 0; 
	BOOL bActive = TRUE;
	DWORD tim = 0;

	if(iWhichUD == CBS0)
	{
		bActive = g_dbContainer.cbs.cbs1Enabled;
	}
	if(iWhichUD == CBS1)
	{
		bActive = g_dbContainer.cbs.cbs2Enabled;
	}
	if( bActive && ( ( iWhichUD == CBS0 ) || ( iWhichUD == CBS1 ) ) )
	{
		switch(pRails->m_uintUpdownPhase)
		{
			case 0:
				pRails->udPhaseTimer = 0;
				pRails->m_bUDPhaseMonitor = FALSE;
				break;

			case 1:
			case 2:
			case 3:
			case 4:
				if(!pRails->udPhaseTimer)
				{
					
					if(iWhichUD)
					{
						cState = CBS_GetSecondState(cbs);
					}
					else
					{
						cState = CBS_GetState(cbs);
					}
					CBS_setStates(cbs, !cState, iWhichUD);
					pRails->selfAckAlarmNo2 = AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, RAILS_JOG_CBS_SWITCH, iWhichUD);
					pRails->udPhaseTimer = Timer_getCurrentTime10ths(timer); 
				}
				else
				{
					tim = Timer_getCurrentTime10ths(timer);
					if( (tim - pRails->udPhaseTimer ) > 49)
					{
						pRails->udPhaseTimer = 0;
						AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRails->selfAckAlarmNo2);
						pRails->m_uintUpdownPhase++;
					}	
				}
				break;

			case 5:
				pRails->m_bUDPhaseMonitor = TRUE;
				uReturn = TRUE;
				break;

			default:
				break;					
		}
	}
	else
	{
		uReturn = TRUE;
	}
	return uReturn;
}

void Rails_SetPulseCounts(Rails* pRails, DWORD count, DWORD index)
{
	if(index <MaxRails)
	{
		pRails->pulseCounts[index] = count;
	}
}

void Rails_setHomeUnstable(Rails* pRails)
{
	UINT lcv;
	Rail* rail;
	for(lcv = 0; lcv < MaxRails; lcv++)
	{
		rail = Rails_GetRail(pRails, lcv);
		Rail_setHomeAchieved(rail, FALSE);
		Rail_stop(rail);
		Rail_setOutputEnableFlag(rail, TRUE);
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_setRailHuntValues
			
			calls the preset warning routine


 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rails_setRailHuntValues(Rails* pRails, BOOL bJogging)
{
	UINT i = 0;
	Rail* rail = NULL;

	for(i = 0; i < MaxRails; i++)
	{
		rail = Rails_GetRail(pRails, i);
		if(rail)
		{
			Rail_setPresetWarningFlag(rail, bJogging);
		}
	}

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_testJobTime

			adds the rail exercise timeout
 
 RETURNS:   void
------------------------------------------------------------------------*/
void Rails_testJobTime(Rails* pRails)
{
	BOOL bForce;
	UINT i;
	Rail* rail;
	DWORD tim;

	bForce = FALSE;
	i = 0;
	rail = NULL;
	tim = 0;

	if(pRails)
	{
		if(pRails->m_bJogPossible && pRails->m_bJogOn)
		{
			for(i = 0; i < MaxRails; i++)
			{
				rail = Rails_GetRail(pRails, i);
				if(rail)
				{
					if(rail->presetWarningAdded || rail->alarm1id)
					{
						bForce = TRUE;
					}
				}
				tim = Timer_getCurrentTime10ths(timer);
				if( bForce || ( (tim - pRails->startJogTime) >= RAILS_JOG_FAIL_TIME_10THS) )
				{
					pRails->m_bJogOn = TRUE;	
					AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAILS_JOG_FAILED, 0);
				}
		
			}
		}
	}
	return;
}
DWORD Rails_monitorudPhaseTimer(Rails* pRails)
{
	return pRails->udPhaseTimer;
}

UINT Rails_monitorm_uintUpdownPhase(Rails* pRails)
{
	return pRails->m_uintUpdownPhase;
}

UINT Rails_monitorm_uintJogPhase(Rails* pRails)
{
	return pRails->m_uintJogPhase;
}

UINT Rails_monitorm_bUDPhaseMonitor(Rails* pRails)
{
	return pRails->m_bUDPhaseMonitor;
}
UINT Rails_monitorcurrentRail(Rails* pRails)
{
	return pRails->currentRail;
}

UINT Rails_monitorm_bJogOn(Rails* pRails)
{
	return pRails->m_bJogOn;
}

void Rails_preTest(Rails* pRails)
{
	if(*DIN_GetAt(digitalInputs, pRails->m_iInputForHardware))
		pRails->m_bRailHardwarePreProcess=TRUE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rails_railsInHardwareMode
			
			reads a digital input and uses a software setting to determine
			whether we are in hardware mode or not


 RETURNS:   UINT, true or false
------------------------------------------------------------------------*/
UINT Rails_railsInHardwareMode(Rails* pRails)
{
	BOOL bReturn;
	BOOL bInput;
	bInput = FALSE;
	bReturn = FALSE;
	if(pRails)
	{
		if(pRails->railControlVector == HARDWARE_CON )
		{
			bInput = *DIN_GetAt(digitalInputs, pRails->m_iInputForHardware);
			if(bInput )
			{
				bReturn = TRUE;
			}
		}
	}
	return bReturn;
}

