/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2013, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __MASS_CONTROLLER_H__
#define __MASS_CONTROLLER_H__

#include "typedefdefine.h"


// Abstract:
// This class writes TPO on the secondary board.  Heller calls these mass controllers, which are
//modelled after heat zone blowers.  They do not have a second flush cycle


enum { MAX_MASS_CONTROLLERS = 5 };

typedef struct _MassControllers_
{
	unsigned int    TPOBlowerPercentX10[MAX_MASS_CONTROLLERS];
	BOOL			enabled[MAX_MASS_CONTROLLERS];
	UINT			LowSetting[MAX_MASS_CONTROLLERS];
	UINT			MediumSetting[MAX_MASS_CONTROLLERS];
	UINT			HighSetting[MAX_MASS_CONTROLLERS];
	unsigned int	uintOutputIndex[MAX_MASS_CONTROLLERS]; 
	DWORD			flushTime;
	UINT			jobNo;
	DWORD			startTime;

} MassController;

void MassController_init(MassController* pMassController);

void MassController_process( MassController* pMassController );
BOOL MassController_setOutputPercent(MassController* pMassController, unsigned int ZoneNo, int outputPercent );
unsigned int MassController_getOutputPercent(MassController* pMassController, unsigned int ZoneNo );
void MassController_setEnable(MassController* pMassController, int blowerID, BOOL enable /*= TRUE*/ );
BOOL MassController_getIfMassControllerIsEnabled(MassController* pMassController, int blowerID);
void MassController_setLowSetting(MassController* pMassController, int blowerID, UINT uiSetting);
void MassController_setMediumSetting(MassController* pMassController, int blowerID, UINT uiSetting);
void MassController_setHighSetting(MassController* pMassController, int blowerID, UINT uiSetting);
UINT MassController_getLowSetting(MassController* pMassController, int blowerID);
UINT MassController_getMediumSetting(MassController* pMassController, int blowerID);
UINT MassController_getHighSetting(MassController* pMassController, int blowerID);
void MassController_setFlushTime(MassController* pMassController, DWORD flshTime);	
void MassController_testTPOPath(int iTest);
#endif
