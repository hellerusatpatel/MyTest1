/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// bdrop.cpp
#include "contain.h"
#include "digitio.h"
#include "alarm.h"
#include "oven.h"
#include "bdrop.h"
#include <string.h>

extern DbContainer g_dbContainer;

static UINT bdDetectorNo = 0;

static AlarmQueue*	alarmQueueDb;
static Oven*		oven;
static Timer* 	elapseTimer;
static DIN*		digitalInDb;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  BoardDropLB_init
			
			

 GLOBALS:	g_dbContainer
 RETURNS:   NTSTATUS
 SEE ALSO:
------------------------------------------------------------------------*/
void BoardDropLB_init(BoardDropLB* pBD)
{
	PARAM_CHECK( pBD, "BoardDropLB_init");

	pBD->idNo = bdDetectorNo;
	pBD->enabled	= FALSE;
	pBD->boardDropTimeOutMode = FALSE;

	bdDetectorNo++;

	alarmQueueDb = &(g_dbContainer.alarmQueueDb );
	digitalInDb	= &(g_dbContainer.digitalInDb );
	oven = &(g_dbContainer.ovenDb );
	elapseTimer = &(g_dbContainer.elapseTimer );
	BoardDropLB_configureIO(pBD);
	return;
}


void BoardDropLB_configureIO(BoardDropLB* pBD)
{
	PARAM_CHECK( pBD, "BoardDropLB_configureIO");

	switch( pBD->idNo )
	{
		case 0:
			 pBD->pBoardDropInput = DIN_GetAt(digitalInDb, IDI_BEAM_BOARD_DROP_LANE1);
			break;
		case 1: 
			pBD->pBoardDropInput = DIN_GetAt(digitalInDb, IDI_BEAM_BOARD_DROP_LANE2);
			break;
	}
}

BOOL BoardDropLB_configure(BoardDropLB* pBD, DWORD configOption )
{
	BOOL status = TRUE;

	PARAM_CHECK_RETURN( pBD, "BoardDropLB_configure", FALSE);

	switch ( pBD->idNo )
	{
		case 0:	switch ( configOption )
				{
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:  
						pBD->enabled = FALSE;
						break;	
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
					case 14:
					case 15:
						pBD->enabled = TRUE;
						break;
					default:
						pBD->enabled = FALSE;
						status = FALSE; 	
						break;
				}
				break;
		case 1: switch ( configOption )
				{
			
					case 0:
					case 1:
					case 4:
					case 5:
					case 8:
					case 9:
					case 12:
					case 13: pBD->enabled = FALSE;
							 break;
					case 2:
					case 3:
					case 6:
					case 7:
					case 10:
					case 11:
					case 14:
					case 15: pBD->enabled = TRUE;
							 break;
					default: pBD->enabled = FALSE;
							 status = FALSE;
							
				}
	}
	return status;
}

void BoardDropLB_enableOption(BoardDropLB* pBD,  BOOL optionEnable )
{
	PARAM_CHECK( pBD, "BoardDropLB_enableOption");
	pBD->enabled = optionEnable;
}

void BoardDropLB_process(BoardDropLB* pBD)
{
	PARAM_CHECK( pBD, "BoardDropLB_process");

	if ( Oven_getJob(oven) == COOLDOWN || pBD->enabled == FALSE )
	{
		pBD->boardDropTimeOutMode = FALSE;
	}
	else
	{
		if ( *(pBD->pBoardDropInput) == FALSE && pBD->boardDropTimeOutMode == FALSE ) // board drop detected 
		{
			pBD->boardDropTimeOutMode = TRUE;
			pBD->startTime = Timer_getCurrentTime10ths(elapseTimer);
		}
		if ( *(pBD->pBoardDropInput) == FALSE ) 
		{
			pBD->elapsedTime = Timer_getCurrentTime10ths(elapseTimer) - pBD->startTime;
			
			if ( pBD->elapsedTime >= BOARD_DROP_TIME_OUT_10THS )
			{
				if(pBD->idNo==0)
					AlarmQueue_addAlarm(alarmQueueDb, WARNING, BOARD_DROP_WARNING, pBD->idNo );
				if(pBD->idNo==1)
					AlarmQueue_addAlarm(alarmQueueDb, WARNING, BOARD_DROP_WARNING_2, pBD->idNo );
			}

		}
		else
		{
			pBD->boardDropTimeOutMode = FALSE;
		}
	}
}


