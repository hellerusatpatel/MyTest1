/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999-2014, All Rights Reserved
                    Company Confidential

	File:			alarm.h

	Description:	alarm defines

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//alarm
#ifndef __ALARM_H__
#define __ALARM_H__

#include "typedefdefine.h"
extern unsigned char ucLane1Secsgem;
extern unsigned char ucLane2Secsgem;
extern unsigned char ucLane3Secsgem;
extern unsigned char ucLane4Secsgem;

extern unsigned char ucLane1Audible;
extern unsigned char ucLane2Audible;
extern unsigned char ucLane3Audible;
extern unsigned char ucLane4Audible;

typedef struct _TimeStamp_
{
	BYTE mm,dd,yy,cc;
	BYTE hh,min,ss;
} TimeStamp;

BYTE readClock ( BYTE reg );
void getTimeStamp( TimeStamp* pTimeStamp );

enum AlarmStatus 	{ AS_OK=0,	AS_NOMESSAGES,	AS_OVERFLOW };
enum AlarmType		{ AVAILABLE=0, ALARM,	WARNING, INFORMATION, LOGGED_EVENT }; 

#define ALARM_WARNING_CNT_MAX	256
								
typedef struct _TransferAlarmData_
{
	DWORD			alarmID;
	UINT		 	moduleCode;
	enum AlarmType  alarmType;
	UINT		 	messageNo;
	TimeStamp		tStamp;
	enum AlarmStatus	status;
	BOOL			read;
	BOOL			notify;
} TransferAlarmData;

struct AlarmQueue;

//*****************************************************************************
// class ALARM
//
// Abstract:
//	The alarm information by module with the specifying messageNo, module code and
//  alarm type. Two flags read and acknoledge are used to inform the Windows 
//  application if the record has been read or read and acknoledged.
//  The read flag being set to TRUE tells Windows that this record has been read
//  and not to read it again. When the acknowledge flag is FALSE the VXD must 
//  check each record, where acknoledge flags being FALSE means that the record is
//  in use and that no more alarms of that type will be added.
//
// Programmer: Steven Young
// Date: 06/11/1998
//
//*****************************************************************************
typedef struct _Alarm_
{
//private:
	DWORD			alarmID;
	UINT		 	messageNo;
	UINT		 	moduleCode;
	enum AlarmType  		alarmType;
	TimeStamp		tStamp;
	enum AlarmStatus		status;
	BOOL			read;
	BOOL			acknowledge;
	BOOL			notify;
} Alarm;

void Alarm_init(Alarm* pAlarm);
void Alarm_getAlarm(Alarm* pAlarm, TransferAlarmData* pAlarmData, BOOL setReadFlag );
void Alarm_setAlarm(Alarm* pAlarm, enum AlarmType aType, UINT messNo, UINT mCode, DWORD alarmID );
void Alarm_alarmAcknowledge(Alarm* pAlarm);

#define MaxAlarms 50

typedef struct _AlarmQueue_
{
//private:
	char name[MaxNameLength+1];

	UINT		 	alarmCount;
	DWORD			alarmID;
	enum AlarmStatus 	aStatus;
	UINT			openAlarms;
	UINT			openAudibleWarnings;
	UINT			openWarnings;
	
	// used for keeping track of warnings belonging to a lane of one of the light towers
	UINT			openWarnings_lt1;	// warnings for light tower 1
	UINT			openWarnings_lt2;	// warnings for light tower 1
	UINT			openWarnings_common;	// warnings for light tower 1 & 2

	BOOL			boardDropWarning;
	BOOL			boardDropWarningLT;
	Alarm 			aq[MaxAlarms];
	BOOL			delayFor10seconds;
	DWORD			startTime;
	DWORD			currentTime;
	BOOL			m_AlarmLight;
	BOOL			m_bAlarmsTriggerAudibleEvent;
	BOOL			m_bAudibleWarnings;
	BOOL			m_bOKForAudibleWarnings;
	
	// Flag added to allow silence button to kill audible warnings
	// without affecting light tower/smema behavior
	BOOL			m_bAudibleWarningFlag;

//public:
	BOOL			m_bAudibleBeltWarningsEnabled;
	BOOL			m_bAudibleLowExhaustEnabled;
	BOOL			m_bAudibleDansensorWarningEnabled;
  
	BOOL 			m_bAudibleLane1Warnings;
	BOOL 			m_bAudibleLane2Warnings;      
//protected:
	BOOL 			m_bProcessLoopStarted;
	BOOL 			m_bAudibleBCWarnings;
	UINT 			m_openBCWarnings;
	BOOL 			m_bVIPMode;
	UINT 			m_dwrdOutput;
	DWORD 			m_openAudibleLaneWarnings;
	BOOL 			m_bAudibleEnergySave;
	BOOL			m_bAudibleCA3;
	BOOL			m_bCA3InWarning;
	BOOL			m_bCA3Output;
	BOOL			m_bAudibleCA4;
	BOOL			m_bCA4InWarning;
	BOOL			m_bCA4Output;
	BOOL			m_bAudibleCA5;
	BOOL			m_bCA5InWarning;
	BOOL			m_bCA5Output;
	BOOL			m_bAudibleBoardWarnings[MAX_SMEMA_LANES];
	BOOL			m_bAudibleBoardInWarning[MAX_SMEMA_LANES];
	BOOL			m_bBlowerInWarning;
} AlarmQueue;

void AlarmQueue_init(AlarmQueue* pAlarmQ);
enum AlarmType AlarmQueue_AlarmTypeSwitch(AlarmQueue* pAlarmQ, enum AlarmType baseAlarmType, UINT messageNumber);
DWORD AlarmQueue_addAlarm(AlarmQueue* pAlarmQ, enum AlarmType aType, UINT messNo, UINT mCode /*=0*/);
BOOL AlarmQueue_EventActive(AlarmQueue* pAlarmQ, UINT messNo, UINT mCode );
UINT AlarmQueue_getAlarmCount(AlarmQueue* pAlarmQ);
UINT AlarmQueue_getStatusEvents(AlarmQueue* pAlarmQ);
UINT AlarmQueue_getAlarmOutput(AlarmQueue* pAlarmQ);
signed int AlarmQueue_getQueuePosition(AlarmQueue* pAlarmQ, DWORD alarmIDsearch);

BOOL AlarmQueue_alarmsPresent(AlarmQueue* pAlarmQ);

UINT AlarmQueue_audibleWarningsPresent(AlarmQueue* pAlarmQ);

BOOL AlarmQueue_audibleUserWarningsPresent(AlarmQueue* pAlarmQ);

BOOL AlarmQueue_warningsPresent(AlarmQueue* pAlarmQ);
BOOL AlarmQueue_warningsPresent_lt1(AlarmQueue* pAlarmQ);
BOOL AlarmQueue_warningsPresent_lt2(AlarmQueue* pAlarmQ);
BOOL AlarmQueue_warningsPresent_common(AlarmQueue* pAlarmQ);

BOOL AlarmQueue_getAlarmMessage(AlarmQueue* pAlarmQ, UINT messageIndex, TransferAlarmData* pAlarmData, BOOL bWin_hdac /*=TRUE*/);
BOOL AlarmQueue_alarmQueueAcknowledge(AlarmQueue* pAlarmQ, DWORD alarmIDsearch );
void AlarmQueue_alarmQueueAcknowledgeByType(AlarmQueue* pAlarmQ, DWORD alarmTypesearch );

const char* AlarmQueue_getName(AlarmQueue* pAlarmQ);
void AlarmQueue_resetAlarms(AlarmQueue* pAlarmQ);			// need for testing
void AlarmQueue_clearReadFlagAll(AlarmQueue* pAlarmQ);

BOOL AlarmQueue_getBoardDropStatus(AlarmQueue* pAlarmQ);
BOOL AlarmQueue_getBoardDropStatusLightTower(AlarmQueue* pAlarmQ);
 
BOOL AlarmQueue_findAcknowledgedAlarm(AlarmQueue* pAlarmQ, DWORD alarmIDsearch );

//these no longer are cooldown preferences, they now prevent a limited amount of heat alarms
//from triggering cooldown(they warn instead and involve additional processing for channel state)
void AlarmQueue_setCooldownPreference(AlarmQueue* pAlarmQ, BOOL bAlarmLight);
BOOL AlarmQueue_getCooldownPreference(AlarmQueue* pAlarmQ);
void AlarmQueue_resetAudibleSounding(AlarmQueue* pAlarmQ);
UINT AlarmQueue_returnInAudibleCondition(AlarmQueue* pAlarmQ);
void AlarmQueue_setProcessLoopStarted(AlarmQueue* pAlarmQ, BOOL bStarted);
BOOL AlarmQueue_getProcessLoopStarted(AlarmQueue* pAlarmQ);

void AlarmQueue_setAudibleWarnings(AlarmQueue* pAlarmQ, BOOL bOn);
void AlarmQueue_setAudibleBCWarnings(AlarmQueue* pAlarmQ, BOOL bOn);

void AlarmQueue_enableAudibleWarnings(AlarmQueue* pAlarmQ, BOOL bEnable);
void AlarmQueue_clearAllWarnings(AlarmQueue* pAlarmQ);
void AlarmQueue_setLaneWarnings(AlarmQueue* pAlarmQ, BOOL bWarning, UINT uIndex);
void AlarmQueue_clearLoggedEvents(AlarmQueue* pAlarmQ);
void AlarmQueue_setVIPMode(AlarmQueue* pAlarmQ, BOOL bOn);
void AlarmQueue_setAWOutput(AlarmQueue* pAlarmQ, DWORD dwrdOutput);
void AlarmQueue_setRedOnBoardError(AlarmQueue* pAlarmQ, BOOL bAlarm);

BOOL AlarmQueue_hasEStopAlarm(AlarmQueue* pAlarmQ);
DWORD AlarmQueue_findOpenWarning(AlarmQueue* pAlarmQ, UINT messNo);
unsigned char AlarmQueue_SecsgemLightTower();
#endif
