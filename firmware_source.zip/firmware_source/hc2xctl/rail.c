/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
/* NOTE:
/ The value of 150 pulses that is being used for the tolerance is the result 
/ of the following calculation:
/ 768 pulses/.1in * 1in/25.4mm = 302.4pulses/mm
/ Tolerance is +1mm/-0mm
/ 1mm = 302 pulses and as a margin of safety 1/2 of 302 or approximately 150
/ was chosen to define the tolerance.
/ Tolerance can be affected by motor speed when the rail leaves the limit switch.
/ A scan time of .1sec with the resulting error being the distance the rail travels
/ during this time.
***************************************************************************/ 
#include "contain.h"
#include "alarm.h"
#include "digitio.h"
#include "oven.h"
#include "timer.h"
#include "digitio.h"
#include "rails.h"

extern DbContainer g_dbContainer;

AlarmQueue* alarmQueueDb;
Timer* 		timer;
DIN*		digitalInputs;
DOUT* 		digitalOutputs;
ANALOGIN*	analogInputs;
Oven*		ovenDb;
Rails*		railsDb;


#define ONEMINUTE_TIMEOUT 300 //30 seconds or 300 tenths of seconds
#define PRESET_TIMEOUT 150
#define THREE_SECONDS 30 //30 1/10 seconds

#define DEADBANDSTATE_INIT 0
#define DEADBANDSTATE_INDEADBAND 1
#define DEADBANDSTATE_OVERSHOT 2
#define DEADBANDSTATE_UNDERSHOT 3

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_init

			initializes member variables for the rail
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_init(Rail* pRail, enum IdNo idNo)
{
	PARAM_CHECK( pRail, "Rail_init");

	pRail->railIdNo			= idNo;
	pRail->railActive			= FALSE;
	pRail->homeAchieved		= FALSE;
	pRail->startHomeTime		= 0L;
	pRail->elapsedHomeTime		= 0L;
	pRail->rail_homeTime		= 0L;
	pRail->lastPositionCounts	= 0L;
	pRail->newJob				= FALSE;
	pRail->lastHome			= TRUE;
	pRail->controlType			= Auto;
	pRail->directionFlag		= Rail_REVERSE;
	pRail->presetPosition		= 0L;
	pRail->currentPositionLSW  = 0L;
	pRail->currentPositionMSW  = 0L;
	pRail->currentPositionCounts = 0L;
	pRail->homePositionCounts	= 0L;
	pRail->homeOffsetCounts	= 0L;
	pRail->actualPosition		= 0L;
	pRail->homeDirection		= HomeIN;
	pRail->railState			= Rail_STOP;
	pRail->presetAchieved		= FALSE;
	pRail->incrementFlag		= FALSE;
	pRail->decrementFlag		= FALSE;
	pRail->motorEnabled		= FALSE;
	pRail->manualMove			= FALSE;
	pRail->scanDelay			= 4;
	pRail->lastDirectionChangeTime = 0;
	pRail->overShootFactor		= 0;
	pRail->toleranceAttempts	= 0;
	pRail->lastMotorEnabledTime = 0;
	pRail->lastActualOnTime	= 0;
	pRail->directionChangeFlag = FALSE;
	pRail->underShoot			= FALSE;
	pRail->finalStagePositioning = FALSE;
	pRail->trackPushButton		= FALSE;
	pRail->overShootTimeOut	= FALSE;
	pRail->m_bOutputEnable		= TRUE;
	pRail->m_bNewPresetPosition = FALSE;
	pRail->m_lAtFinalPresetTimer = 0;
	pRail->presetShouldBeStable = FALSE;
	pRail->timerForYellow =		  0;
	pRail->m_fallInTime  =		  0;
	pRail->presetAttemptFailed = FALSE;
	pRail->m_backUpTime =		0;
	pRail->iArrayIndicator =  0;
	pRail->m_bForPrintfDebuggingControl  = FALSE;
	pRail->m_bStablizeOvershootReading = FALSE;
	pRail->m_bUnderShootingCorrectionEntered = FALSE;
	pRail->lStopFactor  = -1;
	pRail->eOvershootFactor = 20;
	pRail->eInitialCorrectionFactor = 0;
	pRail->eUndershootCorrectionFactor = 15;
	pRail->backupForFirstRun = FALSE;
	pRail->backingUp = FALSE;
	pRail->lastRailState = 0;
	pRail->nTolerance = 16;
	pRail->pTolerance = 146;
	pRail->backDistance = 3152;
	pRail->defaultHunt = TRUE;
	pRail->maxHunt = 5;
	pRail->useHomeOutHuntAlg = FALSE;
	pRail->presetWarningAdded = FALSE;
	pRail->selfAckAlarmNo = 0;
	pRail->m_SlowPresetTime = 0;
	pRail->previousActualPos = 0;
	pRail->bUsingRealPosition = TRUE;
	pRail->backOffHomeFlag = FALSE;
	pRail->bDontAllowNewStopFactor = FALSE;
	pRail->bHardwareMode = FALSE;
	pRail->AssignSP = FALSE;
	pRail->bNoFailureToAchievePresetWarning = FALSE;
	pRail->m_bNotSequenced = TRUE;
	alarmQueueDb = &( g_dbContainer.alarmQueueDb );
	timer = &( g_dbContainer.elapseTimer );
	digitalInputs = &( g_dbContainer.digitalInDb );
	digitalOutputs = &( g_dbContainer.digitalOutDb );
	analogInputs = &( g_dbContainer.analogInDb );
	ovenDb = &( g_dbContainer.ovenDb );
	railsDb = &(g_dbContainer.railsDb);

	pRail->lastDecrementTime = Timer_getCurrentTime10ths(timer);
	pRail->lastIncrementTime = Timer_getCurrentTime10ths(timer);
	pRail->directionDelayStartTime = Timer_getCurrentTime10ths(timer);
	pRail->selfAckAlarmNo2 = 0;
	pRail->lastCurrentPositionCounts = 0;
	pRail->m_bRailMoved = TRUE;

	pRail->m_laneIndex = 0;
	pRail->m_hasHomed = 0;
	pRail->m_bSPChanged = FALSE;
	pRail->alarm1id = 0;
	switch(pRail->railIdNo)
	{
		case RAIL0:
		pRail->m_ioHomeSwitch = IDI_RAIL1_HOME_SWITCH;
		pRail->m_uiOutput = ODO_RAIL1_ENABLE;
		pRail->m_uiDirection = ODO_RAIL1_DIRECTION;
		break;
		case RAIL1:
		pRail->m_ioHomeSwitch = IDI_RAIL2_HOME_SWITCH;
		pRail->m_uiOutput = ODO_RAIL2_ENABLE;
		pRail->m_uiDirection = ODO_RAIL2_DIRECTION;
		break;
		
		case  RAIL2:
		pRail->m_ioHomeSwitch = IDI_RAIL3_HOME_SWITCH;
		pRail->m_uiOutput = ODO_RAIL3_ENABLE;
		pRail->m_uiDirection = ODO_RAIL3_DIRECTION;
		break;
		
		case RAIL3:
		pRail->m_ioHomeSwitch = IDI_RAIL4_HOME_SWITCH;
		pRail->m_uiOutput = ODO_RAIL4_ENABLE;
		pRail->m_uiDirection = ODO_RAIL4_DIRECTION;
		break;

		case BADRAIL:
		default:
		pRail->m_ioHomeSwitch = IDI_NULL;
		pRail->m_uiOutput = ODO_NULL;
		pRail->m_uiDirection = ODO_NULL;
		break;
	}
	return;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//void Rail_setPositionCounts(Rail* pRail, DWORD presetCounts, BOOL presetStable, BOOL bTransition )
//
//used to assign a SP to the rails
////////////////////////////////////////////////////////////////////////////////////////////////////////
void Rail_setPositionCounts(Rail* pRail, DWORD presetCounts, BOOL presetStable, BOOL bTransition )
{
	PARAM_CHECK( pRail, "Rail_setPositionCounts");
	if ( pRail->incrementFlag == TRUE || pRail->decrementFlag == TRUE )//early return
	{
	}
	else
	{
		if((pRail->railActive == TRUE) && pRail->controlType == Auto)
		{
			pRail->m_bSPChanged=TRUE;
		}
		if ( pRail->AssignSP )//early return
		{
			pRail->AssignSP = FALSE;
			pRail->priorPosition  = pRail->presetPosition;
			pRail->presetPosition = presetCounts;
		}
		else
		{
			pRail->presetAttemptFailed = FALSE;
			pRail->priorPosition = pRail->presetPosition;
			pRail->presetPosition = presetCounts;		
			pRail->trackPushButton = FALSE;
			pRail->finalStagePositioning = FALSE;
			pRail->m_bStablizeOvershootReading = FALSE;
			pRail->m_bUnderShootingCorrectionEntered = FALSE;
			if ( (pRail->priorPosition != pRail->presetPosition) || bTransition )
			{
				if(!presetStable)
				{
					pRail->presetShouldBeStable = FALSE;
					pRail->presetAchieved = FALSE;
				}
				pRail->presetWarningAdded = FALSE;
				pRail->overShootFactor = pRail->eInitialCorrectionFactor;
	
				pRail->toleranceAttempts = 0;
				pRail->m_bNewPresetPosition = TRUE;
				pRail->m_lAtFinalPresetTimer = 0;
	
				pRail->overShootTimeOut = FALSE;
				pRail->backupForFirstRun = TRUE;
				pRail->backingUp = FALSE;
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo );
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo2 );
				Rail_addSlowRailWarning(pRail, TRUE);
				pRail->bDontAllowNewStopFactor = FALSE;
				if(Rail_onHomeSwitch(pRail))
				{
					pRail->backOffHomeFlag = TRUE;
					if(!pRail->defaultHunt)//in this condition the rails will calculate a new stop factor before in position to start hunting
					{
						pRail->bDontAllowNewStopFactor = TRUE;
					}
				}
				if(!pRail->useHomeOutHuntAlg && Rails_returnRailsHaveHomed(railsDb))
				{
					Rail_setDirectionFlag(pRail, Rail_REVERSE);
				}
				Rail_resetOverShootTimeOut(pRail);
				if(Rails_returnRailsHaveHomed(railsDb))
				{
					Rail_preset(pRail);
				}
			}
		}
	}
}

void Rail_setHomeAchieved(Rail* pRail, BOOL homeState )
{
	PARAM_CHECK( pRail, "Rail_setHomeAchieved");
	pRail->homeAchieved = homeState;
}

//*****************************************************************************
// void Rail_getHomeAchieved()
//
// Abstract:
// Rails that are not active or in Rail_MANUAL mode need to report that the rails are
// home when the railstate is home otherwise the mode will never switch to 
// preset railstate. If the rail is not in the Home railstate	 
//
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
BOOL Rail_getHomeAchieved(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getHomeAchieved", 0);
	if ( pRail->railState == Rail_HOME || pRail->railState == Rail_STOP )
	{
		if ( pRail->railActive == FALSE )
		{
			pRail->homeAchieved = TRUE;
//			presetShouldBeStable = FALSE;
		}
	}
	return pRail->homeAchieved;
}

//*****************************************************************************
// void Rail_getPresetAchieved()
//
// Abstract:
// Rails that are not active or in Rail_MANUAL mode need to report that the rails are
// home when the railstate is home otherwise the mode will never switch to 
// preset railstate. If the rail is not in the Home railstate	 
//
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
BOOL Rail_getPresetAchieved(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getPresetAchieved", 0);
	if ( pRail->railState == Rail_PRESET || pRail->railState == Rail_STOP )
	{
		if ( pRail->railActive == FALSE )
		{
			pRail->presetAchieved = TRUE;
		}
	}

	return pRail->presetAchieved;
}

//*****************************************************************************
// void Rail_setHomeDirection( HomeDirection homeInOrHomeOut )
//
// Abstract: 
// Each rail needs to know whether it is a home in or a home out rail. In order
// to simplify sequencing of rails to the home position all rails that are home
// in are completed first from low to high number rails. The process is reversed
// for home out rails starting at the higher numbered rails. In order for this
// to work rails are numbered with reference to their closest home in position,
// without this specifics about each rail is required.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_setHomeDirection(Rail* pRail, enum HomeDirection homeInOrHomeOut )
{
	PARAM_CHECK( pRail, "Rail_setHomeDirection");
	pRail->homeDirection = homeInOrHomeOut;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_process
			
			Allow each rail to process themselves dependent on the current system state.

 RETURNS:   void
------------------------------------------------------------------------*/
void Rail_process(Rail* pRail)
{
	BOOL bCannotMove;
	DWORD dwrdL1;
	DWORD dwrdL2;
	DWORD dwrdL3;
	DWORD dwrdL4;

	bCannotMove = FALSE;
	dwrdL1 = 0;
	dwrdL2 = 0;
	dwrdL3 = 0;
	dwrdL4 = 0;

	if( NULL != pRail )
	{
		if(pRail->railActive == TRUE)
		{
			Rail_getLastHomePosition(pRail);		// need to get last count when leaving limit switch.
			Rail_calculateCurrentPosition(pRail);
	
			switch(pRail->m_laneIndex)
			{
				case 1:
					if( FALSE == g_bLotProcessingEnable )
					{
						dwrdL1 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP),1);
					}
					else
					{
						dwrdL1 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0),1);
					}
	
					if(dwrdL1)
					{
						bCannotMove = TRUE;
					}
					break;
				case 2:
					if( FALSE == g_bLotProcessingEnable )
					{
						dwrdL2 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP),1);
					}
					else
					{
						dwrdL2 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1),1);
					}

 					if(dwrdL2)
					{
						bCannotMove = TRUE;
					}
					break;
				case 3:
					if( FALSE == g_bLotProcessingEnable )
					{
						dwrdL3 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP),1);
					}
					else
					{
						dwrdL3 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2),1);
					}

 					if(dwrdL3)
					{
						bCannotMove = TRUE;
					}
					break;
				case 4:
					if( FALSE == g_bLotProcessingEnable )
					{
						dwrdL4 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP),1);
					}
					else
					{
						dwrdL4 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3),1);
					}

 					if(dwrdL4)
					{
						bCannotMove = TRUE;
					}
					break;
				case 10:
					if( FALSE == g_bLotProcessingEnable )
					{
 						dwrdL1 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ0_NoLP),1);
						dwrdL2 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ1_NoLP),1);
						dwrdL3 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ2_NoLP),1);
						dwrdL4 = newBoardQueue_getBoardsInOvenCount_NoLP(&(g_dbContainer.boardQ3_NoLP),1);
					}
					else
					{
 						dwrdL1 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ0),1);
						dwrdL2 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ1),1);
						dwrdL3 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ2),1);
						dwrdL4 = newBoardQueue_getBoardsInOvenCount(&(g_dbContainer.boardQ3),1);
					}

					if(dwrdL1 || dwrdL2 ||
						dwrdL3 || dwrdL4 )
					{
						bCannotMove = TRUE;
					}
					break;
				default:
					break;
			}
			if(bCannotMove == TRUE )
			{
				Rail_disableOutput(pRail);
			}
			else
			{
				switch ( pRail->railState )
				{
					case Rail_STOP:	
						Rail_disableOutput(pRail);
						break;

					case Rail_MANUAL:
						Rail_disableOutput(pRail);
						if( pRail->incrementFlag )
						{
							pRail->trackPushButton = TRUE;
							Rail_doIncrement(pRail);
						}
						if( pRail->decrementFlag)
						{	
							pRail->trackPushButton = TRUE;
							Rail_doDecrement(pRail);
						}
						if ( pRail->trackPushButton == TRUE )
						{
							pRail->presetPosition = pRail->actualPosition;
						}
						break;
					case Rail_HOME:	
						pRail->presetAchieved = FALSE;
						Rail_goHome(pRail);
						break;
					case Rail_PRESET:
						if(pRail->bUsingRealPosition && !pRail->presetAchieved)//if we have elected not to move, do not attempt to move until flag is cleared
						{
							//also we will not move if we are in the ok band and we have not been instructed to move by either a job or position changes
							Rail_goPreset(pRail);
						}
						break;

					default:
						pRail->railState = Rail_STOP;
						Rail_disableOutput(pRail);
						break;
				}
				// jwf 12/18/00 this modification is required inorder to differentiate 
				// between the home in and home out condition
				// if direction flag is reverse and home is hit then disable output.
				if ( ( pRail->directionFlag == Rail_REVERSE ) && ( pRail->motorEnabled == TRUE ) && 
					( pRail->homeDirection == HomeIN ) )
				{
					Rail_checkHomeStatus(pRail);
					if ( pRail->homeAchieved == TRUE )
					{
						Rail_disableOutput(pRail);
						Rail_preset(pRail);
					}
				}
	    		if ( ( pRail->directionFlag == Rail_FORWARD ) && ( pRail->motorEnabled == TRUE ) && 	
					( pRail->homeDirection == HomeOUT ) )
				{
					Rail_checkHomeStatus(pRail);
					if ( pRail->homeAchieved == TRUE )
					{
						Rail_disableOutput(pRail);
						Rail_preset(pRail);
					}
				}
				//Rails will be disabled once the final position is achieved.  The rails can fall
				//into setpoint and stop up to five times in an attempt to achieve preset.  When the 
				//rail is at setpoint we will trigger the timer(counter) if another tolerence attempt is
				//made the timer will be reset.  Otherwise at 4.5 seconds the rail will be disabled.
				if(pRail->presetAchieved && ( pRail->m_lAtFinalPresetTimer < (PRESET_TIMEOUT + 5) ) )
				{
					pRail->m_lAtFinalPresetTimer++;
				}
				if(pRail->m_lAtFinalPresetTimer > PRESET_TIMEOUT)
				{
					pRail->m_bOutputEnable = FALSE; //final disable of output until new setpoint
				}
			}
		}
	}

	return;
}



//*****************************************************************************
//VOID Rail_calculateCurrentPosition()
//
// Abstract:
// The current position of the rail is the position that is relative to the 
// home switch. In order for this to work the counts from the home position
// must be accounted for calculating the relative position. 
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_calculateCurrentPosition(Rail* pRail)
{
//	UINT currentRailForSwitch;
	PARAM_CHECK( pRail, "Rail_calculateCurrentPosition");
	// this is the count returned by the Analogic board.
	pRail->currentPositionCounts = Rail_getCurrentAbsolutePosition(pRail);

	if ( pRail->railActive == FALSE )
	{
		// if the rail is not active there should be no counting.
		pRail->actualPosition = 0;
	}
	else
	{
		switch ( pRail->homeDirection )
		{
			// for home in counts the currentPositionCounts will always be greater than
			// home position counts.Need to account for rollover.
			case HomeIN:
				pRail->actualPosition = pRail->currentPositionCounts - pRail->homePositionCounts;
				// the case that the rails have been homed and the position
				// was greater than 2 billion and we have a transition from
				// a +2b to a -2b number for a difference of 1 at the crossover
				// from positive to negative.
				if ( pRail->currentPositionCounts < pRail->homePositionCounts ) 
				{
					if ( ((DWORD)pRail->homePositionCounts <  3000000000) && ((DWORD)pRail->homePositionCounts > 1000000000) )
					{
						pRail->actualPosition = (DWORD)pRail->currentPositionCounts - (DWORD)pRail->homePositionCounts;
					}
				}
				break;
			case HomeOUT:
			
					pRail->actualPosition = pRail->homeOffsetCounts - (pRail->homePositionCounts - pRail->currentPositionCounts);
					if ( pRail->homePositionCounts < pRail->currentPositionCounts )
					{
						if ( ((DWORD)pRail->homePositionCounts <  3000000000) && ((DWORD)pRail->homePositionCounts > 1000000000) )
						{
							pRail->actualPosition = pRail->homeOffsetCounts - ((DWORD)pRail->homePositionCounts - (DWORD)pRail->homePositionCounts);
						}
					}
			break;
			default:
				pRail->actualPosition = 0;
			break;
		}
	}

	if(pRail->lastCurrentPositionCounts != pRail->currentPositionCounts)
	{
		pRail->m_bRailMoved = TRUE;
	}
	else
	{
		pRail->m_bRailMoved = FALSE;
	}

	pRail->lastCurrentPositionCounts = pRail->currentPositionCounts;

	if ( pRail->actualPosition < 0 )
	{
		pRail->actualPosition = 0;
	}
}

//*****************************************************************************
//VOID Rail_getCurrentAbsolutePosition()
//
// Abstract:
// The current absolute position is the value returned from the Analogic 
// IO device. This is the number of counts that have occurred since the
// unit was last reset and taken to the home position. 
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
long Rail_getCurrentAbsolutePosition(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getCurrentAbsolutePosition", 0);
	if ( pRail->railActive == FALSE )
	{
		pRail->currentPositionCounts = 0;
	}
	else
	{
		switch ( pRail->railIdNo )
		{
			case RAIL0:
				pRail->currentPositionLSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_1_LSW);
				pRail->currentPositionMSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_1_MSW);
				pRail->currentPositionCounts = ((pRail->currentPositionMSW<<16)&0xFFFF0000) | (pRail->currentPositionLSW & 0xFFFF);
				break;
						
			case RAIL1:		
				pRail->currentPositionLSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_2_LSW);
				pRail->currentPositionMSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_2_MSW);
				pRail->currentPositionCounts = ((pRail->currentPositionMSW<<16)&0xFFFF0000) | (pRail->currentPositionLSW & 0xFFFF);
				break;

			case RAIL2:
				pRail->currentPositionLSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_3_LSW);
				pRail->currentPositionMSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_3_MSW);
				pRail->currentPositionCounts = ((pRail->currentPositionMSW<<16)&0xFFFF0000) | (pRail->currentPositionLSW & 0xFFFF);
				break;

			case RAIL3:
				pRail->currentPositionLSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_4_LSW);
				pRail->currentPositionMSW = (short) *ANALOGIN_GetAt(analogInputs, PULSE_COUNTER_4_MSW);
				pRail->currentPositionCounts = ((pRail->currentPositionMSW<<16)&0xFFFF0000) | ( pRail->currentPositionLSW & 0xFFFF);
				break;		
			default:
				break;
		}

	}
	return pRail->currentPositionCounts;
}

//*****************************************************************************
//VOID Rail_getLastHomePosition()
//
// Abstract:
// The home position as the rail heads away from the limit switch.
//
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_getLastHomePosition(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_getLastHomePosition");
	if ( pRail->railActive == FALSE )
	{
		pRail->homePositionCounts = 0;
	}
	else 
	{
		if ( *DIN_GetAt(digitalInputs, pRail->m_ioHomeSwitch) && pRail->lastHome == FALSE )
		{
			pRail->homePositionCounts = Rail_getCurrentAbsolutePosition(pRail);
		}
		else
		{
			if( pRail->newJob == FALSE )
			{
				pRail->lastHome = TRUE;
			}
		}
	}
}

//*****************************************************************************
// VOID Rail_goPreset( )
//
// Abstract:
// Move the rail to the preset recipe position.
// 
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************	
void Rail_goPreset(Rail* pRail )
{
	PARAM_CHECK( pRail, "Rail_goPreset");
	BOOL bContinue = TRUE;
	BOOL bAddSlow = FALSE;
	Rail_disableOutput(pRail); // always assume no movement;
	if( pRail->controlType == Manual )
	{
		pRail->presetAchieved = TRUE;
		pRail->presetShouldBeStable = TRUE;
		Rail_stop(pRail);
	}
	else
	{
		if(pRail->backOffHomeFlag) //we must move off the home position if a new setpoint is entered, but not in default condition
		{
			if(pRail->homeDirection == HomeIN)
			{
				Rail_setDirectionFlag(pRail,  Rail_FORWARD);
				if(Rail_onHomeSwitch(pRail))
				{
					pRail->backupForFirstRun = FALSE; //move off the home switch and do not backup
					Rail_enableOutput(pRail);
				}
				else
				{
					pRail->backOffHomeFlag = FALSE;
					if(!pRail->defaultHunt)//in this condition the rails will calculate a new stop factor before in position to start hunting
					{
						pRail->backupForFirstRun = TRUE;		
					}
				}
			}
			else
			{
				Rail_setDirectionFlag(pRail, Rail_REVERSE);
				if(Rail_onHomeSwitch(pRail))
				{
	/*if the rail is hunt out, home out and the setpoint is on the home switch, and we 
	enter a new setpoint that is within deadband distance of the home switch we will generate
	a color problem due to the timer never being initialized for the deadband test*/
					pRail->deadbandStartTime = Timer_getCurrentTime10ths(timer); 
					pRail->backupForFirstRun = FALSE;
					Rail_enableOutput(pRail);
				}
				else
				{
					pRail->backOffHomeFlag = FALSE;
					if(!pRail->defaultHunt)//in this condition the rails will calculate a new stop factor before in position to start hunting
					{
						pRail->backupForFirstRun = TRUE;
					}
				}
			}
			bContinue = FALSE;
		}
		if(bContinue)
		{
			bAddSlow = Rail_addSlowRailWarning(pRail, FALSE); //if we have not moved in .5 minutes while going to preset exit to prevent rail motor from powering on
			if(bAddSlow)
			{
				if(!pRail->useHomeOutHuntAlg)
				{
					Rail_goAutoModePreset(pRail);
				}
				else
				{
				Rail_goHuntDownAutoModePreset(pRail);
				}
			}
		}
	}
}

DWORD Rail_overShootTimer(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_overShootTimer", 0);
	return  Timer_getCurrentTime10ths(timer) - pRail->overShootTempTime; 
}

void Rail_resetOverShootTimeOut(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_resetOverShootTimeOut");
	pRail->overShootTempTime = Timer_getCurrentTime10ths(timer);
}

//*****************************************************************************
// void Rail_checkHomeTime()
//
// Abstract:
// The rail must achieve home position within 3 minutes or a warning will occur.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_checkHomeTime(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_checkHomeTime");
	if ( pRail->homeAchieved == FALSE && pRail->controlType == Auto && pRail->railState == Rail_HOME ) 
	{	
		if ( pRail->startHomeTime == 0 )
		{
			pRail->startHomeTime = Timer_getCurrentTime10ths(timer);
		}
		else
		{
			 pRail->elapsedHomeTime = Timer_getCurrentTime10ths(timer);
			 if ( pRail->elapsedHomeTime >= THREE_MINUTE_DELAY )
			 {
				pRail->m_bSPChanged =FALSE;
				pRail->alarm1id = AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAIL_3MIN_TIMEOUT_WARNING, pRail->railIdNo );
				pRail->startHomeTime = 0;
			 }
		}	
	}
	else
	{
		pRail->startHomeTime = 0;
	}
}

void Rail_home(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_home");
	if ( pRail->railActive )
	{
		pRail->railState = Rail_HOME;
	}
	else 
	{
		pRail->railState = Rail_STOP;
	}
}

void Rail_stop(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_stop");
	pRail->railState = Rail_STOP;
	Rail_disableOutput(pRail);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_preset::CloseEventLog


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_preset(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_preset");
	if ( pRail->railActive )
	{
		pRail->railState = Rail_PRESET;
	}
	else
	{
		Rail_stop(pRail);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_goHome
			
			The rail object being capable of taking care of itself when told to do 
			a task will do so provided that the rail is active and that the rails
			has set autoMode to TRUE.
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_goHome(Rail* pRail)
{	
	DWORD presetCounts;
	PARAM_CHECK( pRail, "Rail_goHome");
	
	Rail_checkHomeStatus(pRail);
	pRail->presetAttemptFailed = FALSE;
	pRail->backOffHomeFlag = FALSE;
	pRail->presetStableDelayTime = Timer_getCurrentTime10ths(timer);
	pRail->presetWarningAdded = FALSE;
	pRail->railState = Rail_HOME;

	if ( pRail->controlType == Manual )
	{
		pRail->homeAchieved = TRUE;
		Rail_disableOutput(pRail);
		Rail_stop(pRail);
		return;
	}

	if ( pRail->homeAchieved == FALSE && pRail->railActive == TRUE && pRail->controlType == Auto )
	{
		//checkHomeTime();
		if ( pRail->homeDirection == HomeIN )
		{
			Rail_setDirectionFlag(pRail, Rail_REVERSE );	
		}
		else // HomeOUT - increasing encoder counts.
		{
			Rail_setDirectionFlag(pRail, Rail_FORWARD );
		}
		if(Rail_addSlowRailWarning(pRail, FALSE) == TRUE)
		{
			Rail_enableOutput(pRail);
		}
		else
		{
			Rail_disableOutput(pRail);
		}
		Rail_addSlowRailWarning(pRail, FALSE);
	}
	else	// home has been achieved.
	{	
		pRail->startHomeTime = 0;
		Rail_disableOutput(pRail);
		Rail_stop(pRail);
		// jwf 1/31/01 Need to set these parameters inorder to preset the position in event 
		// of a home out condition
		if ( pRail->homeDirection == HomeOUT )
		{
			presetCounts = pRail->presetPosition;
			pRail->presetPosition = pRail->homeOffsetCounts;
			Rail_setPositionCounts(pRail, presetCounts, FALSE, FALSE );
			pRail->backOffHomeFlag = FALSE;
			pRail->railState = Rail_HOME;
		}
	}
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo );
	return;
}

//*****************************************************************************
// void Rail_checkHomeStatus
//
// Abstract: 
// When sending the rails home need to know if the limit switch has been hit to
// indicate a home position. This is only true when the rail is in auto. If
// the rail is in Rail_MANUAL then it will not automatically go home, so as far as
// the software is concerned it has achieved its' position.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_checkHomeStatus(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_checkHomeStatus");
	pRail->homeAchieved = FALSE;
	
	if (  pRail->railActive == FALSE )
	{
		pRail->homeAchieved = TRUE;

		Rail_stop(pRail);
	}
	else
	{
		if ( *DIN_GetAt(digitalInputs, pRail->m_ioHomeSwitch) == TRUE  )
		{
			if ( pRail->rail_homeTime == 0 )
			{
				pRail->rail_homeTime = Timer_getCurrentTime10ths(timer);
			}
			if ( Timer_getCurrentTime10ths(timer) - pRail->rail_homeTime > 5 )
			{
				pRail->homeAchieved = TRUE;
				pRail->m_hasHomed = 1;
				pRail->newJob = FALSE;
				pRail->lastHome = FALSE;
			}
		}	
		else
		{
			pRail->rail_homeTime = 0;
		}
	}
}

//*****************************************************************************
// void Rail_enableOutput()
//
// Abstract:
// Turn on the output relay to allow the motor to move.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_enableOutput(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_enableOutput");
	pRail->lastMotorEnabledTime = Timer_getCurrentTime10ths(timer);
	if ( pRail->directionChangeFlag == TRUE )
	{
		Rail_disableOutput(pRail);
		if ( ( pRail->lastMotorEnabledTime - pRail->lastActualOnTime ) > 40 )
		{
			pRail->directionChangeFlag = FALSE;
		}
	}
	else
	{
		pRail->lastActualOnTime = Timer_getCurrentTime10ths(timer);
		if(!pRail->bHardwareMode)  //No output during hardware control!
		{
			*DOUT_GetAt(digitalOutputs, pRail->m_uiOutput) = TRUE;
		}
		if ( pRail->railState == Rail_HOME && *DIN_GetAt(digitalInputs, pRail->m_ioHomeSwitch) == TRUE )
		{
			*DOUT_GetAt(digitalOutputs, pRail->m_uiOutput) = FALSE;
		}
	}
	pRail->motorEnabled = TRUE;
}

//*****************************************************************************
// void Rail_disableOutput()
//
// Abstract:
// Turn off the output relay to stop the motor from moving.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_disableOutput(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_disableOutput");
	pRail->motorEnabled = FALSE;
	if(pRail->railActive==TRUE)
	{
		*DOUT_GetAt(digitalOutputs, pRail->m_uiOutput) = FALSE;
	}
}
//*****************************************************************************
// void Rail_setDirectionFlag( DirectionFlag direction )
//
// Abstract:
// Set the relay that controls the direction of the rail movement.
//
// Programmer: Steven Young
// Date: 09/01/1998
//*****************************************************************************
void Rail_setDirectionFlag(Rail* pRail, enum DirectionFlag direction )
{
	PARAM_CHECK( pRail, "Rail_setDirectionFlag");

	if(pRail->railActive==TRUE)
	{
		if ( pRail->directionFlag != direction )
		{
			pRail->directionChangeFlag = TRUE;
			pRail->storedDirection = pRail->directionFlag = direction;
			Rail_disableOutput(pRail);
		}
		else
		{
			if(pRail->bHardwareMode)
			{
				*DOUT_GetAt(digitalOutputs, pRail->m_uiDirection) = Rail_FORWARD;
			}
			else
			{
				*DOUT_GetAt(digitalOutputs, pRail->m_uiDirection) = direction;
			}
		}
	}
}

void Rail_setNewJob(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_setNewJob");
	pRail->newJob = TRUE;
}

BOOL Rail_isPresetStable(Rail* pRail)
{
	BOOL state = FALSE;
	PARAM_CHECK_RETURN( pRail, "Rail_isPresetStable", 0);

	if(pRail->controlType == Manual || pRail->bHardwareMode)
	{
		return TRUE;
	}
	if( Rail_isInToleranceBand(pRail, TRUE, TRUE) || pRail->railState == Rail_MANUAL )
	{
		if( (Timer_getCurrentTime10ths(timer) - pRail->presetStableDelayTime) >= 150 )    // wait for 15 seconds for preset stable
		{

			state =  TRUE;
			pRail->m_bSPChanged=FALSE;
		}
	}
	else
	{
		pRail->presetStableDelayTime = Timer_getCurrentTime10ths(timer);
	}

	return state;
}
			
void Rail_doIncrement(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_doIncrement");
	if ( pRail->railState == Rail_MANUAL || pRail->controlType == Manual )
	{
		Rail_setDirectionFlag(pRail, Rail_FORWARD);
//Reseting the below flag, can cause the enable output to fail, there should be no reason
//to not enable output on a manual move
		pRail->directionChangeFlag = FALSE;
		Rail_enableOutput(pRail);
	}
}

void Rail_doDecrement(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_doDecrement");
	if ( pRail->railState == Rail_MANUAL || pRail->controlType == Manual )
	{
		Rail_setDirectionFlag(pRail, Rail_REVERSE);
//Reseting the below flag, can cause the enable output to fail, there should be no reason
//to not enable output on a manual move
		pRail->directionChangeFlag = FALSE;
		Rail_enableOutput(pRail);
	}
}

void Rail_increment(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_increment");
	pRail->incrementFlag = TRUE;
	pRail->decrementFlag = FALSE;
}

void Rail_decrement(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_decrement");
	pRail->incrementFlag = FALSE;
	pRail->decrementFlag = TRUE;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_resetIncDec

			clears the increment/decrement flags

 
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_resetIncDec(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_resetIncDec");
	pRail->incrementFlag = FALSE;
	pRail->decrementFlag = FALSE;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_addSlowRailWarning

			test to see if the rails have moved or not

 RETURNS:   BOOL - true to add the warning
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_addSlowRailWarning(Rail* pRail, BOOL bStartTime)
{
	PARAM_CHECK_RETURN( pRail, "Rail_addSlowRailWarning", 0);
	BOOL bReturn = TRUE;
	DWORD tim = 0;
	if(bStartTime)
	{
		pRail->m_SlowPresetTime = Timer_getCurrentTime10ths(timer);
	}
	else
	{
		if( ( pRail->m_bRailMoved == TRUE )  )
		{
			pRail->m_SlowPresetTime = Timer_getCurrentTime10ths(timer);
		}
		else
		{
			tim = Timer_getCurrentTime10ths(timer);
			if( ( tim - pRail->m_SlowPresetTime ) > ONEMINUTE_TIMEOUT)//.5 minute without movement
			{
				if(!pRail->presetWarningAdded && !pRail->presetShouldBeStable )
				{
					pRail->m_bSPChanged = FALSE;
					pRail->selfAckAlarmNo2 = AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAIL_1MIN_NOTATPRESET_WARNING, pRail->railIdNo);
					pRail->presetWarningAdded = TRUE;
				}
				bReturn = FALSE;
			}
		}
	}
	return bReturn;
}

void Rail_setOutputEnableFlag(Rail* pRail, BOOL bEnable)
{
	PARAM_CHECK( pRail, "Rail_setOutputEnableFlag");
	pRail->m_bOutputEnable = bEnable;
	pRail->toleranceAttempts = 0;
	pRail->m_bNewPresetPosition = TRUE;
	pRail->m_lAtFinalPresetTimer = 0;
//	presetShouldBeStable = FALSE;
}
////////////////////////////////////////////////////////////////////////////////////
//long Rail_isInFinalPosition(Rail* pRail)
//
//in tolerance band is not a sufficent test as the rail can still be hunting
//this function returns if it is in tolerance and has completed all hunting
////////////////////////////////////////////////////////////////////////////////////
long Rail_isInFinalPosition(Rail* pRail)
{
	long state = FALSE;
	PARAM_CHECK_RETURN( pRail, "Rail_isInFinalPosition", 0);
	if(pRail->m_bNotSequenced)
		return CONDITION_SUSPENDED;
	if(pRail->presetShouldBeStable) //should be in deadband, is not
	{
		if(pRail->bUsingRealPosition)
		{
			state = Rail_isPresetStable(pRail);
			if( !Rail_isInToleranceBand(pRail, TRUE, TRUE) )//1 mm 162 counts 2Xtolerence+10=170
			{
			//no yellow state when green state is viable
				state =  CONDITION_YELLOW; //yellow, setpoint and end user setpoint differ
			}
		}
		else
		{
			state = Rail_isFakePresetStable(pRail);
			if(!Rail_isInFakeToleranceBand(pRail))
			{
				state = CONDITION_YELLOW;
			}
		}
	}

	if((pRail->controlType == Manual) || pRail->bHardwareMode)
	{
		state = TRUE;
	}
	return state;
}
//sets the virtual position
void Rail_setFalsePositionCounts(Rail* pRail, LONG lPos)
{
	PARAM_CHECK( pRail, "Rail_setFalsePositionCounts");
	pRail->endUserPresetPosition = lPos;
}

void Rail_resetPresetStableTimer(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_resetPresetStableTimer");
	pRail->presetStableDelayTime = Timer_getCurrentTime10ths(timer);
}
////////////////////////////////////////////////////////////////////////////
//
//void Rail_setOvershootFactor(LONG newOvershoot)
//
//Tushar has observed that loading a new recipe will not set the overshoot
//factor for rail0 to 0.  This will occurr if the new setpoint is equal to the 
//old setpoint in the setposition routine.  To correct this I have added this 
//routine for the rails class to call from the allrailshome routine.  I will also
//set the value used by the prp3 for monitoring to uninitialized state (-1)
///////////////////////////////////////////////////////////////////////////
void Rail_setOvershootFactor(Rail* pRail, LONG newOvershoot)
{
	PARAM_CHECK( pRail, "Rail_setOvershootFactor");
	pRail->overShootFactor = newOvershoot;
	pRail->lStopFactor = pRail->overShootFactor;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_goAutoModePreset
			
			new go preset routine

 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_goAutoModePreset(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_goAutoModePreset");
	BOOL waitToEnableMotor = FALSE;
	BOOL sittingOnHomeFlag = FALSE;
	BOOL bOnHomeSwitch = FALSE;
	BOOL bInToleranceBand = FALSE;
	BOOL bBackup = FALSE;
	SHORT deadBandActionControl = 0;

	pRail->lStopFactor = pRail->overShootFactor;//for prp3 tracking, could use overshootfactor directly as it is now public

	if(pRail->bDontAllowNewStopFactor)
	{
		if( ( pRail->actualPosition + pRail->nTolerance ) <= pRail->presetPosition )
		{
			pRail->bDontAllowNewStopFactor = FALSE;
		}
	}

	if(pRail->backupForFirstRun)//Backup until preset, start default backup go
	{
		Rail_backingUpForInitialPresetAttempt(pRail);
	}
	bOnHomeSwitch = Rail_onHomeSwitch(pRail);
	bInToleranceBand = Rail_isInToleranceBand(pRail, FALSE, TRUE);
	if( bOnHomeSwitch && bInToleranceBand )//at home, in deadband life is good
	{
		if( ( pRail->homePositionCounts == pRail->presetPosition ) || pRail->defaultHunt)
		{
			//if home out hunting as home in refuse the toleranceband for anything but an exact match
			pRail->presetAchieved = TRUE;
			pRail->presetShouldBeStable = TRUE;//we should have achieved preset
			waitToEnableMotor = TRUE;
			sittingOnHomeFlag = TRUE;
		}
	}

	if ( ( pRail->actualPosition > (pRail->presetPosition - pRail->overShootFactor) ) && !pRail->backingUp &&
		!sittingOnHomeFlag)
	{
		pRail->lastRailState = deadBandActionControl = Rail_whatIsDeadbandState(pRail); 
		if(deadBandActionControl) //not waiting for timeout
		{
			if(deadBandActionControl == DEADBANDSTATE_OVERSHOT || deadBandActionControl == DEADBANDSTATE_UNDERSHOT)//overshoot or undershoot
			{
				if(!pRail->bDontAllowNewStopFactor)
				{
					if(!pRail->bNoFailureToAchievePresetWarning)//jog cycle we dont care
					{
						if(pRail->toleranceAttempts < pRail->maxHunt)//hunt 0-5 times
						{
							pRail->overShootFactor = Rail_calculateNewStopFactor(pRail, pRail->overShootFactor, deadBandActionControl);
							Rail_backup(pRail, TRUE);
							pRail->toleranceAttempts++;
						}
						else
						{
							if(!pRail->presetWarningAdded)
							{
								pRail->m_bSPChanged = FALSE;
								pRail->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAIL_FAILED_PRESET, pRail->railIdNo);
								pRail->presetWarningAdded = TRUE;
							}
						}
						pRail->m_bNewPresetPosition = FALSE;
						pRail->m_bOutputEnable = FALSE;  //we can't achieve preset
						pRail->presetShouldBeStable = TRUE;//we should have achieved preset
					}
				}
			}
			else if(deadBandActionControl == DEADBANDSTATE_INDEADBAND) //were in tolerance, our timer has expired, life is good
			{
				pRail->presetAchieved = TRUE;
				pRail->presetShouldBeStable = TRUE;//we should have achieved preset
				//life is good 
			}
		}
		else //still waiting on deadband timer
		{
			waitToEnableMotor = TRUE;
		}	
	}
	else //were moving forward or backing up
	{
		pRail->deadbandStartTime = Timer_getCurrentTime10ths(timer);  //record time for coast testing
		if(!pRail->backingUp)
		{
			Rail_setDirectionFlag(pRail, Rail_FORWARD);
		}
		else
		{
			Rail_setDirectionFlag(pRail, Rail_REVERSE);
		}
		bBackup = Rail_backup(pRail, FALSE);
		if(( bBackup || !waitToEnableMotor) && !sittingOnHomeFlag)
		{
			Rail_enableOutput(pRail);
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_whatIsDeadbandState
			
			calculates if we are in tolerance, overshoot, undershoot, or indeterminate

 RETURNS:   short, deadband enumeration
 SEE ALSO:
------------------------------------------------------------------------*/
SHORT Rail_whatIsDeadbandState(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_whatIsDeadbandState", 0);
	DWORD deadbandTime = Timer_getCurrentTime10ths(timer);
	BOOL bInTolerance = FALSE;
	short sReturn = DEADBANDSTATE_INIT;		

	if( ( deadbandTime - pRail->deadbandStartTime) > THREE_SECONDS)
	{
		bInTolerance = Rail_isInToleranceBand(pRail, TRUE, TRUE);
		if(bInTolerance)
		{
			sReturn = DEADBANDSTATE_INDEADBAND;//indeadband
		}
		else
		{
			if(pRail->actualPosition > pRail->presetPosition)//overshoot homein, undershoot home out
			{
				sReturn = DEADBANDSTATE_OVERSHOT;
			}
			else//undershoot
			{
				sReturn = DEADBANDSTATE_UNDERSHOT;
			}
		}
	}
	return sReturn;
}

//Correction type indicates overshoot or undershoot 2, 3 currently
DWORD Rail_calculateNewStopFactor(Rail* pRail, LONG oldStopFactor, short CorrectionType)
{ 
	PARAM_CHECK_RETURN( pRail, "Rail_calculateNewStopFactor", 0);
	switch(CorrectionType)
	{
	case 2:
		return ( oldStopFactor + (pRail->actualPosition - pRail->presetPosition) - pRail->eOvershootFactor);//eOvershootFactor 20 counts, using for both over and under
		break;
	
	case 3:
		return (oldStopFactor + (pRail->actualPosition - pRail->presetPosition) - pRail->eOvershootFactor);//eOvershootFactor 20 counts, using for both over and under
		break;
	
	default:
		return oldStopFactor + (pRail->actualPosition - pRail->presetPosition);
		break;

	}
}

DWORD Rail_huntOutcalculateNewStopFactor(Rail* pRail, LONG oldStopFactor, short CorrectionType)
{
	PARAM_CHECK_RETURN( pRail, "Rail_huntOutcalculateNewStopFactor", 0);
	switch(CorrectionType)
	{
	case 2:
		return ( oldStopFactor + pRail->eOvershootFactor + pRail->presetPosition - pRail->actualPosition);//eOvershootFactor 20 counts, using for both over and under
		break;
	
	case 3:
		return (oldStopFactor + pRail->eOvershootFactor + pRail->presetPosition - pRail->actualPosition);//eOvershootFactor 20 counts, using for both over and under
		break;
	
	default:
		return oldStopFactor + pRail->presetPosition - pRail->actualPosition;
		break;

	}
}

BOOL Rail_backup(Rail* pRail, BOOL startBackingUp)
{
	BOOL bOnHomeTrue = FALSE;
	LONG lSP, lPV, lBackDist;
	PARAM_CHECK_RETURN( pRail, "Rail_backup", 0);

	lSP = pRail->presetPosition;
	lPV = pRail->actualPosition;
	lBackDist = pRail->backDistance;

	if(startBackingUp)
	{
		Rail_setDirectionFlag(pRail, Rail_REVERSE);
		pRail->backingUp = TRUE;
		pRail->backupStartTime = Timer_getCurrentTime10ths(timer);
		return FALSE;
	}
	else
	{
		bOnHomeTrue = Rail_onHomeSwitchandDefaultHunt(pRail);
//		if((timer.getCurrentTime10ths() - backupStartTime) > 30)
		if((lPV <= (lSP - lBackDist))|| bOnHomeTrue)
		{
			Rail_setDirectionFlag(pRail, Rail_FORWARD);
			pRail->backingUp = FALSE;	
		}
		else
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL Rail_backupForHuntOut(Rail* pRail, BOOL startBackingUp)
{
	BOOL bOnHomeTrue = FALSE;
	PARAM_CHECK_RETURN( pRail, "Rail_backupForHuntOut", 0);

	if(startBackingUp)
	{
		Rail_setDirectionFlag(pRail, Rail_FORWARD);
		pRail->backingUp = TRUE;
		pRail->backupStartTime = Timer_getCurrentTime10ths(timer);
		return FALSE;
	}
	else
	{
		bOnHomeTrue = Rail_onHomeSwitchandDefaultHunt(pRail);
//		if((timer.getCurrentTime10ths() - backupStartTime) > 30)
		if((pRail->actualPosition >= (pRail->presetPosition + pRail->backDistance)) || bOnHomeTrue)
		{
			Rail_setDirectionFlag(pRail, Rail_REVERSE);
			pRail->backingUp = FALSE;	
		}
		else
		{
			return TRUE;
		}
	}
	return FALSE;
}

void Rail_backingUpForInitialPresetAttempt(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_backingUpForInitialPresetAttempt");
	pRail->backingUp = TRUE;

	if(!Rail_onHomeSwitch(pRail))
	{
		Rail_setDirectionFlag(pRail, Rail_REVERSE);
		Rail_backup(pRail, TRUE);//to reset backup timeout to prevent direction reverse
	}
	if(pRail->actualPosition < (pRail->presetPosition - pRail->overShootFactor))//beyond testing area start normal backup routine
	{
		if(!Rail_onHomeSwitch(pRail))
			Rail_backup(pRail, TRUE);
		pRail->backupForFirstRun = FALSE;
	}
	if(Rail_onHomeSwitchandDefaultHunt(pRail))
		pRail->backupForFirstRun = FALSE;
}

void Rail_backingUpForInitialPresetAttemptHuntOut(Rail* pRail)//backing up is really moving forward
{
	PARAM_CHECK( pRail, "Rail_backingUpForInitialPresetAttemptHuntOut");
	pRail->backingUp = TRUE;

	if(!Rail_onHomeSwitch(pRail))
	{
		Rail_setDirectionFlag(pRail, Rail_FORWARD);
		Rail_backupForHuntOut(pRail, TRUE);//to reset backup timeout to prevent direction reverse
	}
	if(pRail->actualPosition > (pRail->presetPosition + pRail->overShootFactor))//beyond testing area start normal backup routine
	{
		if(!Rail_onHomeSwitch(pRail))
			Rail_backupForHuntOut(pRail, TRUE);
		pRail->backupForFirstRun = FALSE;
	}
	if(Rail_onHomeSwitchandDefaultHunt(pRail) && !Rail_isInToleranceBand(pRail, TRUE, FALSE))
		pRail->backupForFirstRun = FALSE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_goHuntDownAutoModePreset
			
			reverse hunt for auto mode

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_goHuntDownAutoModePreset(Rail* pRail)
{
	BOOL waitToEnableMotor = FALSE;
	SHORT deadBandActionControl = 0;
	BOOL sittingOnHomeFlag = FALSE;
	BOOL bOnHomeSwitch = FALSE;
	BOOL bBackupForHunt = FALSE;
	PARAM_CHECK( pRail, "Rail_goHuntDownAutoModePreset");

	pRail->lStopFactor = pRail->overShootFactor;//for prp3 tracking, could use overshootfactor directly as it is now public

	if(pRail->bDontAllowNewStopFactor)
	{
		if( pRail->actualPosition >= ( pRail->presetPosition + pRail->pTolerance ) )
		{
			pRail->bDontAllowNewStopFactor = FALSE;
		}
	}
			
	if( pRail->backupForFirstRun )//Backup until preset, start default backup go
	{
		Rail_backingUpForInitialPresetAttemptHuntOut(pRail);
	}
	bOnHomeSwitch = Rail_onHomeSwitch(pRail);
	if( bOnHomeSwitch && ( pRail->actualPosition == pRail->presetPosition ) )//at home, in deadband life is good
	{
		pRail->presetAchieved = TRUE;
		pRail->presetShouldBeStable = TRUE;//we should have achieved preset
		waitToEnableMotor = TRUE;
		sittingOnHomeFlag = TRUE;
	}
	if ( pRail->actualPosition < (pRail->presetPosition + pRail->overShootFactor) &&
		!pRail->backingUp)
	{
		pRail->lastRailState = deadBandActionControl = Rail_whatIsDeadbandState(pRail); 
		if(deadBandActionControl) //not waiting for timeout
		{
			if( ( deadBandActionControl == DEADBANDSTATE_OVERSHOT ) || ( deadBandActionControl == DEADBANDSTATE_UNDERSHOT ) )//overshoot or undershoot
			{
				if(!pRail->bDontAllowNewStopFactor)
				{
					if(!pRail->bNoFailureToAchievePresetWarning)
					{
						if(pRail->toleranceAttempts < pRail->maxHunt)//hunt 0-5 times
						{
							pRail->overShootFactor = Rail_huntOutcalculateNewStopFactor(pRail, pRail->overShootFactor, deadBandActionControl);
							Rail_backupForHuntOut(pRail, TRUE);
							(pRail->toleranceAttempts)++;
						}
						else
						{
							if(!pRail->presetWarningAdded)
							{
								pRail->m_bSPChanged = FALSE;
								pRail->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, RAIL_FAILED_PRESET, pRail->railIdNo);
								pRail->presetWarningAdded = TRUE;
							}
						}
						pRail->m_bNewPresetPosition = FALSE;
						pRail->m_bOutputEnable = FALSE;  //we can't achieve preset
						pRail->presetShouldBeStable = TRUE;//we should have achieved preset
					}
				}
			}
			else if(deadBandActionControl == DEADBANDSTATE_INDEADBAND) //were in tolerance, our timer has expired, life is good
			{
				pRail->presetAchieved = TRUE;
				pRail->presetShouldBeStable = TRUE;//we should have achieved preset
				//life is good 
			}
		}
		else //still waiting on deadband timer
		{
			waitToEnableMotor = TRUE;
		}	
	}
	else //were moving forward or backing up
	{
		pRail->deadbandStartTime = Timer_getCurrentTime10ths(timer);  //record time for coast testing
		if(!pRail->backingUp)
		{
			Rail_setDirectionFlag(pRail, Rail_REVERSE);
		}
		else
		{
			Rail_setDirectionFlag(pRail, Rail_FORWARD);
		}
		bBackupForHunt = Rail_backupForHuntOut(pRail, FALSE);
		if( ( bBackupForHunt || !waitToEnableMotor) && !sittingOnHomeFlag)
		{
			Rail_enableOutput(pRail);
		}
	}
	return;
}

void Rail_setHuntPreference(Rail* pRail, BOOL defaultDir)
{
	PARAM_CHECK( pRail, "Rail_setHuntPreference");
	pRail->defaultHunt = defaultDir;
	pRail->useHomeOutHuntAlg = (pRail->defaultHunt ? pRail->homeDirection : !pRail->homeDirection); 

}

//When reversing special handling is neccessary near the home switch.
//if we run in reverse we must bypass the on home switch logic, thus this
//function was born
BOOL Rail_onHomeSwitchandDefaultHunt(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_onHomeSwitchandDefaultHunt", 0);
	return (pRail->defaultHunt && Rail_onHomeSwitch(pRail));
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_onHomeSwitch

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_onHomeSwitch(Rail* pRail)
{
	BOOL bOnHomeSwitch = FALSE;
	PARAM_CHECK_RETURN( pRail, "Rail_onHomeSwitch", 0);
	bOnHomeSwitch = *DIN_GetAt(digitalInputs, pRail->m_ioHomeSwitch);
	return bOnHomeSwitch;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_isInToleranceBand

			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_isInToleranceBand(Rail* pRail, BOOL applyNeg, BOOL applyPos)
{
	PARAM_CHECK_RETURN( pRail, "Rail_isInToleranceBand", 0);
	LONG lPV = 0; 
	LONG lSP = 0; 
	LONG lNT = 0;
	LONG posToleranceLocal = (LONG)pRail->pTolerance;
	lPV = pRail->actualPosition;
	lSP = pRail->presetPosition;
	lNT = pRail->nTolerance;
	BOOL bReturn = FALSE;
	if(!applyNeg)
	{
		pRail->nTolerance = 0;
	}
	lNT = lNT + 15;
	if(!applyPos)
	{
		posToleranceLocal = 0;
	}	
	 
	if((lPV >= (lSP - lNT)) && (pRail->actualPosition <= (pRail->presetPosition + posToleranceLocal)))
	{
		bReturn =  TRUE;
	}
	else
	{
		bReturn =  FALSE;
	}
	return bReturn;
}

//used to determine tolerance when the enduser does not move rails
BOOL Rail_isInFakeToleranceBand(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_isInFakeToleranceBand", 0);
	return ((pRail->actualPosition  >= (pRail->endUserPresetPosition - pRail->nTolerance)) && (pRail->actualPosition <= (pRail->endUserPresetPosition + pRail->pTolerance)));
}

BOOL Rail_isFakePresetStable(Rail* pRail)
{
	BOOL state = FALSE;
	PARAM_CHECK_RETURN( pRail, "Rail_isFakePresetStable", 0);

	if( Rail_isInFakeToleranceBand(pRail) || pRail->railState == Rail_MANUAL )
	{
		if( (Timer_getCurrentTime10ths(timer) - pRail->presetStableDelayTime) >= 150 )    // wait for 15 seconds for preset stable
		{
			state =  TRUE;
			pRail->m_bSPChanged=FALSE;
		}
	}
	else
	{
		pRail->presetStableDelayTime = Timer_getCurrentTime10ths(timer);
	}

	return state;	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_manual

			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Rail_manual(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_manual");
	if ( pRail->railActive )
	{
		pRail->railState = Rail_MANUAL;
	}
}

void Rail_clearWarnings(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_clearWarnings");
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo );
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo2 );
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->alarm1id );
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->alarm2id );
}

//////////////////////////////////////////////////////////////////////////
//
//Rail_process_hardware()
//
//A simplified process loop used when the hardware control is engaged, currently
//it will only produce a pv
//////////////////////////////////////////////////////////////////////////
void Rail_process_hardware(Rail* pRail)
{
	PARAM_CHECK( pRail, "Rail_process_hardware");
	Rail_calculateCurrentPosition(pRail);
}

void Rail_setHomeDistanceCounts(Rail* pRail, DWORD countsFrom0offset)
{
	PARAM_CHECK( pRail, "Rail_setHomeDistanceCounts");
	pRail->homeOffsetCounts = countsFrom0offset; 
}

DWORD Rail_getHomeDistanceCounts(Rail* pRail) 
{
	PARAM_CHECK_RETURN( pRail, "Rail_getHomeDistanceCounts", 0);
	return pRail->homeOffsetCounts;
}

DWORD Rail_getPresetPosition(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getPresetPosition", 0);
	return pRail->presetPosition; 
}

DWORD Rail_getPositionCounts(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getPositionCounts", 0);
	return pRail->actualPosition; 
}

void Rail_setControlType(Rail* pRail, enum ControlType autoOrManual )
{
	PARAM_CHECK( pRail, "Rail_setControlType");
	pRail->controlType = autoOrManual; 
}

enum HomeDirection Rail_getHomeDirection(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getHomeDirection", 0);
	return pRail->homeDirection; 
}

void Rail_setActive(Rail* pRail, BOOL activeState ) 
{
	PARAM_CHECK( pRail, "Rail_setActive");
	pRail->railActive = activeState; 
}

BOOL Rail_getActive(Rail* pRail) 
{
	PARAM_CHECK_RETURN( pRail, "Rail_getActive", 0);
	return pRail->railActive; 
}

enum RailStates Rail_getRailState(Rail* pRail) 
{
	PARAM_CHECK_RETURN( pRail, "Rail_getRailState", 0);
	return pRail->railState; 
}

BOOL Rail_getHomeHuntUsed(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getHomeHuntUsed", 0);
	return pRail->useHomeOutHuntAlg;
}
void Rail_setPresetWarningFlag(Rail* pRail, BOOL bDisableWarning)
{
	PARAM_CHECK(pRail, "Rail_setPresetWarningFlag");
	pRail->bNoFailureToAchievePresetWarning = bDisableWarning;
}

void Rail_clearMovementWarning(Rail * pRail)
{
	AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pRail->selfAckAlarmNo2 );
}

void Rail_SetLaneIndex(Rail* pRail, UINT index)
{
	if ( pRail )
	{
		pRail->m_laneIndex = index;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_getSPChanged

			We cannot directly read the setpoint changed variable
			due to hardware control.  In hardware control the smema
			and light tower should be on.  Once the control is terminated
			the test should procede as ussual.  Thus this function will
			filter the boolean

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_getSPChanged(Rail* pRail)
{
	BOOL bReturn = pRail->m_bSPChanged;
	if(pRail->bHardwareMode)
	{
		bReturn = FALSE;
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_jogPositionAchieved
			
			determines if a rail has moved far enough in jog (exercise) mode

 RETURNS:   True if achieved preset or greater
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_JoggedOut(Rail* pRail)
{
	BOOL bReturn = FALSE;
	if(pRail->homeDirection == HomeIN) //Home in actual position must exceed/equal preset
	{
		if(pRail->actualPosition >= pRail->presetPosition)
		{
			bReturn = TRUE;
		}
	}
	if(pRail->homeDirection == HomeOUT)//actual position must be less than/equal preset
	{
		if(pRail->actualPosition <= pRail->presetPosition)
		{
			bReturn = TRUE;
		}
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Rail_isHomeInType
			
			are we a home in? home in need the home value added to the pos count

 RETURNS:   BOOL true if home in, false otherwise
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Rail_isHomeInType(Rail* pRail)
{
	PARAM_CHECK_RETURN( pRail, "Rail_getHomeDirection", 0);
	BOOL bReturn = FALSE;
	if(pRail->homeDirection == HomeIN)
	{
		bReturn = TRUE;
	}
	return bReturn;
}
