/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __BELT_H__
#define __BELT_H__

#include "typedefdefine.h"
#include "pid.h"
#include "smema.h"

enum CountMethod { PULSE_COUNT = 1, FREQ_TO_ANALOG = 2, OPEN_LOOP_TIMER = 3 };

#define BELT_INDEX_A 1
#define BELT_INDEX_B 2
#define DUAL_BUFFER_SIZE 200
#define INPUT_DIFF_TOLERANCE 2
#define MOTOR_FAILURE_COUNTS 2 //Allowance for electical noise on inputs
#define PROC_MODE_HYBRID 0
#define PROC_MODE_A 1
#define PROC_MODE_B 2


//******************************************************************************
// Class:Belt
//
// Abstract:
// The belt transports the boards through the oven at a specified rate
// this module will be developed to hold 256 boards.
// There can be two belts.
// The IO will vary for each belt.
// Characteristics of Belt: Speed and Number of boards
// During a board drop or other system problem the belt shall be increased to
// max speed 100%. A signal shall be sent to change the belt parameters under
// these conditions vs scanning to find out if the condition exists.
// The belt can never go in reverse.
// Belt speed is controlled by an optional PID Loop.
// For Freg to analog conversion an offset of 4 ma is at 0hz
// At max speed of 40 hz the output current is 20ma.
// These outputs are into a precision 3ohm resistor resulting in a 12mv to 60mv
// output. <=12mv = 0cm/sec, 60mv = 188cm/minute = 3.133cm/sec.
// At max speed there are 40pulses/sec = 2400pulses/minute
// Pulses/cm = 2400/188 = 12.76pulses/cm.
//
//	Programmer: Steven Young
// Date: 03/02/1998
//******************************************************************************
typedef struct _Belt_
{
//private:

	UCHAR		 	beltID;				// different belt no's require different IO points

	PID				pid;
	BOOL			autoMode;			// run open or closed loop
	BOOL			pidEnabled;
	BOOL			beltActive;			// either one or two belts are active.
	BOOL			beltIOConfigured;
	LONG			beltTPOoutput;
	WORD*			pBeltTPOout;
	WORD			*pBeltTPOoutB;
	WORD			wrdBeltOutput;
	WORD			wrdBeltOutput2;
	WORD			manualTPOcounts;
	DWORD			speedInCMsPerMin;
	DWORD			StandbySpeedInCMsPerMin;
	DWORD			nonStandbySpeedInCMsPerMin;
	LONG			actualSpeedCountsPerSec;	// these variables are unsigned long becaus we cannot have 
	LONG			setSpeedCountsPerSec;		// negative speed counts. 
	LONG			actualSpeedCounts_x_100;
	LONG			YLastOutput;				// the Yk -1 output of our filter
	LONG			filteredActualSpeedCounts_x_100; 
	LONG			setSpeedCounts_x_100;
	LONG			setStandbyCounts_x_100;
	LONG			nonStandbyCounts_x_100;
	WORD			previousSetSpeedCountsPerSec;
	DWORD			jobNo;
	DWORD			summOfSpeeds;
	DWORD			startPositionCounts;
	DWORD			startPositionCountsB;
	DWORD			currentPositionCounts;	//	the current position from analogic board. 
	DWORD			currentPositionCountsB;	
	DWORD			elapsedPositionCounts;  //  the currentPositionCounts - startPositionCounts.
	DWORD			sumOfPositionCounts;	//ten segment counts
	DWORD 			currentCountsLSW;	//			"
	DWORD			currentCountsMSW;	//			"
	DWORD			currentTimePosition;
	DWORD			speedSimTime;
	DWORD			simulatedEncoderPulses;
	DWORD			m_dwrdRemainder;
	DWORD			maxCounts;
	DWORD			minCounts;
	DWORD			maxMv;
	DWORD			minMv;
	DWORD			fourBillionElapsedPositionCountTics;
	DWORD			startOverTime;
	DWORD			startUnderTime;
	DWORD			diffTimeOver;
	DWORD			diffTimeUnder;
	DWORD			deadBandDelay;
	DWORD           selfAckAlarmNo;
	BOOL			overFlag;
	BOOL			underFlag;
	BOOL			beltInitialized;	// need to get initial count from encoder be careful of negative values		
	UINT			maxOutputPercent;	// max speed for belt
	UINT			minOutputPercent;	// min speed for belt
	enum CountMethod		countMethod;		// either pulse or freq to analog conversion.
	BOOL			openLoopSystem;		// need to know if this is an open loop system for board processing.

	WORD		*	pBeltPosMSW;		// pointers into the io table to get the current
	WORD		*	pBeltPosLSW;        // belt position.
	WORD		*   pBeltSpeed;			
	WORD		*	pBeltSpeedB;
	WORD		*	pBeltPosMSW_B;
	WORD		*	pBeltPosLSW_B;

	LONG			m_lSchedulerLoopCounter; 	//Timer for indeadband pid execution
	DWORD			hiDeviationTimer;
	DWORD			loDeviationTimer;
	DWORD			m_iDualMotorFailTime;

	// warnings and alarms.
	long		hiProcessOffsetCounts;
	long			loProcessOffsetCounts;
	long			hiDeviationOffsetCounts;
	long			loDeviationOffsetCounts;
	long			hiWarningOffsetCounts;
	long			loWarningOffsetCounts;
	long			hiDeadBandOffsetCounts;
	long			loDeadBandOffsetCounts;

	BOOL			hiProcessAlarmEnabled;
	BOOL			loProcessAlarmEnabled;
	BOOL			hiDeviationAlarmEnabled;
	BOOL			loDeviationAlarmEnabled;
	BOOL			hiDeviationWarningEnabled;
	BOOL			loDeviationWarningEnabled;
	BOOL			inDeadBand;
	
//4 Rail belt must use different manner to determine counts (the input is tied to a thermal input) boolean below
//switches routine
	BOOL			m_bDoFourRailCalc;			

//Copied from belt info for 3rd party control
	UINT			m_iInLo;
	UINT			m_iInHi;
	UINT			m_iPulsesPerCmBelt;
	UINT			m_iMaxFreq;
	UINT			m_iRangeHiSpeed;
	UINT			m_iRangeLoSpeed;
	UINT			m_iRangeHiPercent;
	UINT			m_iRangeLoPercent;

//added to limit test the for slow pid control
	LONG			m_lSlowPidRange;
	BOOL			m_bDoFastCalculation;

//adding a flag so the belts will switch from the slow loop control to the fast
//loop control when the oven moves from cooldown to active recipe
//changed the fast pid will be triggered by a recipe change or a setpoint change
	BOOL			m_bswitchToFastControl;
	DWORD			ovenJobNo;
	BOOL			m_bBeltMustStop;
	DWORD			m_dwrdWarnTime;
	DWORD			m_dwrdDbDevTime;

//when adjusting setpoints lower the belts would achive deadband, switch to slow control
//and undershoot taking 1+minutes to come back into deadband added int to allow the switch
//to occur only when continous deadband achieved
	UINT			m_iNumberofContinousTimesWithinDeadband;

	UINT			iStartupGroup;
	BOOL			bBeltSequenced; //Indicates that the belt is sequenced heat zone style
	BOOL			beltHasSequenced;  //TRUE if the belt is not sequenced or startup group has elapsed
	BOOL			m_bSuspendProcessing;
	BOOL			m_bHighDevInput;
	BOOL			m_bLowDevInput;
	BOOL			m_bHybridOn;
	BOOL			m_bDualMotors;
	UINT			m_iDeviationCOunt;
	UINT			m_iMotorFailCount;
	UINT			m_iDeviationCOuntL;
	UINT			m_iMotorFailCountL;
	UINT			m_iOutputBehave;
	UINT			m_iWhichOutput;
	UINT			m_iNumberOfSlowLoops;
	WORD			inputABuffer[DUAL_BUFFER_SIZE];
	WORD			inputBBuffer[DUAL_BUFFER_SIZE];
	WORD*			ptrCurrentInputA;
	WORD*			ptrCurrentInputB;
	UINT			uintPtrALocation;
	UINT			uintPtrBLocation;
	UINT			indexA;
	UINT			indexB;
	UINT			procMode;
	BOOL			secondaryMotor;
	UINT			m_iTimesSinceMotorFailed;
	UINT			m_iTimesSinceInputDeviated;
	BOOL			m_bDualStartTest;


	WORD			dummyTPODual;
	int				m_iMotorTestTime;												
	int				m_iTestTime;		
	BOOL			bTempzonesSequenced;		
	DWORD			dualBeltTimer10ths;
	BOOL			m_bUseHighOutput;
	LONG			switchSpeed;

	BOOL 			m_bStoppedForSmema;
	DWORD			m_dwrdOffDist;
	BOOL			m_bWantStopForSmema;
	BOOL			m_bSmemaRequest[MAX_SMEMA_LANES][2];
	BOOL			m_bSmemaRequestHistory[MAX_SMEMA_LANES][2];
	BOOL			m_bSmemaOff[MAX_SMEMA_LANES][2];
	SMEMA*			m_smemaLanes[MAX_SMEMA_LANES];
	DWORD			m_dwrdCureStart[MAX_SMEMA_LANES][2];
	DWORD			m_dwrdCureOffTPO;
	DWORD			m_dwrdTemp;
	BOOL mbStandbyMode;
	DWORD			mTPOStandbyOLCounts;
	DWORD 			openLoopCounts;
	DWORD 			nominalSpeedCount;
	DWORD			m_mvFractionalRemainder;

	// digital belt stop
	DWORD m_digitalStopSensor;
	BOOL m_digitalStopAsserted;
	DWORD m_digitalStopSpeedCounts_x_100;
	DWORD m_digitalStopSpeedInCMsPerMin;
	DWORD m_digitalStopSelfAckAlarmNo;
} Belt;

void	Belt_setProcMode(Belt* pBelt,UINT pMode);
void	Belt_beltPositionCalculation(Belt* pBelt); 
void	Belt_calculateBeltSpeed(Belt* pBelt);
void	Belt_checkAlarms(Belt* pBelt);
void	Belt_SetpointDeviationDelayFilter(Belt* pBelt);
void  	Belt_checkSelfAcknowledgement(Belt* pBelt);
void	Belt_beltSpeedFilterCalc(Belt* pBelt);
void	Belt_init(Belt* pBelt);
		
const DWORD		Belt_getPosition(Belt* pBelt);
void	Belt_setBeltActive(Belt* pBelt, BOOL state);
BOOL	Belt_getBeltActive(Belt* pBelt);
BOOL	Belt_configureBeltIO(Belt* pBelt);		
void	Belt_process(Belt* pBelt);
void 	Belt_positionOnlyProcess(Belt* pBelt);
BOOL	Belt_MoveTo(Belt* pBelt, UINT whichInput, UINT moveTo);
BOOL	Belt_processDualMotor(Belt* pBelt);
void Belt_standbyCountsOpenLoop(Belt* pBelt, DWORD counts);

void	Belt_setAutoMode(Belt* pBelt, UINT automode/* = 1*/ );
BOOL	Belt_getAutoMode(Belt* pBelt);
void 	Belt_clearSelfAck(Belt* pBelt);
void	Belt_setBeltCounts(Belt* pBelt, DWORD OCXbeltCountsCalculation );
void	Belt_setCountMethod(Belt* pBelt, enum CountMethod beltPositionCountMethod );		
BOOL	Belt_setManualTPOcounts(Belt* pBelt, DWORD tpoCounts ); 
DWORD	Belt_getTPOoutputCounts(Belt* pBelt);

UCHAR	Belt_getBeltId(Belt* pBelt);
void	Belt_setSpeedInCMsPerMin(Belt* pBelt, DWORD	setSpeedInCMsPerMin );
DWORD	Belt_getSpeedInCMsPerMin(Belt* pBelt);
void	Belt_setSpeedCounts(Belt* pBelt, WORD setSpeedInCounts );
DWORD	Belt_getSetPoint(Belt* pBelt);
DWORD	Belt_getSpeedCounts(Belt* pBelt);

void	Belt_setPb(Belt* pBelt, DWORD pb );
void	Belt_setTi(Belt* pBelt, DWORD ti );
void	Belt_setTd(Belt* pBelt, DWORD td );
DWORD	Belt_getPb(Belt* pBelt);
DWORD	Belt_getTi(Belt* pBelt);
DWORD	Belt_getTd(Belt* pBelt);

// the following function is required to tell the belt channels to calculate their
// closed loop speed once a second;

DWORD Belt_getHiDeadBandOffsetCounts(Belt* pBelt);
DWORD Belt_getHiProcessCounts(Belt* pBelt);
DWORD Belt_getHiDeviationCounts(Belt* pBelt);
DWORD Belt_getHiWarningCounts(Belt* pBelt);
DWORD Belt_getLoWarningCounts(Belt* pBelt);
DWORD Belt_getLoDeviationCounts(Belt* pBelt);
DWORD Belt_getLoProcessCounts(Belt* pBelt);
BOOL Belt_returnHiProcAlarm(Belt* pBelt);		
BOOL Belt_returnHiDevAlarm(Belt* pBelt);
BOOL Belt_returnHiDevWarn(Belt* pBelt);
BOOL Belt_returnLoDevWarn(Belt* pBelt);
BOOL Belt_returnLoDevAlarm(Belt* pBelt);
BOOL Belt_returnLoProcAlarm(Belt* pBelt);

void	Belt_setHiDeadBandOffsetCounts(Belt* pBelt, DWORD hiDeadBandInCounts );
void	Belt_setLoDeadBandOffsetCounts(Belt* pBelt, DWORD loDeadBandInCounts );
void	Belt_setHiProcessCounts(Belt* pBelt, DWORD hiProcCountsOffset );
void	Belt_setLoProcessCounts(Belt* pBelt, DWORD loProcCountsOffset );
void	Belt_setHiDeviationCounts(Belt* pBelt, DWORD hiDevCountsOffset );
void	Belt_setLoDeviationCounts(Belt* pBelt, DWORD loDevCountsOffset );
void	Belt_setHiWarningCounts(Belt* pBelt, DWORD hiWarnCountsOffset);
void	Belt_setLoWarningCounts(Belt* pBelt, DWORD loWarnCountsOffset);
void	Belt_enableHiProcAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ );
void	Belt_enableLoProcAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ );
void	Belt_enableHiDevAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ );
void	Belt_enableLoDevAlarm(Belt* pBelt, BOOL enable /*= TRUE*/ );
void	Belt_enableHiDevWarn(Belt* pBelt, BOOL enable /*= TRUE*/ );
void	Belt_enableLoDevWarn(Belt* pBelt, BOOL enable /*= TRUE*/ );

void	Belt_enterSlowPidValue(Belt* pBelt, LONG slowPidOffset);

// the following functions are required by the OCX to calculate belt position.
enum CountMethod		Belt_getCountMethod(Belt* pBelt);
DWORD	Belt_getSummOfSpeeds(Belt* pBelt);
DWORD	Belt_get4BElapsedPositionCountTics(Belt* pBelt);
void	Belt_setOpenLoop(Belt* pBelt, BOOL openLoopState );
BOOL	Belt_isOpenLoop(Belt* pBelt);
DWORD	Belt_getCurrentState(Belt* pBelt);
BOOL    Belt_IsBeltInWarning(Belt* pBelt);
void	Belt_setElapsedPositionCounts(Belt* pBelt, DWORD elapsedPosCounts );

void	Belt_setInputRangeLowValue(Belt* pBelt, UINT low);
UINT	Belt_getInputRangeLowValue(Belt* pBelt);
void	Belt_setInputRangeHighValue(Belt* pBelt, UINT high);
UINT	Belt_getInputRangeHighValue(Belt* pBelt);
void	Belt_setPulsesPerCmCount(Belt* pBelt, UINT pulses);
UINT	Belt_getPulsesPerCmCount(Belt* pBelt);
void	Belt_setMaxFreq(Belt* pBelt, UINT freq);
UINT	Belt_getMaxFreq(Belt* pBelt);
void	Belt_setHiSpeedLimit(Belt* pBelt, UINT speed);
UINT	Belt_getHiSpeedRange(Belt* pBelt);
void	Belt_setLowSpeedLimit(Belt* pBelt, UINT speed);
UINT	Belt_getLowSpeedLimit(Belt* pBelt);
void	Belt_setHiPercentLimit(Belt* pBelt, UINT percent);
UINT	Belt_getHiPercentLimit(Belt* pBelt);
void	Belt_setLoPercentLimit(Belt* pBelt, UINT percent);
UINT	Belt_getLoPercentLimit(Belt* pBelt);
void	Belt_doFastPidControl(Belt* pBelt);
void	Belt_setSequenceGroup(Belt* pBelt, UINT sGroup );
UINT	Belt_getSequenceGroup(Belt* pBelt);
void	Belt_setIfSequenced(Belt* pBelt, BOOL bSequenced);
void	Belt_doPowerUpSequencing(Belt* pBelt, UINT iActivatedGroup);
void	Belt_initPowerUpSequencing(Belt* pBelt);
void	Belt_setWarningTimeVariable(Belt* pBelt, DWORD d10thSec);
void	Belt_setDeadbandDeviationTime(Belt* pBelt, DWORD dwrd10thSec);
void  Belt_AdvanceWordPoint(Belt* pBelt, UINT whichPointer);
void  Belt_setHybridBehavior(Belt* pBelt, BOOL bHybridOn);
void  Belt_setLowDevBehavior(Belt* pBelt, BOOL bLowDevInput);
void  Belt_setHighDevInput(Belt* pBelt, BOOL bHighDevInput);
void  Belt_setdualBeltTimer10ths(Belt* pBelt, UINT iDevCount);
UINT  Belt_smemaAllow(Belt* pBelt);
void Belt_SmemaOffDist(Belt* pBelt, DWORD delayCounts);
void Belt_SuspendForSmema(Belt* pBelt, UINT smemaIndex, BOOL bSuspend, UINT type);
void Belt_CureExitTest(Belt* pBelt);
void Belt_CureInit(Belt* pBelt);
UINT Belt_getSMEMASuspend(Belt* pBelt);

//******************************************************************************
// Class:Belts
//
// Abstract:
// This class acts a container for an array of multiple belts. Although there
// are only two as of 4/2/1998, the use of arrays is consistent with other
// modules that have been developed. Please remember that belts and rails
// have an interaction on the IO that is used.
//
//	Programmer: Steven Young
// Date: 04/02/1998
//******************************************************************************
typedef struct _Belts_
{
//private:
	DWORD		beltsLoaded;		// the no of belts loaded to use as an id
	DWORD 		noOfActiveBelts;	// 1 or 2 are the only valid values here.
	DWORD		noOfActiveRails;	// need to know to set up IO
	DWORD		boardsInOven;		// Total number of boards in oven, independent of belts
	BOOL		BeltSpeedPIDTrig; // this variable tells the PID loop to 
	BOOL		m_bAutoRange;
	BOOL		m_bOutputActive;
	UINT 		m_iOutput;
	} Belts;

void Belts_init(Belts* pBelts);

BOOL 		Belts_setNoOfActiveBelts	(Belts* pBelts, DWORD activeBelts );
DWORD 		Belts_getNoOfActiveBelts	(Belts* pBelts);

DWORD		Belts_addBelt				(Belts* pBelts);
UINT		Belts_getBeltsLoaded		(Belts* pBelts);
void		Belts_process				(Belts* pBelts);
BOOL        Belts_IsWarningConditionPresent(Belts* pBelts, short beltNo);
void		Belts_SetBeltSpeedPIDTrig(Belts* pBelts, BOOL state);
BOOL		Belts_GetBeltSpeedPIDTrig(Belts* pBelts);
void		Belts_doPowerUpSequencing(Belts* pBelts, UINT iGroup);
void		Belts_initializePowerUpSequencing(Belts* pBelts);
void		Belts_BeltsAreSequenced(Belts* pBelts, BOOL bSequenced);
UINT		Belts_returnNumberOfBeltsInStartUpSequence(Belts* pBelts, UINT iSequence);
BOOL  Belts_TempzonesAreSequenced(Belts* pBelts, BOOL bSequence);
void  Belts_setDualMotors(Belts* pBelts, BOOL bDualMotors);
void  Belt_setDualMotorFailTime(Belt* pBelt, DWORD dwrdFailTime);
void  Belt_setsecondaryMotor(Belt* pBelt, BOOL bSec);
void  Belt_setDualMotors(Belt* pBelt, BOOL bDualMotors);
void  Belts_setDigOutput(Belts* pBelts, UINT iWhichOutput);
void  Belt_setDigOutput(Belt* pBelt, UINT iWhichOutput);
void  Belts_setDigOutputBehavior(Belts* pBelts, UINT iOutputBehave);
void  Belt_setDigOutputBehavior(Belt* pBelt, UINT iOutputBehave);
void  Belts_setHybridBehavior(Belts* pBelts, BOOL bHybridOn);
void  Belts_setMotorFailedCounts (Belts* pBelts, UINT iMotorFailCount);
void  Belts_setHiDevBehavior(Belts* pBelts, BOOL bHighDevInput);
void  Belts_setLowDevBehavior(Belts* pBelts, BOOL bLowDevInput);
void Belts_setDifferentialCounts(Belts* pBelts, UINT iDeviationCOunt);
void Belts_testCriticalPath(int iTest);

void Belts_enableAutoRange(Belts* pBelts, BOOL enable);
void Belts_enableAutoRangeOutput(Belts* pBelts, UINT output);
void Belts_setAutoRangeSwitch(Belts* pBelts, DWORD setting);
void Belts_SmemaOffDist(Belts* pBelts, DWORD delayCounts);
void Belts_standbyMode(Belts* pBelts, BOOL bOn);
void Belt_setStandbyCounts(Belt* pBelt, WORD setStandbyInCounts );
void Belt_standbyMode(Belt* pBelt, BOOL bOn);
void Belt_setDigitalStopSensor(Belt* pBelt, DWORD sensor);
void Belt_resetDigitalStop(Belt* pBelt);

#endif
