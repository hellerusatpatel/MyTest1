//*****************************************************************************
// Copyright (c) 1999-2015 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2015 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: fluxheater.c
//
// Description: control file for fluxheaters (heat zones for clearing accumulated flux) also known as cool zones
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 07-Jan-15  FJN  Implement FluxHeater_currentMonitorFailure and FluxHeater_heaterFailure
// 13-Mar-15  FJN  Implement FluxHeater_currentMonitorFailureHigh
// 19-Sep-16  TP   Correct FluxHeater_checkSelfAcknowledgeAlarms() to skip startp sequence ver8.0.0.11
// 19-Sep-16  TP   Add DisableDevAlarmInStartup for flux heaters ver8.0.0.11
//*****************************************************************************
#include "contain.h"
#include "fluxheater.h"
#include "alarm.h"
#include "hellerenumerations.h"
#include "oven.h"
#include "digitio.h"
#include "pid.h"
#include "timer.h"
#include "tempzone.h"
#include "typedefdefine.h"
#include "hc2xio_exports.h"

#include <string.h>

extern DbContainer g_dbContainer;

AlarmQueue			* alarmQueueDb;
Oven 				* ovenDb;
ANALOGIN  			* analogInDb;
ANALOGOUT 			* analogOutDb;
DIN					* digInDb;
DOUT 				* digOutDb;
Timer				* timerDb;	
TempZones			* tempZonesDb;	// rev8.0.0.11


static BOOL blowerOffMessageSent;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_init
			
			The flux heater is used to heat the flux on the board so that it will drip
			into the flux filter.

 RETURNS:   void
------------------------------------------------------------------------*/
void FluxHeater_init(FluxHeater* pFluxHeater, UINT nID)
{
	if(pFluxHeater)
	{
		pFluxHeater->zoneAuto			= eOFF;
		pFluxHeater->zoneActive			= FALSE;	
		pFluxHeater->hiProcAlarmEnable	= TRUE;
		pFluxHeater->loProcAlarmEnable	= TRUE;	
		pFluxHeater->htAlarmEnable	   	= TRUE;	
		pFluxHeater->ltAlarmEnable		= TRUE;	
		pFluxHeater->htWarnEnable		= TRUE;
		pFluxHeater->ltWarnEnable		= TRUE;
		pFluxHeater->alarmBandsEnabled	= FALSE; 
		pFluxHeater->highProcess			= 2000;//2 seconds
		pFluxHeater->selfAckAlarmSecondNo = 0;	
		pFluxHeater->lowProcess			= 0;	
		pFluxHeater->alarmHighTempOffset	= (DWORD)DEFAULT_ALARM_BAND;
		pFluxHeater->alarmLowTempOffset	= (DWORD)DEFAULT_ALARM_BAND;
		pFluxHeater->warnHighTempOffset	= (DWORD)DEFAULT_WARN_BAND;
		pFluxHeater->warnLowTempOffset	= (DWORD)DEFAULT_WARN_BAND;
		pFluxHeater->deadBandHighTempOffset	= (DWORD)DEFAULT_DEAD_BAND;
		pFluxHeater->deadBandLowTempOffset	= (DWORD)DEFAULT_DEAD_BAND;
		pFluxHeater->sp					= 0;
		pFluxHeater->tpoOutput			= 0;
		pFluxHeater->inDeadBand			= FALSE;
		pFluxHeater->riseRateSetPointChange = FALSE;
		pFluxHeater->zoneInactiveToActiveTransition = FALSE;
		pFluxHeater->riseRateDelayStartTime = 0;

		pFluxHeater->currentJobNo		= COOLDOWN;
		pFluxHeater->previousJobNo		= COOLDOWN;
		pFluxHeater->lastCheckTemp		= 0;
		pFluxHeater->directionalIOset	= FALSE;
		pFluxHeater->deadBandEnableStatus= FALSE;
		pFluxHeater->minTpoOut			= 0;
		pFluxHeater->maxTpoOut			= MAXIMUM_PERCENTAGE;
		pFluxHeater->onInitTPO			=0;
		PID_init(&(pFluxHeater->pid), &(pFluxHeater->sp), &(pFluxHeater->pv), 
			&(pFluxHeater->tpoOutput), Reverse);
		PID_init(&(pFluxHeater->coolPID), &(pFluxHeater->coolSP), &(pFluxHeater->pv), &(pFluxHeater->tpoOutputCooling), Direct);
		pFluxHeater->m_bPowerUpDelayElapsed = FALSE;
		pFluxHeater->m_iGroupNo = 0;
		pFluxHeater->scTpoOutput = 0;
		pFluxHeater->m_bDoRiseRateCheck = FALSE;
		pFluxHeater->m_bAutocleanRecipeRunning = FALSE;
		pFluxHeater->m_bPowerUpSequencingCalled = FALSE;
		pFluxHeater->m_bFluxHeaterEnabled = TRUE;
		pFluxHeater->fluxheaterDelayTimer = DEFAULT_FLUXHEATERDELAY;
		pFluxHeater->flxStartTime = 0;
		pFluxHeater->m_iCurrentStartedGroup = 0;
		pFluxHeater->output25Flag = FALSE;
		pFluxHeater->m_bStartupGroupHasFired = FALSE;
		pFluxHeater->m_bGen9 = FALSE;
		pFluxHeater->m_iWarnings = 0;
		pFluxHeater->m_bType2 = FALSE;
		pFluxHeater->m_iTestTPOPath = 0;
	
		ovenDb = &( g_dbContainer.ovenDb );
		analogInDb = &( g_dbContainer.analogInDb );
		analogOutDb = &( g_dbContainer.analogOutDb );
		digInDb = &( g_dbContainer.digitalInDb 	);
		digOutDb = &( g_dbContainer.digitalOutDb	);
		alarmQueueDb = &( g_dbContainer.alarmQueueDb	);
		timerDb = &( g_dbContainer.elapseTimer 	);
		pFluxHeater->m_bRiseRateEnabled = FALSE;
		pFluxHeater->m_bSuspended = FALSE;	
		tempZonesDb = &( g_dbContainer.tempZonesDb );	//ver8.0.0.11

		switch(nID)
		{
			case 0:
				pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, AI_EXHAUST_FLUX_HEATER);	
				pFluxHeater->m_nTcInput = AI_EXHAUST_FLUX_HEATER;
				pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_EXHAUST_FLUX_HEATER);
				pFluxHeater->m_nTPOoutput = TPO_EXHAUST_FLUX_HEATER;
				pFluxHeater->m_bFluxHeaterEnabled = TRUE;
				pFluxHeater->m_iFluxHeaterIndex = nID;
				break;
			case 1:
				//this needs to be dynamic
				pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);	
	   			pFluxHeater->m_nTcInput = AI_UPZ9;	
				pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN);
				pFluxHeater->m_nTPOoutput = TPO_ANALOG_FAN;
				pFluxHeater->inDeadBand = TRUE; //needs to be TRUE if heater is disabled.
				pFluxHeater->deadBandEnableStatus = TRUE; //needs to be TRUE if heater is disabled.
				pFluxHeater->m_iFluxHeaterIndex = nID;
				pFluxHeater->m_bFluxHeaterEnabled = TRUE;
				break;
			case 2:
				pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, AI_TCPORT1);	
	   			pFluxHeater->m_nTcInput = AI_TCPORT1;
				pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL);
				pFluxHeater->m_nTPOoutput = TPO_GLOBAL_BLOWER_CONTROL;
				pFluxHeater->m_nScTPOOutput = AI_TCPORT1;
				pFluxHeater->inDeadBand = TRUE; //needs to be TRUE if heater is disabled.
				pFluxHeater->deadBandEnableStatus = TRUE; //needs to be TRUE if heater is disabled.
				pFluxHeater->m_iFluxHeaterIndex = nID;
				pFluxHeater->m_bFluxHeaterEnabled = TRUE;
				break;
			case 3:
	   			pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, AI_EXHAUST_FLUX_HEATER);	
	   			pFluxHeater->m_nTcInput = AI_EXHAUST_FLUX_HEATER;
	   			pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_EXHAUST_FLUX_HEATER);
				pFluxHeater->m_nTPOoutput = TPO_EXHAUST_FLUX_HEATER;
				pFluxHeater->m_bFluxHeaterEnabled = TRUE;
				pFluxHeater->m_iFluxHeaterIndex = nID;                               	
				break;

			case 4:
	   			pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, AI_TCPORT1);	
	   			pFluxHeater->m_nTcInput = AI_TCPORT1;
	   			pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL);
				pFluxHeater->m_nScTPOOutput = AI_TCPORT1;
				pFluxHeater->m_bFluxHeaterEnabled = TRUE;
				pFluxHeater->m_iFluxHeaterIndex = nID;                               	
				break;

			default:
				printk("invalid flux heater index in init\n");
				break;
		}
		pFluxHeater->currentTooth = 1;
		pFluxHeater->coolOutput = (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);
		pFluxHeater->tpoOutputCooling = 0;  
		pFluxHeater->coolOnOff = 0;
		pFluxHeater->period = DEFAULT_COOLING_PERIOD;
		pFluxHeater->mDwrdOutput = 0;
		pFluxHeater->mCoolingOutputPercentX100 = 0;
		pFluxHeater->mCoolingOnInCooldown = 0;
		pFluxHeater->mbSequence = TRUE;
		FluxHeater_sampleRiseRate(pFluxHeater);
	}
	return;
}

//******************************************************************************
// FluxHeater_setHiProcTemp
//
// Abstract:
//  The absolute high temperature for this job. All data validity checking is
//  done in the user interface.
//
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
// 						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setHiProcTemp(FluxHeater* pFluxHeater,  DWORD newHighProcess )
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setHiProcTemp", 0);
	pFluxHeater->highProcess = newHighProcess;
	return TRUE;
};

//******************************************************************************
// FluxHeater_setLoProcTemp
//
// Abstract:
// The absolute low temperature for this job. All data validity checking is
//  done in the user interface.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setLoProcTemp(FluxHeater* pFluxHeater, DWORD newLowProcess )
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setLoProcTemp", 0);
	pFluxHeater->lowProcess = newLowProcess;
	return TRUE;
};

//******************************************************************************
// FluxHeater_setAlarmHiTempOffset
//
// Abstract:
// The maximum process temperature that will cause a shutdown once inside deadband.
// It must be less than or equal to the highProcess temperature.
// All data validity checking is done in the user interface.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setAlarmHiTempOffset( FluxHeater* pFluxHeater, DWORD newAlarmHighTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setAlarmHiTempOffset", 0);
	pFluxHeater->alarmHighTempOffset = newAlarmHighTempOffset;
	return TRUE;
};
//******************************************************************************
// FluxHeater_setAlarmLoTempOffset
//
// Abstract:
// The minimum process temperature that will cause a shutdown once inside deadband.
// It must be greater than or equal to the lowProcess temperature.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setAlarmLoTempOffset(FluxHeater* pFluxHeater, DWORD newAlarmLowTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setAlarmLoTempOffset", 0);
	pFluxHeater->alarmLowTempOffset = newAlarmLowTempOffset;
	return TRUE;
};
//******************************************************************************
// FluxHeater_setWarnHiTempOffset
//
// Abstract:
// The temperature at which to inform the operator that the process may be going
// out of control before shutting down. This may allow the operator to make
// corrections prior to the oven beginning cooldown cycle.
// It must be less than or equal to the alarmHighTempOffset.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setWarnHiTempOffset(FluxHeater* pFluxHeater,  DWORD newWarnHighTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setWarnHiTempOffset", 0);
	pFluxHeater->warnHighTempOffset = newWarnHighTempOffset;
	return TRUE;
};
//******************************************************************************
// FluxHeater_setWarnLoTempOffset
//
// Abstract:
// The temperature at which to inform the operator that the process may be going
// out of control before shutting down. This may allow the operator to make
// corrections prior to the oven beginning cooldown cycle.
// It must be less than or equal to the alarmLowTempOffset.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setWarnLoTempOffset(FluxHeater* pFluxHeater, DWORD newWarnLowTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setWarnLoTempOffset", 0);
	pFluxHeater->warnLowTempOffset = newWarnLowTempOffset;
	return TRUE;
};
//******************************************************************************
// FluxHeater_setDeadBandHiTempOffset
//
// Abstract:
// The temperature at which to activate alarms if they have not already been
// activated.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setDeadBandHiTempOffset(FluxHeater* pFluxHeater, DWORD newDeadBandHighTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setDeadBandHiTempOffset", 0);
	pFluxHeater->deadBandHighTempOffset = newDeadBandHighTempOffset;
	return TRUE;
};
//******************************************************************************
// FluxHeater_setDeadBandLoTempOffset
//
// Abstract:
// The temperature at which to activate alarms if they have not already been
// activated.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL FluxHeater_setDeadBandLoTempOffset(FluxHeater* pFluxHeater, DWORD newDeadBandLowTempOffset)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setDeadBandLoTempOffset", 0);
	pFluxHeater->deadBandLowTempOffset = newDeadBandLowTempOffset;
	return TRUE;
};

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setSetPoint
			
			To change the setpoint of a zone is analogous to loading a new job. Whenever
			the setpoint is changed it will inform the oven that a new job is loaded.
			All data validity checking is done within the user application.

 RETURNS:   true
------------------------------------------------------------------------*/
BOOL FluxHeater_setSetPoint(FluxHeater* pFluxHeater, LONG newSetPointValue )
{
	if(NULL != pFluxHeater)
	{
		if ( newSetPointValue >= 0 )
		{
			if ( pFluxHeater->sp != newSetPointValue )
			{
				pFluxHeater->alarmBandsEnabled = FALSE;
				pFluxHeater->inDeadBand = FALSE;
				pFluxHeater->riseRateSetPointChange = TRUE;
				pFluxHeater->sp = newSetPointValue;
				pFluxHeater->coolSP=pFluxHeater->sp + pFluxHeater->coolSPOffset;
				if(pFluxHeater->selfAckAlarmNo)
				{
					AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pFluxHeater->selfAckAlarmNo );
				}
			}
		}
	}
	return TRUE;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setZoneAuto
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setZoneAuto(FluxHeater* pFluxHeater, enum ZoneTriState autoState )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setZoneAuto");

	// 0 = manual
	// 1 = auto
	// 2 = off
	if ( pFluxHeater->zoneAuto != eAUTO && autoState == eAUTO )
	{
		pFluxHeater->zoneInactiveToActiveTransition = TRUE;
	}
	pFluxHeater->zoneAuto = autoState;
	pFluxHeater->alarmBandsEnabled = FALSE;
	pFluxHeater->inDeadBand = FALSE;

}
//******************************************************************************
// FluxHeater_setActive
//
// Abstract:
// The operator interface will only allow FluxHeaters that are configured to go
// to active state. All zones are considered inactive until told otherwise.
// 
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -  	Originally this function changed all the setpoints and
//						alarm and warning band parameters. Changing from Active
//						to open loop should not lose alarm and warning bands.
//						Although as a safety precaution set the TPO output to
//						0%.
//
//                      Changing from open loop to closed loop requires a power
//						up sequencing to occur. This will prevent the operator
// 						from switching from auto to manual to bypass sequencing.
//
//						During PowerUpSequencing or CoolDown modes a zone cannot
//						be made active only inactive.
//
//******************************************************************************
BOOL FluxHeater_setActive(FluxHeater* pFluxHeater, BOOL active )
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setActive", 0);
	BOOL status = FALSE;

	if ( active == TRUE  )
	{
		// check for a zone that is transitioning from inactive to active for
		// rise rate checking.
		if ( pFluxHeater->zoneActive == FALSE && active == TRUE )
		{
			pFluxHeater->inDeadBand = FALSE;
			pFluxHeater->alarmBandsEnabled = FALSE;
			pFluxHeater->zoneInactiveToActiveTransition = TRUE;
		}
		pFluxHeater->zoneActive 	= active;  	// active if true, inactive false.
			
		if ( Oven_getJob(ovenDb) != COOLDOWN )
		{
			pFluxHeater->pidEnabled 	= TRUE;   // power up Sequencing complete and not in COOLDOWN.
		}
		else
		{
			pFluxHeater->pidEnabled	= FALSE;
		}
			
		status	= TRUE;
	}
	else
	{
		pFluxHeater->zoneActive 	= FALSE; 	// if zone not present it is not active!
								// it can also be set inactive by the operator.
		pFluxHeater->pidEnabled 	= FALSE;
		pFluxHeater->tpoOutput	= 0;
		*(pFluxHeater->pTPOoutput)	= 0;
		ANALOGOUT_set(analogOutDb, pFluxHeater->m_nTPOoutput, (WORD) 0 );
		ANALOGOUT_setFree(analogOutDb, pFluxHeater->m_nTPOoutput);
		status = TRUE;
	}

	return status;
};

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_process
			
			main process loop for the fluxheaters

 RETURNS:   void
------------------------------------------------------------------------*/
void FluxHeater_process(FluxHeater* pFluxHeater)
{
	BOOL bCooldownComplete;
	BOOL bJobLoading;
	DWORD dwrdTerminal;
	short sZoneState;
	LONG lMaxPossibleCoolOutputs;

	lMaxPossibleCoolOutputs = 0;
	bCooldownComplete = FALSE;
	bJobLoading = FALSE;
	dwrdTerminal = 0;
	sZoneState = eOFF;

	if(pFluxHeater)
	{
		if(!pFluxHeater->m_bFluxHeaterEnabled)
		{
			pFluxHeater->inDeadBand = TRUE;

		}
		else
		{
			FluxHeater_checkDelayPeriod(pFluxHeater);
			FluxHeater_checkRiseRate(pFluxHeater);
							
			pFluxHeater->pv = *(pFluxHeater->pTcInput);

			if ( pFluxHeater->zoneActive == FALSE )
			{
				pFluxHeater->tpoOutput = 0;   // if the zone is not active make sure this is always off.
			}
			else	// the zone must be active.
			{
	 			pFluxHeater->currentJobNo = Oven_getJob(ovenDb);
		
				if(pFluxHeater->m_bStartupGroupHasFired) //only test the fluxheater time after the startup group has started
				{
					FluxHeater_processFluxheaterTime(pFluxHeater);
				}
				if ( pFluxHeater->currentJobNo == COOLDOWN || pFluxHeater->zoneAuto == eOFF )
				{
					pFluxHeater->tpoOutput = 0;
					bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
					dwrdTerminal = Oven_getTerminal(ovenDb);
					lMaxPossibleCoolOutputs =  (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);

					if(!bCooldownComplete && ( pFluxHeater->coolOutput < lMaxPossibleCoolOutputs ) && 
						pFluxHeater->mCoolingOnInCooldown && (dwrdTerminal != 0) )
					{
						if(pFluxHeater->coolSP < pFluxHeater->pv)
						{
							pFluxHeater->tpoOutputCooling = MAX_TPO_COUNTS;
						}
						else
						{
							pFluxHeater->tpoOutputCooling = 0;
						}
					}
					else
					{							
						pFluxHeater->tpoOutputCooling = 0;
					}
				}
				else
				{
					if( ( pFluxHeater->m_bPowerUpSequencingCalled == FALSE ) && ( pFluxHeater->mbSequence == TRUE ) )
					{
						pFluxHeater->tpoOutputCooling = 0;
					}
					else if( ( pFluxHeater->m_bPowerUpSequencingCalled == FALSE ) && ( pFluxHeater->mbSequence == FALSE ) )
					{
						if(pFluxHeater->coolOnOff == 0)
						{
							PID_calcPID(&(pFluxHeater->coolPID));
						}
						else  //on off direct for now
						{
							if(pFluxHeater->coolSP < pFluxHeater->pv)
							{
								pFluxHeater->tpoOutputCooling = MAX_TPO_COUNTS;
							}
							else
							{
								pFluxHeater->tpoOutputCooling = 0;
							}
						}
					}
					// if the zoneAuto is manual or auto then alarms need to be monitored.
					bJobLoading = Oven_isJobLoadInProgress(ovenDb);
					if ( bJobLoading == FALSE )
					{
						// alarm bands are always checked independent of the state of the PID;
						FluxHeater_checkAlarmBands(pFluxHeater);
						FluxHeater_checkSelfAcknowledgeAlarms(pFluxHeater);
						sZoneState = FluxHeater_getZoneState(pFluxHeater);

						if ( ( pFluxHeater->pidEnabled == TRUE ) && sZoneState == eAUTO)
						{
							if(pFluxHeater->m_bPowerUpSequencingCalled)
							{
								FluxHeater_calcPid(pFluxHeater);
							}
						}//vstop
						else
						{
							lMaxPossibleCoolOutputs =  (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);
							if( ( pFluxHeater->coolOutput < lMaxPossibleCoolOutputs ) &&
								( pFluxHeater->mCoolingOnInCooldown == FALSE ) )
							{
								if(pFluxHeater->coolOnOff == 0)
								{
									PID_calcPID(&(pFluxHeater->coolPID));
								}
								else  //on off direct for now
								{
									if(pFluxHeater->coolSP<pFluxHeater->pv)
									{
										pFluxHeater->tpoOutputCooling = MAX_TPO_COUNTS;
									}
									else
									{
										pFluxHeater->tpoOutputCooling = 0;
									}
								}
							}				
						}
					}
				}
				pFluxHeater->previousJobNo = pFluxHeater->currentJobNo;
			}	
			if( ( ( pFluxHeater->pidEnabled && pFluxHeater->m_bPowerUpSequencingCalled ) || ( pFluxHeater->zoneAuto == eMANUAL ) ) &&
				!pFluxHeater->m_bSuspended )
			{

				if(!pFluxHeater->m_iTestTPOPath)
				{
					TPO_AddSafeSegment(pFluxHeater->m_nTPOoutput , SAFE_SEGMENT_CONTROL);
				}
				*(pFluxHeater->pTPOoutput) = (WORD) pFluxHeater->tpoOutput;

				ANALOGOUT_set(analogOutDb, pFluxHeater->m_nTPOoutput, (WORD) pFluxHeater->tpoOutput );

			}
			else
			{
				if(!pFluxHeater->m_iTestTPOPath)
				{
					TPO_AddSafeSegment(pFluxHeater->m_nTPOoutput, SAFE_SEGMENT_CONTROL);
				}
				*(pFluxHeater->pTPOoutput) = pFluxHeater->tpoOutput = 0;
				ANALOGOUT_set(analogOutDb, pFluxHeater->m_nTPOoutput, 0 );

			}
			FluxHeater_TPOToDigitalTime(pFluxHeater);
		}
	}
	return;
}

//******************************************************************************
// FluxHeater_checkSelfAcknowledgeAlarms()
//
// Abstract:
// Warnings for temperature deviation need to be selfacknowledging in order to 
// allow the SMEMA interface to continue board feed without operator intervention.
// 
//
// Programmer: Steven Young
// Date: 08/12/1998
//
//******************************************************************************
void FluxHeater_checkSelfAcknowledgeAlarms(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_checkSelfAcknowledgeAlarms");

	if ( pFluxHeater->selfAckAlarmNo != 0 )
	{
		if ( ( pFluxHeater->pv <= (long)( pFluxHeater->sp + pFluxHeater->warnHighTempOffset - pFluxHeater->deadBandHighTempOffset )) && 
			( pFluxHeater->pv >= (long)(pFluxHeater->sp - pFluxHeater->warnLowTempOffset + pFluxHeater->deadBandLowTempOffset)))
		{
			if(Oven_getIsAutoAcknowledgedDisabled(ovenDb))
			{
				if(!Oven_isJobStartupComplete(ovenDb) || tempZonesDb->m_bTimerStartupEventFired == FALSE ) //add if test in ver8.0.0.11
					AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pFluxHeater->selfAckAlarmNo );
			}
			else
			{
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pFluxHeater->selfAckAlarmNo );
			}

			pFluxHeater->selfAckAlarmNo = 0;
		}

	}

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_checkWarningState

 GLOBALS:
 RETURNS:   int
 SEE ALSO:
------------------------------------------------------------------------*/
int FluxHeater_checkWarningState(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_checkWarningState", 0);
	if ( ( pFluxHeater->pv <= (long)( pFluxHeater->sp + pFluxHeater->warnHighTempOffset - pFluxHeater->deadBandHighTempOffset)) || 
		(pFluxHeater->pv >= (long)(pFluxHeater->sp - pFluxHeater->warnLowTempOffset + pFluxHeater->deadBandLowTempOffset)))
	{
		pFluxHeater->m_iWarnings = 0;
	}
	return pFluxHeater->m_iWarnings;
}


//******************************************************************************
// FluxHeater_checkAlarmBands()
//
// Abstract:
// When power up sequencing begins wait for the delay time before monitoring the
// riserate( degrees c/time seconds ). If the PV is within the deadband enable
// alarms. Do not check for alarmbands when COOLDOWN is loaded.
//
//
// Programmer: Steven Young
// Date: 05/07/1998
//
//******************************************************************************
void FluxHeater_checkAlarmBands(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_checkAlarmBands");
	long hdbOffset = 0;
	long ldbOffset = 0;
	BOOL bJobLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
	BOOL bDisableDevAlarmInStartup = FALSE;
	BOOL bStartupComplete = FALSE;
	UINT curJob = Oven_getJob(ovenDb);
	if ( (curJob == COOLDOWN) || (bJobLoadInProgress == TRUE) ||
		!pFluxHeater->m_bFluxHeaterEnabled)
	{
		pFluxHeater->alarmBandsEnabled = FALSE;
	}
	else
	{
		// need to check for low and high process alarms regardless of 
		// state of state of deviation alarms.

		if ( bJobLoadInProgress == FALSE )
		{
			//ver8.0.0.11
			bDisableDevAlarmInStartup = Oven_getIsDevAlarmInStartupDisabled(ovenDb);
			if(Oven_isJobStartupComplete(ovenDb))
			{
				if(tempZonesDb->m_bTimerStartupEventFired == TRUE)
					bStartupComplete = TRUE;
			}
			////
			
			if ( pFluxHeater->pv <= pFluxHeater->lowProcess && pFluxHeater->loProcAlarmEnable == TRUE )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_LO_PROCESS_ALARM, pFluxHeater->m_iFluxHeaterIndex  );
				pFluxHeater->selfAckAlarmNo=0;	
				pFluxHeater->m_iWarnings=0;
			}
			if (  pFluxHeater->highProcess <= pFluxHeater->pv && pFluxHeater->hiProcAlarmEnable == TRUE )
			{
				AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_HI_PROCESS_ALARM, pFluxHeater->m_iFluxHeaterIndex  );	
				pFluxHeater->selfAckAlarmNo=0;	
				pFluxHeater->m_iWarnings=0;
			}
		}
		if(pFluxHeater->m_bPowerUpSequencingCalled)
		{
			if ( pFluxHeater->alarmBandsEnabled == FALSE )
			{
				if ( pFluxHeater->htWarnEnable )
				{
					hdbOffset = pFluxHeater->sp + pFluxHeater->warnHighTempOffset - pFluxHeater->deadBandHighTempOffset;
				}
				else
				{
					hdbOffset = pFluxHeater->warnHighTempOffset + pFluxHeater->sp;
				}


				if ( pFluxHeater->ltWarnEnable )
				{
					ldbOffset = pFluxHeater->sp - pFluxHeater->warnLowTempOffset + pFluxHeater->deadBandLowTempOffset;
					if ( (long)ldbOffset < 0 )
					{
						ldbOffset = 0;
					}
				}
				else
				{
					ldbOffset = pFluxHeater->sp - pFluxHeater->warnLowTempOffset;
				}

				if ( ( pFluxHeater->pv >= ldbOffset ) && (pFluxHeater->pv <= hdbOffset) )
				{
					pFluxHeater->alarmBandsEnabled = TRUE;
					pFluxHeater->inDeadBand	= TRUE;
				}
				else
				{
				//WDT 1/5/1 if channel goes out of deadband the boolean
				//needs to be set to false to update GUI
					pFluxHeater->inDeadBand=FALSE;
				}
			}
			else	// alarmbands enabled == TRUE	
			{
				if ( pFluxHeater->pv <= (long)( pFluxHeater->sp - pFluxHeater->alarmLowTempOffset )&& pFluxHeater->ltAlarmEnable == TRUE )
				{
					if( bDisableDevAlarmInStartup == TRUE )
					{
						if( bStartupComplete == TRUE )
						{
							AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_LO_DEVIATION_ALARM, pFluxHeater->m_iFluxHeaterIndex  );
							pFluxHeater->selfAckAlarmNo=0;
							pFluxHeater->m_iWarnings=0;
						}
					}
					else
					{					
						AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_LO_DEVIATION_ALARM, pFluxHeater->m_iFluxHeaterIndex  );
						pFluxHeater->selfAckAlarmNo=0;
						pFluxHeater->m_iWarnings=0;
					}
				}
				else 
				{ 
					if ( pFluxHeater->pv <= (long)( pFluxHeater->sp - pFluxHeater->warnLowTempOffset ) && pFluxHeater->ltWarnEnable == TRUE )
					{
						pFluxHeater->selfAckAlarmNo = AlarmQueue_addAlarm(alarmQueueDb, WARNING, FLUXHEATER_LO_DEVIATION_WARNING, pFluxHeater->m_iFluxHeaterIndex );
						pFluxHeater->m_iWarnings=1;
					}
				}

				if ( pFluxHeater->pv >= (long)( pFluxHeater->sp + pFluxHeater->alarmHighTempOffset ) && pFluxHeater->htAlarmEnable == TRUE )
				{
					if( bDisableDevAlarmInStartup == TRUE )
					{
						if( bStartupComplete == TRUE )
						{
							AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_HI_DEVIATION_ALARM, pFluxHeater->m_iFluxHeaterIndex  );
							pFluxHeater->selfAckAlarmNo=0;
							pFluxHeater->m_iWarnings=0;
						}
					}
					else
					{		
						AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_HI_DEVIATION_ALARM, pFluxHeater->m_iFluxHeaterIndex  );
						pFluxHeater->selfAckAlarmNo=0;
						pFluxHeater->m_iWarnings=0;
					}
				}
				else 
				{ 
					if ( pFluxHeater->pv >= (long)( pFluxHeater->sp + pFluxHeater->warnHighTempOffset ) && pFluxHeater->htWarnEnable == TRUE )
					{
						pFluxHeater->selfAckAlarmNo =  AlarmQueue_addAlarm(alarmQueueDb, WARNING, FLUXHEATER_HI_DEVIATION_WARNING, pFluxHeater->m_iFluxHeaterIndex  );
						pFluxHeater->m_iWarnings=1;
					}
				}
			}
		}
	}  
}  

//******************************************************************************
// FluxHeater_setRiseRatePeriod()
//
// Abstract:
// The time between temperature checks to verify that the temperature is actually
// rising and not a constant which could indicate a broken thermocouple
//
// Programmer: Steven Young
// Date: 09/30/1999
//
//******************************************************************************
void FluxHeater_setRiseRatePeriod(FluxHeater* pFluxHeater, DWORD riseRatePeriodIn10ths )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setRiseRatePeriod");
	pFluxHeater->heaterRiseRatePeriod10ths = riseRatePeriodIn10ths;
}

//******************************************************************************
// FluxHeater_setMinRiseDegreesCounts()
//
// Abstract:
// The minimum temperature rise that must occur within the period, else an alarm
// message will be sent.
//
// Programmer: Steven Young
// Date: 09/30/1999
//
//******************************************************************************
void FluxHeater_setMinRiseDegreeCounts(FluxHeater* pFluxHeater, DWORD minRiseDegrees )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setMinRiseDegreeCounts");
	pFluxHeater->minimumRiseDegrees = minRiseDegrees;
}

//******************************************************************************
// BOOL FluxHeater_IsZoneInWarnging()
//
// Abstract:
// Used to check if the zone is in a warning state. As part of the auto acknowledgement
// mechanism the individual zones will be displayed in yellow if a warning is present.
// Upon screen updating a check must be done to see if the zone is still in warning or 
// not. If it is not still in warning, automatically cleared or operator cleared the 
// zone must be changed to green. If the selfAckAlarmNo > 0 then an alarm of warning
// type has been activated. An ID is returned and is never 0.
//
// Programmer:
// Date:
//
//******************************************************************************
BOOL FluxHeater_IsZoneInWarning(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_IsZoneInWarning", 0);
	BOOL bReturn = FALSE;
	BOOL bAckedAlarm = FALSE;
    if ( pFluxHeater->selfAckAlarmNo > 0 && pFluxHeater->m_bFluxHeaterEnabled)
    {
		bAckedAlarm = AlarmQueue_findAcknowledgedAlarm(alarmQueueDb, pFluxHeater->selfAckAlarmNo);
		if(!bAckedAlarm &&pFluxHeater->m_bPowerUpSequencingCalled) //zone is not yet active
		{
	        bReturn = TRUE;
		}
    }
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_InDeadBandOrIsNotEnabled

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_InDeadBandOrIsNotEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_InDeadBandOrIsNotEnabled", 0);
	BOOL bReturn = FALSE;
	BOOL bStatus = FALSE;

	if ( pFluxHeater->zoneActive == FALSE )
	{

		bReturn = TRUE;
	}
	else
	{
		if(pFluxHeater->zoneAuto==eAUTO && !pFluxHeater->pidEnabled)
		{

			bReturn = FALSE;	
		}
		else
		{
			bStatus = Oven_getJob(ovenDb);
			if(!bStatus)//cooldown
			{

				bReturn = FALSE;
			}
			else
			{
				bStatus = FluxHeater_isInDeadBand(pFluxHeater);
				if (bStatus)
				{
					bReturn = TRUE;
				}
			}
		}
	}
	return bReturn;	
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_ActivateZones 

			activates the process loop if the group number matches the fluxheater's

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_ActivateZones(FluxHeater* pFluxHeater, short groupNum, BOOL bIncrementGroupcount)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_ActivateZones");
	if(bIncrementGroupcount==TRUE)
	{
		pFluxHeater->m_iCurrentStartedGroup = groupNum;
	}
	if(!pFluxHeater->m_iGroupNo && groupNum==1)
	{
		if(!pFluxHeater->m_bAutocleanRecipeRunning)//we will not allow startup until timer termination
		{
			pFluxHeater->m_bPowerUpSequencingCalled = TRUE;
			FluxHeater_setPowerUpDelayFlag(pFluxHeater, TRUE);
			FluxHeater_setPIDenable(pFluxHeater, TRUE);	// manual and 0% output.
			FluxHeater_enableDeadBandRange(pFluxHeater, TRUE);
			if((pFluxHeater->zoneActive == TRUE) && (pFluxHeater->zoneAuto == eMANUAL))
			{
				pFluxHeater->tpoOutput = pFluxHeater->onInitTPO; 
			}
	    }
		else //this condition will be hit when the startup group terminates, we will then count down the timer and recall this function
		{
			pFluxHeater->flxStartTime = Timer_getCurrentTime10ths(timerDb);
			pFluxHeater->m_bStartupGroupHasFired = TRUE;
		}
	}
	if(groupNum == pFluxHeater->m_iGroupNo)
	{
		if(!pFluxHeater->m_bAutocleanRecipeRunning || pFluxHeater->m_bGen9)//we will not allow startup until timer termination, unless we're gen 9 
		{
			pFluxHeater->m_bPowerUpSequencingCalled = TRUE;
			FluxHeater_setPowerUpDelayFlag(pFluxHeater, TRUE);
			FluxHeater_setPIDenable(pFluxHeater, TRUE);	// manual and 0% output.
			FluxHeater_enableDeadBandRange(pFluxHeater, TRUE);
	    }
		else //this condition will be hit when the startup group terminates, we will then count down the timer and recall this function
		{
			pFluxHeater->flxStartTime = Timer_getCurrentTime10ths(timerDb);
			pFluxHeater->m_bStartupGroupHasFired = TRUE;
		}
	}

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_DeActivateZones 

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_DeActivateZones(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_DeActivateZones");
	pFluxHeater->m_bPowerUpDelayElapsed = FALSE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_initializePowerUpSequencing 

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_initializePowerUpSequencing(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_initializePowerUpSequencing");

	pFluxHeater->m_iCurrentStartedGroup = 0;
	pFluxHeater->m_bPowerUpSequencingCalled = FALSE;
	FluxHeater_setPIDenable(pFluxHeater, FALSE);	// manual and 0% output.
	FluxHeater_setTPOoutput(pFluxHeater, 0);
	FluxHeater_enableDeadBandRange(pFluxHeater, FALSE);
	pFluxHeater->output25Flag = TRUE;
	blowerOffMessageSent = FALSE;
	pFluxHeater->m_bStartupGroupHasFired = FALSE;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_IsFluxHeaterInAutoManualMode
			

 GLOBALS:
 RETURNS:   BOOL 
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_IsFluxHeaterInAutoManualMode(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_IsFluxHeaterInAutoManualMode", 0);
	BOOL bReturn = FALSE;
	if(pFluxHeater->zoneAuto == eAUTO)
	{
		bReturn = TRUE;
	}
	if(pFluxHeater->zoneAuto == eMANUAL && pFluxHeater->zoneActive==TRUE)
	{
		bReturn = TRUE;
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setPowerUpDelayFlag
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setPowerUpDelayFlag(FluxHeater* pFluxHeater, BOOL bPowerState )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setPowerUpDelayFlag");

	pFluxHeater->m_bPowerUpDelayElapsed = bPowerState; 
	if(!bPowerState) // if turning cycle off deactivate rise rate check
	{
		pFluxHeater->m_bDoRiseRateCheck = FALSE;
	}
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isInDeviationAlarmZone
			

 GLOBALS:
 RETURNS:   SHORT 
 SEE ALSO:
------------------------------------------------------------------------*/
SHORT FluxHeater_isInDeviationAlarmZone(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isInDeviationAlarmZone", 0);
	SHORT sReturn = FALSE;
	if(pFluxHeater->m_bFluxHeaterEnabled)
	{
		if(pFluxHeater->inDeadBand && AlarmQueue_getCooldownPreference(alarmQueueDb))
		{
	// FLUXHEATER_LO_DEVIATION_ALARM:
			if ( pFluxHeater->pv <= (long)( pFluxHeater->sp - pFluxHeater->alarmLowTempOffset )&& pFluxHeater->ltAlarmEnable == TRUE )
			{
				sReturn = TRUE;
			}
	// FLUXHEATER_HI_DEVIATION_ALARM:	
			if ( pFluxHeater->pv >= (long)( pFluxHeater->sp + pFluxHeater->alarmHighTempOffset ) && pFluxHeater->htAlarmEnable == TRUE )
			{
				sReturn = TRUE;
			}
		}
	}
	return sReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_initTcInput
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_initTcInput(FluxHeater* pFluxHeater, UINT nIndex)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_initTcInput");
	pFluxHeater->pTcInput = ANALOGIN_GetAt(analogInDb, nIndex);
	pFluxHeater->m_nTcInput = nIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_initTPOoutput
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_initTPOoutput(FluxHeater* pFluxHeater, UINT nIndex)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_initTPOoutput");
	if((nIndex != NULL_TEMP_IO) && (nIndex<MAX_ANALOG_OUTPUTS))
	{
		pFluxHeater->pTPOoutput = ANALOGOUT_GetAt(analogOutDb, nIndex);
		ANALOGOUT_setOwned(analogOutDb, nIndex);
		pFluxHeater->m_nTPOoutput = nIndex;
	}
	else
	{
		if(pFluxHeater->m_nTPOoutput&&(pFluxHeater->m_nTPOoutput!=MAX_ANALOG_OUTPUTS+1))
		{
			ANALOGOUT_setFree(analogOutDb, nIndex);
		}
		pFluxHeater->m_nTPOoutput = MAX_ANALOG_OUTPUTS+1;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setFluxHeaterEnable
			
			enables/disables the fluxheater

 RETURNS:   void 
------------------------------------------------------------------------*/
void FluxHeater_setFluxHeaterEnable(FluxHeater* pFluxHeater, BOOL bEnable)
{
	if(pFluxHeater)
	{
		pFluxHeater->inDeadBand = !bEnable; //needs to start FALSE if heater is enabled.
		pFluxHeater->deadBandEnableStatus = !bEnable; //needs to start FALSE if heater is enabled.
		pFluxHeater->m_bFluxHeaterEnabled = bEnable;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_processFluxheaterTime
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_processFluxheaterTime(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_processFluxheaterTime");
	int i = 0;
	DWORD drwdFluxDelay = 0;
	DWORD tim = Timer_getCurrentTime10ths(timerDb);
	if(pFluxHeater->m_bType2 && !pFluxHeater->m_bGen9)
	{
		drwdFluxDelay = 0;
		blowerOffMessageSent = TRUE;
	}
	else
	{
		drwdFluxDelay = pFluxHeater->fluxheaterDelayTimer;
	}	
	if(pFluxHeater->m_bAutocleanRecipeRunning)
	{
		if(tim >= (pFluxHeater->flxStartTime + drwdFluxDelay) )
		{
			pFluxHeater->m_bAutocleanRecipeRunning = FALSE;
			pFluxHeater->output25Flag = FALSE;
			if(!blowerOffMessageSent)//Allow only one flux heater to throw the blower off message
			{
				AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, FLUX_BLOWER_OFF, 0);
				blowerOffMessageSent = TRUE;
			}
			for(i = 1; i <= pFluxHeater->m_iCurrentStartedGroup; i++)
			{
				FluxHeater_ActivateZones(pFluxHeater, (short)i, FALSE);  //start the flux heater if the sequence number has already been passed
			}
		}
	}
	else
	{
		pFluxHeater->flxStartTime = Timer_getCurrentTime10ths(timerDb);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_startSequencingRequiresTimer
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_startSequencingRequiresTimer(FluxHeater* pFluxHeater, BOOL bFluxCRecipe)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_startSequencingRequiresTimer");
	pFluxHeater->m_bAutocleanRecipeRunning = bFluxCRecipe;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setFluxheaterDelayTime
			

 GLOBALS:
 RETURNS:   void 
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setFluxheaterDelayTime(FluxHeater* pFluxHeater, DWORD dTime)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setFluxheaterDelayTime");
	pFluxHeater->fluxheaterDelayTimer = dTime * 600;//convert from minutes to 1/10 second units
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isInDeadBand
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isInDeadBand(FluxHeater* pFluxHeater)				
{
	BOOL returnValue;
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isInDeadBand", 0);
	returnValue = pFluxHeater->inDeadBand; 
	return returnValue;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getOutput25Flag
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_getOutput25Flag(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getOutput25Flag", 0);
	BOOL bReturn = FALSE;
	if ( pFluxHeater->zoneActive != FALSE )
	{
		bReturn =  pFluxHeater->output25Flag;  
	}
	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isInDeadBandRangeEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isInDeadBandRangeEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isInDeadBandRangeEnabled", 0);
	return pFluxHeater->deadBandEnableStatus; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setIfInDeadBand
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setIfInDeadBand(FluxHeater* pFluxHeater, BOOL bDBState)		
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setIfInDeadBand");
	pFluxHeater->inDeadBand = bDBState;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableDeadBandRange
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableDeadBandRange(FluxHeater* pFluxHeater, BOOL dbFlag /*= TRUE*/ )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableDeadBandRange");
	pFluxHeater->deadBandEnableStatus = dbFlag; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getTcInputIndex
			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT FluxHeater_getTcInputIndex(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getTcInputIndex", 0);
	return pFluxHeater->m_nTcInput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getTPOoutputIndex
			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT FluxHeater_getTPOoutputIndex(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getTPOoutputIndex", 0);
	return pFluxHeater->m_nTPOoutput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getScInputIndex
			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT FluxHeater_getScInputIndex(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getScInputIndex", 0);
	return pFluxHeater->m_nScInput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getScTOPOutputIndex
			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT FluxHeater_getScTOPOutputIndex(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getScTOPOutputIndex", 0);
	return pFluxHeater->m_nScTPOOutput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isPIDenabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isPIDenabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isPIDenabled", 0);
	return pFluxHeater->pidEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isActive
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isActive(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isActive", 0);
	return pFluxHeater->zoneActive;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isHiProcAlarmEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isHiProcAlarmEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isHiProcAlarmEnabled", 0);
	return pFluxHeater->hiProcAlarmEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isLohProcAlarmEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL	FluxHeater_isLohProcAlarmEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isLohProcAlarmEnabled", 0);
	return pFluxHeater->loProcAlarmEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isHiDeviationAlarmEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isHiDeviationAlarmEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isHiDeviationAlarmEnabled", 0);
	return pFluxHeater->htAlarmEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isHiDeviationWarningEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isLoDeviationAlarmEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isLoDeviationAlarmEnabled", 0);
	return pFluxHeater->ltAlarmEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isHiDeviationWarningEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isHiDeviationWarningEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isHiDeviationWarningEnabled", 0);
	return pFluxHeater->htWarnEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isLoDeviationWarningEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isLoDeviationWarningEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isLoDeviationWarningEnabled", 0);
	return pFluxHeater->ltWarnEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_isFluxHeaterEnabled
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_isFluxHeaterEnabled(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_isFluxHeaterEnabled", 0);
	return pFluxHeater->m_bFluxHeaterEnabled;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getZoneState
			

 GLOBALS:
 RETURNS:   SHORT
 SEE ALSO:
------------------------------------------------------------------------*/
SHORT FluxHeater_getZoneState(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getZoneState", 0);
	return pFluxHeater->zoneAuto; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getHiProcTemp
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getHiProcTemp(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getHiProcTemp", 0);
	return pFluxHeater->highProcess;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getLoProcTemp
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getLoProcTemp(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getLoProcTemp", 0);
	return pFluxHeater->lowProcess;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getAlarmHiTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getAlarmHiTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getAlarmHiTempOffset", 0);
	return pFluxHeater->alarmHighTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getAlarmLoTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getAlarmLoTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getAlarmLoTempOffset", 0);
	return pFluxHeater->alarmLowTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getWarnHiTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD	FluxHeater_getWarnHiTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getWarnHiTempOffset", 0);
	return pFluxHeater->warnHighTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getWarnLoTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getWarnLoTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getWarnLoTempOffset", 0);
	return pFluxHeater->warnLowTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getDeadBandHiTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getDeadBandHiTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getDeadBandHiTempOffset", 0);
	return pFluxHeater->deadBandHighTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getDeadBandLoTempOffset
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getDeadBandLoTempOffset(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getDeadBandLoTempOffset", 0);
	return pFluxHeater->deadBandLowTempOffset;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getTPOoutput
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getTPOoutput(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getTPOoutput", 0);
	DWORD returnValue = pFluxHeater->tpoOutput;
	if((pFluxHeater->zoneActive == TRUE) && (pFluxHeater->zoneAuto == eMANUAL) &&
		!(pFluxHeater->m_bPowerUpSequencingCalled))
	{
		returnValue = 0;
	}
	return returnValue;	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getSetPoint
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getSetPoint(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getSetPoint", 0);
	return pFluxHeater->sp; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getProcVar
			

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD FluxHeater_getProcVar(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getProcVar", 0);
	return pFluxHeater->pv; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setPIDenable
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setPIDenable(FluxHeater* pFluxHeater, BOOL pe )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setPIDenable");
	pFluxHeater->pidEnabled=pe;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setAlarmsEnabled
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setAlarmsEnabled(FluxHeater* pFluxHeater, BOOL state )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setAlarmsEnabled");
	pFluxHeater->alarmBandsEnabled = state;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setTPOoutput
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setTPOoutput(FluxHeater* pFluxHeater, LONG   cTPOoutput )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setTPOoutput");
	pFluxHeater->tpoOutput	= cTPOoutput; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableHiProcAlarm
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableHiProcAlarm(FluxHeater* pFluxHeater, BOOL enable )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableHiProcAlarm");
	pFluxHeater->hiProcAlarmEnable = enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableLoProcAlarm
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableLoProcAlarm(FluxHeater* pFluxHeater, BOOL enable )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableLoProcAlarm");
	pFluxHeater->loProcAlarmEnable = enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableHiDeviationAlarm
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableHiDeviationAlarm(FluxHeater* pFluxHeater, BOOL enable )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableHiDeviationAlarm");
	pFluxHeater->htAlarmEnable = enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableLoDeviationAlarm
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableLoDeviationAlarm(FluxHeater* pFluxHeater, BOOL enable )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableLoDeviationAlarm");
	pFluxHeater->ltAlarmEnable	= enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableHiDeviationWarn
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableHiDeviationWarn(FluxHeater* pFluxHeater, BOOL enable )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableHiDeviationWarn");
	pFluxHeater->htWarnEnable	= enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_enableLoDeviationWarn
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_enableLoDeviationWarn(FluxHeater* pFluxHeater, BOOL enable ) 
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_enableLoDeviationWarn");
	pFluxHeater->ltWarnEnable	= enable; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setProcVariable
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_calcPid(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_calcPid");
	BOOL bPidEnabled = FluxHeater_isPIDenabled(pFluxHeater);
	if(bPidEnabled == TRUE)
	{
		PID_calcPID(&(pFluxHeater->pid));
		if(pFluxHeater->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS))
		{
			if(pFluxHeater->coolOnOff == 0)
			{
				PID_calcPID(&(pFluxHeater->coolPID));
			}
			else  //on off direct for now
			{
				if(pFluxHeater->coolSP < pFluxHeater->pv)
				{
					pFluxHeater->tpoOutputCooling = 256;
				}
				else
				{
					pFluxHeater->tpoOutputCooling = 0;
				}
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setProcVariable
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL FluxHeater_setProcVariable	(FluxHeater* pFluxHeater, DWORD newProcVar )
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_setProcVariable", 0);
	pFluxHeater->pv = newProcVar; return TRUE; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setSequenceGroup

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setSequenceGroup(FluxHeater* pFluxHeater, UINT group)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setSequenceGroup");
	pFluxHeater->m_iGroupNo = group;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_getSequenceGroup
			

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT FluxHeater_getSequenceGroup(FluxHeater* pFluxHeater)
{
	PARAM_CHECK_RETURN( pFluxHeater, "FluxHeater_getSequenceGroup", 0);
	return pFluxHeater->m_iGroupNo;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setGen9
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setGen9(FluxHeater* pFluxHeater, BOOL bGen9)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setGen9");
	pFluxHeater->m_bGen9 = bGen9;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setType2
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setType2(FluxHeater* pFluxHeater, BOOL bType2)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setType2");
	pFluxHeater->m_bType2 = bType2;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_testTPOPath
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_testTPOPath(FluxHeater* pFluxHeater, int iTest)
{
	pFluxHeater->m_iTestTPOPath = iTest;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_set_pendTPOoutput
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_set_pendTPOoutput(FluxHeater* pFluxHeater, LONG   cTPOoutput )
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_set_pendTPOoutput");
	pFluxHeater->tpoOutput	= cTPOoutput; 
	pFluxHeater->onInitTPO = cTPOoutput;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setCoolSPOffset
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setCoolSPOffset(FluxHeater* pFluxHeater, LONG nSP)
{
	pFluxHeater->coolSPOffset=nSP;
	pFluxHeater->coolSP=pFluxHeater->sp+pFluxHeater->coolSPOffset;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_coolingInCooldown
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_coolingInCooldown(FluxHeater* pFluxHeater, DWORD on)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_coolingInCooldown");
	pFluxHeater->mCoolingOnInCooldown=on;
	
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_CooldownSequenced
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_CooldownSequenced(FluxHeater* pFluxHeater, DWORD nOff)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_CooldownSequenced");
	if(nOff)
	{
		pFluxHeater->mbSequence=FALSE;
	}
	else
	{
		pFluxHeater->mbSequence=TRUE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setCoolPeriod
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setCoolPeriod(FluxHeater* pFluxHeater, DWORD period)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setCoolPeriod");
	pFluxHeater->period = period;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setCoolOnOff
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setCoolOnOff(FluxHeater* pFluxHeater, DWORD nOff)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setCoolOnOff");
	pFluxHeater->coolOnOff = nOff;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_setCoolOutput
			sets the output to a non null value using the RealToNominalOutput
			function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_setCoolOutput(FluxHeater* pFluxHeater, DWORD output)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_setCoolOutput");
	if(output != ODO_NULL)
	{
		pFluxHeater->coolOutput = RealToNominalOutput(output);
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_cooling
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_cooling(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_cooling");
	DWORD which;
	which = pFluxHeater->coolOutput;

		if( which < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
		{
			if(pFluxHeater->mDwrdOutput >= pFluxHeater->currentTooth)
			{
				*DOUT_GetAt(digOutDb, which) = TRUE;
			}
			else
			{
				*DOUT_GetAt(digOutDb, which) = FALSE;
			}
			pFluxHeater->currentTooth++;
			if(pFluxHeater->currentTooth>pFluxHeater->period)
			{
				pFluxHeater->currentTooth = 1;
			}
		}
	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_TPOToDigitalTime
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_TPOToDigitalTime(FluxHeater* pFluxHeater)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_TPOToDigitalTime");
	pFluxHeater->mDwrdOutput = 0;
	if(pFluxHeater->coolOutput < (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS) )
	{
		if(pFluxHeater->period != 0)
		{
			pFluxHeater->mDwrdOutput = (pFluxHeater->tpoOutputCooling * 10000 * pFluxHeater->period) / 256;
			pFluxHeater->mCoolingOutputPercentX100 = (pFluxHeater->mDwrdOutput / pFluxHeater->period) / 100;
			pFluxHeater->mDwrdOutput = pFluxHeater->mDwrdOutput / 10000;
		}
		else
		{
			printk("error pFluxHeater->period\n");//purposeful printk to detect error
		}
	
	}
	return;
}		          

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_pidSetPbCool
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_pidSetPbCool(FluxHeater* pFluxHeater, DWORD proportionalBand)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_pidSetTdCool");

	if ( pFluxHeater )
	{
		PID_setPb( &(pFluxHeater->coolPID), proportionalBand );

	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_pidSetTiCool
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_pidSetTiCool(FluxHeater* pFluxHeater, DWORD dwTi)
{
	PARAM_CHECK( pFluxHeater, "PIDController_pidSetTdCool");
	if ( pFluxHeater )
	{
		PID_setTi( &(pFluxHeater->coolPID), dwTi );
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_pidSetTdCool
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_pidSetTdCool(FluxHeater* pFluxHeater, DWORD dwTd)
{
	PARAM_CHECK( pFluxHeater, "FluxHeater_pidSetTdCool");
	if ( pFluxHeater )
	{
		PID_setTd( &(pFluxHeater->coolPID), dwTd );
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_blowerFailure
			
			if the zone is active this will deactivate tpo and request cooldown
			from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_blowerFailure(FluxHeater* pFluxHeater, BOOL bOFF)
{
	if(pFluxHeater->zoneActive)
	{
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, FLUX_BLOWER_FAILURE, pFluxHeater->m_iFluxHeaterIndex);
			Oven_requestCooldown(ovenDb); 
		}
	}
	pFluxHeater->m_bSuspended = bOFF;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_currentMonitorFailureLow
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_currentMonitorFailureLow(FluxHeater* pFluxHeater, BOOL bOFF)
{
	if(pFluxHeater->zoneActive)
	{
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_FLUX_ZONE_CURRENT_LOW, pFluxHeater->m_iFluxHeaterIndex);
			Oven_requestCooldown(ovenDb); 
		}
	}
	pFluxHeater->m_bSuspended = bOFF;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_currentMonitorFailureHigh
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_currentMonitorFailureHigh(FluxHeater* pFluxHeater, BOOL bOFF)
{
	if(pFluxHeater->zoneActive)
	{
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_FLUX_ZONE_CURRENT_HIGH, pFluxHeater->m_iFluxHeaterIndex);
			Oven_requestCooldown(ovenDb); 
		}
	}
	pFluxHeater->m_bSuspended = bOFF;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_heaterFailure
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void FluxHeater_heaterFailure(FluxHeater* pFluxHeater, BOOL bOFF)
{
	if(pFluxHeater->zoneActive)
	{
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_FLUX_ZONE_FAILURE, pFluxHeater->m_iFluxHeaterIndex);
			Oven_requestCooldown(ovenDb); 
		}
	}
	pFluxHeater->m_bSuspended = bOFF;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_checkRiseRate
			
			In order to detect a shorted thermocouple or a defective heater zone, a rise
			rate check is required. While the alarms are not enabled, haven't reached
			the dead band limits, the temperature should be rising at a minimum specified rate
			in degrees per second. Please note rise rate cannot be established when
			above the set point for the temperature will be falling.
 
 RETURNS:   void
------------------------------------------------------------------------*/
BOOL FluxHeater_checkRiseRate( FluxHeater* pFluxHeater )
{
	BOOL status;
	BOOL bSample;
	DWORD timDiff;
	LONG tempDif;

	tempDif = 0;
	timDiff = 0;
	bSample = TRUE;
	status = TRUE;

	// if we are in alarm band regions, we are close to being in control and
	// the rise rate will no longer be as great and may cause an alarm.
	
	//JMR - if we are not enabled, we don't want to alarm.
	if(pFluxHeater != NULL)
	{
		if  ( pFluxHeater->alarmBandsEnabled == FALSE )
		{
			if ( ( pFluxHeater->pv < pFluxHeater->sp - RISE_RATE_MARGIN) && !pFluxHeater->inDeadBand ) // the temperature must be rising.
			{
				bSample = FALSE;  //sample when we are testing or the test time has expired
				pFluxHeater->currentTime = Timer_getCurrentTime10ths(timerDb);
		
				timDiff = pFluxHeater->currentTime - pFluxHeater->lastCheckTime;
				if ( timDiff > pFluxHeater->heaterRiseRatePeriod10ths )
				{
					tempDif = (LONG)(pFluxHeater->lastCheckTemp + pFluxHeater->minimumRiseDegrees);
					if (  pFluxHeater->pv < tempDif )
					{

						if( pFluxHeater->m_bRiseRateEnabled == TRUE )
						{
							AlarmQueue_addAlarm(alarmQueueDb, WARNING, FLUXHEATER_RISERATE_WARN, pFluxHeater->m_iFluxHeaterIndex );
						}
						else
						{
						  // temperature rate of change not high enough Alarm.
							AlarmQueue_addAlarm(alarmQueueDb, ALARM, FLUXHEATER_RISERATE_ALARM, pFluxHeater->m_iFluxHeaterIndex );
							pFluxHeater->m_iWarnings = 0;
							status = FALSE;
						}
					}
					bSample = TRUE;
				}
			}
		}
		if(bSample)
		{
			FluxHeater_sampleRiseRate(pFluxHeater);
		}
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_sampleRiseRate
			
			to determine a rise rate error a sample must be taken
			and compared to a reading x tenth of seconds in the future
			this function will set the sample time and sample value,
			they must be set concurrently

 RETURNS:   void

------------------------------------------------------------------------*/
void FluxHeater_sampleRiseRate( FluxHeater* pFluxHeater )
{
	DWORD tim;
	tim = 0;

	tim = Timer_getCurrentTime10ths(timerDb);
	pFluxHeater->lastCheckTemp = *(pFluxHeater->pTcInput);
	pFluxHeater->lastCheckTime = tim;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  FluxHeater_checkDelayPeriod
			
			When a new job is loaded the delay period for rise rate is reset. During this 
			time period checking for rise rate is disabled.

 RETURNS:   void
------------------------------------------------------------------------*/
void FluxHeater_checkDelayPeriod(FluxHeater* pFluxHeater)
{
	DWORD tim;
	short sZoneState;

	sZoneState = eOFF;
	tim = 0;

	tim = Timer_getCurrentTime10ths(timerDb);

	if(pFluxHeater != NULL)
	{
		sZoneState = FluxHeater_getZoneState(pFluxHeater);
		
		//reset conditions
		if( ( pFluxHeater->currentJobNo == COOLDOWN ) || ( pFluxHeater->currentJobNo != pFluxHeater->previousJobNo ) || 
			( pFluxHeater->zoneInactiveToActiveTransition == TRUE ) || ( pFluxHeater->riseRateSetPointChange == TRUE ) ||
			( sZoneState != eAUTO ) || !pFluxHeater->m_bPowerUpDelayElapsed )
		{
			pFluxHeater->alarmBandsEnabled = FALSE;	// alarm bands are disabled on a new job.
			pFluxHeater->riseRateSetPointChange = FALSE;
			pFluxHeater->zoneInactiveToActiveTransition = FALSE;	// reset the transition flag, we are now doing rise rate check
			pFluxHeater->riseRateDelayStartTime = Timer_getCurrentTime10ths(timerDb); 
			FluxHeater_sampleRiseRate(pFluxHeater);
		}

	}
	return;
}
