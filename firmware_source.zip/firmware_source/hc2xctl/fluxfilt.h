/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// flux filter

#ifndef __FLUXFILTER_H__
#define __FLUXFILTER_H__

typedef struct _FluxFilter_
{
//private:
	DWORD elapsedTimeLastClean10ths;
	DWORD elapsedTimeDoorOpen;
	DWORD lastCheckTime10ths;
	DWORD intervalBetweenCleaning10ths;
	DWORD currentTime10ths;
	DWORD deltaTime;
	DWORD messageSendTime10ths;
	DWORD doorOpenStartTime10ths;
	DWORD doorOpenTime10ths;
	BOOL  messageSent;
	BOOL  priorContactorState;
	BOOL  cleanFilter;
	BOOL  fluxFilterDoorOpened;
	BOOL  fluxFilterEnabled;
	BOOL  bSetDO;
	BOOL bDoorOpenSent;
} FluxFilter;

void FluxFilter_init(FluxFilter* pFluxFilter);

void FluxFilter_process(FluxFilter* pFluxFilter);
DWORD FluxFilter_getElapsedTime10ths(FluxFilter* pFluxFilter);						// for saving to disk 
void FluxFilter_setElapsedTime10ths(FluxFilter* pFluxFilter, DWORD elapsedTime10ths ); // when loading program  
void FluxFilter_setFluxFilterCleaningInterval10ths(FluxFilter* pFluxFilter, DWORD cleanInterval10ths );	
DWORD FluxFilter_getFluxFilterCleaningInterval10ths(FluxFilter* pFluxFilter);
BOOL FluxFilter_getCleaningStatus(FluxFilter* pFluxFilter);
const char * FluxFilter_getName(FluxFilter* pFluxFilter);
void FluxFilter_fluxFilterEnable(FluxFilter* pFluxFilter,  BOOL enable /*= TRUE*/ );
void FluxFilter_setDOAvailibility(FluxFilter* pFluxFilter, BOOL bAvail);

#endif

