/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2006, All Rights Reserved
                    Company Confidential
                                                                                                    
    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.

// Version history
// 23-Dec-16  TP   Update version printk 8.0.0.16 20161223 to match PC program version only
// 01-Feb-17  TP   Update version printk 8.0.0.17 20170201 to match PC program version
// 03-Apr-17  TP   Update version printk 8.0.0.18 20170403
// 16-Apr-17  TP   Update version printk 8.0.0.19 20170416
// 25-Apr-17  TP   Update version printk 8.0.0.20 20170425
***************************************************************************/
#ifndef __KERNEL__
	#define __KERNEL
#endif

#ifndef MODULE
	#define MODULE
#endif

#include <linux/module.h> 
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/param.h>
#include <linux/poll.h>
#include <linux/timer.h>
#include <linux/tqueue.h>
#include <linux/interrupt.h>
#include <asm/arch/platform.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/arch/hardware.h>
#include <asm/semaphore.h>
#include <asm/segment.h>
#include <asm/uaccess.h>

#include "contain.h"
#include "xpdriverdevice.h"

#include "hc2xwd.h"

#define MSG_SIZE 512	

extern void calcBeltPID( unsigned int PIDNum, unsigned int enterDT );
extern void setPIDMode(unsigned int PIDNum, unsigned int pidModeEnabled);
extern void setTd( unsigned int PIDNum, long derivativeTime );
extern void setTi( unsigned int PIDNum, long integralResetTimeSeconds );
extern void PIDInit( unsigned int PIDNum, long usSetPoint, long usProcVariable,
                        long lTPOoutput, unsigned int directReverse);
extern void calcPID(unsigned int PIDNum, long setPoint);
                                                                                
int driver_major  = 0;
struct timer_list timer;
struct fasync_struct *async_queue;

DbContainer 	g_dbContainer;
XpDriverDevice g_xp;

void initialize_timer();

int g_useTimer = 0;
int g_timerCount = 0;
unsigned char out = 0xff;
int mask = 0;

int block = 0;

unsigned long last_jiffies;
unsigned short timer_started = 0;
struct tq_struct timer_task; //this is bottom half structure
unsigned long start_time;

unsigned int j = 0;

typedef struct _FILEDATA_
{
	KIrp kirp;
	struct semaphore sem;
} HellerFileData;

HellerFileData g_HellerFileData;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  timer_bottom_half

  
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void timer_bottom_half( void *unused )
{
   Scheduler_sequencer(&(g_xp.m_Scheduler));
	block = 0;

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  timer_handler

  
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void timer_handler( int irq, void *dev_id, struct pt_regs *regs )
{
	if(!timer_started)
	{
		timer_started = 1;
	}
	if(!g_timerCount)
	{
		start_time = inl(RTCDR);
	}
	g_timerCount++;
	if ( g_useTimer )
	{
		outl(0, TIMER2CLEAR); /* Write Anything to Clear */
	}
	if(!block)
	{
		block = 1;
		queue_task(&timer_task, &tq_immediate);
		mark_bh(IMMEDIATE_BH);
	}

	return;
}

int driver_fasync(int fd, struct file *filp, int mode)
{
	return fasync_helper(fd, filp, mode, &async_queue);
}

int driver_release(struct inode *inode, struct file *filp)
{
	hc2xwd_EnableDog(CTL_DOG, 0);
	free_irq(5, NULL);
	timer_started = 0;
	g_useTimer = 0;

	 return 0;
}

void initialize_timer()
{
	timer_started = 0;
	outl(50846, TIMER2LOAD); /* 100mSec */
	outl(0xC8, TIMER2CONTROL);
	outl(0, TIMER2CLEAR); /* Write Anything to Clear */
	// Now we setup up the Immediate Queue.
	timer_task.routine  = timer_bottom_half;
	timer_task.data = NULL;
	request_irq(5, timer_handler, 0, "hc2xctl", NULL);

	return;
}

int driver_open(struct inode* i, struct file* f)
{
	MOD_INC_USE_COUNT;

	f->private_data = &g_HellerFileData;

	g_timerCount = 0;
	g_useTimer = 1;
	initialize_timer();
	hc2xwd_EnableDog(CTL_DOG, 1);

	return 0;
}

ssize_t driver_read(struct file* f, char* buf, size_t count, loff_t* f_pos)
{
	HellerFileData* data = (HellerFileData*) f->private_data;
	ssize_t retValue = -ENOMEM;
	int status;

	if ( data == NULL )
	{
		printk("driver_read() has null data ptr!\n");
		return -EFAULT;
	}

	// make sure the user specified enough room.  as of the
	//	introduction of seperate lot processing commands, we
	//	support passing back more than 512 bytes.
	if ((count > 6) && (data->kirp.m_information > count))
	{
		return -EINVAL;
	}

	status = access_ok(VERIFY_WRITE, buf, count);
	if ( status == 0 )
	{
		printk("hc2xctl: driver_read !access_ok\n");
		return -EFAULT;
	}

	if ( down_interruptible(&(data->sem)) )
	{
		printk("hc2xctl: driver_read !down_interruptible\n");
		return -ERESTARTSYS;
	}

	status = copy_to_user(buf, &(data->kirp.m_ioctlCode),	4);
	if ( status != 0 )
	{
		printk("hc2xctl: driver_read !copy_to_user(m_ioctlCode)\n");
		retValue = -EFAULT;
		goto out;
	}

	status = copy_to_user(buf+4, &(data->kirp.m_information), 2);
	if ( status != 0 )
	{
		printk("hc2xctl: driver_read !copy_to_user(m_information)\n");
		retValue = -EFAULT;
		goto out;
	}
	
	status = copy_to_user(buf+6, &(data->kirp.m_ioctlBuffer), data->kirp.m_information);
	if ( status != 0 )
	{
		printk("hc2xctl: driver_read !copy_to_user(m_ioctlBuffer, m_information)\n");
		retValue = -EFAULT;
		goto out;
	}

	retValue = count;

out:
	if(retValue==0)
	{
		printk("return 0\n");
	}
	up(&(data->sem));
	return retValue;
}

ssize_t driver_write(struct file* f, const char* buf, size_t len, loff_t* f_pos)
{
	HellerFileData* data = (HellerFileData*) f->private_data;
	ssize_t retValue = -ENOMEM;
	int status;

	if ( data == NULL )
	{
		printk("driver_write() has null data ptr!\n");
		return -EFAULT;
	}

	if (len > KIRP_IOCTL_BUFFER_SIZE)
	// if ( len != MSG_SIZE )
	{
		printk("len > KIRP_IOCTL_BUFFER_SIZEE (%d != %d)\n", len, KIRP_IOCTL_BUFFER_SIZE);
		printk("\topCode: %d\n", *((unsigned int*)buf));
		return -EINVAL;
	}

	status = access_ok(VERIFY_READ, buf, len);
	if ( status == 0 )
	{
		printk("access_ok(VERIFY_READ)\n");
		return -EFAULT;
	}

	if ( down_interruptible(&(data->sem)) )
	{
		printk("down_interruptible\n");
		return -ERESTARTSYS;
	}

	// extract op code
	status = copy_from_user(&(data->kirp.m_ioctlCode),	buf, 4);
	if ( status != 0 )
	{
		printk("copy ioctl\n");
		retValue = -EFAULT;
		goto out;
	}

	// extract message size
	status = copy_from_user(&(data->kirp.m_information),	buf+4, 2);
	if ( status != 0 )
	{
		printk("copy information\n");
		retValue = -EFAULT;
		goto out;
	}
	
	data->kirp.m_inputBufferSize = len - 6;
	
	// extract message
	status = copy_from_user(&(data->kirp.m_ioctlBuffer),	buf+6, data->kirp.m_inputBufferSize);
	if ( status != 0 )
	{
		printk("copy ioctlBuffer\n");
		retValue = -EFAULT;
		goto out;
	}

	XpDriverDevice_DeviceControl(&g_xp, &(data->kirp));

	retValue = len;

out:
	if(retValue==0)
		printk("return 0\n");

	up(&(data->sem));
	return retValue;
}

struct file_operations driver_fops =
{
	open:		driver_open,
	fasync:     driver_fasync,
	release:    driver_release,
	write:		driver_write,
	read:			driver_read,
};

/*--(GLOBAL FUNCTION)----------------------------------------------------
 FUNCTION:  init_module

			Driver Function called with the driver is loaded.

 RETURNS:   int - Initialization Status
------------------------------------------------------------------------*/
int init_module()
{
	int status;

	status = 0;

	printk("hc2xctl: entering init_module %d, %ld\n", HZ, jiffies);

	driver_fops.owner = THIS_MODULE;

	XpDriverDevice_init(&g_xp, 0);

	printk("hc2xctl: register_chrdev...\n");
	/*
	* Register your major, and accept a dynamic number. This is the
	* first thing to do, in order to avoid releasing other module's
	* fops in scull_cleanup_module()
	*/
	status = register_chrdev(driver_major, "hc2xctl", &driver_fops);
	if (status < 0)
	{
		printk(KERN_WARNING "hc2xctl: can't get major %d\n", driver_major);
	}
	else
	{
		if (driver_major == 0)
		{
			driver_major = status; /* dynamic */
		}
		printk("hc2xctl: register_chrdev... succeeded\n");

		sema_init(&(g_HellerFileData.sem), 1);
	
		printk("hc2xctl::init_module() loaded version 8.0.0.28 20180208\n");
		status = 0;
	}

	return status;
}

void cleanup_module()
{
	unregister_chrdev(driver_major, "hc2xctl");
}
