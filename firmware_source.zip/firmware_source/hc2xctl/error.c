/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// error.cpp

#include "typedefdefine.h"
#include "error.h"
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  ErrorContainer_init
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void ErrorContainer_init(ErrorContainer* pErrorContainer )
{
	PARAM_CHECK( pErrorContainer, "ErrorContainer_init");


	pErrorContainer->analogInputOverrun = 0;	
	pErrorContainer->analogOutputOverrun = 0;
	pErrorContainer->digitalInputOverrun = 0;
	pErrorContainer->digitalOutputOverrun = 0;
}		 

void ErrorContainer_incAnalogInOverrun   (ErrorContainer* pErrorContainer)
{ 
	PARAM_CHECK( pErrorContainer, "ErrorContainer_incAnalogInOverrun");
	pErrorContainer->analogInputOverrun++;			
}

void ErrorContainer_incAnalogOutOverrun  (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK( pErrorContainer, "ErrorContainer_incAnalogOutOverrun");
	pErrorContainer->analogOutputOverrun++;		
}

void ErrorContainer_incDigitalInOverrun  (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK( pErrorContainer, "ErrorContainer_incDigitalInOverrun");
	pErrorContainer->digitalInputOverrun++;		
}

void ErrorContainer_incDigitalOutOverrun (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK( pErrorContainer, "ErrorContainer_incDigitalOutOverrun");
	pErrorContainer->digitalOutputOverrun++;		
}

DWORD ErrorContainer_getAnalogInOverrun  (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK_RETURN( pErrorContainer, "ErrorContainer_getAnalogInOverrun", 0);
	return pErrorContainer->analogInputOverrun;	
}

DWORD ErrorContainer_getAnalogOutOverrun (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK_RETURN( pErrorContainer, "ErrorContainer_getAnalogOutOverrun", 0);
	return pErrorContainer->analogOutputOverrun;	
}		

DWORD ErrorContainer_getDigitalInOverrun (ErrorContainer* pErrorContainer)
{
	PARAM_CHECK_RETURN( pErrorContainer, "ErrorContainer_getDigitalInOverrun", 0);
	return pErrorContainer->digitalInputOverrun;	
}

DWORD ErrorContainer_getDigitalOutOverrun(ErrorContainer* pErrorContainer)
{
	PARAM_CHECK_RETURN( pErrorContainer, "ErrorContainer_getDigitalOutOverrun", 0);
	return pErrorContainer->digitalOutputOverrun;	
}
