/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __RD__
#define __RD__

#include "typedefdefine.h"


typedef struct _recipeTrigger_
{
//private:
	char recipePath[MAX_RECIPE_NAME_LENGTH];
	char cooldown[MAX_RECIPE_NAME_LENGTH];
//public:
	UINT m_numberComms;
	UINT m_actionControl;
//the following uint stores the current controlling comm reference
//1 will be the Win_Hdac, 2 will be outside program
	UINT	m_ControlComm;
//True==fire state change event to Win_Hdac
	BOOL bNotify;
//this variable indicates the recipe should be saved when control is transfered
//back to the HOP
	BOOL bSaveRecipePath;
//the same way it sounds, this will of course fire the event to one piece of outside
//software only
	BOOL bFireRecipeNotification;

	BOOL bHellerProgramExited;
	BOOL bHellerUp;

	UINT loadRecipe;
	char recipeTransferPath[MAX_RECIPE_NAME_LENGTH];
	char recipeSaveTransferPath[MAX_RECIPE_NAME_LENGTH];
	int iAckedControl;
} recipeTrigger;

void recipeTrigger_init(recipeTrigger* precipeTrigger);

void recipeTrigger_ExecuteLoad(recipeTrigger* precipeTrigger);
void recipeTrigger_IncrementInstance(recipeTrigger* precipeTrigger);
void recipeTrigger_DecrementInstance(recipeTrigger* precipeTrigger);

char* recipeTrigger_getRecipePath( recipeTrigger* precipeTrigger );
BOOL recipeTrigger_setRecipePath(recipeTrigger* precipeTrigger, char *recipe_name );
BOOL recipeTrigger_setRecipeTransferPath(recipeTrigger* precipeTrigger, char *recipe_name);
char* recipeTrigger_getRecipeSavePath(recipeTrigger* precipeTrigger);
char*  recipeTrigger_getRecipeSaveTransferPath(recipeTrigger* precipeTrigger);

BOOL recipeTrigger_getHellerUp(recipeTrigger* precipeTrigger);
void recipeTrigger_setHellerUp(recipeTrigger* precipeTrigger, BOOL bUP);
void recipeTrigger_setReadControl(recipeTrigger* pRecipeTrigger, int iControl);
int recipeTrigger_getReadControl(recipeTrigger* pRecipeTrigger);
#endif
