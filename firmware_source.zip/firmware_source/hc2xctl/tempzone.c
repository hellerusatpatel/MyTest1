//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: tempzone.c
//
// Description: heater zone code
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 07-Jan-15  FJN  Revise HEATER_CURRENT_LOW to HEATER_TEMP_ZONE_CURRENT_LOW
// 07-Jan-15  FJN  Revise HEATER_FAILURE to HEATER_TEMP_ZONE_FAILURE
// 13-Man-15  FJN  Declare HEATER_TEMP_ZONE_CURRENT_HIGH
// 24-Mar-16  FJN  Revise TempZone_checkRiseRate to have smaller warning band
// 12-Sep-16  TP   Update TempZone_process() to fix DisableAutoAcknowledge warning option
// 08-Feb-18  TP   Update TempZone_IsZoneInWarning() to address zone color issue for heat zones on secondary HC2, ver8.0.0.28
//*****************************************************************************
#include <stdio.h>
#include "contain.h"
#include "typedefdefine.h"
#include "tempzone.h"
#include "tempzs.h"
#include "alarm.h"
#include "hellerenumerations.h"
#include "oven.h"
#include "digitio.h"
#include "pid.h"
#include "timer.h"
#include "hzblower.h"

extern DbContainer g_dbContainer;

AlarmQueue			* alarmQueueDb;
Oven 				* ovenDb;
ANALOGIN  			* analogInDb;
ANALOGOUT 			* analogOutDb;
DIN					* digInDb;
DOUT 				* digOutDb;
Timer				* timerDb;
AnalogFan			* analogFan;
GlobalBlower		* globalBlower;
TempZones			* tempZonesDb;	// reference to container ie parent.

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_init

			init for tempzone

 RETURNS:   void
------------------------------------------------------------------------*/
void TempZone_init(TempZone* pTempZone, BOOL bLocal)
{
		
	if(pTempZone)
	{
		tempZonesDb = &( g_dbContainer.tempZonesDb );
		ovenDb = &( g_dbContainer.ovenDb );
		analogInDb = &( g_dbContainer.analogInDb );
		analogOutDb = &( g_dbContainer.analogOutDb );
		digInDb = &( g_dbContainer.digitalInDb );
		digOutDb = &( g_dbContainer.digitalOutDb );
		alarmQueueDb = &( g_dbContainer.alarmQueueDb );
		timerDb = &( g_dbContainer.elapseTimer );
		globalBlower = &( g_dbContainer.globalBlower );
		analogFan = &( g_dbContainer.analogFan );
		PIDController_init( &(pTempZone->pidCtrl), tempZonesDb->tempZoneCount, bLocal );
	
		pTempZone->directionalIOset	= FALSE;
		pTempZone->selfAckAlarmNo = 0;
		pTempZone->selfAckAlarmSecondNo =0;
		pTempZone->onInitTPO = 0;
		
		
		pTempZone->bSecondaryTPODirect = FALSE;
		pTempZone->m_bEnableOverDrawWarning = FALSE;
		pTempZone->m_iOverdrawPercentage = MAX_TPO_COUNTS;
		pTempZone->overdrawTime = 0L;
		pTempZone->m_bSecondaryOpenThermocouple = FALSE;
		pTempZone->m_bSecondaryHiProcCountdownOn = FALSE;
		pTempZone->m_dwrdHiProcSecBeginTime = 0;
		pTempZone->selfAckAlarmNoComm = 0;
		pTempZone->wallyCount = 0;
		pTempZone->m_iTestPath = 0;
		pTempZone->readDelay=0;
		pTempZone->m_bGroupStarted = FALSE;
		pTempZone->commLossAttemptsII=0;
		switch ( pTempZone->pidCtrl.zoneNo )
	
		{
			case 0:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ1, TPO_UPZ1 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 1);
				break;
	
			case 1:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ1, TPO_LOWZ1 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 1);			
				break;
	
			case 2:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ2, TPO_UPZ2 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 2);			
				break;
	
			case 3:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ2, TPO_LOWZ2 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 2);			
				break;
	
			case 4:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ3, TPO_UPZ3 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 3);			
				break;
	
			case 5:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ3, TPO_LOWZ3 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 3);
				break;
	
			case 6:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ4, TPO_UPZ4 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 4);
				break;
	
			case 7:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ4, TPO_LOWZ4 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 4);
				break;
	
			case 8:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ5, TPO_UPZ5 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 5);
				break;
	
			case 9:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ5, TPO_LOWZ5 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 5);
				break;
	
			case 10:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ6, TPO_UPZ6 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 6);
				break;
	
			case 11:	
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ6, TPO_LOWZ6 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 6);
				break;
	
			case 12:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ7, TPO_UPZ7 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 7);
				break;
	
			case 13:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ7, TPO_LOWZ7 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 7);
				break;
	
			case 14:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ8, TPO_UPZ8 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 8);
				break;
	
			case 15:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ8, TPO_LOWZ8 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 8);
				break;
	
			case 16:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ9, TPO_UPZ9 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 9);
				break;
	
			case 17:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ9, TPO_LOWZ9 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 9);
				break;
	
			case 18:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ10, TPO_UPZ10 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 10);
				break;
	
			case 19:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ10, TPO_LOWZ10 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 10);
				break;
	
			case 20:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ11, TPO_UPZ11 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 11);
				break;
	
			case 21:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ11, TPO_LOWZ11 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 11);
				break;
	
			case 22:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_UPZ12, TPO_UPZ12 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 12);
				break;
	
			case 23:
				PIDController_configureIO( &(pTempZone->pidCtrl), AI_LOWZ12, TPO_LOWZ12 );
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 12);
				break;
	
			case 24:
				pTempZone->pidCtrl.pTcInput = &(pTempZone->dummyValue);   		// no relationship to io
				pTempZone->pidCtrl.m_nTcInput = 0;
				pTempZone->pidCtrl.dwrdOurOutput = OUTPUT_INVALID_INDEX;
				pTempZone->pidCtrl.pTPOoutput	 = &(pTempZone->dummyValue);
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 0);
				break;
	
			case 25:
				pTempZone->pidCtrl.pTcInput = &(pTempZone->dummyValue);   		// no relationship to io
				pTempZone->pidCtrl.m_nTcInput = 0;
	
				pTempZone->pidCtrl.dwrdOurOutput = OUTPUT_INVALID_INDEX;
				pTempZone->pidCtrl.pTPOoutput	 = &(pTempZone->dummyValue);
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 0);
				break;
	
			case 26:
				pTempZone->pidCtrl.pTcInput = &(pTempZone->dummyValue);   		// no relationship to io
				pTempZone->pidCtrl.m_nTcInput=0;
				pTempZone->pidCtrl.dwrdOurOutput = OUTPUT_INVALID_INDEX;
				pTempZone->pidCtrl.pTPOoutput	 = &(pTempZone->dummyValue);
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 0);
				break;
	
			case 27:
				pTempZone->pidCtrl.pTcInput = &(pTempZone->dummyValue);   		// no relationship to io
				pTempZone->pidCtrl.m_nTcInput = 0;
				pTempZone->pidCtrl.dwrdOurOutput = OUTPUT_INVALID_INDEX;
				pTempZone->pidCtrl.pTPOoutput	 = &(pTempZone->dummyValue);
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 0);
				break;
			case 28: //these are slave board indexes
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38: //these are slave board indexes
			case 39:
			case 40:
			case 41:
			case 42:
			case 43:
			case 44:
			case 45:
			case 46:
			case 47:
			case 48: //these are slave board indexes
			case 49:
			case 50:
			case 51:
			case 52:
			case 53:
			case 54:
			case 55:
			case 56:
			case 57:
			case 58: //these are slave board indexes
			case 59:
				PIDController_configureSlaveIO(&(pTempZone->pidCtrl));
				break;

			default:
				pTempZone->pidCtrl.pTcInput = &(pTempZone->dummyValue);   		// no relationship to io
				pTempZone->pidCtrl.m_nTcInput = 0;
				pTempZone->pidCtrl.dwrdOurOutput = OUTPUT_INVALID_INDEX;
				pTempZone->pidCtrl.pTPOoutput	 = &(pTempZone->dummyValue);
				PIDController_setGroupNo( &(pTempZone->pidCtrl), 0);
				break;
		}
		pTempZone->riseRateSetPointChange = FALSE;
		pTempZone->lastCheckTime = 0;
		pTempZone->lastCheckTemp = 0;
	}	
	return;
}

//******************************************************************************
// TempZone_setSequenceGroup
//
// Abstract:
// Allow for changes to which temperature sequence group a zone belongs to.
// This may be limited to Heller customization, in that case the functionality
// of this function is determined by the windows application.
//
// Programmer: Steven Young
// Date: 03/19/1998
//******************************************************************************
BOOL TempZone_setSequenceGroup(TempZone* pTempZone, DWORD newGroupNo)
{
	BOOL status = FALSE;
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setSequenceGroup", 0);
	if ( TempZones_getOperationMode(tempZonesDb) != PowerUpSequencing )
	{
		// no changes to groupings during power up or if zone not active.
		// A zone that is not configured cannot be active!
		PIDController_setGroupNo( &(pTempZone->pidCtrl), newGroupNo);
		
		status = TRUE;
	}
	
	return status;
}

//******************************************************************************
// TempZone_setHiProcTemp
//
// Abstract:
//  The absolute high temperature for this job. All data validity checking is
//  done in the user interface.
//
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
// 						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setHiProcTemp(TempZone* pTempZone, DWORD newHighProcess )
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setHiProcTemp", 0);
	return PIDController_setHiProcTemp( &(pTempZone->pidCtrl), newHighProcess);
}

//******************************************************************************
// TempZone_setLoProcTemp
//
// Abstract:
// The absolute low temperature for this job. All data validity checking is
//  done in the user interface.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setLoProcTemp(TempZone* pTempZone, DWORD newLowProcess )
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setLoProcTemp", 0);
	return PIDController_setLoProcTemp( &(pTempZone->pidCtrl), newLowProcess );
}

//******************************************************************************
// TempZone_setAlarmHiTempOffset
//
// Abstract:
// The maximum process temperature that will cause a shutdown once inside deadband.
// It must be less than or equal to the highProcess temperature.
// All data validity checking is done in the user interface.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setAlarmHiTempOffset(TempZone* pTempZone, DWORD newAlarmHighTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setAlarmHiTempOffset", 0);
	PIDController_setAlarmHiTempOffset( &(pTempZone->pidCtrl), newAlarmHighTempOffset );
	return TRUE;
}

//******************************************************************************
// TempZone_setAlarmLoTempOffset
//
// Abstract:
// The minimum process temperature that will cause a shutdown once inside deadband.
// It must be greater than or equal to the lowProcess temperature.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setAlarmLoTempOffset(TempZone* pTempZone, DWORD newAlarmLowTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setAlarmLoTempOffset", 0);
	PIDController_setAlarmLoTempOffset( &(pTempZone->pidCtrl), newAlarmLowTempOffset );
	return TRUE;
}

//******************************************************************************
// TempZone_setWarnHiTempOffset
//
// Abstract:
// The temperature at which to inform the operator that the process may be going
// out of control before shutting down. This may allow the operator to make
// corrections prior to the oven beginning cooldown cycle.
// It must be less than or equal to the alarmHighTempOffset.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setWarnHiTempOffset(TempZone* pTempZone, DWORD newWarnHighTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setWarnHiTempOffset", 0);
	PIDController_setWarnHiTempOffset( &(pTempZone->pidCtrl), newWarnHighTempOffset );
	return TRUE;
}

//******************************************************************************
// TempZone_setWarnLoTempOffset
//
// Abstract:
// The temperature at which to inform the operator that the process may be going
// out of control before shutting down. This may allow the operator to make
// corrections prior to the oven beginning cooldown cycle.
// It must be less than or equal to the alarmLowTempOffset.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setWarnLoTempOffset(TempZone* pTempZone, DWORD newWarnLowTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setWarnLoTempOffset", 0);
	return PIDController_setWarnLoTempOffset( &(pTempZone->pidCtrl), newWarnLowTempOffset );
}

//******************************************************************************
// TempZone_setDeadBandHiTempOffset
//
// Abstract:
// The temperature at which to activate alarms if they have not already been
// activated.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setDeadBandHiTempOffset(TempZone* pTempZone, DWORD newDeadBandHighTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setDeadBandHiTempOffset", 0);
	PIDController_setDeadBandHiTempOffset( &(pTempZone->pidCtrl), newDeadBandHighTempOffset );
	return TRUE;
}

//******************************************************************************
// TempZone_setDeadBandLoTempOffset
//
// Abstract:
// The temperature at which to activate alarms if they have not already been
// activated.
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -	Remove all checking to let the windows application do the
//						setting so that only one location will handle.
//
//******************************************************************************
BOOL TempZone_setDeadBandLoTempOffset(TempZone* pTempZone, DWORD newDeadBandLowTempOffset)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setDeadBandLoTempOffset", 0);
	return PIDController_setDeadBandLoTempOffset( &(pTempZone->pidCtrl), newDeadBandLowTempOffset );
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_setSetPoint
			
	To change the setpoint of a zone is analogous to loading a new job. Whenever
 the setpoint is changed it will inform the oven that a new job is loaded.
	All data validity checking is done within the user application.

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL TempZone_setSetPoint(TempZone* pTempZone, LONG newSetPointValue )
{
	if(pTempZone)
	{

		if ( (pTempZone->pidCtrl.sp != newSetPointValue) && (newSetPointValue >= 0) )
		{
		
			TempZone_setAlarmsEnabled(pTempZone, FALSE);
			TempZone_setDeadBandState(pTempZone, FALSE);

			pTempZone->riseRateSetPointChange = TRUE;

			pTempZone->pidCtrl.bRetry=1;
			PIDController_setSP( &(pTempZone->pidCtrl), newSetPointValue);		
		
			pTempZone->m_bSecondaryHiProcCountdownOn = FALSE;

			PIDController_setInternalTestForDrawWarning( &(pTempZone->pidCtrl), FALSE );
			PIDController_setHiProcCountdownOn( &(pTempZone->pidCtrl), FALSE );
		}
	}
	return TRUE;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_setZoneAuto



	GLOBALS:
	RETURNS:	none
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_setZoneAuto(TempZone* pTempZone, enum ZoneTriState autoState )
{
	PARAM_CHECK( pTempZone, "TempZone_setZoneAuto");
	// 0 = manual
	// 1 = auto
	// 2 = off
	
	PIDController_setZoneMode( &(pTempZone->pidCtrl), autoState );
	
	if(pTempZone->pidCtrl.zoneAuto != eMANUAL)
	{
		pTempZone->onInitTPO = 0;
	}
	
	TempZone_setAlarmsEnabled(pTempZone, FALSE);
	TempZone_setDeadBandState(pTempZone, FALSE);
}

//******************************************************************************
// TempZone_setActive
//
// Abstract:
// The operator interface will only allow tempzones that are configured to go
// to active state. All zones are considered inactive until told otherwise.
// 
//
// Programmer: Steven Young
// Date: 03/27/1998
//
// Rev History.
// 05/06/1998 - SDY -  	Originally this function changed all the setpoints and
//						alarm and warning band parameters. Changing from Active
//						to open loop should not lose alarm and warning bands.
//						Although as a safety precaution set the TPO output to
//						0%.
//
//                      Changing from open loop to closed loop requires a power
//						up sequencing to occur. This will prevent the operator
// 						from switching from auto to manual to bypass sequencing.
//
//						During PowerUpSequencing or CoolDown modes a zone cannot
//						be made active only inactive.
//
//******************************************************************************
BOOL TempZone_setActive(TempZone* pTempZone, BOOL active )
{
	BOOL status = FALSE;
	enum OperationMode heaterState;
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setActive", 0);
	BOOL bEnable = FALSE;


	heaterState = TempZones_getOperationMode(tempZonesDb );

	if ( heaterState == PowerUpSequencing  )
	{
		status = FALSE;		// don't allow changes while doing a power up sequencing.
	}
	else
	{
		if ( active == TRUE  )
		{
			// check for a zone that is transitioning from inactive to active for
			// rise rate checking.
			if ( pTempZone->pidCtrl.bZoneActive == FALSE && active == TRUE )
			{

				TempZone_setDeadBandState(pTempZone, FALSE);
				TempZone_setAlarmsEnabled(pTempZone, FALSE);
			}

			PIDController_setActive( &(pTempZone->pidCtrl), active );
			
			if ( Oven_getJob(ovenDb) == COOLDOWN )
			{
				bEnable	= FALSE;
			}
			else
			{
				bEnable = TRUE;
			}
			PIDController_setPidEnable( &(pTempZone->pidCtrl), bEnable );


			
			TempZone_enableDeadBandRangeCheck(pTempZone, TRUE);
			
			status = TRUE;
		}
		else
		{
			// if zone not present it is not active!
			// it can also be set inactive by the operator.
			PIDController_setActive( &(pTempZone->pidCtrl), FALSE );
	

			PIDController_setPidEnable( &(pTempZone->pidCtrl), FALSE );
			PIDController_setTpo( &(pTempZone->pidCtrl), 0 );

			if(!pTempZone->m_iTestPath)
			{
				PIDController_AddSafeSegment(&(pTempZone->pidCtrl), (unsigned int)pTempZone->pidCtrl.dwrdOurOutput, 0x01);
			}

			PIDController_writeTpo( &(pTempZone->pidCtrl), 0);

			status = TRUE;
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_process
				All functions related to each temperature zone. Rise Rate, sequencing and
				 PID calculations, to name a few.
			
 GLOBALS:	ovenDb, timerDb
 RETURNS:   void
------------------------------------------------------------------------*/
void TempZone_process(TempZone* pTempZone)
{
	UINT currentJobNo;
	signed char bReturn;
	signed int iGlobalHiProc;
	BOOL bDirection;
	BOOL bCooldownComplete;

	DWORD ovenTerminal;
	BOOL bJobLoading;
	SHORT sZoneState;
	DWORD tim;
	DWORD oldSelfAck;
						
	LONG lCoolMaxOutput;
	
	lCoolMaxOutput = 0;

	currentJobNo = 0;
	tim = 0;
	bDirection = 0;
	bReturn = 0;
	iGlobalHiProc = 0;

	bCooldownComplete = FALSE;
	ovenTerminal = 0;
	bJobLoading = FALSE;
	sZoneState = eOFF;
	oldSelfAck = 0;

	currentJobNo = Oven_getJob(ovenDb);
	tim = Timer_getCurrentTime10ths(timerDb);
	bDirection = Oven_getDirection(ovenDb);

	if(pTempZone)
	{
		if ( pTempZone->pidCtrl.bLocalZone ||  (bDirection == TRUE) )
		{
			if ( pTempZone->directionalIOset == FALSE )
			{
				TempZone_configureIO(pTempZone);
			}
		}
	
		bReturn = PIDController_updatePV( &(pTempZone->pidCtrl) );
		if ( bReturn != 0 )
		{
			pTempZone->commLossAttemptsII = 0;
		}
			
		oldSelfAck = pTempZone->selfAckAlarmNo;
		pTempZone->selfAckAlarmNo = PIDController_getSelfAckAlarmNo( &(pTempZone->pidCtrl) );
		if( (oldSelfAck != 0) && (pTempZone->selfAckAlarmNo != oldSelfAck) && (pTempZone->selfAckAlarmNo != 0) ) //update ver8.0.0.11 to add 3rd && check
		{
			AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, oldSelfAck);
		}

		if ( pTempZone->pidCtrl.bZoneActive == FALSE )
		{
			// if the zone is not active make sure this is always off.
			PIDController_setTpo( &(pTempZone->pidCtrl), 0 );
			pTempZone->onInitTPO = 0;
		}
		else
		{
			iGlobalHiProc = PIDController_checkGlobalHighProcess( &(pTempZone->pidCtrl) );
			TempZone_checkDelayPeriod(pTempZone);
			TempZone_checkRiseRate(pTempZone);
			if(!iGlobalHiProc)	// the zone must be active.
			{
 				if( (pTempZone->pidCtrl.bLocalZone == FALSE) && (pTempZone->pidCtrl.m_bSetpointSendFailed == TRUE) )
				{
					PIDController_setSP(&(pTempZone->pidCtrl), pTempZone->pidCtrl.sp);	
					if(	pTempZone->pidCtrl.bRetry != 0)
					{
						pTempZone->pidCtrl.m_bSetpointSendFailed = TRUE;
					}
				}
				if(pTempZone->pidCtrl.bLocalZone == FALSE)
				{
					PIDController_setPidEnable(&(pTempZone->pidCtrl), pTempZone->pidCtrl.pidEnabled);
				}

				PIDController_checkSelfAcknowledgeAlarms(&(pTempZone->pidCtrl));

				if ( currentJobNo == COOLDOWN || 
						pTempZone->pidCtrl.zoneAuto == eOFF )
				{
					PIDController_setTpo( &(pTempZone->pidCtrl), 0 );
					PIDController_TPOToDigitalTime(&(pTempZone->pidCtrl));
					if(currentJobNo == COOLDOWN)
					{
						bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
						ovenTerminal = Oven_getTerminal(ovenDb);
						lCoolMaxOutput = (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS); 
						if(!bCooldownComplete && (pTempZone->pidCtrl.coolOutput < lCoolMaxOutput) && 
							pTempZone->pidCtrl.mCoolingOnInCooldown && (ovenTerminal != 0) )
						{
							if(pTempZone->pidCtrl.coolSP < pTempZone->pidCtrl.pv)
							{
								pTempZone->pidCtrl.tpoOutputCooling = MAX_TPO_COUNTS;
							}
							else
							{
								pTempZone->pidCtrl.tpoOutputCooling = 0;
							}
						}
						else
						{						
							pTempZone->pidCtrl.tpoOutputCooling = 0;
						}
					}
					else
					{
						pTempZone->pidCtrl.tpoOutputCooling = 0;
					}
				}
				else
				{
					if( (pTempZone->pidCtrl.pidEnabled == FALSE) && (pTempZone->pidCtrl.mbSequence == TRUE) )
					{
						pTempZone->pidCtrl.tpoOutputCooling = 0;
					}
					// if the zoneAuto is manual or auto then alarms need to be monitored.
					bJobLoading = Oven_isJobLoadInProgress(ovenDb);
					if ( bJobLoading == FALSE )
					{ 
						// alarm bands are always checked independent of the state of the PID;
						TempZone_checkAlarmBands(pTempZone);	
						sZoneState = TempZone_getZoneState(pTempZone);
						if ( sZoneState != eAUTO )
						{
							pTempZone->lastCheckTime = tim;
						}

						if ( (pTempZone->pidCtrl.pidEnabled == TRUE) && 
								(sZoneState == eAUTO) )
						{
							TempZone_calcPid(pTempZone);

							if(pTempZone->m_bEnableOverDrawWarning && 
								pTempZone->pidCtrl.m_bInternalTestForDrawWarning)
							{
								if( (pTempZone->pidCtrl.tpoOutput >= pTempZone->m_iOverdrawPercentage) &&
									(pTempZone->pidCtrl.groupNo != TH_STARTUPGROUP) )
								{
									if ( pTempZone->overdrawTime == 0 )
									{
										pTempZone->overdrawTime = tim;
									}
									if ( (tim - pTempZone->overdrawTime) > TENTHS_IN7_SECONDS )//seven second arbitrary choice
									{
										AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_DRAW_WARNING_WARNING,
										pTempZone->pidCtrl.zoneNo);
									}
								}	
								else
								{
									pTempZone->overdrawTime = 0;
								}
							}
							else
							{
								pTempZone->overdrawTime = 0;
							}
						}
						else
						{
							lCoolMaxOutput = (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);
							if( (pTempZone->pidCtrl.coolOutput < lCoolMaxOutput ) && (pTempZone->pidCtrl.mbSequence == FALSE) )
							{
								if(pTempZone->pidCtrl.coolOnOff == 0)
								{
									PID_calcPID(&(pTempZone->pidCtrl.coolPID));
								}
								else  //on off direct for now
								{
									if(pTempZone->pidCtrl.coolSP < pTempZone->pidCtrl.pv)
									{
										pTempZone->pidCtrl.tpoOutputCooling = MAX_TPO_COUNTS;
									}
									else
									{
										pTempZone->pidCtrl.tpoOutputCooling = 0;
									}
								}
							}
						}
					}
				}
				PIDController_setPreviousJob( &(pTempZone->pidCtrl), currentJobNo);
			}

			if(!pTempZone->m_iTestPath)
			{
				PIDController_AddSafeSegment(&(pTempZone->pidCtrl),
					(unsigned int)pTempZone->pidCtrl.dwrdOurOutput, SAFE_SEGMENT_CONTROL);
			}

			if((pTempZone->pidCtrl.zoneAuto == eMANUAL) && !pTempZone->m_bGroupStarted)
			{
				if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
				{
					if(!pTempZone->m_iTestPath)
					{
						PIDController_AddSafeSegment(&(pTempZone->pidCtrl), 
						(unsigned int)pTempZone->pidCtrl.dwrdOurOutput, SAFE_SEGMENT_CONTROL);
					}
					pTempZone->pidCtrl.tpoOutputCooling = 0;
					PIDController_TPOToDigitalTime(&(pTempZone->pidCtrl));
					if(pTempZone->m_bOff == TRUE)
					{
						ANALOGOUT_set(analogOutDb, (unsigned int)pTempZone->pidCtrl.dwrdOurOutput, (WORD) 0 );
					}
					else
					{
						ANALOGOUT_set(analogOutDb, (unsigned int)pTempZone->pidCtrl.dwrdOurOutput, (WORD) 0 );
					}
				}
				else
				{
					PIDController_TPOToDigitalTime(&(pTempZone->pidCtrl));
					PIDController_writeTpo( &(pTempZone->pidCtrl), 0);
				}
			}
			else
			{
				if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
				{
					if(!pTempZone->m_iTestPath)
					{
						PIDController_AddSafeSegment(&(pTempZone->pidCtrl), 
								(unsigned int)pTempZone->pidCtrl.dwrdOurOutput , SAFE_SEGMENT_CONTROL);				
					}

					if(pTempZone->m_bOff == TRUE)
					{			
						ANALOGOUT_set(analogOutDb, (unsigned int)pTempZone->pidCtrl.dwrdOurOutput, (WORD) 0);
						pTempZone->pidCtrl.tpoOutputCooling = 0;
						PIDController_TPOToDigitalTime(&(pTempZone->pidCtrl));
					}
					else
					{
						ANALOGOUT_set(analogOutDb, (unsigned int)pTempZone->pidCtrl.dwrdOurOutput, (WORD) pTempZone->pidCtrl.tpoOutput);
						PIDController_TPOToDigitalTime(&(pTempZone->pidCtrl));
					}
				}
				else
				{
					PIDController_writeCalculatedTpo( &(pTempZone->pidCtrl) );
				}
			}
		}
	}
	return;
}


//******************************************************************************
// BOOL TempZone_IsZoneInWarnging()
//
// Abstract:
// Used to check if the zone is in a warning state. As part of the auto acknowledgement
// mechanism the individual zones will be displayed in yellow if a warning is present.
// Upon screen updating a check must be done to see if the zone is still in warning or 
// not. If it is not still in warning, automatically cleared or operator cleared the 
// zone must be changed to green. If the selfAckAlarmNo > 0 then an alarm of warning
// type has been activated. An ID is returned and is never 0.
//
// Programmer: Steven Young
// Date: 08/10/2000
//
//******************************************************************************
BOOL TempZone_IsZoneInWarning(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_IsZoneInWarning", 0);
	DWORD localSA = 0;
	BOOL bReturn = TRUE;
    if ( pTempZone->selfAckAlarmNo > 0&& pTempZone->selfAckAlarmNo!=-1)
    {
		localSA=pTempZone->selfAckAlarmNo;
        //if ((PIDController_getClearLocal(&(pTempZone->pidCtrl))!=1)&&AlarmQueue_findAcknowledgedAlarm(alarmQueueDb, pTempZone->pidCtrl.selfAckAlarmNo) == TRUE)	//ver8.0.0.28
		if (AlarmQueue_findAcknowledgedAlarm(alarmQueueDb, pTempZone->pidCtrl.selfAckAlarmNo) == TRUE)
		{
            bReturn = FALSE;
        }
    }
    else
    {
        bReturn = FALSE;
    }
	return bReturn;
}

//******************************************************************************
// TempZone_checkAlarmBands()
//
// Abstract:
// When power up sequencing begins wait for the delay time before monitoring the
// riserate( degrees c/time seconds ). If the PV is within the deadband enable
// alarms. Do not check for alarmbands when COOLDOWN is loaded.
//
//
// Programmer: Steven Young
// Date: 05/07/1998
//
//******************************************************************************
void TempZone_checkAlarmBands(TempZone* pTempZone)
{ 
	PARAM_CHECK( pTempZone, "TempZone_checkAlarmBands");
	PIDController_checkAlarmBands(&pTempZone->pidCtrl);
}  

//******************************************************************************
// TempZone_resetPID()
//
// Abstract:
// The delay in startup has caused a problem with five zones at 100%. By resetting 
// the PID loop it is hoped that this problem is resolved.
//
// Programmer: Steven Young
// Date: 08/25/2000
//
//******************************************************************************
/*void TempZone_resetPID( void  )
{
    pid.reset();
}*/

//******************************************************************************
// TempZone_getCurrentState()
//
// Abstract:
// In order for the auto-acknowledgement to work the current state of the tempzone
// must be transferred. 
// State Values:
//      0 - Startup - White
//      1 - Operational - Achieved Deadband and within warning band parameters - Green
//      2 - Warning State - Yellow
//
// Programmer: Steven Young
// Date: 08/22/2000
//
//******************************************************************************
DWORD TempZone_getCurrentState(TempZone* pTempZone)
{
    DWORD state = 1;  // Green
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getCurrentState", 0);
	
	if ( (pTempZone->pidCtrl.alarmBandsEnabled == FALSE ) /*&& (pTempZone->zoneAuto == eAUTO)*/)
	{
		state = 0;  // deadband has not been achieved. White
	}
	else
	{
//added check for secondary values
		if ( ((pTempZone->selfAckAlarmNo != 0) && (pTempZone->selfAckAlarmNo != -1)) ||
			((pTempZone->pidCtrl.selfAckAlarmNo != 0) && (pTempZone->pidCtrl.selfAckAlarmNo != -1)) ||
			(pTempZone->selfAckAlarmSecondNo != 0) )
		{
			state = 2;  // Warning - Yellow
		}
	}



	return state;
}

//modified case statements per example below, WDT 02.19.02
//direct intialization of a pointer to shared memory where the secondary boards present values will be written.
//by setting a pointer based on the input pointer we will allow left-right redraw functionality by default.
///
void TempZone_configureIO(TempZone* pTempZone)
{
	PARAM_CHECK( pTempZone, "TempZone_configureIO");
	pTempZone->directionalIOset = TRUE;
	
	if ( Oven_getDirection(ovenDb) == TRUE ) // Right to Left 
	{
		switch( Oven_getModelNo(ovenDb) )
		{
			case e1088_OVENMODELS:
				TempZone_configureIO1088(pTempZone);
				break;
			case e1500_OVENMODELS:
				TempZone_configureIO1500(pTempZone);
				break;
			case e1700_OVENMODELS:
				TempZone_configureIO1700(pTempZone);
				break;

			case e1800_OVENMODELS:
				TempZone_configureIO1800(pTempZone);
				break;

			case e1800Z_OVENMODELS:
				TempZone_configureIO1800Z(pTempZone);
				break;

			case e1910_OVENMODELS: 
				TempZone_configureIO1910(pTempZone);
				break;

			case e1911_OVENMODELS: 
				TempZone_configureIO1911(pTempZone);
				break;

			case e1912_OVENMODELS:
				TempZone_configureIO1912(pTempZone);
				break;

			case e1913_OVENMODELS:
				TempZone_configureIO1913(pTempZone);
				break;
			case e1707_OVENMODELS:
				TempZone_configureIO1707(pTempZone);
				break;

			case e1914_OVENMODELS:
				TempZone_configureIO1914(pTempZone);
				break;
			case e1917_OVENMODELS:
				TempZone_configureIORL1917(pTempZone);
				break;
			case e2024_OVENMODELS:
				TempZone_configureIORL2024(pTempZone);
				break;
			case e2060_OVENMODELS:
				TempZone_configureIORL2060(pTempZone);
				break;
			case e2018_OVENMODELS:
				TempZone_configureIORL2018(pTempZone);
				break;
			case e1707_DUAL_OVENMODELS:
				TempZone_configureIORLDual1707(pTempZone);
				break;
			case e1913_MS_OVENMODELS:
				TempZone_configureIORL1913(pTempZone);
				break;
			case e1914_MS_OVENMODELS:
				TempZone_configureIORL1914(pTempZone);
				break;
			default:
				pTempZone->directionalIOset = TRUE;
				break;
		}
	}
}

DWORD TempZone_getSetPoint(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getSetPoint", 0);
	return pTempZone->pidCtrl.sp;
}


/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_setPowerUpComplete

				

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_setPowerUpComplete(TempZone* pTempZone, BOOL bSetTo )
{
	PARAM_CHECK( pTempZone, "TempZone_setPowerUpComplete");

	PIDController_setPowerUpComplete(&(pTempZone->pidCtrl), bSetTo);
}

//******************************************************************************
// TempZone_setDrawWarningPercentage
//
// Abstract:
//Sets the minimum value for the draw warning, converting within function from percent to
//absolute TPO val*256/100.  Warning is enabled through an inline function call when the 
//lighttower is green.
//
// Programmer: Wallace Tree
// Date: 10/10/2002
//
//******************************************************************************

void TempZone_setDrawWarningPercentage(TempZone* pTempZone, int drawPercent)
{
	PARAM_CHECK( pTempZone, "TempZone_setDrawWarningPercentage");
	pTempZone->m_iOverdrawPercentage = 256 * drawPercent / 100;
}

//******************************************************************************
// TempZone_isInDeviationAlarmZone
//
// Abstract:
//This is used to tell the zone to display red although only a warning event has occurred
//testing against the light alarm field in the setup wizard and indeadband which is flagged
//when deadband is first achieved and reset by a new setpoint, recipe, or mode switch
//
// Programmer: Wallace Tree
// Date: 10/29/2002
//
//******************************************************************************


SHORT TempZone_isInDeviationAlarmZone(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isInDeviationAlarmZone", 0);
	SHORT sReturn = FALSE;
	if(pTempZone->pidCtrl.inDeadBand && AlarmQueue_getCooldownPreference(alarmQueueDb))
	{
// TZ_LO_DEVIATION_ALARM:
		if ( pTempZone->pidCtrl.pv <= (long)( pTempZone->pidCtrl.sp - pTempZone->pidCtrl.alarmLowTempOffset )&& pTempZone->pidCtrl.ltAlarmEnable == TRUE )
		{
			sReturn = TRUE;
		}
// TZ_HI_DEVIATION_ALARM:
		else if ( pTempZone->pidCtrl.pv >= (long)( pTempZone->pidCtrl.sp + pTempZone->pidCtrl.alarmHighTempOffset ) && pTempZone->pidCtrl.htAlarmEnable == TRUE )
		{
			sReturn = TRUE;
		}

	}
	return sReturn;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_setHiProcDelay


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_setHiProcDelay(TempZone* pTempZone, int iDelay)
{
	PARAM_CHECK( pTempZone, "TempZone_setHiProcDelay");
	PIDController_setHiProcDelay( &(pTempZone->pidCtrl), (DWORD) iDelay );
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_enableDeadBandRangeCheck


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void	TempZone_enableDeadBandRangeCheck(TempZone* pTempZone, BOOL dbFlag /*= TRUE*/ )
{
	PARAM_CHECK( pTempZone, "TempZone_enableDeadBandRangeCheck");
	PIDController_enableDeadBandRangeCheck( &(pTempZone->pidCtrl), dbFlag ); 
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isInDeadBandRangeCheckEnabled


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isInDeadBandRangeCheckEnabled(TempZone* pTempZone) 
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isInDeadBandRangeCheckEnabled", 0);
	return pTempZone->pidCtrl.deadBandEnableStatus; 
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_setDeadBandState


	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void  TempZone_setDeadBandState(TempZone* pTempZone, BOOL dbState )    
{ 
	PARAM_CHECK( pTempZone, "TempZone_setDeadBandState");

	PIDController_setDeadBandState( &(pTempZone->pidCtrl), dbState );
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isPIDenabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL TempZone_isPIDenabled(TempZone* pTempZone)
{
	BOOL bReturn = FALSE;
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isPIDenabled", 0);
	bReturn = pTempZone->pidCtrl.pidEnabled;
	return bReturn;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isActive


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isActive(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isActive", 0);
	return pTempZone->pidCtrl.bZoneActive;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isHiProcAlarmEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isHiProcAlarmEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isHiProcAlarmEnabled", 0);
	return pTempZone->pidCtrl.hiProcAlarmEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isLohProcAlarmEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isLohProcAlarmEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isLohProcAlarmEnabled", 0);
	return pTempZone->pidCtrl.loProcAlarmEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isHiDeviationAlarmEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isHiDeviationAlarmEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isHiDeviationAlarmEnabled", 0);
	return pTempZone->pidCtrl.htAlarmEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isLoDeviationAlarmEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/
BOOL	TempZone_isLoDeviationAlarmEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isLoDeviationAlarmEnabled", 0);
	return pTempZone->pidCtrl.ltAlarmEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isHiDeviationWarningEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/

BOOL	TempZone_isHiDeviationWarningEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isHiDeviationWarningEnabled", 0);
	return pTempZone->pidCtrl.htWarnEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isLoDeviationWarningEnabled


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/

BOOL	TempZone_isLoDeviationWarningEnabled(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isLoDeviationWarningEnabled", 0);
	return pTempZone->pidCtrl.ltWarnEnable;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_isInDeadBandZone


	GLOBALS:
	RETURNS:	BOOL.
	SEE ALSO:  
------------------------------------------------------------------------*/

BOOL	TempZone_isInDeadBandZone(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_isInDeadBandZone", 0);
	return pTempZone->pidCtrl.inDeadBand; 
}

SHORT	TempZone_getZoneState(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getZoneState", 0);
	return pTempZone->pidCtrl.zoneAuto; 
}

DWORD	TempZone_getHiProcTemp(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getHiProcTemp", 0);
	return pTempZone->pidCtrl.highProcess;
}

DWORD	TempZone_getLoProcTemp(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getLoProcTemp", 0);
	return pTempZone->pidCtrl.lowProcess;
}

DWORD	TempZone_getAlarmHiTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getAlarmHiTempOffset", 0);
	return pTempZone->pidCtrl.alarmHighTempOffset;
}

DWORD	TempZone_getAlarmLoTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getAlarmLoTempOffset", 0);
	return pTempZone->pidCtrl.alarmLowTempOffset;
}

DWORD	TempZone_getWarnHiTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getWarnHiTempOffset", 0);
	return pTempZone->pidCtrl.warnHighTempOffset;
}

DWORD	TempZone_getWarnLoTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getWarnLoTempOffset", 0);

	return pTempZone->pidCtrl.warnLowTempOffset;
}

DWORD	TempZone_getDeadBandHiTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getDeadBandHiTempOffset", 0);
	return pTempZone->pidCtrl.deadBandHighTempOffset;
}

DWORD	TempZone_getDeadBandLoTempOffset(TempZone* pTempZone)
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getDeadBandLoTempOffset", 0);
	return pTempZone->pidCtrl.deadBandLowTempOffset;
}

DWORD TempZone_getSequenceGroup	(TempZone* pTempZone)						
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getSequenceGroup", 0);
	return pTempZone->pidCtrl.groupNo;
}

DWORD TempZone_getTPOoutput		(TempZone* pTempZone)						
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getTPOoutput", 0);

	return PIDController_getTPO(&(pTempZone->pidCtrl)); // pTempZone->pidCtrl.tpoOutput;
}

DWORD TempZone_getZoneNo		(TempZone* pTempZone)						
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getZoneNo", 0);
	return pTempZone->pidCtrl.zoneNo;
}

DWORD TempZone_getProcVar		(TempZone* pTempZone)						
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getProcVar", 0);
	return pTempZone->pidCtrl.pv; 
}

const char * const TempZone_getName	(TempZone* pTempZone)						
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_getName", 0);
	return pTempZone->name;
}

void TempZone_setPIDenable(TempZone* pTempZone, BOOL pe ) 		 		
{
	PARAM_CHECK( pTempZone, "TempZone_setPIDenable");
	PIDController_setPidEnable( &(pTempZone->pidCtrl), pe );
}

void TempZone_setAlarmsEnabled(TempZone* pTempZone, BOOL state ) 				
{
	PARAM_CHECK( pTempZone, "TempZone_setAlarmsEnabled");
	PIDController_setAlarmsEnabled( &(pTempZone->pidCtrl), state );
}

void TempZone_setTPOoutput		(TempZone* pTempZone, LONG   cTPOoutput )		
{
	PARAM_CHECK( pTempZone, "TempZone_setTPOoutput");
 	PIDController_setTpo( &(pTempZone->pidCtrl), cTPOoutput );
}

void TempZone_enableHiProcAlarm	(TempZone* pTempZone, BOOL enable )				
{
	PARAM_CHECK( pTempZone, "TempZone_enableHiProcAlarm");
	PIDController_enableHiProcAlarm( &(pTempZone->pidCtrl), enable );
}

void TempZone_enableLoProcAlarm	(TempZone* pTempZone, BOOL enable )   	        
{
	PARAM_CHECK( pTempZone, "TempZone_enableLoProcAlarm");
	PIDController_enableLoProcAlarm( &(pTempZone->pidCtrl), enable ); 
}

void TempZone_calcPid(TempZone* pTempZone)
{
	PARAM_CHECK( pTempZone, "TempZone_calcPid");
	if( TempZone_isPIDenabled(pTempZone)==TRUE ) 
	{
		PIDController_calcPid(&(pTempZone->pidCtrl)); 
	}
}

BOOL TempZone_setProcVariable(TempZone* pTempZone, DWORD   newProcVar ) 
{
	PARAM_CHECK_RETURN( pTempZone, "TempZone_setProcVariable", 0);
	PIDController_setPV( &(pTempZone->pidCtrl), newProcVar); 
	return TRUE; 
}		

void	TempZone_EnableDrawWarning(TempZone* pTempZone, BOOL bEnable)
{
	PARAM_CHECK( pTempZone, "TempZone_EnableDrawWarning");
	pTempZone->m_bEnableOverDrawWarning = bEnable;
}

void TempZone_setGlobalHighProcess(TempZone* pTempZone, LONG newHP)
{
	PIDController_setGlobalHighProcess( &(pTempZone->pidCtrl), newHP );
}

void TempZone_testTPOPath(TempZone* pTempZone, int iTest)
{
	pTempZone->m_iTestPath = iTest;
}

void TempZone_set_pendTPOoutput(TempZone* pTempZone, LONG cTPOoutput)
{
 	PIDController_setTpo( &(pTempZone->pidCtrl), cTPOoutput );
	
	pTempZone->onInitTPO = cTPOoutput;
}

void TempZone_manualZoneSequencedOn(TempZone* pTempZone)
{
	if((pTempZone->pidCtrl.bZoneActive == TRUE) && 
		(pTempZone->pidCtrl.zoneAuto == eMANUAL))
	{
 		PIDController_setTpo( &(pTempZone->pidCtrl), pTempZone->onInitTPO );
	}
}
void TempZone_setGroupStarted(TempZone* pTZone, BOOL bSet)
{
	pTZone->m_bGroupStarted = bSet;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_initTcInput
			
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_initTcInput(TempZone* pTempZone, UINT nIndex)
{
	PARAM_CHECK( pTempZone, "TempZone_initTcInput");
	pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, nIndex);
	pTempZone->pidCtrl.m_nTcInput = nIndex;	
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_initTPOoutput
			
			
 GLOBALS:	analogOutDb
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_initTPOoutput(TempZone* pTempZone, UINT nIndex)
{
	PARAM_CHECK( pTempZone, "TempZone_initTPOoutput");

	if( (nIndex != NULL_TEMP_IO) && (nIndex < MAX_ANALOG_OUTPUTS) )
	{
		pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, nIndex);
		ANALOGOUT_setOwned(analogOutDb, nIndex);
		
		pTempZone->pidCtrl.m_nTPOoutput = nIndex;
		pTempZone->pidCtrl.dwrdOurOutput = nIndex;
	}
	else
	{
		if(pTempZone->pidCtrl.m_nTPOoutput && (pTempZone->pidCtrl.m_nTPOoutput != (MAX_ANALOG_OUTPUTS+1) ) )
		{
			ANALOGOUT_setFree(analogOutDb, nIndex);
		}
		pTempZone->pidCtrl.m_nTPOoutput = NULL_OUTPUT_POINTER;
		pTempZone->pidCtrl.dwrdOurOutput = 100;
	}
	return;
}

DWORD TempZone_getInputVal(TempZone* pTempZone)
{
	return pTempZone->pidCtrl.m_nTcInput;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_blowerFailure
			
			if the zone is active this will deactivate tpo and request cooldown
			from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_blowerFailure(TempZone* pTempZone, BOOL bOFF)
{
	if(pTempZone->pidCtrl.bZoneActive)
	{
		pTempZone->m_bOff = bOFF;
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_BLOWER_OFF, pTempZone->pidCtrl.zoneNo);
			Oven_requestCooldown(ovenDb); 
		}
		PIDController_suspendSecondaryWrite( &(pTempZone->pidCtrl), bOFF);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_currentMonitorFailureLow
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_currentMonitorFailureLow(TempZone* pTempZone, BOOL bOFF)
{
	if(pTempZone->pidCtrl.bZoneActive)
	{
		pTempZone->m_bOff = bOFF;
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_TEMP_ZONE_CURRENT_LOW, pTempZone->pidCtrl.zoneNo);
			Oven_requestCooldown(ovenDb); 
		}
		PIDController_suspendSecondaryWrite( &(pTempZone->pidCtrl), bOFF);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_currentMonitorFailureHigh
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_currentMonitorFailureHigh(TempZone* pTempZone, BOOL bOFF)
{
	if(pTempZone->pidCtrl.bZoneActive)
	{
		pTempZone->m_bOff = bOFF;
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_TEMP_ZONE_CURRENT_HIGH, pTempZone->pidCtrl.zoneNo);
			Oven_requestCooldown(ovenDb); 
		}
		PIDController_suspendSecondaryWrite( &(pTempZone->pidCtrl), bOFF);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_heaterFailure
			
			if the zone is active this will deactivate tpo and request cooldown from the oven

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_heaterFailure(TempZone* pTempZone, BOOL bOFF)
{
	if(pTempZone->pidCtrl.bZoneActive)
	{
		pTempZone->m_bOff = bOFF;
		if(bOFF == TRUE)
		{
			AlarmQueue_addAlarm(alarmQueueDb, WARNING, HEATER_TEMP_ZONE_FAILURE, pTempZone->pidCtrl.zoneNo);
			Oven_requestCooldown(ovenDb); 
		}
		PIDController_suspendSecondaryWrite( &(pTempZone->pidCtrl), bOFF);
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_setCoolOutput
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_setCoolOutput(TempZone* pTempZone, DWORD output)
{
	PARAM_CHECK( pTempZone, "TempZone_setCoolOutput");
	PIDController_setCoolOutput( &(pTempZone->pidCtrl), output);
	return;
}
void TempZone_setCoolPeriod(TempZone* pTempZone, DWORD period)
{
	PARAM_CHECK( pTempZone, "TempZone_setCoolPeriod");
	PIDController_setCoolPeriod( &(pTempZone->pidCtrl), period);

}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1088

			configures IO for RL configuration for 1088
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1088(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 2:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput  = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 4:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 6:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1500

			configures IO for RL configuration for 1500
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1500(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 4:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 6:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 8:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1700

			configures IO for RL configuration for 1700
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1700(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 6:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 8:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 10:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1800

			configures IO for RL configuration for 1800
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1800(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 10:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 12:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;

	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1800Z

			configures IO for RL configuration for 1800Z
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1800Z(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 10: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 12:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 16:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1912

			configures IO for RL configuration for 1912
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1912(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ12);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ12);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ11);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ11);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ10);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ10);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 10:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 12:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 16: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
		break;
			case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 18:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 19:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 20:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 21:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 22:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 23:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;

	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1913

			configures IO for RL configuration for 1913
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1913(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ12);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ11);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ11);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ10);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ10);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 10:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 12:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 16: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
		break;
		case 18:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 19:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 20:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 21:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;

		case 22:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 23:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1707

			configures IO for RL configuration for 1707
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1707(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 8:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 10:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 12:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;

	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1914

			configures IO for RL configuration for 1914
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void TempZone_configureIO1914(TempZone* pTempZone)
{
	FluxHeater* ptrFlux = NULL;

	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0:
		case 1:
			break;
		case 2://assign flux 0 to set 2 upper
			ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 0);
			FluxHeater_initTPOoutput(ptrFlux, TPO_UPZ2);
			FluxHeater_initTcInput(ptrFlux, AI_UPZ2);
			break;
		case 3://assign flux 3 to set 2 lower
			ptrFlux = DbContainer_getCorrectFluxheater(&g_dbContainer, 1);
			FluxHeater_initTPOoutput(ptrFlux, TPO_LOWZ2);
			FluxHeater_initTcInput(ptrFlux, AI_LOWZ2);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ12);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ12);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ11);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ11);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ10);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ10);
			break;
		case 10: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 12: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 16:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 18:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 19:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 20: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 21:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 22:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 23:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 24:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 25:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1910

			configures IO for RL configuration for 1910
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void	TempZone_configureIO1910(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ10);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ10);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 10: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 12: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 14:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 16:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 18:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 19:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	} 
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_configureIO1911

			configures IO for RL configuration for 1911
			broken out to reduce size of the configure IO function

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void	TempZone_configureIO1911(TempZone* pTempZone)
{
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ11);
			break;
		case 1:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ11);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ11);
			break;
		case 2: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ10);
			break;
		case 3:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ10);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ10);
			break;
		case 4: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ9);
			break;
		case 5:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ9);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ9);
			break;
		case 6: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ8);
			break;
		case 7:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ8);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ8);
			break;
		case 8: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ7);
			break;
		case 9:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ7);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ7);
			break;
		case 10: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ6);
			break;
		case 11:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ6);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ6);
			break;
		case 12: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ5);
			break;
		case 13:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ5);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ5);
			break;
		case 14: 
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ4);
			break;
		case 15:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ4);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ4);
			break;
		case 16:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ3);
			break;
		case 17:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ3);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ3);
			break;
		case 18:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ2);
			break;
		case 19:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ2);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ2);
			break;
		case 20:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_UPZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_UPZ1);
			break;
		case 21:
			pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, AI_LOWZ1);
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			pTempZone->pidCtrl.pTPOoutput = ANALOGOUT_GetAt(analogOutDb, TPO_LOWZ1);
			break;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL1917

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL1917(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;

	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 1: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
			break;
		case 2: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
			break;
		case 3: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
			break;
		case 4: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
			break;
		case 5: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
			break;
		case 6: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;
		case 7: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;
		case 8: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 9: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		case 10:
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			break;
		case 11: 
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;

		case 12:
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
		case 13: 
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
		case 14: 
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			break;
		case 15: 
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			break;
		case 16: 
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			break;
		case 17: 
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			break;
		case 18: 
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			break;
		case 19: 
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			break;
		case 20: 
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			break;
		case 21: 
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			break;
		case 22: 
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			break;
		case 23: 
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			break;

		case 24:
			break;

		case 25:
			break;

		case 26:
			break;

		case 27:
			break;

		case 28: 
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			break;
		case 29: 
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			break;
		case 30: 
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			break;
		case 31: 
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			break;
		case 32: 
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			break;
		case 33: 
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			break;
		case 34: 
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			break;
		case 35: 
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			break;
		case 36: 
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			break;
		case 37: 
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			break;

		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
	return;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL2024

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL2024(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;

	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ12);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ12);
			break;
		case 1: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ12);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ12);
			break;
		case 2: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ11);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ11);
			break;
		case 3: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ11);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ11);
			break;
		case 4: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ10);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ10);
			break;
		case 5: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ10);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ10);
			break;
		case 6: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ9);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ9);
			break;
		case 7: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ9);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ9);
			break;
		case 8: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ8);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ8);
			break;
		case 9: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ8);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ8);
			break;
		case 10: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ7);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ7);
			break;
		case 11: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ7);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ7);
			break;
		case 12: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ6);
			break;
		case 13: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ6);
			break;
		case 14: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
			break;
		case 15: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
			break;
		case 16: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
			break;
		case 17: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
			break;
		case 18: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
			break;
		case 19: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
			break;
		case 20: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;
		case 21: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;
		case 22: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 23: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;
		case 24:
		case 25:
		case 26:
		case 27:
			break;
		case 28:
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			break;
		case 29: 
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			break;
		case 30:
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			break;
		case 31: 
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			break;
		case 32: 
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			break;
		case 33: 
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			break;
		case 34: 
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			break;
		case 35: 
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			break;
		case 36: 
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			break;
		case 37: 
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			break;
		case 38: 
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			break;
		case 39: 
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			break;
		case 40: 
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			break;
		case 41: 
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			break;
		case 42: 
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			break;
		case 43: 
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			break;
		case 44: 
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			break;
		case 45: 
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			break;
		case 46: 
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			break;
		case 47: 
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			break;
		case 48: 
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			break;
		case 49: 
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			break;
		case 50: 
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			break;
		case 51: 
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
	return;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL1913

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL1913(TempZone* pTempZone)
{
	PARAM_CHECK( pTempZone, "TempZone_configureIORL1913");

	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 1: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		case 2:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			break;
		case 3: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
		break;

		case 4:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			break;
		case 5: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			break;
		case 6: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			break;
		case 7: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			break;
		case 8: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			break;
		case 9: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
		break;
		case 10: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			break;
		case 11: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			break;
		case 12: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			break;
		case 13: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			break;
		case 14: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			break;
		case 15: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			break;

		case 16: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			break;
		case 17: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			break;
		case 18: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			break;
		case 19: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			break;
		case 20: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			break;
		case 21: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			break;
		case 22: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			break;
		case 23: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			break;
		case 28: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			break;
		case 29: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			break;
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}	
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
	return;
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL1914

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL1914(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;
		case 1: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;
		case 2: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 3: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		case 4:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			break;
		case 5: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
		break;

		case 6:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			break;
		case 7: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			break;
		case 8: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			break;
		case 9: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			break;
		case 10: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			break;
		case 11: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
		break;
		case 12: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			break;
		case 13: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			break;
		case 14: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			break;
		case 15: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			break;
		case 16: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			break;
		case 17: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			break;

		case 18: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			break;
		case 19: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			break;
		case 20: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			break;
		case 21: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			break;
		case 22: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			break;
		case 23: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			break;
		case 28: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			break;
		case 29: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			break;
		case 30: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			break;
		case 31: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			break;
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}	
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL2060

					// zones: 1-12, 29-30 exist on the master
					// zones: 13-28 exist on the slave
	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL2060(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;
	switch ( pTempZone->pidCtrl.zoneNo )
	{
		// zone 30
		case 0:
			aiIndex = AI_TCPORT4;
			aoIndex = TPO_ANALOG_FAN;
			break;
		case 1:
			aiIndex = AI_TCPORT5;
			aoIndex = TPO_EXHAUST_FLUX_HEATER;
			break;

		// zone 29
		case 2:
			aiIndex = AI_FREE_L1SR;
			aoIndex = TPO_FREECL1;
			break;
		case 3:
			aiIndex = AI_FREE_L2SR;
			aoIndex = TPO_FREECL2;
			break;

		////////////////////////////////////////////
		// START SLAVE ZONES
		//

		// zone 28
		case 4:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_CONVBELT1);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 5:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_GLOBAL_BLOWER_CONTROL);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;

		// zone 27
		case 6:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_ANALOG_FAN);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 7:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_EXHAUST_FLUX_HEATER);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_EXHAUST_FLUX_HEATER);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;

		// zone 26
		case 8:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_CONVBELT2);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 9:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_TCPORT5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_AVAILABLE);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;

		// zone 25
		case 10:
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_FREE_L1SR);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_FREECL1);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 11:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_FREE_L2SR);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_FREECL2);
			break;

		// zone 24
		case 12:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ12);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ12);
			break;
		case 13:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ12);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ12);
			break;

		// zone 23
		case 14:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ11);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ11);
			break;
		case 15:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ11);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ11);
			break;

		// zone 22
		case 16:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ10);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ10);
			break;
		case 17:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ10);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ10);
			break;

		// zone 21
		case 18:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ9);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ9);
			break;
		case 19:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ9);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ9);
			break;

		// zone 20
		case 20:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ8);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ8);
			break;
		case 21:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ8);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ8);
			break;

		// zone 19
		case 22:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ7);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ7);
			break;
		case 23:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ7);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ7);
			break;

		// zone 18
		case 24:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ6);
			break;
		case 25:
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ6);
			break;

		// zone 17
		case 26: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
			break;
		case 27: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
			break;

		// zone 16
		case 28: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
			break;
		case 29: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
			break;

		// zone 14
		case 30: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
			break;
		case 31: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
			break;

		// zone 15
		case 32: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;

		case 33: 
			pTempZone->pidCtrl.bLocalZone=TRUE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;

		// zone 13
		case 34: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 35: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		//
		// END SLAVE ZONES
		////////////////////////////////////////////

		// zone 12
		case 36:
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			break;
		case 37: 
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
			break;

		// zone 11
		case 38:
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			break;
		case 39: 
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			break;

		// zone 10
		case 40: 
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			break;
		case 41: 
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			break;

		// zone 9
		case 42: 
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			break;
		case 43: 
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
			break;

		// zone 8
		case 44: 
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			break;
		case 45: 
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			break;

		// zone 7
		case 46: 
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			break;
		case 47: 
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			break;

		// zone 6
		case 48: 
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			break;
		case 49: 
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			break;

		// zone 5
		case 50: 
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			break;
		case 51: 
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			break;

		// zone 4
		case 52: 
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			break;
		case 53: 
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			break;

		// zone 3
		case 54: 
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			break;
		case 55: 
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			break;

		// zone 2
		case 56: 
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			break;
		case 57: 
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			break;

		// zone 1
		case 58: 
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			break;
		case 59: 
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			break;

		default:
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}		
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
}
/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORLDual1707

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORLDual1707(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;

	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			break;
		case 1: 
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			break;
		case 2: 
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			break;
		case 3: 
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			break;
		case 4:
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			break;
		case 5: 
			aiIndex  = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			break;
		case 6:
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			break;
		case 7: 
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			break;
		case 8: 
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			break;
		case 9: 
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			break;
		case 10: 
			aiIndex =AI_UPZ2;
			aoIndex = TPO_UPZ2;
			break;
		case 11: 
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			break;
		case 12: 
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			break;
		case 13: 
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			break;
		case 14: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;
		case 15: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;
		case 16: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 17: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		case 18: 
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			break;
		case 19: 
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
			break;
		case 20: 
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			break;
		case 21: 
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			break;
		case 22: 
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			break;
		case 23: 
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			break;
		case 28: 
			aiIndex =AI_UPZ9;
			aoIndex = TPO_UPZ9;
			break;
		case 29: 
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
			break;
		case 30: 
			aiIndex =AI_UPZ8;
			aoIndex = TPO_UPZ8;
			break;
		case 31: 
			aiIndex =AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			break;
		default:
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}	
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_configureIORL2018

	GLOBALS:
	RETURNS:	void.
	SEE ALSO:  
------------------------------------------------------------------------*/
void TempZone_configureIORL2018(TempZone* pTempZone)
{
	pTempZone->pidCtrl.bLocalZone=TRUE;
	UINT aiIndex = 0xffff;
	UINT aoIndex = 0xffff;

	switch ( pTempZone->pidCtrl.zoneNo )
	{
		case 0: 
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ6);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 1: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ6);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ6);
			break;
		case 2: 
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ5);
			pTempZone->pidCtrl.bLocalZone=FALSE;
			break;
		case 3: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ5);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ5);
			break;
		case 4: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ4);
			break;
		case 5: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ4);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ4);
			break;
		case 6: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ3);
			break;
		case 7: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ3);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ3);
			break;
		case 8: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ2);
			break;
		case 9: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ2);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ2);
			break;
		case 10: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_UPZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_UPZ1);
			break;
		case 11: 
			pTempZone->pidCtrl.bLocalZone=FALSE;
			aiIndex = ANALOGIN_indexToSecondaryIndex(AI_LOWZ1);
			aoIndex = ANALOGOUT_indexToSecondaryIndex(TPO_LOWZ1);
			break;

		case 12:
			aiIndex = AI_UPZ12;
			aoIndex = TPO_UPZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ12;
			break;
		case 13: 
			aiIndex = AI_LOWZ12;
			aoIndex = TPO_LOWZ12;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ12;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;

		case 14:
			aiIndex = AI_UPZ11;
			aoIndex = TPO_UPZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ11;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
		case 15: 
			aiIndex = AI_LOWZ11;
			aoIndex = TPO_LOWZ11;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ11;
			pTempZone->pidCtrl.bLocalZone=TRUE;
			break;
		case 16: 
			aiIndex = AI_UPZ10;
			aoIndex = TPO_UPZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ10;
			break;
		case 17: 
			aiIndex = AI_LOWZ10;
			aoIndex = TPO_LOWZ10;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ10;
			break;
		case 18: 
			aiIndex = AI_UPZ9;
			aoIndex = TPO_UPZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ9;
			break;
		case 19: 
			aiIndex = AI_LOWZ9;
			aoIndex = TPO_LOWZ9;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ9;
			break;
		case 20: 
			aiIndex = AI_UPZ8;
			aoIndex = TPO_UPZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ8;
			break;
		case 21: 
			aiIndex = AI_LOWZ8;
			aoIndex = TPO_LOWZ8;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ8;
			break;
		case 22: 
			aiIndex = AI_UPZ7;
			aoIndex = TPO_UPZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ7;
			break;
		case 23: 
			aiIndex = AI_LOWZ7;
			aoIndex = TPO_LOWZ7;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ7;
			break;
		case 24: 
			break;
		case 25: 
			break;



		case 26:
			break;

		case 27:
			break;
		case 28: 
			aiIndex = AI_UPZ6;
			aoIndex = TPO_UPZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ6;
			break;
		case 29: 
			aiIndex = AI_LOWZ6;
			aoIndex = TPO_LOWZ6;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ6;
			break;
		case 30: 
			aiIndex = AI_UPZ5;
			aoIndex = TPO_UPZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ5;
			break;
		case 31: 
			aiIndex = AI_LOWZ5;
			aoIndex = TPO_LOWZ5;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ5;
			break;
		case 32: 
			aiIndex = AI_UPZ4;
			aoIndex = TPO_UPZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ4;
			break;
		case 33: 
			aiIndex = AI_LOWZ4;
			aoIndex = TPO_LOWZ4;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ4;
			break;
		case 34: 
			aiIndex = AI_UPZ3;
			aoIndex = TPO_UPZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ3;
			break;
		case 35: 
			aiIndex = AI_LOWZ3;
			aoIndex = TPO_LOWZ3;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ3;
			break;
		case 36: 
			aiIndex = AI_UPZ2;
			aoIndex = TPO_UPZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ2;
			break;
		case 37: 
			aiIndex = AI_LOWZ2;
			aoIndex = TPO_LOWZ2;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ2;
			break;
		case 38: 
			aiIndex = AI_UPZ1;
			aoIndex = TPO_UPZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_UPZ1;
			break;
		case 39: 
			aiIndex = AI_LOWZ1;
			aoIndex = TPO_LOWZ1;
			pTempZone->pidCtrl.dwrdOurOutput = TPO_LOWZ1;
			break;


		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
			break;
	}
	if(pTempZone->pidCtrl.m_nTPOoutput != NULL_OUTPUT_POINTER)
	{
		TempZone_initTPOoutput(pTempZone, NULL_TEMP_IO);
	}	
	if((aiIndex != 0xffff) && (aoIndex != 0xffff))
	{
		pTempZone->pidCtrl.pTcInput = ANALOGIN_GetAt(analogInDb, aiIndex);
		pTempZone->pidCtrl.pTPOoutput   = ANALOGOUT_GetAt(analogOutDb, aoIndex);
		if(aoIndex > MAX_ANALOG_OUTPUTS)
		{
			pTempZone->pidCtrl.m_nTPOoutput = aoIndex;
		}
		pTempZone->pidCtrl.dwrdOurOutput = aoIndex;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  RealToNominalOutput
			
 GLOBALS:
 RETURNS:   DWORD between 0 and MAX_DOUTS * 2, above max are on secondary board set to max * 2 for invalid output
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD RealToNominalOutput(DWORD real)
{
	DWORD dwrdOutput = (MAX_DIGITAL_OUTPUTS * NUMBER_POSSIBLE_CONTROL_BOARDS);
	switch(real)
	{
		case 0:
			dwrdOutput = ODO_RED_LIGHT_TOWER;
			break;
		case 1:
			dwrdOutput = ODO_AMBER_LIGHT_TOWER;
			break;
		case 2:
			dwrdOutput = ODO_GREEN_LIGHT_TOWER;
			break;
		case 3:
			dwrdOutput = ODO_AUDIBLE_ALARM;
			break;
		case 4:
			dwrdOutput = ODO_CONVEYOR_BLOWER;
			break;
		case 5:
			dwrdOutput = ODO_HEATER_CONTACT;
			break;
		case 6:
			dwrdOutput = ODO_SMEMA1_ENTRANCE;
			break;
		case 7:
			dwrdOutput = ODO_SMEMA1_EXIT;
			break;
		case 8:
			dwrdOutput = ODO_RAIL1_ENABLE;
			break;
		case 9:
			dwrdOutput = ODO_RAIL1_DIRECTION;
			break;
		case 10:
			dwrdOutput = ODO_RAIL2_ENABLE;
			break;
		case 11:
			dwrdOutput = ODO_RAIL2_DIRECTION;
			break;
		case 12:
			dwrdOutput = ODO_AUTOLUBE_SOLENOID_1;
			break;
		case 13:
			dwrdOutput = ODO_NITROGEN_ON;
			break;
		case 14:
			dwrdOutput = ODO_SMEMA2_ENTRANCE;
			break;
		case 15:
			dwrdOutput = ODO_SMEMA2_EXIT;
			break;
		case 16:
			dwrdOutput = ODO_RAIL3_ENABLE;
			break;
		case 17:
			dwrdOutput = ODO_RAIL3_DIRECTION;
			break;
		case 18:
			dwrdOutput = ODO_RAIL4_ENABLE;
			break;
		case 19:
			dwrdOutput = ODO_RAIL4_DIRECTION;
			break;
		case 20:
			dwrdOutput = ODO_CBS_UP;
			break;
		case 21:
			dwrdOutput = ODO_NITROGEN_HIGH_FLOW;
			break;
		case 22:
			dwrdOutput = ODO_NITROGEN_NORMAL_FLOW;
			break;
		case 23:
			dwrdOutput = ODO_NITROGEN_LOW_FLOW;
			break;
		case 24:
			dwrdOutput = ODO_1088_DIGITAL_FAN_FLUX_FILTER;
			break;
		case 25:
			dwrdOutput = ODO_NEW_JOB_FIVESEC;
			break;
		case 26:
			dwrdOutput = ODO_CBS_UP2;
			break;
		case 27:
			dwrdOutput = ODO_SMEMA4_ENTRANCE;
			break;
		case 28:
			dwrdOutput = ODO_AUTOLUBE_SOLENOID_2;
			break;
		case 29:
			dwrdOutput = ODO_SMEMA4_EXIT;
			break;
		case 30:
			dwrdOutput = ODO_SMEMA3_ENTRANCE;
			break;
		case 31:
			dwrdOutput = ODO_SMEMA3_EXIT;
			break;
		case 32:
			dwrdOutput = (ODO_RED_LIGHT_TOWER + MAX_DIGITAL_OUTPUTS);
			break;
		case 33:
			dwrdOutput = (ODO_AMBER_LIGHT_TOWER + MAX_DIGITAL_OUTPUTS);
			break;
		case 34:
			dwrdOutput = (ODO_GREEN_LIGHT_TOWER + MAX_DIGITAL_OUTPUTS);
			break;
		case 35:
			dwrdOutput = (ODO_AUDIBLE_ALARM + MAX_DIGITAL_OUTPUTS);
			break;
		case 36:
			dwrdOutput = (ODO_CONVEYOR_BLOWER + MAX_DIGITAL_OUTPUTS);
			break;
		case 37:
			dwrdOutput = ODO_HEATER_CONTACT + MAX_DIGITAL_OUTPUTS;
			break;
		case 38:
			dwrdOutput = ODO_SMEMA1_ENTRANCE + MAX_DIGITAL_OUTPUTS;
			break;
		case 39:
			dwrdOutput = ODO_SMEMA1_EXIT + MAX_DIGITAL_OUTPUTS;
			break;
		case 40:
			dwrdOutput = ODO_RAIL1_ENABLE + MAX_DIGITAL_OUTPUTS;
			break;
		case 41:
			dwrdOutput = ODO_RAIL1_DIRECTION + MAX_DIGITAL_OUTPUTS;
			break;
		case 42:
			dwrdOutput = ODO_RAIL2_ENABLE + MAX_DIGITAL_OUTPUTS;
			break;
		case 43:
			dwrdOutput = ODO_RAIL2_DIRECTION + MAX_DIGITAL_OUTPUTS;
			break;
		case 44:
			dwrdOutput = ODO_AUTOLUBE_SOLENOID_1 + MAX_DIGITAL_OUTPUTS;
			break;
		case 45:
			dwrdOutput = ODO_NITROGEN_ON + MAX_DIGITAL_OUTPUTS;
			break;
		case 46:
			dwrdOutput = ODO_SMEMA2_ENTRANCE + MAX_DIGITAL_OUTPUTS;
			break;
		case 47:
			dwrdOutput = ODO_SMEMA2_EXIT + MAX_DIGITAL_OUTPUTS;
			break;
		case 48:
			dwrdOutput = ODO_RAIL3_ENABLE + MAX_DIGITAL_OUTPUTS;
			break;
		case 49:
			dwrdOutput = ODO_RAIL3_DIRECTION + MAX_DIGITAL_OUTPUTS;
			break;
		case 50:
			dwrdOutput = ODO_RAIL4_ENABLE + MAX_DIGITAL_OUTPUTS;
			break;
		case 51:
			dwrdOutput = ODO_RAIL4_DIRECTION + MAX_DIGITAL_OUTPUTS;
			break;
		case 52:
			dwrdOutput = ODO_CBS_UP + MAX_DIGITAL_OUTPUTS;
			break;
		case 53:
			dwrdOutput = ODO_NITROGEN_HIGH_FLOW + MAX_DIGITAL_OUTPUTS;
			break;
		case 54:
			dwrdOutput = ODO_NITROGEN_NORMAL_FLOW + MAX_DIGITAL_OUTPUTS;
			break;
		case 55:
			dwrdOutput = ODO_NITROGEN_LOW_FLOW + MAX_DIGITAL_OUTPUTS;
			break;
		case 56:
			dwrdOutput = ODO_1088_DIGITAL_FAN_FLUX_FILTER + MAX_DIGITAL_OUTPUTS;
			break;
		case 57:
			dwrdOutput = ODO_NEW_JOB_FIVESEC + MAX_DIGITAL_OUTPUTS;
			break;
		case 58:
			dwrdOutput = ODO_CBS_UP2 + MAX_DIGITAL_OUTPUTS;
			break;
		case 59:
			dwrdOutput = ODO_SMEMA4_ENTRANCE + MAX_DIGITAL_OUTPUTS;
			break;
		case 60:
			dwrdOutput = ODO_AUTOLUBE_SOLENOID_2 + MAX_DIGITAL_OUTPUTS;
			break;
		case 61:
			dwrdOutput = ODO_SMEMA4_EXIT + MAX_DIGITAL_OUTPUTS;
			break;
		case 62:
			dwrdOutput = ODO_SMEMA3_ENTRANCE + MAX_DIGITAL_OUTPUTS;
			break;
		case 63:
			dwrdOutput = ODO_SMEMA3_EXIT + MAX_DIGITAL_OUTPUTS;
			break;
		default:
			break;
	}
	return dwrdOutput;
}



/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_checkDelayPeriod

				When a new job is loaded the delay period for rise rate is reset. During this 
				time period checking for rise rate is disabled.

	RETURNS:	void.
------------------------------------------------------------------------*/
void TempZone_checkDelayPeriod(TempZone* pTempZone)
{
	UINT currentJobNo;
	SHORT sZoneState;

	currentJobNo = Oven_getJob(ovenDb);
	sZoneState = eOFF;
	
	sZoneState = TempZone_getZoneState(pTempZone);

	if ( currentJobNo == COOLDOWN || ( currentJobNo != pTempZone->pidCtrl.previousJobNo ) || 
		(pTempZone->pidCtrl.zoneInactiveToActiveTransition == TRUE) || ( pTempZone->riseRateSetPointChange == TRUE ) ||
		(pTempZone->pidCtrl.pidEnabled != TRUE) || sZoneState != eAUTO) // job has changed
	{
		TempZone_sampleRiseRate(pTempZone);


		pTempZone->riseRateSetPointChange = FALSE;

		pTempZone->pidCtrl.zoneInactiveToActiveTransition = FALSE;	// reset the transition flag, we are now doing rise rate check
	}
	return;
}

/*--(PUBLIC FUNCTION)----------------------------------------------------
	FUNCTION:  	TempZone_checkRiseRate

				In order to detect a shorted thermocouple or a defective heater zone, a rise
				rate check is required. While the alarms are not enabled, haven't reached
				the dead band limits, the temperature should be rising at a minimum specified rate
				in degrees per second. Please note rise rate cannot be established when
				 above the set point for the temperature will be falling.

	RETURNS:	bool

------------------------------------------------------------------------*/
BOOL TempZone_checkRiseRate( TempZone* pTempZone )
{
#ifdef BAD_FRANK
	return TRUE;
#else
	BOOL status;
	BOOL bRiseRateEnabled;
	UINT minimumRiseDegrees;
	UINT heaterRiseRatePeriod10ths;
	DWORD dwTempZone;

	BOOL bSample;
	DWORD tim;
	DWORD timDiff;
	LONG lTempCheck;
				
	lTempCheck = 0;
	timDiff = 0;
	tim = 0;
	bSample = TRUE;

	status = TRUE;
	bRiseRateEnabled = FALSE;
	minimumRiseDegrees = 0;
	heaterRiseRatePeriod10ths = 0;
	dwTempZone = 0;

	dwTempZone = PIDController_getAbsoluteTempZoneNumber( &(pTempZone->pidCtrl) );
	tim = Timer_getCurrentTime10ths(timerDb);

	bRiseRateEnabled = TempZones_riseRateWarning(tempZonesDb);
	minimumRiseDegrees = tempZonesDb->minimumRiseDegrees;
	heaterRiseRatePeriod10ths = tempZonesDb->heaterRiseRatePeriod10ths;

	// if we are in alarm band regions, we are close to being in control and
	// the rise rate will no longer be as great and may cause an alarm.
	
	if  ( pTempZone->pidCtrl.alarmBandsEnabled == FALSE && (pTempZone->pidCtrl.groupNo != TH_STARTUPGROUP) )
	{
		if ( ( pTempZone->pidCtrl.pv < pTempZone->pidCtrl.sp - RISE_RATE_MARGIN) && !pTempZone->pidCtrl.inDeadBand ) // the temperature must be rising.
		{
			bSample = FALSE;  //sample when we are testing or the test time has expired
			timDiff = differenceWithRollover(tim, pTempZone->lastCheckTime); 
			if ( timDiff > heaterRiseRatePeriod10ths )
			{
				lTempCheck =  pTempZone->lastCheckTemp + minimumRiseDegrees;
				if (  pTempZone->pidCtrl.pv < lTempCheck )
				{
					// temperature rate of change not high enough Alarm.
					if( bRiseRateEnabled == TRUE )
					{
						AlarmQueue_addAlarm(alarmQueueDb, WARNING, TZ_RISERATE_WARN, dwTempZone);
					}
					else
					{
						AlarmQueue_addAlarm(alarmQueueDb, ALARM, TZ_RISERATE_ALARM, dwTempZone);
					}
					status = FALSE;
				}
				bSample = TRUE;
				
				TempZone_sampleRiseRate(pTempZone);
			}
		}
		if(bSample)
		{
			TempZone_sampleRiseRate(pTempZone);
		}
	}
	return status;
#endif
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  TempZone_sampleRiseRate
			
			to determine a rise rate error a sample must be taken
			and compared to a reading x tenth of seconds in the future
			this function will set the sample time and sample value,
			they must be set concurrently

 RETURNS:   void

------------------------------------------------------------------------*/
void TempZone_sampleRiseRate( TempZone* pTempZone )
{
	DWORD tim;
	tim = 0;

	tim = Timer_getCurrentTime10ths(timerDb);
	if(pTempZone != NULL)
	{
		pTempZone->lastCheckTemp = pTempZone->pidCtrl.pv;
		pTempZone->lastCheckTime = tim;
	}
	return;
}
