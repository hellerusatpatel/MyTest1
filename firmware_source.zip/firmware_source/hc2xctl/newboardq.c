//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: newboardq.c
//
// Description: intel style lane tracking
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 08-Jan-15  FJN  Set and clear bBoardEntering as appropriate
// 26-Oct-16  FJN  Modify newBoardQueue_checkForBoardDrop to increment notifyBoardOut
// 14-Nov-17  FJN, TP  Implement Oven_checkRecipeLoadBoardEntryWait
//*****************************************************************************
#include "contain.h"
#include "newboardq.h"
#include "boards.h"
#include "belt.h"
#include "timer.h"
#include "oven.h"
#include "purge.h"
#include <linux/poll.h>

extern DbContainer g_dbContainer;
static UINT boardQIdIndex = 0;
extern BOOL bBoardEntering[];
extern DWORD dwBoardEnteringTime[];

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_init

            Initialization routine.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_init(newBoardQueue* pNBQ, const char* szName)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_init");

	if ( szName )
	{
		strcpy(pNBQ->name, szName);
	}

	pNBQ->pBeltIOTied  = NULL;
	pNBQ->pBoardEnteringOven = NULL;
	pNBQ->pBoardLeavingOven = NULL;
	pNBQ->headIndex = 0;
	pNBQ->tailIndex = 0;
	pNBQ->boardQueueActive = FALSE;
	pNBQ->lastBoardDetectPosition = 0;
	pNBQ->lastBoardDetectTime = 0;
	pNBQ->m_boardCount = 0;
	pNBQ->boardsProcessed = 0;

	pNBQ->previousBoardDetectState = FALSE;
	pNBQ->m_startBoardInDetectTime = 0;
	pNBQ->expectLowInputAfterCounts = 0;
	pNBQ->previousBoardOutDetectState = FALSE;
	pNBQ->startBoardOutDetectTime = 0;
	pNBQ->boardEntranceJamState = FALSE;
	pNBQ->boardBackUpTime = 0;
	pNBQ->filterCount = 0;
	pNBQ->lowHasOccurred = TRUE;
	pNBQ->m_bBoardOnEntrySensor = FALSE;
	pNBQ->m_bEnableBoardStop = FALSE;
	pNBQ->exitBoardDeadbandCounts = 0;
	pNBQ->boardDropTol = 0;

	pNBQ->boardQId = boardQIdIndex++;
	pNBQ->notifyBoard = 0;
	pNBQ->notifyBoardOut = 0;

	pNBQ->m_uintTimeBackupBegan = 0;
	pNBQ->m_uintTimeEntranceJamBegan = 0;
	pNBQ->boardDropTolNeg = 0;
	pNBQ->uintBoardDropTime = 0;
	pNBQ->m_bSprayEnabled = 0;
	pNBQ->m_dwSprayDist = 0;
	pNBQ->dwSprayLength = 0;
	pNBQ->selfAckCode = 0;
	pNBQ->m_FCExit = 0;
	pNBQ->m_bBoardExitFull = TRUE;
	pNBQ->m_dwrdLastBeltPosWNoBoards = 0;
	pNBQ->selfAckAdd = 0;
	pNBQ->m_bPendSmema = FALSE;
	pNBQ->m_bStartSmema = FALSE;
	pNBQ->smema9851startBoardInDetectDist = 0;

	pNBQ->m_boardHeadReadEntry = FALSE;
	pNBQ->m_boardStartPosEntry = 0;

	pNBQ->m_boardHeadReadExit = FALSE;
	pNBQ->m_boardStartPosExit = 0;

	pNBQ->m_b9851Enter = FALSE;
	pNBQ->m_9851distanceTraveled = 0;

	pNBQ->m_bIgnoreBoardLength = FALSE;
	pNBQ->m_bEnablePredefinedBoardLength = FALSE;
	pNBQ->m_PredefinedBoardLength = 0;
	pNBQ->m_bEntranceJamWarning = FALSE;
	pNBQ->m_bEnteranceJamStampTaken = FALSE;
	pNBQ->m_enteranceJamBeginDist = 0;
	pNBQ->m_bExitJamStampTaken = FALSE;
	pNBQ->m_exitJamBeginDist = 0;
	pNBQ->boardExitJamState = FALSE;
	pNBQ->m_uintTimeExitJamBegan = 0;

	LocalTime_resetTime( &(pNBQ->m_currentTime) );
	LocalTime_resetTime( &(pNBQ->m_localTimeEntryLeadingEdge) );
	LocalTime_resetTime( &(pNBQ->m_localTimeEntryTrailingEdge) );
	LocalTime_resetTime( &(pNBQ->m_localTimeExitLeadingEdge) );
	LocalTime_resetTime( &(pNBQ->m_localTimeExitTrailingEdge) );

	pNBQ->m_bLengthAssigned = TRUE;
	pNBQ->uiCurrentJob = 0;
	pNBQ->existingBoardDropID = 0;
	pNBQ->inputHighCount = 0;

	pNBQ->m_lastJob = 0;
	pNBQ->m_bBoardBackUpState = FALSE;
	pNBQ->m_bleadingEdgeLow = FALSE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_addBoard

            Add a board to the internal queue.

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL newBoardQueue_addBoard(newBoardQueue* pNBQ)
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_addBoard", 0);

	if ( pNBQ->m_boardCount > MaxBoards )
	{
		status = FALSE;     // too many boards in oven
#ifdef DEBUG_SMEMA_HOLD
		printk("newBoardQueue_addBoard lane%d too many boards in oven\n", pNBQ->boardQId + 1);
#endif
	}
	else
	{
		pNBQ->tailIndex = (pNBQ->headIndex + pNBQ->m_boardCount) % MaxBoards;
		pNBQ->m_boardCount++;
		pNBQ->m_bLengthAssigned = FALSE;
	}

	bBoardEntering[pNBQ->boardQId] = TRUE;
	dwBoardEnteringTime[pNBQ->boardQId] = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
#ifdef DEBUG_SMEMA_HOLD
	printk("newBoardQueue_addBoard lane%d m_boardCount=%d\n", pNBQ->boardQId + 1, pNBQ->m_boardCount);
#endif
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_removeBoardFromCircularBuffer

            helper function for newBoardQueue_removeBoard does the 
			actual increment of head, changes count, and tail index if
			neccessary

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_removeBoardFromCircularBuffer(newBoardQueue* pNBQ)
{
	Board_init( &(pNBQ->boards[pNBQ->headIndex]) ); //clear head variables
	(pNBQ->headIndex)++;
	(pNBQ->m_boardCount)--;

	if ( pNBQ->headIndex >= MaxBoards )
	{
		pNBQ->headIndex = 0;
	}
	if ( pNBQ->m_boardCount == 0 )
	{
		pNBQ->tailIndex = pNBQ->headIndex;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_removeBoard

            Remove the head board from the internal queue.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_removeBoard(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_removeBoard");
	Board* pBoard = NULL;
	CarrierBoard* pCarrier = NULL;
	DWORD localIndex = 0;
	if ( pNBQ->m_boardCount )
	{
		//check for drop in board after head index, special case for blocked exit sensor
		if(pNBQ->m_boardCount > 1)
		{
			localIndex = newBoardQueue_getNextIndex(pNBQ);
			pBoard = &(pNBQ->boards[localIndex]);
			if(pBoard->bBoardDropped)
			{
				if ( pBoard->timeStamps.bValidExitLeading &&//should be redundant, set when dropped
					pBoard->timeStamps.bValidExitTrailing )
				{
		
					pCarrier = LotProcessing_getCarrierByBoard(&(g_dbContainer.m_lotProcessing),&(pNBQ->boards[pNBQ->headIndex]));					
					Board_Copy(pBoard,&(pNBQ->boards[pNBQ->headIndex]));//copy board from head to next pos
					newBoardQueue_removeBoardFromCircularBuffer(pNBQ);
					pCarrier->m_pBoard = pBoard;
				}
			}
		}
		pBoard = &(pNBQ->boards[pNBQ->headIndex]);
		if ( pBoard && 
			pBoard->bInUse )
		{
			// Only remove boards whose exit-side leading and trailing edge timestamps are set.
			if ( pBoard->timeStamps.bValidExitLeading &&
				pBoard->timeStamps.bValidExitTrailing )
			{

				// reset all the data in the structure
				newBoardQueue_removeBoardFromCircularBuffer(pNBQ);
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_updateBoardPositions


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_updateBoardPositions(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_updateBoardPositions");
	DWORD index = pNBQ->headIndex;
	DWORD currentBeltPositionCounts = pNBQ->currentBeltPosition;
	DWORD lcv;

	for ( lcv = 0; lcv < pNBQ->m_boardCount; lcv++, index++ )
	{
		if ( index >= MaxBoards )
		{
			index = 0;  // wrap around
		}

		pNBQ->boards[index].elapsedPositionCounts = currentBeltPositionCounts - pNBQ->boards[index].startPositionCounts;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardsInOvenCount


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD newBoardQueue_getBoardsInOvenCount(newBoardQueue* pNBQ, UINT ui_Type)
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getBoardsInOvenCount", 0);
	DWORD dReturn = 0;

	if ( pNBQ->boardsInOvenEnabled == TRUE )
	{
		if (pNBQ->m_boardCount != 0)
		{
			dReturn = pNBQ->m_boardCount;
		}
		else
		{
			dReturn = !pNBQ->m_bBoardExitFull;
		}
	}

	return dReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardsProcessed


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD newBoardQueue_getBoardsProcessed(newBoardQueue* pNBQ)
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getBoardsProcessed", 0);
	DWORD dwReturn = 0;

	if ( pNBQ->boardsProcessedEnabled == TRUE )
	{
		dwReturn = pNBQ->boardsProcessed;
	}

	return dwReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardAnimationData


 GLOBALS:
 RETURNS:   BoardData*
 SEE ALSO:
------------------------------------------------------------------------*/
const BoardData* newBoardQueue_getBoardAnimationData( newBoardQueue* pNBQ )
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getBoardAnimationData", 0);
	pNBQ->boardData.pBoardArray = pNBQ->boards;
	pNBQ->boardData.headIndex   = pNBQ->headIndex;
	pNBQ->boardData.tailIndex   = pNBQ->tailIndex;
	pNBQ->boardData.maxBoards   = MaxBoards;
	pNBQ->boardData.boardCount  = newBoardQueue_getBoardsInOvenCount(pNBQ, 0);

	return &(pNBQ->boardData);
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setSensorDistance


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setSensorDistance(newBoardQueue* pNBQ,  DWORD distanceBetweenSensorsInCounts )
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setSensorDistance");
	pNBQ->distanceBetweenSensorsCounts = distanceBetweenSensorsInCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardDeadBandDistance


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDeadBandDistance(newBoardQueue* pNBQ, DWORD boardDeadBandInCounts )
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setBoardDeadBandDistance");
	pNBQ->boardDeadbandCounts =  boardDeadBandInCounts;
}

//*****************************************************************************
// void BoardQueue::configure( DWORD configurationOption )
//
// Abstract:
// Board tracking is done by detection of a board at the board entering sensor
// and removed at the board leaving sensor. Board distances are tracked by belt.
// If there is no belts then tracking is disabled. If there is only one belt
// then all the board tracking is done off this belt. If there are two belts then
// the first board entering and leaving inputs are tracked via belt 1 and the
// second set is tracked by belt 2. If a boardQueueActive flag is set to false
// then no board tracking is available through that object. This function needs
// to be set by the ovenDb object whenever the configuration changes.
//
// Programmer: Steven Young
// Date: 6/24/98
//
//*****************************************************************************
BOOL newBoardQueue_configure(newBoardQueue* pNBQ, DWORD boardDropConfig, DWORD boardsProcessedConfig, DWORD boardsInOvenConfig )
{
	BOOL status = FALSE;
	UINT activeBelts;
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_configure", 0);

	pNBQ->boardQueueActive = FALSE;
	if ( boardDropConfig < 16 )             // no of options with none, timed, beam and both for two lanes.
	{
		if ( boardsProcessedConfig < 4 )    // boards processed on or off for two lanes
		{
			if ( boardsInOvenConfig < 4 )   // boards in oven on or off for two lanes.
			{
				status = TRUE;

				activeBelts = Belts_getNoOfActiveBelts( &(g_dbContainer.beltsDb) );

				if ( activeBelts > 0 && activeBelts <= MaxBelts )
				{
					if (  ! ( newBoardQueue_ioConfig(pNBQ, activeBelts ) &&
					          newBoardQueue_bdConfig(pNBQ, boardDropConfig ) &&
					          newBoardQueue_bpConfig(pNBQ, boardsProcessedConfig ) &&
					          newBoardQueue_boConfig(pNBQ, boardsInOvenConfig ) )
					   )
					{
						pNBQ->boardQueueActive = FALSE;

						status = FALSE;
					}
				}
			}
			else
			{
				pNBQ->boardQueueActive = FALSE;
				status = FALSE;
			}
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_ioConfig

			There is the possibility of two board tracking sensor pairs - 
			entering and exiting IO points.  Due to this there only needs 
			to be two board queues for tracking of boards. By knowing the
			ID's of the queue it is possible to establish pointers to the 
			electrical inputs. Additionally position needs to be tracked 
			by belt. If there are two belts the second of the BoardQueue 
			is tracking from the second belt. If there is only one belt 
			there is no choice but to track from belt one

 RETURNS:   BOOL - See description
------------------------------------------------------------------------*/
BOOL newBoardQueue_ioConfig(newBoardQueue* pNBQ, UINT activeBelts )
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_ioConfig", 0);

	if ( activeBelts == 0 )
	{
		status = FALSE;
	}
	else
	{
		switch ( pNBQ->boardQId )
		{
		case 0:
			pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
			pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA1_BOARD_ENTERING_OVEN);
			pNBQ->pBoardLeavingOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA1_BOARD_LEAVING_OVEN);
			break;

		case 1:
			pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA2_BOARD_ENTERING_OVEN);
			pNBQ->pBoardLeavingOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA2_BOARD_LEAVING_OVEN);
			switch ( activeBelts )
			{
			case 1:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
				break;

			case 2:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[1]);
				break;

			default:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
				status = FALSE;
				break;
			}
			break;

		case 2:
			pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
			pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA3_BOARD_ENTERING_OVEN);
			pNBQ->pBoardLeavingOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA3_BOARD_LEAVING_OVEN);
			break;

		case 3:
			pNBQ->pBoardEnteringOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA4_BOARD_ENTERING_OVEN);
			pNBQ->pBoardLeavingOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA4_BOARD_LEAVING_OVEN);
			switch ( activeBelts )		
			{
				case 1:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
					break;
							
				case 2:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[1]);
					break;
							
				default:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
					status = FALSE;
					break;
			}
			break;

		default:
			pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
			status = FALSE;
			break;
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_bdConfig

			per Tushar only the in oven and processed should
			enable lane tracking

			If the board Config option is set for the timed method then 
			there is an entry and exit sensor for detecting boards. In 
			the event this option is false it may already have been set 
			in another function.  If that is the case then the state 
			needs to be OR'd with the current state. If it's TRUE then
			set it TRUE and don't worry about the previous state.

 RETURNS:   BOOL  - see description
------------------------------------------------------------------------*/
BOOL  newBoardQueue_bdConfig(newBoardQueue* pNBQ, DWORD boardDropConfig )
{
	BOOL status;
	status = TRUE;
	
	if(pNBQ)
	{

		if ( (pNBQ->boardQId == 0) || (pNBQ->boardQId == 2) )
		{
			switch ( boardDropConfig )
			{
				case L1_NONE_L2_NONE:  //fall through // the following options do not track by belt.
				case L1_NONE_L2_TIMED:
				case L1_NONE_L2_BEAM:
				case L1_NONE_L2_BOTH:
				case L1_BEAM_L2_NONE:
				case L1_BEAM_L2_TIMED:
				case L1_BEAM_L2_BEAM:
				case L1_BEAM_L2_BOTH:
					pNBQ->timedBoarddropEnabled = FALSE;
					break;

				case L1_TIMED_L2_NONE: //fall through
				case L1_TIMED_L2_TIMED:
				case L1_TIMED_L2_BEAM:
				case L1_TIMED_L2_BOTH:
				case L1_BOTH_L2_NONE:
				case L1_BOTH_L2_TIMED:
				case L1_BOTH_L2_BEAM:
				case 15:
					pNBQ->timedBoarddropEnabled = TRUE;
					break;

				default:
					pNBQ->timedBoarddropEnabled =   FALSE;
					status = FALSE;
					break;
			}
		}
		else
		{
			if ( (pNBQ->boardQId == 1) || (pNBQ->boardQId == 3) )
			{
				switch ( boardDropConfig )
				{
					case L1_NONE_L2_NONE: //fall through
					case L1_NONE_L2_BEAM:
					case L1_TIMED_L2_NONE:
					case L1_TIMED_L2_BEAM:
					case L1_BEAM_L2_NONE:
					case L1_BEAM_L2_BEAM:
					case L1_BOTH_L2_NONE:
					case L1_BOTH_L2_BEAM:
						pNBQ->timedBoarddropEnabled = FALSE;
						break;
	
					case L1_NONE_L2_TIMED: //fall through
					case L1_NONE_L2_BOTH:
					case L1_TIMED_L2_TIMED:
					case L1_TIMED_L2_BOTH:
					case L1_BEAM_L2_TIMED:
					case L1_BEAM_L2_BOTH:
					case L1_BOTH_L2_TIMED:
					case L1_BOTH_L2_BOTH:
						pNBQ->timedBoarddropEnabled =   TRUE;
						break;
	
					default:
						pNBQ->timedBoarddropEnabled = FALSE;
						status = FALSE;
						break;
				}
			}
		}
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_bpConfig

			If the boards processed option is configured then there is 
			an entry and exit sensor for detecting boards. In the event 
			this option is false it may already have been set in another 
			function. If that is the case then the state needs to be 
			OR'd with the current state. If it's TRUE then set it TRUE 
			and don't worry about the previous state.

 RETURNS:   BOOL - see description
------------------------------------------------------------------------*/
BOOL newBoardQueue_bpConfig(newBoardQueue* pNBQ, DWORD boardsProcessedConfig )
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_bpConfig", 0);

	switch ( pNBQ->boardQId )
	{
	case 0: // lane 3 has the same settings as lane 1. Only use though if the check box is set. (FALL THROUGH)
	case 2:
		switch ( boardsProcessedConfig )
		{
		case 0:
			pNBQ->boardsProcessedEnabled = FALSE;
			break;

		case 1:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsProcessedEnabled = TRUE;
			break;

		case 2:
			pNBQ->boardsProcessedEnabled = FALSE;
			break;

		case 3:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsProcessedEnabled = TRUE;
			break;

		default:
			pNBQ->boardQueueActive = FALSE;
			pNBQ->boardsProcessedEnabled = FALSE;
			status = FALSE;
			break;
		}
		break;

	case 1: //FALL THROUGH
	case 3:
		switch ( boardsProcessedConfig )
		{
		case 0:
			pNBQ->boardsProcessedEnabled = FALSE;
			break;

		case 1:
			pNBQ->boardsProcessedEnabled = FALSE;
			break;

		case 2:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsProcessedEnabled = TRUE;
			break;

		case 3:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsProcessedEnabled = TRUE;
			break;

		default:
			pNBQ->boardQueueActive = FALSE;
			pNBQ->boardsProcessedEnabled = FALSE;
			status = FALSE;
			break;
		}
		break;

	default:
		pNBQ->boardQueueActive = FALSE;
		status = FALSE;
		break;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_boConfig

			If the boards in oven option is configured then there is an 
			entry and exit sensor for detecting boards. In the event 
			this option is false it may already have been set in another 
			function. If that is the case then the state needs to be 
			OR'd with the current state. If it's TRUE then set it TRUE 
			and don't worry about the previous state.

 RETURNS:   BOOL - see description
------------------------------------------------------------------------*/
BOOL newBoardQueue_boConfig(newBoardQueue* pNBQ, DWORD boardsInOvenConfig )
{
	BOOL status = TRUE;
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_boConfig", 0);

	switch ( pNBQ->boardQId )
	{
	case 0: //FALL THROUGH
	case 2:
		switch ( boardsInOvenConfig )
		{
		case 0:
			pNBQ->boardsInOvenEnabled = FALSE;
			break;

		case 1:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsInOvenEnabled = TRUE;
			break;

		case 2:
			pNBQ->boardsInOvenEnabled = FALSE;
			break;

		case 3:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsInOvenEnabled = TRUE;
			break;

		default:
			pNBQ->boardQueueActive = FALSE;
			pNBQ->boardsInOvenEnabled = FALSE;
			status = FALSE;
			break;
		}
		break;

	case 1:
	case 3:
		switch ( boardsInOvenConfig )
		{
		case 0:
			pNBQ->boardsInOvenEnabled = FALSE;
			break;

		case 1:
			pNBQ->boardsInOvenEnabled = FALSE;
			break;

		case 2:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsInOvenEnabled = TRUE;
			break;

		case 3:
			pNBQ->boardQueueActive = TRUE;
			pNBQ->boardsInOvenEnabled = TRUE;
			break;

		default:
			pNBQ->boardQueueActive = FALSE;
			pNBQ->boardsInOvenEnabled = FALSE;
			status = FALSE;
			break;
		}
		break;

	default :
		pNBQ->boardQueueActive = FALSE;
		status = FALSE;
		break;
	}

	return status;
}
//**************************************************************************************************
//void BoardQueue::process()
//
// Abstract:
// The following boardQueue processes need to be executed to detect board drops and board position.
//
// Programmer: Steven Young
// Date: 06/25/1998
//**************************************************************************************************
void newBoardQueue_process(newBoardQueue* pNBQ)
{
	// There was a third land configuration that was added in 08/10/2000. Per Heller the third lane
	// configuration was to be identical to that of lane 1. A problem occurred where the configuration
	// would not be set correctly until the program was run a second time. This was due to the oven
	// class knowing the state of the third lane prior to the configuration being set. Since the order
	// of execution is important and changing the way the database updates components it was decidely
	// easier to update a flag that would be cleared during execution.
	//
	// SDY 08-18-2000
	Belt* pBeltIOTiedLocal = NULL;
	PARAM_CHECK( pNBQ, "newBoardQueue_process");

	const UINT job = Oven_getJob(&(g_dbContainer.ovenDb));

	pBeltIOTiedLocal = pNBQ->pBeltIOTied;

	newBoardQueue_updateCurrentTime( pNBQ );

	if ( pNBQ->boardQueueActive == TRUE )
	{
		pNBQ->currentBeltPosition = Belt_getPosition(pNBQ->pBeltIOTied);

		if ( job == COOLDOWN )
		{
			newBoardQueue_markBoardsWithCooldown(pNBQ);
		}

		if ( pNBQ->lowHasOccurred == FALSE )
		{
			newBoardQueue_hasLowOccurred(pNBQ);
		}
		newBoardQueue_checkForLeadingEdgeLow(pNBQ);

		newBoardQueue_removeBoard(pNBQ);
		newBoardQueue_checkForBoardEntering(pNBQ);
		newBoardQueue_updateBoardPositions(pNBQ);
		newBoardQueue_checkForEntranceBoardJam(pNBQ);
		newBoardQueue_checkForBoardBackup(pNBQ);
		newBoardQueue_checkForBoardDrop(pNBQ);
		newBoardQueue_checkForBoardLeaving(pNBQ);
		newBoardQueue_checkForBoardFCExit(pNBQ);

		Purge_setSprayOn(&(g_dbContainer.purge), newBoardQueue_checkForSpray(pNBQ), pNBQ->boardQId);

		if (*(pNBQ->pBoardEnteringOven) == FALSE)
		{
			pNBQ->m_bBoardOnEntrySensor = FALSE;

			if (pNBQ->selfAckAdd != 0)
			{
				AlarmQueue_alarmQueueAcknowledge(&(g_dbContainer.alarmQueueDb), pNBQ->selfAckAdd);
				pNBQ->selfAckAdd = 0;
			}
		}

		// if the following two options are not turned on then return 0.
		if ( pNBQ->boardsInOvenEnabled == FALSE )
		{
			pNBQ->m_boardCount = 0;
		}

		if ( pNBQ->boardsProcessedEnabled == FALSE )
		{
			pNBQ->boardsProcessed = 0;
		}

		// Save the state of the last job.
		pNBQ->m_lastJob = job;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForLeadingEdgeLow
 checks for a low when a board head should be about to hit the exit sensor


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_checkForLeadingEdgeLow(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_checkForLeadingEdgeLow");
	DWORD dwrdDist = 0;
	DWORD deltaPos = 0;
	if(pNBQ->m_boardCount>0)//this tests for a low when the leading edge is in range
	{
		if ( *(pNBQ->pBoardLeavingOven) == FALSE )
		{
			dwrdDist = pNBQ->boards[pNBQ->headIndex].startPositionCounts;
			deltaPos = differenceWithRollover(pNBQ->currentBeltPosition, dwrdDist) + pNBQ->boardDropTolNeg + 1;//adding 1 to the total so it is slightly larger than the input on test
			if ( deltaPos >= pNBQ->distanceBetweenSensorsCounts )
			{
				pNBQ->m_bleadingEdgeLow = TRUE;
			}
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_hasLowOccurred


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_hasLowOccurred(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_hasLowOccurred");
	if ( Belt_getPosition(pNBQ->pBeltIOTied) >= pNBQ->expectLowInputAfterCounts )
	{
		if ( *(pNBQ->pBoardLeavingOven) == FALSE )
		{
			pNBQ->inputHighCount = 0;
			pNBQ->lowHasOccurred = TRUE;

		}
		else  //reset the distance count per Tushar (on two blocks)
		{
			pNBQ->inputHighCount++;

			if (pNBQ->inputHighCount >= 2) //require two blocks to elimate mesh belt reflections
			{
				pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + pNBQ->exitBoardDeadbandCounts;
			}
		}
	}
	else
	{
		if ( *(pNBQ->pBoardLeavingOven) == FALSE )
		{
			pNBQ->inputHighCount = 0;

		}
		else  //reset the distance count per Tushar (on two blocks)
		{
			pNBQ->inputHighCount++;

			if (pNBQ->inputHighCount >= 2) //require two blocks to elimate mesh belt reflections
			{
				pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + pNBQ->exitBoardDeadbandCounts;
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForEntranceBoardJam


 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_checkForEntranceBoardJam(newBoardQueue* pNBQ)
{
	if ( pNBQ)
	{
		if ( pNBQ->m_bEntranceJamWarning &&
		     pNBQ->m_bEnablePredefinedBoardLength )
		{
			BOOL bBoardInputSensor = *(pNBQ->pBoardEnteringOven);

			if ( bBoardInputSensor )
			{
				if (pNBQ->m_bEnteranceJamStampTaken == FALSE)
				{
					pNBQ->m_bEnteranceJamStampTaken = TRUE;
					pNBQ->m_enteranceJamBeginDist = pNBQ->currentBeltPosition;
				}

				DWORD distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->m_enteranceJamBeginDist);

				if ( distanceTraveled >= pNBQ->m_PredefinedBoardLength )
				{
					if ( pNBQ->boardEntranceJamState == FALSE ) //first time through, take beginning timestamp
					{
						pNBQ->m_uintTimeEntranceJamBegan =
							Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
					}

					pNBQ->boardEntranceJamState = TRUE;

					if ( differenceWithRollover(Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)), pNBQ->m_uintTimeEntranceJamBegan) > pNBQ->uintBoardDropTime)
					{
						DWORD messNo = 0;

						switch (pNBQ->boardQId)
						{
							case 0:
								messNo = BOARD_ENTRANCE_JAM1;
								break;

							case 1:
								messNo = BOARD_ENTRANCE_JAM2;
								break;

							case 2:
								messNo = BOARD_ENTRANCE_JAM3;
								break;

							case 3:
								messNo = BOARD_ENTRANCE_JAM4;
								break;

							default:
								break;
						}

						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb),
											WARNING, messNo, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
			}
			else
			{
				pNBQ->m_bEnteranceJamStampTaken = FALSE;
				pNBQ->boardEntranceJamState = FALSE;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardBackup

			In order to differentiate between board drops and board 
			backups then a low is expected from the board sensor 
			within the period between the end of the board in counts 
			and the end of the board plus board deadband counts. If 
			a low does not occur it is assumed that a board backup has 
			occurred, although a number of other events can cause 
			this as well.

			Code works with the first board sensor only with lto option
			modifying the code so the smema tested is keyed to the 
			boardQId i.e.

			id 0=IDI_SMEMA1_BOARD_LEAVING_OVEN
			id 1=IDI_SMEMA2_BOARD_LEAVING_OVEN
			id 2=IDI_SMEMA3_BOARD_LEAVING_OVEN
			id 3=IDI_SMEMA4_BOARD_LEAVING_OVEN

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardBackup(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_checkForBoardBackup");

	// Per Heller Fax 05/01/00 from D. Smith. Attach board stop function to board drop enable-disable function
	// in setup wizard. Used for only timed method, the through beam option does not have the correct configuration
	// options.
	// SDY - 08/23/00
	if ( pNBQ->m_bEnableBoardStop == TRUE )
	{
		if (pNBQ->m_bEnablePredefinedBoardLength )
		{
			if ( *(pNBQ->pBoardLeavingOven) )
			{
				if (pNBQ->m_bExitJamStampTaken == FALSE)
				{
					pNBQ->m_bExitJamStampTaken = TRUE;
					pNBQ->m_exitJamBeginDist = pNBQ->currentBeltPosition;
				}

				DWORD distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->m_exitJamBeginDist);

				if ( distanceTraveled >= pNBQ->m_PredefinedBoardLength )
				{
					if ( pNBQ->boardExitJamState == FALSE ) //first time through, take beginning timestamp
					{
						pNBQ->m_uintTimeExitJamBegan =
							Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
					}

					pNBQ->boardExitJamState = TRUE;

					if ( differenceWithRollover(Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)), pNBQ->m_uintTimeExitJamBegan) > pNBQ->uintBoardDropTime )
					{
						DWORD messNo = 0;

						switch (pNBQ->boardQId)
						{
							case 0:
								messNo = BOARD_BACKUP_WARNING;
								break;

							case 1:
								messNo = BOARD_BACKUP_WARNING_2;
								break;

							case 2:
								messNo = BOARD_BACKUP_WARNING_3;
								break;

							case 3:
								messNo = BOARD_BACKUP_WARNING_4;
								break;

							default:
								break;
						}
						pNBQ->m_bBoardBackUpState = TRUE;
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb),
											WARNING, messNo, Belt_getBeltId(pNBQ->pBeltIOTied));


					}
				}
			}
			else
			{
				pNBQ->m_bExitJamStampTaken = FALSE;
				pNBQ->boardExitJamState = FALSE;
			    pNBQ->m_bBoardBackUpState = FALSE;
			}
		}	
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardDrop

			A board drop is detected whenever the lead board has traveled 
			a distance of the distance between sensors + deadband. If 
			this position is achieved then the board has dropped,
			and the board needs to be removed from the Queue.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardDrop(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_checkForBoardDrop");
	DWORD distanceTraveled = 0;
	UINT localIndex = pNBQ->headIndex;
	DWORD deltaBoardDistance = 0;
	BOOL bSkipDropTest = FALSE;//if there is one board and we are stopped skip test, if there are no boards skip test
	DWORD wiggle = 5;
	BOOL bCheckingSecond = FALSE;
	//the following code is to address the following situation
	//sensor is blocked on a board, it remains blocked while boards behind it should have dropped
	//the leading board will generate trailing edge exit events when the sensor is cleared, all other boards should drop
	// however if the head was not read (sensor was blocked by grime? ie sensor blocked early) the first board should drop as well
	//test the exit sensor so the first board will not drop while it is blocking the sensor.  this is ored with the backup state
	//otherwise it will drop once the sensor becomes false, which is incorrect, it should exit normally
	if((pNBQ->m_boardHeadReadExit==TRUE) && (pNBQ->m_boardCount > 0) &&
		((*(pNBQ->pBoardLeavingOven) == TRUE) || (pNBQ->m_bBoardBackUpState==TRUE))) //set the test board to the next board, first board is stopped(potentially)
	{
		if(pNBQ->m_boardCount > 1)
		{
			localIndex = newBoardQueue_getNextIndex(pNBQ);
			bCheckingSecond = TRUE;
		}
		else //can't drop we are stopped
		{
			bSkipDropTest = TRUE;
		}
	}
	if ( pNBQ->m_boardCount == 0 )//skip test if there are no boards in the oven
	{
		bSkipDropTest = TRUE;
	}
	if ( bSkipDropTest == FALSE) 
	{
		// the board can only move a distance of the sensors in counts of the encoders. If the board has
		// traveled the distance between the sensors plus the deadband then a board drop is detected.
		// Also, only test for board drop if we have not already registered the leading edge.
		if ( pNBQ->timedBoarddropEnabled == TRUE )
		{
			distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition , pNBQ->boards[localIndex].startPositionCounts);
			// distance traveled needs to be less set to 0 in the event it is negative. The reason is
			// when doing a comparison a negative value is very large so set it to 0 when it is negative.
			// Othersise the distanceBetweenSensorsCounts could be converted to a long but if the encoder
			// counts or oven length increases or some combination of the two we don't want overflow,
			// although that may be impossible with 2billion+ counts.

			if ( (long)(distanceTraveled - pNBQ->exitBoardDeadbandCounts) < 0 )
			{
				distanceTraveled = 0;
			}

			deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boards[localIndex].boardLengthCounts + pNBQ->boardDropTol);

			if ( pNBQ->m_bIgnoreBoardLength )
			{
				deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boardDropTol + wiggle);
			}
			//first statement in distance to test second statement not leading board or the head was not read
			if ( (distanceTraveled > deltaBoardDistance) && 
				((pNBQ->m_boardHeadReadExit == FALSE) || (bCheckingSecond == TRUE)))
			{
				// For a dropped board, set both of the exit timestamps to the current time stamp.
				pNBQ->boards[localIndex].bBoardDropped = TRUE;
				Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), TRUE, &(pNBQ->m_currentTime) );
				Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), FALSE, &(pNBQ->m_currentTime) );
				pNBQ->m_bleadingEdgeLow = FALSE;
				pNBQ->notifyBoardOut++; // fjn -- keep notifyBoard and notifyBoardOut in sync

				if (pNBQ->boardQId == 0)
				{
					if (pNBQ->existingBoardDropID == 0)
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
					else
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
				else if (pNBQ->boardQId == 1)
				{
					if (pNBQ->existingBoardDropID == 0)
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
					else
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
				else if (pNBQ->boardQId == 2)
				{
					if (pNBQ->existingBoardDropID == 0)
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
					else
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
				else if (pNBQ->boardQId == 3)
				{
					if (pNBQ->existingBoardDropID == 0)
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
					else
					{
						pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
			}
		}
	}

	return;
}

//**************************************************************************************************
// void BoardQueue::checkForBoardLeaving()
//
// Abstract:
//  A board will only be detected as leaving when its' position is
//  ( currentPosition - startPositionCounts + deadBandcounts ) > distanceBetweenSensors
//  If this condition is not met it is the previous board and it would not be correct to
//  repeatedly remove boards. Thus the deadband.
//
// Programmer: Steven Young
// Date: 06/25/1998
//**************************************************************************************************
void newBoardQueue_checkForBoardLeaving(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_checkForBoardLeaving");
	DWORD dwrdDist = 0;
	DWORD deltaTime = 0;
	DWORD deltaPos = 0;

	BOOL bTrailingEdgeExit = FALSE;
	BOOL bLeadingEdgeExit = FALSE;

	BOOL boardOutputValid = FALSE;

	const DWORD dwCurrentTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));

	BOOL boardDetectOut = *(pNBQ->pBoardLeavingOven);

	if ( boardDetectOut == TRUE && pNBQ->lowHasOccurred == TRUE )
	{
		// We have a transition from OFF to ON of the exit sensor.  
		// Save the state of the current driver-time and clock-time.
		if ( pNBQ->previousBoardOutDetectState == FALSE )
		{
			pNBQ->startBoardOutDetectTime = dwCurrentTime;
			newBoardQueue_setTimeStampWithCurrentTime( pNBQ, &(pNBQ->m_localTimeExitLeadingEdge) );
		}

		deltaTime = differenceWithRollover( dwCurrentTime, pNBQ->startBoardOutDetectTime );
		if ( deltaTime >= 2 )
		{
			if (pNBQ->m_boardCount != 0)
			{
				boardOutputValid = TRUE;
			}
		}
	}

	if ( boardOutputValid == TRUE )
	{
		// need to detect whether board is in deadband
		dwrdDist = pNBQ->boards[pNBQ->headIndex].startPositionCounts;

		deltaPos = differenceWithRollover(pNBQ->currentBeltPosition, dwrdDist) + pNBQ->boardDropTolNeg;
		if ( deltaPos >= pNBQ->distanceBetweenSensorsCounts )
		{
			// If the exit DIN for board exiting is valid, and this is the first time we have
			// seen the valid flag, set the head flag.
			if ( boardOutputValid && (pNBQ->m_bleadingEdgeLow == TRUE) 
				&& (pNBQ->m_boardHeadReadExit == FALSE))
			{
				pNBQ->m_boardHeadReadExit = TRUE;
				pNBQ->m_boardStartPosExit = pNBQ->currentBeltPosition;
				//since a board is under the sensor, the trailing edge must not have occurred
				pNBQ->lowHasOccurred = FALSE;
				pNBQ->expectLowInputAfterCounts = pNBQ->currentBeltPosition + pNBQ->exitBoardDeadbandCounts;


				bLeadingEdgeExit = TRUE;
			}

			// Continue to update the board's "last" clock-time while the exit sensor is ON.
			// Trailing-edge timestamps will then be set when the board fully exits the oven.

			newBoardQueue_setTimeStampWithCurrentTime( pNBQ, &(pNBQ->m_localTimeExitTrailingEdge) );
		}
	}

	if ( pNBQ->m_boardHeadReadExit )
	{
		if ( boardDetectOut )
		{
			newBoardQueue_setTimeStampWithCurrentTime( pNBQ, &(pNBQ->m_localTimeExitTrailingEdge) );
		}
		//printk("detect out %d, lowed %d",boardDetectOut,pNBQ->lowHasOccurred);
		// If the DIN exit sensor is no longer on, check for cut-off deadband.
		if ( boardDetectOut == FALSE && pNBQ->lowHasOccurred == TRUE )
		{
			// The board has fully exited.  Reset the head flag.
			pNBQ->m_boardHeadReadExit = FALSE;

			// A Jammed board at the exit will set the trailing-edge timestamp
			// when the warning is fired and then the board will be removed.
			// Therefore only set the trailing-edge time stamp on a valid board if this is a successful exit.
			if ( pNBQ->boards[pNBQ->headIndex].bInUse &&
				(pNBQ->boards[pNBQ->headIndex].timeStamps.bValidExitTrailing == FALSE) )
			{
				bTrailingEdgeExit = TRUE;
				pNBQ->m_bleadingEdgeLow = FALSE;
			}
		}
	}

	if ( bLeadingEdgeExit )
	{
		//printk( "\nnewBoardQueue_checkForBoardLeaving\n" );
		// Record the exit side leading edge time stamp.
		Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), TRUE, &(pNBQ->m_localTimeExitLeadingEdge) );
	}

	if ( bTrailingEdgeExit )
	{

		// Record the exit side trailing edge time stamp.
		// The board will now be removed on the next iteration around the nbq_process() loop.
		Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), FALSE, &(pNBQ->m_localTimeExitTrailingEdge) );


		if ( pNBQ->m_boardCount != 0 )   // problem with boards processed being incremented when no boards in oven.
		{
			pNBQ->boardsProcessed++;

			pNBQ->inputHighCount = 0;
		}
	}

	// Save the current state of the exit DIN for use on the next iteration.
	pNBQ->previousBoardOutDetectState = boardDetectOut;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardEntering

			A new board entering the oven is defined by the elapsed 
			distance of the belt traveled since the last board is 
			detected being equal to or greater than the deadband for a 
			board. Some boards have holes or other gaps that can occur 
			where the sensor for the board input is. Without taking 
			into account some deadband limits any transition from low 
			to high would indicate a new board.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardEntering(newBoardQueue* pNBQ)
{
	DWORD deltaTime = 0;
	DWORD deltaDist = 0;
	BOOL  boardInputValid = FALSE;
	BOOL bStatus = FALSE;
	BOOL boardDetectIn = FALSE;

	DWORD dwCurrentTime;

	deltaTime = 0;
	deltaDist = 0;
	boardInputValid = FALSE;
	bStatus = FALSE;
	boardDetectIn = FALSE;

	dwCurrentTime = 0;


	dwCurrentTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
	if(pNBQ)
	{
		if (Oven_checkRecipeLoadBoardEntryWait(&g_dbContainer.ovenDb))	//ver8.0.0.24, wait after recipe load to start detecting boards
			boardDetectIn = FALSE;
		else
			boardDetectIn = *(pNBQ->pBoardEnteringOven);

		// Filter the board detection so that we recognize a valid board entering for a predetermined time.
		if ( boardDetectIn == TRUE )
		{
			if ( pNBQ->previousBoardDetectState == FALSE )
			{
				// We have a transition from OFF to ON.  
				// Save the state of the current driver-time and clock-time.
				pNBQ->m_startBoardInDetectTime = dwCurrentTime;
				newBoardQueue_setTimeStampWithCurrentTime( pNBQ, &(pNBQ->m_localTimeEntryLeadingEdge) );
			}

			deltaTime = differenceWithRollover( dwCurrentTime, pNBQ->m_startBoardInDetectTime );
			if ( deltaTime >= 2 )   // must see board for a 200mS.
			{
				boardInputValid = TRUE;
			}
		}

		// If the DIN for board entering is valid, then record the start of an entering board.
		if ( boardInputValid && (pNBQ->m_boardHeadReadEntry == FALSE))
		{
			pNBQ->m_boardHeadReadEntry = TRUE;
			pNBQ->m_boardStartPosEntry = pNBQ->currentBeltPosition;

			pNBQ->m_bPendSmema = TRUE;

			//note the system always declares a new board at the current belt position, even though the sensor
			//has been blocked for several cycles.
			newBoardQueue_newBoard(pNBQ, pNBQ->m_boardStartPosEntry);
		}

		// If the head of a board has been seen, then there is a board
		// in the process of entering.
		// While this board is entering check for the trailing edge and cut-off deadband.
		if ( pNBQ->m_boardHeadReadEntry )
		{
			// If the DIN input sensor is no longer on, check for cut-off deadband.
			if ( boardDetectIn == FALSE )
			{
				bStatus = newBoardQueue_isPastDeadBand(pNBQ);

				if ( bStatus )
				{
					// Deadband has been reached.  Clear the board's head flag and set the length of the board.
					pNBQ->m_boardHeadReadEntry = FALSE;
					newBoardQueue_setLength(pNBQ);


					// Set the entrance trailing edge stamp.
					// A Jammed board at the entry will set the trailing-edge timestamp
					// when the warning is fired.  Therefore only set the trailing-edge
					// time stamp if this is a successful entry.
					if ( pNBQ->boards[pNBQ->tailIndex].bInUse &&
						(pNBQ->boards[pNBQ->tailIndex].timeStamps.bValidEntryTrailing == FALSE) )
					{
						Board_TimeStampSetEntry( &(pNBQ->boards[pNBQ->tailIndex]), FALSE, &(pNBQ->m_localTimeEntryTrailingEdge) );
					}
				}
			}
		}

		//
		// SMEMA processing
		//

		// board for both length and deadband.
		if ( boardDetectIn == TRUE )
		{
			pNBQ->m_b9851Enter = FALSE;
			pNBQ->m_9851distanceTraveled = pNBQ->currentBeltPosition;
		}
		else
		{
			if ( pNBQ->m_bPendSmema == TRUE )
			{
				if ( (differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->m_9851distanceTraveled) > pNBQ->boardDeadbandCounts) )
				{
					pNBQ->m_b9851Enter = TRUE;
				}
			}
		}

		if ( boardInputValid == TRUE )
		{
		}
		else
		{
			if ( pNBQ->m_bPendSmema == TRUE &&
				 pNBQ->m_b9851Enter == TRUE )
			{
				pNBQ->m_bPendSmema = FALSE;
				pNBQ->m_bStartSmema = TRUE;

				pNBQ->m_b9851Enter = FALSE;

				bBoardEntering[pNBQ->boardQId] = FALSE;
				dwBoardEnteringTime[pNBQ->boardQId] = 0;
#ifdef DEBUG_SMEMA_HOLD
				printk("newBoardQueue_checkForBoardEntering lane%d\n", pNBQ->boardQId + 1);
#endif
				switch ( pNBQ->boardQId )
				{
					case 0:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD1, Belt_getBeltId(pNBQ->pBeltIOTied));
						break;

					case 1:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD2, Belt_getBeltId(pNBQ->pBeltIOTied));
						break;

					case 2:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD3, Belt_getBeltId(pNBQ->pBeltIOTied));
						break;

					case 3:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD4, Belt_getBeltId(pNBQ->pBeltIOTied));
						break;

					default:
						break;
				}
			}
			else if (pNBQ->m_bStartSmema == TRUE)
			{
				pNBQ->m_bStartSmema = FALSE;
			}
		}

		// Update the "last" positions and times of the board for when the input sensor ON.
		// These variables will be used to test for cut-off deadband when the input sensor transitions OFF.
		// Board length and trailing-edge timestamps will then be set.
		if ( boardDetectIn )
		{
			pNBQ->lastBoardDetectPosition = pNBQ->currentBeltPosition;
			pNBQ->lastBoardDetectTime = dwCurrentTime;

			newBoardQueue_setTimeStampWithCurrentTime( pNBQ, &(pNBQ->m_localTimeEntryTrailingEdge) );
		}

		// Save the current state of the DIN for use on the next iteration.
		pNBQ->previousBoardDetectState = boardDetectIn;
	}
	return;
}

//**************************************************************************************************
// void BoardQueue::setLength()
//
// Abstract:
// The boards length can only be determined by the position of the last board detection and the
// belt traveling an additional distance of deadband counts. Once the deadband counts have been
// achieved then the last position of the board being detected was the length of the previous
// board.
//
// Programmer: Steven Young
// Date: 6/25/1998
//
//**************************************************************************************************
void newBoardQueue_setLength(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setLength");
	Board* pBoard = &(pNBQ->boards[pNBQ->tailIndex]);

	if ( pBoard )
	{
		DWORD dwLength = pNBQ->lastBoardDetectPosition - pBoard->startPositionCounts;

		if ( pNBQ->m_bEnablePredefinedBoardLength )
		{
			if ( pNBQ->m_PredefinedBoardLength > 0 )
			{
				dwLength = pNBQ->m_PredefinedBoardLength;

				//
				// re-adjust starting edge of the board as necessary because this is a predefined length
				//
				DWORD startCount = Belt_getPosition(pNBQ->pBeltIOTied) - (pNBQ->boardDeadbandCounts + pNBQ->m_PredefinedBoardLength);

				Board_setStartPosition( pBoard, startCount );
			}
		}

		Board_setLength( pBoard, dwLength );
	}
}

//**************************************************************************************************
// BOOL BoardQueue::isPastDeadBand()
//
// Abstract:
// A board may have holes in it that may give the false impression that a board is complete and the
// next transition will add another board. The method of deadband has been changed from time to
// distance making the operation consistent at all speeds without having to change the time setting
// as belt speed changes.
//
// Programmer: Steven Young
// Date: 6/25/1998
//
//**************************************************************************************************
BOOL newBoardQueue_isPastDeadBand(newBoardQueue* pNBQ)
{
	BOOL status = FALSE;
	static BOOL pastDeadBandDetect = FALSE;
	DWORD lastBoardDetectionElapsed = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->lastBoardDetectPosition);
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_isPastDeadBand", 0);

	if (  lastBoardDetectionElapsed >= pNBQ->boardDeadbandCounts )
	{
		if ( pastDeadBandDetect == FALSE )
		{

			pastDeadBandDetect = TRUE;
		}

		status = TRUE;

		if (pNBQ->boardDeadbandCounts == 0)
		{
			if (*(pNBQ->pBoardEnteringOven) == TRUE)
			{
				status = FALSE;
			}
		}
	}
	else
	{
		pastDeadBandDetect = FALSE;

	}

	return status;
}

//**************************************************************************************************
// BOOL BoardQueue::newBoard()
//
// Abstract:
// A board may have holes in it that may give the false impression that a board is complete and the
// next transition will add another board. The method of deadband has been changed from time to
// distance making the operation consistent at all speeds without having to change the time setting
// as belt speed changes.
//
// Programmer: Steven Young
// Date: 6/25/1998
//
//**************************************************************************************************
void newBoardQueue_newBoard(newBoardQueue* pNBQ, DWORD beltStartPositionCounts )
{
	PARAM_CHECK( pNBQ, "newBoardQueue_newBoard");
	Board* pBoard = NULL;

	BOOL status = newBoardQueue_addBoard(pNBQ);     // get index into queue
	if ( status == TRUE )
	{
		pBoard = &(pNBQ->boards[pNBQ->tailIndex]);
		
		// always add a board to the end of the queue.
		// in the event no boards are in the oven then the head and tail are the same.
		pBoard->bInUse = TRUE;
		Board_setStartPosition( pBoard, beltStartPositionCounts );
		Board_setLength( pBoard, 0 );    // a new board that has been added is zero length until the next board is detected.
		Board_TimeStampSetEntry( pBoard, TRUE, &(pNBQ->m_localTimeEntryLeadingEdge) );

		pNBQ->m_boardStartPosEntry = 0;

		//printk( "newBoardQueue_newBoard() at index %d\n", pNBQ->tailIndex );
	}

	pNBQ->m_bBoardOnEntrySensor = TRUE;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_clearBoardsInOven


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_clearBoardsInOven(newBoardQueue* pNBQ)
{
	DWORD lcv;
	PARAM_CHECK( pNBQ, "newBoardQueue_clearBoardsInOven");

	//printk( "newBoardQueue_clearBoardsInOven()\n" );

	pNBQ->m_boardCount = 0;
	pNBQ->headIndex = 0;
	pNBQ->tailIndex = 0;

	for ( lcv = 0; lcv < MaxBoards; lcv++ )
	{
		// reset all the data in the structure
		Board_init( &(pNBQ->boards[lcv]) );
	}

	pNBQ->m_bPendSmema = FALSE;
	pNBQ->m_bStartSmema = FALSE;
	pNBQ->m_boardHeadReadEntry = FALSE;
	pNBQ->m_boardStartPosEntry = 0;
	pNBQ->m_dwrdLastBeltPosWNoBoards = pNBQ->currentBeltPosition - pNBQ->m_FCExit;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardsProcessed


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardsProcessed(newBoardQueue* pNBQ, DWORD noOfBoardsProcessed )
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setBoardsProcessed");
	pNBQ->boardsProcessed = noOfBoardsProcessed;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_clearBoardsProcessed


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_clearBoardsProcessed(newBoardQueue* pNBQ)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_clearBoardsProcessed");
	pNBQ->boardsProcessed = 0;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getMaxBoards


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD newBoardQueue_getMaxBoards(newBoardQueue* pNBQ)
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getMaxBoards", 0);
	return MaxBoards;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getName


 GLOBALS:
 RETURNS:   const char*
 SEE ALSO:
------------------------------------------------------------------------*/
const char* newBoardQueue_getName(newBoardQueue* pNBQ)
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getName", 0);
	return pNBQ->name;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getSensorDistance


 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD newBoardQueue_getSensorDistance(newBoardQueue* pNBQ)
{
	PARAM_CHECK_RETURN( pNBQ, "newBoardQueue_getSensorDistance", 0);
	return pNBQ->distanceBetweenSensorsCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_enableBoardStop


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_enableBoardStop(newBoardQueue* pNBQ, BOOL enableState)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_enableBoardStop");
	pNBQ->m_bEnableBoardStop = enableState;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setExitBoardDeadbandCounts


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setExitBoardDeadbandCounts(newBoardQueue* pNBQ, DWORD boardDeadbandExitInCounts)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setExitBoardDeadbandCounts");
	pNBQ->exitBoardDeadbandCounts = boardDeadbandExitInCounts;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardDropTolerance


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropTolerance(newBoardQueue* pNBQ, DWORD bdt)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setBoardDropTolerance");
	pNBQ->boardDropTol = bdt;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardDropTime


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropTime(newBoardQueue* pNBQ, UINT bTime)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setBoardDropTime");
	pNBQ->uintBoardDropTime = bTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardDropToleranceNeg


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropToleranceNeg(newBoardQueue* pNBQ, DWORD bdt)
{
	PARAM_CHECK( pNBQ, "newBoardQueue_setBoardDropToleranceNeg");
	pNBQ->boardDropTolNeg = bdt;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setSprayDist


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setSprayDist(newBoardQueue* pNBQ, DWORD dwDist)
{
	pNBQ->m_dwSprayDist = dwDist;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_enableSpraySensor


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_enableSpraySensor(newBoardQueue* pNBQ, BOOL bEnable)
{
	pNBQ->m_bSprayEnabled = bEnable;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_addSprayLength


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_addSprayLength(newBoardQueue* pNBQ, DWORD dwrLength)
{
	pNBQ->dwSprayLength = dwrLength;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForSpray


 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL newBoardQueue_checkForSpray(newBoardQueue* pNBQ)
{
	DWORD index = pNBQ->headIndex;
	DWORD lcv;

	BOOL bReturn = FALSE;

	if (!pNBQ->m_bSprayEnabled)
	{
		bReturn = FALSE;
	}
	else
	{
		for (lcv = 0; (lcv < pNBQ->m_boardCount) && (bReturn == FALSE); lcv++, index++)
		{
			if (index >= MaxBoards)
			{
				index = 0;
			}

			if (pNBQ->m_dwSprayDist < (pNBQ->boards[index].elapsedPositionCounts) 
				&& pNBQ->boards[index].elapsedPositionCounts < (pNBQ->dwSprayLength + pNBQ->boards[index].boardLengthCounts + pNBQ->m_dwSprayDist))
			{
				bReturn = TRUE;
			}
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardFCExit


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardFCExit(newBoardQueue* pNBQ)
{
	if (pNBQ->boardsInOvenEnabled == TRUE)
	{
		if (pNBQ->m_boardCount)
		{
			pNBQ->m_dwrdLastBeltPosWNoBoards = pNBQ->currentBeltPosition;
			pNBQ->m_bBoardExitFull = FALSE;
		}
		else
		{
			if ((pNBQ->currentBeltPosition - pNBQ->m_dwrdLastBeltPosWNoBoards) >= pNBQ->m_FCExit)
			{
				pNBQ->m_bBoardExitFull = TRUE;
			}
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardFCExtraTravel


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setBoardFCExtraTravel(newBoardQueue* pNBQ, DWORD extra)
{
	pNBQ->m_FCExit = extra;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_updateCurrentTime


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_updateCurrentTime( newBoardQueue* pNBQ )
{
	//
	// Update Current time
	//
	if(pNBQ->m_currentTime.dwLow == 0xffffffff)
	{
		pNBQ->m_currentTime.dwHigh++;
		pNBQ->m_currentTime.dwLow = 0;
	}
	pNBQ->m_currentTime.dwMilli += differenceWithRollover(jiffies, pNBQ->m_jiffies);
	pNBQ->m_jiffies = jiffies;

	if(pNBQ->m_currentTime.dwMilli > 999)
	{
		pNBQ->m_currentTime.dwLow++;
		pNBQ->m_currentTime.dwMilli -= 1000;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setTimeStampWithCurrentTime

			Copies the current time into the timestamp parameter.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_setTimeStampWithCurrentTime( newBoardQueue* pNBQ, LocalTime* pTimeStamp )
{
	if ( pNBQ && pTimeStamp )
	{
		pTimeStamp->dwHigh = pNBQ->m_currentTime.dwHigh;
		pTimeStamp->dwLow = pNBQ->m_currentTime.dwLow;
		pTimeStamp->dwMilli = pNBQ->m_currentTime.dwMilli;
	}
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_markBoardsWithCooldown

			Marks all the boards in the oven as being in COOLDOWN.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void newBoardQueue_markBoardsWithCooldown( newBoardQueue* pNBQ )
{
	int i = 0;
	Board* pBoard = NULL;

	if ( pNBQ )
	{
		if ( pNBQ->m_boardCount )
		{
			for ( i = 0; i < MaxBoards; i++ )
			{
				pBoard = &(pNBQ->boards[i]);
				if ( pBoard->bInUse )
				{
					pBoard->bCooldown = TRUE;
				}
			}
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getNextIndex

			return the index of the second board in queue
			only call if there is more than 1 board in queue

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT newBoardQueue_getNextIndex(newBoardQueue* pNBQ)
{
	UINT uiReturn = pNBQ->headIndex;
	uiReturn++;
	if ( uiReturn == MaxBoards )
	{
		uiReturn = 0;
	}
	return uiReturn;
}
