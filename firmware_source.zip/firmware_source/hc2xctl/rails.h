/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __RAILS_H__
#define __RAILS_H__

//#include "heller.h"
#include "modbcrc.h"	// Added by ClassView
#include "typedefdefine.h"
#include "rail.h"

/*

6/17/1998

Ray L mentioned that max and min distances for each rail could be set.
This would require changes to the Setup Screen but could reduce the amount
of logic required for configurations 7,8,9,10, 15,16,17, 18, 19 ... 
Also need to consider that if opitios 15 and above are limited it may be
worthwhile to create separate modules for these configurations.
All of the valid rail configurations. Confirmed 
with Ray Lachenauer, Heller Industries on June 16, 1998
Configuration Parameters:
F - Fixed Rail 1 or 2
R - Movable Rail 1 or 3
CBS - Movable Center Board Support

0. No Rails Configured.

Configuration 
One Fixed Rail
1. F1 R1
2. F1 CBS1 R1

Fixed Edge Rail and Fixed Center Rail.
3. F1 R1		F2 R3
4. F1 CBS1 R1	F2 R3
5. F1 CBS1 R1	F2 CBS2 R3
6. F1 R1		F2 CBS2 R3

Fixed Rails on Outside Edges.
7.  F1 R1		R3 F2
8.  F1 CBS1 R1	R3 F2
9.  F1 CBS1 R1	R3 CBS2 F2
10. F1 R1		R3 CBS2 F2

One Fixed Rail in Center
11.			R1		F1		R3
12.		R1	CBS1	F1		R3		
13.		R1	CBS1	F1		CBS2	R3
14.			R1		F1		CBS2	R3

New configuration as of 6/17/1998 hold for review for future release.
Need to consider placement of rails and overlapped lanes. This will increase
the number of combinations dramatically. 

15.		F1 R1		F2 R2		F3 R3				Three rails no CBS
16.		F1 CBS1 R1	F2 R3		F3 R4				4 rails w/CBS
17.		F1 R1		F2 CBS1 R3	F3 R4				4 rails w/CBS
18		F1 R1		F2 R3		F3 CBS1 R4			4 rails w/CBS
19		F1 R1		F2 R2		F3 R3		F4 R4

Four conditions that will cause a sequence to abort:

1. When moving home and no pulses received.
2. When moving home and proximity sensor does not trip after 3 minutes.
3. When emergency stop button is pushed.
4. When board is detected in oven.

need to add

F1 R1 
F1 R1 F2 CBS1
F1 R1 F2 CBS1 F3	
F1 R1 F2 CBS1 F3 F4 CBS2	

*/

enum RailState	{ HOME_STATE=1,PRESET_STATE,BOARDS_IN_OVEN_STATE,E_STOP_STATE, MANUAL_STATE };
enum Rails_ControlType { SOFTWARE_CON = 1, HARDWARE_CON }; 
enum	{ RailCombinations = 16  };

typedef struct _Rails_
{	
//public:
	enum RailState		    railState;
	enum RailState			indRailState[MaxRails];
	enum Rails_ControlType			railControlVector;

//private:
//Boolean to control which rails the board sensors deactive true if 4 rail configuration
	BOOL				m_bFourRails;
//Boolean to test if the rails need to move to home when the recipe is switched
	BOOL				railWidthChanged[MaxRails];
//see note for boolean when =true is set
	BOOL				firstRecipeLoad[MaxRails];
	BOOL				bRWC;
	DWORD				railPositions[MaxRails];
	BOOL				m_bPreventMoveFromCooldown;

//variables for intermediate storage and testing of setpoints
	DWORD				presetPositionBuffer[MaxRails];
	BOOL				moveThisRail[MaxRails];
	BOOL				homeIndicatorBuffer[MaxRails];
	BOOL				newRailPositions;
	DWORD				selfAckAlarmNo;
	DWORD				selfAckAlarmNo2;
	BOOL				m_bSoftwareDisengaged;
	UINT				configurationOption;
	UINT				noActiveRails;
	UINT				currentRail;
	enum HomeDirection currentHomeDirection;
	Rail				rail0;
	Rail				rail1;
	Rail				rail2;
	Rail				rail3;
	Rail				badRail;
	DWORD				jobNo;
	DWORD				jobNoForEx;

	UINT				railToIncrement;
	UINT				railToDecrement;
	BOOL				timeDelayElapsed;
	BOOL				allRailsAtHome;
	BOOL				allRailsAtPreset;
	DWORD				startDelayTime10ths;
	BOOL				bAllowMovement;
	DWORD				mTimerCount;
	BOOL				m_bSkipJobStartupRoutine;
	BOOL				m_bForceHome;
	UINT				m_iInputForHardware;	
	BOOL				m_bRailNotPreseting[MaxRails];
	BOOL				m_bNeedsHome;
	BOOL 				m_bRailsHaveHomed;
	BOOL 				m_bJogOn;
	BOOL 				m_bJogPossible;
	BOOL				m_bJobSwitchover;
	UINT				m_uintJogPhase;
	UINT				m_uintUpdownPhase;
	UINT 				controledUD[MaxRails];
	BOOL				m_bSwitchJogFlag;
	BOOL 				m_bUDPhaseMonitor;
	DWORD				startJogTime;
	BOOL				railSuspended;
	BOOL				m_bStartupDisabled;
	DWORD				udPhaseTimer;
	DWORD				pulseCounts[MaxRails];
	DWORD				m_dwrdOurStartupGroup;
	DWORD 			m_dwrdTheCurrentGroup;
	BOOL			m_bRailHardwarePreProcess;
	BOOL			mbTestReturn;
	BOOL			bHardwarePause;
} Rails;

void Rails_preTest(Rails* pRails);
UINT Rails_railsInHardwareMode(Rails* pRails);
void Rails_clearWarnings(Rails* pRails);
void Rails_suspendRailOps(Rails* pRails, BOOL bSuspendRails);
void Rails_resetTimeDelay(Rails* pRails);
BOOL Rails_timeDelay(Rails* pRails);
void Rails_allRailsHome(Rails* pRails);
void Rails_checkAllRailsHome(Rails* pRails);
void Rails_checkAllRailsAtPreset(Rails* pRails);
void Rails_presetRails(Rails* pRails);
void Rails_timeOutMovementCheck(Rails* pRails);
BOOL Rails_checkForMadePresetAndHuntFailure(Rails* pRails);
void Rails_manualRails(Rails* pRails);
UINT Rails_returnRailsHaveHomed(Rails* pRails);
void Rails_sendRailsHome(Rails* pRails, UINT presetOption);
UINT Rails_returnHardwareRunning(Rails* pRails);
BOOL Rails_process_hardware(Rails* pRails);
void Rails_setHardwareOption(Rails* pRails, UINT railControlType);
void Rails_init(Rails* pRails);

Rail* Rails_GetRail(Rails* pRails, DWORD railNo);

void Rails_checkDistance(Rails* pRails);
void Rails_process(Rails* pRails);
BOOL Rails_setConfiguration(Rails* pRails, DWORD configNo );
UINT Rails_getNoOfActiveRails(Rails* pRails);
void Rails_setPosition(Rails* pRails, DWORD railNo, DWORD presetPosition, BOOL bHomeIndicator );
DWORD Rails_getPositionCounts(Rails* pRails, DWORD railNo );
void Rails_increment(Rails* pRails, DWORD railNo );
void Rails_decrement(Rails* pRails, DWORD railNo );
void Rails_resetIncDec(Rails* pRails, DWORD railNo );

BOOL Rails_allRailsPreset( Rails* pRails, int lane_index );
BOOL Rails_allRailsPresetSharedDual( Rails* pRails);
BOOL Rails_inWarningRailsPreset( Rails* pRails, int lane_index );//using this for warning mode, out of pos can be due to SP change
BOOL Rails_inWarningRailsPresetSharedDual( Rails* pRails);//using this for warning mode, out of pos can be due to SP change

//Rails_we can't set the values of the array elements in the contructor so We'll
//do it in a function called from the setsystemparam function
void Rails_IntializeEdgeholdBools(Rails* pRails);
void Rails_EnableTest(Rails* pRails);
void Rails_DisableTest(Rails* pRails);
void Rails_setOpFromCoolRailMovement(Rails* pRails, BOOL bMove);
void Rails_queueSetPosition(Rails* pRails, DWORD railNo, DWORD presetPosition, BOOL bHomeIndicator);
void Rails_arrayInitialization(Rails* pRails);
void Rails_bypassHomeAndPresetRoutines(Rails* pRails);
void Rails_setRailStateToPresetForJobLoad(Rails* pRails);
BOOL Rails_returnRailTerminalPosition(Rails* pRails);
void Rails_setRailInputForHardware(Rails* pRails, UINT uintIndex);
void Rails_testJobTime(Rails* pRails);
void Rails_setRailHuntValues(Rails* pRails, BOOL bJogging);
void Rails_setHomeUnstable(Rails* pRails);
void Rails_railJogOptionPossible(Rails* pRails, UINT bPossible);
void Rails_ExerciseCBS2onRail(Rails * pRails, DWORD dwrdRailN);
void Rails_SetJogOn(Rails* pRails, UINT bOn);
UINT returnRailsHaveHomed(Rails* pRails);
UINT Rails_Process_JogCycle(Rails* pRails);
DWORD Rails_monitorudPhaseTimer(Rails * pRails);
UINT Rails_monitorm_uintUpdownPhase(Rails * pRails);
UINT Rails_monitorm_uintJogPhase(Rails* pRails);
UINT Rails_monitorm_bJogOn(Rails * pRails);
UINT Rails_monitorcurrentRail(Rails* pRails);
void Rails_SetPulseCounts(Rails* pRails, DWORD count, DWORD index);
UINT Rails_phaseUpDown(Rails* pRails, UINT iWhichUD);
UINT Rails_monitorm_bUDPhaseMonitor(Rails* pRails);
void Rails_SetStartupGroup(Rails* pRails, DWORD nGroup);
#endif
