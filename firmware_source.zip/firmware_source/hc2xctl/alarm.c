//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: alarm.c
//
// Description: alarm processing
//
// This is a trade secret of imagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 12-Nov-14  FJN  Check current monitor cooldown delay together with [blower] cooldown delay
// 05-Dec-14  FJN  Check heater failure cooldown delay
// 04-Mar-16  FJN  Implement custom alarm 4 and 5
// 02-Apr-17  TP   Modify AlarmQueue_getAlarmMessage() to not call Alarm_getAlarm() when delayFor10Seconds is TRUE
// 02-Apr-17  TP   Modify AlarmQueue_addAlarm() to allow BOARD_ADDED logged events if previous is not processed
// 28-Aug-17  TP   Modify AlarmQueue_alarmQueueAcknowledge() to comment out "pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE" to correct board drop and stop audible alarm issue when multiple warnings are present and some of them clears
//
//*****************************************************************************
#include <stdio.h>
#include "contain.h"
#include "alarm.h"
#include "oven.h"
#include "purge.h"
#include "timer.h"
//#include "xpdriverdevice.h"
//#include "xpdriverioctl.h"

//#define DEBUG_addAlarm

extern DbContainer g_dbContainer;

static AlarmQueue*	alarmQueue = NULL;
static Oven*		ovenDb = NULL;
static Timer*		elapseTimerDb = NULL;
static Purge*		purgeControl = NULL;

unsigned char ucLane1Secsgem;
unsigned char ucLane2Secsgem;
unsigned char ucLane3Secsgem;
unsigned char ucLane4Secsgem;

unsigned char ucLane1Audible;
unsigned char ucLane2Audible;
unsigned char ucLane3Audible;
unsigned char ucLane4Audible;
unsigned char ucAudible1Clear;
unsigned char ucAudible2Clear;
unsigned char ucAudible3Clear;
unsigned char ucAudible4Clear;

///////////////////////////////////////////////////////////////////
//
// Alarm methods
//
///////////////////////////////////////////////////////////////////

void Alarm_init(Alarm* pAlarm)
{
	PARAM_CHECK( pAlarm, "Alarm_init");

	alarmQueue = &(g_dbContainer.alarmQueueDb);
	pAlarm->alarmID = 0;
	pAlarm->moduleCode = 0;
	pAlarm->alarmType = AVAILABLE;
	pAlarm->messageNo = 0;
	pAlarm->read = TRUE;
	pAlarm->acknowledge = TRUE;
	
}

void Alarm_getAlarm(Alarm* pAlarm, TransferAlarmData* pAlarmData, BOOL setReadFlag )
{
	PARAM_CHECK( pAlarm, "Alarm_getAlarm");

	pAlarmData->alarmID		= pAlarm->alarmID;
	pAlarmData->moduleCode	= pAlarm->moduleCode;
	pAlarmData->alarmType	= pAlarm->alarmType;
	pAlarmData->messageNo	= pAlarm->messageNo;
	pAlarmData->tStamp		= pAlarm->tStamp;						
	pAlarmData->read		= pAlarm->read;			// let the windows app know if it has been read or not
	pAlarmData->notify		= pAlarm->notify;

	if(setReadFlag)
		pAlarm->read = TRUE;
	else
		pAlarm->notify = TRUE;
}

void Alarm_setAlarm(Alarm* pAlarm, enum AlarmType aType, UINT messNo, UINT mCode, DWORD alarmID)
{
	PARAM_CHECK( pAlarm, "Alarm_setAlarm");

	pAlarm->alarmID		= alarmID;
	pAlarm->moduleCode	= mCode;
	pAlarm->alarmType	= aType;
	pAlarm->messageNo	= messNo;
	//getTimeStamp(tStamp);
	pAlarm->read		= FALSE;	// comes from user. Set to true when acknowledged.
	pAlarm->notify		= FALSE;
	pAlarm->acknowledge = FALSE; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Alarm_alarmAcknowledge

			acknowledges (clears) a single alarm

 RETURNS:   void
------------------------------------------------------------------------*/
void Alarm_alarmAcknowledge(Alarm* pAlarm)
{
	if(pAlarm)
	{
		pAlarm->acknowledge = TRUE;
	}
	return;
}

///////////////////////////////////////////////////////////////////
//
// AlarmQueue methods
//
///////////////////////////////////////////////////////////////////


UINT AlarmQueue_getAlarmCount(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getAlarmCount", -1);

	return pAlarmQ->openAlarms;
}

UINT AlarmQueue_getStatusEvents(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getStatusEvents", -1);

	return pAlarmQ->alarmCount;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	AlarmQueue_resetAlarms
				acks all alarms, warnings,etc
				

	RETURNS:   void
------------------------------------------------------------------------*/
void AlarmQueue_resetAlarms(AlarmQueue* pAlarmQ)
{
	UINT lcv;
	signed char i;

	i = 0;
	lcv = 0;

	if( NULL != pAlarmQ )
	{
		for(i = 0; i < MAX_CALARMS_BOTH_TYPES; i++)
		{
			Purge_clearWarning(i);
		}
		for ( lcv = 0; lcv < MaxAlarms; lcv++ )
		{
			pAlarmQ->aq[lcv].read = TRUE;
			pAlarmQ->aq[lcv].acknowledge = TRUE;
			pAlarmQ->aq[lcv].alarmID = 0;
			pAlarmQ->aq[lcv].alarmType = AVAILABLE;
			pAlarmQ->aq[lcv].messageNo = 0;
			pAlarmQ->aq[lcv].moduleCode = 0;
		}
		pAlarmQ->alarmCount = 0;
		pAlarmQ->openWarnings = 0;
		pAlarmQ->openAlarms	= 0;
		pAlarmQ->openAudibleWarnings = 0;
		pAlarmQ->boardDropWarning = FALSE;
		pAlarmQ->m_bAudibleWarningFlag = FALSE;
		pAlarmQ->boardDropWarningLT = FALSE;
		pAlarmQ->m_openBCWarnings=0;
		pAlarmQ->m_openAudibleLaneWarnings=0;
		pAlarmQ->m_bAudibleEnergySave=FALSE;
		pAlarmQ->m_bCA3InWarning=FALSE;
		pAlarmQ->m_bCA3Output=FALSE;
		pAlarmQ->m_bCA4InWarning=FALSE;
		pAlarmQ->m_bCA4Output=FALSE;
		pAlarmQ->m_bCA5InWarning=FALSE;
		pAlarmQ->m_bCA5Output=FALSE;
		pAlarmQ->m_bBlowerInWarning = FALSE;
		for(lcv = 0; lcv < MAX_SMEMA_LANES; lcv++)
		{
			if(pAlarmQ->m_bAudibleBoardWarnings[lcv]==TRUE)
			{
				pAlarmQ->m_bAudibleBoardInWarning[lcv]=FALSE;
			}
		}

		pAlarmQ->openWarnings_lt1 = 0;
		pAlarmQ->openWarnings_lt2 = 0;
		pAlarmQ->openWarnings_common = 0;
		OVEN_allowPowerLossWarning();

		if( TRUE == g_bLotProcessingEnable )
		{
			g_dbContainer.boardQ0.existingBoardDropID=0;
			g_dbContainer.boardQ1.existingBoardDropID=0;
			g_dbContainer.boardQ2.existingBoardDropID=0;
			g_dbContainer.boardQ3.existingBoardDropID=0;
		}
		else	//ver8.0.0.15  TESTONLY
		{
			g_dbContainer.boardQ0_NoLP.existingBoardDropID = 0;
			g_dbContainer.boardQ1_NoLP.existingBoardDropID = 0;
			g_dbContainer.boardQ2_NoLP.existingBoardDropID = 0;
			g_dbContainer.boardQ3_NoLP.existingBoardDropID = 0;
		}
	}
	ucAudible1Clear = 0;
	ucAudible2Clear = 0;
	ucAudible3Clear = 0;
	ucAudible4Clear = 0;
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	AlarmQueue_audibleWarningsPresent

				sub function for audible output
				

	RETURNS:   uint
------------------------------------------------------------------------*/
UINT AlarmQueue_audibleWarningsPresent(AlarmQueue* pAlarmQ)
{
#ifdef DEBUG_AUDIBLEWARNING
	static DWORD lastTime = 0;
	DWORD currentTime = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
#endif

	BOOL bReturn;
	bReturn = FALSE;
	if(pAlarmQ)
	{
		if(pAlarmQ->m_bBlowerInWarning)
		{
			bReturn = TRUE;
		}
		if( pAlarmQ->openAudibleWarnings && pAlarmQ->openWarnings )
		{
			bReturn = TRUE;
		}
		else if(pAlarmQ->m_bAudibleEnergySave==TRUE)
		{
			bReturn=TRUE;
		}
		else if(pAlarmQ->m_bAudibleCA3==TRUE && pAlarmQ->m_bCA3InWarning==TRUE)
		{
			// user settable
			bReturn = TRUE;
		}
		else if(pAlarmQ->m_bAudibleCA4==TRUE && pAlarmQ->m_bCA4InWarning==TRUE)
		{
			// user settable
			bReturn = TRUE;
		}
		else if(pAlarmQ->m_bAudibleCA5==TRUE && pAlarmQ->m_bCA5InWarning==TRUE)
		{
			// user settable
			bReturn = TRUE;
		}
		else if( pAlarmQ->m_bAudibleLane1Warnings==1 || pAlarmQ->m_bAudibleLane2Warnings==1 ) 
		{
			// user settable
			if ( pAlarmQ->m_openAudibleLaneWarnings != 0 )
			{
				bReturn = TRUE;
			}
		}
	}	

#ifdef DEBUG_AUDIBLEWARNING
	if (currentTime - lastTime >= 10)
	{
		lastTime = currentTime;
		printk("m_openAudibleLaneWarnings=%d, bReturn=%d\n", pAlarmQ->m_openAudibleLaneWarnings, (short)bReturn);
	}
#endif	

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	AlarmQueue_init

				
				init function

	RETURNS:   void
------------------------------------------------------------------------*/
void AlarmQueue_init(AlarmQueue* pAlarmQ)
{
	int i;
	i = 0;
	if(pAlarmQ)
	{
		pAlarmQ->alarmCount = 0;
		pAlarmQ->alarmID = 1;
		pAlarmQ->boardDropWarning = FALSE;
		pAlarmQ->aStatus	= AS_OK;
		pAlarmQ->delayFor10seconds = FALSE;
		pAlarmQ->m_AlarmLight = FALSE;
		pAlarmQ->openAudibleWarnings = 0;
		pAlarmQ->m_bAudibleBeltWarningsEnabled = FALSE;
		pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
		pAlarmQ->m_bAudibleLowExhaustEnabled = FALSE;
		pAlarmQ->m_bAudibleDansensorWarningEnabled = FALSE;
		pAlarmQ->m_bProcessLoopStarted = FALSE;
		pAlarmQ->m_bAudibleWarnings = FALSE;
		pAlarmQ->m_bOKForAudibleWarnings = TRUE;
		pAlarmQ->m_bAudibleWarningFlag = FALSE;
		pAlarmQ->m_bAudibleLane1Warnings = TRUE;
		pAlarmQ->m_bAudibleLane2Warnings = TRUE;
		pAlarmQ->boardDropWarningLT = FALSE;
		pAlarmQ->m_bBlowerInWarning = FALSE;
		for(i=0; i<MaxAlarms; i++)
		{
			Alarm_init(&(pAlarmQ->aq[i]));
		}
	
		ovenDb = &(g_dbContainer.ovenDb);
		elapseTimerDb = &(g_dbContainer.elapseTimer);
		purgeControl = &(g_dbContainer.purge);
		pAlarmQ->startTime	= Timer_getCurrentTime10ths(elapseTimerDb);
		pAlarmQ->currentTime = Timer_getCurrentTime10ths(elapseTimerDb);
		pAlarmQ->m_bAudibleBCWarnings=FALSE;
		pAlarmQ->m_openBCWarnings=0;
		pAlarmQ->m_bVIPMode = FALSE;
		pAlarmQ->m_dwrdOutput = ODO_NULL;
		pAlarmQ->m_openAudibleLaneWarnings=0;
		pAlarmQ->m_bAudibleEnergySave=FALSE;
		pAlarmQ->m_bAudibleCA3 = FALSE;
		pAlarmQ->m_bAudibleCA4 = FALSE;
		pAlarmQ->m_bAudibleCA5 = FALSE;
		pAlarmQ->m_bCA3InWarning = FALSE;
		pAlarmQ->m_bCA4InWarning = FALSE;
		pAlarmQ->m_bCA5InWarning = FALSE;
		pAlarmQ->m_bCA3Output=FALSE;
		pAlarmQ->m_bCA4Output=FALSE;
		pAlarmQ->m_bCA5Output=FALSE;
		for(i=0; i<MAX_SMEMA_LANES; i++)
		{
			pAlarmQ->m_bAudibleBoardWarnings[i]=FALSE;
			pAlarmQ->m_bAudibleBoardInWarning[i]=FALSE;
		}
		ucLane1Secsgem = 0;
		ucLane2Secsgem = 0;
		ucLane3Secsgem = 0;
		ucLane4Secsgem = 0;
		
		ucLane1Audible = 0;
		ucLane2Audible = 0;
		ucLane3Audible = 0;
		ucLane4Audible = 0;

		ucAudible1Clear = 0;
		ucAudible2Clear = 0;
		ucAudible3Clear = 0;
		ucAudible4Clear = 0;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_alarmQueueAcknowledgeByType


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AlarmQueue_alarmQueueAcknowledgeByType(AlarmQueue* pAlarmQ, DWORD alarmTypesearch )
{
	UINT lcv = 0;
	for( lcv = 0; (lcv< MaxAlarms) ; lcv++ )
	{
		if ( pAlarmQ->aq[lcv].messageNo == alarmTypesearch && pAlarmQ->aq[lcv].acknowledge == FALSE )
		{
			AlarmQueue_alarmQueueAcknowledge(pAlarmQ,pAlarmQ->aq[lcv].alarmID); 
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_alarmQueueAcknowledge

			acks one alarm/warning

 RETURNS:   BOOL true if found
------------------------------------------------------------------------*/
BOOL AlarmQueue_alarmQueueAcknowledge(AlarmQueue* pAlarmQ, DWORD alarmIDsearch )
{
	BOOL found;
	UINT lcv;

	// used for keeping track of warnings belonging to a lane of one of the light towers
	BOOL bLightTower1;
	BOOL bLightTower2;

	found = FALSE;
	lcv = 0;
	bLightTower1 = FALSE;
	bLightTower2 = FALSE;

	if( NULL != pAlarmQ )
	{
		for( lcv = 0; (lcv< MaxAlarms) && (found == FALSE); lcv++ )
		{
			bLightTower1 = FALSE;
			bLightTower2 = FALSE;

			if ( pAlarmQ->aq[lcv].alarmID == alarmIDsearch && 
				pAlarmQ->aq[lcv].acknowledge == FALSE )
			{
				// need to know how many alarms and warnings are present so the light
				// tower can be set correctly.
				if(pAlarmQ->aq[lcv].messageNo == CUSTOM_MESSAGE_INITED)
				{
					Purge_clearWarning(0);
				}
				if(pAlarmQ->aq[lcv].messageNo == CUSTOM_MESSAGE_INITED2)
				{
					Purge_clearWarning(1);
				}
				switch ( pAlarmQ->aq[lcv].alarmType )
				{
					case ALARM:
						if ( pAlarmQ->openAlarms > 1 )
						{
							pAlarmQ->openAlarms--;	
						}
						else
						{
							pAlarmQ->openAlarms = 0;	// decrement the number of alarms, typically 1
						}
						break;

					case WARNING:
						switch ( pAlarmQ->aq[lcv].messageNo )
						{
							case POWER_FAILURE_EVENT:
								OVEN_allowPowerLossWarning();
								break;

							case CA3_WARNING:
								pAlarmQ->m_bCA3InWarning = FALSE;
								pAlarmQ->m_bCA3Output = FALSE;
								break;

							case CA4_WARNING:
								pAlarmQ->m_bCA4InWarning = FALSE;
								pAlarmQ->m_bCA4Output = FALSE;
								break;

							case CA5_WARNING:
								pAlarmQ->m_bCA5InWarning = FALSE;
								pAlarmQ->m_bCA5Output = FALSE;
								break;

							case EXIT_ENERGY_MODE:
								pAlarmQ->m_bAudibleEnergySave = FALSE;
								break;

							case HEAT_FAN_FAULT_WARN_CODE:
								if ( ovenDb->m_bAudibleBlowFail )
								{
									pAlarmQ->m_bBlowerInWarning = FALSE;
								}
								break;
					 
							case BELT_HI_DEVIATION_WARNING:/* FALL THROUGH */
							case BELT_LO_DEVIATION_WARNING:
								if(pAlarmQ->m_bAudibleBeltWarningsEnabled)
								{
									if ( pAlarmQ->openAudibleWarnings > 1 )
									{
										pAlarmQ->openAudibleWarnings--;	
									}
									else
									{
										pAlarmQ->openAudibleWarnings = 0;	// decrement the number of alarms, typically 1
									}
								}				
								break;

							case LOW_EXHAUST_WARNING:
								if(pAlarmQ->m_bAudibleLowExhaustEnabled)
								{
									if ( pAlarmQ->openAudibleWarnings > 1 )
									{
										pAlarmQ->openAudibleWarnings--;	
									}
									else
									{
										pAlarmQ->openAudibleWarnings = 0;	// decrement the number of alarms, typically 1
									}
								}
								break;

							case TZ_HI_DEVIATION_ALARM_SEC:
								if(pAlarmQ->m_bAudibleBeltWarningsEnabled || 
									pAlarmQ->m_bAudibleLowExhaustEnabled ||
									pAlarmQ->m_bAudibleDansensorWarningEnabled)
								{
									if ( pAlarmQ->openAudibleWarnings > 1 )
									{
										pAlarmQ->openAudibleWarnings--;	
									}
									else
									{
										pAlarmQ->openAudibleWarnings = 0;	// decrement the number of alarms, typically 1
									}
								}
								break;

							case SECSGEM_WARN1:
								ucAudible1Clear = 0;
								break;

							case SECSGEM_WARN2:
								ucAudible2Clear = 0;
								break;

							case SECSGEM_WARN3:
								ucAudible3Clear = 0;
								break;

							case SECSGEM_WARN4:
								ucAudible4Clear = 0;
								break;
								
							case PPM_EXCEEDS_ALARM1_WARNING: /* FALL THROUGH */
							case ALARM2_EXCEEDS_PPM_WARNING:
							case PPM_EXCEEDS_ALARM2_WARNING:
							case DANSENSOR_CONNECTION_BROKEN:
							case DANSENSOR_NOT_CONNECTIONED:
							case DANSENSOR_STOPPED:
								if(pAlarmQ->m_bAudibleDansensorWarningEnabled)
								{
									if ( pAlarmQ->openAudibleWarnings > 1 )
									{
										pAlarmQ->openAudibleWarnings--;	
									}
									else
									{
										pAlarmQ->openAudibleWarnings = 0;	// decrement the number of alarms, typically 1
									}
								}
								break;

							case BOARD_DROP_WARNING:
								if( TRUE == g_bLotProcessingEnable )
								{
									g_dbContainer.boardQ0.existingBoardDropID = 0;
								}
								else	//ver8.0.0.15 TESTONLY
								{
									g_dbContainer.boardQ0_NoLP.existingBoardDropID = 0;
								}

								if( pAlarmQ->m_bAudibleBoardWarnings[0] == TRUE )
								{
									pAlarmQ->m_bAudibleBoardInWarning[0] = FALSE;
								}

								if( pAlarmQ->m_bAudibleLane1Warnings )
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if (pAlarmQ->m_openAudibleLaneWarnings > 0 )
									{
										pAlarmQ->m_openAudibleLaneWarnings--;							
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower1 = TRUE;
								break;


							case DUALBC_BADBARCODE_LANE1: /* FALL THROUGH */
							case DUALBC_HOLD_SMEMA_LANE1: 
							case BOARD_BACKUP_WARNING:
							case BOARD_ENTRANCE_JAM1:
							case DUALBC_RECMISMATCH_LANE1:
							case DUALBC_BELTSPEEDMISMATCH_LANE1:
							case DUALBC_RAILWIDTHMISMATCH_LANE1:
							case DUALBC_COMPORTFAIL_LANE1:

								if(pAlarmQ->m_bAudibleBoardWarnings[0] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[0] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane1Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;							
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower1 = TRUE;
								break;

							case BOARD_DROP_WARNING_3:
								if( TRUE == g_bLotProcessingEnable )
								{
									g_dbContainer.boardQ2.existingBoardDropID = 0;
								}
								else	//ver8.0.0.15
								{
									g_dbContainer.boardQ2_NoLP.existingBoardDropID = 0;
								}

								if(pAlarmQ->m_bAudibleBoardWarnings[2] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[2] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane1Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;							
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower1 = TRUE;
								break;

							case DUALBC_BADBARCODE_LANE3: /* FALL THROUGH */
							case DUALBC_HOLD_SMEMA_LANE3: 
							case BOARD_BACKUP_WARNING_3:
							case BOARD_ENTRANCE_JAM3:
							case DUALBC_RECMISMATCH_LANE3:
							case DUALBC_BELTSPEEDMISMATCH_LANE3:
							case DUALBC_RAILWIDTHMISMATCH_LANE3:
							case DUALBC_COMPORTFAIL_LANE3:
								if(pAlarmQ->m_bAudibleBoardWarnings[2] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[2] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane1Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;							
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower1 = TRUE;
								break;

							case BOARD_DROP_WARNING_2:
								if( TRUE == g_bLotProcessingEnable )
								{
									g_dbContainer.boardQ1.existingBoardDropID = 0;
								}
								else	//ver8.0.0.15
								{
									g_dbContainer.boardQ1_NoLP.existingBoardDropID = 0;
								}

								if(pAlarmQ->m_bAudibleBoardWarnings[1] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[1] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane2Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower2 = TRUE;
								break;

							case DUALBC_BADBARCODE_LANE2: /* FALL THROUGH */
							case DUALBC_HOLD_SMEMA_LANE2: 
							case BOARD_ENTRANCE_JAM2:
							case BOARD_BACKUP_WARNING_2:
							case DUALBC_RECMISMATCH_LANE2:
							case DUALBC_BELTSPEEDMISMATCH_LANE2:
							case DUALBC_RAILWIDTHMISMATCH_LANE2:
							case DUALBC_COMPORTFAIL_LANE2:
								if(pAlarmQ->m_bAudibleBoardWarnings[1] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[1] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane2Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower2 = TRUE;
								break;

							case BOARD_DROP_WARNING_4:
								if( TRUE == g_bLotProcessingEnable )
								{
									g_dbContainer.boardQ3.existingBoardDropID = 0;
								}
								else	//ver8.0.0.15
								{
									g_dbContainer.boardQ3_NoLP.existingBoardDropID = 0;
								}

								if(pAlarmQ->m_bAudibleBoardWarnings[3] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[3] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane2Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower2 = TRUE;
								break;

							case DUALBC_BADBARCODE_LANE4: //fall through
							case DUALBC_HOLD_SMEMA_LANE4: 
							case BOARD_BACKUP_WARNING_4:
							case BOARD_ENTRANCE_JAM4:
							case DUALBC_RECMISMATCH_LANE4:
							case DUALBC_BELTSPEEDMISMATCH_LANE4:
							case DUALBC_RAILWIDTHMISMATCH_LANE4:
							case DUALBC_COMPORTFAIL_LANE4:
								if(pAlarmQ->m_bAudibleBoardWarnings[3] == TRUE)
								{
									pAlarmQ->m_bAudibleBoardInWarning[3] = FALSE;
								}

								if(pAlarmQ->m_bAudibleLane2Warnings)
								{
									pAlarmQ->boardDropWarning = FALSE;
							
									//pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE;	//2017-08-25, ver8.0.0.21-22
									if(pAlarmQ->m_openAudibleLaneWarnings > 0)
									{
										pAlarmQ->m_openAudibleLaneWarnings--;
									}
								}
								pAlarmQ->boardDropWarningLT = FALSE;
								bLightTower2 = TRUE;
								break;	

							case BARCODE_ERROR_MISMATCH: //fall through
							case BARCODE_HOLD_SMEMA: 
							case BARCODE_RECORD_HOLD:
							case BARCODE_READ_ERROR: 
							case BARCODE_STATUS_ERROR: 
							case BARCODE_APP_TERMINATED: 
							case BARCODE_APP_INIT:
							case BARCODE_TIMEOUT: 
								if(pAlarmQ->m_openBCWarnings > 0)
								{
									pAlarmQ->m_openBCWarnings--;
								}
								break;

							default:
								break;
						}

						if(pAlarmQ->openWarnings < ALARM_WARNING_CNT_MAX)
						{
							pAlarmQ->openWarnings--;
						}
						else
						{
							pAlarmQ->openWarnings = 0;
						}
					
						if ( pAlarmQ->openWarnings == 0 )
						{
							pAlarmQ->m_bAudibleWarningFlag = FALSE;
						}

						if ( bLightTower1 )
						{
							if ( pAlarmQ->openWarnings_lt1 < ALARM_WARNING_CNT_MAX )
							{
								pAlarmQ->openWarnings_lt1--;
							}
							else
							{
								pAlarmQ->openWarnings_lt1 = 0;
							}
						}

						if ( bLightTower2 )
						{
							if ( pAlarmQ->openWarnings_lt2 < ALARM_WARNING_CNT_MAX )
							{
								pAlarmQ->openWarnings_lt2--;
							}
							else
							{
								pAlarmQ->openWarnings_lt2 = 0;
							}
						}

						if ( ( bLightTower1 == FALSE ) && 
							( bLightTower2 == FALSE ) )
						{
							if ( pAlarmQ->openWarnings_common < ALARM_WARNING_CNT_MAX )
							{
								pAlarmQ->openWarnings_common--;
							}
							else
							{
								pAlarmQ->openWarnings_common = 0;
							}
						}
						break;

					default:
						break;
				}
				found = TRUE;
			
				Alarm_alarmAcknowledge(&(pAlarmQ->aq[lcv]));
				(pAlarmQ->alarmCount)--;

			}
		}
	}

	return found;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_addAlarm

			adds an alarm to the queue

 RETURNS:   DWORD alarm position in array
------------------------------------------------------------------------*/
DWORD AlarmQueue_addAlarm(AlarmQueue* pAlarmQ, enum AlarmType aType, UINT messNo, UINT mCode )
{
	BOOL status;
	BOOL storedBoolean;
	BOOL bJobLoading;
	BOOL bLightTower1;
	BOOL bLightTower2;

	BOOL found;
	BOOL bDelayedCooldown;
	BOOL bCurrentMonitorDelayedCooldown;
	BOOL bHeaterFailureDelayedCooldown;
	BOOL bContinue;
	DWORD selfAckCode;
	UINT messNoInput;

	UINT mCodeInput;
	UINT messNoStored;
	UINT mCodeStored;
	UINT returnValue;
	UINT lastAvailable;

	UINT lcv;
	enum AlarmType aTypeInput;
	enum AlarmType aTypeStored;
	DWORD job;

#ifdef DEBUG_addAlarm
	printk("AlarmQueue_addAlarm aType=%d messNo=%d mCode=%d\n", aType, messNo, mCode);
#endif

	status = TRUE;
	storedBoolean = 0;
	bJobLoading = FALSE;
	bLightTower1 = FALSE;
	bLightTower2 = FALSE;

	found = FALSE;
	bDelayedCooldown = FALSE;
	bCurrentMonitorDelayedCooldown = FALSE;
	bHeaterFailureDelayedCooldown = FALSE;
	bContinue = TRUE;
	selfAckCode = 0;
	messNoInput = 0;

	mCodeInput = 0;
	messNoStored = 0;
	mCodeStored = 0;
	returnValue = 0;
	lastAvailable = 0;

	lcv = 0;
	aTypeInput = AVAILABLE;
	aTypeStored = AVAILABLE;
	job = COOLDOWN;

	if(aType == ALARM && pAlarmQ->m_AlarmLight)
	{
		aType = AlarmQueue_AlarmTypeSwitch(pAlarmQ, aType, messNo);

	}

	if(aType != WARNING || 
		( pAlarmQ->m_bVIPMode == FALSE ) )
	{
		messNoInput = messNo;
		mCodeInput = mCode;
		aTypeInput = aType;

		// No ALARMS or WARNINGS can be sent during COOLDOWN. But informational or logged events are OK. exception for energy saving warning
		//adding an exception for estop as estop light tower settings can differ from alarms.  estop should take precendence per Tushar
		job = Oven_getJob(ovenDb);
		if ( job != COOLDOWN || 
			aType ==INFORMATION || 
			aType ==  LOGGED_EVENT ||
			(messNo == EXIT_ENERGY_MODE) ||
			(messNo == COMM_TIMER_LOSS_ALARM && !pAlarmQ->m_bProcessLoopStarted) )
		{

			if ( (pAlarmQ->alarmCount >= MaxAlarms-1) && (aType != ALARM) )
			{
				// no room to add any alarms
				status = FALSE;
				pAlarmQ->aStatus = AS_OVERFLOW;

			}
			else
			{

				for ( lcv = 0; ( ( lcv < MaxAlarms) && ( found == FALSE ) ); lcv++ )
				{
					messNoStored = pAlarmQ->aq[lcv].messageNo;
					mCodeStored = pAlarmQ->aq[lcv].moduleCode;
					aTypeStored = pAlarmQ->aq[lcv].alarmType;
					storedBoolean = pAlarmQ->aq[lcv].acknowledge;
					if ( pAlarmQ->aq[lcv].acknowledge == FALSE ) // alarm has NOT been acknowledged 
					{
						if ( aType == pAlarmQ->aq[lcv].alarmType )
						{
							if ( messNo == pAlarmQ->aq[lcv].messageNo )
							{
								if ( mCode == pAlarmQ->aq[lcv].moduleCode )
								{
									if(messNo==EXIT_ENERGY_MODE)//refire
									{
										pAlarmQ->aq[lcv].read = FALSE;
										pAlarmQ->aq[lcv].notify = FALSE;
									}
									if(messNo==EXIT_ENERGY_MODE)
									{
										pAlarmQ->m_bAudibleEnergySave = TRUE;
									}
									if ( ( messNo == SECSGEM_WARN1 ) &&
										ucLane1Audible)//allow audible on user set warnings if they readd									{
									{
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										ucAudible1Clear = 1;
									}
									if ( ( messNo == SECSGEM_WARN2 ) &&
										ucLane2Audible)//allow audible on user set warnings if they readd									{
									{
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										ucAudible2Clear = 1;
									}
									if ( ( messNo == SECSGEM_WARN3 ) &&
										ucLane3Audible)//allow audible on user set warnings if they readd									{
									{
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										ucAudible3Clear = 1;
									}
									if ( ( messNo == SECSGEM_WARN4 ) &&
										ucLane4Audible)//allow audible on user set warnings if they readd
									{
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										ucAudible4Clear = 1;
									}

									//found = TRUE;	//ver8.0.0.18, Apr-02-2017, comment out to allow multiple boards added
									switch(messNo)
									{
										case BOARD_ADDED:	//ver8.0.0.18, Apr-02-2017, allow multiple boards to add in queue if previous board is not peocesses
										case BOARD_ADDED2:
										case BOARD_ADDED3:
										case BOARD_ADDED4:
										case BOARD_EXITED:
										case BOARD_EXITED2:
										case BOARD_EXITED3:
										case BOARD_EXITED4:
											found = FALSE;
											break;

										default:
											found = TRUE;
											break;
									}
	                                // If the alarm or warning was found and duplicates aren't allowed. 
	                                // Need to return the same alarm ID that was returned before.
	                                // This was causing big problems with the alarm acknowledgement.
	                                // SDY - 08/17/2000
	                                selfAckCode = pAlarmQ->aq[lcv].alarmID;
								}
							}
						}
					}
					else
					{
						lastAvailable = lcv;
					}
				}

	            if ( found == TRUE )
	            {
	                returnValue = selfAckCode;  
					bContinue = FALSE;
	            }
				if(bContinue)
				{
					bJobLoading = Oven_isJobLoadInProgress(ovenDb);
					if ( ((aType == INFORMATION || 
						aType ==  LOGGED_EVENT) || 
						( pAlarmQ->openAlarms == 0 && bJobLoading == FALSE ) ) ||
						( messNo == COMM_TIMER_LOSS_ALARM && !pAlarmQ->m_bProcessLoopStarted ) )  // message not present
					{
						Alarm_setAlarm(&(pAlarmQ->aq[lastAvailable]), aType, messNo, mCode, pAlarmQ->alarmID);
						returnValue = pAlarmQ->alarmID;

						pAlarmQ->alarmCount++;		// the number of alarms and warnings that have not been acknowledged.
						pAlarmQ->alarmID++;			// this will continuously increment until the program is restarted guaranteeing a unique ID 
										// in the array.				

						switch ( aType )
						{
							case ALARM:
								// Whenever an alarm occurs load COOLDOWN.
								// When COOLDOWN is loaded ignore all other alarms, 
								// effectively limiting alarm counts to 1.
								bDelayedCooldown = Oven_getDelayedCooldown(ovenDb);
								bCurrentMonitorDelayedCooldown = Oven_getCurrentMonitorDelayedCooldown(ovenDb);
								bHeaterFailureDelayedCooldown = Oven_getHeaterFailureDelayedCooldown(ovenDb);
								if( (bDelayedCooldown || bCurrentMonitorDelayedCooldown || bHeaterFailureDelayedCooldown) && (messNo != E_STOP_ALARM))
								{
#ifdef DEBUG_CURRENT_MONITOR
									printk("AlarmQueue_addAlarm bDelayedCooldown=%d bCurrentMonitorDelayedCooldown=%d bHeaterFailureDelayedCooldown=%d messNo=%d delaying cooldown\n",
										bDelayedCooldown, bCurrentMonitorDelayedCooldown, bHeaterFailureDelayedCooldown, messNo);
#endif
									Oven_initiateCooldownCountdown(ovenDb, TRUE);
								}
								else
								{
									Oven_setJob(ovenDb, COOLDOWN );
									Oven_setAppFlag(ovenDb, TRUE);
#ifdef DEBUG_CURRENT_MONITOR
									printk("AlarmQueue_addAlarm bDelayedCooldown=%d bCurrentMonitorDelayedCooldown=%d bHeaterFailureDelayedCooldown=%d messNo=%d not delaying cooldown\n", bDelayedCooldown, bCurrentMonitorDelayedCooldown, bHeaterFailureDelayedCooldown, messNo);
#endif
								}
								pAlarmQ->openAlarms++; 
								pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE; //enable audible alarm on every new alarm
								break;
			
							case WARNING:
								switch ( messNo )
								{
									case BELT_HI_DEVIATION_WARNING: //fall through
									case BELT_LO_DEVIATION_WARNING:
										if(pAlarmQ->m_bAudibleBeltWarningsEnabled)
										{
											pAlarmQ->openAudibleWarnings++; //NEED TO FLAG TO ENABLE AUDIBLE ALARM
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;	
										}
										break;
	
									case LOW_EXHAUST_WARNING:
										if(pAlarmQ->m_bAudibleLowExhaustEnabled)
										{
											pAlarmQ->openAudibleWarnings++; //NEED TO FLAG TO ENABLE AUDIBLE ALARM
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
			
										}
										break;
	
									case TZ_HI_DEVIATION_ALARM_SEC:
										if(pAlarmQ->m_bAudibleBeltWarningsEnabled || 
											pAlarmQ->m_bAudibleLowExhaustEnabled ||
											pAlarmQ->m_bAudibleDansensorWarningEnabled)
										{
											pAlarmQ->openAudibleWarnings++; //NEED TO FLAG TO ENABLE AUDIBLE ALARM
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										}
										break;
			
									case SECSGEM_WARN1:
										if(ucLane1Audible)
										{
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
											ucAudible1Clear = 1;
										}
										break;

									case SECSGEM_WARN2:
										if(ucLane2Audible)
										{
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
											ucAudible2Clear = 1;
										}
										break;

									case SECSGEM_WARN3:
										if(ucLane3Audible)
										{
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
											ucAudible3Clear = 1;
										}
										break;

									case SECSGEM_WARN4:
										if(ucLane4Audible)
										{
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
											ucAudible4Clear = 1;
										}
										break;
				
									case PPM_EXCEEDS_ALARM1_WARNING://fall through
									case ALARM2_EXCEEDS_PPM_WARNING:
									case PPM_EXCEEDS_ALARM2_WARNING:
									case DANSENSOR_CONNECTION_BROKEN:
									case DANSENSOR_NOT_CONNECTIONED:
									case DANSENSOR_STOPPED:
										if(pAlarmQ->m_bAudibleDansensorWarningEnabled)
										{
											pAlarmQ->openAudibleWarnings++; //NEED TO FLAG TO ENABLE AUDIBLE ALARM
											pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;											
										}
										break;
	
									case DUALBC_BADBARCODE_LANE1: //fall through
									case BOARD_DROP_WARNING:
									case BOARD_BACKUP_WARNING:
									case BOARD_ENTRANCE_JAM1:
									case DUALBC_RECMISMATCH_LANE1:
									case DUALBC_BELTSPEEDMISMATCH_LANE1:
									case DUALBC_RAILWIDTHMISMATCH_LANE1:
									case DUALBC_COMPORTFAIL_LANE1:
									case DUALBC_HOLD_SMEMA_LANE1: 
	
										if( pAlarmQ->m_bAudibleBoardWarnings[0] == TRUE )
										{
											pAlarmQ->m_bAudibleBoardInWarning[0] = TRUE;
										}
	
										if( pAlarmQ->m_bAudibleLane1Warnings )
										{
											pAlarmQ->m_openAudibleLaneWarnings++;
										}
	
										pAlarmQ->boardDropWarning = TRUE;
										
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										pAlarmQ->boardDropWarningLT = TRUE;
	
										bLightTower1 = TRUE;
										
										break;
	
									case DUALBC_HOLD_SMEMA_LANE3: //fall through 
									case DUALBC_BADBARCODE_LANE3:
									case BOARD_DROP_WARNING_3:
									case BOARD_BACKUP_WARNING_3:
									case BOARD_ENTRANCE_JAM3:
									case DUALBC_RECMISMATCH_LANE3:
									case DUALBC_BELTSPEEDMISMATCH_LANE3:
									case DUALBC_RAILWIDTHMISMATCH_LANE3:
									case DUALBC_COMPORTFAIL_LANE3:
										if(pAlarmQ->m_bAudibleBoardWarnings[2] == TRUE)
										{
											pAlarmQ->m_bAudibleBoardInWarning[2] = TRUE;
										}
	
										if(pAlarmQ->m_bAudibleLane1Warnings)
										{
											pAlarmQ->m_openAudibleLaneWarnings++;
										}
										pAlarmQ->boardDropWarning = TRUE;
										
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										pAlarmQ->boardDropWarningLT = TRUE;
	
										bLightTower1 = TRUE;
										
										break;
	
									case DUALBC_BADBARCODE_LANE2: //fall through
									case DUALBC_HOLD_SMEMA_LANE2: 
									case BOARD_DROP_WARNING_2:
									case BOARD_ENTRANCE_JAM2:
									case BOARD_BACKUP_WARNING_2:
									case DUALBC_RECMISMATCH_LANE2:
									case DUALBC_BELTSPEEDMISMATCH_LANE2:
									case DUALBC_RAILWIDTHMISMATCH_LANE2:
									case DUALBC_COMPORTFAIL_LANE2:
										if(pAlarmQ->m_bAudibleBoardWarnings[1] == TRUE)
										{
											pAlarmQ->m_bAudibleBoardInWarning[1] = TRUE;
										}
	
										if(pAlarmQ->m_bAudibleLane2Warnings)
										{
											pAlarmQ->m_openAudibleLaneWarnings++;
										}
	
										pAlarmQ->boardDropWarning = TRUE;
										
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										pAlarmQ->boardDropWarningLT = TRUE;
	
										bLightTower2 = TRUE;
										
										break; // Just to flash the red light in a non alarm condition
	
									case DUALBC_BADBARCODE_LANE4: //fall through
									case DUALBC_HOLD_SMEMA_LANE4: 
									case BOARD_DROP_WARNING_4:
									case BOARD_BACKUP_WARNING_4:
									case BOARD_ENTRANCE_JAM4:
									case DUALBC_RECMISMATCH_LANE4:
									case DUALBC_BELTSPEEDMISMATCH_LANE4:
									case DUALBC_RAILWIDTHMISMATCH_LANE4:
									case DUALBC_COMPORTFAIL_LANE4:
										if( pAlarmQ->m_bAudibleBoardWarnings[3] == TRUE )
										{
											pAlarmQ->m_bAudibleBoardInWarning[3] = TRUE;
										}
	
										if( pAlarmQ->m_bAudibleLane2Warnings )
										{
											pAlarmQ->m_openAudibleLaneWarnings++;
										}
	
										pAlarmQ->boardDropWarning = TRUE;
										
										pAlarmQ->m_bAlarmsTriggerAudibleEvent = TRUE;
										pAlarmQ->boardDropWarningLT = TRUE;
	
										bLightTower2 = TRUE;
										
										break; // Just to flash the red light in a non alarm condition
	
									case BARCODE_ERROR_MISMATCH: //fall through
									case BARCODE_HOLD_SMEMA:
									case BARCODE_RECORD_HOLD:
									case BARCODE_READ_ERROR:
									case BARCODE_STATUS_ERROR:
									case BARCODE_APP_TERMINATED:
									case BARCODE_APP_INIT:
									case BARCODE_TIMEOUT:
										pAlarmQ->m_openBCWarnings++;
										break;
	
									case CA3_WARNING:
										pAlarmQ->m_bCA3InWarning = TRUE;
										pAlarmQ->m_bCA3Output = TRUE;
										break;
	
									case CA4_WARNING:
										pAlarmQ->m_bCA4InWarning = TRUE;
										pAlarmQ->m_bCA4Output = TRUE;
										break;
	
									case CA5_WARNING:
										pAlarmQ->m_bCA5InWarning = TRUE;
										pAlarmQ->m_bCA5Output = TRUE;
										break;
	
									case EXIT_ENERGY_MODE:
										pAlarmQ->m_bAudibleEnergySave = TRUE;
										break;
	
									case HEAT_FAN_FAULT_WARN_CODE:
										if ( ovenDb->m_bAudibleBlowFail )
										{
											pAlarmQ->m_bBlowerInWarning = TRUE;
										}
										break;
							
									default:
										break;
								}

								pAlarmQ->openWarnings++;

								if ( bLightTower1 )
								{
									pAlarmQ->openWarnings_lt1++;
								}

								if ( bLightTower2 )
								{
									pAlarmQ->openWarnings_lt2++;
								}

								if ( (bLightTower1 == FALSE) && 
									(bLightTower2 == FALSE) )
								{
									pAlarmQ->openWarnings_common++;
								}

								pAlarmQ->m_bAudibleWarningFlag = TRUE;
								break;
							default:
								break;
						}
					}
				}
			}
		}
	}


	return ( returnValue );	
}

BOOL AlarmQueue_getAlarmMessage(AlarmQueue* pAlarmQ, UINT messageIndex, TransferAlarmData* pAlarmData, BOOL win_hdac )
{
	BOOL status;

	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getAlarmMessage", FALSE);
	PARAM_CHECK_RETURN( pAlarmData, "AlarmQueue_getAlarmMessage", FALSE);

	if ( pAlarmQ->delayFor10seconds )
	{
		pAlarmQ->currentTime = Timer_getCurrentTime10ths(elapseTimerDb);
		if ( differenceWithRollover( pAlarmQ->currentTime, pAlarmQ->startTime )>100 )
		{
			pAlarmQ->delayFor10seconds = FALSE;
		}
	}
	else
	{
		Alarm_getAlarm(&(pAlarmQ->aq[messageIndex]), pAlarmData, win_hdac);	//ver8.0.0.18, Apr-02-2017, added to else condition, used to be by itself without else
	}

	

	// If the data has not been read by the windows application, indicated by read == FALSE
	// return TRUE to the application for processing. FALSE if it has already been read.
//	status = TRUE; 
	//DEBUG - We are going to let Windows decide whether or not it has already processed
	//this alarm.
#if 1
	if(win_hdac)
	{
		if ( pAlarmData->read == FALSE && pAlarmQ->delayFor10seconds == FALSE)
		{
			status = TRUE;	
		}
		else
		{
			status = FALSE;
		}
	}
	else	
	{
		if ( pAlarmData->notify == FALSE && pAlarmQ->delayFor10seconds == FALSE)
		{
			status = TRUE;	
		}
		else
		{
			status = FALSE;
		}
	}
#endif

	return status;
}

void AlarmQueue_clearReadFlagAll(AlarmQueue* pAlarmQ)
{
	UINT lcv;
	PARAM_CHECK( pAlarmQ, "AlarmQueue_clearReadFlagAll");

	for( lcv = 0; lcv< MaxAlarms; lcv++ )
	{
		if ( pAlarmQ->aq[lcv].acknowledge == FALSE ) // make sure alarm has NOT been acknowledged 
		{
			pAlarmQ->aq[lcv].read = FALSE;			// The application needs to know it has not been read for rereading.
			pAlarmQ->aq[lcv].notify = FALSE;
		}
	}
	pAlarmQ->delayFor10seconds = TRUE;
	pAlarmQ->startTime = Timer_getCurrentTime10ths(elapseTimerDb);

//	printk( "AlarmQueue_clearReadFlagAll()\n" );
}
			
BOOL AlarmQueue_findAcknowledgedAlarm(AlarmQueue* pAlarmQ, DWORD alarmIDsearch )
{
	UINT lcv;
	BOOL found = FALSE;
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_findAcknowledgedAlarm", FALSE);

    for ( lcv = 0; lcv < MaxAlarms; lcv++ )
    {
        if ( pAlarmQ->aq[lcv].alarmID == alarmIDsearch && pAlarmQ->aq[lcv].acknowledge == TRUE )
        {
            found = TRUE;
        }
    }
    return found;
}

//******************************************************************************
// AlarmQueue::AlarmTypeSwitch
//
// Abstract:
// 	All alarms trigger cooldown mode in a 2 phase approach.  This routine will be called
// in the alarm queue to switch from alarm to warning when the temperature zone alarms are
// deactivated.  This could be done on each addAlarm, but the logic has mutated so it is more
// expiditious to do it in the queue object.
//
//
// Programmer: Wallace Tree
// Date: 10/23/2002
//
// History:
//******************************************************************************

enum AlarmType AlarmQueue_AlarmTypeSwitch(AlarmQueue* pAlarmQ, enum AlarmType baseAlarmType, UINT messageNumber)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_AlarmTypeSwitch", 0);

	switch(messageNumber)
	{
	case HEAT_FAN_FAULT_ALARM_CODE:
//	case TZ_RISERATE_ALARM:
//	case TZ_LO_PROCESS_ALARM:
//	case TZ_HI_PROCESS_ALARM:
	case TZ_LO_DEVIATION_ALARM:
	case TZ_HI_DEVIATION_ALARM:
	case SECONDARY_BOARD_OUT:
//	case TZ_LO_PROCESS_ALARM_SEC:
//	case TZ_HI_PROCESS_ALARM_SEC:
	case TZ_LO_DEVIATION_ALARM_SEC:
	case TZ_HI_DEVIATION_ALARM_SEC:
//	case FLUXHEATER_RISERATE_ALARM:
//	case FLUXHEATER_LO_PROCESS_ALARM:
//	case FLUXHEATER_HI_PROCESS_ALARM:
	case FLUXHEATER_LO_DEVIATION_ALARM:
	case FLUXHEATER_HI_DEVIATION_ALARM:
		if(baseAlarmType == ALARM)
		{
			return WARNING;
		}
		break;
	}
	return baseAlarmType;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	AlarmQueue_resetAudibleSounding

				
				clears audible output, but not warning

	RETURNS:   void
------------------------------------------------------------------------*/
void AlarmQueue_resetAudibleSounding(AlarmQueue* pAlarmQ)
{

	if(pAlarmQ)
	{
		pAlarmQ->m_bAlarmsTriggerAudibleEvent = FALSE; //Prevent the alarms from producing audible events
		pAlarmQ->openAudibleWarnings = 0;  //current audible warnings cleared, base warning still present
		pAlarmQ->m_openBCWarnings = 0;
		pAlarmQ->m_openAudibleLaneWarnings=0;
		pAlarmQ->m_bAudibleWarningFlag = FALSE;  //beyond the existing audible warnings a new feature for all warnings to sound main
		//alarm has been added, to minimize bugs and allow the existing features to function I have used a new varible
		Purge_suppressAudibleEvent();
		pAlarmQ->m_bAudibleEnergySave=FALSE;
		pAlarmQ->m_bCA3InWarning = FALSE;
		pAlarmQ->m_bCA4InWarning = FALSE;
		pAlarmQ->m_bCA5InWarning = FALSE;
		pAlarmQ->m_bBlowerInWarning = FALSE;

		ucAudible1Clear = 0;
		ucAudible2Clear = 0;
		ucAudible3Clear = 0;
		ucAudible4Clear = 0;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_returnInAudibleCondition

			used by light tower and xpdriverdevice

 RETURNS:   UINT 0 not audible, 1 alarm audible, 2 warning audible
------------------------------------------------------------------------*/
UINT AlarmQueue_returnInAudibleCondition(AlarmQueue* pAlarmQ)
{
	UINT iReturn;
	BOOL bAudible;
	UINT uiAud;

	uiAud = 0;	
	bAudible = FALSE;
	iReturn = ALARMCONDITION_NONE;

#ifdef DEBUG_AUDIBLEWARNING
	static DWORD lastTime1 = 0;
	DWORD currentTime1 = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
#endif

	if(pAlarmQ)
	{
		if(pAlarmQ->m_bBlowerInWarning)
		{
			iReturn = ALARMCONDITION_SPECIAL;
		}

		bAudible = Purge_inAudibleCondition(purgeControl);
		if ( bAudible )
		{
			// Purge takes higher precendence over other alarm/warning setting.
			// User settable audible warnings.
			iReturn = ALARMCONDITION_NORMAL;
		}
		else
		{
			if ( pAlarmQ->m_bAudibleBCWarnings && pAlarmQ->m_openBCWarnings )
			{
				// User settable audible warnings.
				iReturn = ALARMCONDITION_NORMAL;
			}
			uiAud = AlarmQueue_audibleWarningsPresent(pAlarmQ);

#ifdef DEBUG_AUDIBLEWARNING
	if (currentTime1 - lastTime1 >= 10)
	{
		lastTime1 = currentTime1;
		printk("AlarmQueue_returnInAudibleCondition(), uiAud=%d\n", uiAud);
	}
#endif
			if ( uiAud )
			{	
				iReturn = ALARMCONDITION_NORMAL;

#ifdef DEBUG_AUDIBLEWARNING
	if (currentTime1 - lastTime1 >= 10)
	{
		//lastTime1 = currentTime1;
		printk("AlarmQueue_returnInAudibleCondition(), iReturn=%d\n", iReturn);
	}
#endif
			}
			else if ( pAlarmQ->m_bAlarmsTriggerAudibleEvent && 
				AlarmQueue_alarmsPresent(pAlarmQ) == TRUE )
			{
				iReturn = ALARMCONDITION_NORMAL;
			}
			else if ( pAlarmQ->m_bAudibleWarningFlag )
			{
				if ( pAlarmQ->m_bOKForAudibleWarnings && 
					pAlarmQ->m_bAudibleWarnings )
				{
					// toggled by tempzones during powerup sequencing.
					iReturn = ALARMCONDITION_NORMAL;
				}
			}
			else
			{
				if ( pAlarmQ->m_bAlarmsTriggerAudibleEvent )
				{
					if ( pAlarmQ->m_bAudibleBeltWarningsEnabled ||
						pAlarmQ->m_bAudibleLowExhaustEnabled ||
						pAlarmQ->m_bAudibleDansensorWarningEnabled )
					{
						if ( pAlarmQ->openAudibleWarnings )
						{
							// User settable audible warnings.
							iReturn = ALARMCONDITION_SPECIAL;
						}
					}
				}
			}
		}
	}
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_audibleUserWarningsPresent
			
			are audible warnings present

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL AlarmQueue_audibleUserWarningsPresent(AlarmQueue* pAlarmQ)
{

	BOOL bReturn;
	BOOL bPurge;

	bReturn = FALSE;
	bPurge = FALSE;
	if ( pAlarmQ->m_bAudibleBCWarnings && 
		pAlarmQ->m_openBCWarnings )
	{
		// User settable audible warnings.
		bReturn = TRUE;
	}
	if( pAlarmQ->m_bAudibleLane1Warnings==1 || pAlarmQ->m_bAudibleLane2Warnings==1 ) 
	{
		if ( pAlarmQ->m_openAudibleLaneWarnings != 0 )
		{
			bReturn = TRUE;
		}
	}

	bPurge = Purge_inAudibleCondition(purgeControl);
	if ( bPurge )
	{
		bReturn = TRUE;
	}

	if(pAlarmQ->m_bAudibleCA3==TRUE && pAlarmQ->m_bCA3InWarning==TRUE)
	{
		bReturn = TRUE;
	}

	if(pAlarmQ->m_bAudibleCA4==TRUE && pAlarmQ->m_bCA4InWarning==TRUE)
	{
		bReturn = TRUE;
	}

	if(pAlarmQ->m_bAudibleCA5==TRUE && pAlarmQ->m_bCA5InWarning==TRUE)
	{
		bReturn = TRUE;
	}

	if ( pAlarmQ->m_bAudibleWarningFlag )
	{
		if ( pAlarmQ->m_bOKForAudibleWarnings && 
			pAlarmQ->m_bAudibleWarnings )
		{
			bReturn = TRUE;
		}
	}
	
	if ( pAlarmQ->m_bAlarmsTriggerAudibleEvent )
	{
		if ( pAlarmQ->m_bAudibleBeltWarningsEnabled ||
			pAlarmQ->m_bAudibleLowExhaustEnabled ||
			pAlarmQ->m_bAudibleDansensorWarningEnabled )
		{
			if ( pAlarmQ->openAudibleWarnings )
			{
				// User settable audible warnings.
				bReturn = TRUE;
			}
		}
	}
	if( (ucLane1Audible && ucAudible1Clear ) ||
		(ucLane2Audible && ucAudible2Clear ) ||
		(ucLane3Audible && ucAudible3Clear ) ||
		(ucLane4Audible && ucAudible4Clear ) )
	{
		bReturn = TRUE;
	}
	return bReturn;
}

void AlarmQueue_setProcessLoopStarted(AlarmQueue* pAlarmQ, BOOL bStarted)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setProcessLoopStarted");
	pAlarmQ->m_bProcessLoopStarted = bStarted;
}

BOOL AlarmQueue_getProcessLoopStarted(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getProcessLoopStarted", FALSE);
	return pAlarmQ->m_bProcessLoopStarted;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
//void AlarmQueue_enableAudibleWarnings()
//
//We cannot allow audible warnings until one of the following has occurred:
//
//1  The first startup sequence has expired
//2  The initial startup sequence is terminated (cooldown load)
//8/20/9 after discussion with Tushar we are not sure why we have this delay.  removing as
//33 startup groups really delays the audible warning by too much and he did not want to pick
//an arbitrary delay
void AlarmQueue_enableAudibleWarnings(AlarmQueue* pAlarmQ, BOOL bEnable)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_enableAudibleWarnings");
	pAlarmQ->m_bOKForAudibleWarnings = bEnable;
	
	//printk( "AlarmQueue_enableAudibleWarnings(%d)\n", bEnable );
}

void AlarmQueue_setAudibleWarnings(AlarmQueue* pAlarmQ, BOOL bOn)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setAudibleWarnings");
	pAlarmQ->m_bAudibleWarnings = bOn; 
}

void AlarmQueue_setAudibleBCWarnings(AlarmQueue* pAlarmQ, BOOL bOn)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setAudibleBCWarnings");
	pAlarmQ->m_bAudibleBCWarnings = bOn; 
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_clearAllWarnings
			
			clears all the warnings

 RETURNS:   void
------------------------------------------------------------------------*/
void AlarmQueue_clearAllWarnings(AlarmQueue* pAlarmQ)
{
	UINT lcv;

	lcv = 0;

	if( NULL != pAlarmQ )
	{
		for( lcv = 0; lcv< MaxAlarms; lcv++ )
		{
			if ( pAlarmQ->aq[lcv].acknowledge == FALSE && pAlarmQ->aq[lcv].alarmType == WARNING ) // make sure alarm has NOT been acknowledged and is type appropriate
			{
				if( TRUE == g_bLotProcessingEnable )
				{
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING)//ugly callback, but the queue needs to know if it should warn or just log
					{
						g_dbContainer.boardQ0.existingBoardDropID=0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_2)//ugly callback, but the queue needs to know if it should warn or just log
					{
						g_dbContainer.boardQ1.existingBoardDropID=0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_3)//ugly callback, but the queue needs to know if it should warn or just log
					{
						g_dbContainer.boardQ2.existingBoardDropID=0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_4)//ugly callback, but the queue needs to know if it should warn or just log
					{
						g_dbContainer.boardQ3.existingBoardDropID=0;
					}
				}
				else	//ver8.0.0.15 TESTONLY
				{
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING)
					{
						g_dbContainer.boardQ0_NoLP.existingBoardDropID = 0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_2)
					{
						g_dbContainer.boardQ1_NoLP.existingBoardDropID=0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_3)
					{
						g_dbContainer.boardQ2_NoLP.existingBoardDropID=0;
					}
					if(pAlarmQ->aq[lcv].messageNo==BOARD_DROP_WARNING_4)
					{
						g_dbContainer.boardQ3_NoLP.existingBoardDropID=0;
					}
				}

				pAlarmQ->aq[lcv].read = TRUE;
				pAlarmQ->aq[lcv].acknowledge = TRUE;
				pAlarmQ->aq[lcv].alarmID = 0;
				pAlarmQ->aq[lcv].alarmType = AVAILABLE;
				pAlarmQ->aq[lcv].messageNo = 0;
				pAlarmQ->aq[lcv].moduleCode = 0;
				if(pAlarmQ->alarmCount > 0)
				{
					pAlarmQ->alarmCount--;
				}
			}
		}

		pAlarmQ->openWarnings = 0;
		pAlarmQ->openWarnings_lt1 = 0;
		pAlarmQ->openWarnings_lt2 = 0;
		pAlarmQ->openWarnings_common = 0;
		pAlarmQ->m_bAudibleWarningFlag = FALSE;
		pAlarmQ->m_bBlowerInWarning = FALSE;

		pAlarmQ->m_bCA3InWarning=FALSE;
		pAlarmQ->m_bCA4InWarning=FALSE;
		pAlarmQ->m_bCA5InWarning=FALSE;
		pAlarmQ->m_bCA3Output=FALSE;
		pAlarmQ->m_bCA4Output=FALSE;
		pAlarmQ->m_bCA5Output=FALSE;
		pAlarmQ->openAudibleWarnings = 0;
		pAlarmQ->m_openBCWarnings = 0;
		pAlarmQ->m_openAudibleLaneWarnings = 0;
		pAlarmQ->m_bAudibleEnergySave = FALSE;
 		for(lcv = 0; lcv < MAX_SMEMA_LANES; lcv++)
		{
			if(pAlarmQ->m_bAudibleBoardWarnings[lcv] == TRUE)
			{
				pAlarmQ->m_bAudibleBoardInWarning[lcv] = FALSE;
			}
		}
	}
	ucAudible1Clear = 0;
	ucAudible2Clear = 0;
	ucAudible3Clear = 0;
	ucAudible4Clear = 0;
	return;
}

BOOL AlarmQueue_alarmsPresent(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_alarmsPresent", FALSE);
	return (pAlarmQ->openAlarms >=1) ? TRUE : FALSE;
}


BOOL AlarmQueue_warningsPresent(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_warningsPresent", FALSE);
	return (pAlarmQ->openWarnings>=1) ? TRUE : FALSE;
}

BOOL AlarmQueue_warningsPresent_lt1(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_warningsPresent", FALSE);
	return (pAlarmQ->openWarnings_lt1 >= 1) ? TRUE : FALSE;
}

BOOL AlarmQueue_warningsPresent_lt2(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_warningsPresent", FALSE);
	return (pAlarmQ->openWarnings_lt2 >= 1) ? TRUE : FALSE;
}

BOOL AlarmQueue_warningsPresent_common(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_warningsPresent", FALSE);
	return (pAlarmQ->openWarnings_common >= 1) ? TRUE : FALSE;
}

const char* AlarmQueue_getName(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getName", FALSE);
	return pAlarmQ->name;
}


BOOL AlarmQueue_getBoardDropStatus(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getBoardDropStatus", FALSE);
	return pAlarmQ->boardDropWarning;
}

void AlarmQueue_setCooldownPreference(AlarmQueue* pAlarmQ, BOOL bAlarmLight)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setCooldownPreference");
	pAlarmQ->m_AlarmLight = bAlarmLight;
}

BOOL AlarmQueue_getCooldownPreference(AlarmQueue* pAlarmQ)
{
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getCooldownPreference", FALSE);
	return pAlarmQ->m_AlarmLight;
}

void AlarmQueue_setLaneWarnings(AlarmQueue* pAlarmQ, BOOL bWarning, UINT uIndex)
{
//	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_setLaneWarnings", FALSE);
	switch(uIndex)
	{	
	case 0:
		pAlarmQ->m_bAudibleLane1Warnings = bWarning;
		break;
		
	default:
		pAlarmQ->m_bAudibleLane2Warnings = bWarning; 	
		break;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_clearLoggedEvents


 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AlarmQueue_clearLoggedEvents(AlarmQueue* pAlarmQ)
{
	UINT lcv;
	PARAM_CHECK( pAlarmQ, "AlarmQueue_clearLoggedEvents");
	
	for ( lcv = 0; lcv < MaxAlarms; lcv++ )
	{
		if(pAlarmQ->aq[lcv].alarmType == LOGGED_EVENT)
		{
			pAlarmQ->aq[lcv].read = TRUE;
			pAlarmQ->aq[lcv].acknowledge = TRUE;
			pAlarmQ->aq[lcv].alarmID = 0;
			pAlarmQ->aq[lcv].alarmType = AVAILABLE;
			pAlarmQ->aq[lcv].messageNo = 0;
			pAlarmQ->aq[lcv].moduleCode = 0;
		}
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_getBoardDropStatusLightTower


 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL AlarmQueue_getBoardDropStatusLightTower(AlarmQueue* pAlarmQ)
{	
	PARAM_CHECK_RETURN( pAlarmQ, "AlarmQueue_getBoardDropStatusLightTower",0);
	return pAlarmQ->boardDropWarningLT; 
}




void AlarmQueue_setVIPMode(AlarmQueue* pAlarmQ, BOOL bOn)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setVIPMode");
	pAlarmQ->m_bVIPMode = bOn;
}

void AlarmQueue_setAWOutput(AlarmQueue* pAlarmQ, DWORD dwrdOutput)
{
	PARAM_CHECK( pAlarmQ, "AlarmQueue_setAWOutput");
	pAlarmQ->m_dwrdOutput = dwrdOutput;
}

///////////////////////
//alarms will set the alarm output, warnings with no alarms will set a varying output
//(maybe, depending on setup wizard configuration
UINT AlarmQueue_getAlarmOutput(AlarmQueue* pAlarmQ)
{
	UINT iReturn=ODO_AUDIBLE_ALARM;
	if(pAlarmQ->m_bAlarmsTriggerAudibleEvent && AlarmQueue_alarmsPresent(pAlarmQ) == TRUE)
	{
	}
	else
	{
		if(pAlarmQ->m_dwrdOutput!=ODO_NULL)
			iReturn=pAlarmQ->m_dwrdOutput;
	}
	return iReturn;
}

BOOL AlarmQueue_hasEStopAlarm(AlarmQueue* pAlarmQ)
{
	BOOL bHasEstop = FALSE;

	UINT lcv;
	for( lcv = 0; (lcv < MaxAlarms) && (bHasEstop == FALSE); lcv++ )
	{
		if ( (pAlarmQ->aq[lcv].messageNo == E_STOP_ALARM) && 
			(pAlarmQ->aq[lcv].acknowledge == FALSE) )
		{
			bHasEstop = TRUE;
		}
	}

	return bHasEstop;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_findOpenWarning

			returns 0 if warning not in queue or not open
			otherwise it returns the alarm id
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD AlarmQueue_findOpenWarning(AlarmQueue* pAlarmQ, UINT messNo)
{
	UINT messNoStored;
	UINT mCodeStored;
	enum AlarmType aTypeStored;
	DWORD dwrdRet = 0;
	int lcv = 0;
	BOOL found = FALSE;
	for ( lcv = 0; lcv < MaxAlarms && found == FALSE; lcv++ )
	{
		messNoStored = pAlarmQ->aq[lcv].messageNo;
		mCodeStored = pAlarmQ->aq[lcv].moduleCode;
		aTypeStored = pAlarmQ->aq[lcv].alarmType;
		if ( pAlarmQ->aq[lcv].acknowledge == FALSE ) // alarm has NOT been acknowledged 
		{
			if ( WARNING == pAlarmQ->aq[lcv].alarmType )
			{
				if ( messNo == pAlarmQ->aq[lcv].messageNo )
				{
					found = TRUE;
					dwrdRet = pAlarmQ->aq[lcv].alarmID;
				}
			}
		}
	}
	return dwrdRet;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_getQueuePosition

			returns the position of the queue based on an alarm id for non acked
			alarms.  This is useful so the CA3 does not need to iterate through
			the entire list to find out if the alarm is acked.  Could be extended
			for other alarms with custom behavior

			RETURNS:   signed int
------------------------------------------------------------------------*/
signed int AlarmQueue_getQueuePosition(AlarmQueue* pAlarmQ, DWORD alarmIDsearch)
{
	BOOL found;
	UINT lcv;
	signed int iReturn;

	iReturn = -1;
	found = FALSE;
	lcv = 0;
	
	if( NULL != pAlarmQ )
	{
		for( lcv = 0; (lcv< MaxAlarms) && (iReturn == -1); lcv++ )
		{


			if ( pAlarmQ->aq[lcv].alarmID == alarmIDsearch && 
				pAlarmQ->aq[lcv].acknowledge == FALSE )
			{
				iReturn = lcv;
			}
		}
	}
	return iReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_EventActive

			searches queue for unacked event

 RETURNS:   true if found, false if not
------------------------------------------------------------------------*/
BOOL AlarmQueue_EventActive(AlarmQueue* pAlarmQ, UINT messNo, UINT mCode )
{
	BOOL found;
	UINT lcv;

	found = FALSE;
	lcv = 0;

	if(pAlarmQ)
	{
		for ( lcv = 0; ( ( lcv < MaxAlarms) && ( found == FALSE ) ); lcv++ )
		{
			if ( pAlarmQ->aq[lcv].acknowledge == FALSE ) // alarm has NOT been acknowledged 
			{
				if ( messNo == pAlarmQ->aq[lcv].messageNo )
				{
					if ( mCode == pAlarmQ->aq[lcv].moduleCode )
					{
						found = TRUE;
					}
				}
			}
		}
	}
	return ( found );	
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AlarmQueue_SecsgemLightTower

			searches queue for unacked event

 RETURNS:	WARNING_TYPE_ALL_AUDIBLE 13
			WARNING_TYPE_SECSGEM_BOTH_RED_AUDIBLE 12 
			WARNING_TYPE_SECSGEM_BOTH_YELLOW_AUDIBLE 11 
			WARNING_TYPE_SECSGEM_BOTH_AUDIBLE 10 
			WARNING_TYPE_SECSGEM_RED_AUDIBLE 9 
			WARNING_TYPE_SECSGEM_YELLOW_AUDIBLE 8
			WARNING_TYPE_ALL 7
			WARNING_TYPE_SECSGEM_RED 6
			WARNING_TYPE_SECSGEM_BOTH_YELLOW 5
			WARNING_TYPE_SECSGEM_BOTH 4
			WARNING_TYPE_SECSGEM_RED 3
			WARNING_TYPE_SECSGEM_YELLOW 2
			WARNING_TYPE_STANDARD 1
------------------------------------------------------------------------*/
unsigned char AlarmQueue_SecsgemLightTower()
{
	DWORD dwrdSearch;
	unsigned char cAudible;
	unsigned char cReturn;
	unsigned char cRedWarning;
	unsigned char cYellowWarning;
	unsigned char cCount;
	unsigned char cStandardWarning;

	cStandardWarning = 0;
	cReturn = 0;
	cAudible = 0;
	cRedWarning = 0;
	cYellowWarning = 0;
	cCount = 0;
	dwrdSearch = 0;

	if(g_dbContainer.alarmQueueDb.openWarnings > 0)
	{
		dwrdSearch = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), SECSGEM_WARN1);
	
		if(dwrdSearch > 0)
		{
			cCount++;
			if(ucLane1Secsgem)
			{
				cRedWarning = 1;
			}
			else
			{
				cYellowWarning = 1;
			}
			if(ucLane1Audible && ucAudible1Clear)
			{
				cAudible = 1;
			}
		}
		dwrdSearch = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), SECSGEM_WARN2);
		if(dwrdSearch > 0)
		{
			cCount++;
			if(ucLane2Secsgem)
			{
				cRedWarning = 1;
			}
			else
			{
				cYellowWarning = 1;
			}
			if(ucLane2Audible && ucAudible2Clear)
			{
				cAudible = 1;
			}
		}
		dwrdSearch = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), SECSGEM_WARN3);
		if(dwrdSearch > 0)
		{
			cCount++;
			if(ucLane3Secsgem)
			{
				cRedWarning = 1;
			}
			else
			{
				cYellowWarning = 1;
			}
			if(ucLane3Audible && ucAudible3Clear)
			{
				cAudible = 1;
			}
		}
		dwrdSearch = AlarmQueue_findOpenWarning(&(g_dbContainer.alarmQueueDb), SECSGEM_WARN4);
		if(dwrdSearch > 0)
		{
			cCount++;
			if(ucLane4Secsgem)
			{
				cRedWarning = 1;
			}
			else
			{
				cYellowWarning = 1;
			}
			if(ucLane4Audible && ucAudible4Clear)
			{
				cAudible = 1;
			}

		}

		if(cCount < g_dbContainer.alarmQueueDb.openWarnings)
		{
			cStandardWarning = 1;
		}

		if(cStandardWarning && 
			cYellowWarning && 
			cRedWarning)
		{
			cReturn = WARNING_TYPE_ALL;
		}
		else if(cYellowWarning && cRedWarning)
		{
			cReturn = WARNING_TYPE_SECSGEM_BOTH;
		}
		else if(cStandardWarning && cRedWarning)
		{
			cReturn = WARNING_TYPE_SECSGEM_BOTH_RED;
		}
		else if(cStandardWarning && cYellowWarning)
		{
			cReturn = WARNING_TYPE_SECSGEM_BOTH_YELLOW;
		}
		else if (cRedWarning)
		{
			cReturn = WARNING_TYPE_SECSGEM_RED;
		}
		else if (cYellowWarning)
		{
			cReturn = WARNING_TYPE_SECSGEM_YELLOW;
		}
		else // all that is left is normal state
		{
			cReturn = WARNING_TYPE_STANDARD;
		}
		if(cAudible)
		{
			cReturn = cReturn + WARNING_TYPE_AUDILE_OFFSET;
		}
	}


	return cReturn;
}


