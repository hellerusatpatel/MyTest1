/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "flasher.h"

void Flasher_init(Flasher* pFlasher, enum Light_States color, BOOL bFlasherEnable, BOOL bAudibleAlarm)
{
	PARAM_CHECK( pFlasher, "Flasher_init");

	pFlasher->cycleCount = 0;

	pFlasher->flasherColor = color;
	pFlasher->state = Flasher_ON;

	pFlasher->m_bAudibleAlarm = bAudibleAlarm;

	pFlasher->m_bFlasherEnabled = bFlasherEnable;
}

void Flasher_process(Flasher* pFlasher)
{
	PARAM_CHECK( pFlasher, "Flasher_process");

	BOOL bNewState = pFlasher->state;

	pFlasher->cycleCount++;

	if ( pFlasher->m_bFlasherEnabled )
	{
		if ( pFlasher->cycleCount >= 10 )
		{
			if ( pFlasher->state == Flasher_ON )
			{
				bNewState = Flasher_OFF;
			}
			else
			{
				bNewState = Flasher_ON;
			}
		}
	}
	else
	{
		bNewState = Flasher_ON;
	}

	pFlasher->state = bNewState;

	if ( pFlasher->cycleCount >= 10  )
	{
		pFlasher->cycleCount = 0;
	}
}
   
BOOL Flasher_getFlashState(Flasher* pFlasher )
{
	PARAM_CHECK_RETURN( pFlasher, "Flasher_getFlashState", FALSE);
	return pFlasher->state;
}

void Flasher_enableFlasher(Flasher* pFlasher, BOOL bEnable)
{
	PARAM_CHECK( pFlasher, "Flasher_enableFlasher");
	pFlasher->m_bFlasherEnabled = bEnable;
}

void Flasher_setFlasherColor(Flasher* pFlasher, enum Light_States flasherColor)
{
	pFlasher->flasherColor = flasherColor;
}

enum Light_States Flasher_GetFlasherColor(Flasher* pFlasher)
{
	return pFlasher->flasherColor;
}

void Flasher_setAudibleAlarm(Flasher* pFlasher, BOOL bAudibleAlarm)
{
	pFlasher->m_bAudibleAlarm = bAudibleAlarm;
}

BOOL Flasher_getAudibleAlarm(Flasher* pFlasher)
{
	return pFlasher->m_bAudibleAlarm;
}

