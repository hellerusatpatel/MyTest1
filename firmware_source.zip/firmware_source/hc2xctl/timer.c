/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifdef HELLER_COMM_CTRL_
#include "stdafx1.h"
#endif
#include "timer.h"

/******************************************************************************
 class Timer_Timer

 Function: Constructor - Default

 Abstract:
Initialize the class.

 Programmer: Steven Young
 Date: 03/20/1998
******************************************************************************/
void Timer_init(Timer* pTimer)
{
 	pTimer->countOn	= FALSE;
	pTimer->tenthsOfSecondsCount = 0;
}

DWORD Timer_getCurrentTime10ths(Timer* pTimer)
{
	return pTimer->tenthsOfSecondsCount;
}

void Timer_add10thSecond(Timer* pTimer )
{
	if ( pTimer->countOn == TRUE )
	{
		(pTimer->tenthsOfSecondsCount)++;
	}
}

//******************************************************************************
// Timer_timerOff
//
// 	Abstract:
//  On powerup and changing states from scan off to on the system tics will be
// 	incrementing and the system does not need or want this.
//
//******************************************************************************
void Timer_timerOff( Timer* pTimer)
{
	PARAM_CHECK( pTimer, "Timer_timerOff");
//printk("Timer_timerOff\n");
	pTimer->countOn = FALSE;
};

void Timer_timerOn(Timer* pTimer)
{
	PARAM_CHECK( pTimer, "Timer_timerOn");
//printk("Timer_timerOn\n");	
	pTimer->countOn = TRUE;
}

void Timer_setScanPeriod(Timer* pTimer, DWORD scanPeriodFromScheduler )
{
	PARAM_CHECK( pTimer, "Timer_setScanPeriod");
	pTimer->scanPeriod = scanPeriodFromScheduler; 
}

DWORD Timer_getScanPeriod(Timer* pTimer)
{
	PARAM_CHECK_RETURN( pTimer, "Timer_getScanPeriod", 0);
	return pTimer->scanPeriod; 
}
