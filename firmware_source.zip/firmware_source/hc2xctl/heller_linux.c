#include <stdio.h>
#include "contain.h"

DbContainer g_dbContainer;

int main()
{
	DbContainer_init(&g_dbContainer, NULL);
	return 0;
}

