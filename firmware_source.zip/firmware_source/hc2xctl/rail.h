/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __RAIL_H__
#define __RAIL_H__

#include "typedefdefine.h"

enum DirectionFlag { Rail_FORWARD = 0, Rail_REVERSE = 1 };// forward increases counts
enum RailStates		{ Rail_STOP = 0, Rail_HOME, Rail_PRESET, Rail_MANUAL }; 
enum HomeDirection	{ HomeIN = 0, HomeOUT  };
enum IdNo			{ RAIL0=0 , RAIL1, RAIL2, RAIL3, BADRAIL = MaxRails };
enum ControlType	{ Manual = 0, Auto };
		
typedef struct _Rail_
{	
//public:
	enum DirectionFlag directionFlag;
	BOOL presetAttemptFailed;
	BOOL presetShouldBeStable;  //boolean flag to turn channel yellow when knocked out of position
//made public for tracking by prp3, temp
	int lastRailState; 
	BOOL	presetAchieved;
	BOOL backupForFirstRun;
	BOOL backingUp;
	LONG	toleranceAttempts;
	BOOL bDontAllowNewStopFactor;

	DWORD nTolerance;
	DWORD pTolerance;
	DWORD backDistance;
	BOOL defaultHunt;
	SHORT maxHunt;
	BOOL useHomeOutHuntAlg;
	BOOL bUsingRealPosition;
	enum DirectionFlag storedDirection;
	BOOL AssignSP;

	enum IdNo		railIdNo;				// for determining IO points
	LONG		priorPosition;
	LONG		endUserPresetPosition;	//if they opt to not move the rails the preset position is not what they see

	// these two variables are used to store the current position and save using the stack.
	SHORT 	currentPositionLSW;		// encoder counts 16 BITS signed.
	SHORT	currentPositionMSW;		// 65536 and counting.
	SHORT	scanDelay;

	enum HomeDirection currentHomeDirection;

	LONG	currentPositionCounts;	// The number of counts read from Analogic Board.
	LONG	homePositionCounts;		// The counts from the Analogic Board when the rail leaves the limit switch.
	LONG	homeOffsetCounts;		// CurrentPositionCounts-HomePositionCounts+HomeOffsetCounts = actualPosition.
	LONG	overShootFactor;
	DWORD   overShootTempTime;
	DWORD	lastDecrementTime;
	DWORD	lastIncrementTime;
	DWORD	rail_homeTime;
	enum HomeDirection homeDirection;
	enum RailStates railState;
	BOOL	newJob;
	BOOL	lastHome;
	BOOL	overShootTimeOut;
	BOOL	railActive;
	BOOL	homeAchieved;
	BOOL	manualMove;
	BOOL	incrementFlag;
	BOOL	decrementFlag;
	BOOL	motorEnabled;
	BOOL	incrementEnable;
	BOOL	decrementEnable;

	DWORD   presetStableDelayTime;
	DWORD	finalPositionStableDelayTime;
	DWORD	lastMotorEnabledTime;
	DWORD	lastActualOnTime;
	BOOL	directionChangeFlag;
	BOOL	underShoot;
	BOOL	finalStagePositioning;
	BOOL	trackPushButton;
	DWORD	lastDirectionChangeTime;
	DWORD	directionDelayStartTime;
	DWORD	startHomeTime;
	DWORD	elapsedHomeTime;
	LONG	lastPositionCounts;
	BOOL	m_bOutputEnable;
	BOOL	m_bNewPresetPosition;
	
	enum ControlType controlType;

	LONG timerForYellow;
	DWORD m_fallInTime; //timer for preset test
	DWORD m_backUpTime; //Timer for undershoot backup
	BOOL bRecordedDIStatus[20];
	int iArrayIndicator;
	BOOL m_bForPrintfDebuggingControl;
	BOOL m_bStablizeOvershootReading;  //When undershooting the rail will adjust the overshoot factor based on the amount undershoot
//this works ok but the undershoot flag is reset once moving and the rail takes a new overshoot reading.  This variable will prevent a new
//overshoot reading until conditions warrent it.
	BOOL m_bUnderShootingCorrectionEntered;  //currently the undershoot correction will occur several times before rail output
//is enabled.  We will correct once and attempt again before taking a new reading

	DWORD deadbandStartTime;
	DWORD backupStartTime;

	BOOL presetWarningAdded;
	DWORD selfAckAlarmNo;
	DWORD alarm1id;
	DWORD alarm2id;
	DWORD m_SlowPresetTime;
	DWORD previousActualPos;
	BOOL backOffHomeFlag;

	BOOL bHardwareMode;

	LONG eOvershootFactor;
	LONG eInitialCorrectionFactor;
	LONG eUndershootCorrectionFactor;
	LONG	actualPosition;			// the actual position in counts.
	LONG lStopFactor;  //used by prp3 to read stop position
	LONG		presetPosition;			// the place we want to be during preset.
	LONG m_lAtFinalPresetTimer;
	BOOL m_bNotSequenced;
	BOOL bNoFailureToAchievePresetWarning;
	BOOL m_bRailMoved;
	LONG lastCurrentPositionCounts;	// The number of counts read from Analogic Board.
	DWORD selfAckAlarmNo2;

	UINT	m_laneIndex;	// dual-barcode allows for the user to set the lane index for each rail
	BOOL	m_hasHomed;
	BOOL 	m_bSPChanged;
	unsigned int m_uiOutput;
	unsigned int m_uiDirection;
	unsigned int m_ioHomeSwitch;
} Rail;

void	Rail_init(Rail* pRail, enum IdNo idNo);
void	Rail_enableOutput(Rail* pRail);
void	Rail_setDirectionFlag(Rail* pRail, enum DirectionFlag direction ); 
void	Rail_checkHomeStatus(Rail* pRail);
void	Rail_getLastHomePosition(Rail* pRail);
void	Rail_checkHomeTime(Rail* pRail);
void	Rail_checkForStalledMotor(Rail* pRail);
void	Rail_setManual(Rail* pRail);
void	Rail_setAuto(Rail* pRail);
void	Rail_disableDecrement(Rail* pRail);
void	Rail_disableIncrement(Rail* pRail);
void	Rail_checkCountDirection(Rail* pRail);
DWORD Rail_overShootTimer(Rail* pRail);
void Rail_resetOverShootTimeOut(Rail* pRail);
void Rail_doIncrement(Rail* pRail);
void Rail_doDecrement(Rail* pRail);
SHORT Rail_whatIsDeadbandState();
DWORD Rail_calculateNewStopFactor(Rail* pRail, LONG oldStopFactor, short CorrectionType);
DWORD Rail_huntOutcalculateNewStopFactor(Rail* pRail, LONG oldStopFactor, short CorrectionType);
BOOL Rail_backupForHuntOut(Rail* pRail, BOOL startBackingUp);
BOOL Rail_backup(Rail* pRail, BOOL startBackingUp);
void Rail_backingUpForInitialPresetAttempt(Rail* pRail);
void Rail_backingUpForInitialPresetAttemptHuntOut(Rail* pRail);
BOOL Rail_onHomeSwitch(Rail* pRail);
BOOL Rail_onHomeSwitchandDefaultHunt(Rail* pRail);
BOOL Rail_isInToleranceBand(Rail* pRail, BOOL applyNeg, BOOL applyPos);//rail pv >= (sp - ntol) && pv <= (sp + ptol)
BOOL Rail_isInFakeToleranceBand(Rail* pRail);
BOOL  Rail_isHomeInType(Rail* pRail);
void Rail_process_hardware(Rail* pRail);
void Rail_clearWarnings(Rail* pRail);

void Rail_calculateCurrentPosition(Rail* pRail);
void Rail_goHome(Rail* pRail);
void Rail_goPreset(Rail* pRail);
void Rail_goAutoModePreset(Rail* pRail);
void Rail_goHuntDownAutoModePreset(Rail* pRail);
void Rail_process(Rail* pRail);
void Rail_setHomeDistanceCounts(Rail* pRail, DWORD countsFrom0offset);
DWORD Rail_getHomeDistanceCounts(Rail* pRail);
void Rail_increment(Rail* pRail);
void Rail_decrement(Rail* pRail);
void Rail_disableOutput(Rail* pRail);
void Rail_setNewJob(Rail* pRail);
void Rail_setPositionCounts(Rail* pRail, DWORD presetCounts, BOOL presetStable, BOOL bTransitioning ); 
DWORD Rail_getPresetPosition(Rail* pRail);
DWORD Rail_getPositionCounts(Rail* pRail);
void Rail_setControlType(Rail* pRail, enum ControlType autoOrManual );
void Rail_setHomeDirection(Rail* pRail, enum HomeDirection cHomeDirection );
enum HomeDirection Rail_getHomeDirection(Rail* pRail);
void Rail_setHomeAchieved(Rail* pRail, BOOL homeState );
BOOL Rail_getHomeAchieved(Rail* pRail); 
BOOL Rail_getPresetAchieved(Rail* pRail);
LONG Rail_getCurrentAbsolutePosition(Rail* pRail);
void Rail_setActive(Rail* pRail, BOOL activeState );
BOOL Rail_getActive(Rail* pRail);
void Rail_home(Rail* pRail);
void Rail_stop(Rail* pRail);
void Rail_preset(Rail* pRail);
void Rail_manual(Rail* pRail);
BOOL Rail_isPresetStable(Rail* pRail);
long Rail_isInFinalPosition();
BOOL Rail_isFakePresetStable();
enum RailStates Rail_getRailState(Rail* pRail);
void Rail_resetIncDec(Rail* pRail);
BOOL Rail_addSlowRailWarning(Rail* pRail, BOOL bStartTime);//if a mechanical blockage occurrs this will add a warning and return false to disable output
void Rail_setOutputEnableFlag(Rail* pRail, BOOL bEnable); /*added to explicately disable output unless a setpoint change is sent
in Rail_automatic mode.  Heller has observed rail movement when the rail is borderline in position(jitter?)*/
void Rail_setFalsePositionCounts(Rail* pRail, LONG lPos);
void Rail_resetPresetStableTimer(Rail* pRail);
void Rail_setOvershootFactor(Rail* pRail, LONG newOvershoot);
void Rail_setHuntPreference(Rail* pRail, BOOL defaultDir);
BOOL Rail_getHomeHuntUsed(Rail* pRail);
DWORD Rail_GetSequenceGroup(Rail* pRail);
void Rail_setPresetWarningFlag(Rail* pRail, BOOL bDisableWarning);
void Rail_clearMovementWarning(Rail* pRail);

void Rail_SetLaneIndex(Rail* pRail, UINT index);
BOOL Rail_getSPChanged(Rail* pRail);
BOOL Rail_JoggedOut(Rail* pRail);

#endif
