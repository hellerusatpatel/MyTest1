//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: smema.c
//
// Description: board tracking with no lot processing
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 08-Jan-15  FJN  Set or clear bBoardEntering as appropriate
// 26-Oct-16  FJN  Revise newBoardQueue_checkForBoardDrop_NoLP to increment notifyBoardOut on board drop
// 15-Nov-16  TP   Modify newBoardQueue_checkForBoardDrop_NoLP() to allow board drop event even if board drop warning not enabled
// 14-Nov-17  FJN, TP  Implement Oven_checkRecipeLoadBoardEntryWait
//*****************************************************************************
#include "contain.h"
#include "newboardqNoLP.h"
#include "boards.h"
#include "belt.h"
#include "timer.h"
#include "oven.h"
#include "purge.h"
#include <linux/poll.h>

/*----------------------------------------------------------------------
 *
 *	GLOBAL VARIABLES
 *
 *---------------------------------------------------------------------*/

extern DbContainer g_dbContainer;
static UINT boardQIdIndex = 0;
static UINT barcodeEvents = 0;

BOOL g_bPanelIDEnable;
BOOL g_bLotProcessingEnable;
extern BOOL bBoardEntering[];
extern DWORD dwBoardEnteringTime[];

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_initGlobalVariables

			Initializes Global Variables associated with the
			newBoardQueue that are NOT lane specific.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_initGlobalVariables( void )
{
	g_bPanelIDEnable = FALSE;
	g_bLotProcessingEnable = FALSE;

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_init_NoLP


 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_init_NoLP(newBoardQueue_NoLP* pNBQ)
{
	if( NULL != pNBQ )
	{
		pNBQ->pBeltIOTied  = NULL;
		pNBQ->pBoardEnteringOven = NULL;
		pNBQ->pBoardLeavingOven = NULL;

		pNBQ->boardQueueActive = FALSE;
		pNBQ->lastBoardDetectPosition = 0;
		pNBQ->boardsProcessed = 0;
		pNBQ->boardDetectIn = FALSE;
		pNBQ->boardDetectOut = FALSE;
		pNBQ->boardInputValid = FALSE;
		pNBQ->previousBoardDetectState = FALSE;
		pNBQ->startBoardInDetectTime = 0;
		pNBQ->expectLowInputAfterCounts = 0;
		pNBQ->boardOutputValid = FALSE;
		pNBQ->previousBoardOutDetectState = FALSE;
		pNBQ->startBoardOutDetectTime = 0;
		pNBQ->boardBackUpState = FALSE;
		pNBQ->boardEntranceJamState = FALSE;
		pNBQ->boardBackUpTime = 0;
		pNBQ->updateComplete = FALSE;
		pNBQ->filterCount = 0;
		pNBQ->lowHasOccurred = TRUE;
		pNBQ->m_bBoardOnEntrySensor = FALSE;
		pNBQ->m_bEnableBoardStop = FALSE;
		pNBQ->exitBoardDeadbandCounts = 0;
		pNBQ->boardDropTol = 0;

		pNBQ->boardQId = boardQIdIndex++;
		pNBQ->notifyBoard=0;
		pNBQ->notifyBoardOut=0;
		
		pNBQ->m_uintTimeBackupBegan = 0;
		pNBQ->m_uintTimeEntranceJamBegan = 0;
		pNBQ->boardDropTolNeg = 0;
		pNBQ->uintBoardDropTime = 0;
		pNBQ->m_bSprayEnabled = 0;
		pNBQ->m_dwSprayDist = 0;
		pNBQ->dwSprayLength = 0;
		pNBQ->m_bSprayIsOn = FALSE;
		pNBQ->selfAckCode = 0;
		pNBQ->m_FCExit = 0;
		pNBQ->m_bBoardExitFull = TRUE;
		pNBQ->selfAckAdd =0;
		pNBQ->selfAckExit=0;
		pNBQ->m_dwZoneADist=0;
		pNBQ->smema9851startBoardInDetectDist=0;

		pNBQ->m_bBoardRemoved=FALSE;
		pNBQ->m_b9851Enter=FALSE;
		pNBQ->m_9851distanceTraveled=0;
		pNBQ->cureOven=0;

		pNBQ->m_bIgnoreBoardLength = FALSE;
		pNBQ->m_bEnablePredefinedBoardLength = FALSE;
		pNBQ->m_PredefinedBoardLength = 0;
		pNBQ->m_bEntranceJamWarning = FALSE;
		pNBQ->m_bEnteranceJamStampTaken=FALSE;
		pNBQ->m_enteranceJamBeginDist=0;
		pNBQ->m_bExitJamWarning=FALSE;
		pNBQ->m_bExitJamStampTaken=FALSE;
		pNBQ->m_exitJamBeginDist=0;
		pNBQ->boardExitJamState = FALSE;
		pNBQ->m_uintTimeExitJamBegan=0;
		pNBQ->blowerBoardLoad=BOARD_LOAD_DEFAULT;
		pNBQ->m_dMilli=0;
		pNBQ->m_dHigh=0;
		pNBQ->m_dLow=0;
		pNBQ->m_bLengthAssigned=TRUE;
		pNBQ->uiCurrentJob=0;
		pNBQ->existingBoardDropID=0;
		pNBQ->ltTracking=FALSE;
		pNBQ->dwrdPosWhenHigh=0;
		pNBQ->bBoardLeft = FALSE;
		pNBQ->inputHighCount=0;
		pNBQ->m_dwrdTrailingEdgeCounts = 0;
		LocalTime_resetTime( &(pNBQ->m_currentTime) );
		LocalTime_resetTime( &(pNBQ->m_localTimeEntryLeadingEdge) );
		LocalTime_resetTime( &(pNBQ->m_localTimeEntryTrailingEdge) );
		LocalTime_resetTime( &(pNBQ->m_localTimeExitLeadingEdge) );
		LocalTime_resetTime( &(pNBQ->m_localTimeExitTrailingEdge) );

		newBoardQueue_clearBoardsInOven_NoLP( pNBQ );
	}

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_addBoard_NoLP

			Allocates a board to the appropriate queue and generates
			the appropriate log event.

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL newBoardQueue_addBoard_NoLP(newBoardQueue_NoLP* pNBQ)
{
	BOOL status;
	BOOL bSetLock;
	BOOL bEntranceSMEMA;
	BOOL* pDout;

	status = TRUE;
	bSetLock = FALSE;
	bEntranceSMEMA = FALSE;
	pDout = NULL;

	if( NULL != pNBQ )
	{
		if ( pNBQ->boardCount > MaxBoards )
		{
			status = FALSE;		// to many boards in oven
		}
		else
		{		
			pNBQ->tailIndex = (pNBQ->headIndex + pNBQ->boardCount) % MaxBoards;

			pNBQ->boardCount++;
			pNBQ->notifyBoard++;
			pNBQ->m_bLengthAssigned=FALSE;
			SMEMA_MESSmemaVariable(0,NUM_FILE_CONTROLLED_SMEMA);
			bBoardEntering[pNBQ->boardQId] = TRUE;
			dwBoardEnteringTime[pNBQ->boardQId] = Timer_getCurrentTime10ths(&g_dbContainer.elapseTimer);
#ifdef DEBUG_SMEMA_HOLD
			printk("newBoardQueue_addBoard_NoLP lane%d boardCount=%d\n", pNBQ->boardQId, pNBQ->boardCount);
#endif
			switch ( pNBQ->boardQId )
			{
				case 0:
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_ADDED, Belt_getBeltId(pNBQ->pBeltIOTied));
					pDout = DOUT_GetAt(&( g_dbContainer.digitalOutDb ),ODO_SMEMA1_ENTRANCE );
					
					if( pDout != NULL )
					{
						bEntranceSMEMA = *pDout;
						if( bEntranceSMEMA == TRUE )
						{
							bSetLock = TRUE;
						}
					}
					break;

				case 1:
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_ADDED2, Belt_getBeltId(pNBQ->pBeltIOTied));
					pDout = DOUT_GetAt(&( g_dbContainer.digitalOutDb ),ODO_SMEMA2_ENTRANCE );
					
					if( pDout != NULL )
					{
						bEntranceSMEMA = *pDout;
						if( bEntranceSMEMA == TRUE )
						{
							bSetLock = TRUE;
						}
					}
					break;

				case 2:
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_ADDED3, Belt_getBeltId(pNBQ->pBeltIOTied));
					pDout = DOUT_GetAt(&( g_dbContainer.digitalOutDb ),ODO_SMEMA3_ENTRANCE );
					
					if( pDout != NULL )
					{
						bEntranceSMEMA = *pDout;
						if( bEntranceSMEMA == TRUE )
						{
							bSetLock = TRUE;
						}
					}
					break;

				case 3:
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_ADDED4, Belt_getBeltId(pNBQ->pBeltIOTied));
					pDout = DOUT_GetAt(&( g_dbContainer.digitalOutDb ),ODO_SMEMA4_ENTRANCE );
					
					if( pDout != NULL )
					{
						bEntranceSMEMA = *pDout;
						if( bEntranceSMEMA == TRUE )
						{
							bSetLock = TRUE;
						}
					}
					break;

				default:
					break;
			}
		}
	}
	else
	{
		status = FALSE;
	}

	return status;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_updateBoardPositions_NoLP

			Allocates a board to the appropriate queue and generates
			the appropriate log event.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_updateBoardPositions_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD index;
	DWORD currentBeltPositionCounts;
 	DWORD lcv;

	index = pNBQ->headIndex;
	currentBeltPositionCounts = pNBQ->currentBeltPosition;
	lcv = 0;

	if( NULL != pNBQ )
	{
		for ( lcv = 0; lcv < pNBQ->boardCount; lcv++, index++ )
		{
			if ( index >= MaxBoards )
			{
				index = 0;	// wrap around
			}
					
			pNBQ->boards[index].elapsedPositionCounts = currentBeltPositionCounts - pNBQ->boards[index].startPositionCounts;
		}

	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardsInOvenCount_NoLP

			returns  a count of boards 

 RETURNS:   DWORD count of boards
------------------------------------------------------------------------*/
DWORD newBoardQueue_getBoardsInOvenCount_NoLP(newBoardQueue_NoLP* pNBQ, UINT ui_Type)
{ 
	DWORD dwrdReturn;

	dwrdReturn = 0;

	if( NULL != pNBQ )
	{
		if ( pNBQ->boardsInOvenEnabled == TRUE )
		{
			if(pNBQ->boardCount!=0)
			{
				dwrdReturn = pNBQ->boardCount;
			}
			else
			{ 
				dwrdReturn = !pNBQ->m_bBoardExitFull;
			}
		}
	}

	return dwrdReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardsProcessed_NoLP

			returns  the number processed boards.

 RETURNS:   DWORD count of boards
------------------------------------------------------------------------*/
DWORD newBoardQueue_getBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ)
{ 
	DWORD nRetVal;

	nRetVal = 0;

	if( NULL != pNBQ )
	{
		if ( pNBQ->boardsProcessedEnabled == TRUE )
		{
			nRetVal = pNBQ->boardsProcessed;	
		}
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getBoardAnimationData_NoLP

			Returns a pointer to the specified queue's board animation
			data.

 RETURNS:   BoardData *
------------------------------------------------------------------------*/
const BoardData* newBoardQueue_getBoardAnimationData_NoLP( newBoardQueue_NoLP* pNBQ )
{
	BoardData* pRetVal;

	pRetVal = NULL;

	if( NULL != pNBQ )
	{
		pNBQ->boardData.pBoardArray	= pNBQ->boards;
		pNBQ->boardData.headIndex	= pNBQ->headIndex;
		pNBQ->boardData.tailIndex	= pNBQ->tailIndex;
		pNBQ->boardData.maxBoards	= MaxBoards;
		pNBQ->boardData.boardCount	= newBoardQueue_getBoardsInOvenCount_NoLP(pNBQ, 0);

		pRetVal = &(pNBQ->boardData);
	}

	return (const BoardData*)pRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setSensorDistance_NoLP

			Sets the distance between sensors to in the specified queue.
		
 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_setSensorDistance_NoLP(newBoardQueue_NoLP* pNBQ,  DWORD distanceBetweenSensorsInCounts )
{
	if( NULL != pNBQ )
	{
		pNBQ->distanceBetweenSensorsCounts = distanceBetweenSensorsInCounts;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardDeadBandDistance_NoLP

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDeadBandDistance_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDeadBandInCounts )
{
	if( NULL != pNBQ )
	{
		pNBQ->boardDeadbandCounts =  boardDeadBandInCounts;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_configure_NoLP

			Board tracking is done by detection of a board at the board 
			entering sensor and removed at the board leaving sensor. 
			Board distances are tracked by belt.  If there is no belts then 
			tracking is disabled. If there is only one belt then all the 
			board tracking is done off this belt. If there are two belts then
			the first board entering and leaving inputs are tracked via 
			belt 1 and the second set is tracked by belt 2. If a 
			boardQueueActive flag is set to false then no board tracking 
			is available through that object. This function needs to be 
			set by the ovenDb object whenever the configuration changes.

 RETURNS:   void
------------------------------------------------------------------------*/
BOOL newBoardQueue_configure_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDropConfig, DWORD boardsProcessedConfig, DWORD boardsInOvenConfig )
{
	BOOL status;
	UINT activeBelts;

	BOOL bIoConfig;
	BOOL bBdConfig;
	BOOL bBpConfig;
	BOOL bBoConfig;

	status = FALSE;
	activeBelts = 0;
	bIoConfig = FALSE;
	bBdConfig = FALSE;
	bBpConfig = FALSE;
	bBoConfig = FALSE;

	if( NULL != pNBQ )
	{
		pNBQ->boardQueueActive = FALSE;

		pNBQ->updateComplete = FALSE;

		if ( boardDropConfig < 16 )				// no of options with none, timed, beam and both for two lanes.
		{
			if ( boardsProcessedConfig < 4 )	// boards processed on or off for two lanes
			{
				if ( boardsInOvenConfig < 4 )	// boards in oven on or off for two lanes.
				{
					status = TRUE;
					
					activeBelts = Belts_getNoOfActiveBelts( &(g_dbContainer.beltsDb) );

					if ( activeBelts > 0 && activeBelts <= MaxBelts )
					{
						bIoConfig = newBoardQueue_ioConfig_NoLP(pNBQ, activeBelts );
						bBdConfig = newBoardQueue_bdConfig_NoLP(pNBQ, boardDropConfig );
						bBpConfig = newBoardQueue_bpConfig_NoLP(pNBQ, boardsProcessedConfig );
						bBoConfig = newBoardQueue_boConfig_NoLP(pNBQ, boardsInOvenConfig );

						if (  !	( bIoConfig && 
								  bBdConfig &&  
								  bBpConfig && 
								  bBoConfig ) )
						{
						
							pNBQ->boardQueueActive = FALSE;
							status = FALSE;
						}
					}
				
				}
				else 
				{

					pNBQ->boardQueueActive = FALSE;
					status = FALSE;
				}
			}
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_ioConfig_NoLP

			There is the possibility of two board tracking sensor 
			pairs - entering and exiting IO points.  Due to this there 
			only needs to be two board queues for tracking of boards. By 
			knowing the ID's of the queue it is possible to establish 
			pointers to the electrical inputs. Additionally position 
			needs to be tracked by belt. If there are two belts the 
			second of the BoardQueue is tracking from the second belt. 
			If there is only one belt there is no choice but to track 
			from belt one.

 RETURNS: BOOL - The status of the operation (TRUE or FALSE)
------------------------------------------------------------------------*/
BOOL newBoardQueue_ioConfig_NoLP(newBoardQueue_NoLP* pNBQ, UINT activeBelts )
{
	BOOL status;

	status = TRUE;
	
	if ( activeBelts == 0 || NULL == pNBQ )
	{
		status = FALSE;
	}
	else 
	{
		switch ( pNBQ->boardQId )
		{
			case 0:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
				pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA1_BOARD_ENTERING_OVEN);
				pNBQ->pBoardLeavingOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA1_BOARD_LEAVING_OVEN);
				break;

			case 1:
				pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA2_BOARD_ENTERING_OVEN);
				pNBQ->pBoardLeavingOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA2_BOARD_LEAVING_OVEN);
				switch ( activeBelts )		
				{
				case 1:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
					break;
						
				case 2:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[1]);
					break;
						
				default:
					pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
					status = FALSE;
				}
				break;

			case 2:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
				pNBQ->pBoardEnteringOven = DIN_GetAt( &(g_dbContainer.digitalInDb), IDI_SMEMA3_BOARD_ENTERING_OVEN);
				pNBQ->pBoardLeavingOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA3_BOARD_LEAVING_OVEN);
				break;

			case 3:
				pNBQ->pBoardEnteringOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA4_BOARD_ENTERING_OVEN);
				pNBQ->pBoardLeavingOven = DIN_GetAt(&(g_dbContainer.digitalInDb), IDI_SMEMA4_BOARD_LEAVING_OVEN);
				switch ( activeBelts )		
				{
					case 1:
						pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
						break;
							
					case 2:
						pNBQ->pBeltIOTied = &(g_dbContainer.belt[1]);
						break;
							
					default:
						pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
						status = FALSE;
				}
				break;

			default:
				pNBQ->pBeltIOTied = &(g_dbContainer.belt[0]);
				status = FALSE;
		}
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_bdConfig_NoLP

			If the board Config option is set for the timed method 
			then there is an entry and exit sensor for detecting 
			boards. In the event this option is false it may already 
			have been set in another function. If that is the case 
			then the state needs to be OR'd with the current state. If 
			it's TRUE then set it TRUE and don't worry about the 
			previous state.

 RETURNS: BOOL - The status of the operation (TRUE or FALSE)
------------------------------------------------------------------------*/
BOOL  newBoardQueue_bdConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDropConfig )
{
	BOOL status;

	status = TRUE;

	if( NULL != pNBQ )
	{
		if ( (pNBQ->boardQId == 0) || (pNBQ->boardQId == 2) )
		{
			switch ( boardDropConfig )
			{
				case L1_NONE_L2_NONE:	// the following options do not track by belt.	
				case L1_NONE_L2_TIMED:
				case L1_NONE_L2_BEAM:
				case L1_NONE_L2_BOTH: 
				case L1_BEAM_L2_NONE:	
				case L1_BEAM_L2_TIMED:	
				case L1_BEAM_L2_BEAM:	
				case L1_BEAM_L2_BOTH:
					pNBQ->timedBoarddropEnabled = FALSE;
					break;

				case L1_TIMED_L2_NONE: //fall through
				case L1_TIMED_L2_TIMED:
				case L1_TIMED_L2_BEAM:
				case L1_TIMED_L2_BOTH:	
				case L1_BOTH_L2_NONE:	
				case L1_BOTH_L2_TIMED:
				case L1_BOTH_L2_BEAM:
				case L1_BOTH_L2_BOTH:
					pNBQ->timedBoarddropEnabled = TRUE;
					break;

				default:
					pNBQ->timedBoarddropEnabled =	FALSE;
					status = FALSE;
					break;
			}
		}
		else 
		{
			if ( (pNBQ->boardQId == 1) || (pNBQ->boardQId == 3) )
			{	// boardQ2 is dependent on the number of belts to know which one to track from
				switch ( boardDropConfig )
				{
					case L1_NONE_L2_NONE: //fall through
					case L1_NONE_L2_BEAM:
					case L1_TIMED_L2_NONE:
					case L1_TIMED_L2_BEAM:
					case L1_BEAM_L2_NONE:
					case L1_BEAM_L2_BEAM:
					case L1_BOTH_L2_NONE:
					case L1_BOTH_L2_BEAM:
						pNBQ->timedBoarddropEnabled = FALSE;
						break;

					case L1_NONE_L2_TIMED: //fall through
					case L1_NONE_L2_BOTH:
					case L1_TIMED_L2_TIMED:
					case L1_TIMED_L2_BOTH:
					case L1_BEAM_L2_TIMED:
					case L1_BEAM_L2_BOTH:
					case L1_BOTH_L2_TIMED:
					case L1_BOTH_L2_BOTH:
						pNBQ->timedBoarddropEnabled =	TRUE;
						break;

					default:
						pNBQ->timedBoarddropEnabled = FALSE;
						status = FALSE;
						break;
				}
			}
		}
	}
	else
	{
		status = FALSE;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_bpConfig_NoLP

			If the boards processed option is configured then there is 
			an entry and exit sensor for detecting boards. In the event 
			this option is false it may already have been set in another 
			function. If that is the case then the state needs to be 
			OR'd with the current state. If it's TRUE then set it TRUE 
			and don't worry about the previous state.
 
 RETURNS: BOOL - The status of the operation (TRUE or FALSE)
------------------------------------------------------------------------*/
BOOL newBoardQueue_bpConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardsProcessedConfig )
{	
	BOOL status;

	status = TRUE;

	if( NULL != pNBQ )
	{
		switch ( pNBQ->boardQId )
		{
			case 0: // lane 3 has the same settings as lane 1. Only use though if the check box is set.
			case 2:
				switch ( boardsProcessedConfig )
				{
					case 0:
						pNBQ->boardsProcessedEnabled = FALSE;
						break;
					case 1:
						pNBQ->boardQueueActive = TRUE;
						pNBQ->boardsProcessedEnabled = TRUE;
						break;
					case 2:
						pNBQ->boardsProcessedEnabled = FALSE;
						break;
					case 3:
						pNBQ->boardQueueActive = TRUE;
						pNBQ->boardsProcessedEnabled = TRUE;
						break;
					default:
						pNBQ->boardQueueActive = FALSE;
						pNBQ->boardsProcessedEnabled = FALSE;
						status = FALSE;
						break;
				}        
				break;
		
			case 1:
			case 3:
				switch ( boardsProcessedConfig )
				{
					case 0:
						pNBQ->boardsProcessedEnabled = FALSE;
						break;
					case 1:
						pNBQ->boardsProcessedEnabled = FALSE;
						break;
					case 2:
						pNBQ->boardQueueActive = TRUE;
						pNBQ->boardsProcessedEnabled = TRUE;
						break;
					case 3:
						pNBQ->boardQueueActive = TRUE;
						pNBQ->boardsProcessedEnabled = TRUE;
						break;
					default:
						pNBQ->boardQueueActive = FALSE;
						pNBQ->boardsProcessedEnabled = FALSE;
						status = FALSE;
						break;
				}
				break;
			
			default:
				pNBQ->boardQueueActive = FALSE;
				status = FALSE;
				break;
		}
	}
	else
	{
		status = FALSE;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_boConfig_NoLP

			If the boards in oven option is configured then there is 
			an entry and exit sensor for detecting boards. In the event 
			this option is false it may already have been set in another 
			function. If that is the case then the state needs to be 
			OR'd with the current state. If it's TRUE then set it TRUE 
			and don't worry about the previous state.
 
 RETURNS: BOOL - The status of the operation (TRUE or FALSE)
------------------------------------------------------------------------*/
BOOL newBoardQueue_boConfig_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardsInOvenConfig )
{	
	BOOL status;

	status = TRUE;

	if( NULL != pNBQ )
	{
		pNBQ->updateComplete = FALSE;
		switch ( pNBQ->boardQId )
		{
			case 0:
			case 2: 
				switch ( boardsInOvenConfig )
				{
					case 0: pNBQ->boardsInOvenEnabled = FALSE;
							break;
					case 1:	pNBQ->boardQueueActive = TRUE;
							pNBQ->boardsInOvenEnabled = TRUE;
							break;
					case 2: pNBQ->boardsInOvenEnabled = FALSE;
							break;
					case 3: pNBQ->boardQueueActive = TRUE;
							pNBQ->boardsInOvenEnabled = TRUE;
							break;
					default: pNBQ->boardQueueActive = FALSE;
							 pNBQ->boardsInOvenEnabled = FALSE;		
							 status = FALSE;
							 break;
				}
        		break;
			case 1:
			case 3: 
				switch ( boardsInOvenConfig )
				{
					case 0: pNBQ->boardsInOvenEnabled = FALSE;
							break;
					case 1:	pNBQ->boardsInOvenEnabled = FALSE;
							break;
					case 2: pNBQ->boardQueueActive = TRUE;
							pNBQ->boardsInOvenEnabled = TRUE;
							break;
					case 3: pNBQ->boardQueueActive = TRUE;
							pNBQ->boardsInOvenEnabled = TRUE;
							break;
					default: pNBQ->boardQueueActive = FALSE;
							 pNBQ->boardsInOvenEnabled = FALSE;	
							 status = FALSE;
							 break;
				}
				break;
			default : 
				pNBQ->boardQueueActive = FALSE;
				status = FALSE;
				break;
		}
	}
	else
	{
		status = FALSE;
	}

	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_process_NoLP

			The following boardQueue processes need to be executed to 
			detect board drops and board position. 

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_process_NoLP(newBoardQueue_NoLP* pNBQ)
{
    // There was a third land configuration that was added in 08/10/2000. Per Heller the third lane
    // configuration was to be identical to that of lane 1. A problem occurred where the configuration
    // would not be set correctly until the program was run a second time. This was due to the oven 
    // class knowing the state of the third lane prior to the configuration being set. Since the order
    // of execution is important and changing the way the database updates components it was decidely
    // easier to update a flag that would be cleared during execution. 
    //
    // SDY 08-18-2000
	BOOL bLaneEnabled;
	BOOL bEntering;
	BOOL bCheckSpray;

	bCheckSpray = FALSE;
	bEntering = FALSE;
	bLaneEnabled = FALSE;

	if( NULL != pNBQ )
	{
		newBoardQueue_updateCurrentTime_NoLP( pNBQ );

		if ( pNBQ->updateComplete == FALSE )
		{
			switch ( pNBQ->boardQId )
			{
				case 0: // These two are ok. It is the third lane that matches lane 1 that the state needs
				case 1: // to be determined.
					pNBQ->updateComplete = TRUE;
					break;

				case 2:
					if(g_dbContainer.ovenDb.lane3Enabled || ( g_dbContainer.smema3.SMEMA_Type  == SMEMA_9851 ) )
					{
						bLaneEnabled = TRUE;
					}
					if( bLaneEnabled == FALSE )
					{
						pNBQ->boardQueueActive = FALSE;
						pNBQ->boardsInOvenEnabled = FALSE;
						pNBQ->boardsProcessedEnabled = FALSE;
					}
					pNBQ->updateComplete = TRUE;
					break;

				case 3:
					if(g_dbContainer.ovenDb.lane4Enabled || ( g_dbContainer.smema4.SMEMA_Type  == SMEMA_9851 ) )
					{
						bLaneEnabled = TRUE;
					}
					if( bLaneEnabled == FALSE )
					{
						pNBQ->boardQueueActive = FALSE;
						pNBQ->boardsInOvenEnabled = FALSE;
						pNBQ->boardsProcessedEnabled = FALSE;
					}
					pNBQ->updateComplete = TRUE;
					break;

				default:
					break;
			}
		}

		if ( pNBQ->boardQueueActive == TRUE )
		{
			pNBQ->currentBeltPosition = Belt_getPosition(pNBQ->pBeltIOTied);

			newBoardQueue_addOutstandingEntryEvents_NoLP( pNBQ );

 			if ( pNBQ->lowHasOccurred == FALSE )
			{
				newBoardQueue_hasLowOccurred_NoLP(pNBQ);
			}

			newBoardQueue_removeBoard_NoLP(pNBQ);
			newBoardQueue_checkForBoardEntering_NoLP(pNBQ);
			newBoardQueue_updateBoardPositions_NoLP(pNBQ);
			newBoardQueue_checkForEntranceBoardJam_NoLP(pNBQ);
			newBoardQueue_checkForBoardBackup_NoLP(pNBQ);
			newBoardQueue_checkForBoardDrop_NoLP(pNBQ);
			newBoardQueue_checkForBoardLeaving_NoLP(pNBQ);
			newBoardQueue_checkForBoardFCExit_NoLP(pNBQ);
			

			bCheckSpray = newBoardQueue_checkForSpray_NoLP(pNBQ);
			Purge_setSprayOn(&(g_dbContainer.purge), bCheckSpray, pNBQ->boardQId);
			bEntering = *(pNBQ->pBoardEnteringOven); 
			if(bEntering == FALSE)
			{
				pNBQ->m_bBoardOnEntrySensor = FALSE;	
				if(pNBQ->selfAckAdd!=0)
				{
					AlarmQueue_alarmQueueAcknowledge(&(g_dbContainer.alarmQueueDb), pNBQ->selfAckAdd);				
					pNBQ->selfAckAdd = 0;
				}	
			}

			// if the following two options are not turned on then return 0.
			if ( pNBQ->boardsInOvenEnabled == FALSE )
			{
				pNBQ->boardCount = 0;
			}

			if ( pNBQ->boardsProcessedEnabled == FALSE )
			{
				pNBQ->boardsProcessed = 0;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_hasLowOccurred_NoLP

			Monitors for a valid board Entrance. 

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_hasLowOccurred_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD position;

	position = 0;

	if( NULL != pNBQ )
	{
		position = (const DWORD)Belt_getPosition(pNBQ->pBeltIOTied);
		if (  position >= pNBQ->expectLowInputAfterCounts )
		{
			if ( *(pNBQ->pBoardLeavingOven) == FALSE )
			{
				pNBQ->inputHighCount=0;
				pNBQ->lowHasOccurred = TRUE;
			}
			else
			{
				pNBQ->inputHighCount++;

				if( pNBQ->inputHighCount > 2 )
				{
					pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + pNBQ->exitBoardDeadbandCounts;
				}
			}
		}
		else
		{
			if( *(pNBQ->pBoardLeavingOven) == FALSE )
			{
				pNBQ->inputHighCount=0;
			}
			else
			{
				pNBQ->inputHighCount++;

				if( pNBQ->inputHighCount >= 2 )
				{
					pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + pNBQ->exitBoardDeadbandCounts;
				}
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForEntranceBoardJam_NoLP

			Monitors Board Entrance for a board jam condition. 

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_checkForEntranceBoardJam_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD nDifference;
	DWORD distanceTraveled;
	BOOL bBoardInputSensor;
	DWORD messNo;
	DWORD nTimerTenths;

	nDifference = 0;
	distanceTraveled = 0;
	bBoardInputSensor = FALSE;
	messNo = 0;
	nTimerTenths = 0;

	if ( NULL != pNBQ )
	{
		if ( pNBQ->m_bEntranceJamWarning && 
			pNBQ->m_bEnablePredefinedBoardLength )
		{
			bBoardInputSensor = *(pNBQ->pBoardEnteringOven);

			if ( bBoardInputSensor )
			{
				if(pNBQ->m_bEnteranceJamStampTaken==FALSE)
				{
					pNBQ->m_bEnteranceJamStampTaken=TRUE;
					pNBQ->m_enteranceJamBeginDist=pNBQ->currentBeltPosition;
				}

				distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->m_enteranceJamBeginDist); 

				if ( distanceTraveled >= pNBQ->m_PredefinedBoardLength )
				{
		    		if( pNBQ->boardEntranceJamState == FALSE )//first time through, take beginning timestamp
					{
						pNBQ->m_uintTimeEntranceJamBegan = 
							Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
					}

					pNBQ->boardEntranceJamState = TRUE;

					nTimerTenths = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
					nDifference = differenceWithRollover(nTimerTenths, pNBQ->m_uintTimeEntranceJamBegan);
					
					if ( nDifference > pNBQ->uintBoardDropTime /*400*/)
					{
						messNo = 0;

						switch (pNBQ->boardQId)
						{
							case 0:
								messNo = BOARD_ENTRANCE_JAM1;
								break;

							case 1:
								messNo = BOARD_ENTRANCE_JAM2;
								break;

							case 2:
								messNo = BOARD_ENTRANCE_JAM3;
								break;

							case 3:
								messNo = BOARD_ENTRANCE_JAM4;
								break;

							default:
								break;
						}

						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb),
								WARNING, messNo, Belt_getBeltId(pNBQ->pBeltIOTied));
					}
				}
			}
			else 
			{
				pNBQ->m_bEnteranceJamStampTaken=FALSE;
				pNBQ->boardEntranceJamState = FALSE;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardBackup_NoLP

			In order to differentiate between board drops and board 
			backups then a low is expected from the board sensor within 
			the period between the end of the board in counts and the 
			end of the board plus board deadband counts. If a low does 
			not occur it is assumed that a board backup has occurred, 
			although a number of other events can cause this as well.

			Code works with the first board sensor only with lto option
			modifying the code so the smema tested is keyed to the 
			boardQId i.e.

			id 0=IDI_SMEMA1_BOARD_LEAVING_OVEN
			id 1=IDI_SMEMA2_BOARD_LEAVING_OVEN
			id 2=IDI_SMEMA3_BOARD_LEAVING_OVEN
			id 3=IDI_SMEMA4_BOARD_LEAVING_OVEN

			wdt
			12/28/00

RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardBackup_NoLP(newBoardQueue_NoLP* pNBQ)
{
	signed int iSmemaLeavingIndex;
	signed int FILTER_SCANS;
	DWORD distanceTraveled;
	DWORD nDifference;
	DWORD messNo;
	BOOL bLTOption;
	BOOL din;
	DWORD dwBeltPos;
	DWORD nTimerTenths;

	iSmemaLeavingIndex = 0;
	FILTER_SCANS = 5; // 1/2 second
	distanceTraveled = 0;
	nDifference = 0;
	bLTOption = TRUE;
	messNo = 0;
	din = FALSE;
	dwBeltPos = 0;
	nTimerTenths = 0;

	if( NULL != pNBQ )
	{
		switch(pNBQ->boardQId)
		{
			case 0:
				iSmemaLeavingIndex=IDI_SMEMA1_BOARD_LEAVING_OVEN;
				break;
			case 1:
				iSmemaLeavingIndex=IDI_SMEMA2_BOARD_LEAVING_OVEN;
				break;
			case 2:
				iSmemaLeavingIndex=IDI_SMEMA3_BOARD_LEAVING_OVEN;
				break;
			case 3:
				iSmemaLeavingIndex=IDI_SMEMA4_BOARD_LEAVING_OVEN;
				break;
			default:
				iSmemaLeavingIndex=IDI_SMEMA1_BOARD_LEAVING_OVEN;
				break;
		}

		FILTER_SCANS = 5;  // 1/2 second
		// Per Heller Fax 05/01/00 from D. Smith. Attach board stop function to board drop enable-disable function
		// in setup wizard. Used for only timed method, the through beam option does not have the correct configuration
		// options.
		// SDY - 08/23/00
		if ( pNBQ->m_bEnableBoardStop == TRUE )
		{
			if (pNBQ->m_bEnablePredefinedBoardLength )
			{

				if ( *(pNBQ->pBoardLeavingOven) )
				{
					if(pNBQ->m_bExitJamStampTaken==FALSE)
					{
						pNBQ->m_bExitJamStampTaken=TRUE;
						pNBQ->m_exitJamBeginDist=pNBQ->currentBeltPosition;
					}
		
					distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->m_exitJamBeginDist); 
		
					if ( distanceTraveled >= pNBQ->m_PredefinedBoardLength )
					{
		    			if( pNBQ->boardExitJamState == FALSE )//first time through, take beginning timestamp
						{
							pNBQ->m_uintTimeExitJamBegan = 
								Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						}

						pNBQ->boardExitJamState = TRUE;

						nTimerTenths = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						nDifference = differenceWithRollover(nTimerTenths, pNBQ->m_uintTimeExitJamBegan);

						if ( nDifference > pNBQ->uintBoardDropTime )
						{
							messNo = 0;

							switch (pNBQ->boardQId)
							{
								case 0:
									messNo = BOARD_BACKUP_WARNING;
									break;

								case 1:
									messNo = BOARD_BACKUP_WARNING_2;
									break;

								case 2:
									messNo = BOARD_BACKUP_WARNING_3;
									break;

								case 3:
									messNo = BOARD_BACKUP_WARNING_4;
									break;

								default:
									break;
							}

							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb),
									WARNING, messNo, Belt_getBeltId(pNBQ->pBeltIOTied));
						}
					}
				}
				else 
				{
					pNBQ->m_bExitJamStampTaken=FALSE;
					pNBQ->boardExitJamState = FALSE;
				}
			}
			else
			{
				bLTOption = Oven_getLTOption(&(g_dbContainer.ovenDb));

				if ( bLTOption == TRUE )
	    		{
				// a filter count needed to be added to eliminate spikes causing the board
				// backup timer to reset.
				// Spikes were causing the counter to reset, counter begins on transition
				// from low to high. Need to prevent the low going spikes from starting the
				// forty second timer from resetting. It is expected that 5 scans or .5 seconds
				// of continuous low signal should be adequate.
				// SDY - 10/26/99

					din = *DIN_GetAt(&(g_dbContainer.digitalInDb), iSmemaLeavingIndex);

					if ( din == FALSE )
					{
						pNBQ->filterCount++;
					}
					else 
					{
						pNBQ->filterCount = 0;
					}

					din = *DIN_GetAt(&(g_dbContainer.digitalInDb), iSmemaLeavingIndex);

					if( din == FALSE && pNBQ->filterCount >= FILTER_SCANS )
					{
						pNBQ->boardBackUpTime = 0;
						pNBQ->boardBackUpState = FALSE;
						if(pNBQ->selfAckCode != 0)
						{
							switch(pNBQ->boardQId)
							{
								case 0:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 1:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED2, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 2:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED3, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 3:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED4, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								default:
									break;
							}

							AlarmQueue_alarmQueueAcknowledge(&(g_dbContainer.alarmQueueDb), pNBQ->selfAckCode);
							pNBQ->selfAckCode = 0;
						}
					}

					din = *DIN_GetAt(&(g_dbContainer.digitalInDb), iSmemaLeavingIndex);

					if( din == TRUE && pNBQ->boardBackUpTime == 0 )
					{
						pNBQ->boardBackUpTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
					}

					if ( pNBQ->boardBackUpTime != 0 )
					{
						nTimerTenths = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						nDifference = differenceWithRollover( nTimerTenths, pNBQ->boardBackUpTime );

						if ( nDifference > pNBQ->uintBoardDropTime /*400*/)
						{
							pNBQ->boardBackUpState = TRUE;

							if(pNBQ->boardQId==0)
							{
	    						pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==1)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==2)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==3)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
					}
	 		   }
	 		   else
	 		   {
					dwBeltPos = Belt_getPosition(pNBQ->pBeltIOTied);

					if( (dwBeltPos >= pNBQ->m_dwrdTrailingEdgeCounts) && (pNBQ->lowHasOccurred == FALSE) )
					{
			    		if(pNBQ->boardBackUpState == FALSE )//first time through, take beginning timestamp
						{
							pNBQ->m_uintTimeBackupBegan = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						}
						pNBQ->boardBackUpState = TRUE;

						nTimerTenths = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
						nDifference = differenceWithRollover( nTimerTenths, pNBQ->m_uintTimeBackupBegan );

						if ( nDifference > pNBQ->uintBoardDropTime /*400*/)
						{
							if(pNBQ->boardQId==0)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==1)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==2)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else if(pNBQ->boardQId==3)
							{
								pNBQ->selfAckCode = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_BACKUP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
					}
					else
					{
						if(pNBQ->selfAckCode)
						{
							switch(pNBQ->boardQId)
							{
								case 0:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 1:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED2, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 2:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED3, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								case 3:
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_BACKUP_CLEARED4, Belt_getBeltId(pNBQ->pBeltIOTied));
									break;
								default:
									break;
							}

							AlarmQueue_alarmQueueAcknowledge(&(g_dbContainer.alarmQueueDb), pNBQ->selfAckCode);
							pNBQ->selfAckCode = 0;
						}	

						pNBQ->boardBackUpState = FALSE;
					}
	 		   }
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardDrop_NoLP

			A board drop is detected whenever the lead board has 
			traveled a distance of the distance between sensors + 
			deadband. If this position is achieved then the board 
			has dropped.  and the board needs to be removed from 
			the Queue.

RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardDrop_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD distanceTraveled;
	BOOL bSkipDueToCure;
	UINT localIndex;
	char bBoardRemoved;
	DWORD deltaBoardDistance;
	BOOL bSmemaNoBoardAnimation;

	DWORD wiggle;
	UINT job;
	LONG lDiff;

	distanceTraveled = 0;
	bSkipDueToCure = FALSE;
	localIndex = pNBQ->headIndex;
	bBoardRemoved = 0;
	deltaBoardDistance = 0;
	bSmemaNoBoardAnimation = FALSE;

	lDiff = 0;
	wiggle = 5;
	job=0;

	if( NULL != pNBQ )
	{
		// the board can only move a distance of the sensors in counts of the encoders. If the board has
		// traveled the distance between the sensors plus the deadband then a board drop is detected.

		bSmemaNoBoardAnimation = newBoardQueue_GetSmemaNoAnimation_NoLP(pNBQ);

		//if ( pNBQ->timedBoarddropEnabled == TRUE  && pNBQ->boardCount != 0 )  //ver8.0.0.15
		if(pNBQ->boardCount != 0 && pNBQ->boardsProcessedEnabled == TRUE && pNBQ->boardsInOvenEnabled == TRUE && bSmemaNoBoardAnimation == FALSE)
		{
			distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->boards[pNBQ->headIndex].startPositionCounts); 
			// distance traveled needs to be less set to 0 in the event it is negative. The reason is
			// when doing a comparison a negative value is very large so set it to 0 when it is negative.
			// Othersise the distanceBetweenSensorsCounts could be converted to a long but if the encoder
			// counts or oven length increases or some combination of the two we don't want overflow,
			// although that may be impossible with 2billion+ counts.
			lDiff = (distanceTraveled - pNBQ->exitBoardDeadbandCounts);
			if ( lDiff < 0 )
			{
				distanceTraveled = 0;
			}
			
			if( ( pNBQ->cureOven != 0 ) && ( pNBQ->m_skipTail == TRUE ) )//for cure oven, if head is in exit window act on the next if there are no more, skip the alarm as the board does not really exist for board drop testing
			{
				if( pNBQ->boardCount > 1 )//for cure oven, if head is in exit window act on the next
				{
					localIndex++;
					if ( localIndex >= MaxBoards )
					{
						localIndex = 0;
					}

					distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->boards[localIndex].startPositionCounts); 
					lDiff = (distanceTraveled - pNBQ->exitBoardDeadbandCounts);

					if ( lDiff < 0 )
					{
						distanceTraveled = 0;
					}
				}
				else
				{
					bSkipDueToCure=TRUE;
				}
			}
			if ( bSkipDueToCure == FALSE )
			{
				deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boards[localIndex].boardLengthCounts + pNBQ->boardDropTol);
				if ( pNBQ->m_bIgnoreBoardLength )
				{
					deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boardDropTol + wiggle);
				}


				if ( distanceTraveled > deltaBoardDistance )
				{
					// Do not indicate Board Drop if board backup has ocurred but the board will still need
					// to be removed from oven.
					// SDY 10/20/1999
					if ( pNBQ->boardBackUpState == FALSE)
					{
						Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), TRUE, &(pNBQ->m_currentTime) );
						Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), FALSE, &(pNBQ->m_currentTime) );
						if ( pNBQ->boardQId == 0 )
						{
							//AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
							//ver8.0.0.15
							if (pNBQ->existingBoardDropID == 0)
							{
								if(pNBQ->timedBoarddropEnabled == TRUE)
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
								else
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else
							{
								pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
						else if ( pNBQ->boardQId == 1 )
						{
							//AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
							//ver8.0.0.15
							if (pNBQ->existingBoardDropID == 0)
							{
								if(pNBQ->timedBoarddropEnabled == TRUE)
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
								else
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else
							{
								pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_2, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
						else if ( pNBQ->boardQId == 2 )
						{
							//AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
							//ver8.0.0.15
							if (pNBQ->existingBoardDropID == 0)
							{
								if(pNBQ->timedBoarddropEnabled == TRUE)
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
								else
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else
							{
								pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_3, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
						else if ( pNBQ->boardQId == 3 )
						{
							//AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
							//ver8.0.0.15
							if (pNBQ->existingBoardDropID == 0)
							{
								if(pNBQ->timedBoarddropEnabled == TRUE)
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
								else
									pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
							else
							{
								pNBQ->existingBoardDropID = AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_DROP_WARNING_4, Belt_getBeltId(pNBQ->pBeltIOTied));
							}
						}
						if( barcodeEvents != 0 )
						{
							job = Oven_getJob(&(g_dbContainer.ovenDb));

							if( job == COOLDOWN )
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), INFORMATION, BOARD_DROP_INFO, 0);
							}
						}
						pNBQ->notifyBoardOut++; // fjn -- keep notifyBoardOut and notifyBoard in sync
					}

					bBoardRemoved = 1;
				}
			}
		}
		
		if( ( bSkipDueToCure == FALSE ) && ( pNBQ->boardCount != 0 ) && ( bBoardRemoved == 0 ) )
		{
			distanceTraveled = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->boards[localIndex].startPositionCounts); 
			lDiff = ((LONG)distanceTraveled - pNBQ->exitBoardDeadbandCounts);
			if( lDiff < 0 )
			{
				distanceTraveled = 0; 
			}

			deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boards[localIndex].boardLengthCounts + pNBQ->boardDropTol);

			if ( pNBQ->m_bIgnoreBoardLength )
			{
				deltaBoardDistance = (pNBQ->distanceBetweenSensorsCounts + pNBQ->boardDropTol + wiggle);
			}

			if ( distanceTraveled > deltaBoardDistance )
			{	
				Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), TRUE, &(pNBQ->m_currentTime) );
				Board_TimeStampSetExit( &(pNBQ->boards[localIndex]), FALSE, &(pNBQ->m_currentTime) );
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardLeaving_NoLP

			A board will only be detected as leaving when its' 
			position is:

			( currentPosition - startPositionCounts + deadBandcounts ) > distanceBetweenSensors  

			If this condition is not met it is the previous board and 
			it would not be correct to repeatedly remove boards. Thus the deadband.

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardLeaving_NoLP(newBoardQueue_NoLP* pNBQ)
{
    BOOL boardDetectOutLocal; 
	DWORD dwrdDist;
	BOOL bSmemaNoBoardAnimation;
	DWORD deltaTime;
	DWORD nDifference;
	UCHAR nBeltId;

	boardDetectOutLocal = FALSE; //jwf 
	dwrdDist = 0;
	bSmemaNoBoardAnimation = FALSE;
	deltaTime = 0;
	nDifference = 0;
	nBeltId = 0;

	if( NULL != pNBQ )
	{
		pNBQ->boardDetectOut = *(pNBQ->pBoardLeavingOven);
		boardDetectOutLocal = pNBQ->boardDetectOut;// jwf

		pNBQ->boardOutputValid = FALSE;
		
		if ( pNBQ->boardDetectOut == TRUE)
		{
			bSmemaNoBoardAnimation = newBoardQueue_GetSmemaNoAnimation_NoLP(pNBQ);

			if ( bSmemaNoBoardAnimation == TRUE )
			{
				if ( pNBQ->previousBoardOutDetectState == FALSE )
				{
					pNBQ->startBoardOutDetectTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
				}

				deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pNBQ->startBoardOutDetectTime;

				if ( deltaTime == TIMER_20MS_CNTS )
				{
					nDifference = differenceWithRollover(pNBQ->currentBeltPosition,pNBQ->dwrdPosWhenHigh);

					if ( ( pNBQ->boardCount > 0 ) && ( nDifference >= pNBQ->exitBoardDeadbandCounts ) )
					{
						pNBQ->boardCount--;
						pNBQ->boardsProcessed++;
						pNBQ->notifyBoardOut++;
						nBeltId = Belt_getBeltId(pNBQ->pBeltIOTied);

						switch ( pNBQ->boardQId )
						{
							case 0:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED, nBeltId );
								break;
							case 1:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED2, nBeltId );
								break;
							case 2:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED3, nBeltId );
								break;
							case 3:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED4, nBeltId );
								break;
							default:
								break;
						}
					}
				}
			}
			else
			{
				if ( pNBQ->lowHasOccurred == TRUE )
				{
					if ( pNBQ->previousBoardOutDetectState == FALSE )
					{
						pNBQ->startBoardOutDetectTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
				
					}

					deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pNBQ->startBoardOutDetectTime;

					if ( deltaTime >= TIMER_20MS_CNTS )
					{
						 if(pNBQ->boardCount != 0)
						 {
							 pNBQ->boardOutputValid = TRUE;
							 pNBQ->bBoardLeft = TRUE;
							 Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), TRUE, &(pNBQ->m_localTimeExitLeadingEdge) );
						 }
					}
				}
			}
		}
		else//the output must low for at least the carrier exit spacing before removing a board
		{
			if( ( pNBQ->previousBoardOutDetectState == TRUE ) && ( pNBQ->bBoardLeft == TRUE ) )
			{
				pNBQ->dwrdPosWhenHigh=pNBQ->currentBeltPosition;
				pNBQ->bBoardLeft = FALSE;
			}
		}
		// this is used to prevent a board jam at the sensor from ever allowing a board 
		// to exit if another board is jammed at the sensor.

		if ( pNBQ->boardDetectOut == FALSE )
		{
			pNBQ->startBoardOutDetectTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
		}
		
		pNBQ->previousBoardOutDetectState = pNBQ->boardDetectOut;

		//Tushar does not want the board removed if the output has not lowed at least the exit cutoff distance

		nDifference = differenceWithRollover(pNBQ->currentBeltPosition,pNBQ->dwrdPosWhenHigh);

		if ( ( pNBQ->boardOutputValid == TRUE ) && ( nDifference >= pNBQ->exitBoardDeadbandCounts ) )
		{
			dwrdDist = pNBQ->boards[pNBQ->headIndex].startPositionCounts;

			//cure oven test on the trailing edge
			if( pNBQ->cureOven == 0 )
			{
				nDifference = differenceWithRollover(pNBQ->currentBeltPosition, dwrdDist) + pNBQ->boardDropTolNeg;

				if (  nDifference >= pNBQ->distanceBetweenSensorsCounts )
				{
			
					if ( pNBQ->boardCount != 0 )   // problem with boards processed being incremented when no boards in oven.
					{
						pNBQ->boardsProcessed++;
						pNBQ->notifyBoardOut++;

						nBeltId = Belt_getBeltId(pNBQ->pBeltIOTied);

						switch ( pNBQ->boardQId )
						{
							case 0:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED, nBeltId );
								break;
							case 1:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED2, nBeltId );
								break;
							case 2:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED3, nBeltId );
								break;
							case 3:
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED4, nBeltId );
								break;
							default:
								break;
						}
						// in order to detect a jam there must be a low input of the board
						// leaving sensor. So we need to get the current belt position 
						// and the length to know when this must occur.
						if ( pNBQ->m_bEnablePredefinedBoardLength && pNBQ->m_PredefinedBoardLength )
						{
							pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + 
									pNBQ->m_PredefinedBoardLength;
						}
						else
						{
							pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + 
									pNBQ->boards[pNBQ->headIndex].boardLengthCounts;
							pNBQ->m_dwrdTrailingEdgeCounts = Belt_getPosition(pNBQ->pBeltIOTied) + 
									pNBQ->boards[pNBQ->headIndex].boardLengthCounts;//this is the start position for the stop warning
						}
						pNBQ->m_skipTail=FALSE;
						pNBQ->lowHasOccurred = FALSE;
						pNBQ->inputHighCount=0;
						Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), FALSE, &(pNBQ->m_currentTime) );
						Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), TRUE, &(pNBQ->m_currentTime) );
					}
					else
					{
						pNBQ->lowHasOccurred = TRUE;
					}
				}
			}
			else
			{
				nDifference = differenceWithRollover(pNBQ->currentBeltPosition, dwrdDist);
				if ( ( nDifference + pNBQ->boardDropTolNeg)  >= pNBQ->distanceBetweenSensorsCounts )
				{	
					if( ( pNBQ->m_bCureRemove == FALSE ) && ( pNBQ->boardCount != 0 ) )
					{
						pNBQ->m_skipTail=TRUE;
						pNBQ->m_bCureRemove=TRUE;
						pNBQ->m_bCureRemoveDistStamped=FALSE;
						pNBQ->m_cureRemoveDist=0;
					}

					if ( pNBQ->boardCount != 0 )   // problem with boards processed being incremented when no boards in oven.
					{
						if ( pNBQ->m_bEnablePredefinedBoardLength && pNBQ->m_PredefinedBoardLength )
						{
							pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + 
									pNBQ->m_PredefinedBoardLength;
						}
						else
						{
							pNBQ->expectLowInputAfterCounts = Belt_getPosition(pNBQ->pBeltIOTied) + 
								pNBQ->boards[pNBQ->headIndex].boardLengthCounts;
						}


						pNBQ->lowHasOccurred = FALSE;
					}
					else
					{
						pNBQ->lowHasOccurred = TRUE;
					}
				}
			}
		}
		if( ( pNBQ->boardDetectOut == FALSE ) && ( pNBQ->cureOven != 0 ) && ( pNBQ->m_bCureRemove == TRUE ) )
		{
			nDifference = differenceWithRollover(pNBQ->currentBeltPosition,pNBQ->m_cureRemoveDist);

			if( pNBQ->m_bCureRemoveDistStamped == FALSE )
			{
				pNBQ->m_bCureRemoveDistStamped=TRUE;
				pNBQ->m_cureRemoveDist=pNBQ->currentBeltPosition;
			}
			else if( nDifference > pNBQ->boardDeadbandCounts )
			{
				pNBQ->m_bCureRemove=FALSE;

				nBeltId = Belt_getBeltId(pNBQ->pBeltIOTied);

				//do removal////////////////////////////
				switch ( pNBQ->boardQId )
				{
					case 0:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED, nBeltId );
						break;
					case 1:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED2, nBeltId );
						break;
					case 2:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED3, nBeltId );
						break;
					case 3:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_EXITED4, nBeltId );
						break;
					default:
						break;
				}


				if ( pNBQ->boardCount != 0 )   // problem with boards processed being incremented when no boards in oven.
				{
					pNBQ->boardsProcessed++;
					pNBQ->notifyBoardOut++;
						
					Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), TRUE, &(pNBQ->m_currentTime) );
					Board_TimeStampSetExit( &(pNBQ->boards[pNBQ->headIndex]), FALSE, &(pNBQ->m_currentTime) );
				}
			}
		}
	}

	return;
}
		

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardEntering_NoLP

			A new board entering the oven is defined by the elapsed 
			distance of the belt traveled since the last board is 
			detected being equal to or greater than the deadband for a 
			board. Some boards have holes or other gaps that can occur 
			where the sensor for the board input is. Without taking into
			account some deadband limits any transition from low to high 
			would indicate a new board.

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardEntering_NoLP(newBoardQueue_NoLP* pNBQ)
{
    DWORD deltaTime;
	BOOL bClearBarCodeAllow;
	BOOL bSmemaNoBoardAnimation;
	BOOL bPastDeadBand;
	DWORD nDifference;
	UCHAR nBeltId;

	deltaTime = 0;
	bClearBarCodeAllow = FALSE;
	bSmemaNoBoardAnimation = FALSE;
	bPastDeadBand = FALSE;
	nDifference = 0;
	nBeltId = 0;

	if( NULL != pNBQ )
	{
		
		if (Oven_checkRecipeLoadBoardEntryWait(&g_dbContainer.ovenDb))	//ver8.0.0.24, TP
			pNBQ->boardDetectIn = FALSE;
		else
			pNBQ->boardDetectIn = *(pNBQ->pBoardEnteringOven);

		pNBQ->boardInputValid = FALSE;

		if( pNBQ->boardDetectIn && ( pNBQ->boardHeadRead == FALSE ) )
		{
			pNBQ->boardHeadRead = TRUE;
			pNBQ->boardStartPos = pNBQ->currentBeltPosition;
		}

		if ( pNBQ->boardDetectIn == TRUE )
		{	
			
			if ( pNBQ->previousBoardDetectState == FALSE )
			{
				pNBQ->startBoardInDetectTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer));
 				newBoardQueue_setTimeStampWithCurrentTime_NoLP( pNBQ, &(pNBQ->m_localTimeEntryLeadingEdge) );
			}
		
			deltaTime = Timer_getCurrentTime10ths(&(g_dbContainer.elapseTimer)) - pNBQ->startBoardInDetectTime;
			
			bClearBarCodeAllow = FALSE;

			bSmemaNoBoardAnimation = newBoardQueue_GetSmemaNoAnimation_NoLP(pNBQ);

			if ( bSmemaNoBoardAnimation == TRUE )
			{
				if ( deltaTime == TIMER_20MS_CNTS )
				{
					if ( pNBQ->boardCount >= 0 )
					{
						pNBQ->boardCount++;
						bClearBarCodeAllow = TRUE;
					}
				}
			}
			else
			{
				if ( deltaTime >= TIMER_20MS_CNTS )	// must see board for a half second.
				{

					pNBQ->boardInputValid = TRUE;
					bClearBarCodeAllow = TRUE;
				}
			}

			if ( bClearBarCodeAllow )
			{
				switch( pNBQ->boardQId )
				{
					case 0:
						g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						break;

					case 1:
						g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						break;

					case 2:
						g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema4.m_bBarcodeAllow=FALSE;	
						break;

					case 3:
						g_dbContainer.smema1.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema2.m_bBarcodeAllow=FALSE;	
						g_dbContainer.smema3.m_bBarcodeAllow=FALSE;	
						break;
					default:
						break;
				}
			}

		}
		else
		{
			pNBQ->boardHeadRead=FALSE;
		}

		pNBQ->previousBoardDetectState = pNBQ->boardDetectIn;

		bPastDeadBand = newBoardQueue_isPastDeadBand_NoLP(pNBQ);

		if ( bPastDeadBand == TRUE || pNBQ->boardCount == 0 )
		{
			//this leads to animation problems
			if ( pNBQ->boardCount > 0 && pNBQ->boardCount <= MaxBoards)//if we set length when we are at maximum it causes a bug since the board will not be added and position data will be incorrect
			{
				if(	pNBQ->m_bLengthAssigned == FALSE )
				{
					pNBQ->m_bLengthAssigned = TRUE;

					newBoardQueue_setLength_NoLP(pNBQ);		// if not done in this order the last board will never have a length.	

					if ( pNBQ->boards[pNBQ->tailIndex].bInUse &&
						(pNBQ->boards[pNBQ->tailIndex].timeStamps.bValidEntryTrailing == FALSE) )
					{
						Board_TimeStampSetEntry( &(pNBQ->boards[pNBQ->tailIndex]), FALSE, &(pNBQ->m_localTimeEntryTrailingEdge) );
					}
				}
				
			}
		
			if ( pNBQ->boardInputValid == TRUE )
			{
				// If the distance that has elapsed is equal to or  greater than the deadband and a board is 
				// detected it will be considered a new board.
				// At this point a distance greater than the deadband has elapsed and a board has been 
				// detected then this is a new board.
				if( !pNBQ->m_bBoardOnEntrySensor )
				{
					pNBQ->m_bPendSmema=TRUE;
					
					/* note the system always declares a new board at the 
					   current belt position, even though the sensor
					   has been blocked for five cycles.  end was correct.  
					   changing this so board length will now be correct.  
					   may effect drop tolerances?
				    */

					newBoardQueue_newBoard_NoLP(pNBQ, pNBQ->boardStartPos);
				}
				else if(pNBQ->boardDeadbandCounts==0)//we must assign the length for 0 cutoff as long as the entrance sensor is blocked
				{
					newBoardQueue_setLength_NoLP(pNBQ);
				}
			}
		}

		// as long a board is detected the last position of the board needs to be recorded to get an
		// actual distance in belt counts that the board is long.

		if ( pNBQ->boardInputValid == TRUE )
		{
			pNBQ->lastBoardDetectPosition = pNBQ->currentBeltPosition;	// need to track the last postion of 
															// board for both length and deadband.
			if( ( *( pNBQ->pBoardEnteringOven ) == FALSE ) && ( pNBQ->m_bPendSmema == TRUE ) )
			{
				nDifference = differenceWithRollover(pNBQ->currentBeltPosition,pNBQ->m_9851distanceTraveled);
				if( nDifference > pNBQ->boardDeadbandCounts )
				{
					pNBQ->m_b9851Enter=TRUE;
		
				}
			}
			else if( ( *( pNBQ->pBoardEnteringOven ) == TRUE ) )
			{
				pNBQ->m_b9851Enter=FALSE;
				pNBQ->m_9851distanceTraveled = pNBQ->currentBeltPosition;
			} 
		}
		else
		{
			if( ( *( pNBQ->pBoardEnteringOven ) == FALSE ) && ( pNBQ->m_bPendSmema == TRUE ) )
			{
				nDifference = differenceWithRollover( pNBQ->currentBeltPosition,pNBQ->m_9851distanceTraveled);

				if( nDifference > pNBQ->boardDeadbandCounts )
				{
					pNBQ->m_b9851Enter=TRUE;
				}
			}
			else if( ( *( pNBQ->pBoardEnteringOven ) == TRUE ) )
			{
				pNBQ->m_b9851Enter=FALSE;
				pNBQ->m_9851distanceTraveled = pNBQ->currentBeltPosition;
			} 

			if( pNBQ->m_bPendSmema == TRUE && pNBQ->m_b9851Enter == TRUE )
			{
				pNBQ->m_bPendSmema = FALSE;
				pNBQ->m_bStartSmema = TRUE;
				pNBQ->m_b9851Enter = FALSE;
			
				pNBQ->smema9851startBoardInDetectDist = pNBQ->currentBeltPosition;

				nBeltId = Belt_getBeltId(pNBQ->pBeltIOTied);

				bBoardEntering[pNBQ->boardQId] = FALSE;
				dwBoardEnteringTime[pNBQ->boardQId] = 0;
#ifdef DEBUG_SMEMA_HOLD
				printk("newBoardQueue_checkForBoardEntering_NoLP lane%d\n", pNBQ->boardQId);
#endif
				switch ( pNBQ->boardQId )
				{
					case 0:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD1, nBeltId );
						break;
					case 1:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD2, nBeltId );
						break;
					case 2:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD3, nBeltId );
						break;
					case 3:
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, BOARD_LOG_RECORD4, nBeltId );
						break;
					default:
						break;
				}
			
			}
			else if( pNBQ->m_bStartSmema == TRUE )
			{	
					pNBQ->m_bStartSmema = FALSE;
					pNBQ->boardHeadRead = FALSE;
			}

			if( *( pNBQ->pBoardEnteringOven ) == TRUE ) //allow for spacing
			{
				pNBQ->smema9851startBoardInDetectDist=pNBQ->currentBeltPosition;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setLength_NoLP

			The boards length can only be determined by the position 
			of the last board detection and the belt traveling an 
			additional distance of deadband counts. Once the deadband 
			counts have been achieved then the last position of the 
			board being detected was the length of the previous board.

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_setLength_NoLP(newBoardQueue_NoLP* pNBQ)
{

	DWORD dwLength;
	DWORD startCount;
	DWORD dwrdSumDeadPredefine;

	dwrdSumDeadPredefine = 0;
	dwLength = 0;
	startCount = 0;

	if( NULL != pNBQ )
	{
		dwLength = pNBQ->lastBoardDetectPosition - pNBQ->boards[pNBQ->tailIndex].startPositionCounts;

		if ( pNBQ->m_bEnablePredefinedBoardLength )
		{
			if ( pNBQ->m_PredefinedBoardLength > 0 )
			{
				dwLength = pNBQ->m_PredefinedBoardLength;

				//
				// re-adjust starting edge of the board as necessary because this is a predefined length
				//
				dwrdSumDeadPredefine = (pNBQ->boardDeadbandCounts+pNBQ->m_PredefinedBoardLength);
				startCount = Belt_getPosition(pNBQ->pBeltIOTied) - dwrdSumDeadPredefine;

				Board_setStartPosition( &(pNBQ->boards[pNBQ->tailIndex]), startCount );
			}
		}

		if( pNBQ->m_bEnablePredefinedBoardLength == TRUE )
		{
			Board_setLength( &(pNBQ->boards[pNBQ->tailIndex]), pNBQ->m_PredefinedBoardLength	);
		}
		else
		{
			Board_setLength( &(pNBQ->boards[pNBQ->tailIndex]), dwLength	);
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_isPastDeadBand_NoLP

			A board may have holes in it that may give the false 
			impression that a board is complete and the next 
			transition will add another board. The method of 
			deadband has been changed from time to distance making 
			the operation consistent at all speeds without having to 
			change the time setting as belt speed changes.

 RETURNS: BOOL - TRUE if past deadband; FALSE otherwise
------------------------------------------------------------------------*/
BOOL newBoardQueue_isPastDeadBand_NoLP(newBoardQueue_NoLP* pNBQ)
{
	BOOL status;
	DWORD lastBoardDetectionElapsed;

	/* This construct violates the coding standard,
	   however, in an effort to not disrupt the 
	   this function, this static variable 
	   has been left. - JMR
	*/
	static BOOL pastDeadBandDetect = FALSE;

	status = FALSE;
	lastBoardDetectionElapsed = differenceWithRollover(pNBQ->currentBeltPosition, pNBQ->lastBoardDetectPosition);

	if( NULL != pNBQ )
	{
		if (  lastBoardDetectionElapsed >= pNBQ->boardDeadbandCounts )
		{	

			if ( pastDeadBandDetect == FALSE )
			{
				pastDeadBandDetect = TRUE;
			}
			if( pNBQ->boardDeadbandCounts == 0 )//0 board spacing will continually return true.  we need to return false if the input is low because this is cutoff spacing and no voids are possible
			{
				status = *(pNBQ->pBoardEnteringOven);
			}
			else
			{
				status = TRUE;
			}
			if( pNBQ->boardDeadbandCounts == 0 )
			{
				if( *( pNBQ->pBoardEnteringOven ) == TRUE )
				{
					pastDeadBandDetect=FALSE;
				}
			}

		}
		else 
		{
			pastDeadBandDetect = FALSE;
		}
	}
	
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_newBoard_NoLP

			A board may have holes in it that may give the false 
			impression that a board is complete and the next transition 
			will add another board. The method of deadband has been 
			changed from time to distance making the operation 
			consistent at all speeds without having to change the time 
			setting as belt speed changes.

 RETURNS: void
------------------------------------------------------------------------*/
void newBoardQueue_newBoard_NoLP(newBoardQueue_NoLP* pNBQ, DWORD beltStartPositionCounts )
{
	BOOL status;
	Board* pBoard;

	status = FALSE;
	pBoard = NULL;

	if( NULL != pNBQ )
	{
		status = newBoardQueue_addBoard_NoLP(pNBQ);		// get index into queue

		pNBQ->ltTracking=TRUE;

		if ( status == TRUE )
		{
			// always add a board to the end of the queue.
			// in the event no boards are in the oven then the head and tail are the same.
			pBoard = &(pNBQ->boards[pNBQ->tailIndex]);

			pBoard->bInUse = TRUE;

			Board_setStartPosition(&(pNBQ->boards[pNBQ->tailIndex]), beltStartPositionCounts );
			Board_setLength(&(pNBQ->boards[pNBQ->tailIndex]), 0);	 // a new board that has been added is zero length until the next
											 // board is detected.

			Board_TimeStampSetEntry( pBoard, TRUE, &(pNBQ->m_localTimeEntryLeadingEdge) );

			BoardEntryEvents_AddBoardEntryEvent( &(g_dbContainer.m_boardEvents), pBoard, pNBQ->boardQId );

			pNBQ->boardStartPos = 0;
		}

		pNBQ->m_bBoardOnEntrySensor = TRUE;
	}	

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_clearBoardsInOven_NoLP

				Clears the specified queue of all boards.				

	RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_clearBoardsInOven_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD lcv;

	lcv = 0;

	if ( NULL != pNBQ )
	{
		pNBQ->boardCount = 0;
		pNBQ->headIndex = 0;
		pNBQ->tailIndex = 0;


		pNBQ->m_skipTail=FALSE;

		for ( lcv = 0; lcv < MaxBoards; lcv++ ) 
		{
			Board_init( &(pNBQ->boards[lcv]) );
			pNBQ->boards[lcv].boardLengthCounts = 0;	
			pNBQ->boards[lcv].startPositionCounts = 0;
			pNBQ->boards[lcv].elapsedPositionCounts = 0;
		}

		pNBQ->m_bPendSmema = FALSE;
		pNBQ->m_bStartSmema = FALSE;

		pNBQ->boardHeadRead = FALSE;
		pNBQ->boardStartPos = 0;

		pNBQ->m_dwrdLastBeltPosWNoBoards = pNBQ->currentBeltPosition - pNBQ->m_FCExit;
		pNBQ->m_bCureRemove=FALSE;
		pNBQ->m_bCureRemoveDistStamped=FALSE;
		pNBQ->m_cureRemoveDist=0;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setBoardsProcessed_NoLP

				Sets the boards processed flag for the specified
				queue.

	RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_setBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ, DWORD noOfBoardsProcessed )
{
	if( NULL != pNBQ )
	{
		pNBQ->boardsProcessed = noOfBoardsProcessed;
	}

	return;
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_clearBoardsProcessed_NoLP

				Sets the boards processed flag for the specified
				queue to ZERO.

	RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_clearBoardsProcessed_NoLP(newBoardQueue_NoLP* pNBQ)
{
	if( NULL != pNBQ )
	{
		pNBQ->boardsProcessed = 0;	
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_clearBoardsProcessed

				Returns the number of Max Boards.

				NOTE: This function used to use PARAM_CHECK_RETURN 
				with a return of ZERO if the pNBQ pointer was 
				NULL.  MaxBoards is not a member of the newBoardQueue
				structure, and therefor not referenced by the pNBQ
				pointer.  However, this function has been rewritten
				to maintain the function of this call.

	RETURNS:   DWORD MaxBoards
------------------------------------------------------------------------*/
DWORD newBoardQueue_getMaxBoards_NoLP(newBoardQueue_NoLP* pNBQ)	
{
	DWORD nRetVal;

	nRetVal = 0;

	if( NULL != pNBQ )
	{
		nRetVal = MaxBoards;
	}

	return nRetVal;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_getSensorDistance_NoLP

				Returns the counts between sensors.

	RETURNS:   DWORD distanceBetweenSensorsCounts
------------------------------------------------------------------------*/
DWORD newBoardQueue_getSensorDistance_NoLP(newBoardQueue_NoLP* pNBQ) 
{
	DWORD nRetVal;

	nRetVal = 0;
	
	if( NULL != pNBQ )
	{
		nRetVal = pNBQ->distanceBetweenSensorsCounts; 
	}

	return nRetVal;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_enableBoardStop_NoLP

				Set the enable board stop flag for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_enableBoardStop_NoLP(newBoardQueue_NoLP* pNBQ, BOOL enableState)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_bEnableBoardStop = enableState;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setExitBoardDeadbandCounts_NoLP

				Set the exit board deadband counts for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_setExitBoardDeadbandCounts_NoLP(newBoardQueue_NoLP* pNBQ, DWORD boardDeadbandExitInCounts)
{
	if( NULL != pNBQ )
	{
		pNBQ->exitBoardDeadbandCounts = boardDeadbandExitInCounts;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setBoardDropTolerance_NoLP

				Sets the board drop tolerence for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropTolerance_NoLP(newBoardQueue_NoLP* pNBQ, DWORD bdt)
{
	if( NULL != pNBQ )
	{
		pNBQ->boardDropTol = bdt;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setBoardDropTime_NoLP

				Sets the board drop time for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropTime_NoLP(newBoardQueue_NoLP* pNBQ, UINT bTime)
{
	if( NULL != pNBQ )
	{
		pNBQ->uintBoardDropTime = bTime;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setBoardDropToleranceNeg_NoLP

				Sets the board drop negative tolerence for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_setBoardDropToleranceNeg_NoLP(newBoardQueue_NoLP* pNBQ, DWORD bdt)
{
	if( NULL != pNBQ )
	{
		pNBQ->boardDropTolNeg = bdt;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_setSprayDist_NoLP

				Sets the spray distance for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_setSprayDist_NoLP(newBoardQueue_NoLP* pNBQ, DWORD dwDist)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_dwSprayDist = dwDist;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_enableSpraySensor_NoLP

				Sets the spray enable for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_enableSpraySensor_NoLP(newBoardQueue_NoLP* pNBQ, BOOL bEnable)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_bSprayEnabled = bEnable;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	newBoardQueue_addSprayLength_NoLP

				Sets the spray length for the specified
				board queue.

	RETURNS:   void 
------------------------------------------------------------------------*/
void newBoardQueue_addSprayLength_NoLP(newBoardQueue_NoLP* pNBQ, DWORD dwrLength)
{
	if( NULL != pNBQ )
	{
		pNBQ->dwSprayLength = dwrLength;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForSpray_NoLP

			Monitors is Spray is active

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL newBoardQueue_checkForSpray_NoLP(newBoardQueue_NoLP* pNBQ)
{
	DWORD index;
	DWORD lcv;
	BOOL bReturn;

	index = 0;
	lcv = 0;
	bReturn = FALSE;

	if( NULL != pNBQ )
	{
		index = pNBQ->headIndex;

		if(pNBQ->m_bSprayEnabled)
		{
			for( lcv = 0; ( ( lcv < pNBQ->boardCount ) && ( bReturn==FALSE ) ); lcv++, index++ )
			{
				if( index >= MaxBoards )
				{
					index = 0;
				}
				if( ( pNBQ->m_dwSprayDist < (pNBQ->boards[index].elapsedPositionCounts) ) && 
					( pNBQ->boards[index].elapsedPositionCounts < (pNBQ->dwSprayLength + pNBQ->boards[index].boardLengthCounts + pNBQ->m_dwSprayDist) ) )
				{
					bReturn = TRUE;
				}
			}
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_checkForBoardFCExit_NoLP

 RETURNS:   BOOL
------------------------------------------------------------------------*/
void newBoardQueue_checkForBoardFCExit_NoLP(newBoardQueue_NoLP* pNBQ)
{
	if( NULL != pNBQ )
	{
		if( pNBQ->boardsInOvenEnabled == TRUE )
		{
			if( pNBQ->boardCount )
			{
				pNBQ->m_dwrdLastBeltPosWNoBoards = pNBQ->currentBeltPosition;
				pNBQ->m_bBoardExitFull = FALSE;
			}
			else
			{
				if( ( pNBQ->currentBeltPosition - pNBQ->m_dwrdLastBeltPosWNoBoards ) >= pNBQ->m_FCExit )
				{
					pNBQ->m_bBoardExitFull = TRUE;
				}
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBoardFCExtraTravel_NoLP

			Sets the FC Exit extra travel.
			
 RETURNS:   void
 -----------------------------------------------------------------------*/
void newBoardQueue_setBoardFCExtraTravel_NoLP(newBoardQueue_NoLP* pNBQ, DWORD extra)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_FCExit = extra;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setZoneADist_NoLP

			Removes the board at the head of the queue.
			
 RETURNS:   void
 -----------------------------------------------------------------------*/
void newBoardQueue_setZoneADist_NoLP(newBoardQueue_NoLP* pNBQ, DWORD dist)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_dwZoneADist = dist;
	}

	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setBarcodeEvents_NoLP

			Sets the global barcodeEvents variable.
			
 RETURNS:   void
 -----------------------------------------------------------------------*/
void newBoardQueue_setBarcodeEvents_NoLP(UINT bcEvent)
{
	barcodeEvents = bcEvent;

	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_GetSmemaNoAnimation_NoLP

			Returns the lane dependant No Board Animation Flag

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL newBoardQueue_GetSmemaNoAnimation_NoLP( newBoardQueue_NoLP *pNBQ )
{
	BOOL bReturn;

	bReturn = FALSE;

	/* m_bNoBoardAnimation is only valid if m_bMaxBoardsPerLaneEnable is set.
	*/

	if( NULL != pNBQ )
	{
		switch( pNBQ->boardQId )
		{
			case 0:
				if ( g_dbContainer.smema1.m_bMaxBoardsPerLaneEnable )
				{
					bReturn = g_dbContainer.smema1.m_bNoBoardAnimation;	
				}
				break;

			case 1:
				if ( g_dbContainer.smema2.m_bMaxBoardsPerLaneEnable )
				{
					bReturn = g_dbContainer.smema2.m_bNoBoardAnimation;	
				}
				break;

			case 2:
				if ( g_dbContainer.smema3.m_bMaxBoardsPerLaneEnable )
				{
					bReturn = g_dbContainer.smema3.m_bNoBoardAnimation;	
				}
				break;

			case 3:
				if ( g_dbContainer.smema4.m_bMaxBoardsPerLaneEnable )
				{
					bReturn = g_dbContainer.smema4.m_bNoBoardAnimation;	
				}
				break;

			default:
				break;
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_updateCurrentTime_NoLP


 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_updateCurrentTime_NoLP( newBoardQueue_NoLP* pNBQ )
{
	if( NULL != pNBQ )
	{
		//
		// Update Current time
		//
		if(pNBQ->m_currentTime.dwLow == 0xffffffff)
		{
			pNBQ->m_currentTime.dwHigh++;
			pNBQ->m_currentTime.dwLow = 0;
		}
		pNBQ->m_currentTime.dwMilli += differenceWithRollover(jiffies, pNBQ->m_jiffies);
		pNBQ->m_jiffies = jiffies;

		if(pNBQ->m_currentTime.dwMilli > 999)
		{
			pNBQ->m_currentTime.dwLow++;
			pNBQ->m_currentTime.dwMilli -= 1000;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_setTimeStampWithCurrentTime_NoLP

			Copies the current time into the timestamp parameter.

 RETURNS:   void
 -----------------------------------------------------------------------*/
void newBoardQueue_setTimeStampWithCurrentTime_NoLP( newBoardQueue_NoLP* pNBQ, LocalTime* pTimeStamp )
{
	if ( pNBQ && pTimeStamp )
	{
		pTimeStamp->dwHigh = pNBQ->m_currentTime.dwHigh;
		pTimeStamp->dwLow = pNBQ->m_currentTime.dwLow;
		pTimeStamp->dwMilli = pNBQ->m_currentTime.dwMilli;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_getNextIndex_NoLP

			return the index of the second board in queue
			only call if there is more than 1 board in queue

 RETURNS:   UINT
------------------------------------------------------------------------*/
UINT newBoardQueue_getNextIndex_NoLP(newBoardQueue_NoLP* pNBQ)
{
	UINT uiReturn = pNBQ->headIndex;

	uiReturn = 0;

	if( NULL != pNBQ )
	{
		uiReturn = pNBQ->headIndex;
		uiReturn++;
		if ( uiReturn >= MaxBoards )
		{
			uiReturn = 0;
		}
	}

	return uiReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_removeBoard_NoLP

            Remove the head board from the internal queue.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_removeBoard_NoLP(newBoardQueue_NoLP* pNBQ)
{
	Board* pBoard;
	DWORD localIndex;

	pBoard = NULL;
	localIndex = 0;

	if( NULL != pNBQ)
	{
		if ( pNBQ->boardCount )
		{
			//check for drop in board after head index, special case for blocked exit sensor
			if( pNBQ->boardCount > 1 )
			{
				localIndex = newBoardQueue_getNextIndex_NoLP(pNBQ);
				pBoard = &(pNBQ->boards[localIndex]);
				if( pBoard->bBoardDropped )
				{
					if ( pBoard->timeStamps.bValidExitLeading &&//should be redundant, set when dropped
						pBoard->timeStamps.bValidExitTrailing )
					{
						Board_Copy(pBoard,&(pNBQ->boards[pNBQ->headIndex]));//copy board from head to next pos
						newBoardQueue_removeBoardFromCircularBuffer_NoLP(pNBQ);
					}
				}
			}

			pBoard = &(pNBQ->boards[pNBQ->headIndex]);
			if ( pBoard && pBoard->bInUse )
			{
				// Only remove boards whose exit-side leading and trailing edge timestamps are set.
				if ( pBoard->timeStamps.bValidExitLeading &&
					 pBoard->timeStamps.bValidExitTrailing )
				{

					// reset all the data in the structure
					newBoardQueue_removeBoardFromCircularBuffer_NoLP(pNBQ);
				}
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_removeBoardFromCircularBuffer_NoLP

            helper function for newBoardQueue_removeBoard does the 
			actual increment of head, changes count, and tail index if
			neccessary

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_removeBoardFromCircularBuffer_NoLP(newBoardQueue_NoLP* pNBQ)
{
	if( NULL != pNBQ )
	{
		pNBQ->m_skipTail=FALSE;
		pNBQ->m_bBoardRemoved=TRUE;
		pNBQ->boards[pNBQ->headIndex].boardLengthCounts = 0;
		pNBQ->boards[pNBQ->headIndex].startPositionCounts = 0;
		pNBQ->boards[pNBQ->headIndex].elapsedPositionCounts = 0;
		Board_init( &(pNBQ->boards[pNBQ->headIndex]) ); //clear head variables
		(pNBQ->headIndex)++;
		(pNBQ->boardCount)--;

		if ( pNBQ->headIndex >= MaxBoards )
		{
			pNBQ->headIndex = 0;
		}

		if ( pNBQ->boardCount == 0 )
		{
			pNBQ->tailIndex = pNBQ->headIndex;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  newBoardQueue_addOutstandingEntryEvents_NoLP

            Entry events are normally added from newBoardQueue_newBoard_NoLP().
			However, if the event queue was full and awaiting acks,
			then we need to retry adding the events.

 RETURNS:   void
------------------------------------------------------------------------*/
void newBoardQueue_addOutstandingEntryEvents_NoLP(newBoardQueue_NoLP* pNBQ)
{
	int i;
	Board* pBoard;

	i = 0;
	pBoard = NULL;

	if( NULL != pNBQ )
	{
		for ( i = 0; i < MaxBoards; i++ )
		{
			pBoard = &(pNBQ->boards[i]);

			if ( pBoard->bInUse 
				&& (pBoard->timeStamps.bEntryEventAdded == FALSE) )
			{
				BoardEntryEvents_AddBoardEntryEvent( &(g_dbContainer.m_boardEvents), pBoard, pNBQ->boardQId );
			}
		}
	}

	return;
}
