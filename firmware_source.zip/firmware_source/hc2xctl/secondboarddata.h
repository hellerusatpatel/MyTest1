/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __SECPVTRANS__
#define __SECPVTRANS__

#include "typedefdefine.h"

typedef struct _SecondaryBoardData_
{
//private:
	char	name[MaxNameLength+1];

//public:
//by setting the present values up equivalent to the DIN's it makes my life much easier(we can directly assign
//the modbus reads without parsing for ground and supply channels like I implemented in the board offset program).
//Beyond that it allows the software to use the same left to right switching strategy so less error should be introduced.
//WDT 02.12.02
	WORD	presentValues[MAX_DIGITAL_INPUTS];
	WORD	setpoints[MAX_DIGITAL_OUTPUTS];
	
	UINT	iCommError;
	UINT	iReadingAttempts;

	BOOL	bReading;
	BOOL	bCommunicationTimeOut;
	BOOL	bSendTPO;

//private:
	BOOL	bMonitoring; //used by the monitor to indicate run status
	BOOL    bMasterOnOff;  //used by the hdac for on/off, anded with bMonitoring

} SecondaryBoardData;

void SecondaryBoardData_setHc1xQuality(SecondaryBoardData* pSecondaryBoardData, int hc1xIndicators);
void SecondaryBoardData_setMonitoringStatusFromSecondBoard(SecondaryBoardData* pSecondaryBoardData, BOOL bIsSendingData);
void SecondaryBoardData_setMonitoringStatusFromHdac(SecondaryBoardData* pSecondaryBoardData, BOOL bWillAcceptData);
BOOL SecondaryBoardData_getMonitoringStatusCombined(SecondaryBoardData* pSecondaryBoardData);
void SecondaryBoardData_InitializeTPObuffer(SecondaryBoardData* pSecondaryBoardData);
void SecondaryBoardData_init(SecondaryBoardData* pSecondaryBoardData, const char *szName 	);
void SecondaryBoardData_assignTPO(SecondaryBoardData* pSecondaryBoardData, UINT index, WORD wVal);
#endif
