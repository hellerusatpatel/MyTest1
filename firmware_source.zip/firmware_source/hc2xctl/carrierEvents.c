/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			CarrierEvents.c

	Description:	Implementation of the CHellerCommCtrl OLE control class

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

/*=======================================================================
 *
 * INCLUDE FILES:
 *
 *=======================================================================*/

#include "contain.h"
#include "BoardEventCmds.h"
#include "LotProcessingCmds.h"
#include "carrierEvents.h"
#include "newboardq.h"
#include "newboardqNoLP.h"
#include "boards.h"
#include "oven.h"
#include "typedefdefine.h"
#include "utility.h"

extern DbContainer g_dbContainer;

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  CarrierBoard_init

            Initialization routine.

 RETURNS:   void
------------------------------------------------------------------------*/
void CarrierBoard_init(CarrierBoard* pCarrierBoard)
{
	if ( NULL != pCarrierBoard )
	{
		pCarrierBoard->m_bInUse = FALSE;
		pCarrierBoard->m_pBoard = NULL;

		pCarrierBoard->m_lotID = 0;
		pCarrierBoard->m_carrierIndex = 0;

		pCarrierBoard->m_lane = 0;

		LocalTime_resetTime( &(pCarrierBoard->timeStamps.entryLeadingEdge) );
		LocalTime_resetTime( &(pCarrierBoard->timeStamps.entryTrailingEdge) );
		LocalTime_resetTime( &(pCarrierBoard->timeStamps.exitLeadingEdge) );
		LocalTime_resetTime( &(pCarrierBoard->timeStamps.exitTrailingEdge) );

		pCarrierBoard->timeStamps.bValidEntryLeading = FALSE;
		pCarrierBoard->timeStamps.bValidEntryTrailing = FALSE;
		pCarrierBoard->timeStamps.bValidExitLeading = FALSE;
		pCarrierBoard->timeStamps.bValidExitTrailing = FALSE;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcEvent_init

            Initialization routine.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcEvent_init(LotProcEvent* pLotProcEvent)
{
	if ( NULL != pLotProcEvent )
	{
		pLotProcEvent->highTime = 0;
		pLotProcEvent->lowTime = 0;
		pLotProcEvent->milliseconds = 0;
		pLotProcEvent->eventSeqNum = 0;
		pLotProcEvent->lotID = 0;
		pLotProcEvent->carrierIndex = 0;
		pLotProcEvent->inUse = 0;
		pLotProcEvent->lane = 0;
		pLotProcEvent->entryExit = 0;
		pLotProcEvent->position = 0;
		pLotProcEvent->lotStart = 0;
		pLotProcEvent->lotEnd = 0;
		pLotProcEvent->lastEnter = 0;
		pLotProcEvent->firstExit = 0;
		pLotProcEvent->cooldown = 0;
		pLotProcEvent->reserved = 0;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Lot_init

            Initialization routine.
			If bInvalidLot is TRUE, then the lot is initialized for the INVALID LOT.

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Lot_init(Lot* pLot, BOOL bInvalidLot)
{
	signed int i;

	i = 0;

	if ( NULL != pLot )
	{
		pLot->m_bInUse = FALSE;

		pLot->m_lotId = 0;
		pLot->m_expectedCount = 0;
		pLot->m_bAbortEarly = FALSE;

		pLot->m_nInOvenCount = 0;
		pLot->m_nProcessedCount = 0;

		for ( i = 0; i < MaxBoards; i++ )
		{
			CarrierBoard_init( &(pLot->m_carrier.m_boards[i]) );
		}
		pLot->m_carrier.m_headIndex = 0;
		pLot->m_carrier.m_tailIndex = 0;
		pLot->m_carrier.m_count = 0;

		if ( bInvalidLot )
		{
			// The invalid lots are always in use.
			pLot->m_lotId = LOTPROC_INVALID_LOT;
			pLot->m_bInUse = TRUE;
			pLot->m_expectedCount = MaxBoards;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Lot_carrierAdd

			Returns the index of the added carrier, or -1.
			Sets the in-use flag of the carrier at the returned index.

 RETURNS:   int
------------------------------------------------------------------------*/
signed int Lot_carrierAdd(Lot* pLot)
{
	signed int nReturnIndex;
	CarrierBoard* pCarrier;

	nReturnIndex = -1;
	pCarrier = NULL;

	if ( NULL != pLot )
	{
		if ( pLot->m_carrier.m_count < MaxBoards )
		{
			if ( (pLot->m_carrier.m_tailIndex >= 0) &&
				(pLot->m_carrier.m_tailIndex < MaxBoards) )
			{
				pLot->m_carrier.m_tailIndex = (pLot->m_carrier.m_headIndex + pLot->m_carrier.m_count) % MaxBoards;
				pLot->m_carrier.m_count++;

				pCarrier = &(pLot->m_carrier.m_boards[ pLot->m_carrier.m_tailIndex ]);
				pCarrier->m_bInUse = TRUE;

				nReturnIndex = pLot->m_carrier.m_tailIndex;
			}
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Lot_carrierGetByBoard

			Returns the index of the carrier associated with the Board 
			pointer, or -1.

 RETURNS:   int
------------------------------------------------------------------------*/
signed int Lot_carrierGetByBoard(Lot* pLot, Board* pBoard)
{
	signed int nReturnIndex;
	signed int index;
	signed int i;

	CarrierBoard* pCarrier;

	nReturnIndex = -1;
	index = 0;
	i = 0;
	pCarrier = NULL;

	if ( NULL != pLot && 
		 NULL != pBoard )
	{
		//
		// Iterate through the carrier boards looking for the matching element.
		//
		index = pLot->m_carrier.m_headIndex;
		for ( i = 0; (i < MaxBoards) && (nReturnIndex == -1); i++ )
		{
			pCarrier = &(pLot->m_carrier.m_boards[index]);

			if ( pCarrier->m_bInUse && 
				(pCarrier->m_pBoard == pBoard) )
			{
				nReturnIndex = index;
			}
			
			index++;
			if ( index >= MaxBoards )
			{
				index = 0;
			}
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_init

            Initialization routine.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_init(LotProcessing* pLotProc)
{
	int i;

	i = 0;

	if ( NULL != pLotProc )
	{
		for ( i = 0; i < MAX_LOT_COUNT; i++ )
		{
			Lot_init( &(pLotProc->m_lot[i]), FALSE ) ;
		}

		pLotProc->m_lotCount = 0;
		pLotProc->m_lotHeadIndex = 0;
		pLotProc->m_lotTailIndex = 0;

		for ( i = 0; i < MAX_INVALID_LOT; i++ )
		{
			Lot_init( &(pLotProc->m_lotInvalid[i]), TRUE );
		}

		pLotProc->m_lotInvalidIndex = 0;

		for ( i = 0; i < MAX_CARRIER_EVENT_COUNT; i++ )
		{
			LotProcEvent_init( &(pLotProc->m_events.m_array[i]) );
		}
		pLotProc->m_events.m_headIndex = 0;
		pLotProc->m_events.m_tailIndex = 0;
		pLotProc->m_events.m_count = 0;
		pLotProc->m_events.m_sequenceNum = 0;
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_process

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void LotProcessing_process(LotProcessing* pLotProc)
{
	if ( NULL != pLotProc )
	{
		// Check for any lots that can be deleted.
		LotProcessing_clearCompletedLots( pLotProc );

		// Check both of the newboardQueues for newly entered 
		// boards.  Add CarrierBoards for each new Board encountered
		// and associate the Board pointer.
		LotProcessing_checkForNewBoards( pLotProc, &(g_dbContainer.boardQ0) );
		LotProcessing_checkForNewBoards( pLotProc, &(g_dbContainer.boardQ1) );
		LotProcessing_checkForNewBoards( pLotProc, &(g_dbContainer.boardQ2) );
		LotProcessing_checkForNewBoards( pLotProc, &(g_dbContainer.boardQ3) );

		// Run through all the CarrierBoards and compare their
		// timestamps to their associated Board's timestamps.  If we
		// find a new timestamp create the correct carrier event.
		LotProcessing_checkForNewEvents( pLotProc );
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_eventAdd

			Returns the index of the added event, or -1.
			Sets the in-use flag and updates the sequence number 
			of the event at the returned index.

 RETURNS:   void
------------------------------------------------------------------------*/
signed int LotProcessing_eventAdd(LotProcessing* pLotProc)
{
	signed int nReturnIndex;
	LotProcEvent* pLotProcEvent;

	nReturnIndex = -1;
	pLotProcEvent = NULL;

	// Get the carrier board at the tail index and then update the tail.
	if ( NULL != pLotProc )
	{
		if ( pLotProc->m_events.m_count < MAX_CARRIER_EVENT_COUNT )
		{
			if ( (pLotProc->m_events.m_tailIndex >= 0) &&
				(pLotProc->m_events.m_tailIndex < MAX_CARRIER_EVENT_COUNT) )
			{
				pLotProc->m_events.m_tailIndex = (pLotProc->m_events.m_headIndex + pLotProc->m_events.m_count) % MAX_CARRIER_EVENT_COUNT;
				pLotProc->m_events.m_count++;

				pLotProcEvent = &(pLotProc->m_events.m_array[ pLotProc->m_events.m_tailIndex ]);
				pLotProcEvent->inUse = TRUE;
				pLotProcEvent->eventSeqNum = pLotProc->m_events.m_sequenceNum;

				pLotProc->m_events.m_sequenceNum++;

				nReturnIndex = pLotProc->m_events.m_tailIndex;
			}
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotAbort

 			Returns TRUE if the lot specified by lotID was aborted, FALSE
				if the lot was not found.

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL LotProcessing_lotAbort(LotProcessing* pLotProc, WORD lotID)
{
	BOOL retval;
	signed int i;

	retval = FALSE;
	i = 0;

	for (i = 0; (!retval) && (i < MAX_LOT_COUNT); ++i)
	{
		// skip it if it's not in use
		if (pLotProc->m_lot[i].m_bInUse)
		{
			// this is the lot we are looking for?
			if (lotID == pLotProc->m_lot[i].m_lotId)
			{
				// set the abort early flag
				pLotProc->m_lot[i].m_bAbortEarly = TRUE;
				// found it, we should return success
				retval = TRUE;

			}
		}
	}

	return retval;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotAdd

			Returns the index of the added lot, or -1.
			Sets the in-use flag and the data of the lot at the returned index.

 RETURNS:   int
------------------------------------------------------------------------*/
signed int LotProcessing_lotAdd(LotProcessing* pLotProc, WORD lotID, WORD count )
{
	signed int nReturnIndex;
	Lot* pLot;

	nReturnIndex = -1;
	pLot = NULL;

	if ( NULL != pLotProc )
	{
		if ( pLotProc->m_lotCount < MAX_LOT_COUNT )
		{
			if ( (pLotProc->m_lotTailIndex >= 0) &&
				(pLotProc->m_lotTailIndex < MAX_LOT_COUNT) )
			{
				pLotProc->m_lotTailIndex = (pLotProc->m_lotHeadIndex + pLotProc->m_lotCount) % MAX_LOT_COUNT;
				pLotProc->m_lotCount++;

				pLot = &(pLotProc->m_lot[ pLotProc->m_lotTailIndex ]);
				pLot->m_bInUse = TRUE;
				pLot->m_lotId = lotID;
				pLot->m_expectedCount = count;

				nReturnIndex = pLotProc->m_lotTailIndex;
			}
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotRemoveByIndex

			Removes the lot at any index.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_lotRemoveByIndex(LotProcessing* pLotProc, UINT index)
{
	Lot* pLot;
	Lot* pSourceLot;
	BOOL bInvalidLot;
	BOOL bCopy;
	BOOL bTail;
	UINT copyID;

	pLot = NULL;
	pSourceLot = NULL;
	bInvalidLot = FALSE;
	bCopy = FALSE;
	bTail = FALSE;
	copyID = 0;

	if ( NULL != pLotProc )
	{
		if ( pLotProc->m_lotCount > 0 )
		{
			if ( (index >= 0) &&
				(index < MAX_LOT_COUNT) )
			{
				pLot = &(pLotProc->m_lot[ index ]);

				bInvalidLot = (pLot->m_lotId == LOTPROC_INVALID_LOT);
				Lot_init( pLot, bInvalidLot ); // reset the data
				if(index == pLotProc->m_lotHeadIndex)//we must increment the head possibly more than once
				{
					pLotProc->m_lotHeadIndex++;
					pLot = &(pLotProc->m_lot[ pLotProc->m_lotHeadIndex ]);
					while((pLot->m_bInUse == FALSE) && 
						  (pLotProc->m_lotHeadIndex != pLotProc->m_lotTailIndex))
					{
						pLotProc->m_lotHeadIndex++;
						if ( pLotProc->m_lotHeadIndex >= MAX_LOT_COUNT )
						{
							pLotProc->m_lotHeadIndex = 0;
						}
						pLot = &(pLotProc->m_lot[ pLotProc->m_lotHeadIndex ]);
					};
				}
				else if(index == pLotProc->m_lotTailIndex)
				{
					bTail = TRUE;
				}
				else
				{
					//defrag routine, no carriers in these lots yet, just copy critical variables
					//note this routine assumes max lots of 3, if the number is adjusted the routine will need to transverse
					//the entire buffer
					bTail = TRUE;
					copyID = (index + 1);
					if(copyID >= MAX_LOT_COUNT)
					{
						copyID = 0;
					}
					pSourceLot = &(pLotProc->m_lot[copyID]);
					pLot->m_bInUse = pSourceLot->m_bInUse;
					pLot->m_lotId = pSourceLot->m_lotId;
					pLot->m_expectedCount = pSourceLot->m_expectedCount;
					Lot_init( pSourceLot,bInvalidLot ); // reset the data on the source
				}

				pLotProc->m_lotCount--;

				if ( pLotProc->m_lotHeadIndex >= MAX_LOT_COUNT )
				{
					pLotProc->m_lotHeadIndex = 0;
				}

				if ( pLotProc->m_lotCount == 0 )
				{
					pLotProc->m_lotTailIndex = pLotProc->m_lotHeadIndex;
				}

				if(bTail)
				{
					if(pLotProc->m_lotTailIndex != 0)
					{
						pLotProc->m_lotTailIndex--;
					}
					else
					{
						pLotProc->m_lotTailIndex = (MAX_LOT_COUNT - 1);
					}
				}

			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotRemove

			Removes the lot at the head.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_lotRemove(LotProcessing* pLotProc )
{
	Lot* pLot;
	BOOL bInvalidLot;

	pLot = NULL;
	bInvalidLot = FALSE;

	if ( NULL != pLotProc )
	{
		if ( pLotProc->m_lotCount > 0 )
		{
			if ( (pLotProc->m_lotHeadIndex >= 0) &&
				 (pLotProc->m_lotHeadIndex < MAX_LOT_COUNT) )
			{
				pLot = &(pLotProc->m_lot[ pLotProc->m_lotHeadIndex ]);

				bInvalidLot = (pLot->m_lotId == LOTPROC_INVALID_LOT);
				Lot_init( pLot, bInvalidLot ); // reset the data

				pLotProc->m_lotHeadIndex++;
				pLotProc->m_lotCount--;

				if ( pLotProc->m_lotHeadIndex >= MAX_LOT_COUNT )
				{
					pLotProc->m_lotHeadIndex = 0;
				}

				if ( pLotProc->m_lotCount == 0 )
				{
					pLotProc->m_lotTailIndex = pLotProc->m_lotHeadIndex;
				}
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotGetCurrentLot

			Returns index of valid lot, or -1 if no lots available.

			This function will run through all defined lots (from head to tail)
			and only return the valid lot that has carriers left to add
			and which does not have its bAbortEarly flag set.

			A return of -1 does not necessarily mean there are not lots defined.
			We could have 1-or-more lots defined but all the lots are currently
			awaiting deletion.

 RETURNS:   int
------------------------------------------------------------------------*/
signed int LotProcessing_lotGetCurrentLot(LotProcessing* pLotProc)
{
	int nReturnIndex;
	Lot* pLot;
	int index;
	int i;

	nReturnIndex = -1;
	pLot = NULL;
	index = 0;
	i = 0;

	if ( NULL != pLotProc )
	{
		//
		// Iterate through the lots from head to tail 
		// (and around the bend as necessary) looking for an available lot.
		//
		index = pLotProc->m_lotHeadIndex;

		for ( i = 0; (i < MAX_LOT_COUNT) && (nReturnIndex == -1); i++ )
		{
			pLot = &(pLotProc->m_lot[ index ]);

			if ( (pLot->m_bInUse == TRUE)
				&& (pLot->m_bAbortEarly == FALSE)
				&& (pLot->m_carrier.m_count < pLot->m_expectedCount) )
			{
				nReturnIndex = index;
			}

			index++;
			if ( index >= MAX_LOT_COUNT )
			{
				index = 0;
			}
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_lotGetInvalidLot

			Returns index of invalid lot, should never returns -1.

 RETURNS:   int
------------------------------------------------------------------------*/
signed int LotProcessing_lotGetInvalidLot(LotProcessing* pLotProc)
{

	int nReturnIndex;
	int i;
	Lot* pLot;
	UINT iterator;
	UINT lotIndex;

	nReturnIndex = -1;
	i = 0;
	pLot = NULL;
	iterator = 0;
	lotIndex = 0;

	if ( NULL != pLotProc )
	{
		lotIndex = pLotProc->m_lotInvalidIndex; 
		while ( (nReturnIndex == -1) &&
				(iterator < MAX_INVALID_LOT) )
		{
			if ( lotIndex >= MAX_INVALID_LOT )
			{
				lotIndex = 0;
			}

			// Check the current lot in use for an empty spot.
			pLot = &(pLotProc->m_lotInvalid[ lotIndex ]);

			if( NULL != pLot )
			{
				if ( pLot->m_carrier.m_count < pLot->m_expectedCount )
				{
					nReturnIndex = lotIndex;
				}
				else
				{
					// This lot is full.  Try the next lot.
					lotIndex++;
				}
			}
			
			iterator++;
		}

		// Set the new lot index in use.
		if ( (nReturnIndex != -1)
			&& (nReturnIndex != pLotProc->m_lotInvalidIndex) )
		{
			pLotProc->m_lotInvalidIndex = nReturnIndex;
		}
	}

	return nReturnIndex;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_getCarrierByBoard

			Runs through all of the lots and checks for a carrier
			that is associated with the Board. 
			Returns TRUE if Board has an associated carrier.

 RETURNS:   CarrierBoard*
------------------------------------------------------------------------*/
CarrierBoard* LotProcessing_getCarrierByBoard( LotProcessing* pLotProc, Board* pBoard )
{
	BOOL bReturn;
	signed int i;
	signed int nCarrierIndex;
	Lot* pLot;
	CarrierBoard* pCarrier;

	bReturn = FALSE;
	i = 0;
	nCarrierIndex = -1;
	pLot = NULL;
	pCarrier = NULL;

	if ( NULL != pLotProc && 
		 NULL != pBoard )
	{
		// Look at the valid lots first.
		for ( i = 0; (i < MAX_LOT_COUNT) && (bReturn == FALSE); i++ )
		{
			pLot = &(pLotProc->m_lot[i]);
			if ( pLot->m_bInUse )
			{
				nCarrierIndex = Lot_carrierGetByBoard( pLot, pBoard );
				if ( nCarrierIndex != -1 )
				{
					bReturn = TRUE;
					pCarrier = &(pLot->m_carrier.m_boards[nCarrierIndex]);
				}
			}
		}

		if ( bReturn == FALSE )
		{
			// Still haven't found it.  
			// Check the invalid lots.
			for ( i = 0; (i < MAX_INVALID_LOT) && (bReturn == FALSE); i++ )
			{
				pLot = &(pLotProc->m_lotInvalid[i]);
				if ( pLot->m_bInUse )
				{
					nCarrierIndex = Lot_carrierGetByBoard( pLot, pBoard );
					if ( nCarrierIndex != -1 )
					{
						bReturn = TRUE;
						pCarrier = &(pLot->m_carrier.m_boards[nCarrierIndex]);
					}
				}
			}
		}
	}

	return pCarrier;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_boardHasAssociatedCarrier

			Runs through all of the lots and checks for a carrier
			that is associated with the Board. 
			Returns TRUE if Board has an associated carrier.

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL LotProcessing_boardHasAssociatedCarrier( LotProcessing* pLotProc, Board* pBoard )
{
	BOOL bReturn;
	signed int i;
	signed int nCarrierIndex;
	Lot* pLot;

	bReturn = FALSE;
	i = 0;
	nCarrierIndex = -1;
	pLot = NULL;

	if ( NULL != pLotProc && 
		 NULL != pBoard )
	{
		// Look at the valid lots first.
		for ( i = 0; (i < MAX_LOT_COUNT) && (bReturn == FALSE); i++ )
		{
			pLot = &(pLotProc->m_lot[i]);
			if ( pLot->m_bInUse )
			{
				nCarrierIndex = Lot_carrierGetByBoard( pLot, pBoard );
				if ( nCarrierIndex != -1 )
				{
					bReturn = TRUE;
				}
			}
		}

		if ( bReturn == FALSE )
		{
			// Still haven't found it.  
			// Check the invalid lots.
			for ( i = 0; (i < MAX_INVALID_LOT) && (bReturn == FALSE); i++ )
			{
				pLot = &(pLotProc->m_lotInvalid[i]);
				if ( pLot->m_bInUse )
				{
					nCarrierIndex = Lot_carrierGetByBoard( pLot, pBoard );
					if ( nCarrierIndex != -1 )
					{
						bReturn = TRUE;
					}
				}
			}
		}
	}

	return bReturn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_checkForNewBoards

			Check for newly entered boards.  
			Add CarrierBoards for each new Board encountered
			and associate the Board pointer.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_checkForNewBoards( LotProcessing* pLotProc, newBoardQueue* pNBQ )
{
	Board* pBoard;
	CarrierBoard* pCarrier;
	Lot* pLot;
	signed int lotIndex;
	signed int board_index;
	signed int i;
	signed int nCarrierIndex;
	BOOL bFoundCarrier;

	pBoard = NULL;
	pCarrier = NULL;
	pLot = NULL;
	lotIndex = -1;
	board_index = 0;
	i = 0;
	nCarrierIndex = -1;
	bFoundCarrier = FALSE;

	if ( NULL != pLotProc && 
		 NULL != pNBQ )
	{
		//
		// Iterate through the newBoardQueue's boards from head to tail 
		// (and around the bend as necessary) looking for newly entered boards.
		//
		board_index = pNBQ->headIndex;

		for ( i = 0; i < MaxBoards; i++  )
		{
			pBoard = &(pNBQ->boards[board_index]);

			if ( pBoard->bInUse && !pBoard->hasCarrier)
			{
				// Search for an associated carrier for the board.
				bFoundCarrier = LotProcessing_boardHasAssociatedCarrier( pLotProc, pBoard );

				if ( bFoundCarrier == FALSE )
				{
					// For each iteration get the Current Lot.
					// We need to make sure we count the new carrier's correctly
					// and move to the next valid lot when the expected count has been reached.
					// If we run out of valid lots, use the invalid lot.
					lotIndex = LotProcessing_lotGetCurrentLot( pLotProc );

					if ( lotIndex >= 0 )
					{
						pLot = &(pLotProc->m_lot[lotIndex]);
					}
					else
					{
						// Get the invalid lot.
						lotIndex = LotProcessing_lotGetInvalidLot( pLotProc );

						if( lotIndex >= 0 && lotIndex < MAX_INVALID_LOT )
						{
							pLot = &(pLotProc->m_lotInvalid[lotIndex]);
						}
					}

					/* if neither a valid lot or invalid lot are
					   located for this carrier, pLot will
					   remain NULL from the initialization of
					   the pointer.
					*/
					if( NULL != pLot )
					{
						// New Board.  Add a carrier for it.
						nCarrierIndex = Lot_carrierAdd( pLot );
						if ( nCarrierIndex >= 0 && nCarrierIndex < MaxBoards )
						{
							pCarrier = &(pLot->m_carrier.m_boards[nCarrierIndex]);

							pCarrier->m_pBoard = pBoard;
							pCarrier->m_lane = pNBQ->boardQId;

							pCarrier->m_lotID = pLot->m_lotId;
							pCarrier->m_carrierIndex = pLot->m_carrier.m_count;
							pBoard->hasCarrier = TRUE;

						}
					}
				}
			}

			board_index++;
			if ( board_index >= MaxBoards )
			{
				board_index = 0;
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_checkForNewEvents

			Run through all the CarrierBoards and compare their
			timestamps to their associated Board's timestamps.  If we
			find a new timestamp create the correct carrier event.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_checkForNewEvents( LotProcessing* pLotProc )
{
	CarrierBoard* pCarrier;
	Board* pBoard;
	LotProcEvent* pEvent;
	Lot* pLot;
	signed int lotIndex;
	signed int nEventIndex;
	signed int i;
	signed int carrier_index;
	signed int carrier_end;
	BOOL bCoolDown;
	signed int countAllLots;;
	Lot* lotArray[MAX_INVALID_LOT + MAX_LOT_COUNT] = { NULL };

	pCarrier = NULL;
	pBoard = NULL;
	pEvent = NULL;
	pLot = NULL;
	lotIndex = -1;
	nEventIndex = 0;
	i = 0;
	carrier_index = 0;
	carrier_end = 0;
	bCoolDown = (g_dbContainer.ovenDb.jobNo == COOLDOWN);

	// Copy all the lot pointers into a single pointer array so 
	// that we can iterate through the lots in a simple manner.
	countAllLots = MAX_INVALID_LOT + MAX_LOT_COUNT;

	lotIndex = 0;

	for ( i = 0; i < MAX_LOT_COUNT; i++ )
	{
		lotArray[lotIndex] = &(pLotProc->m_lot[i]);
		lotIndex++;
	}

	for ( i = 0; i < MAX_INVALID_LOT; i++ )
	{
		lotArray[lotIndex] = &(pLotProc->m_lotInvalid[i]);
		lotIndex++;
	}

	if ( NULL != pLotProc )
	{
		//
		// Iterate through all the lots and then through each lot's carrier boards 
		// from head to tail (and around the bend as necessary) looking for updated time stamps.
		//

		for ( lotIndex = 0; lotIndex < countAllLots; lotIndex++ )
		{
			pLot = lotArray[lotIndex];

			if ( pLot->m_bInUse )
			{
				carrier_index = pLot->m_carrier.m_headIndex;
				for ( i = 0; i < MaxBoards; i++ )
				{
					pCarrier = &(pLot->m_carrier.m_boards[carrier_index]);

					if ( pCarrier->m_bInUse 
						&& pCarrier->m_pBoard )
					{
						pBoard = pCarrier->m_pBoard;

						// Entry Leading Edge
						if ( (pCarrier->timeStamps.bValidEntryLeading == FALSE)
							&& pBoard->timeStamps.bValidEntryLeading )
						{
							// Create the event.
							nEventIndex = LotProcessing_eventAdd( pLotProc );
							if ( nEventIndex >= 0 )
							{
								// Copy the board time stamp to the carrier board.
								LocalTime_copy( &(pBoard->timeStamps.entryLeadingEdge), &(pCarrier->timeStamps.entryLeadingEdge) );
								pCarrier->timeStamps.bValidEntryLeading = TRUE;

								// upate the event data.
								pEvent = &(pLotProc->m_events.m_array[nEventIndex]);

								pEvent->highTime = pCarrier->timeStamps.entryLeadingEdge.dwHigh;
								pEvent->lowTime = pCarrier->timeStamps.entryLeadingEdge.dwLow;
								pEvent->milliseconds = pCarrier->timeStamps.entryLeadingEdge.dwMilli;

								pEvent->lotID = pCarrier->m_lotID;
								pEvent->carrierIndex = pCarrier->m_carrierIndex;
								pEvent->lane = pCarrier->m_lane;

								pEvent->entryExit = LOTPROC_BOARD_ENTRANCE;
								pEvent->position = LOTPROC_POS_LEADING;

								// don't need the lot information for invalid lots
								if ( pCarrier->m_lotID != LOTPROC_INVALID_LOT )
								{
									if ( pCarrier->m_carrierIndex == 1 )
									{
										pEvent->lotStart = TRUE;
									}
								}

								if ( bCoolDown || pBoard->bCooldown )
								{
									pEvent->cooldown = TRUE;
								}

								// Update the lot status variables.
								if ( pLot )
								{
									(pLot->m_nInOvenCount)++;
								}

							}
						}

						// Entry Trailing Edge
						if ( (pCarrier->timeStamps.bValidEntryTrailing == FALSE)
							&& pBoard->timeStamps.bValidEntryTrailing )
						{
							// Create the event.
							nEventIndex = LotProcessing_eventAdd( pLotProc );
							if ( nEventIndex >= 0 )
							{
								// Copy the board time stamp to the carrier board.
								LocalTime_copy( &(pBoard->timeStamps.entryTrailingEdge), &(pCarrier->timeStamps.entryTrailingEdge) );
								pCarrier->timeStamps.bValidEntryTrailing = TRUE;

								// upate the event data.
								pEvent = &(pLotProc->m_events.m_array[nEventIndex]);

								pEvent->highTime = pCarrier->timeStamps.entryTrailingEdge.dwHigh;
								pEvent->lowTime = pCarrier->timeStamps.entryTrailingEdge.dwLow;
								pEvent->milliseconds = pCarrier->timeStamps.entryTrailingEdge.dwMilli;

								pEvent->lotID = pCarrier->m_lotID;
								pEvent->carrierIndex = pCarrier->m_carrierIndex;
								pEvent->lane = pCarrier->m_lane;

								pEvent->entryExit = LOTPROC_BOARD_ENTRANCE;
								pEvent->position = LOTPROC_POS_TRAILING;


								// don't need the lot information for invalid lots
								if ( pLot->m_lotId != LOTPROC_INVALID_LOT )
								{
									if ( (pCarrier->m_carrierIndex == pLot->m_expectedCount)
										|| pLot->m_bAbortEarly )
									{
										pEvent->lastEnter = TRUE;
									}
								}

								if ( bCoolDown || pBoard->bCooldown )
								{
									pEvent->cooldown = TRUE;
								}

							}
						}

						// Exit Leading Edge
						if ( (pCarrier->timeStamps.bValidExitLeading == FALSE)
							&& pBoard->timeStamps.bValidExitLeading )
						{
							// Create the event.
							nEventIndex = LotProcessing_eventAdd( pLotProc );
							if ( nEventIndex >= 0 )
							{
								// Copy the board time stamp to the carrier board.
								LocalTime_copy( &(pBoard->timeStamps.exitLeadingEdge), &(pCarrier->timeStamps.exitLeadingEdge) );
								pCarrier->timeStamps.bValidExitLeading = TRUE;

								// upate the event data.
								pEvent = &(pLotProc->m_events.m_array[nEventIndex]);

								pEvent->highTime = pCarrier->timeStamps.exitLeadingEdge.dwHigh;
								pEvent->lowTime = pCarrier->timeStamps.exitLeadingEdge.dwLow;
								pEvent->milliseconds = pCarrier->timeStamps.exitLeadingEdge.dwMilli;

								pEvent->lotID = pCarrier->m_lotID;
								pEvent->carrierIndex = pCarrier->m_carrierIndex;
								pEvent->lane = pCarrier->m_lane;

								pEvent->entryExit = LOTPROC_BOARD_EXIT;
								pEvent->position = LOTPROC_POS_LEADING;
								if ( pCarrier->m_pBoard->bBoardDropped )
								{
									// overwrite the position
									pEvent->position = LOTPROC_POS_DROPPED_LEAD;
								}
								if ( bCoolDown || pBoard->bCooldown )
								{
									pEvent->cooldown = TRUE;
								}


							}
						}

						// Exit Trailing Edge
						if ( (pCarrier->timeStamps.bValidExitTrailing == FALSE)
							&& pBoard->timeStamps.bValidExitTrailing )
						{
							// Create the event.
							nEventIndex = LotProcessing_eventAdd( pLotProc );
							if ( nEventIndex >= 0 )
							{
								// Copy the board time stamp to the carrier board.
								LocalTime_copy( &(pBoard->timeStamps.exitTrailingEdge), &(pCarrier->timeStamps.exitTrailingEdge) );
								pCarrier->timeStamps.bValidExitTrailing = TRUE;

								// upate the event data.
								pEvent = &(pLotProc->m_events.m_array[nEventIndex]);

								pEvent->highTime = pCarrier->timeStamps.exitTrailingEdge.dwHigh;
								pEvent->lowTime = pCarrier->timeStamps.exitTrailingEdge.dwLow;
								pEvent->milliseconds = pCarrier->timeStamps.exitTrailingEdge.dwMilli;
								pEvent->lotID = pCarrier->m_lotID;
								pEvent->carrierIndex = pCarrier->m_carrierIndex;
								pEvent->lane = pCarrier->m_lane;

								pEvent->entryExit = LOTPROC_BOARD_EXIT;
								pEvent->position = LOTPROC_POS_TRAILING;

								if ( pCarrier->m_pBoard )
								{
									if ( pCarrier->m_pBoard->bBoardDropped )
									{
										// overwrite the position
										pEvent->position = LOTPROC_POS_DROPPED;
									}
								}

								// don't need the lot information for invalid lots
								if ( pLot->m_lotId != LOTPROC_INVALID_LOT )
								{
									if ( pCarrier->m_carrierIndex == 1 )
									{
										pEvent->firstExit = TRUE;
									}
									
									//(carrier_index==pLot->m_carrier.m_tailIndex) was added due to all 
									//carriers on a lot stop reporting as end of lot
									if ( (pCarrier->m_carrierIndex == pLot->m_expectedCount) ||
										 (pLot->m_bAbortEarly && (carrier_index==pLot->m_carrier.m_tailIndex)) )
									{
										pEvent->lotEnd = TRUE;
									}
								}

								if ( bCoolDown || pBoard->bCooldown )
								{
									pEvent->cooldown = TRUE;
								}

								// Update the lot status variables.
								if ( pLot )
								{
									(pLot->m_nInOvenCount)--;
									(pLot->m_nProcessedCount)++;
								}

							
							}
						}

						// Now that all the time-stamps have been copied from the Board,
						// reset the Board pointer.  We don't need it anymore.  The newBoardQueue
						// will be "deleting" this board soon anyways.
						if ( pCarrier->timeStamps.bValidExitLeading &&
							pCarrier->timeStamps.bValidExitTrailing )
						{
							pCarrier->m_pBoard = NULL;
						}
					}

					carrier_index++;
					if ( carrier_index >= MaxBoards )
					{
						carrier_index = 0;
					}
				}
			}
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  LotProcessing_clearCompletedLots

			Run through the defined and invalid lots and remove 
			those lots that are aborted-early or filled.

 RETURNS:   void
------------------------------------------------------------------------*/
void LotProcessing_clearCompletedLots( LotProcessing* pLotProc )
{
	Lot* pLot;
	UINT index;
	int i;
	int counter;
	BOOL bContinue;
	BOOL bDelete;

	pLot = NULL;
	index = 0;
	i = 0;
	counter = 0;
	bContinue = TRUE;
	bDelete = FALSE;

	if ( NULL != pLotProc )
	{
		// Valid lots are defined dynamically.  
		// While the lot at the head is defined
		// and complete delete it and move
		// on to the next lot (deletion resets head index).
		// Stop deletion when we arrive at an undefined lot
		// or one that is not-complete.
		// Just to be sure we don't get stuck in an infinite-loop
		// never iterate more than the defined number of lots.
		index = pLotProc->m_lotHeadIndex;
		while ( counter < MAX_LOT_COUNT )
		{
			pLot = &(pLotProc->m_lot[ index ]);
			if ( pLot->m_bInUse )
			{
				bDelete = FALSE;

				if ( pLot->m_bAbortEarly && 
					(pLot->m_nInOvenCount == 0) )
				{
					bDelete = TRUE;
				}
				else if ( pLot->m_carrier.m_count 
					&& (pLot->m_carrier.m_count >= pLot->m_expectedCount)
					&& (pLot->m_nInOvenCount == 0) )
				{
					bDelete = TRUE;
				}

				if ( bDelete )
				{
					LotProcessing_lotRemoveByIndex( pLotProc, index );
				}

			}
		
			counter++;
			index++;
			if ( index >= MAX_LOT_COUNT )
			{
				index = 0;
			}
		}

		// Invalid lots are not created dynamically.
		// No need to run through a circular array.
		// Delete the completed lots, and be sure to reinitialize
		// it so that we can reuse it.
		for ( i = 0; i < MAX_INVALID_LOT; i++ )
		{
			pLot = &(pLotProc->m_lotInvalid[i]);
			if( NULL != pLot )
			{
				if ( pLot->m_carrier.m_count 
					&& (pLot->m_carrier.m_count >= pLot->m_expectedCount)
					&& (pLot->m_nInOvenCount == 0) )
				{
					Lot_init( pLot, TRUE );
				}
			}
		}
	}

	return;
}
