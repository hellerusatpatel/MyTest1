/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
//flasher.h
/******************************************************************************
 class Flasher

 Abstract:
 The various alarm and warning conditions will flash the light tower. This will
 be set to change state from off to on and off again in half second intervals.
 The update flash  will be called on each interrupt of the scheduler, upon
 reaching a count of 512 change the state of the counter.

 Programmer: Steven Young
 Date: 05/03/1998
******************************************************************************/
#ifndef __FLASHER__
#define __FLASHER__

#include "typedefdefine.h"
#include "litetowr.h"

enum Flasher_States{ Flasher_OFF=0, Flasher_ON=1};

typedef struct _Flasher_
{
//private:

	// The flasherColor corresponds to the user choosen oven state.
	// This color can either be set to SOLID (m_bFlasherEnabled == FALSE)
	// or FLASHING (m_bFlasherEnabled == TRUE). 
	enum Light_States	flasherColor;

	// The state variable determines whether the light is on or off when the flasher
	// is enabled.
	BOOL state;
	BOOL m_bFlasherEnabled;

	BOOL m_bAudibleAlarm;

	unsigned int cycleCount;
} Flasher;

void Flasher_init(Flasher* pFlasher, enum Light_States color, BOOL bFlasherEnable, BOOL bAudibleAlarm);		// constructor
void Flasher_process(Flasher* pFlasher);

BOOL Flasher_getFlashState(Flasher* pFlasher);

void Flasher_enableFlasher(Flasher* pFlasher, BOOL bEnable);

void Flasher_setFlasherColor(Flasher* pFlasher, enum Light_States flasherColor);
enum Light_States Flasher_GetFlasherColor(Flasher* pFlasher);

void Flasher_setAudibleAlarm(Flasher* pFlasher, BOOL bAudibleAlarm);
BOOL Flasher_getAudibleAlarm(Flasher* pFlasher);

#endif

