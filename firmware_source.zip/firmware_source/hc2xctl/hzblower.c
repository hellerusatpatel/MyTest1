/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			hzblower.c

	Description:	blower file

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "hzblower.h"
#include "oven.h"
#include "digitio.h"
#include "hc2xio_exports.h"
#include "rails.h"

extern DbContainer g_dbContainer;

ANALOGOUT 		* analogOutDb;
Oven 			* ovenDb;
Timer			*elapseTimer;
int iTestFanPath = 0;
int iTPOTest = 0;	

#define IE_LEVEL_LOW 0
#define IE_LEVEL_MED 1
#define IE_LEVEL_HI 2
#define IE_LEVEL_INVALID 3

#define STANDBY_TIME 150

//******************************************************************************
// class HeatZoneBlowers
//
// Abstract:
// Constructor for the Heat Zone Blower Configuration.
//
// Programmer: Steven Young
// Date: 07/12/1999
//******************************************************************************
void HeatZoneBlowers_init(HeatZoneBlowers* pHeatZoneBlowers)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_init");
	int lcv = 0;
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	iTestFanPath = 0;
	for ( lcv = 0; lcv < MAX_HEAT_ZONE_BLOWERS; lcv++ )
	{
		pHeatZoneBlowers->enabled[lcv] = FALSE;
	}
	pHeatZoneBlowers->flushTime = 150;
	pHeatZoneBlowers->jobNo = 0;
	pHeatZoneBlowers->startTime = 0;
	elapseTimer	= &( g_dbContainer.elapseTimer	);
	for ( lcv = 0; lcv < MAX_HEAT_ZONE_BLOWERS; lcv++ )
	{
		pHeatZoneBlowers->TPOBlowerPercent[lcv] = 0;
		pHeatZoneBlowers->controlType[lcv] = CLASSIC_BLOWERS;
		pHeatZoneBlowers->runLevel[MAX_HEAT_ZONE_BLOWERS]=RUN_LEVEL_LOW;
		pHeatZoneBlowers->standbyTime[lcv]=tim;
		pHeatZoneBlowers->lastStepTime[lcv] = tim;
		pHeatZoneBlowers->m_bInStandby[lcv]=FALSE;
		pHeatZoneBlowers->currentIELevel[lcv] = IE_LEVEL_INVALID;
		pHeatZoneBlowers->m_dwrdMaximum[lcv] = MAXIMUM_PERCENTAGE;
		pHeatZoneBlowers->m_charBounded[lcv] = 0;
	}
	pHeatZoneBlowers->controlType[3] = STANDBY_BLOWERS;
	for ( lcv = 0; lcv < MAX_SMEMA_LANES; lcv++ )
	{
		pHeatZoneBlowers->ieRequestLevel[lcv]=RUN_LEVEL_LOW;
	}

	analogOutDb	 = &( g_dbContainer.analogOutDb	);
	ovenDb	 = &( g_dbContainer.ovenDb	);
	pHeatZoneBlowers->bInStartupMode = TRUE;
	pHeatZoneBlowers->startupAlg = 0;
	pHeatZoneBlowers->ssTime = Timer_getCurrentTime10ths(elapseTimer);
	pHeatZoneBlowers->bFlush2 = FALSE;
	pHeatZoneBlowers->m_bFlush = FALSE;

	for( lcv = 0; lcv > MAX_BLOWERS_INCLUDING_FANS; lcv++)
	{
		pHeatZoneBlowers->m_bOutOfRangeHigh[lcv] = FALSE;
		pHeatZoneBlowers->m_bOutOfRangeLo[lcv] = FALSE;
	}
	pHeatZoneBlowers->m_uintAutoClean = 0;

	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_process
			
			main process loop for the hz blowers (a-c)

 RETURNS:   void
------------------------------------------------------------------------*/
void HeatZoneBlowers_process(HeatZoneBlowers* pHeatZoneBlowers)
{	
	BOOL bOut;
	BOOL bJobLoadInProgress;
	BOOL bCooldown;
	BOOL bInStandby;
	BOOL bCooldownComplete;

	UINT controltype[MAX_HEAT_ZONE_BLOWERS];
	UINT uiOutput[MAX_HEAT_ZONE_BLOWERS];
	int i;
	WORD maxOutput[MAX_HEAT_ZONE_BLOWERS];
	DWORD tim;

	DWORD dwrdJob;
	DWORD dwrdTimeDifference;

	bOut = FALSE;

	controltype[0] = pHeatZoneBlowers->controlType[0];//to turn ie off temporarily
	controltype[1] = pHeatZoneBlowers->controlType[1];//to turn ie off temporarily
	controltype[2] = pHeatZoneBlowers->controlType[2];//to turn ie off temporarily
	controltype[3] = pHeatZoneBlowers->controlType[3];//to turn ie off temporarily

	uiOutput[0] = TPO_AVAILABLE;
	uiOutput[1] = TPO_FREECL1;
	uiOutput[2] = TPO_FREECL2;
	uiOutput[3] = TPO_AVAILABLE;
	i = 0;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	dwrdJob = Oven_getJob(ovenDb);
	bCooldown = FALSE;
	bInStandby = FALSE;
	bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
	bJobLoadInProgress = Oven_isJobLoadInProgress(ovenDb);
	dwrdTimeDifference = 0;
	for(i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
	{
		//below math max is 0-100 multiply by max output 256.  Add 50 for rounding and divide by 100 to get value 0 to 256
		maxOutput[i] = MAX_TPO_COUNTS;
	}

	if(pHeatZoneBlowers)
	{
		bCooldown = HeatZoneBlowers_IELevelTest(pHeatZoneBlowers);
		bInStandby = HeatZoneBlowers_StandbyModeTest(pHeatZoneBlowers);

		for(i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
		{
			//below math max is 0-100 multiply by max output 256.  Add 50 for rounding and divide by 100 to get value 0 to 256
			maxOutput[i] = ( ( (pHeatZoneBlowers->m_dwrdMaximum[i] * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE);
		}

		if (!bCooldown)
		{
			if(!bJobLoadInProgress)
			{
				for(i = 0; i < MAX_BLOWERS_INCLUDING_FANS; i++)
				{
					if(pHeatZoneBlowers->m_bOutOfRangeHigh[i] == TRUE)
					{
						pHeatZoneBlowers->m_bOutOfRangeHigh[i] = FALSE;
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BLOWER_OUTPUT_OUTOFRANGE_HI, i);
					}
					if(pHeatZoneBlowers->m_bOutOfRangeLo[i] == TRUE)
					{
						pHeatZoneBlowers->m_bOutOfRangeLo[i] = FALSE;
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), WARNING, BLOWER_OUTPUT_OUTOFRANGE_LO, i);
					}
				}
	
			}
			if( dwrdJob != pHeatZoneBlowers->jobNo)
			{
				pHeatZoneBlowers->jobNo = dwrdJob;
				pHeatZoneBlowers->ssTime = pHeatZoneBlowers->startTime =  tim;
				pHeatZoneBlowers->m_bFlush = TRUE;
				pHeatZoneBlowers->bInStartupMode = TRUE;
				if(pHeatZoneBlowers->startupAlg != FALSE)
				{
						Fans_beginFlush2(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan), pHeatZoneBlowers);
				}
			}
			else
			{
				if(pHeatZoneBlowers->m_bFlush)
				{
					dwrdTimeDifference = differenceWithRollover( tim, pHeatZoneBlowers->startTime );
					if ( dwrdTimeDifference < pHeatZoneBlowers->flushTime )
					{
						HeatZoneBlower_StandbyResetForSequencing(pHeatZoneBlowers);
					}
					else
					{
						pHeatZoneBlowers->m_bFlush = FALSE;
					}
				}
				if(pHeatZoneBlowers->startupAlg != FALSE)
				{
					if(pHeatZoneBlowers->bInStartupMode == FALSE)
					{
						if(pHeatZoneBlowers->bFlush2 == TRUE)
						{
							bOut = TempZones_AllZonesSequencedBelowDraw(&(g_dbContainer.tempZonesDb));
							if(bOut)
							{
								Fans_endFlush2(&(g_dbContainer.globalBlower), &(g_dbContainer.analogFan), pHeatZoneBlowers);
							}
						}
					}
					else
					{
						pHeatZoneBlowers->ssTime = tim;
					}
				}
			}
		}
		if(bCooldown || g_dbContainer.heatZoneBlowers.m_uintAutoClean || 
				( g_dbContainer.railsDb.m_bJogOn == TRUE ) )//per Tushar no standby or ie in cooldown
		{
			controltype[0] = CLASSIC_BLOWERS;
			controltype[1] = CLASSIC_BLOWERS;
			controltype[2] = CLASSIC_BLOWERS;
			controltype[3] = CLASSIC_BLOWERS;
		}
		if(ovenDb->m_EnergySaving_IntelExhaust_Enabled==FALSE)
		{
			for(i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
			{
				if(controltype[i]==INTELLIGENT_EXHAUST)
				{
					controltype[i]=CLASSIC_BLOWERS;
				}
			}
		}
		for(i = 0; i < (MAX_HEAT_ZONE_BLOWERS - 1); i++)//FIRST 3 ARE Actual blowers, 4 is a standby mode check
		{
			if ( pHeatZoneBlowers->enabled[i] )
			{
				switch(controltype[i])
				{
					case STANDBY_BLOWERS:
						if(bInStandby != pHeatZoneBlowers->m_bInStandby[i])
						{
							if(bInStandby)
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IN_STANDBY, i);
							}
							else
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, OUT_STANDBY, i);
							}
						}
						pHeatZoneBlowers->m_bInStandby[i] = bInStandby;
	
						if(bInStandby)
						{
							TPO_AddSafeSegment(uiOutput[i], 0x01);
							if(!iTestFanPath)
							{
								*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (ovenDb->m_EnergySaving_StandbyMode1_ZoneSpeed * MAX_TPO_COUNTS + ROUND_FACTOR_TPO) / MAXIMUM_PERCENTAGE;	
							}
						}
						else
						{
							if(pHeatZoneBlowers->m_bFlush)
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								if(!iTestFanPath)
								{
									if(pHeatZoneBlowers->b0100[i]==FALSE)
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = maxOutput[i];
									}
								}
							}
							else if(pHeatZoneBlowers->bFlush2==TRUE)
							{
	
								if(pHeatZoneBlowers->b0100[i]==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = maxOutput[i];
								}
								TPO_AddSafeSegment(uiOutput[i], 0x01);
							}
							else
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								if(!iTestFanPath)
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->TPOBlowerPercent[i]*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
							}
						}
						break;

					case INTELLIGENT_EXHAUST:
						TPO_AddSafeSegment(uiOutput[i], 0x01);
						switch(pHeatZoneBlowers->runLevel[i])
						{
							case RUN_LEVEL_LOW:
								if(!iTestFanPath)
								{
									if(bCooldown==FALSE)
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (ovenDb->m_EnergySaving_StandbyMode1_ExhaustSpeed*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
										pHeatZoneBlowers->currentIELevel[i] = IE_LEVEL_LOW;
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i]*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
										pHeatZoneBlowers->currentIELevel[i] = IE_LEVEL_HI;
									}
								}				
								break;

							case RUN_LEVEL_MEDIUM:
								if(!iTestFanPath)
								{
									if(bCooldown==FALSE)
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (ovenDb->m_EnergySaving_IntelExhaust_Speed * MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
										pHeatZoneBlowers->currentIELevel[i] = IE_LEVEL_MED;
	
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
										pHeatZoneBlowers->currentIELevel[i] = IE_LEVEL_HI;
	
									}
								}			
								break;

							case RUN_LEVEL_HIGH: //fall through
							default:
								if(!iTestFanPath)
								{
									if(pHeatZoneBlowers->b0100[i] == TRUE)
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->TPOBlowerPercent[i]*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
	
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i]*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;	
									}
								}				
								pHeatZoneBlowers->currentIELevel[i] = IE_LEVEL_HI;
								break;
						} 
						break;

					case CLASSIC_BLOWERS: //fall through
					default:
						if(bCooldown)
						{
							if ( bCooldownComplete == FALSE )
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								if(pHeatZoneBlowers->b0100[i]==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = maxOutput[i];
								}
							}
							else
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = 0;
							}
						}
						else
						{
							if(pHeatZoneBlowers->m_bFlush)
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								if(!iTestFanPath)
								{
									if(pHeatZoneBlowers->b0100[i] == FALSE)
									{

										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = ( pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE;
									}
									else
									{

										*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = maxOutput[i];
									}
								}
							}
							else if(pHeatZoneBlowers->bFlush2==TRUE)
							{
								if(pHeatZoneBlowers->b0100[i] == FALSE)
								{

									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = ( pHeatZoneBlowers->HighSetting[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE;
								}
								else
								{

									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = maxOutput[i];
								}
								TPO_AddSafeSegment(uiOutput[i], 0x01);
							}
							else
							{
								TPO_AddSafeSegment(uiOutput[i], 0x01);
								if(!iTestFanPath)
								{
									*ANALOGOUT_GetAt(analogOutDb, uiOutput[i]) = (pHeatZoneBlowers->TPOBlowerPercent[i] * MAX_TPO_COUNTS + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE;
								}
							}
						}
						break;
				}
			}
		}

		switch(controltype[(MAX_HEAT_ZONE_BLOWERS-1)])
		{
			case STANDBY_BLOWERS:
				if(bInStandby != pHeatZoneBlowers->m_bInStandby[(MAX_HEAT_ZONE_BLOWERS-1)])
				{
					Belts_standbyMode(&(g_dbContainer.beltsDb), bInStandby);
					Nitrogen_setStandbyMode(&(g_dbContainer.nitrogen), bInStandby);
					if(bInStandby)
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IN_STANDBY, 5);
					}
					else
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, OUT_STANDBY, 5);
					}
				}
				pHeatZoneBlowers->m_bInStandby[(MAX_HEAT_ZONE_BLOWERS-1)] = bInStandby;
				break;

			case INTELLIGENT_EXHAUST://fall through
			case CLASSIC_BLOWERS:
			default:
				break;

		}
	}
	return;
}

//*****************************************************************************
// class HeatZoneBlowers_getOutputPercent( unsigned int ZoneNo )
//
// Abstract:
//	Get the value of the zone for displaying to the operator interface and saving
//  to the recipe file.
//  
// Programmer: Steven Young
// Date: 07/12/1999
//*****************************************************************************
unsigned int HeatZoneBlowers_getOutputPercent(HeatZoneBlowers* pHeatZoneBlowers, unsigned int ZoneNo )
{
	BOOL status = TRUE;
	int outputPercent;
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "HeatZoneBlowers_getOutputPercent", 0);

	if ( ZoneNo-1 < MAX_HEAT_ZONE_BLOWERS )
	{
		outputPercent = pHeatZoneBlowers->TPOBlowerPercent[ZoneNo-1];
	}
	else
	{
		outputPercent = 0;
		status = FALSE;
	}

	return outputPercent;
}

//*****************************************************************************
// void setEnable( int blowerID, BOOL enable = TRUE )
//
// Abstract:
//
// Enable the heat zone blowers to change the TPO outputs. This option is 
// configurable and the TPO's may be used elsewhere so don't cause a 
// problem by letting these blowers change the values.
//
// Programmer: Steven Young
// Date: 12/01/99

//*****************************************************************************
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_setEnable
			enables execution of processing to drive output

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_setEnable(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, BOOL enable )
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_setEnable");
	if(blowerID < MAX_HEAT_ZONE_BLOWERS)
	{
		pHeatZoneBlowers->enabled[blowerID] = enable; 
	}

	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_getIfHZBlowerIsEnabled
			
			returns whether a blower index is active

 RETURNS:   BOOL indicator of active
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL HeatZoneBlowers_getIfHZBlowerIsEnabled(HeatZoneBlowers* pHeatZoneBlowers, int blowerID)
{
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "HeatZoneBlowers_getIfHZBlowerIsEnabled", 0);
	BOOL bReturn = 0;
	if(blowerID < MAX_HEAT_ZONE_BLOWERS)
	{
		bReturn = pHeatZoneBlowers->enabled[blowerID];
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_setFlushTime

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_setFlushTime(HeatZoneBlowers* pHeatZoneBlowers, DWORD flshTime)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_setFlushTime");
	pHeatZoneBlowers->flushTime = flshTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_setLowSetting

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_setLowSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_setLowSetting");
	pHeatZoneBlowers->LowSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_setMediumSetting

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_setMediumSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_setMediumSetting");
	pHeatZoneBlowers->MediumSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_setHighSetting

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_setHighSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID, UINT uiSetting)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_setHighSetting");
	pHeatZoneBlowers->HighSetting[blowerID-1] = uiSetting;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_getLowSetting

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT HeatZoneBlowers_getLowSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID)
{
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "HeatZoneBlowers_getLowSetting", 0);
	return pHeatZoneBlowers->LowSetting[blowerID-1];
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_getMediumSetting

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT HeatZoneBlowers_getMediumSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID)
{
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "HeatZoneBlowers_getMediumSetting", 0);
	return pHeatZoneBlowers->MediumSetting[blowerID-1];
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_getHighSetting

 GLOBALS:
 RETURNS:   UINT
 SEE ALSO:
------------------------------------------------------------------------*/
UINT HeatZoneBlowers_getHighSetting(HeatZoneBlowers* pHeatZoneBlowers, int blowerID)
{
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "HeatZoneBlowers_getHighSetting", 0);
	return pHeatZoneBlowers->HighSetting[blowerID-1];
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_testTPOPath

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_testTPOPath(int iTest)
{
	iTestFanPath = iTest;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_IELevelTest

			Determines if the blower is in ie mode

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL HeatZoneBlowers_IELevelTest(HeatZoneBlowers* pHeatZoneBlowers)
{
	int lcv;
	DWORD tim;
	BOOL bReturn;
	DWORD dwrdJob;
	DWORD dwrdDiff;

	dwrdDiff = 0;
	lcv = 0;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	bReturn = FALSE;
	dwrdJob = Oven_getJob(ovenDb);

	if(pHeatZoneBlowers)
	{
		if(dwrdJob == COOLDOWN) //IE not allowed in cooldown
		{
			bReturn = TRUE;
		}
		else if(pHeatZoneBlowers->m_uintAutoClean || ( g_dbContainer.railsDb.m_bJogOn == TRUE ) )//autoclean or exercise
		{
			bReturn = FALSE;  //These jobs do not allow IE or standby
		}
		else
		{
			for ( lcv = 0; lcv < MAX_HEAT_ZONE_BLOWERS; lcv++ )
			{
				if(pHeatZoneBlowers->controlType[lcv] == INTELLIGENT_EXHAUST)
				{
					if( ( pHeatZoneBlowers->ieRequestLevel[0] == RUN_LEVEL_HIGH ) || ( pHeatZoneBlowers->ieRequestLevel[1] == RUN_LEVEL_HIGH ) ||
						( pHeatZoneBlowers->ieRequestLevel[2] == RUN_LEVEL_HIGH ) )
					{
						if( ( pHeatZoneBlowers->runLevel[lcv]!=RUN_LEVEL_HIGH ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
						{
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_HIGH_LEVEL, lcv);			
						}
						pHeatZoneBlowers->runLevel[lcv]=RUN_LEVEL_HIGH;
						if(pHeatZoneBlowers->controlType[lcv]==INTELLIGENT_EXHAUST)	
						{
							pHeatZoneBlowers->lastStepTime[lcv]=tim;
						}
					}
					else if( ( pHeatZoneBlowers->ieRequestLevel[0] == RUN_LEVEL_MEDIUM ) || ( pHeatZoneBlowers->ieRequestLevel[1] == RUN_LEVEL_MEDIUM ) ||
						( pHeatZoneBlowers->ieRequestLevel[2] == RUN_LEVEL_MEDIUM ) )
					{
						if(pHeatZoneBlowers->runLevel[lcv]==RUN_LEVEL_HIGH)
						{
							dwrdDiff = tim - pHeatZoneBlowers->lastStepTime[lcv];
							if( dwrdDiff > STANDBY_TIME)
							{
								pHeatZoneBlowers->runLevel[lcv] = RUN_LEVEL_MEDIUM;
								if ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) 
								{
									AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, lcv);
								}
							}
						}
						else
						{
							if( (pHeatZoneBlowers->runLevel[lcv] != RUN_LEVEL_MEDIUM ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
							{
								AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, lcv);
							}
							pHeatZoneBlowers->runLevel[lcv] = RUN_LEVEL_MEDIUM;
							if(pHeatZoneBlowers->controlType[lcv] == INTELLIGENT_EXHAUST)	
							{
								pHeatZoneBlowers->lastStepTime[lcv] = tim;
							}
						}
					}
					else if( pHeatZoneBlowers->runLevel[lcv] != RUN_LEVEL_LOW)
					{
						dwrdDiff = tim - pHeatZoneBlowers->lastStepTime[lcv];
						if( dwrdDiff > STANDBY_TIME)
						{
							if( (pHeatZoneBlowers->runLevel[lcv] != RUN_LEVEL_LOW ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) ) 
							{
								AlarmQueue_addAlarm( &( g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_LOW_LEVEL, lcv );
							}
							pHeatZoneBlowers->runLevel[lcv] = RUN_LEVEL_LOW;
						}
					}
				}
			}
		}
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_StandbyModeTest

 			tests whether the hz blower is in standby, produces events

 RETURNS:   BOOL-In standby or not
------------------------------------------------------------------------*/
BOOL HeatZoneBlowers_StandbyModeTest(HeatZoneBlowers* pHeatZoneBlowers)
{
	BOOL bInStandby;
	BOOL bEnergySavingMode;
	DWORD tim;
	signed int i;
	DWORD dwrdJob;
	BOOL bActiveBlower[MAX_HEAT_ZONE_BLOWERS];
	BOOL bBoardQCondition;

	bInStandby = FALSE;
	bEnergySavingMode = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	i = 0;
	dwrdJob = Oven_getJob(ovenDb);
	bBoardQCondition = FALSE;

	for( i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
	{
		bActiveBlower[i] = FALSE;
	}

	if( NULL != pHeatZoneBlowers )
	{
		for( i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
		{
			bActiveBlower[i] = pHeatZoneBlowers->enabled[i];
		}
		bActiveBlower[3] = TRUE;

		if( FALSE == g_bLotProcessingEnable )
		{
			bBoardQCondition = (g_dbContainer.boardQ0_NoLP.boardCount > 0) || (g_dbContainer.boardQ1_NoLP.boardCount > 0) ||
							   (g_dbContainer.boardQ2_NoLP.boardCount > 0) || (g_dbContainer.boardQ3_NoLP.boardCount > 0) ||
							   (dwrdJob == COOLDOWN);
		}
		else
		{
			bBoardQCondition = (g_dbContainer.boardQ0.m_boardCount > 0) || (g_dbContainer.boardQ1.m_boardCount > 0) ||
							   (g_dbContainer.boardQ2.m_boardCount > 0) || (g_dbContainer.boardQ3.m_boardCount > 0) ||
							   (dwrdJob == COOLDOWN);
		}

	
		if( bBoardQCondition )
		{
			bInStandby=FALSE;
			for( i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
			{
				if(pHeatZoneBlowers->controlType[i] == STANDBY_BLOWERS)
				{
					pHeatZoneBlowers->lastStepTime[i] = tim;
				}
			}

		}
		if(pHeatZoneBlowers->bInStartupMode || (pHeatZoneBlowers->bFlush2 == TRUE) )
		{
			HeatZoneBlower_StandbyResetForSequencing(pHeatZoneBlowers);
		}
		if(pHeatZoneBlowers->bInStartupMode || (pHeatZoneBlowers->bFlush2 == TRUE) ||
			(ovenDb->mbEnergyRecipe == TRUE) )
		{
			bInStandby = FALSE;
		}
		else
		{
			i = (MAX_HEAT_ZONE_BLOWERS - 1);////the 4th hz blower is a phantom, only used to write standby
			if((bActiveBlower[i] == TRUE) && (pHeatZoneBlowers->controlType[i] == STANDBY_BLOWERS))
			{	
			
				if( ( tim - pHeatZoneBlowers->lastStepTime[i] ) > pHeatZoneBlowers->standbyTime[i] )//right now all blowers are the same, so we can test just the first
				{
					bInStandby = TRUE;
				}
			}	
		}

		bEnergySavingMode = Oven_sm1(ovenDb);
		if(bEnergySavingMode == FALSE)
		{
			bInStandby = FALSE;
		}
	}

	return bInStandby;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlowers_requestIE

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlowers_requestIE(HeatZoneBlowers* pHeatZoneBlowers, int iRequestIELevel)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_testTPOPath");
	pHeatZoneBlowers->ieRequestLevel[0]=pHeatZoneBlowers->ieRequestLevel[1]=pHeatZoneBlowers->ieRequestLevel[2]=pHeatZoneBlowers->ieRequestLevel[3]=iRequestIELevel;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlower_toggleSMOne
//turns standby mode 1 on/off instantly
//used by start/stop buttons, DI reset in oven class

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlower_toggleSMOne(HeatZoneBlowers* pHeatZoneBlowers, BOOL on)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_toggleSMOne");
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	DWORD assignTime;
	if(on==TRUE)
	{
		if(pHeatZoneBlowers->controlType[0]==STANDBY_BLOWERS)
		{
			assignTime=tim-pHeatZoneBlowers->standbyTime[0];
			pHeatZoneBlowers->lastStepTime[0]=assignTime;
		}
		if(pHeatZoneBlowers->controlType[1]==STANDBY_BLOWERS)
		{
			assignTime=tim-pHeatZoneBlowers->standbyTime[1];
			pHeatZoneBlowers->lastStepTime[1]=assignTime;
		}
		if(pHeatZoneBlowers->controlType[2]==STANDBY_BLOWERS)
		{
			assignTime=tim-pHeatZoneBlowers->standbyTime[2];
			pHeatZoneBlowers->lastStepTime[2]=assignTime;
		}
		if(pHeatZoneBlowers->controlType[3]==STANDBY_BLOWERS)
		{
			assignTime=tim-pHeatZoneBlowers->standbyTime[3];
			pHeatZoneBlowers->lastStepTime[3]=assignTime;
		}
	}
	else
	{
		if(pHeatZoneBlowers->controlType[0]==STANDBY_BLOWERS)
		{
			pHeatZoneBlowers->lastStepTime[0]=tim;
		}
		if(pHeatZoneBlowers->controlType[1]==STANDBY_BLOWERS)
		{
			pHeatZoneBlowers->lastStepTime[1]=tim;
		}
		if(pHeatZoneBlowers->controlType[2]==STANDBY_BLOWERS)
		{
			pHeatZoneBlowers->lastStepTime[2]=tim;
		}

		if(pHeatZoneBlowers->controlType[3]==STANDBY_BLOWERS)
		{
			pHeatZoneBlowers->lastStepTime[3]=tim;
		}
	}

}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  HeatZoneBlower_StandbyResetForSequenceing
//used to reset sb mode 1, 2 and cooldown timers for flush, flush 2, and cooldown
//similar functions(2) in fans


 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void HeatZoneBlower_StandbyResetForSequencing(HeatZoneBlowers* pHeatZoneBlowers)
{
	PARAM_CHECK( pHeatZoneBlowers, "HeatZoneBlowers_StandbyResetForSequencing");

	int i = 0;
	BOOL bActiveBlower[MAX_HEAT_ZONE_BLOWERS];
	for( i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
	{
		bActiveBlower[i] = pHeatZoneBlowers->enabled[i];
	}
	bActiveBlower[3] = TRUE;
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);

	ovenDb->mbDoReset=TRUE; //This should be a global reset

	for(i=0; i<MAX_HEAT_ZONE_BLOWERS; i++)
	{
		if((bActiveBlower[i]==TRUE)&&(pHeatZoneBlowers->controlType[i]==STANDBY_BLOWERS))
		{
			pHeatZoneBlowers->lastStepTime[i]=tim;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_init
			inits the global blower variables
 
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void GlobalBlower_init(GlobalBlower* pGlobalBlower)
{
	PARAM_CHECK( pGlobalBlower, "GlobalBlower_init");


	iTPOTest = 0;
	pGlobalBlower->startTime = 0;
	pGlobalBlower->TPOBlowerPercent = 0;
	pGlobalBlower->jobNo = COOLDOWN;
	pGlobalBlower->enabled = FALSE;
	pGlobalBlower->flushTime = 150;

	analogOutDb	= &( g_dbContainer.analogOutDb	);
	elapseTimer	= &( g_dbContainer.elapseTimer	);
	ovenDb = &( g_dbContainer.ovenDb );
	pGlobalBlower->controlType=CLASSIC_BLOWERS;
	pGlobalBlower->ieRequestLevel=RUN_LEVEL_LOW;
	pGlobalBlower->lastStepTime=Timer_getCurrentTime10ths(elapseTimer);
	pGlobalBlower->runLevel=RUN_LEVEL_LOW;
	pGlobalBlower->bInStartupMode=FALSE;
	pGlobalBlower->LowSetting=0;
	pGlobalBlower->MediumSetting=0;
	pGlobalBlower->HighSetting=0;
	pGlobalBlower->minimum=0;
	pGlobalBlower->bInStandbyMode=FALSE;
	pGlobalBlower->currentIELevel = IE_LEVEL_INVALID;
	pGlobalBlower->ssTime = Timer_getCurrentTime10ths(elapseTimer);
	pGlobalBlower->bFlush2 = FALSE;
	pGlobalBlower->m_dwrdMaximum = MAXIMUM_PERCENTAGE;
	pGlobalBlower->m_bFlush = FALSE;

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_getTPOoutputCounts

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD GlobalBlower_getTPOoutputCounts(GlobalBlower* pGlobalBlower)
{
	WORD* value = NULL;
	PARAM_CHECK_RETURN( pGlobalBlower, "GlobalBlower_getTPOoutputCounts", 0);

	value = ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL);
	return (DWORD) *value;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_setEnableState

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void GlobalBlower_setEnableState(GlobalBlower* pGlobalBlower, BOOL enableState )
{
	PARAM_CHECK( pGlobalBlower, "GlobalBlower_setEnableState");
	pGlobalBlower->enabled = enableState;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_getEnableState

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL GlobalBlower_getEnableState( GlobalBlower* pGlobalBlower )
{
	PARAM_CHECK_RETURN( pGlobalBlower, "GlobalBlower_getEnableState", 0);
	return pGlobalBlower->enabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_getOutputPercent

 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD GlobalBlower_getOutputPercent(GlobalBlower* pGlobalBlower)
{
	PARAM_CHECK_RETURN( pGlobalBlower, "GlobalBlower_getOutputPercent", 0);
	return pGlobalBlower->TPOBlowerPercent;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_setPointChange

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void GlobalBlower_setPointChange(GlobalBlower* pGlobalBlower, BOOL setPointHasChanged )
{
	PARAM_CHECK( pGlobalBlower, "GlobalBlower_setPointChange");
	pGlobalBlower->setPointChanged = setPointHasChanged;
} 
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_process
			main process loop for global blower

 RETURNS:   void
------------------------------------------------------------------------*/

void GlobalBlower_process(GlobalBlower* pGlobalBlower)
{
	// if not enabled make sure the output is off and do not process the rest
	BOOL bCooldown;
	BOOL bInStandby;
	BOOL bLTOOption;
	BOOL bCooldownComplete;
	UINT controltype;

	DWORD dwrdJob;
	DWORD dwrdTimeDifference;
	DWORD tim;
	WORD maxOutput;

	bCooldown = FALSE;
	bInStandby = FALSE;
	controltype = 0;
	bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
	dwrdJob = Oven_getJob(ovenDb);
	dwrdTimeDifference = 0;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	bLTOOption = Oven_getLTOption(ovenDb);
	maxOutput =  MAX_TPO_COUNTS;

	if(pGlobalBlower)
	{
		maxOutput = ( ( (pGlobalBlower->m_dwrdMaximum * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE);
		if ( pGlobalBlower->enabled == FALSE )
		{
			if(!iTPOTest)	
			{
				TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
			}
			*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = 0;
		}
		else 
		{
			bCooldown = GlobalBlower_IELevelTest(pGlobalBlower);
			bInStandby = GlobalBlower_StandbyModeTest(pGlobalBlower);
			pGlobalBlower->bInStandbyMode=bInStandby;
			if( dwrdJob != pGlobalBlower->jobNo)
			{
				pGlobalBlower->jobNo = dwrdJob;
				pGlobalBlower->ssTime = pGlobalBlower->startTime =  tim;
				pGlobalBlower->m_bFlush = TRUE;
			}
			else
			{
				if(pGlobalBlower->m_bFlush)
				{
					dwrdTimeDifference = differenceWithRollover( tim, pGlobalBlower->startTime );

					if ( dwrdTimeDifference < pGlobalBlower->flushTime )
					{
						GlobalBlower_StandbyResetForSequencing(pGlobalBlower);
					}
					else
					{
						pGlobalBlower->m_bFlush = FALSE;
					}
				}
			}
		
			controltype = pGlobalBlower->controlType;
			if(ovenDb->m_EnergySaving_IntelExhaust_Enabled==FALSE)
			{
				if(controltype == INTELLIGENT_EXHAUST)
				{
					controltype = CLASSIC_BLOWERS;
				}
			}
			if(bCooldown || g_dbContainer.heatZoneBlowers.m_uintAutoClean || 
				( g_dbContainer.railsDb.m_bJogOn == TRUE ) )
			{
				controltype = CLASSIC_BLOWERS;
			}
			switch(controltype)
			{
				case STANDBY_BLOWERS:
					if(bInStandby)
					{
						TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
						if(!iTPOTest)
						{
							*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = ((ovenDb->m_EnergySaving_StandbyMode1_ZoneSpeed * MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
						}
					}
					else
					{
						if (!bCooldown)
						{
							if(pGlobalBlower->m_bFlush)
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
								}
								if(pGlobalBlower->b0100 == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
								}
							}
							else
							{
								if(pGlobalBlower->bFlush2 == TRUE)
								{
									if(pGlobalBlower->b0100 == FALSE)
									{
										*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
									}
									TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
								}									
								else
								{
									if(!iTPOTest)
									{
										TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
									}
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (WORD)(((pGlobalBlower->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
								}
							}
						}
						else // job no == COOLDOWN
						{
							if ( bCooldownComplete == FALSE )
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
								}
								*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
							}
							else
							{
								//sony wants the blower to stay at 100%
								if(!bLTOOption)
								{
									if(!iTPOTest)
									{
										TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
									}
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = 0;
								}
							}
						}
					}
					break;
				case INTELLIGENT_EXHAUST:
					TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
					switch(pGlobalBlower->runLevel)
					{
						case RUN_LEVEL_LOW:
							if(!iTPOTest)
							{
								if(bCooldown == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (ovenDb->m_EnergySaving_StandbyMode1_ExhaustSpeed*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;				
									pGlobalBlower->currentIELevel = IE_LEVEL_LOW;	
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pGlobalBlower->currentIELevel = IE_LEVEL_HI;
								}
							}				
							break;
						case RUN_LEVEL_MEDIUM:
							if(!iTPOTest)
							{
								if(bCooldown==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (ovenDb->m_EnergySaving_IntelExhaust_Speed * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pGlobalBlower->currentIELevel = IE_LEVEL_MED;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pGlobalBlower->currentIELevel = IE_LEVEL_HI;
								}
							}			
							break;
						case RUN_LEVEL_HIGH: //fall through
						default:
							if(!iTPOTest)
							{
								if(pGlobalBlower->b0100==TRUE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (WORD)(((pGlobalBlower->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;		
								}
							}
							pGlobalBlower->currentIELevel = IE_LEVEL_HI;					
							break;
					} 
					break;

				// need to detect a job change.
				// One shot it and start timing.
				case CLASSIC_BLOWERS: //fall through
				default:
					if (!bCooldown)
					{
						if( pGlobalBlower->m_bFlush )
						{
							pGlobalBlower->setPointChanged = FALSE;
							if(!iTPOTest)
							{
								TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
							}
								if(pGlobalBlower->b0100 == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS+ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
								}

						}
						else
						{
							if(pGlobalBlower->bFlush2==TRUE)
							{
								if(pGlobalBlower->b0100==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
								}
								TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
							}									
							else
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
								}
								*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (WORD)(((pGlobalBlower->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
							}
						}
					}
					else // job no == COOLDOWN
					{
						if ( bCooldownComplete == FALSE )
						{
							if(!iTPOTest)
							{
								TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
							}

							if(pGlobalBlower->b0100==FALSE)
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = (pGlobalBlower->HighSetting * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
							}
							else
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = maxOutput;
							}
						}
						else
						{
							//sony wants the blower to stay at 100%
							if(!bLTOOption)
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_GLOBAL_BLOWER_CONTROL, 0x01);
								}
								*ANALOGOUT_GetAt(analogOutDb, TPO_GLOBAL_BLOWER_CONTROL) = 0;
							}
						}
					}
					break;
			}
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_setFlushTime

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void GlobalBlower_setFlushTime(GlobalBlower* pGlobalBlower, DWORD flshTime)
{
	PARAM_CHECK( pGlobalBlower, "GlobalBlower_setFlushTime");
	pGlobalBlower->flushTime = flshTime;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_init
			inits the analog fan member variables

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_init(AnalogFan* pAnalogFan)
{
	PARAM_CHECK( pAnalogFan, "AnalogFan_init");

	pAnalogFan->startTime = 0;
	pAnalogFan->TPOBlowerPercent = 0;
	pAnalogFan->jobNo = COOLDOWN;
	pAnalogFan->enabled = FALSE;
	pAnalogFan->flushTime = 150;
	pAnalogFan->controlType=CLASSIC_BLOWERS;

	analogOutDb = &(g_dbContainer.analogOutDb);
	ovenDb = &(g_dbContainer.ovenDb);
	elapseTimer = &(g_dbContainer.elapseTimer);	
	pAnalogFan->ieRequestLevel=RUN_LEVEL_LOW;
	pAnalogFan->lastStepTime=Timer_getCurrentTime10ths(elapseTimer);
	pAnalogFan->runLevel=RUN_LEVEL_LOW;
	pAnalogFan->bInStartupMode=FALSE;
	pAnalogFan->LowSetting=0;
	pAnalogFan->mediumSetting=0;
	pAnalogFan->HighSetting=0;
	pAnalogFan->minimum=0;
	pAnalogFan->bInStandbyMode=FALSE;
	pAnalogFan->currentIELevel = IE_LEVEL_INVALID;
	pAnalogFan->ssTime = Timer_getCurrentTime10ths(elapseTimer);
	pAnalogFan->bFlush2 = FALSE;
	pAnalogFan->m_dwrdMaximum = MAXIMUM_PERCENTAGE;
	pAnalogFan->m_bFlush = FALSE;

	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_setEnableState

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_setEnableState(AnalogFan* pAnalogFan, BOOL enableState )
{
	PARAM_CHECK( pAnalogFan, "AnalogFan_setEnableState");
	pAnalogFan->enabled =  enableState;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_getTPOoutputCounts

			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD AnalogFan_getTPOoutputCounts( AnalogFan* pAnalogFan )
{
	PARAM_CHECK_RETURN( pAnalogFan, "AnalogFan_getTPOoutputCounts", 0);
	return ( DWORD )(*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN));
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_getEnableState

			
 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL AnalogFan_getEnableState( AnalogFan* pAnalogFan )
{ 
	PARAM_CHECK_RETURN( pAnalogFan, "AnalogFan_getEnableState", 0);
	return pAnalogFan->enabled;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_getOutputPercent

			
 GLOBALS:
 RETURNS:   DWORD
 SEE ALSO:
------------------------------------------------------------------------*/
DWORD AnalogFan_getOutputPercent( AnalogFan* pAnalogFan)
{
	PARAM_CHECK_RETURN( pAnalogFan, "AnalogFan_getOutputPercent", 0);
	return pAnalogFan->TPOBlowerPercent;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_setPointChange

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_setPointChange(AnalogFan* pAnalogFan, BOOL setPointHasChanged )
{
	PARAM_CHECK( pAnalogFan, "AnalogFan_setPointChange");
	pAnalogFan->setPointChanged = setPointHasChanged;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_setFlushTime

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_setFlushTime(AnalogFan* pAnalogFan, DWORD flshTime)
{
	PARAM_CHECK( pAnalogFan, "AnalogFan_setFlushTime");
	pAnalogFan->flushTime = flshTime;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_process
			main loop for analog fan
		
 RETURNS:   void
------------------------------------------------------------------------*/
void AnalogFan_process(AnalogFan* pAnalogFan)
{
	BOOL bCooldown;
	BOOL bInStandby;
	BOOL bCooldownComplete;
	DWORD dwrdJob;
	DWORD dwrdTimeDifference;
	WORD maxOutput;
	UINT controltype;
	DWORD tim;

	bCooldownComplete = Oven_isCOOLDOWNcomplete(ovenDb);
	dwrdJob = Oven_getJob(ovenDb);
	dwrdTimeDifference = 0;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	maxOutput = MAX_TPO_COUNTS;
	controltype = CLASSIC_BLOWERS;
	bCooldown = FALSE;
	bInStandby = FALSE;

	if(pAnalogFan)
	{
		maxOutput = ( ( (pAnalogFan->m_dwrdMaximum * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO ) / MAXIMUM_PERCENTAGE);
		controltype = pAnalogFan->controlType;
		bCooldown= AnalogFan_IELevelTest(pAnalogFan);
		bInStandby = AnalogFan_StandbyModeTest(pAnalogFan);
		pAnalogFan->bInStandbyMode=bInStandby;

		if ( pAnalogFan->enabled == FALSE )
		{
			if(!iTPOTest)
			{
				TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
			}
			*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = 0;
		}
		else 
		{

			if( dwrdJob != pAnalogFan->jobNo)
			{
				pAnalogFan->jobNo = dwrdJob;
				pAnalogFan->startTime =  Timer_getCurrentTime10ths(elapseTimer);
				pAnalogFan->m_bFlush = TRUE;
			}
			else
			{
				if(pAnalogFan->m_bFlush)
				{
					dwrdTimeDifference = differenceWithRollover( tim, pAnalogFan->startTime );

					if ( dwrdTimeDifference < pAnalogFan->flushTime )
					{
						AnalogFan_StandbyResetForSequencing(pAnalogFan);
					}
					else
					{
						pAnalogFan->m_bFlush = FALSE;
					}
				}
			}

			if(ovenDb->m_EnergySaving_IntelExhaust_Enabled == FALSE)
			{
				if(controltype == INTELLIGENT_EXHAUST)
				{
					controltype = CLASSIC_BLOWERS;
				}
			}
			if(bCooldown || g_dbContainer.heatZoneBlowers.m_uintAutoClean || 
				( g_dbContainer.railsDb.m_bJogOn == TRUE ) )
			{
				controltype = CLASSIC_BLOWERS;
			}
			switch(controltype)
			{
				case STANDBY_BLOWERS:
					if(bInStandby)
					{
						TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
						if(!iTPOTest)
						{
							if(pAnalogFan->b0100 == TRUE)
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = ((ovenDb->m_EnergySaving_StandbyMode1_ZoneSpeed * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
							}
							else
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (ovenDb->m_EnergySaving_StandbyMode1_ZoneSpeed*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
							}
						}
					}
					else
					{
						if ( dwrdJob == COOLDOWN )
						{
							if (bCooldownComplete == FALSE)
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
								}
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
							}
							else
							{
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
								}
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = 0;
							}
						}
						else 
						{
	
							if ( pAnalogFan->m_bFlush )
							{
								pAnalogFan->setPointChanged = FALSE;
								if(!iTPOTest)
								{
									TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
								}
								if(pAnalogFan->b0100==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
								}
							}
							else
							{
								if(pAnalogFan->bFlush2==TRUE)
								{
	
									if(pAnalogFan->b0100==FALSE)
									{
										*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
									}
									else
									{
										*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
									}
									TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
								}			
								else
								{
									if(!iTPOTest)
									{
										TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
									}
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (WORD)(((pAnalogFan->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
								}
							}
						}	
					}
					break;
				case INTELLIGENT_EXHAUST:
					TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
					switch(pAnalogFan->runLevel)
					{
						case RUN_LEVEL_LOW:
							if(!iTPOTest)
							{
								if(bCooldown==FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (ovenDb->m_EnergySaving_StandbyMode1_ExhaustSpeed*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pAnalogFan->currentIELevel = IE_LEVEL_LOW;
	
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pAnalogFan->currentIELevel = IE_LEVEL_HI;
				
								}
							}				
							break;
						case RUN_LEVEL_MEDIUM:
							if(!iTPOTest)
							{
								if(bCooldown == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (ovenDb->m_EnergySaving_IntelExhaust_Speed * MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pAnalogFan->currentIELevel = IE_LEVEL_MED;
	
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;					
									pAnalogFan->currentIELevel = IE_LEVEL_HI;
								}
							}			
							break;
						case RUN_LEVEL_HIGH: //fall through
						default:
							if(!iTPOTest)
							{
								if(pAnalogFan->b0100==TRUE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (WORD)(((pAnalogFan->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;		
								}
							}
							pAnalogFan->currentIELevel = IE_LEVEL_HI;				
							break;
					} 

					break;
				case CLASSIC_BLOWERS: //fall through
				default:
					if ( dwrdJob == COOLDOWN )
					{
						if ( (bCooldownComplete == FALSE))
						{
							if(!iTPOTest)
							{
								TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
							}
							if(pAnalogFan->b0100==FALSE)
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
							}
							else
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
							}
		
						}
						else
						{
							if(!iTPOTest)
							{
								TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
							}
							*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = 0;
						}
					}
					else 
					{
						// when a new job is loaded set output to 100% for 10 seconds then set to 
						// user settings for output percent.
						if ( pAnalogFan->m_bFlush )
						{
								if(pAnalogFan->b0100 == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
								}
						}
						else
						{	
							if(pAnalogFan->bFlush2 == TRUE)
							{
								if(pAnalogFan->b0100 == FALSE)
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (pAnalogFan->HighSetting*MAX_TPO_COUNTS + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE;
								}
								else
								{
									*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = maxOutput;
								}
							}			
							else
							{
								*ANALOGOUT_GetAt(analogOutDb, TPO_ANALOG_FAN) = (WORD)(((pAnalogFan->TPOBlowerPercent * MAX_TPO_COUNTS) + ROUND_FACTOR_TPO)/MAXIMUM_PERCENTAGE);
							}
							if(!iTPOTest)
							{
								TPO_AddSafeSegment(TPO_ANALOG_FAN, 0x01);
							}					
						}
					}	
					break;
			}
		}
	}
	return;
}


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_testCriticalPath

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_testCriticalPath(int iTest)
{
	iTPOTest = iTest;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_requestIE

			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Fans_requestIE(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, int requestLevel)
{
	PARAM_CHECK( pAnalogFan, "Fans_requestIE");
	PARAM_CHECK( pGlobalBlower, "Fans_requestIE");
	pAnalogFan->ieRequestLevel=pGlobalBlower->ieRequestLevel=requestLevel;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_IELevelTest

			tests whether the af is in ie mode or not

 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL AnalogFan_IELevelTest(AnalogFan* pAnalogFan)
{
	PARAM_CHECK_RETURN( pAnalogFan, "AnalogFan_IELevelTest", 0);
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	BOOL bReturn = FALSE;
	DWORD dwrdJob = Oven_getJob(ovenDb);
	if(dwrdJob == COOLDOWN)
	{
		bReturn = TRUE;
	}
	else if(g_dbContainer.heatZoneBlowers.m_uintAutoClean || ( g_dbContainer.railsDb.m_bJogOn == TRUE ) )//autoclean or exercise
	{
		bReturn = FALSE;  //These jobs do not allow IE or standby
	}
	else
	{
		if( pAnalogFan->controlType == INTELLIGENT_EXHAUST )
		{
			if( ( pAnalogFan->ieRequestLevel==RUN_LEVEL_HIGH ) )
			{

				if( ( pAnalogFan->runLevel != RUN_LEVEL_HIGH )  && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_HIGH_LEVEL, 3);			
				}
				pAnalogFan->runLevel = RUN_LEVEL_HIGH;
				if(pAnalogFan->controlType == INTELLIGENT_EXHAUST)
				{
					pAnalogFan->lastStepTime = tim;
				}
			}
			else if(pAnalogFan->ieRequestLevel==RUN_LEVEL_MEDIUM)
			{
				if(pAnalogFan->runLevel == RUN_LEVEL_HIGH)
				{
					if( (tim - pAnalogFan->lastStepTime ) > STANDBY_TIME)
					{
						pAnalogFan->runLevel=RUN_LEVEL_MEDIUM;
						if ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) 
						{
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, 3);
						}
					}
				}
				else
				{
					if( ( pAnalogFan->runLevel != RUN_LEVEL_MEDIUM ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, 3);
					}
					pAnalogFan->runLevel = RUN_LEVEL_MEDIUM;
					if(pAnalogFan->controlType == INTELLIGENT_EXHAUST)
					{
						pAnalogFan->lastStepTime = tim;
					}
				}
			}
			else if(pAnalogFan->runLevel != RUN_LEVEL_LOW)
			{
				if( ( tim - pAnalogFan->lastStepTime ) > STANDBY_TIME )
				{
					if( ( pAnalogFan->runLevel != RUN_LEVEL_LOW ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_LOW_LEVEL, 3);
					}
					pAnalogFan->runLevel = RUN_LEVEL_LOW;
				}
			}
		}
	}

	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_StandbyModeTest

			Standby mode test with events

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL AnalogFan_StandbyModeTest(AnalogFan* pAnalogFan)
{
	BOOL bInStandby;
	DWORD tim;
	DWORD dwrdOven;
	BOOL bSM1;
	BOOL bBoardQCondition;
	DWORD deltaTim;

	bInStandby = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	dwrdOven = Oven_getJob(ovenDb);
	bSM1 = FALSE;
	bBoardQCondition = FALSE;
	deltaTim = 0;

	if( NULL != pAnalogFan )
	{
		if( FALSE == g_bLotProcessingEnable )
		{
			bBoardQCondition =	( g_dbContainer.boardQ0_NoLP.boardCount > 0 ) || ( g_dbContainer.boardQ1_NoLP.boardCount > 0 ) || 
								( g_dbContainer.boardQ2_NoLP.boardCount > 0 ) || ( g_dbContainer.boardQ3_NoLP.boardCount > 0 ) || 
								dwrdOven == COOLDOWN;
		}
		else
		{
			bBoardQCondition =	( g_dbContainer.boardQ0.m_boardCount > 0 ) || ( g_dbContainer.boardQ1.m_boardCount > 0 ) || 
								( g_dbContainer.boardQ2.m_boardCount > 0 ) || ( g_dbContainer.boardQ3.m_boardCount > 0 ) || 
								dwrdOven == COOLDOWN;
		}

		if( bBoardQCondition )
		{
			bInStandby = FALSE;
			if(pAnalogFan->controlType == STANDBY_BLOWERS)
			{
				pAnalogFan->lastStepTime = tim;
			}
		}
		if(pAnalogFan->bInStartupMode || ( pAnalogFan->bFlush2 == TRUE ) )
		{
			AnalogFan_StandbyResetForSequencing(pAnalogFan);
		}
		if(pAnalogFan->bInStartupMode || ( pAnalogFan->bFlush2 == TRUE ) ||
			( ovenDb->mbEnergyRecipe == TRUE ) )
		{
			bInStandby = FALSE;
		}
		else
		{
			deltaTim = tim - pAnalogFan->lastStepTime;
			if( deltaTim > pAnalogFan->standbyTime )//right now all blowers are the same, so we can test just the first
			{
				bInStandby = TRUE;
			}
		}
		bSM1 = Oven_sm1(ovenDb);
		if( bSM1 == FALSE )
		{
			bInStandby = FALSE;
		}
		if( pAnalogFan->bInStandbyMode != bInStandby )
		{
			if(pAnalogFan->controlType == STANDBY_BLOWERS)
			{	
				Belts_standbyMode(&(g_dbContainer.beltsDb), bInStandby);
				Nitrogen_setStandbyMode(&(g_dbContainer.nitrogen), bInStandby);

				if(bInStandby)
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IN_STANDBY, 3);
				}
				else
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, OUT_STANDBY, 3);
				}
			}
		}
	}

	return bInStandby;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_IELevelTest
			
			ie test for gb,

 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL GlobalBlower_IELevelTest(GlobalBlower* pGlobalBlower)
{
	PARAM_CHECK_RETURN( pGlobalBlower, "GlobalBlower_IELevelTest", 0);
	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	BOOL bReturn = FALSE;
	DWORD dwrdJob = Oven_getJob(ovenDb);
	if( dwrdJob == COOLDOWN )
	{
		bReturn = TRUE;
	}
	else if( g_dbContainer.heatZoneBlowers.m_uintAutoClean || ( g_dbContainer.railsDb.m_bJogOn == TRUE ) )//autoclean or exercise
	{
		bReturn = FALSE;  //These jobs do not allow IE or standby
	}
	else
	{
		if( pGlobalBlower->controlType == INTELLIGENT_EXHAUST )
		{
			if( ( pGlobalBlower->ieRequestLevel == RUN_LEVEL_HIGH ) )
			{
				if( pGlobalBlower->runLevel != RUN_LEVEL_HIGH  && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_HIGH_LEVEL, 4);			
				}
				pGlobalBlower->runLevel = RUN_LEVEL_HIGH;
				if( pGlobalBlower->controlType == INTELLIGENT_EXHAUST )	
				{
					pGlobalBlower->lastStepTime = tim;
				}
			}
			else if( pGlobalBlower->ieRequestLevel == RUN_LEVEL_MEDIUM )
			{
				if(pGlobalBlower->runLevel==RUN_LEVEL_HIGH)
				{
					if( ( tim - pGlobalBlower->lastStepTime ) > STANDBY_TIME )
					{
						pGlobalBlower->runLevel = RUN_LEVEL_MEDIUM;
						if( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) 
						{
							AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, 4);
						}
					}
				}
				else
				{
					if( ( pGlobalBlower->runLevel != RUN_LEVEL_MEDIUM ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_MED_LEVEL, 4);
					}
					pGlobalBlower->runLevel = RUN_LEVEL_MEDIUM;
					if(pGlobalBlower->controlType == INTELLIGENT_EXHAUST)	
					{
						pGlobalBlower->lastStepTime = tim;
					}
				}
			}
			else if(pGlobalBlower->runLevel != RUN_LEVEL_LOW)
			{
				if( ( tim - pGlobalBlower->lastStepTime ) > STANDBY_TIME)
				{
					if( (pGlobalBlower->runLevel != RUN_LEVEL_LOW ) && ( ovenDb->m_EnergySaving_IntelExhaust_Enabled != FALSE ) )
					{
						AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IE_LOW_LEVEL, 4);
					}
					pGlobalBlower->runLevel = RUN_LEVEL_LOW;
				}
			}
		}
	}
	return bReturn;


}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_StandbyModeTest
			
			tests whether the global blower is in standby, produces evenmts

 RETURNS:   BOOL in standby
------------------------------------------------------------------------*/
BOOL GlobalBlower_StandbyModeTest(GlobalBlower* pGlobalBlower)
{
	BOOL bInStandby;
	DWORD tim;
	DWORD dwrdJobNo;
	BOOL bSM1;
	BOOL bBoardQCondition;
	DWORD deltaTim;

	bInStandby = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);
	dwrdJobNo = Oven_getJob(ovenDb);
	bSM1 = FALSE;
	bBoardQCondition = FALSE;
	deltaTim = 0;

	if( NULL != pGlobalBlower )
	{
		if( FALSE == g_bLotProcessingEnable )
		{
			bBoardQCondition =	( g_dbContainer.boardQ0_NoLP.boardCount > 0 ) || ( g_dbContainer.boardQ1_NoLP.boardCount > 0 ) || 
								( g_dbContainer.boardQ2_NoLP.boardCount > 0 ) || ( g_dbContainer.boardQ3_NoLP.boardCount > 0 ) || 
								dwrdJobNo == COOLDOWN;
		}
		else
		{
			bBoardQCondition =	( g_dbContainer.boardQ0.m_boardCount > 0 ) || ( g_dbContainer.boardQ1.m_boardCount > 0 ) || 
								( g_dbContainer.boardQ2.m_boardCount > 0 ) || ( g_dbContainer.boardQ3.m_boardCount > 0 ) || 
								dwrdJobNo == COOLDOWN;
		}

		if( bBoardQCondition )
		{
			bInStandby = FALSE;
			if(pGlobalBlower->controlType == STANDBY_BLOWERS)
			{
				pGlobalBlower->lastStepTime = tim;
			}
		}
		if( pGlobalBlower->bInStartupMode || ( pGlobalBlower->bFlush2 == TRUE ) )
		{
			GlobalBlower_StandbyResetForSequencing(pGlobalBlower);
		}
		if( pGlobalBlower->bInStartupMode || ( pGlobalBlower->bFlush2 == TRUE ) || ( ovenDb->mbEnergyRecipe == TRUE ) )
		{
			bInStandby = FALSE;
		}
		else
		{
			deltaTim = tim - pGlobalBlower->lastStepTime ;
			if( deltaTim > pGlobalBlower->standbyTime )//right now all blowers are the same, so we can test just the first
			{
				bInStandby = TRUE;
			}
		}
		bSM1 = Oven_sm1(ovenDb);
		if(bSM1 == FALSE)
		{
			bInStandby = FALSE;
		}
		if(pGlobalBlower->bInStandbyMode != bInStandby)
		{
			if(pGlobalBlower->controlType == STANDBY_BLOWERS)
			{	
				Belts_standbyMode(&(g_dbContainer.beltsDb), bInStandby);
				Nitrogen_setStandbyMode(&(g_dbContainer.nitrogen), bInStandby);
				if(bInStandby)
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IN_STANDBY, 4);
				}
				else
				{
					AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, OUT_STANDBY, 4);
				}
			}
		}
	}

	return bInStandby;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_toggleSMOne
			
//void Fans_toggleSMOne
//turns standby mode 1 on/off instantly
//used by start/stop buttons, DI reset in oven class

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Fans_toggleSMOne(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, BOOL on)
{
	PARAM_CHECK( pGlobalBlower, "Fans_toggleSMOne");
	PARAM_CHECK( pGlobalBlower, "Fans_pAnalogFan");

	DWORD tim = Timer_getCurrentTime10ths(elapseTimer);
	DWORD assignTime;
	if(on==TRUE)
	{
		if(pGlobalBlower->controlType==STANDBY_BLOWERS)
		{
			assignTime=tim-pGlobalBlower->standbyTime;
			pGlobalBlower->lastStepTime=assignTime;
		}
		if(pAnalogFan->controlType==STANDBY_BLOWERS)
		{
			assignTime=tim-pAnalogFan->standbyTime;
			pAnalogFan->lastStepTime=assignTime;
		}
	}
	else
	{
		if(pGlobalBlower->controlType==STANDBY_BLOWERS)
		{
			pGlobalBlower->lastStepTime=tim;
		}
		if(pAnalogFan->controlType==STANDBY_BLOWERS)
		{
			pAnalogFan->lastStepTime=tim;
		}
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  AnalogFan_StandbyResetForSequencing
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void AnalogFan_StandbyResetForSequencing(AnalogFan* pAnalogFan)
{
	PARAM_CHECK( pAnalogFan, "AnalogFan_StandbyResetForSequencing");
	if((pAnalogFan->enabled)&&(pAnalogFan->controlType==STANDBY_BLOWERS))
	{
		pAnalogFan->lastStepTime=Timer_getCurrentTime10ths(elapseTimer);
		ovenDb->mbDoReset=TRUE;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  GlobalBlower_StandbyResetForSequencing
			

 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void GlobalBlower_StandbyResetForSequencing(GlobalBlower* pGlobalBlower)
{
	PARAM_CHECK( pGlobalBlower, "GlobalBlower_StandbyResetForSequencing");
	if((pGlobalBlower->enabled)&&(pGlobalBlower->controlType==STANDBY_BLOWERS))
	{
		pGlobalBlower->lastStepTime=Timer_getCurrentTime10ths(elapseTimer);
		ovenDb->mbDoReset=TRUE;
	}
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_anyInFlush2
			
			read by the light tower, if flush 2 is active it will be held yellow

 RETURNS:   bool
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Fans_anyInFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers)
{
	PARAM_CHECK_RETURN( pGlobalBlower, "Fans_anyInFlush2", 0);
	PARAM_CHECK_RETURN( pAnalogFan, "Fans_anyInFlush2", 0);
	PARAM_CHECK_RETURN( pHeatZoneBlowers, "Fans_anyInFlush2", 0);
	BOOL bReturn = FALSE;
	int i = 0;
	BOOL bActiveBlower[MAX_HEAT_ZONE_BLOWERS];
	for( i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
	{
		bActiveBlower[i] = pHeatZoneBlowers->enabled[i];
	}
	bActiveBlower[3] = FALSE;

	if((pGlobalBlower->enabled == TRUE) && (pGlobalBlower->controlType!=INTELLIGENT_EXHAUST))
	{
		if(pGlobalBlower->bFlush2 == TRUE)
		{
			bReturn = TRUE;
		}
	}
	if((pAnalogFan->enabled == TRUE) && (pAnalogFan->controlType!=INTELLIGENT_EXHAUST))
	{
		if(pAnalogFan->bFlush2 == TRUE)
		{
			bReturn = TRUE;
		}
	}
	if((pAnalogFan->enabled == TRUE) && (pAnalogFan->controlType!=INTELLIGENT_EXHAUST))
	{
		if(pAnalogFan->bFlush2 == TRUE)
		{
			bReturn = TRUE;
		}
	}

	for(i = 0; i < MAX_HEAT_ZONE_BLOWERS; i++)
	{
		if((bActiveBlower[i] == TRUE) && (pHeatZoneBlowers->controlType[i]!=INTELLIGENT_EXHAUST))
		{
			if(pHeatZoneBlowers->bFlush2 == TRUE)
			{
				bReturn = TRUE;
			}
		}
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_beginFlush2
			
			begins flush 2 cycle for the fans, sets begin events

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Fans_beginFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers)
{
	PARAM_CHECK( pGlobalBlower, "Fans_beginFlush2");
	PARAM_CHECK( pAnalogFan, "Fans_beginFlush2");
	PARAM_CHECK( pHeatZoneBlowers, "Fans_beginFlush2");
	pHeatZoneBlowers->bFlush2 = TRUE;
	pAnalogFan->bFlush2 = TRUE;
	pGlobalBlower->bFlush2 = TRUE;
	BOOL bSend = FALSE;
	UINT group = 0;
	if((pHeatZoneBlowers->enabled[0] == TRUE) && (pHeatZoneBlowers->controlType[0]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_A;
	}
	if((pHeatZoneBlowers->enabled[1] == TRUE) && (pHeatZoneBlowers->controlType[1]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_B;
	}	
	if((pHeatZoneBlowers->enabled[2] == TRUE) && (pHeatZoneBlowers->controlType[2]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_C;
	}	
	if((pAnalogFan->enabled == TRUE) && (pAnalogFan->controlType!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_D;
	}	
	if((pGlobalBlower->enabled == TRUE) && (pGlobalBlower->controlType!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_E;
	}	
	if(bSend)
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, IN_FLUSH2, group);
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_endFlush2
			
			ends flush 2 cycle for the fans, sets end events


 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Fans_endFlush2(GlobalBlower* pGlobalBlower, AnalogFan* pAnalogFan, HeatZoneBlowers* pHeatZoneBlowers)
{
	PARAM_CHECK( pGlobalBlower, "Fans_anyInFlush2");
	PARAM_CHECK( pAnalogFan, "Fans_anyInFlush2");
	PARAM_CHECK( pHeatZoneBlowers, "Fans_anyInFlush2");
	pHeatZoneBlowers->bFlush2 = FALSE;
	pAnalogFan->bFlush2 = FALSE;
	pGlobalBlower->bFlush2 = FALSE;

	BOOL bSend = FALSE;
	UINT group = 0;
	if((pHeatZoneBlowers->enabled[0] == TRUE) && (pHeatZoneBlowers->controlType[0]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_A;
	}
	if((pHeatZoneBlowers->enabled[1] == TRUE) && (pHeatZoneBlowers->controlType[1]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_B;
	}	
	if((pHeatZoneBlowers->enabled[2] == TRUE) && (pHeatZoneBlowers->controlType[2]!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_C;
	}	
	if((pAnalogFan->enabled == TRUE) && (pAnalogFan->controlType!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_D;
	}	
	if((pGlobalBlower->enabled == TRUE) && (pGlobalBlower->controlType!=INTELLIGENT_EXHAUST))
	{
		bSend = TRUE;
		group += GROUP_E;
	}	
	if(bSend)
	{
		AlarmQueue_addAlarm(&(g_dbContainer.alarmQueueDb), LOGGED_EVENT, OUT_FLUSH2, group);
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_setMaximumOutput
			
			sets the maximum output for a blower

 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void Fans_setMaximumOutput(int blowerGroup, int MaxPercentage)
{
	UINT blowerID = MAX_HEAT_ZONE_BLOWERS;
	blowerID = (blowerGroup + 1);	
	if(blowerGroup < MAX_BLOWERS_INCLUDING_FANS)
	{
		if(blowerGroup < (MAX_HEAT_ZONE_BLOWERS - 1) )//the first 3 are classic heat zone blowers
		{
			g_dbContainer.heatZoneBlowers.m_dwrdMaximum[blowerGroup] = MaxPercentage;
		}
		else if(blowerID == GLOBAL_BLOWER_INDEX) //the 4th is the global blower
		{
			g_dbContainer.globalBlower.m_dwrdMaximum = MaxPercentage;	
		}
		else if (blowerID == ANALOG_FAN_INDEX) //the 5th is the analog fam
		{
			g_dbContainer.analogFan.m_dwrdMaximum = MaxPercentage;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_setOutputPercent
			
			sets the output percentage for a blower, with a range check

 RETURNS:   BOOL true if in allowable range
------------------------------------------------------------------------*/
BOOL Fans_setOutputPercent(unsigned int ZoneNo, int outputPercent )
{
	BOOL bEnabled;
	BOOL status;
	BOOL bAlarm;
	UINT blowerID;

	bEnabled = FALSE;
	status = TRUE;
	bAlarm = FALSE;
	blowerID = (ZoneNo - 1);//0 based, zoneNo 1 based

	if ( outputPercent < MIN_OUT_PERCENTAGE )
	{
		outputPercent = MIN_OUT_PERCENTAGE;
		status = FALSE;
	}

	if ( outputPercent > MAX_OUT_PERCENTAGE )
	{
		outputPercent = MAX_OUT_PERCENTAGE;
		status = FALSE;
	}
	if ( blowerID < MAX_BLOWERS_INCLUDING_FANS )
	{
		if ( ZoneNo < MAX_HEAT_ZONE_BLOWERS )
		{
			bEnabled = g_dbContainer.heatZoneBlowers.enabled[blowerID];
			if(	outputPercent <= g_dbContainer.heatZoneBlowers.m_dwrdMaximum[blowerID] )//passed high limit test
			{
				g_dbContainer.heatZoneBlowers.TPOBlowerPercent[blowerID] = outputPercent;
			}
			else //failed high limit, alarm set to max %
			{
				bAlarm = TRUE;
				g_dbContainer.heatZoneBlowers.TPOBlowerPercent[blowerID] = g_dbContainer.heatZoneBlowers.m_dwrdMaximum[blowerID];
			}

		}
		else if(ZoneNo == GLOBAL_BLOWER_INDEX)
		{
			bEnabled = g_dbContainer.globalBlower.enabled;
			if( ( outputPercent <= g_dbContainer.globalBlower.m_dwrdMaximum )  )
			{
				g_dbContainer.globalBlower.TPOBlowerPercent = outputPercent;
			}
			else//failed high limit, alarm set to max %
			{
				bAlarm = TRUE;
				g_dbContainer.globalBlower.TPOBlowerPercent = g_dbContainer.globalBlower.m_dwrdMaximum;
			}
		}
		else if(ZoneNo == ANALOG_FAN_INDEX)
		{
			bEnabled = g_dbContainer.analogFan.enabled;
			if(outputPercent <= g_dbContainer.analogFan.m_dwrdMaximum )
			{
				g_dbContainer.analogFan.TPOBlowerPercent = outputPercent;
			}
			else
			{
				bAlarm = TRUE;
				g_dbContainer.analogFan.TPOBlowerPercent = g_dbContainer.analogFan.m_dwrdMaximum;
			}
		}

		if(bAlarm && bEnabled)//Adds an alarm after the recipe has loaded, warning during recipe load does not work
		{
			g_dbContainer.heatZoneBlowers.m_bOutOfRangeHigh[blowerID] = TRUE;
		}

	}
	else
	{
		status = FALSE;
	}
	return status;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Fans_setMinimum
			
			sets the minimum for a blower
			also adjusts running value if below minimum

 RETURNS:   void

------------------------------------------------------------------------*/
void Fans_setMinimum(unsigned int ZoneNo, int Minimum )
{
	BOOL bEnabled;
	BOOL bLowAlarm;
	UINT blowerID;
	blowerID = (ZoneNo - 1);//0 based, zoneNo 1 based
	bLowAlarm = FALSE;
	bEnabled = FALSE;

	if ( Minimum > MAX_OUT_PERCENTAGE )
	{
		Minimum = MAX_OUT_PERCENTAGE;
	}
	if ( blowerID < MAX_BLOWERS_INCLUDING_FANS )
	{
		if ( ZoneNo < MAX_HEAT_ZONE_BLOWERS )
		{
			bEnabled = g_dbContainer.heatZoneBlowers.enabled[blowerID];
			g_dbContainer.heatZoneBlowers.minimum[blowerID] = Minimum;
			if( g_dbContainer.heatZoneBlowers.TPOBlowerPercent[blowerID] < g_dbContainer.heatZoneBlowers.minimum[blowerID] )//value failed lo limit test
			{
				g_dbContainer.heatZoneBlowers.TPOBlowerPercent[blowerID] = g_dbContainer.heatZoneBlowers.minimum[blowerID];
				bLowAlarm = TRUE;
			}
		}
		else if(ZoneNo == GLOBAL_BLOWER_INDEX)
		{
			bEnabled = g_dbContainer.globalBlower.enabled;
			g_dbContainer.globalBlower.minimum  = Minimum;
			if( ( g_dbContainer.globalBlower.TPOBlowerPercent < g_dbContainer.globalBlower.minimum ) &&
				g_dbContainer.heatZoneBlowers.m_charBounded[blowerID] )//value failed lo limit test, note at first bootup limit is set before sp, must skip warning
			{
				g_dbContainer.globalBlower.TPOBlowerPercent = g_dbContainer.globalBlower.minimum;
				bLowAlarm = TRUE;
			}
		}
		else if(ZoneNo == ANALOG_FAN_INDEX)
		{
			bEnabled = g_dbContainer.analogFan.enabled;
			g_dbContainer.analogFan.minimum  = Minimum;
			if( (g_dbContainer.analogFan.TPOBlowerPercent < g_dbContainer.analogFan.minimum ) &&
				g_dbContainer.heatZoneBlowers.m_charBounded[blowerID] )//value failed lo limit test., note at first bootup limit is set before sp, must skip warning
			{
				g_dbContainer.analogFan.TPOBlowerPercent = g_dbContainer.analogFan.minimum;
				bLowAlarm = TRUE;
			}
		}
		if(bLowAlarm && bEnabled)
		{
			g_dbContainer.heatZoneBlowers.m_bOutOfRangeLo[blowerID] = TRUE;
		}
		g_dbContainer.heatZoneBlowers.m_charBounded[blowerID] = 1;
	}

	return;
}
