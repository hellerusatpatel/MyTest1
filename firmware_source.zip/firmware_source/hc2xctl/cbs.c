/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#include "contain.h"
#include "cbs.h"
#include "digitio.h"

extern DbContainer g_dbContainer;

DOUT *digitalOutDb;
DIN *digitalInDb;


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  CBS_init

  
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void CBS_init(CBS* pCbs)
{
	PARAM_CHECK( pCbs, "CBS_init");


	pCbs->cbs_Up = Down;
	pCbs->cbs_SecondUp = Down;
	pCbs->ds_Up=Down;
	pCbs->firstCBSActiveFeedback = FALSE;
	pCbs->secondCBSActiveFeedback = FALSE;
	pCbs->firstCBSInPositionTime = 0;
	pCbs->secondCBSInPositionTime = 0;

	digitalOutDb = &( g_dbContainer.digitalOutDb );
	*DOUT_GetAt(digitalOutDb, ODO_CBS_UP) = pCbs->cbs_Up;
	*DOUT_GetAt(digitalOutDb, ODO_CBS_UP2) = pCbs->cbs_SecondUp;
	digitalInDb	= &( g_dbContainer.digitalInDb  );

	pCbs->cbs1Enabled=TRUE;
	pCbs->cbs2Enabled=TRUE;

}

void CBS_setStates(CBS* pCbs, enum CBS_State nState, UINT CBSIndex )
{
	PARAM_CHECK( pCbs, "CBS_setStates");
	switch(CBSIndex)
	{
		case 0:
		pCbs->cbs_Up = (enum CBS_State) nState;
		break;

		case 1:
		pCbs->cbs_SecondUp =(enum CBS_State) nState;
		break;

		case 2:
		pCbs->ds_Up=(enum CBS_State) nState;
		break;
	}
/*	if(CBSIndex == 0)
		pCbs->cbs_Up =(enum CBS_State) nState;
	else
		pCbs->cbs_SecondUp =(enum CBS_State) nState; */
}

void CBS_process(CBS* pCbs)
{
	PARAM_CHECK( pCbs, "CBS_process");

	if(*DIN_GetAt(digitalInDb, IDI_CBS_UPDOWN_FB) != *DOUT_GetAt(digitalOutDb, ODO_CBS_UP) )
	{
		pCbs->firstCBSInPositionTime++;
	}
	else
	{
		pCbs->firstCBSInPositionTime = 0;
	}
	if(*DIN_GetAt(digitalInDb, IDI_CBS_UPDOWN_FB2) != *DOUT_GetAt(digitalOutDb, ODO_CBS_UP2) )
	{
		pCbs->secondCBSInPositionTime++;
	}
	else
	{
		pCbs->secondCBSInPositionTime = 0;
	}
		
	if(pCbs->cbs1Enabled==TRUE)
		*DOUT_GetAt(digitalOutDb, ODO_CBS_UP) = pCbs->cbs_Up;
	if(pCbs->cbs2Enabled==TRUE)
		*DOUT_GetAt(digitalOutDb, ODO_CBS_UP2) = pCbs->cbs_SecondUp;

	if(pCbs->bDSEnabled==TRUE)
	{
		*DOUT_GetAt(digitalOutDb, pCbs->iDSDigitalOut) = pCbs->ds_Up;
	}
	
}

void CBS_setFeedbackType(CBS* pCbs, BOOL isReadBack, UINT CBSIndex)
{
	PARAM_CHECK( pCbs, "CBS_setFeedbackType");
	if(CBSIndex == 0)
		pCbs->firstCBSActiveFeedback = isReadBack;
	if(CBSIndex == 1)
		pCbs->secondCBSActiveFeedback = isReadBack;
}

BOOL CBS_areAllBoardSupportsInCorrectPosition(CBS* pCbs)
{
	PARAM_CHECK_RETURN( pCbs, "CBS_areAllBoardSupportsInCorrectPosition", FALSE);

	BOOL bReturn = TRUE;

	BOOL bCbs1 = CBS_isFirstBoardSupportInCorrectPosition( pCbs );
	BOOL bCbs2 = CBS_isSecondBoardSupportInCorrectPosition( pCbs );

	if ( bCbs1 && bCbs2 )
	{
		bReturn = TRUE;
	}
	else
	{
		bReturn = FALSE;
	}
	return bReturn;
}

BOOL CBS_isFirstBoardSupportInCorrectPosition(CBS* pCbs)
{
	BOOL bReturn = TRUE;
	PARAM_CHECK_RETURN( pCbs, "CBS_isFirstBoardSupportInCorrectPosition", FALSE);

	if(pCbs->firstCBSActiveFeedback)
	{
		if(pCbs->firstCBSInPositionTime >= 3)  //more than 3 seconds
			bReturn = FALSE;
	}

	return bReturn;
}

BOOL CBS_isSecondBoardSupportInCorrectPosition(CBS* pCbs)
{
	BOOL bReturn = TRUE;
	PARAM_CHECK_RETURN( pCbs, "CBS_isSecondBoardSupportInCorrectPosition", FALSE);

	if(pCbs->secondCBSActiveFeedback)
	{
		if(pCbs->secondCBSInPositionTime >= 3)  //more than 3 seconds
			bReturn = FALSE;
	}

	return bReturn;
}

enum CBS_State CBS_GetState(CBS* pCbs) 
{
	PARAM_CHECK_RETURN( pCbs, "CBS_GetState", 0);
	return pCbs->cbs_Up; 
}

enum CBS_State CBS_GetSecondState(CBS* pCbs) 
{
	PARAM_CHECK_RETURN( pCbs, "CBS_GetSecondState", 0);
	return pCbs->cbs_SecondUp; 
}

const char * CBS_getName(CBS* pCbs) 
{
	PARAM_CHECK_RETURN( pCbs, "CBS_getName", 0);
	return pCbs->name; 
}

void CBS_setEnable(CBS* pCbs, BOOL bEnable, UINT nIndex)
{
	pCbs->bDSEnabled=bEnable;
}

void CBS_setInput(CBS* pCbs, int iInput, UINT nIndex)
{
	pCbs->iDSDigitalIn=iInput;
}

void CBS_setOutput(CBS* pCbs, int iOutput, UINT nIndex)
{
	pCbs->iDSDigitalOut=iOutput;
}


