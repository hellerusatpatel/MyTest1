//*****************************************************************************
// Copyright (c) 1999-2016 Heller Industries, Inc., All Rights Reserved, Company Confidential
// Copyright (c) 1999-2016 iMagic, Inc., All Rights Reserved, Company Confidential
//
// File: purge.c
//
// Description: purge custom alarm code
//
// This is a trade secret of iMagic, inc. and Heller Industries, Inc
// and is protected by copyright. All unauthorized uses prohibited.
//
// Edit History:
//
// 04-Mar-16  FJN  Implement custom alarms 4 and 5
//*****************************************************************************
#include "purge.h"
#include "contain.h"
#include "alarm.h"
#include "oven.h"
#include "digitio.h"
#include "timer.h"
#include "newboardqNoLP.h"

//#define DEBUG_CUSTOM

extern DbContainer g_dbContainer;

Oven 				* ovenDb;
AlarmQueue			* alarmQueueDb;			
Timer				* elapseTimer;
DOUT 				* digitalOutDb;
DIN					* digitalInDb;

newBoardQueue			*boardQ0;
newBoardQueue			*boardQ1;
newBoardQueue			*boardQ2;
newBoardQueue			*boardQ3;

newBoardQueue_NoLP		*boardQ0_NoLP;
newBoardQueue_NoLP		*boardQ1_NoLP;
newBoardQueue_NoLP		*boardQ2_NoLP;
newBoardQueue_NoLP		*boardQ3_NoLP;

signed char cClearCustomWarning[MAX_CALARMS_BOTH_TYPES];
unsigned char cSoundOff[MAX_CALARMS_BOTH_TYPES];
signed char cSetSoundOff[MAX_CALARMS_BOTH_TYPES];
DWORD g_dwrdCA3ID;
DWORD g_dwrdCW3ID;
DWORD g_dwrdCA4ID;
DWORD g_dwrdCW4ID;
DWORD g_dwrdCA5ID;
DWORD g_dwrdCW5ID;
signed int g_iCAAlarmPos[MAX_CALARMS_BOTH_TYPES];

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_init

			Initialize the database addresses that this module will need 
			to query in order to get the state of the oven.
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_init(Purge* pPurge)
{
	int i;

	i = 0;

	if( NULL != pPurge )
	{
		pPurge->purgeTimeDuration10ths		= 0;
		pPurge->startPurgeTime10ths			= 0;
		pPurge->enabled						= FALSE;
		pPurge->m_bCycleCommenced			= FALSE;
		pPurge->m_bCooldownShouldEnableInput = FALSE;
		pPurge->m_iJobNo					= 0;
		pPurge->m_bForced					= FALSE;
		pPurge->m_bStateChanged				= FALSE;
		pPurge->m_bOutputOn					= FALSE;
		pPurge->m_bSetRecipeOutput			= FALSE;
		pPurge->m_bCondensationGo			= FALSE;
		pPurge->m_bRecipeOptionTrue			= FALSE;
		pPurge->m_bTurnSoundOff				= FALSE;
		pPurge->m_bTwoMotorActive			= FALSE;
		pPurge->m_iTwoMotorOutput			= NULL_OUTPUT;
		pPurge->m_bTwoMotorValue			= FALSE;	
		pPurge->m_shrSprayOutput			= NULL_OUTPUT;
		ovenDb = &( g_dbContainer.ovenDb				);
		alarmQueueDb = &( g_dbContainer.alarmQueueDb	);
		digitalOutDb = &( g_dbContainer.digitalOutDb	);
		elapseTimer = &( g_dbContainer.elapseTimer		);
		digitalInDb = &( g_dbContainer.digitalInDb	);
		boardQ0_NoLP=&(g_dbContainer.boardQ0_NoLP);
		boardQ1_NoLP=&(g_dbContainer.boardQ1_NoLP);
		boardQ2_NoLP=&(g_dbContainer.boardQ2_NoLP);
		boardQ3_NoLP=&(g_dbContainer.boardQ3_NoLP);

		boardQ0=&(g_dbContainer.boardQ0);
		boardQ1=&(g_dbContainer.boardQ1);
		boardQ2=&(g_dbContainer.boardQ2);
		boardQ3=&(g_dbContainer.boardQ3);

		for (i = 0; i < SPRAY_CNT; i++)
		{
			pPurge->m_bSprayOn[i] = FALSE;
		}
		for(i = 0; i < MAX_CALARMS_BOTH_TYPES; i++)
		{
			cClearCustomWarning[i] = 0;
			cSoundOff[i] = 0;
			cSetSoundOff[i] = SOUND_NOT_DEFINED;
		}
		for(i=0; i<MAX_CALARMS; i++)
		{
			pPurge->m_bCustomAlarm[i] = FALSE;
			pPurge->m_bActiveHigh[i] = FALSE;
			pPurge->m_bAudible[i] = FALSE;
			pPurge->m_dwrdDetectOnDelay[i] = 0;
			pPurge->m_dwrdLastOffTime[i] = 0;
			pPurge->m_shrtAlarmType[i] = AVAILABLE;
			pPurge->m_shrtDI[i] = NULL_INPUT;
			pPurge->m_shrtDO[i] = NULL_OUTPUT;
			pPurge->m_shrtLightTowerFilter[i] = 0;
			pPurge->selfAckAlarmNo[i] = FALSE;
			pPurge->m_bInState[i] = FALSE;
			pPurge->m_dwrdLastOffTime[i] = 0;
			pPurge->m_bAllowAddition[i] = TRUE;
		}

		pPurge->m_messageIndex[0] = CUSTOM_MESSAGE_INITED;
		pPurge->m_messageIndex[1] = CUSTOM_MESSAGE_INITED2;

		pPurge->m_bCA3Enabled = FALSE;
		pPurge->m_bCA3Warning=FALSE;
		pPurge->m_bCA3Alarm=FALSE;
		pPurge->m_bCA3Audible=FALSE;
		pPurge->m_bCA3Dist=FALSE;
		pPurge->m_bCA3High=FALSE;
		pPurge->m_bCA3WarningOutputs=FALSE;
		pPurge->m_bCA3AlarmOutput=FALSE;
		pPurge->m_dwrdCA3Input=IDI_NULL;
		pPurge->m_dwrdCA3Output=ODO_NULL;
		pPurge->m_dwrdCA3WarningTime=0;
		pPurge->m_dwrdCA3AlarmTime=0;
		pPurge->m_dwrdCA3AlarmStart=0;
		pPurge->m_dwrdCA3WarningStart=0;

		pPurge->m_bCA4Enabled = FALSE;
		pPurge->m_bCA4Warning=FALSE;
		pPurge->m_bCA4Alarm=FALSE;
		pPurge->m_bCA4Audible=FALSE;
		pPurge->m_bCA4Dist=FALSE;
		pPurge->m_bCA4High=FALSE;
		pPurge->m_bCA4WarningOutputs=FALSE;
		pPurge->m_bCA4AlarmOutput=FALSE;
		pPurge->m_dwrdCA4Input=IDI_NULL;
		pPurge->m_dwrdCA4Output=ODO_NULL;
		pPurge->m_dwrdCA4WarningTime=0;
		pPurge->m_dwrdCA4AlarmTime=0;
		pPurge->m_dwrdCA4AlarmStart=0;
		pPurge->m_dwrdCA4WarningStart=0;

		pPurge->m_bCA5Enabled = FALSE;
		pPurge->m_bCA5Warning=FALSE;
		pPurge->m_bCA5Alarm=FALSE;
		pPurge->m_bCA5Audible=FALSE;
		pPurge->m_bCA5Dist=FALSE;
		pPurge->m_bCA5High=FALSE;
		pPurge->m_bCA5WarningOutputs=FALSE;
		pPurge->m_bCA5AlarmOutput=FALSE;
		pPurge->m_dwrdCA5Input=IDI_NULL;
		pPurge->m_dwrdCA5Output=ODO_NULL;
		pPurge->m_dwrdCA5WarningTime=0;
		pPurge->m_dwrdCA5AlarmTime=0;
		pPurge->m_dwrdCA5AlarmStart=0;
		pPurge->m_dwrdCA5WarningStart=0;

		for(i=0; i<MAX_SMEMA_LANES; i++)
		{
			pPurge->m_dwrdBoardWarningOutput[i]=ODO_NULL;
			pPurge->mbBoardCountOutput[i]=ODO_NULL;
		}

		pPurge->mbBoardCountCount=BOARD_COUNT_PURGE;
		pPurge->mbBoardCountOption=FALSE;
		pPurge->mbBoardCountAction=1;
	}
	g_dwrdCA3ID = 0;
	g_dwrdCW3ID = 0;
	g_dwrdCA4ID = 0;
	g_dwrdCW4ID = 0;
	g_dwrdCA5ID = 0;
	g_dwrdCW5ID = 0;

	for(i = 0; i < MAX_CALARMS_BOTH_TYPES; i++)
	{
		g_iCAAlarmPos[i] = 0;		
	}

	return;
}
//******************************************************************************
// Purge_setPurgeTime10ths
//
// Abstract:
//	Set the purge time in 10ths of seconds.
//
// Programmer: 
// Date: 
//
//******************************************************************************
void Purge_setPurgeTime10ths(Purge* pPurge, DWORD purgeTime10thsOfSeconds )
{
	PARAM_CHECK( pPurge, "Purge_setPurgeTime10ths");
	pPurge->purgeTimeDuration10ths = purgeTime10thsOfSeconds;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_process

			Main purge processing function
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_process(Purge* pPurge)
{
	BOOL bOn;
	signed int i;
	DWORD nBoardsInOven;
	DWORD deltaT;
	UINT nJob;

	bOn = FALSE;
	i = 0;
	nBoardsInOven = 0;
	deltaT = 0;
	nJob = 0;
	
	if( NULL != pPurge )
	{
		Purge_initialization(pPurge);
		if( pPurge->m_bCA3Enabled && ( pPurge->m_bCA3Warning == TRUE || pPurge->m_bCA3Alarm == TRUE ) )
		{
			Purge_CA3Processing(pPurge);
		}
		if( pPurge->m_bCA4Enabled && ( pPurge->m_bCA4Warning == TRUE || pPurge->m_bCA4Alarm == TRUE ) )
		{
			Purge_CA4Processing(pPurge);
		}
		if( pPurge->m_bCA5Enabled && ( pPurge->m_bCA5Warning == TRUE || pPurge->m_bCA5Alarm == TRUE ) )
		{
			Purge_CA5Processing(pPurge);
		}

		if(pPurge->m_bCondensationGo && pPurge->m_bRecipeOptionTrue	&& pPurge->m_iDigitalRecipeOutput)//0 for m_iDigitalRecipeOutput used as a flag for none
		{
			if(pPurge->m_bSetRecipeOutput)
			{
				*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalRecipeOutput) = TRUE;		
			}
			else
			{
				*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalRecipeOutput) = FALSE;		
			}
		}

		if(pPurge->enabled)
		{

			if(pPurge->m_bForced) //recipe mode running
			{
					deltaT = Timer_getCurrentTime10ths(elapseTimer) - pPurge->startPurgeTime10ths;
					if( deltaT > pPurge->purgeTimeDuration10ths)
					{
						*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalOutput) = FALSE;
						bOn = FALSE;
						pPurge->m_bForced = FALSE; //Cycle expired
					}
					else
					{
						*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalOutput) = TRUE;
						bOn = TRUE;

						nJob = Oven_getJob(ovenDb);
						if( nJob > pPurge->m_iJobNo || !nJob )//switched to cooldown or loaded other job, abort(allow at least 10 seconds for state stablization
						{
							pPurge->m_bForced = FALSE;
						}
					}
			}
			else  //cooldown mode possible
			{
				nJob = Oven_getJob(ovenDb);
				if(!nJob && pPurge->m_bCooldownShouldEnableInput)//cooldown, fc recipe flag on
				{
					pPurge->m_bCycleCommenced = TRUE;
					deltaT = Timer_getCurrentTime10ths(elapseTimer) - pPurge->startPurgeTime10ths;
					if( deltaT > pPurge->purgeTimeDuration10ths )
					{
						*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalOutput) = FALSE;
						bOn = FALSE;
						pPurge->m_bCooldownShouldEnableInput = FALSE;
					}
					else
					{
						*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalOutput) = TRUE;
						bOn = TRUE;
					}
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->m_iDigitalOutput) = FALSE;
					bOn = FALSE;
				}

				nJob = Oven_getJob(ovenDb);
				if( nJob && pPurge->m_bCycleCommenced )//We have left cooldown(a job is runningprocessed at least once)
				{
					pPurge->m_bCooldownShouldEnableInput = FALSE;
					pPurge->m_bCycleCommenced = FALSE;
				}
			}
			if(bOn != pPurge->m_bOutputOn)
			{
				pPurge->m_bOutputOn = bOn; //save state
				if(pPurge->m_bOutputOn)
				{
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, PURGE_STATED, 0);
				}
				else
				{
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, PURGE_TERMINATED, 0);
				}
			}
		}

		for( i = 0; i < MAX_CALARMS; i++ )
		{
			if(pPurge->m_bCustomAlarm[i] == TRUE)
			{
				Purge_process_custom(pPurge, i);
			}
		}
				
		if(pPurge->m_bTwoMotorValue && (pPurge->m_iTwoMotorOutput != NULL_OUTPUT))
		{
			*DOUT_GetAt(digitalOutDb, pPurge->m_iTwoMotorOutput) = pPurge->m_bTwoMotorValue;
		}

		Purge_processSpray(pPurge);

		for(i=0; i<MAX_SMEMA_LANES; i++)
		{
			if(pPurge->m_dwrdBoardWarningOutput[i]!=ODO_NULL)
			{
				if(alarmQueueDb->m_bAudibleBoardInWarning[i]==TRUE)
				{
					*DOUT_GetAt(digitalOutDb, pPurge->m_dwrdBoardWarningOutput[i]) = TRUE;
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->m_dwrdBoardWarningOutput[i]) = FALSE;
				}
			}
		}

		if(pPurge->mbBoardCountOption!=FALSE)
		{
			if(pPurge->mbBoardCountOutput[0] != ODO_NULL)
			{
				if( FALSE == g_bLotProcessingEnable )
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ0_NoLP,0);
				}
				else
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount(boardQ0,0);
				}

				if( nBoardsInOven > pPurge->mbBoardCountCount )
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[0]) = pPurge->mbBoardCountAction;
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[0]) = !(pPurge->mbBoardCountAction);
				}
			}
			if(pPurge->mbBoardCountOutput[1] != ODO_NULL)
			{
				if( FALSE == g_bLotProcessingEnable )
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ1_NoLP,0);
				}
				else
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount(boardQ1,0);
				}

				if(nBoardsInOven > pPurge->mbBoardCountCount)
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[1]) = pPurge->mbBoardCountAction;
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[1]) = !(pPurge->mbBoardCountAction);
				}
			}
			if(pPurge->mbBoardCountOutput[2] != ODO_NULL)
			{
				if( FALSE == g_bLotProcessingEnable )
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ2_NoLP,0);
				}
				else
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount(boardQ2,0);
				}

				if(nBoardsInOven > pPurge->mbBoardCountCount)
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[2]) = pPurge->mbBoardCountAction;
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[2]) = !(pPurge->mbBoardCountAction);
				}
			}
			if(pPurge->mbBoardCountOutput[3] != ODO_NULL)
			{
				if( FALSE == g_bLotProcessingEnable )
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount_NoLP(boardQ3_NoLP,0);
				}
				else
				{
					nBoardsInOven = newBoardQueue_getBoardsInOvenCount(boardQ3,0);
				}

				if(nBoardsInOven > pPurge->mbBoardCountCount)
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[3]) = pPurge->mbBoardCountAction;
				}
				else
				{
					*DOUT_GetAt(digitalOutDb, pPurge->mbBoardCountOutput[3]) = !(pPurge->mbBoardCountAction);
				}
			}
		}
	}

	return;
}

void Purge_setOutputOnForCooldown(Purge* pPurge, BOOL bOn)
{ 
	PARAM_CHECK( pPurge, "Purge_setOutputOnForCooldown");
	pPurge->startPurgeTime10ths = Timer_getCurrentTime10ths(elapseTimer);
	pPurge->m_bCooldownShouldEnableInput = bOn;
}

void Purge_setActive(Purge* pPurge, BOOL state )
{
	PARAM_CHECK( pPurge, "Purge_setActive");
	pPurge->enabled = state;
}

void Purge_forceOn(Purge* pPurge)
{
	PARAM_CHECK( pPurge, "Purge_forceOn");
	pPurge->startPurgeTime10ths = Timer_getCurrentTime10ths(elapseTimer);
	pPurge->m_iJobNo = Oven_getTempJobNo(ovenDb);
	pPurge->m_bForced = TRUE;
}

void		Purge_setDigitialOutput	(Purge* pPurge, int iWhichOutput)
{
	PARAM_CHECK( pPurge, "Purge_setDigitialOutput");
	pPurge->m_iDigitalOutput = iWhichOutput;
}

DWORD		Purge_getPurgeTime10ths	(Purge* pPurge)
{
	PARAM_CHECK_RETURN( pPurge, "Purge_getPurgeTime10ths", 0);
	return pPurge->purgeTimeDuration10ths;
}

void		Purge_setRecipeOutput(Purge* pPurge, int iWhichOutput)
{
	PARAM_CHECK( pPurge, "Purge_setRecipeOutput");
	pPurge->m_iDigitalRecipeOutput = iWhichOutput;
}

void		Purge_enableRecipeOutput(Purge* pPurge, BOOL bEnable)
{
	PARAM_CHECK( pPurge, "Purge_enableRecipeOutput");
	pPurge->m_bSetRecipeOutput = bEnable;
}

void		Purge_isFluxCondensationEnabled(Purge* pPurge, BOOL bEnabled)
{
	PARAM_CHECK( pPurge, "Purge_isFluxCondensationEnabled");
	pPurge->m_bCondensationGo = bEnabled;
}

void		Purge_isFluxCondensationRecipeEnabled(Purge* pPurge, BOOL bEnabled)
{
	PARAM_CHECK( pPurge, "Purge_isFluxCondensationRecipeEnabled");
	pPurge->m_bRecipeOptionTrue = bEnabled;
}



/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_process_custom

			main process loop for custom alarm

 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_process_custom(Purge* pPurge, int iWhich)
{
	DWORD oldSelfCode;
	BOOL bInputVal;
	DWORD tim;
	DWORD dwrdJob;
	DWORD dwrdDifOff;
	
	BOOL bOutput;
	DWORD dwrdAlarmID;
	
	dwrdAlarmID = 0;
	bOutput = FALSE;

	dwrdDifOff = 0;
	dwrdJob = COOLDOWN;
	tim = 0;
	bInputVal = 0;
	oldSelfCode = 0;

	tim = Timer_getCurrentTime10ths(elapseTimer);
	if(pPurge && (pPurge->m_shrtDI[iWhich] != NULL_INPUT) ) 
	{

		oldSelfCode = pPurge->selfAckAlarmNo[iWhich];
		bInputVal = *( DIN_GetAt( digitalInDb, pPurge->m_shrtDI[iWhich] ) );
		dwrdJob = Oven_getJob(ovenDb);
		if( ( bInputVal == pPurge->m_bActiveHigh[iWhich] ) && ( dwrdJob != COOLDOWN ) ) //condition true
		{ 
			if(!pPurge->m_dwrdDetectOnDelay[iWhich])
			{
				if(pPurge->m_bAllowAddition[iWhich] || pPurge->m_shrtAlarmType[iWhich] == ALARM ||
					pPurge->m_shrtAlarmType[iWhich] == WARNING)
				{
					pPurge->selfAckAlarmNo[iWhich] = AlarmQueue_addAlarm(alarmQueueDb, pPurge->m_shrtAlarmType[iWhich], pPurge->m_messageIndex[iWhich], 0);
					pPurge->m_bInState[iWhich] = TRUE;
				}
				pPurge->m_bAllowAddition[iWhich] = FALSE;		
				if(oldSelfCode != pPurge->selfAckAlarmNo[iWhich])//if alarm add is fresh
				{
					pPurge->m_bTurnSoundOff = FALSE;
				}
				if(pPurge->m_shrtAlarmType[iWhich] == ALARM)
				{
					pPurge->selfAckAlarmNo[iWhich] =0;
				}
				if(pPurge->m_shrtDO[iWhich] != NULL_OUTPUT)//flag value for no output	
				{
					*DOUT_GetAt(digitalOutDb, pPurge->m_shrtDO[iWhich]) = TRUE;//pPurge->m_bActiveHigh[iWhich];
				}
			}
			else
			{
				dwrdDifOff = (tim - pPurge->m_dwrdLastOffTime[iWhich]);
				if( pPurge->m_dwrdDetectOnDelay[iWhich] <= dwrdDifOff )
				{
					if(pPurge->m_bAllowAddition[iWhich] || pPurge->m_shrtAlarmType[iWhich] == ALARM || 
						pPurge->m_shrtAlarmType[iWhich] == WARNING)
					{
						dwrdAlarmID = AlarmQueue_addAlarm(alarmQueueDb, pPurge->m_shrtAlarmType[iWhich],pPurge->m_messageIndex[iWhich], 0);
						if(dwrdAlarmID != 0)
						{
							pPurge->selfAckAlarmNo[iWhich] = dwrdAlarmID;
						}
						pPurge->m_bInState[iWhich] = TRUE;
					}
					pPurge->m_bAllowAddition[iWhich] = FALSE;		
			
					if(oldSelfCode != pPurge->selfAckAlarmNo[iWhich])//if alarm add is fresh
					{
						if(pPurge->m_shrtAlarmType[iWhich]==ALARM)
						{
							g_iCAAlarmPos[iWhich]=AlarmQueue_getQueuePosition(alarmQueueDb, pPurge->selfAckAlarmNo[iWhich]);
						}
						cSoundOff[iWhich] = 0;//audible output can sound
					}
	
					bOutput = TRUE;
					
				}
			}
		}
		else if(dwrdJob != COOLDOWN )
		{
			
			pPurge->m_dwrdLastOffTime[iWhich] = tim;
			pPurge->m_bAllowAddition[iWhich] = TRUE;
			if(pPurge->selfAckAlarmNo[iWhich] != 0)
			{
				AlarmQueue_alarmQueueAcknowledge(alarmQueueDb, pPurge->selfAckAlarmNo[iWhich] );
				pPurge->selfAckAlarmNo[iWhich] = 0;

				pPurge->m_bInState[iWhich]= FALSE;
			}
			
		}
		else
		{
			if(pPurge->m_shrtAlarmType[iWhich]==ALARM)
			{
				g_iCAAlarmPos[iWhich]=AlarmQueue_getQueuePosition(alarmQueueDb, pPurge->selfAckAlarmNo[iWhich]);
						
				if( ( g_iCAAlarmPos[iWhich] != -1 ) )
				{
					if(g_iCAAlarmPos[iWhich] < MaxAlarms)
					{
						if(alarmQueueDb->aq[g_iCAAlarmPos[iWhich]].acknowledge == FALSE)
						{
							bOutput = TRUE;
						}
					}				
				}
			}
				
			if(pPurge->m_shrtAlarmType[iWhich] != ALARM && pPurge->m_shrtAlarmType[iWhich] != WARNING)
			{
				pPurge->m_bInState[iWhich] = FALSE;
			}
		}
		if(pPurge->m_shrtDO[iWhich] != NULL_OUTPUT)
		{
			*DOUT_GetAt(digitalOutDb, pPurge->m_shrtDO[iWhich]) = bOutput;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_lightTowerShouldBeRed
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Purge_lightTowerShouldBeRed(Purge* pPurge)
{
	int i = 0;
	BOOL bReturn = FALSE;
	if(!pPurge->m_bCustomAlarm||!(pPurge->selfAckAlarmNo[0] || pPurge->selfAckAlarmNo[1]))
	{
		bReturn = FALSE;
	}
	else
	{
		for(i=0; ((i<MAX_CALARMS) && (bReturn==FALSE)); i++)
		{
			if(pPurge->m_shrtLightTowerFilter[i] == RED && pPurge->m_bInState[i])
			{
				bReturn = TRUE;
			}
		}
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_lightTowerShouldBeYellow
			

 GLOBALS:
 RETURNS:   BOOL
 SEE ALSO:
------------------------------------------------------------------------*/
BOOL Purge_lightTowerShouldBeYellow(Purge* pPurge)
{
	int i = 0;
	BOOL bReturn = FALSE;
	if(!pPurge->m_bCustomAlarm||!(pPurge->selfAckAlarmNo[0]||pPurge->selfAckAlarmNo[1]))
	{
		bReturn = FALSE;
	}
	else
	{
		for(i=0; ((i < MAX_CALARMS)&& (bReturn == FALSE)); i++)
		{
			if(pPurge->m_shrtLightTowerFilter[i] == AMBER && pPurge->m_bInState[i])
			{
				bReturn = TRUE;
			}
		}
	}
	return bReturn;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_inAudibleCondition
			
			used by the light tower to set audible outputs

 RETURNS:   BOOL
------------------------------------------------------------------------*/
BOOL Purge_inAudibleCondition(Purge* pPurge)
{
	int i;
	BOOL bReturn;

	i = 0;
	bReturn = FALSE;

	if(pPurge)
	{
		for(i = 0; ((i < MAX_CALARMS) && (bReturn == FALSE)); i++)
		{

			if(!cSoundOff[i])
			{
				if(pPurge->m_bCustomAlarm[i] && pPurge->m_bAudible[i] &&
					pPurge->m_bInState[i])
				{
					bReturn = TRUE;
				}
			}
		}
	}
	return bReturn;
}
void Purge_setLightTowerAction(Purge* pPurge, int shrtAffect, UINT iIndex)
{
	PARAM_CHECK( pPurge, "Purge_setLightTowerAction");
	if(iIndex >= MAX_CALARMS)
		return;
	pPurge->m_shrtLightTowerFilter[iIndex] = shrtAffect;
}

void Purge_enableCustomAlarm(Purge* pPurge, BOOL bAlarmOn, UINT iIndex)
{
	PARAM_CHECK( pPurge, "Purge_enableCustomAlarm");
	if(iIndex >= MAX_CALARMS)
		return;
	pPurge->m_dwrdLastOffTime[iIndex] = Timer_getCurrentTime10ths(elapseTimer);
	pPurge->m_bCustomAlarm[iIndex] = bAlarmOn;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Purge_setMessageType

				sets the message type

	RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setMessageType(Purge* pPurge, int shrtMsgType, UINT iIndex)
{
	if( pPurge )
	{
		if(iIndex < MAX_CALARMS)
		{
			pPurge->m_shrtAlarmType[iIndex] = shrtMsgType;
			pPurge->m_bAllowAddition[iIndex] = TRUE;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Purge_setMessageDelay

				sets the line state

	RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setMessageDelay(Purge* pPurge, DWORD dwrdDelay, UINT iIndex)
{
	if( pPurge)
	{
		if(iIndex < MAX_CALARMS)
		{
			pPurge->m_dwrdDetectOnDelay[iIndex] = dwrdDelay * TENTHS_IN_A_SECOND; 
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Purge_SetLineState

				sets the line state

	RETURNS:   void
------------------------------------------------------------------------*/
void Purge_SetLineState(Purge* pPurge, BOOL bActiveHigh, UINT iIndex)
{
	if( pPurge )
	{
		if(iIndex < MAX_CALARMS)
		{	
			pPurge->m_bActiveHigh[iIndex] = bActiveHigh;
		}
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
	FUNCTION:	Purge_suppressAudibleEvent

				clears audible output, but not warning

	RETURNS:   void
------------------------------------------------------------------------*/
void Purge_suppressAudibleEvent()
{
	int i;
	i = 0;

	for(i=0; i<MAX_CALARMS; i++)
	{
		cSetSoundOff[i] = 1;//flag to clear warning on next process cycle
	}	
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setAudibleWarning
			
			sets the audible ca

 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setAudibleWarning(Purge* pPurge, BOOL bAudible, UINT iIndex)
{
	if( pPurge )
	{
		if(iIndex < MAX_CALARMS)
		{
			pPurge->m_bAudible[iIndex] = bAudible;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setOutput
			
			sets the purge output

 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setOutput(Purge* pPurge, int shrtOutput, UINT iIndex)
{
	if( pPurge )
	{
		if(iIndex< MAX_CALARMS)
		{
			pPurge->m_shrtDO[iIndex] = shrtOutput;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setInput
			
			sets the purge input

 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setInput(Purge* pPurge, int shrtInput, UINT iIndex)
{
	if(pPurge)
	{
		if(iIndex < MAX_CALARMS)
		{
			pPurge->m_shrtDI[iIndex] = shrtInput;
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_clearWarning
			
			sets variables to clear conditions on next process loop

 RETURNS:   void

------------------------------------------------------------------------*/
void Purge_clearWarning(signed char which)
{
	BOOL bClear;
	BOOL bClearP1;
	BOOL bClearP2;

	bClear = FALSE;
	bClearP1 = FALSE;
	bClearP2 = FALSE;

	if(which < MAX_CALARMS_BOTH_TYPES)
	{
		switch(which)
		{		
			case CUSTOM_ALARM1:
				bClear = AlarmQueue_EventActive(alarmQueueDb, CUSTOM_MESSAGE_INITED, 0);
				break;

			case CUSTOM_ALARM2:
				bClear = AlarmQueue_EventActive(alarmQueueDb, CUSTOM_MESSAGE_INITED2, 0);
				break;

			case CUSTOM_ALARM3:
				bClearP1 = AlarmQueue_EventActive(alarmQueueDb, CA3_WARNING, 0);
				bClearP2 = AlarmQueue_EventActive(alarmQueueDb, CA3_ALARM, 0);
				bClear = (bClearP1 || bClearP2); 
				break;

			case CUSTOM_ALARM4:
				bClearP1 = AlarmQueue_EventActive(alarmQueueDb, CA4_WARNING, 0);
				bClearP2 = AlarmQueue_EventActive(alarmQueueDb, CA4_ALARM, 0);
				bClear = (bClearP1 || bClearP2); 
				break;

			case CUSTOM_ALARM5:
				bClearP1 = AlarmQueue_EventActive(alarmQueueDb, CA5_WARNING, 0);
				bClearP2 = AlarmQueue_EventActive(alarmQueueDb, CA5_ALARM, 0);
				bClear = (bClearP1 || bClearP2); 
				break;

			default:
				break;
			
		}
		if(bClear)
		{
			cClearCustomWarning[which] = 1;//flag to clear warning on next process cycle
			cSetSoundOff[which] = 0;
		}
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setTwoMotorActive

			Sets two motor active
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setTwoMotorActive(Purge* pPurge, BOOL bActivate)
{
	if(pPurge)
	{
		pPurge->m_bTwoMotorActive = bActivate;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setTwoMotorOutput

			Sets two motor output
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setTwoMotorOutput(Purge* pPurge, UINT iOutput)
{
	if(pPurge)
	{
		pPurge->m_iTwoMotorOutput = iOutput;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setTwoMotorOutputValue

			Sets two motor output value
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setTwoMotorOutputValue(Purge* pPurge, BOOL bValue)
{
	if(pPurge)
	{
		pPurge->m_bTwoMotorValue = bValue;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_processSpray

			process the spray cycle
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_processSpray(Purge* pPurge)
{
	BOOL bSprayOn;

	bSprayOn = FALSE;
	if(pPurge)
	{
		bSprayOn = pPurge->m_bSprayOn[0] || pPurge->m_bSprayOn[1] || pPurge->m_bSprayOn[2] || pPurge->m_bSprayOn[3];

		if(pPurge->m_shrSprayOutput !=NULL_OUTPUT)
		{
			*DOUT_GetAt(digitalOutDb, pPurge->m_shrSprayOutput) = bSprayOn;		
			if(pPurge->m_bSprayOn[4] != bSprayOn)
			{
				if(bSprayOn)
				{
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, SPRAY_ON, 0);
				}
				else
				{
					AlarmQueue_addAlarm(alarmQueueDb, LOGGED_EVENT, SPRAY_TERMINATED, 0);
				}
				pPurge->m_bSprayOn[4] = bSprayOn;
			}
		}
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setSprayOn

			sets the spray on
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setSprayOn(Purge* pPurge, BOOL bIsSpraying, UINT lane)
{
	if(pPurge)
	{
		pPurge->m_bSprayOn[lane] = bIsSpraying;
	}
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_setSprayOutput

			sets the spray output
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_setSprayOutput(Purge* pPurge, UINT iOutput)
{
	if(pPurge)
	{
		pPurge->m_shrSprayOutput = iOutput;
	}
	return;
}
/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_resetCAs

			resets custom alarms
			
 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_resetCAs(Purge* pPurge)
{
	int i;
	DWORD tim;

	i = 0;
	tim = Timer_getCurrentTime10ths(elapseTimer);

	if(pPurge)
	{
		// custom alarms 1 and 2
		for(i=0; i<MAX_CALARMS; i++)
		{
			pPurge->m_dwrdLastOffTime[i] = tim;
		}

		// custom alarm 3
		if(pPurge->m_bCA3Dist==TRUE)
		{
			pPurge->m_dwrdCA3WarningStart=0;
			pPurge->m_dwrdCA3AlarmStart=0;			
		}	
		else
		{
			pPurge->m_dwrdCA3WarningStart=tim;
			pPurge->m_dwrdCA3AlarmStart=tim;
		}

		// custom alarm 4
		if(pPurge->m_bCA4Dist==TRUE)
		{
			pPurge->m_dwrdCA4WarningStart=0;
			pPurge->m_dwrdCA4AlarmStart=0;			
		}	
		else
		{
			pPurge->m_dwrdCA4WarningStart=tim;
			pPurge->m_dwrdCA4AlarmStart=tim;
		}

		// custom alarm 5
		if(pPurge->m_bCA5Dist==TRUE)
		{
			pPurge->m_dwrdCA5WarningStart=0;
			pPurge->m_dwrdCA5AlarmStart=0;			
		}	
		else
		{
			pPurge->m_dwrdCA5WarningStart=tim;
			pPurge->m_dwrdCA5AlarmStart=tim;
		}
	}
	g_iCAAlarmPos[CUSTOM_ALARM3] = -1;
	g_iCAAlarmPos[CUSTOM_ALARM4] = -1;
	g_iCAAlarmPos[CUSTOM_ALARM5] = -1;
	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_CA3Processing

			This routine processes the custom alarm 3.  Custom alarm 3 
			has a different implementation from custom alarms 1 and 2

			RETURNS:   void
------------------------------------------------------------------------*/
void Purge_CA3Processing(Purge* pPurge)
{
	DWORD tim;
	BOOL bOutput;
	BOOL bAlarmed;
	DWORD dwrOldPos;
	DWORD dwrdDiff;

	BOOL bInputSensor;
	DWORD dwrdJob;
	DWORD dwrdAlarmID;

	dwrdAlarmID = 0;
	dwrdJob = COOLDOWN;
	bInputSensor = FALSE;

	dwrdDiff = 0;
	dwrOldPos = MaxAlarms+1;
	bAlarmed = FALSE;
	bOutput = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);

	if(pPurge)
	{
		if(pPurge->m_dwrdCA3Input != IDI_NULL)
		{
			if(pPurge->m_bCA3Warning==TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA3Input));
				dwrdJob = Oven_getJob(ovenDb);
				if((bInputSensor==pPurge->m_bCA3High) && ( dwrdJob != COOLDOWN ) )
				{
					if(pPurge->m_bCA3Dist==TRUE)
					{
						pPurge->m_dwrdCA3WarningStart += ( (g_dbContainer.belt[0].speedInCMsPerMin) / SECONDS_INA_MINUTE);

						if(pPurge->m_dwrdCA3WarningTime < pPurge->m_dwrdCA3WarningStart)
						{
							g_dwrdCW3ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA3_WARNING,0);
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA3WarningStart;
						if(dwrdDiff > pPurge->m_dwrdCA3WarningTime)
						{
							g_dwrdCW3ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA3_WARNING,0);
						}

					}
				}
				else
				{
					if(pPurge->m_bCA3Dist == TRUE)
					{
						pPurge->m_dwrdCA3WarningStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA3WarningStart = tim;
					}
				}
			}
			if(pPurge->m_bCA3Alarm == TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA3Input));
				if( bInputSensor == pPurge->m_bCA3High )
				{
					if(pPurge->m_bCA3Dist==TRUE)
					{
						pPurge->m_dwrdCA3AlarmStart += ( (g_dbContainer.belt[0].speedInCMsPerMin) / SECONDS_INA_MINUTE );					
						if(pPurge->m_dwrdCA3AlarmTime < pPurge->m_dwrdCA3AlarmStart)
						{
							bAlarmed = TRUE;
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA3AlarmStart;
						if(dwrdDiff > pPurge->m_dwrdCA3AlarmTime)
						{
							bAlarmed = TRUE;
						}

					}
					if(bAlarmed)
					{
						dwrOldPos = g_dwrdCA3ID;
						dwrdAlarmID = AlarmQueue_addAlarm(alarmQueueDb, ALARM, CA3_ALARM,0);
						if(dwrdAlarmID)
						{
							g_dwrdCA3ID = dwrdAlarmID;
						}
						if(g_dwrdCA3ID != dwrOldPos)
						{
							g_iCAAlarmPos[CUSTOM_ALARM3] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA3ID);
						}
					}
				
				}
				else
				{
					if(pPurge->m_bCA3Dist==TRUE)
					{
						pPurge->m_dwrdCA3AlarmStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA3AlarmStart = tim;
					}
				}
			}
		}
		if(pPurge->m_dwrdCA3Output != ODO_NULL)
		{
			if(pPurge->m_bCA3AlarmOutput)
			{
				if(g_iCAAlarmPos[CUSTOM_ALARM3] == -1)
				{
					g_iCAAlarmPos[CUSTOM_ALARM3] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA3ID);
				}
			
				if(pPurge->m_bCA3AlarmOutput && ( g_iCAAlarmPos[CUSTOM_ALARM3] != -1 ) )
				{
					if(g_iCAAlarmPos[CUSTOM_ALARM3] < MaxAlarms)
					{
						if(alarmQueueDb->aq[g_iCAAlarmPos[CUSTOM_ALARM3]].acknowledge == FALSE)
						{
							bOutput = TRUE;
						}
					}				
				}

			}
			if( (pPurge->m_bCA3WarningOutputs == TRUE) && (alarmQueueDb->m_bCA3Output==TRUE) )
			{
				bOutput = TRUE;
			}
			*DOUT_GetAt(digitalOutDb, pPurge->m_dwrdCA3Output) = bOutput;	
		
		}
	}
	return;
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_CA4Processing

			This routine processes the custom alarm 4.  Custom alarm 4 
			has a different implementation from custom alarms 1 and 2

			RETURNS:   void
------------------------------------------------------------------------*/
void Purge_CA4Processing(Purge* pPurge)
{
	DWORD tim;
	BOOL bOutput;
	BOOL bAlarmed;
	DWORD dwrOldPos;
	DWORD dwrdDiff;

	BOOL bInputSensor;
	DWORD dwrdJob;
	DWORD dwrdAlarmID;

	dwrdAlarmID = 0;
	dwrdJob = COOLDOWN;
	bInputSensor = FALSE;

	dwrdDiff = 0;
	dwrOldPos = MaxAlarms+1;
	bAlarmed = FALSE;
	bOutput = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);

	if(pPurge)
	{
		if(pPurge->m_dwrdCA4Input != IDI_NULL)
		{
			if(pPurge->m_bCA4Warning==TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA4Input));
				dwrdJob = Oven_getJob(ovenDb);
				if((bInputSensor==pPurge->m_bCA4High) && ( dwrdJob != COOLDOWN ) )
				{
					if(pPurge->m_bCA4Dist==TRUE)
					{
						pPurge->m_dwrdCA4WarningStart += ( (g_dbContainer.belt[0].speedInCMsPerMin) / SECONDS_INA_MINUTE);

						if(pPurge->m_dwrdCA4WarningTime < pPurge->m_dwrdCA4WarningStart)
						{
#ifdef DEBUG_CUSTOM
							printk("Purge_CA4Processing distance warningTime=%d warningStart=%d delta=%d warning triggered\n",
								pPurge->m_dwrdCA4WarningTime, pPurge->m_dwrdCA4WarningStart, (long)pPurge->m_dwrdCA4WarningTime - (long)pPurge->m_dwrdCA4WarningStart);
#endif
							g_dwrdCW4ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA4_WARNING, 0);
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA4WarningStart;
						if(dwrdDiff > pPurge->m_dwrdCA4WarningTime)
						{
#ifdef DEBUG_CUSTOM
							printk("Purge_CA4Processing time warningTime=%d tim=%d warningStart=%d delta=%d warning triggered\n",
								pPurge->m_dwrdCA4WarningTime, tim, pPurge->m_dwrdCA4WarningStart, dwrdDiff);
#endif
							g_dwrdCW4ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA4_WARNING,0);
						}
					}
				}
				else
				{
					if(pPurge->m_bCA4Dist == TRUE)
					{
						pPurge->m_dwrdCA4WarningStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA4WarningStart = tim;
					}
				}
			}
			if(pPurge->m_bCA4Alarm == TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA4Input));
				if( bInputSensor == pPurge->m_bCA4High )
				{
					if(pPurge->m_bCA4Dist==TRUE)
					{
						pPurge->m_dwrdCA4AlarmStart += g_dbContainer.belt[0].speedInCMsPerMin / SECONDS_INA_MINUTE;					
						if(pPurge->m_dwrdCA4AlarmTime < pPurge->m_dwrdCA4AlarmStart)
						{
#ifdef DEBUG_CUSTOM
							printk("Purge_CA4Processing distance alarmTime=%d alarmStart=%d delta=%d alarm triggered\n",
								pPurge->m_dwrdCA4AlarmTime, pPurge->m_dwrdCA4AlarmStart, (long)pPurge->m_dwrdCA4AlarmTime - (long)pPurge->m_dwrdCA4AlarmStart);
#endif
							bAlarmed = TRUE;
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA4AlarmStart;
						if(dwrdDiff > pPurge->m_dwrdCA4AlarmTime)
						{
#ifdef DEBUG_CUSTOM
							printk("Purge_CA4Processing time alarmTime=%d tim=%d alarmStart=%d delta=%d alarm triggered\n",
								pPurge->m_dwrdCA4AlarmTime, tim, pPurge->m_dwrdCA4AlarmStart, dwrdDiff);
#endif
							bAlarmed = TRUE;
						}
					}
					if(bAlarmed)
					{
						dwrOldPos = g_dwrdCA4ID;
						dwrdAlarmID = AlarmQueue_addAlarm(alarmQueueDb, ALARM, CA4_ALARM,0);
						if(dwrdAlarmID)
						{
							g_dwrdCA4ID = dwrdAlarmID;
						}
						if(g_dwrdCA4ID != dwrOldPos)
						{
							g_iCAAlarmPos[CUSTOM_ALARM4] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA4ID);
						}
					}
				}
				else
				{
					if(pPurge->m_bCA4Dist==TRUE)
					{
						pPurge->m_dwrdCA4AlarmStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA4AlarmStart = tim;
					}
				}
			}
		}
		if(pPurge->m_dwrdCA4Output != ODO_NULL)
		{
			if(pPurge->m_bCA4AlarmOutput)
			{
				if(g_iCAAlarmPos[CUSTOM_ALARM4] == -1)
				{
					g_iCAAlarmPos[CUSTOM_ALARM4] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA4ID);
				}
			
				if(pPurge->m_bCA4AlarmOutput && ( g_iCAAlarmPos[CUSTOM_ALARM4] != -1 ) )
				{
					if(g_iCAAlarmPos[CUSTOM_ALARM4] < MaxAlarms)
					{
						if(alarmQueueDb->aq[g_iCAAlarmPos[CUSTOM_ALARM4]].acknowledge == FALSE)
						{
							bOutput = TRUE;
						}
					}				
				}

			}
			if( (pPurge->m_bCA4WarningOutputs == TRUE) && (alarmQueueDb->m_bCA4Output==TRUE) )
			{
				bOutput = TRUE;
			}
			*DOUT_GetAt(digitalOutDb, pPurge->m_dwrdCA4Output) = bOutput;	
		}
	}
	return;
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_CA5Processing

			This routine processes the custom alarm 5.  Custom alarm 5 
			has a different implementation from custom alarms 1 and 2

			RETURNS:   void
------------------------------------------------------------------------*/
void Purge_CA5Processing(Purge* pPurge)
{
	DWORD tim;
	BOOL bOutput;
	BOOL bAlarmed;
	DWORD dwrOldPos;
	DWORD dwrdDiff;

	BOOL bInputSensor;
	DWORD dwrdJob;
	DWORD dwrdAlarmID;

	dwrdAlarmID = 0;
	dwrdJob = COOLDOWN;
	bInputSensor = FALSE;

	dwrdDiff = 0;
	dwrOldPos = MaxAlarms+1;
	bAlarmed = FALSE;
	bOutput = FALSE;
	tim = Timer_getCurrentTime10ths(elapseTimer);

	if(pPurge)
	{
		if(pPurge->m_dwrdCA5Input != IDI_NULL)
		{
			if(pPurge->m_bCA5Warning==TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA5Input));
				dwrdJob = Oven_getJob(ovenDb);
				if((bInputSensor==pPurge->m_bCA5High) && ( dwrdJob != COOLDOWN ) )
				{
					if(pPurge->m_bCA5Dist==TRUE)
					{
						pPurge->m_dwrdCA5WarningStart += ( (g_dbContainer.belt[0].speedInCMsPerMin) / SECONDS_INA_MINUTE);

						if(pPurge->m_dwrdCA5WarningTime < pPurge->m_dwrdCA5WarningStart)
						{
							g_dwrdCW5ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA5_WARNING,0);
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA5WarningStart;
						if(dwrdDiff > pPurge->m_dwrdCA5WarningTime)
						{
							g_dwrdCW5ID = AlarmQueue_addAlarm(alarmQueueDb, WARNING, CA5_WARNING,0);
						}
					}
				}
				else
				{
					if(pPurge->m_bCA5Dist == TRUE)
					{
						pPurge->m_dwrdCA5WarningStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA5WarningStart = tim;
					}
				}
			}
			if(pPurge->m_bCA5Alarm == TRUE)
			{
				bInputSensor = *(DIN_GetAt(digitalInDb, pPurge->m_dwrdCA5Input));
				if( bInputSensor == pPurge->m_bCA5High )
				{
					if(pPurge->m_bCA5Dist==TRUE)
					{
						pPurge->m_dwrdCA5AlarmStart += ( (g_dbContainer.belt[0].speedInCMsPerMin) / SECONDS_INA_MINUTE );					
						if(pPurge->m_dwrdCA5AlarmTime < pPurge->m_dwrdCA5AlarmStart)
						{
							bAlarmed = TRUE;
						}
					}	
					else
					{
						dwrdDiff = tim - pPurge->m_dwrdCA5AlarmStart;
						if(dwrdDiff > pPurge->m_dwrdCA5AlarmTime)
						{
							bAlarmed = TRUE;
						}
					}
					if(bAlarmed)
					{
						dwrOldPos = g_dwrdCA5ID;
						dwrdAlarmID = AlarmQueue_addAlarm(alarmQueueDb, ALARM, CA5_ALARM,0);
						if(dwrdAlarmID)
						{
							g_dwrdCA5ID = dwrdAlarmID;
						}
						if(g_dwrdCA5ID != dwrOldPos)
						{
							g_iCAAlarmPos[CUSTOM_ALARM5] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA5ID);
						}
					}
				}
				else
				{
					if(pPurge->m_bCA5Dist==TRUE)
					{
						pPurge->m_dwrdCA5AlarmStart = 0;
					}	
					else
					{
						pPurge->m_dwrdCA5AlarmStart = tim;
					}
				}
			}
		}
		if(pPurge->m_dwrdCA5Output != ODO_NULL)
		{
			if(pPurge->m_bCA5AlarmOutput)
			{
				if(g_iCAAlarmPos[CUSTOM_ALARM5] == -1)
				{
					g_iCAAlarmPos[CUSTOM_ALARM5] = AlarmQueue_getQueuePosition(alarmQueueDb, g_dwrdCA5ID);
				}
			
				if(pPurge->m_bCA5AlarmOutput && ( g_iCAAlarmPos[CUSTOM_ALARM5] != -1 ) )
				{
					if(g_iCAAlarmPos[CUSTOM_ALARM5] < MaxAlarms)
					{
						if(alarmQueueDb->aq[g_iCAAlarmPos[CUSTOM_ALARM5]].acknowledge == FALSE)
						{
							bOutput = TRUE;
						}
					}				
				}
			}
			if( (pPurge->m_bCA5WarningOutputs == TRUE) && (alarmQueueDb->m_bCA5Output==TRUE) )
			{
				bOutput = TRUE;
			}
			*DOUT_GetAt(digitalOutDb, pPurge->m_dwrdCA5Output) = bOutput;	
		}
	}
}	

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  Purge_initialization

			Sets variables used by the process loop

 RETURNS:   void
------------------------------------------------------------------------*/
void Purge_initialization(Purge* pPurge)
{
	int i;
	DWORD tim;
	tim = 0;
	i = 0;

	if(pPurge)
	{
		tim = Timer_getCurrentTime10ths(elapseTimer);
		for(i = 0; i < MAX_CALARMS; i++)
		{		
			if( cClearCustomWarning[i] )
			{
				pPurge->m_dwrdLastOffTime[i] = tim;
				if(pPurge->m_shrtAlarmType[i] == ALARM || pPurge->m_shrtAlarmType[i] == WARNING)
				{
					pPurge->m_bInState[i] = FALSE;
				}
				cClearCustomWarning[i] = 0;//were done

			}
			if(cSetSoundOff[i] != SOUND_NOT_DEFINED)
			{
				cSoundOff[i] = cSetSoundOff[i];
				cSetSoundOff[i] = SOUND_NOT_DEFINED;
			}
		}
		if(cClearCustomWarning[CUSTOM_ALARM3])
		{
			if(pPurge->m_bCA3Dist==TRUE)
			{
				pPurge->m_dwrdCA3AlarmStart = 0;
				pPurge->m_dwrdCA3WarningStart = 0;
			}	
			else
			{
				pPurge->m_dwrdCA3AlarmStart = tim;
				pPurge->m_dwrdCA3WarningStart = tim;
			}
			cClearCustomWarning[CUSTOM_ALARM3] = 0;//were done
		}
		if(cClearCustomWarning[CUSTOM_ALARM4])
		{
			if(pPurge->m_bCA4Dist==TRUE)
			{
				pPurge->m_dwrdCA4AlarmStart = 0;
				pPurge->m_dwrdCA4WarningStart = 0;
			}	
			else
			{
				pPurge->m_dwrdCA4AlarmStart = tim;
				pPurge->m_dwrdCA4WarningStart = tim;
			}
			cClearCustomWarning[CUSTOM_ALARM4] = 0;//were done
		}
		if(cClearCustomWarning[CUSTOM_ALARM5])
		{
			if(pPurge->m_bCA3Dist==TRUE)
			{
				pPurge->m_dwrdCA5AlarmStart = 0;
				pPurge->m_dwrdCA5WarningStart = 0;
			}	
			else
			{
				pPurge->m_dwrdCA5AlarmStart = tim;
				pPurge->m_dwrdCA5WarningStart = tim;
			}
			cClearCustomWarning[CUSTOM_ALARM5] = 0;//were done
		}
	}
	return;
}
