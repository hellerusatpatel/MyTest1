/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
#ifndef __TESTOCT__
#define __TESTOCT__

#include "typedefdefine.h"

#define  ICTC_MaxNumberChannels  134
#define T_HEATZONES 26
#define T_FLUXHEATERS 3
#define FLUXHEATZONE_TYPE 7
#define PROFILE_TYPE 8 
#define LOW_HEATZONE_TYPE 9
#define BELT_TYPE 3
#define RAIL_TYPE 1
typedef struct _IChannel_
{
//	public:
	long	channel;
	short	type;
	BOOL	enabled;
} IChannel;


typedef struct _InterCommTransferClass_
{
//Dansensor variables
	int dansensorStateInfo;
	
//public:
	short activeHeatCount;
	short activeBeltCount;
	short activeRailCount;
	short activeProfileCount;
	short activeFluxHeaterCount;
	short totalChannelsEntered;

	IChannel		channelArray[ICTC_MaxNumberChannels];
	IChannel*	activeHeatChannels[T_FLUXHEATERS + T_HEATZONES];
	IChannel*	activeBelts[2];
	IChannel*	activeRailSets[4];
	IChannel*	activeFluxHeatChannels[T_FLUXHEATERS];
	IChannel*	activeProfileChannels[7];
} InterCommTransferClass;

void InterCommTransferClass_InitMap(InterCommTransferClass* pInterCommTransferClass);
void InterCommTransferClass_init(InterCommTransferClass* pInterCommTransferClass);

void InterCommTransferClass_EnterChannel(InterCommTransferClass* pInterCommTransferClass, long channelid, short type, BOOL state);

//Dansensor functions
void InterCommTransferClass_setDanState(InterCommTransferClass* pInterCommTransferClass, int stateInfo);
int InterCommTransferClass_getDanState(InterCommTransferClass* pInterCommTransferClass);

void InterCommTransferClass_appendFluxHeatersToheatzones(InterCommTransferClass* pInterCommTransferClass);

#endif
