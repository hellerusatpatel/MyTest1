/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

	File:			boardEvents.h

	Description:	Implementation of the CHellerCommCtrl OLE control class

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/

#ifndef __BOARDEVENTS_H__
#define __BOARDEVENTS_H__

/*=======================================================================
 *
 * INCLUDE FILES:
 *
 *=======================================================================*/

#include "typedefdefine.h"
#include "BoardEventCmds.h"
#include "utility.h"
#include "boards.h"

/*========================================================================
 *
 * struct Definition: BoardEntryEvents
 *
 *=======================================================================*/   
typedef struct _BoardEntryEvents_
{
	BoardEvent	m_array[MAX_CARRIER_EVENT_COUNT];	// the listing of carrier events.
	DWORD		m_count;	// count of objects in the array

	WORD		m_sequenceNum;	// all new events get a unique sequence number.

} BoardEntryEvents;


/*========================================================================
 *
 * Function Declarations
 *
 *=======================================================================*/   

void BoardEvent_init(BoardEvent* pBoardEvent);

void BoardEntryEvents_init( BoardEntryEvents* pBoardEvents );
int BoardEntryEvents_eventAdd( BoardEntryEvents* pBoardEvents );	// returns the index of the added event, or -1
BOOL BoardEntryEvents_eventRemove( BoardEntryEvents* pBoardEvents, WORD sequenceNum );

BOOL BoardEntryEvents_AddBoardEntryEvent( BoardEntryEvents* pBoardEvents, Board* pBoard, int nLane  );


#endif
