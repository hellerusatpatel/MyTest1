/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 1999, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 
// contain.cpp

#include "contain.h"
#include "xpdriverdevice.h"


/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DbContainer_init
			
			Initializes the global database
 RETURNS:   void
------------------------------------------------------------------------*/
void DbContainer_init(DbContainer* pDbContainer)
{
	char initBuffer[6] = "empty";

	if( NULL != pDbContainer)
	{
		pDbContainer->slaveConfig.config.byte1 = 0;
		pDbContainer->slaveConfig.bWaitingForOffset = FALSE;
		pDbContainer->slaveConfig.bConfigure = FALSE;
		pDbContainer->slaveConfig.bSecondaryActive = FALSE;
		Timer_init(&(pDbContainer->elapseTimer));
		DIN_init(&(pDbContainer->digitalInDb));
		DOUT_init(&(pDbContainer->digitalOutDb));
		ANALOGIN_init(&(pDbContainer->analogInDb));
		ANALOGOUT_init(&(pDbContainer->analogOutDb));

		ErrorContainer_init(&(pDbContainer->error));

		Flasher_init( &(pDbContainer->flasherSPChange), AMBER, TRUE, FALSE );
		Flasher_init( &(pDbContainer->flasherReady), GREEN, FALSE, FALSE );
		Flasher_init( &(pDbContainer->flasherReadyBoards), GREEN, FALSE, FALSE );
		Flasher_init( &(pDbContainer->flasherWarning), AMBER, TRUE, FALSE);
		Flasher_init( &(pDbContainer->flasherAlarmCooldown), RED, TRUE, TRUE );
		Flasher_init( &(pDbContainer->flasherEstopCooldown), RED, TRUE, TRUE );
	
		AlarmQueue_init(&(pDbContainer->alarmQueueDb));
		AnalogFan_init(&(pDbContainer->analogFan));
		GlobalBlower_init(&(pDbContainer->globalBlower));
		Belts_init(&(pDbContainer->beltsDb));
		BoardDropLB_init(&(pDbContainer->boardDropLB0));
		BoardDropLB_init(&(pDbContainer->boardDropLB1));

		//Init non-LotProcessing Board Queues
		newBoardQueue_init_NoLP(&(pDbContainer->boardQ0_NoLP));
		newBoardQueue_init_NoLP(&(pDbContainer->boardQ1_NoLP));
		newBoardQueue_init_NoLP(&(pDbContainer->boardQ2_NoLP));
		newBoardQueue_init_NoLP(&(pDbContainer->boardQ3_NoLP));

		//Now Init LotProcessing Board Queues
		newBoardQueue_init(&(pDbContainer->boardQ0), "Board Queue 0");
		newBoardQueue_init(&(pDbContainer->boardQ1), "Board Queue 1");
		newBoardQueue_init(&(pDbContainer->boardQ2), "Board Queue 2");
		newBoardQueue_init(&(pDbContainer->boardQ3), "Board Queue 3");

		CBS_init(&(pDbContainer->cbs));
		FluxCondensor_init(&(pDbContainer->fluxCondensor));
		FluxFilter_init(&(pDbContainer->fluxFilter));
		FluxHeater_init(&(pDbContainer->fluxHeater), 0);
		FluxHeater_init(&(pDbContainer->fluxHeater1), 1);
		FluxHeater_init(&(pDbContainer->fluxHeater2), 2);
		FluxHeater_init(&(pDbContainer->fluxHeater3), 3);
		FluxHeater_init(&(pDbContainer->fluxHeater4), 4);
		HeatZoneBlowers_init(&(pDbContainer->heatZoneBlowers));
		LightTower_init(&(pDbContainer->lightTower));
		Lube_init(&(pDbContainer->lube1), 1);
		Lube_init(&(pDbContainer->lube2), 2 );
		MassController_init(&(pDbContainer->masscontroller));
		Maintenance_init(&(pDbContainer->maintenance));
		Nitrogen_init(&(pDbContainer->nitrogen));
		Oven_init(&(pDbContainer->ovenDb));
		CoolPipe_init(&pDbContainer->coolPipeDb);
		Oxygen_init(&(pDbContainer->oxygen));
		Rails_init(&(pDbContainer->railsDb));
		SMEMA_init(&(pDbContainer->smema1), 0);
		SMEMA_init(&(pDbContainer->smema2), 1);
		SMEMA_init(&(pDbContainer->smema3), 2);
		SMEMA_init(&(pDbContainer->smema4), 3);
		BCIO_init(&(pDbContainer->barcodeDio));

		TempZones_init(&(pDbContainer->tempZonesDb));


		Purge_init(&(pDbContainer->purge));

		InterCommTransferClass_init(&(pDbContainer->CommTransferClass));
		InterCommTransferClass_InitMap(&(pDbContainer->CommTransferClass));

		recipeTrigger_init(&(pDbContainer->recipetrigger));
		recipeTrigger_setRecipePath(&(pDbContainer->recipetrigger), initBuffer);

		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_COILS_MESSAGE, 1, 0, 56);
		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_DIGITAL_IN_MESSAGE, 1, 0, 64);
		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_ANALOG_OUT_MESSAGE, 1, 0, 32);
		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), READ_ANALOG_IN_MESSAGE, 1, 0, 60);
		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), WRITE_DIGITAL_OUT_MESSAGE, 1, 0, 56);
		Hc1xComm_addMessage(&(pDbContainer->hc1xComm), WRITE_ANALOG_OUT_MESSAGE, 1, 0, 32);

		BoardEntryEvents_init( &(pDbContainer->m_boardEvents) );

		LotProcessing_init( &(pDbContainer->m_lotProcessing) );
	}

	return;
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DbContainer_slaveConfigure
			
			when the system parameters are sent the secondary will be configured
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void DbContainer_slaveConfigure( DbContainer* pDbContainer, BOOL bStart )
{
	if ( pDbContainer )
	{
		pDbContainer->slaveConfig.config.byte1 = (pDbContainer->slaveConfig.config.byte1 & CONFIGURATION_BYTE1_MODBUS_MASTER);

		if ( bStart )
		{
			pDbContainer->slaveConfig.config.byte1 |= CONFIGURATION_BYTE1_GETTDM;
			pDbContainer->slaveConfig.config.byte1 |= CONFIGURATION_BYTE1_MODBUS_SLAVE_ACTIVE;
			pDbContainer->slaveConfig.bWaitingForOffset = TRUE;
		}
		else
		{
			pDbContainer->slaveConfig.config.byte1 |= CONFIGURATION_BYTE1_SHUTDOWN;
			pDbContainer->slaveConfig.bWaitingForOffset = FALSE;
		}
		pDbContainer->slaveConfig.bConfigure = TRUE;
	}
}

/*--(LOCAL FUNCTION)----------------------------------------------------
 FUNCTION:  DbContainer_configureIO
			
 GLOBALS:
 RETURNS:   void
 SEE ALSO:
------------------------------------------------------------------------*/
void DbContainer_configureIO( DbContainer* pDbContainer )
{
	TempZones_configureTempZoneIO( &(pDbContainer->tempZonesDb) );
}
///////////////////////////////////////////////////////////////////////////////////////////////
//
//FluxHeater* DbContainer_getCorrectFluxheater(UINT iWhichFluxheater)
//
//Currently there is a lot of if else statements in the driver to switch between flux0 and flux1
//with the addition of a third flux zone a function to return the pointer seemed to make more sense
//
//WDT
//
////////////////////////////////////////////////////////////////////////////////////////////////
FluxHeater* DbContainer_getCorrectFluxheater(DbContainer* pDbContainer, UINT iWhichFluxheater)
{
	PARAM_CHECK_RETURN( pDbContainer, "DbContainer_getCorrectFluxheater", NULL);

	switch(iWhichFluxheater)
	{
	case 0:
		return &(pDbContainer->fluxHeater);
		break;

	case 1:
		return &(pDbContainer->fluxHeater1);
		break;

	case 2:
		return &(pDbContainer->fluxHeater2);
		break;
	case 3:
		return &(pDbContainer->fluxHeater3);
		break;

	case 4:
		return &(pDbContainer->fluxHeater4);
		break;
//The default condition should not be reached, returning a valid pointer to prevent system crash
	default:
		return &(pDbContainer->fluxHeater);
		break;
	}
}

