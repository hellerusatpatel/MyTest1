
/**************************************************************************
    Heller Industries, Inc.
    imagic, Inc.    Copyright (C) 2002, All Rights Reserved
                    Company Confidential

    This is a trade secret of imagic, inc. and Heller Industries, Inc
    and is protected by copyright.All unauthorized uses prohibited.
***************************************************************************/ 

#include "contain.h"
#include "setpointtransfer.h"
#include "typedefdefine.h"

extern DbContainer g_dbContainer;

//UINT recipeTrigger::m_actionControl = 0;


void SecondaryBoardData_init(SecondaryBoardData* pSecondaryBoardData, const char *szName 	)
{
	PARAM_CHECK( pSecondaryBoardData, "SecondaryBoardData_init");
	if ( szName )
		strcpy(pSecondaryBoardData->name, szName);
	pSecondaryBoardData->bMonitoring	= FALSE;
	pSecondaryBoardData->bReading		= FALSE;
	pSecondaryBoardData->iCommError		= 0;
	pSecondaryBoardData->bCommunicationTimeOut = FALSE;
	pSecondaryBoardData->bSendTPO		= FALSE;
	pSecondaryBoardData->iReadingAttempts = 0;
}

void SecondaryBoardData_InitializeTPObuffer(SecondaryBoardData* pSecondaryBoardData)
{
	int i;
	PARAM_CHECK( pSecondaryBoardData, "SecondaryBoardData_InitializeTPObuffer");

	for( i = 0; i < MAX_DIGITAL_OUTPUTS; i++)
		pSecondaryBoardData->setpoints[i] = 256; //default the tpo to on, assume primary controller handles errors
}

void SecondaryBoardData_setMonitoringStatusFromSecondBoard(SecondaryBoardData* pSecondaryBoardData, BOOL bIsSendingData)
{
	PARAM_CHECK( pSecondaryBoardData, "SecondaryBoardData_setMonitoringStatusFromSecondBoard");
	pSecondaryBoardData->bMonitoring = bIsSendingData;
}

void SecondaryBoardData_setMonitoringStatusFromHdac(SecondaryBoardData* pSecondaryBoardData, BOOL bWillAcceptData)
{
	PARAM_CHECK( pSecondaryBoardData, "SecondaryBoardData_setMonitoringStatusFromHdac");
	pSecondaryBoardData->bMasterOnOff = bWillAcceptData;
}

BOOL SecondaryBoardData_getMonitoringStatusCombined(SecondaryBoardData* pSecondaryBoardData)
{
	PARAM_CHECK_RETURN( pSecondaryBoardData, "SecondaryBoardData_getMonitoringStatusCombined", 0);
	return (pSecondaryBoardData->bMonitoring && pSecondaryBoardData->bMasterOnOff);
}

/////////////////////////////////////////////////////////////////////
//
//Used to flag a failure of communications with the Hc1x, will accept
//additional state values for future use
/////////////////////////////////////////////////////////////////////
void SecondaryBoardData_setHc1xQuality(SecondaryBoardData* pSecondaryBoardData, int hc1xIndicators)
{
	PARAM_CHECK( pSecondaryBoardData, "SecondaryBoardData_setHc1xQuality");
	switch (hc1xIndicators)
	{
	case 0:
		pSecondaryBoardData->bCommunicationTimeOut = FALSE;
		break;
	case 1:
		pSecondaryBoardData->bCommunicationTimeOut = TRUE;
		break;
	case 2:
		pSecondaryBoardData->bCommunicationTimeOut = FALSE;
		pSecondaryBoardData->bMonitoring = TRUE;
		break;
	}
}

void SecondaryBoardData_assignTPO(SecondaryBoardData* pSecondaryBoardData, UINT index,  WORD wVal)
{
	if(index >=MAX_DIGITAL_OUTPUTS)
	{
		printk("invalid index in SecondaryBoardData_assignTPO %d\n", index);
	}
	pSecondaryBoardData->setpoints[index]= wVal;
}
